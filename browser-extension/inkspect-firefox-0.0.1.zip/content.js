"use strict";(()=>{var Q1=Object.create;var Zp=Object.defineProperty;var Z1=Object.getOwnPropertyDescriptor;var J1=Object.getOwnPropertyNames;var $1=Object.getPrototypeOf,P1=Object.prototype.hasOwnProperty;var un=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports}catch(n){throw t=0,n}};var F1=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of J1(t))!P1.call(e,a)&&a!==n&&Zp(e,a,{get:()=>t[a],enumerable:!(o=Z1(t,a))||o.enumerable});return e};var D=(e,t,n)=>(n=e!=null?Q1($1(e)):{},F1(t||!e||!e.__esModule?Zp(n,"default",{value:e,enumerable:!0}):n,e));var lm=un(ke=>{"use strict";function Zu(e,t){var n=e.length;e.push(t);e:for(;0<n;){var o=n-1>>>1,a=e[o];if(0<gc(a,t))e[o]=t,e[n]=a,n=o;else break e}}function sn(e){return e.length===0?null:e[0]}function yc(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;e:for(var o=0,a=e.length,l=a>>>1;o<l;){var i=2*(o+1)-1,c=e[i],r=i+1,u=e[r];if(0>gc(c,n))r<a&&0>gc(u,c)?(e[o]=u,e[r]=n,o=r):(e[o]=c,e[i]=n,o=i);else if(r<a&&0>gc(u,n))e[o]=u,e[r]=n,o=r;else break e}}return t}function gc(e,t){var n=e.sortIndex-t.sortIndex;return n!==0?n:e.id-t.id}ke.unstable_now=void 0;typeof performance=="object"&&typeof performance.now=="function"?(Pp=performance,ke.unstable_now=function(){return Pp.now()}):(Ku=Date,Fp=Ku.now(),ke.unstable_now=function(){return Ku.now()-Fp});var Pp,Ku,Fp,On=[],no=[],ew=1,Lt=null,at=3,Ju=!1,Pl=!1,Fl=!1,$u=!1,em=typeof setTimeout=="function"?setTimeout:null,tm=typeof clearTimeout=="function"?clearTimeout:null,Ip=typeof setImmediate<"u"?setImmediate:null;function vc(e){for(var t=sn(no);t!==null;){if(t.callback===null)yc(no);else if(t.startTime<=e)yc(no),t.sortIndex=t.expirationTime,Zu(On,t);else break;t=sn(no)}}function Pu(e){if(Fl=!1,vc(e),!Pl)if(sn(On)!==null)Pl=!0,_a||(_a=!0,Da());else{var t=sn(no);t!==null&&Fu(Pu,t.startTime-e)}}var _a=!1,Il=-1,nm=5,om=-1;function am(){return $u?!0:!(ke.unstable_now()-om<nm)}function Gu(){if($u=!1,_a){var e=ke.unstable_now();om=e;var t=!0;try{e:{Pl=!1,Fl&&(Fl=!1,tm(Il),Il=-1),Ju=!0;var n=at;try{t:{for(vc(e),Lt=sn(On);Lt!==null&&!(Lt.expirationTime>e&&am());){var o=Lt.callback;if(typeof o=="function"){Lt.callback=null,at=Lt.priorityLevel;var a=o(Lt.expirationTime<=e);if(e=ke.unstable_now(),typeof a=="function"){Lt.callback=a,vc(e),t=!0;break t}Lt===sn(On)&&yc(On),vc(e)}else yc(On);Lt=sn(On)}if(Lt!==null)t=!0;else{var l=sn(no);l!==null&&Fu(Pu,l.startTime-e),t=!1}}break e}finally{Lt=null,at=n,Ju=!1}t=void 0}}finally{t?Da():_a=!1}}}var Da;typeof Ip=="function"?Da=function(){Ip(Gu)}:typeof MessageChannel<"u"?(Qu=new MessageChannel,Wp=Qu.port2,Qu.port1.onmessage=Gu,Da=function(){Wp.postMessage(null)}):Da=function(){em(Gu,0)};var Qu,Wp;function Fu(e,t){Il=em(function(){e(ke.unstable_now())},t)}ke.unstable_IdlePriority=5;ke.unstable_ImmediatePriority=1;ke.unstable_LowPriority=4;ke.unstable_NormalPriority=3;ke.unstable_Profiling=null;ke.unstable_UserBlockingPriority=2;ke.unstable_cancelCallback=function(e){e.callback=null};ke.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):nm=0<e?Math.floor(1e3/e):5};ke.unstable_getCurrentPriorityLevel=function(){return at};ke.unstable_next=function(e){switch(at){case 1:case 2:case 3:var t=3;break;default:t=at}var n=at;at=t;try{return e()}finally{at=n}};ke.unstable_requestPaint=function(){$u=!0};ke.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=at;at=e;try{return t()}finally{at=n}};ke.unstable_scheduleCallback=function(e,t,n){var o=ke.unstable_now();switch(typeof n=="object"&&n!==null?(n=n.delay,n=typeof n=="number"&&0<n?o+n:o):n=o,e){case 1:var a=-1;break;case 2:a=250;break;case 5:a=1073741823;break;case 4:a=1e4;break;default:a=5e3}return a=n+a,e={id:ew++,callback:t,priorityLevel:e,startTime:n,expirationTime:a,sortIndex:-1},n>o?(e.sortIndex=n,Zu(no,e),sn(On)===null&&e===sn(no)&&(Fl?(tm(Il),Il=-1):Fl=!0,Fu(Pu,n-o))):(e.sortIndex=a,Zu(On,e),Pl||Ju||(Pl=!0,_a||(_a=!0,Da()))),e};ke.unstable_shouldYield=am;ke.unstable_wrapCallback=function(e){var t=at;return function(){var n=at;at=t;try{return e.apply(this,arguments)}finally{at=n}}}});var cm=un((Q2,im)=>{"use strict";im.exports=lm()});var wm=un(X=>{"use strict";var es=Symbol.for("react.transitional.element"),tw=Symbol.for("react.portal"),nw=Symbol.for("react.fragment"),ow=Symbol.for("react.strict_mode"),aw=Symbol.for("react.profiler"),lw=Symbol.for("react.consumer"),iw=Symbol.for("react.context"),cw=Symbol.for("react.forward_ref"),rw=Symbol.for("react.suspense"),uw=Symbol.for("react.memo"),fm=Symbol.for("react.lazy"),sw=Symbol.for("react.activity"),dw=Symbol.for("react.view_transition"),rm=Symbol.iterator;function fw(e){return e===null||typeof e!="object"?null:(e=rm&&e[rm]||e["@@iterator"],typeof e=="function"?e:null)}var pm={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},mm=Object.assign,bm={};function Ha(e,t,n){this.props=e,this.context=t,this.refs=bm,this.updater=n||pm}Ha.prototype.isReactComponent={};Ha.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};Ha.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function hm(){}hm.prototype=Ha.prototype;function ts(e,t,n){this.props=e,this.context=t,this.refs=bm,this.updater=n||pm}var ns=ts.prototype=new hm;ns.constructor=ts;mm(ns,Ha.prototype);ns.isPureReactComponent=!0;var um=Array.isArray;function Wu(){}var ve={H:null,A:null,T:null,S:null},gm=Object.prototype.hasOwnProperty;function os(e,t,n){var o=n.ref;return{$$typeof:es,type:e,key:t,ref:o!==void 0?o:null,props:n}}function pw(e,t){return os(e.type,t,e.props)}function as(e){return typeof e=="object"&&e!==null&&e.$$typeof===es}function mw(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var sm=/\/+/g;function Iu(e,t){return typeof e=="object"&&e!==null&&e.key!=null?mw(""+e.key):t.toString(36)}function bw(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(Wu,Wu):(e.status="pending",e.then(function(t){e.status==="pending"&&(e.status="fulfilled",e.value=t)},function(t){e.status==="pending"&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function Ua(e,t,n,o,a){var l=typeof e;(l==="undefined"||l==="boolean")&&(e=null);var i=!1;if(e===null)i=!0;else switch(l){case"bigint":case"string":case"number":i=!0;break;case"object":switch(e.$$typeof){case es:case tw:i=!0;break;case fm:return i=e._init,Ua(i(e._payload),t,n,o,a)}}if(i)return a=a(e),i=o===""?"."+Iu(e,0):o,um(a)?(n="",i!=null&&(n=i.replace(sm,"$&/")+"/"),Ua(a,t,n,"",function(u){return u})):a!=null&&(as(a)&&(a=pw(a,n+(a.key==null||e&&e.key===a.key?"":(""+a.key).replace(sm,"$&/")+"/")+i)),t.push(a)),1;i=0;var c=o===""?".":o+":";if(um(e))for(var r=0;r<e.length;r++)o=e[r],l=c+Iu(o,r),i+=Ua(o,t,n,l,a);else if(r=fw(e),typeof r=="function")for(e=r.call(e),r=0;!(o=e.next()).done;)o=o.value,l=c+Iu(o,r++),i+=Ua(o,t,n,l,a);else if(l==="object"){if(typeof e.then=="function")return Ua(bw(e),t,n,o,a);throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return i}function wc(e,t,n){if(e==null)return e;var o=[],a=0;return Ua(e,o,"","",function(l){return t.call(n,l,a++)}),o}function hw(e){if(e._status===-1){var t=e._result,n=t();n.then(function(o){(e._status===0||e._status===-1)&&(e._status=1,e._result=o,n.status===void 0&&(n.status="fulfilled",n.value=o))},function(o){(e._status===0||e._status===-1)&&(e._status=2,e._result=o,n.status===void 0&&(n.status="rejected",n.reason=o))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var dm=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)};function vm(e){var t=ve.T,n={};n.types=t!==null?t.types:null,ve.T=n;try{var o=e(),a=ve.S;a!==null&&a(n,o),typeof o=="object"&&o!==null&&typeof o.then=="function"&&o.then(Wu,dm)}catch(l){dm(l)}finally{t!==null&&n.types!==null&&(t.types=n.types),ve.T=t}}function ym(e){var t=ve.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else vm(ym.bind(null,e))}var gw={map:wc,forEach:function(e,t,n){wc(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return wc(e,function(){t++}),t},toArray:function(e){return wc(e,function(t){return t})||[]},only:function(e){if(!as(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};X.Activity=sw;X.Children=gw;X.Component=Ha;X.Fragment=nw;X.Profiler=aw;X.PureComponent=ts;X.StrictMode=ow;X.Suspense=rw;X.ViewTransition=dw;X.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=ve;X.__COMPILER_RUNTIME={__proto__:null,c:function(e){return ve.H.useMemoCache(e)}};X.addTransitionType=ym;X.cache=function(e){return function(){return e.apply(null,arguments)}};X.cacheSignal=function(){return null};X.cloneElement=function(e,t,n){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var o=mm({},e.props),a=e.key;if(t!=null)for(l in t.key!==void 0&&(a=""+t.key),t)!gm.call(t,l)||l==="key"||l==="__self"||l==="__source"||l==="ref"&&t.ref===void 0||(o[l]=t[l]);var l=arguments.length-2;if(l===1)o.children=n;else if(1<l){for(var i=Array(l),c=0;c<l;c++)i[c]=arguments[c+2];o.children=i}return os(e.type,a,o)};X.createContext=function(e){return e={$$typeof:iw,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:lw,_context:e},e};X.createElement=function(e,t,n){var o,a={},l=null;if(t!=null)for(o in t.key!==void 0&&(l=""+t.key),t)gm.call(t,o)&&o!=="key"&&o!=="__self"&&o!=="__source"&&(a[o]=t[o]);var i=arguments.length-2;if(i===1)a.children=n;else if(1<i){for(var c=Array(i),r=0;r<i;r++)c[r]=arguments[r+2];a.children=c}if(e&&e.defaultProps)for(o in i=e.defaultProps,i)a[o]===void 0&&(a[o]=i[o]);return os(e,l,a)};X.createRef=function(){return{current:null}};X.forwardRef=function(e){return{$$typeof:cw,render:e}};X.isValidElement=as;X.lazy=function(e){return{$$typeof:fm,_payload:{_status:-1,_result:e},_init:hw}};X.memo=function(e,t){return{$$typeof:uw,type:e,compare:t===void 0?null:t}};X.startTransition=vm;X.unstable_useCacheRefresh=function(){return ve.H.useCacheRefresh()};X.use=function(e){return ve.H.use(e)};X.useActionState=function(e,t,n){return ve.H.useActionState(e,t,n)};X.useCallback=function(e,t){return ve.H.useCallback(e,t)};X.useContext=function(e){return ve.H.useContext(e)};X.useDebugValue=function(){};X.useDeferredValue=function(e,t){return ve.H.useDeferredValue(e,t)};X.useEffect=function(e,t){return ve.H.useEffect(e,t)};X.useEffectEvent=function(e){return ve.H.useEffectEvent(e)};X.useId=function(){return ve.H.useId()};X.useImperativeHandle=function(e,t,n){return ve.H.useImperativeHandle(e,t,n)};X.useInsertionEffect=function(e,t){return ve.H.useInsertionEffect(e,t)};X.useLayoutEffect=function(e,t){return ve.H.useLayoutEffect(e,t)};X.useMemo=function(e,t){return ve.H.useMemo(e,t)};X.useOptimistic=function(e,t){return ve.H.useOptimistic(e,t)};X.useReducer=function(e,t,n){return ve.H.useReducer(e,t,n)};X.useRef=function(e){return ve.H.useRef(e)};X.useState=function(e){return ve.H.useState(e)};X.useSyncExternalStore=function(e,t,n){return ve.H.useSyncExternalStore(e,t,n)};X.useTransition=function(){return ve.H.useTransition()};X.version="19.3.0"});var Ze=un((J2,xm)=>{"use strict";xm.exports=wm()});var Em=un(lt=>{"use strict";var vw=Ze();function km(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function oo(){}var rt={d:{f:oo,r:function(){throw Error(km(522))},D:oo,C:oo,L:oo,m:oo,X:oo,S:oo,M:oo},p:0,findDOMNode:null},yw=Symbol.for("react.portal"),ww=Symbol.for("react.recoverable"),Sm=Symbol.for("react.optimistic_key");function xw(e,t,n){var o=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:yw,key:o==null?null:o===Sm?Sm:""+o,children:e,containerInfo:t,implementation:n}}var Wl=vw.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function xc(e,t){if(e==="font")return"";if(typeof t=="string")return t==="use-credentials"?t:""}lt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=rt;lt.browser=function(e){return{$$typeof:ww,_reason:e}};lt.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(km(299));return xw(e,t,null,n)};lt.flushSync=function(e){var t=Wl.T,n=rt.p;try{if(Wl.T=null,rt.p=2,e)return e()}finally{Wl.T=t,rt.p=n,rt.d.f()}};lt.preconnect=function(e,t){typeof e=="string"&&(t?(t=t.crossOrigin,t=typeof t=="string"?t==="use-credentials"?t:"":void 0):t=null,rt.d.C(e,t))};lt.prefetchDNS=function(e){typeof e=="string"&&rt.d.D(e)};lt.preinit=function(e,t){if(typeof e=="string"&&t&&typeof t.as=="string"){var n=t.as,o=xc(n,t.crossOrigin),a=typeof t.integrity=="string"?t.integrity:void 0,l=typeof t.fetchPriority=="string"?t.fetchPriority:void 0;n==="style"?rt.d.S(e,typeof t.precedence=="string"?t.precedence:void 0,{crossOrigin:o,integrity:a,fetchPriority:l}):n==="script"&&rt.d.X(e,{crossOrigin:o,integrity:a,fetchPriority:l,nonce:typeof t.nonce=="string"?t.nonce:void 0})}};lt.preinitModule=function(e,t){if(typeof e=="string")if(typeof t=="object"&&t!==null){if(t.as==null||t.as==="script"){var n=xc(t.as,t.crossOrigin);rt.d.M(e,{crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}}else t==null&&rt.d.M(e)};lt.preload=function(e,t){if(typeof e=="string"&&typeof t=="object"&&t!==null&&typeof t.as=="string"){var n=t.as,o=xc(n,t.crossOrigin);rt.d.L(e,n,{crossOrigin:o,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,type:typeof t.type=="string"?t.type:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy=="string"?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet=="string"?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes=="string"?t.imageSizes:void 0,media:typeof t.media=="string"?t.media:void 0})}};lt.preloadModule=function(e,t){if(typeof e=="string")if(t){var n=xc(t.as,t.crossOrigin);rt.d.m(e,{as:typeof t.as=="string"&&t.as!=="script"?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}else rt.d.m(e)};lt.requestFormReset=function(e){rt.d.r(e)};lt.unstable_batchedUpdates=function(e,t){return e(t)};lt.useFormState=function(e,t,n){return Wl.H.useFormState(e,t,n)};lt.useFormStatus=function(){return Wl.H.useHostTransitionStatus()};lt.version="19.3.0"});var Sc=un((P2,Cm)=>{"use strict";function Tm(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Tm)}catch(e){console.error(e)}}Tm(),Cm.exports=Em()});var f0=un(ou=>{"use strict";var qe=cm(),dh=Ze(),Sw=Sc();function C(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function fh(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Yi(e){for(var t=e,n=t;n&&!n.alternate;)t=n,(t.flags&4098)!==0&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function ph(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function mh(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Nm(e){if(Yi(e)!==e)throw Error(C(188))}function kw(e){var t=e.alternate;if(!t){if(t=Yi(e),t===null)throw Error(C(188));return t!==e?null:e}for(var n=e,o=t;;){var a=n.return;if(a===null)break;var l=a.alternate;if(l===null){if(o=a.return,o!==null){n=o;continue}break}if(a.child===l.child){for(l=a.child;l;){if(l===n)return Nm(a),e;if(l===o)return Nm(a),t;l=l.sibling}throw Error(C(188))}if(n.return!==o.return)n=a,o=l;else{for(var i=!1,c=a.child;c;){if(c===n){i=!0,n=a,o=l;break}if(c===o){i=!0,o=a,n=l;break}c=c.sibling}if(!i){for(c=l.child;c;){if(c===n){i=!0,n=l,o=a;break}if(c===o){i=!0,o=l,n=a;break}c=c.sibling}if(!i)throw Error(C(189))}}if(n.alternate!==o)throw Error(C(190))}if(n.tag!==3)throw Error(C(188));return n.stateNode.current===n?e:t}function bh(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=bh(e),t!==null)return t;e=e.sibling}return null}function wt(e,t,n,o,a,l){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,o,a,l)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&wt(e.child,t,n,o,a,l))return!0;e=e.sibling}return!1}function ha(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function Mm(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),!(e.tag===3||e.tag===5||e.tag===27));)e=e.return;return t}function hh(e){var t=[null,null],n=ha(e);return n===null||gh(t,e,n.child,{foundSelf:!1}),t}function gh(e,t,n,o){for(;n!==null;){if(n===t)o.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(o.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&gh(e,t,n.child,o))return!0;n=n.sibling}return!1}function Le(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(C(559))}}var Xa=null,Hs=null;function Ew(e,t,n){return e===n?!0:e===t?(Xa=e,!0):!1}function Tw(e,t,n){return e===n?(Hs=e,!1):e===t?(Hs!==null&&(Xa=e),!0):!1}function zm(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function Bs(e,t,n){for(var o=0,a=e;a;a=n(a))o++;a=0;for(var l=t;l;l=n(l))a++;for(;0<o-a;)e=n(e),o--;for(;0<a-o;)t=n(t),a--;for(;o--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var he=Object.assign,Cw=Symbol.for("react.element"),kc=Symbol.for("react.transitional.element"),ii=Symbol.for("react.portal"),Ka=Symbol.for("react.fragment"),vh=Symbol.for("react.strict_mode"),Ls=Symbol.for("react.profiler"),yh=Symbol.for("react.consumer"),hn=Symbol.for("react.context"),Zd=Symbol.for("react.forward_ref"),qs=Symbol.for("react.suspense"),Ys=Symbol.for("react.suspense_list"),Jd=Symbol.for("react.memo"),co=Symbol.for("react.lazy"),Vs=Symbol.for("react.activity"),Nw=Symbol.for("react.legacy_hidden"),Mw=Symbol.for("react.memo_cache_sentinel"),js=Symbol.for("react.view_transition"),zw=Symbol.for("react.recoverable"),Am=Symbol.iterator;function ei(e){return e===null||typeof e!="object"?null:(e=Am&&e[Am]||e["@@iterator"],typeof e=="function"?e:null)}var Aw=Symbol.for("react.client.reference");function Xs(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===Aw?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Ka:return"Fragment";case Ls:return"Profiler";case vh:return"StrictMode";case qs:return"Suspense";case Ys:return"SuspenseList";case Vs:return"Activity";case js:return"ViewTransition"}if(typeof e=="object")switch(e.$$typeof){case ii:return"Portal";case hn:return e.displayName||"Context";case yh:return(e._context.displayName||"Context")+".Consumer";case Zd:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Jd:return t=e.displayName||null,t!==null?t:Xs(e.type)||"Memo";case co:t=e._payload,e=e._init;try{return Xs(e(t))}catch{}}return null}var ci=Array.isArray,Y=dh.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ie=Sw.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,oa={pending:!1,data:null,method:null,action:null},Ks=[],Ga=-1;function kn(e){return{current:e}}function Fe(e){0>Ga||(e.current=Ks[Ga],Ks[Ga]=null,Ga--)}function xe(e,t){Ga++,Ks[Ga]=e.current,e.current=t}var wn=kn(null),Ei=kn(null),go=kn(null),ur=kn(null);function sr(e,t){switch(xe(go,t),xe(Ei,e),xe(wn,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?Kb(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=Kb(t),e=Vv(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}Fe(wn),xe(wn,e)}function dl(){Fe(wn),Fe(Ei),Fe(go)}function Gs(e){var t=e.memoizedState;t!==null&&(xl._currentValue=t.memoizedState,xe(ur,e)),t=wn.current;var n=Vv(t,e.type);t!==n&&(xe(Ei,e),xe(wn,n))}function dr(e){Ei.current===e&&(Fe(wn),Fe(Ei)),ur.current===e&&(Fe(ur),xl._currentValue=oa)}var ls,Om;function lo(e){if(ls===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);ls=t&&t[1]||"",Om=-1<n.stack.indexOf(`
    at`)?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return`
`+ls+e+Om}var is=!1;function cs(e,t){if(!e||is)return"";is=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(t){var m=function(){throw Error()};if(Object.defineProperty(m.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(m,[])}catch(x){var p=x}Reflect.construct(e,[],m)}else{try{m.call()}catch(x){p=x}m=!1;try{var f=Object.getOwnPropertyDescriptor(e.prototype,"props");Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),m=!0,new e}finally{m&&(f!==void 0?Object.defineProperty(e.prototype,"props",f):delete e.prototype.props)}}}else{try{throw Error()}catch(x){p=x}(m=e())&&typeof m.catch=="function"&&m.catch(function(){})}}catch(x){if(x&&p&&typeof x.stack=="string")return[x.stack,p.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var a=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");a&&a.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var l=o.DetermineComponentFrameRoot(),i=l[0],c=l[1];if(i&&c){var r=i.split(`
`),u=c.split(`
`);for(a=o=0;o<r.length&&!r[o].includes("DetermineComponentFrameRoot");)o++;for(;a<u.length&&!u[a].includes("DetermineComponentFrameRoot");)a++;if(o===r.length||a===u.length)for(o=r.length-1,a=u.length-1;1<=o&&0<=a&&r[o]!==u[a];)a--;for(;1<=o&&0<=a;o--,a--)if(r[o]!==u[a]){if(o!==1||a!==1)do if(o--,a--,0>a||r[o]!==u[a]){var h=`
`+r[o].replace(" at new "," at ");return e.displayName&&h.includes("<anonymous>")&&(h=h.replace("<anonymous>",e.displayName)),h}while(1<=o&&0<=a);break}}}finally{is=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?lo(n):""}function Ow(e,t){switch(e.tag){case 26:case 27:case 5:return lo(e.type);case 16:return lo("Lazy");case 13:return e.child!==t&&t!==null?lo("Suspense Fallback"):lo("Suspense");case 19:return lo("SuspenseList");case 0:case 15:return cs(e.type,!1);case 11:return cs(e.type.render,!1);case 1:return cs(e.type,!0);case 31:return lo("Activity");case 30:return lo("ViewTransition");default:return""}}function Rm(e){try{var t="",n=null;do t+=Ow(e,n),n=e,e=e.return;while(e);return t}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var Qs=Object.prototype.hasOwnProperty,$d=qe.unstable_scheduleCallback,rs=qe.unstable_cancelCallback,Rw=qe.unstable_shouldYield,Dw=qe.unstable_requestPaint,At=qe.unstable_now,_w=qe.unstable_getCurrentPriorityLevel,wh=qe.unstable_ImmediatePriority,xh=qe.unstable_UserBlockingPriority,fr=qe.unstable_NormalPriority,Uw=qe.unstable_LowPriority,Sh=qe.unstable_IdlePriority,Hw=qe.log,Bw=qe.unstable_setDisableYieldValue,Vi=null,Ot=null;function so(e){if(typeof Hw=="function"&&Bw(e),Ot&&typeof Ot.setStrictMode=="function")try{Ot.setStrictMode(Vi,e)}catch{}}var Rt=Math.clz32?Math.clz32:Yw,Lw=Math.log,qw=Math.LN2;function Yw(e){return e>>>=0,e===0?32:31-(Lw(e)/qw|0)|0}var Ec=256,Tc=262144,Cc=4194304;function Io(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Lr(e,t,n){var o=e.pendingLanes;if(o===0)return 0;var a=0,l=e.suspendedLanes,i=e.pingedLanes;e=e.warmLanes;var c=o&134217727;return c!==0?(o=c&~l,o!==0?a=Io(o):(i&=c,i!==0?a=Io(i):n||(n=c&~e,n!==0&&(a=Io(n))))):(c=o&~l,c!==0?a=Io(c):i!==0?a=Io(i):n||(n=o&~e,n!==0&&(a=Io(n)))),a===0?0:t!==0&&t!==a&&(t&l)===0&&(l=a&-a,n=t&-t,l>=n||l===32&&(n&4194048)!==0)?t:a}function ji(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function kh(e,t){(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var o=31-Rt(n),a=1<<o;t|=e[o],n&=~a}return t}function Vw(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Eh(){var e=Cc;return Cc<<=1,(Cc&62914560)===0&&(Cc=4194304),e}function us(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Xi(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function jw(e,t,n,o,a,l){var i=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var c=e.entanglements,r=e.expirationTimes,u=e.hiddenUpdates;for(n=i&~n;0<n;){var h=31-Rt(n),m=1<<h;c[h]=0,r[h]=-1;var p=u[h];if(p!==null)for(u[h]=null,h=0;h<p.length;h++){var f=p[h];f!==null&&(f.lane&=-536870913)}n&=~m}o!==0&&Th(e,o,0),l!==0&&a===0&&e.tag!==0&&(e.suspendedLanes|=l&~(i&~t))}function Th(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var o=31-Rt(t);e.entangledLanes|=t,e.entanglements[o]=e.entanglements[o]|1073741824|n&261930}function Ch(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var o=31-Rt(n),a=1<<o;a&t|e[o]&t&&(e[o]|=t),n&=~a}}function Nh(e,t){var n=t&-t;return n=(n&42)!==0?1:Pd(n),(n&(e.suspendedLanes|t))!==0?0:n}function Pd(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Fd(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Mh(){var e=ie.p;return e!==0?e:(e=window.event,e===void 0?32:u0(e.type))}function Dm(e,t){var n=ie.p;try{return ie.p=e,t()}finally{ie.p=n}}var Kn=Math.random().toString(36).slice(2),$e="__reactFiber$"+Kn,xt="__reactProps$"+Kn,El="__reactContainer$"+Kn,_m="__reactEvents$"+Kn,Xw="__reactListeners$"+Kn,Kw="__reactHandles$"+Kn,Um="__reactResources$"+Kn,Ki="__reactMarker$"+Kn,pr="__reactLoad$"+Kn;function qr(e){delete e[$e],delete e[xt],delete e[Xw],delete e[Kw]}function ta(e){var t;if(t=e[$e])return t;for(var n=e.parentNode;n;){if(t=n[El]||n[$e]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=Ib(e);e!==null;){if(n=e[$e])return n;e=Ib(e)}return t}e=n,n=e.parentNode}return null}function Tl(e){if(e=e[$e]||e[El]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function ri(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(C(33))}function tl(e){var t=e[Um];return t||(t=e[Um]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function Xe(e){e[Ki]=!0}function zh(e){e[pr]=void 0}var Ah=new Set,Oh={};function ga(e,t){fl(e,t),fl(e+"Capture",t)}function fl(e,t){for(Oh[e]=t,e=0;e<t.length;e++)Ah.add(t[e])}var Gw=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Hm={},Bm={};function Qw(e){return Qs.call(Bm,e)?!0:Qs.call(Hm,e)?!1:Gw.test(e)?Bm[e]=!0:(Hm[e]=!0,!1)}var oe=!1;function Lm(){var e=oe;return oe=!1,e}function Kc(e,t,n){if(Qw(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var o=t.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,n)}}function Nc(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,n)}}function Rn(e,t,n,o){if(o===null)e.removeAttribute(n);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,o)}}function Ct(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Rh(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Zw(e,t,n){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var a=o.get,l=o.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return a.call(this)},set:function(i){n=""+i,l.call(this,i)}}),Object.defineProperty(e,t,{enumerable:o.enumerable}),{getValue:function(){return n},setValue:function(i){n=""+i},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Zs(e){if(!e._valueTracker){var t=Rh(e)?"checked":"value";e._valueTracker=Zw(e,t,""+e[t])}}function Dh(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),o="";return e&&(o=Rh(e)?e.checked?"true":"false":e.value),e=o,e!==n?(t.setValue(e),!0):!1}var Jw=/[\n"\\]/g;function Xt(e){return e.replace(Jw,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function Js(e,t,n,o,a,l,i,c){e.name="",i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"?e.type=i:e.removeAttribute("type"),t!=null?i==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+Ct(t)):e.value!==""+Ct(t)&&(e.value=""+Ct(t)):i!=="submit"&&i!=="reset"||e.removeAttribute("value"),t!=null?i==="number"&&e.value==t?ss(e,Ct(e.value)):ss(e,Ct(t)):n!=null?ss(e,Ct(n)):o!=null&&e.removeAttribute("value"),a==null&&l!=null&&(e.defaultChecked=!!l),a!=null&&(e.checked=a&&typeof a!="function"&&typeof a!="symbol"),c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"?e.name=""+Ct(c):e.removeAttribute("name")}function _h(e,t,n,o,a,l,i,c){if(l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"&&(e.type=l),t!=null||n!=null){if(!(l!=="submit"&&l!=="reset"||t!=null)){Zs(e);return}n=n!=null?""+Ct(n):"",t=t!=null?""+Ct(t):n,c||t===e.value||(e.value=t),e.defaultValue=t}o=o??a,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=c?e.checked:!!o,e.defaultChecked=!!o,i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"&&(e.name=i),Zs(e)}function ss(e,t){e.defaultValue!==""+t&&(e.defaultValue=""+t)}function nl(e,t,n,o){if(e=e.options,t){t={};for(var a=0;a<n.length;a++)t["$"+n[a]]=!0;for(n=0;n<e.length;n++)a=t.hasOwnProperty("$"+e[n].value),e[n].selected!==a&&(e[n].selected=a),a&&o&&(e[n].defaultSelected=!0)}else{for(n=""+Ct(n),t=null,a=0;a<e.length;a++){if(e[a].value===n){e[a].selected=!0,o&&(e[a].defaultSelected=!0);return}t!==null||e[a].disabled||(t=e[a])}t!==null&&(t.selected=!0)}}function Uh(e,t,n){if(t!=null&&(t=""+Ct(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n!=null?""+Ct(n):""}function Hh(e,t,n,o){if(t==null){if(o!=null){if(n!=null)throw Error(C(92));if(ci(o)){if(1<o.length)throw Error(C(93));o=o[0]}n=o}n==null&&(n=""),t=n}n=Ct(t),e.defaultValue=n,o=e.textContent,o===n&&o!==""&&o!==null&&(e.value=o),Zs(e)}function pl(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var $w=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function qm(e,t,n){var o=t.indexOf("--")===0;n==null||typeof n=="boolean"||n===""?o?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":o?e.setProperty(t,n):typeof n!="number"||n===0||$w.has(t)?t==="float"?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function Bh(e,t,n){if(t!=null&&typeof t!="object")throw Error(C(62));if(e=e.style,n!=null){for(var o in n)!n.hasOwnProperty(o)||t!=null&&t.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="",oe=!0);for(var a in t)o=t[a],t.hasOwnProperty(a)&&n[a]!==o&&(qm(e,a,o),oe=!0)}else for(var l in t)t.hasOwnProperty(l)&&qm(e,l,t[l])}function Id(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Pw=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Fw=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Gc(e){return Fw.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function gn(){}var $s=null;function Wd(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Qa=null,ol=null;function Ym(e){var t=Tl(e);if(t&&(e=t.stateNode)){var n=e[xt]||null;e:switch(e=t.stateNode,t.type){case"input":if(Js(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+Xt(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var o=n[t];if(o!==e&&o.form===e.form){var a=o[xt]||null;if(!a)throw Error(C(90));Js(o,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)o=n[t],o.form===e.form&&Dh(o)}break e;case"textarea":Uh(e,n.value,n.defaultValue);break e;case"select":t=n.value,t!=null&&nl(e,!!n.multiple,t,!1)}}}var ds=!1;function Lh(e,t,n){if(ds)return e(t,n);ds=!0;try{var o=e(t);return o}finally{if(ds=!1,(Qa!==null||ol!==null)&&(Wr(),Qa&&(t=Qa,e=ol,ol=Qa=null,Ym(t),e)))for(t=0;t<e.length;t++)Ym(e[t])}}function Ti(e,t){var n=e.stateNode;if(n===null)return null;var o=n[xt]||null;if(o===null)return null;n=o[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(C(231,t,typeof n));return n}var Ln=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Ps=!1;if(Ln)try{Ba={},Object.defineProperty(Ba,"passive",{get:function(){Ps=!0}}),window.addEventListener("test",Ba,Ba),window.removeEventListener("test",Ba,Ba)}catch{Ps=!1}var Ba,fo=null,ef=null,Qc=null;function qh(){if(Qc)return Qc;var e,t=ef,n=t.length,o,a="value"in fo?fo.value:fo.textContent,l=a.length;for(e=0;e<n&&t[e]===a[e];e++);var i=n-e;for(o=1;o<=i&&t[n-o]===a[l-o];o++);return Qc=a.slice(e,1<o?1-o:void 0)}function Zc(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Mc(){return!0}function Vm(){return!1}function ft(e){function t(n,o,a,l,i){this._reactName=n,this._targetInst=a,this.type=o,this.nativeEvent=l,this.target=i,this.currentTarget=null;for(var c in e)e.hasOwnProperty(c)&&(n=e[c],this[c]=n?n(l):l[c]);return this.isDefaultPrevented=(l.defaultPrevented!=null?l.defaultPrevented:l.returnValue===!1)?Mc:Vm,this.isPropagationStopped=Vm,this}return he(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=Mc)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=Mc)},persist:function(){},isPersistent:Mc}),t}var Ro={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Yr=ft(Ro),Gi=he({},Ro,{view:0,detail:0}),Iw=ft(Gi),fs,ps,ti,Vr=he({},Gi,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:tf,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==ti&&(ti&&e.type==="mousemove"?(fs=e.screenX-ti.screenX,ps=e.screenY-ti.screenY):ps=fs=0,ti=e),fs)},movementY:function(e){return"movementY"in e?e.movementY:ps}}),jm=ft(Vr),Ww=he({},Vr,{dataTransfer:0}),ex=ft(Ww),tx=he({},Gi,{relatedTarget:0}),ms=ft(tx),nx=he({},Ro,{animationName:0,elapsedTime:0,pseudoElement:0}),ox=ft(nx),ax=he({},Ro,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),lx=ft(ax),ix=he({},Ro,{data:0}),Xm=ft(ix),cx={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},rx={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},ux={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function sx(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=ux[e])?!!t[e]:!1}function tf(){return sx}var dx=he({},Gi,{key:function(e){if(e.key){var t=cx[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=Zc(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?rx[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:tf,charCode:function(e){return e.type==="keypress"?Zc(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Zc(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),fx=ft(dx),px=he({},Vr,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Km=ft(px),mx=he({},Ro,{submitter:0}),bx=ft(mx),hx=he({},Gi,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:tf}),gx=ft(hx),vx=he({},Ro,{propertyName:0,elapsedTime:0,pseudoElement:0}),yx=ft(vx),wx=he({},Vr,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),xx=ft(wx),Sx=he({},Ro,{newState:0,oldState:0,source:0}),kx=ft(Sx),Ex=[9,13,27,32],nf=Ln&&"CompositionEvent"in window,di=null;Ln&&"documentMode"in document&&(di=document.documentMode);var Tx=Ln&&"TextEvent"in window&&!di,Yh=Ln&&(!nf||di&&8<di&&11>=di),Gm=" ",Qm=!1;function Vh(e,t){switch(e){case"keyup":return Ex.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function jh(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Za=!1;function Cx(e,t){switch(e){case"compositionend":return jh(t);case"keypress":return t.which!==32?null:(Qm=!0,Gm);case"textInput":return e=t.data,e===Gm&&Qm?null:e;default:return null}}function Nx(e,t){if(Za)return e==="compositionend"||!nf&&Vh(e,t)?(e=qh(),Qc=ef=fo=null,Za=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Yh&&t.locale!=="ko"?null:t.data;default:return null}}var Mx={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Zm(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Mx[e.type]:t==="textarea"}function Xh(e,t,n,o){Qa?ol?ol.push(o):ol=[o]:Qa=o,t=Ur(t,"onChange"),0<t.length&&(n=new Yr("onChange","change",null,n,o),e.push({event:n,listeners:t}))}var fi=null,Ci=null;function zx(e){Lv(e,0)}function jr(e){var t=ri(e);if(Dh(t))return e}function Jm(e,t){if(e==="change")return t}var Kh=!1;Ln&&(Ln?(Ac="oninput"in document,Ac||(bs=document.createElement("div"),bs.setAttribute("oninput","return;"),Ac=typeof bs.oninput=="function"),zc=Ac):zc=!1,Kh=zc&&(!document.documentMode||9<document.documentMode));var zc,Ac,bs;function $m(){fi&&(fi.detachEvent("onpropertychange",Gh),Ci=fi=null)}function Gh(e){if(e.propertyName==="value"&&jr(Ci)){var t=[];Xh(t,Ci,e,Wd(e)),Lh(zx,t)}}function Ax(e,t,n){e==="focusin"?($m(),fi=t,Ci=n,fi.attachEvent("onpropertychange",Gh)):e==="focusout"&&$m()}function Ox(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return jr(Ci)}function Rx(e,t){if(e==="click")return jr(t)}function Dx(e,t){if(e==="input"||e==="change")return jr(t)}function _x(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var _t=typeof Object.is=="function"?Object.is:_x;function Ni(e,t){if(_t(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),o=Object.keys(t);if(n.length!==o.length)return!1;for(o=0;o<n.length;o++){var a=n[o];if(!Qs.call(t,a)||!_t(e[a],t[a]))return!1}return!0}function Fs(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function Pm(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Fm(e,t){var n=Pm(e);e=0;for(var o;n;){if(n.nodeType===3){if(o=e+n.textContent.length,e<=t&&o>=t)return{node:n,offset:t-e};e=o}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=Pm(n)}}function Qh(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Qh(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Zh(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=Fs(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=Fs(e.document)}return t}function of(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var Ux=Ln&&"documentMode"in document&&11>=document.documentMode,Ja=null,Is=null,pi=null,Ws=!1;function Im(e,t,n){var o=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Ws||Ja==null||Ja!==Fs(o)||(o=Ja,"selectionStart"in o&&of(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),pi&&Ni(pi,o)||(pi=o,o=Ur(Is,"onSelect"),0<o.length&&(t=new Yr("onSelect","select",null,t,n),e.push({event:t,listeners:o}),t.target=Ja)))}function Po(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var $a={animationend:Po("Animation","AnimationEnd"),animationiteration:Po("Animation","AnimationIteration"),animationstart:Po("Animation","AnimationStart"),transitionrun:Po("Transition","TransitionRun"),transitionstart:Po("Transition","TransitionStart"),transitioncancel:Po("Transition","TransitionCancel"),transitionend:Po("Transition","TransitionEnd")},hs={},Jh={};Ln&&(Jh=document.createElement("div").style,"AnimationEvent"in window||(delete $a.animationend.animation,delete $a.animationiteration.animation,delete $a.animationstart.animation),"TransitionEvent"in window||delete $a.transitionend.transition);function va(e){if(hs[e])return hs[e];if(!$a[e])return e;var t=$a[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Jh)return hs[e]=t[n];return e}var $h=va("animationend"),Ph=va("animationiteration"),Fh=va("animationstart"),Hx=va("transitionrun"),Bx=va("transitionstart"),Lx=va("transitioncancel"),Ih=va("transitionend"),Wh=new Map,ed="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");ed.push("scrollEnd");function nn(e,t){Wh.set(e,t),ga(t,[e])}var qx=0;function qn(e,t){if(e.name!=null&&e.name!=="auto")return e.name;if(t.autoName!==null)return t.autoName;e=tn.identifierPrefix;var n=qx++;return e="_"+e+"t_"+n.toString(32)+"_",t.autoName=e}function Wm(e){if(e==null||typeof e=="string")return e;var t=null,n=sl;if(n!==null)for(var o=0;o<n.length;o++){var a=e[n[o]];if(a!=null){if(a==="none")return"none";t=t==null?a:t+(" "+a)}}return t??e.default}function Gn(e,t){return e=Wm(e),t=Wm(t),t==null?e==="auto"?null:e:t==="auto"?null:t}var mr=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Yt=[],Pa=0,af=0;function Xr(){for(var e=Pa,t=af=Pa=0;t<e;){var n=Yt[t];Yt[t++]=null;var o=Yt[t];Yt[t++]=null;var a=Yt[t];Yt[t++]=null;var l=Yt[t];if(Yt[t++]=null,o!==null&&a!==null){var i=o.pending;i===null?a.next=a:(a.next=i.next,i.next=a),o.pending=a}l!==0&&eg(n,a,l)}}function Kr(e,t,n,o){Yt[Pa++]=e,Yt[Pa++]=t,Yt[Pa++]=n,Yt[Pa++]=o,af|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function lf(e,t,n,o){return Kr(e,t,n,o),br(e)}function ya(e,t){return Kr(e,null,null,t),br(e)}function eg(e,t,n){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n);for(var a=!1,l=e.return;l!==null;)l.childLanes|=n,o=l.alternate,o!==null&&(o.childLanes|=n),l.tag===22&&(e=l.stateNode,e===null||e._visibility&1||(a=!0)),e=l,l=l.return;return e.tag===3?(l=e.stateNode,a&&t!==null&&(a=31-Rt(n),e=l.hiddenUpdates,o=e[a],o===null?e[a]=[t]:o.push(t),t.lane=n|536870912),l):null}function br(e){if(50<ki)throw ki=0,or=null,Error(C(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Fa={};function Yx(e,t,n,o){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function vt(e,t,n,o){return new Yx(e,t,n,o)}function cf(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Hn(e,t){var n=e.alternate;return n===null?(n=vt(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function tg(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Jc(e,t,n,o,a,l){var i=0;if(o=e,typeof o=="function")cf(o)&&(i=1);else if(typeof o=="string")i=fk(e,n,wn.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(o){case Vs:return e=vt(31,n,t,a),e.elementType=Vs,e.lanes=l,e;case Ka:return aa(n.children,a,l,t);case vh:i=8,a|=24;break;case Ls:return e=vt(12,n,t,a|2),e.elementType=Ls,e.lanes=l,e;case qs:return e=vt(13,n,t,a),e.elementType=qs,e.lanes=l,e;case Ys:return e=vt(19,n,t,a),e.elementType=Ys,e.lanes=l,e;case Nw:case js:return e=a|32,e=vt(30,n,t,e),e.elementType=js,e.lanes=l,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof o=="object"&&o!==null)switch(o.$$typeof){case hn:i=10;break e;case yh:i=9;break e;case Zd:i=11;break e;case Jd:i=14;break e;case co:i=16,o=null;break e}i=29,n=Error(C(130,e===null?"null":typeof e,"")),o=null}return t=vt(i,n,t,a),t.elementType=e,t.type=o,t.lanes=l,t}function aa(e,t,n,o){return e=vt(7,e,o,t),e.lanes=n,e}function gs(e,t,n){return e=vt(6,e,null,t),e.lanes=n,e}function ng(e){var t=vt(18,null,null,0);return t.stateNode=e,t}function vs(e,t,n){return t=vt(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var eb=new WeakMap;function Kt(e,t){if(typeof e=="object"&&e!==null){var n=eb.get(e);return n!==void 0?n:(t={value:e,source:t,stack:Rm(t)},eb.set(e,t),t)}return{value:e,source:t,stack:Rm(t)}}var Ia=[],Wa=0,hr=null,Mi=0,Vt=[],jt=0,No=null,vn=1,yn="";function _n(e,t){Ia[Wa++]=Mi,Ia[Wa++]=hr,hr=e,Mi=t}function og(e,t,n){Vt[jt++]=vn,Vt[jt++]=yn,Vt[jt++]=No,No=e;var o=vn;e=yn;var a=32-Rt(o)-1;o&=~(1<<a),n+=1;var l=32-Rt(t)+a;if(30<l){var i=a-a%5;l=(o&(1<<i)-1).toString(32),o>>=i,a-=i,vn=1<<32-Rt(t)+a|n<<a|o,yn=l+e}else vn=1<<l|n<<a|o,yn=e}function Gr(e){e.return!==null&&(_n(e,1),og(e,1,0))}function rf(e){for(;e===hr;)hr=Ia[--Wa],Ia[Wa]=null,Mi=Ia[--Wa],Ia[Wa]=null;for(;e===No;)No=Vt[--jt],Vt[jt]=null,yn=Vt[--jt],Vt[jt]=null,vn=Vt[--jt],Vt[jt]=null}function ag(e,t){Vt[jt++]=vn,Vt[jt++]=yn,Vt[jt++]=No,vn=t.id,yn=t.overflow,No=e}var Ke=null,we=null,J=!1,vo=null,Gt=!1,td=Error(C(519));function Mo(e){var t=Error(C(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw zi(Kt(t,e)),td}function tb(e){var t=e.stateNode,n=e.type,o=e.memoizedProps;switch(t[$e]=e,t[xt]=o,n){case"dialog":P("cancel",t),P("close",t);break;case"iframe":case"object":case"embed":P("load",t);break;case"video":case"audio":for(n=0;n<Di.length;n++)P(Di[n],t);break;case"source":P("error",t);break;case"img":case"image":case"link":P("error",t),P("load",t);break;case"details":P("toggle",t);break;case"input":P("invalid",t),_h(t,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":P("invalid",t);break;case"textarea":P("invalid",t),Hh(t,o.value,o.defaultValue,o.children)}n=o.children,typeof n!="string"&&typeof n!="number"&&typeof n!="bigint"||t.textContent===""+n||o.suppressHydrationWarning===!0||Yv(t.textContent,n)?(o.popover!=null&&(P("beforetoggle",t),P("toggle",t)),o.onScroll!=null&&P("scroll",t),o.onScrollEnd!=null&&P("scrollend",t),o.onClick!=null&&(t.onclick=gn),t=!0):t=!1,t||Mo(e,!0)}function gr(e){for(Ke=e.return;Ke;)switch(Ke.tag){case 5:case 31:case 13:Gt=!1;return;case 27:case 3:Gt=!0;return;default:Ke=Ke.return}}function La(e){if(e!==Ke)return!1;if(!J)return gr(e),J=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!=="form"&&n!=="button")||qd(e.type,e.memoizedProps)),n=!n),n&&we&&Mo(e),gr(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(C(317));we=Fb(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(C(317));we=Fb(e)}else t===27?(t=we,Do(e.type)?(e=Xd,Xd=null,we=e):we=t):we=Ke?Qt(e.stateNode.nextSibling):null;return!0}function ra(){we=Ke=null,J=!1}function ys(){var e=vo;return e!==null&&(ht===null?ht=e:ht.push.apply(ht,e),vo=null),e}function zi(e){vo===null?vo=[e]:vo.push(e)}var nd=kn(null),wa=null,Un=null;function po(e,t,n){xe(nd,t._currentValue),t._currentValue=n}function Bn(e){e._currentValue=nd.current,Fe(nd)}function $c(e,t,n){for(;e!==null;){var o=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,o!==null&&(o.childLanes|=t)):o!==null&&(o.childLanes&t)!==t&&(o.childLanes|=t),e===n)break;e=e.return}}function od(e,t,n,o){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var l=a.dependencies;if(l!==null){var i=a.child;l=l.firstContext;e:for(;l!==null;){var c=l;l=a;for(var r=0;r<t.length;r++)if(c.context===t[r]){l.lanes|=n,c=l.alternate,c!==null&&(c.lanes|=n),$c(l.return,n,e),o||(i=null);break e}l=c.next}}else if(a.tag===18){if(i=a.return,i===null)throw Error(C(341));i.lanes|=n,l=i.alternate,l!==null&&(l.lanes|=n),$c(i,n,e),i=null}else a.tag===13&&a.memoizedState!==null&&a.memoizedState.dehydrated===null?(a.lanes|=n,i=a.alternate,i!==null&&(i.lanes|=n),$c(a.return,n,e),i=a.child,i=i!==null?i.sibling:null):i=a.child;if(i!==null)i.return=a;else for(i=a;i!==null;){if(i===e){i=null;break}if(a=i.sibling,a!==null){a.return=i.return,i=a;break}i=i.return}a=i}}function ua(e,t,n,o){e=null;for(var a=t,l=!1;a!==null;){if(!l){if((a.flags&524288)!==0)l=!0;else if((a.flags&262144)!==0)break}if(a.tag===10){var i=a.alternate;if(i===null)throw Error(C(387));if(i=i.memoizedProps,i!==null){var c=a.type;_t(a.pendingProps.value,i.value)||(e!==null?e.push(c):e=[c])}}else if(a===ur.current){if(i=a.alternate,i===null)throw Error(C(387));i.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e!==null?e.push(xl):e=[xl])}a=a.return}return e!==null&&od(t,e,n,o),t.flags|=262144,e!==null}function vr(e){for(e=e.firstContext;e!==null;){if(!_t(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function sa(e){wa=e,Un=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function Pe(e){return lg(wa,e)}function Oc(e,t){return wa===null&&sa(e),lg(e,t)}function lg(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},Un===null){if(e===null)throw Error(C(308));Un=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else Un=Un.next=t;return n}var Vx=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(n,o){e.push(o)}};this.abort=function(){t.aborted=!0,e.forEach(function(n){return n()})}},jx=qe.unstable_scheduleCallback,Xx=qe.unstable_NormalPriority,_e={$$typeof:hn,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function uf(){return{controller:new Vx,data:new Map,refCount:0}}function Qi(e){e.refCount--,e.refCount===0&&jx(Xx,function(){e.controller.abort()})}function nb(e,t){if((e.pendingLanes&4194048)!==0){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var o=t[e];n.indexOf(o)===-1&&n.push(o)}}}var ui=null;function Kx(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var mi=null,ad=0,da=0,al=null;function Gx(e,t){if(mi===null){var n=mi=[];ad=0,da=Bf(),al={status:"pending",value:void 0,then:function(o){n.push(o)}}}return ad++,t.then(ob,ob),t}function ob(){if(--ad===0&&(ui=null,mi!==null)){al!==null&&(al.status="fulfilled");var e=mi;mi=null,da=0,al=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Qx(e,t){var n=[],o={status:"pending",value:null,reason:null,then:function(a){n.push(a)}};return e.then(function(){o.status="fulfilled",o.value=t;for(var a=0;a<n.length;a++)(0,n[a])(t)},function(a){for(o.status="rejected",o.reason=a,a=0;a<n.length;a++)(0,n[a])(void 0)}),o}var ab=Y.S;Y.S=function(e,t){if(kv=At(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&Gx(e,t),ui!==null)for(var n=vl;n!==null;)nb(n,ui),n=n.next;if(n=e.types,n!==null){for(var o=vl;o!==null;)nb(o,n),o=o.next;if(da!==0){o=ui,o===null&&(o=ui=[]);for(var a=0;a<n.length;a++){var l=n[a];o.indexOf(l)===-1&&o.push(l)}}}ab!==null&&ab(e,t)};var la=kn(null);function sf(){var e=la.current;return e!==null?e:be.pooledCache}function Pc(e,t){t===null?xe(la,la.current):xe(la,t.pool)}function ig(){var e=sf();return e===null?null:{parent:_e._currentValue,pool:e}}var Cl=Error(C(460)),df=Error(C(474)),Qr=Error(C(542)),yr={then:function(){}};function lb(e){return e=e.status,e==="fulfilled"||e==="rejected"}function cg(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(gn,gn),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,cb(e),e===void 0&&!("reason"in t)?Error(C(600)):e;default:if(typeof t.status=="string")t.then(gn,gn);else{if(e=be,e!==null&&100<e.shellSuspendCounter)throw Error(C(482));e=t,e.status="pending",e.then(function(o){if(t.status==="pending"){var a=t;a.status="fulfilled",a.value=o}},function(o){if(t.status==="pending"){var a=t;a.status="rejected",a.reason=o}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,cb(e),e}throw ia=t,Cl}}function Wo(e){try{var t=e._init;return t(e._payload)}catch(n){throw n!==null&&typeof n=="object"&&typeof n.then=="function"?(ia=n,Cl):n}}var ia=null;function ib(){if(ia===null)throw Error(C(459));var e=ia;return ia=null,e}function cb(e){if(e===Cl||e===Qr)throw Error(C(483))}var ll=null,Ai=0;function Rc(e){var t=Ai;return Ai+=1,ll===null&&(ll=[]),cg(ll,e,t)}function ao(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function Dc(e,t){throw t.$$typeof===Cw?Error(C(525)):(e=Object.prototype.toString.call(t),Error(C(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function rg(e){function t(b,s){if(e){var d=b.deletions;d===null?(b.deletions=[s],b.flags|=16):d.push(s)}}function n(b,s){if(!e)return null;for(;s!==null;)t(b,s),s=s.sibling;return null}function o(b){for(var s=new Map;b!==null;)b.key===null?s.set(b.index,b):s.set(b.key,b),b=b.sibling;return s}function a(b,s){return b=Hn(b,s),b.index=0,b.sibling=null,b}function l(b,s,d){return b.index=d,e?(d=b.alternate,d!==null?(d=d.index,d<s?(b.flags|=2,s):d):(b.flags|=134217730,s)):(b.flags|=1048576,s)}function i(b){return e&&b.alternate===null&&(b.flags|=134217730),b}function c(b,s,d,v){return s===null||s.tag!==6?(s=gs(d,b.mode,v),s.return=b,s):(s=a(s,d),s.return=b,s)}function r(b,s,d,v){var y=d.type;return y===Ka?(b=h(b,s,d.props.children,v,d.key),ao(b,d),b):s!==null&&(s.elementType===y||typeof y=="object"&&y!==null&&y.$$typeof===co&&Wo(y)===s.type)?(s=a(s,d.props),ao(s,d),s.return=b,s):(s=Jc(d.type,d.key,d.props,null,b.mode,v),ao(s,d),s.return=b,s)}function u(b,s,d,v){return s===null||s.tag!==4||s.stateNode.containerInfo!==d.containerInfo||s.stateNode.implementation!==d.implementation?(s=vs(d,b.mode,v),s.return=b,s):(s=a(s,d.children||[]),s.return=b,s)}function h(b,s,d,v,y){return s===null||s.tag!==7?(s=aa(d,b.mode,v,y),s.return=b,s):(s=a(s,d),s.return=b,s)}function m(b,s,d){if(typeof s=="string"&&s!==""||typeof s=="number"||typeof s=="bigint")return s=gs(""+s,b.mode,d),s.return=b,s;if(typeof s=="object"&&s!==null){switch(s.$$typeof){case kc:return d=Jc(s.type,s.key,s.props,null,b.mode,d),ao(d,s),d.return=b,d;case ii:return s=vs(s,b.mode,d),s.return=b,s;case co:return s=Wo(s),m(b,s,d)}if(ci(s)||ei(s))return s=aa(s,b.mode,d,null),s.return=b,s;if(typeof s.then=="function")return m(b,Rc(s),d);if(s.$$typeof===hn)return m(b,Oc(b,s),d);Dc(b,s)}return null}function p(b,s,d,v){var y=s!==null?s.key:null;if(typeof d=="string"&&d!==""||typeof d=="number"||typeof d=="bigint")return y!==null?null:c(b,s,""+d,v);if(typeof d=="object"&&d!==null){switch(d.$$typeof){case kc:return d.key===y?r(b,s,d,v):null;case ii:return d.key===y?u(b,s,d,v):null;case co:return d=Wo(d),p(b,s,d,v)}if(ci(d)||ei(d))return y!==null?null:h(b,s,d,v,null);if(typeof d.then=="function")return p(b,s,Rc(d),v);if(d.$$typeof===hn)return p(b,s,Oc(b,d),v);Dc(b,d)}return null}function f(b,s,d,v,y){if(typeof v=="string"&&v!==""||typeof v=="number"||typeof v=="bigint")return b=b.get(d)||null,c(s,b,""+v,y);if(typeof v=="object"&&v!==null){switch(v.$$typeof){case kc:return b=b.get(v.key===null?d:v.key)||null,r(s,b,v,y);case ii:return b=b.get(v.key===null?d:v.key)||null,u(s,b,v,y);case co:return v=Wo(v),f(b,s,d,v,y)}if(ci(v)||ei(v))return b=b.get(d)||null,h(s,b,v,y,null);if(typeof v.then=="function")return f(b,s,d,Rc(v),y);if(v.$$typeof===hn)return f(b,s,d,Oc(s,v),y);Dc(s,v)}return null}function x(b,s,d,v){for(var y=null,T=null,w=s,M=s=0,H=null;w!==null&&M<d.length;M++){w.index>M?(H=w,w=null):H=w.sibling;var R=p(b,w,d[M],v);if(R===null){w===null&&(w=H);break}e&&w&&R.alternate===null&&t(b,w),s=l(R,s,M),T===null?y=R:T.sibling=R,T=R,w=H}if(M===d.length)return n(b,w),J&&_n(b,M),y;if(w===null){for(;M<d.length;M++)w=m(b,d[M],v),w!==null&&(s=l(w,s,M),T===null?y=w:T.sibling=w,T=w);return J&&_n(b,M),y}for(w=o(w);M<d.length;M++)H=f(w,b,M,d[M],v),H!==null&&(e&&(R=H.alternate,R!==null&&w.delete(R.key===null?M:R.key)),s=l(H,s,M),T===null?y=H:T.sibling=H,T=H);return e&&w.forEach(function(K){return t(b,K)}),J&&_n(b,M),y}function k(b,s,d,v){if(d==null)throw Error(C(151));for(var y=null,T=null,w=s,M=s=0,H=null,R=d.next();w!==null&&!R.done;M++,R=d.next()){w.index>M?(H=w,w=null):H=w.sibling;var K=p(b,w,R.value,v);if(K===null){w===null&&(w=H);break}e&&w&&K.alternate===null&&t(b,w),s=l(K,s,M),T===null?y=K:T.sibling=K,T=K,w=H}if(R.done)return n(b,w),J&&_n(b,M),y;if(w===null){for(;!R.done;M++,R=d.next())R=m(b,R.value,v),R!==null&&(s=l(R,s,M),T===null?y=R:T.sibling=R,T=R);return J&&_n(b,M),y}for(w=o(w);!R.done;M++,R=d.next())R=f(w,b,M,R.value,v),R!==null&&(e&&(H=R.alternate,H!==null&&w.delete(H.key===null?M:H.key)),s=l(R,s,M),T===null?y=R:T.sibling=R,T=R);return e&&w.forEach(function(L){return t(b,L)}),J&&_n(b,M),y}function E(b,s,d,v){if(typeof d=="object"&&d!==null&&d.type===Ka&&d.key===null&&d.props.ref===void 0&&(d=d.props.children),typeof d=="object"&&d!==null){switch(d.$$typeof){case kc:e:{for(var y=d.key;s!==null;){if(s.key===y){if(y=d.type,y===Ka){if(s.tag===7){n(b,s.sibling),v=a(s,d.props.children),ao(v,d),v.return=b,b=v;break e}}else if(s.elementType===y||typeof y=="object"&&y!==null&&y.$$typeof===co&&Wo(y)===s.type){n(b,s.sibling),v=a(s,d.props),ao(v,d),v.return=b,b=v;break e}n(b,s);break}else t(b,s);s=s.sibling}d.type===Ka?(v=aa(d.props.children,b.mode,v,d.key),ao(v,d),v.return=b,b=v):(v=Jc(d.type,d.key,d.props,null,b.mode,v),ao(v,d),v.return=b,b=v)}return i(b);case ii:e:{for(y=d.key;s!==null;){if(s.key===y)if(s.tag===4&&s.stateNode.containerInfo===d.containerInfo&&s.stateNode.implementation===d.implementation){n(b,s.sibling),v=a(s,d.children||[]),v.return=b,b=v;break e}else{n(b,s);break}else t(b,s);s=s.sibling}v=vs(d,b.mode,v),v.return=b,b=v}return i(b);case co:return d=Wo(d),E(b,s,d,v)}if(ci(d))return x(b,s,d,v);if(ei(d)){if(y=ei(d),typeof y!="function")throw Error(C(150));return d=y.call(d),k(b,s,d,v)}if(typeof d.then=="function")return E(b,s,Rc(d),v);if(d.$$typeof===hn)return E(b,s,Oc(b,d),v);Dc(b,d)}return typeof d=="string"&&d!==""||typeof d=="number"||typeof d=="bigint"?(d=""+d,s!==null&&s.tag===6?(n(b,s.sibling),v=a(s,d),v.return=b,b=v):(n(b,s),v=gs(d,b.mode,v),v.return=b,b=v),i(b)):n(b,s)}return function(b,s,d,v){try{Ai=0;var y=E(b,s,d,v);return ll=null,y}catch(w){if(w===Cl||w===Qr)throw w;var T=vt(29,w,null,b.mode);return T.lanes=v,T.return=b,T}}}var fa=rg(!0),ug=rg(!1),ro=!1;function ff(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function ld(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function yo(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function wo(e,t,n){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(le&2)!==0){var a=o.pending;return a===null?t.next=t:(t.next=a.next,a.next=t),o.pending=t,t=br(e),eg(e,null,n),t}return Kr(e,o,t,n),br(e)}function bi(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194048)!==0)){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Ch(e,n)}}function ws(e,t){var n=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,n===o)){var a=null,l=null;if(n=n.firstBaseUpdate,n!==null){do{var i={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};l===null?a=l=i:l=l.next=i,n=n.next}while(n!==null);l===null?a=l=t:l=l.next=t}else a=l=t;n={baseState:o.baseState,firstBaseUpdate:a,lastBaseUpdate:l,shared:o.shared,callbacks:o.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var id=!1;function hi(){if(id){var e=al;if(e!==null)throw e}}function gi(e,t,n,o){id=!1;var a=e.updateQueue;ro=!1;var l=a.firstBaseUpdate,i=a.lastBaseUpdate,c=a.shared.pending;if(c!==null){a.shared.pending=null;var r=c,u=r.next;r.next=null,i===null?l=u:i.next=u,i=r;var h=e.alternate;h!==null&&(h=h.updateQueue,c=h.lastBaseUpdate,c!==i&&(c===null?h.firstBaseUpdate=u:c.next=u,h.lastBaseUpdate=r))}if(l!==null){var m=a.baseState;i=0,h=u=r=null,c=l;do{var p=c.lane&-536870913,f=p!==c.lane;if(f?(I&p)===p:(o&p)===p){p!==0&&p===da&&(id=!0),h!==null&&(h=h.next={lane:0,tag:c.tag,payload:c.payload,callback:null,next:null});e:{var x=e,k=c;p=t;var E=n;switch(k.tag){case 1:if(x=k.payload,typeof x=="function"){m=x.call(E,m,p);break e}m=x;break e;case 3:x.flags=x.flags&-65537|128;case 0:if(x=k.payload,p=typeof x=="function"?x.call(E,m,p):x,p==null)break e;m=he({},m,p);break e;case 2:ro=!0}}p=c.callback,p!==null&&(e.flags|=64,f&&(e.flags|=8192),f=a.callbacks,f===null?a.callbacks=[p]:f.push(p))}else f={lane:p,tag:c.tag,payload:c.payload,callback:c.callback,next:null},h===null?(u=h=f,r=m):h=h.next=f,i|=p;if(c=c.next,c===null){if(c=a.shared.pending,c===null)break;f=c,c=f.next,f.next=null,a.lastBaseUpdate=f,a.shared.pending=null}}while(!0);h===null&&(r=m),a.baseState=r,a.firstBaseUpdate=u,a.lastBaseUpdate=h,l===null&&(a.shared.lanes=0),Oo|=i,e.lanes=i,e.memoizedState=m}}function sg(e,t){if(typeof e!="function")throw Error(C(191,e));e.call(t)}function dg(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)sg(n[e],t)}var zo=kn(null),wr=kn(0);function rb(e,t){e=Xn,xe(wr,e),xe(zo,t),Xn=e|t.baseLanes}function cd(){xe(wr,Xn),xe(zo,zo.current)}function pf(){Xn=wr.current,Fe(zo),Fe(wr)}var et=kn(null),it=null;function xo(e){var t=e.alternate;xe(Ie,Ie.current&1),xe(et,e),it===null&&(t===null||zo.current!==null||t.memoizedState!==null)&&(it=e)}function rd(e){xe(Ie,Ie.current),xe(et,e),it===null&&(it=e)}function fg(e){e.tag===22?(xe(Ie,Ie.current),xe(et,e),it===null&&(it=e)):So()}function So(){xe(Ie,Ie.current),xe(et,et.current)}function Nt(e){Fe(et),it===e&&(it=null),Fe(Ie)}var Ie=kn(0);function Oi(e,t){xe(et,et.current),xe(Ie,t)}function mf(e){Fe(Ie),Fe(et),it===e&&(it=null)}function xr(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||jd(n)||Vf(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!=="independent"){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Yn=0,Q=null,me=null,De=null,Sr=!1,il=!1,pa=!1,kr=0,Ri=0,cl=null,Zx=0;function ze(){throw Error(C(321))}function bf(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!_t(e[n],t[n]))return!1;return!0}function hf(e,t,n,o,a,l){return Yn=l,Q=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,Y.H=e===null||e.memoizedState===null?Xg:Kg,pa=!1,l=n(o,a),pa=!1,il&&(l=mg(t,n,o,a)),pg(e),l}function pg(e){Y.H=Er;var t=me!==null&&me.next!==null;if(Yn=0,De=me=Q=null,Sr=!1,Ri=0,cl=null,t)throw Error(C(300));e===null||Ue||(e=e.dependencies,e!==null&&vr(e)&&(Ue=!0))}function mg(e,t,n,o){Q=e;var a=0;do{if(il&&(cl=null),Ri=0,il=!1,25<=a)throw Error(C(301));if(a+=1,De=me=null,e.updateQueue!=null){var l=e.updateQueue;l.lastEffect=null,l.events=null,l.stores=null,l.memoCache!=null&&(l.memoCache.index=0)}Y.H=tS,l=t(n,o)}while(il);return l}function Jx(){var e=Y.H,t=e.useState()[0];return t=typeof t.then=="function"?Zi(t):t,e=e.useState()[0],(me!==null?me.memoizedState:null)!==e&&(Q.flags|=1024),t}function gf(){var e=kr!==0;return kr=0,e}function vf(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function yf(e){if(Sr){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Sr=!1}Yn=0,De=me=Q=null,il=!1,Ri=kr=0,cl=null}function dt(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return De===null?Q.memoizedState=De=e:De=De.next=e,De}function Oe(){if(me===null){var e=Q.alternate;e=e!==null?e.memoizedState:null}else e=me.next;var t=De===null?Q.memoizedState:De.next;if(t!==null)De=t,me=e;else{if(e===null)throw Q.alternate===null?Error(C(467)):Error(C(310));me=e,e={memoizedState:me.memoizedState,baseState:me.baseState,baseQueue:me.baseQueue,queue:me.queue,next:null},De===null?Q.memoizedState=De=e:De=De.next=e}return De}function Zr(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Zi(e){var t=Ri;return Ri+=1,cl===null&&(cl=[]),e=cg(cl,e,t),t=Q,(De===null?t.memoizedState:De.next)===null&&(t=t.alternate,Y.H=t===null||t.memoizedState===null?Xg:Kg),e}function Jr(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Zi(e);if(e.$$typeof===zw)return;if(e.$$typeof===hn)return Pe(e)}throw Error(C(438,String(e)))}function wf(e){var t=null,n=Q.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var o=Q.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(t={data:o.data.map(function(a){return a.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),n===null&&(n=Zr(),Q.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),o=0;o<e;o++)n[o]=Mw;return t.index++,n}function Vn(e,t){return typeof t=="function"?t(e):t}function Fc(e){var t=Oe();return xf(t,me,e)}function xf(e,t,n){var o=e.queue;if(o===null)throw Error(C(311));o.lastRenderedReducer=n;var a=e.baseQueue,l=o.pending;if(l!==null){if(a!==null){var i=a.next;a.next=l.next,l.next=i}t.baseQueue=a=l,o.pending=null}if(l=e.baseState,a===null)e.memoizedState=l;else{t=a.next;var c=i=null,r=null,u=t,h=!1;do{var m=u.lane&-536870913;if(m!==u.lane?(I&m)===m:(Yn&m)===m){var p=u.revertLane;if(p===0)r!==null&&(r=r.next={lane:0,revertLane:0,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),m===da&&(h=!0);else if((Yn&p)===p){u=u.next,p===da&&(h=!0);continue}else m={lane:0,revertLane:u.revertLane,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},r===null?(c=r=m,i=l):r=r.next=m,Q.lanes|=p,Oo|=p;m=u.action,pa&&n(l,m),l=u.hasEagerState?u.eagerState:n(l,m)}else p={lane:m,revertLane:u.revertLane,gesture:u.gesture,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},r===null?(c=r=p,i=l):r=r.next=p,Q.lanes|=m,Oo|=m;u=u.next}while(u!==null&&u!==t);if(r===null?i=l:r.next=c,!_t(l,e.memoizedState)&&(Ue=!0,h&&(n=al,n!==null)))throw n;e.memoizedState=l,e.baseState=i,e.baseQueue=r,o.lastRenderedState=l}return a===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function xs(e){var t=Oe(),n=t.queue;if(n===null)throw Error(C(311));n.lastRenderedReducer=e;var o=n.dispatch,a=n.pending,l=t.memoizedState;if(a!==null){n.pending=null;var i=a=a.next;do l=e(l,i.action),i=i.next;while(i!==a);_t(l,t.memoizedState)||(Ue=!0),t.memoizedState=l,t.baseQueue===null&&(t.baseState=l),n.lastRenderedState=l}return[l,o]}function bg(e,t,n){var o=Q,a=Oe(),l=J;if(l){if(n===void 0)throw Error(C(407));n=n()}else n=t();var i=!_t((me||a).memoizedState,n);if(i&&(a.memoizedState=n,Ue=!0),a=a.queue,Sf(vg.bind(null,o,a,e),[e]),e=a.getSnapshot!==t||i||De!==null&&(De.memoizedState.tag&1)!==0,ml(e?9:8,{destroy:void 0},gg.bind(null,o,a,n,t),null),e){if(o.flags|=2048,be===null)throw Error(C(349));l||(Yn&127)!==0||hg(o,t,n)}return n}function hg(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=Q.updateQueue,t===null?(t=Zr(),Q.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function gg(e,t,n,o){t.value=n,t.getSnapshot=o,yg(t)&&wg(e)}function vg(e,t,n){return n(function(){yg(t)&&wg(e)})}function yg(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!_t(e,n)}catch{return!0}}function wg(e){var t=ya(e,2);t!==null&&yt(t,e,2)}function ud(e){var t=dt();if(typeof e=="function"){var n=e;if(e=n(),pa){so(!0);try{n()}finally{so(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Vn,lastRenderedState:e},t}function xg(e,t,n,o){return e.baseState=n,xf(e,me,typeof o=="function"?o:Vn)}function $x(e,t,n,o,a){if(Pr(e))throw Error(C(485));if(e=t.action,e!==null){var l={payload:a,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(i){l.listeners.push(i)}};Y.T!==null?n(!0):l.isTransition=!1,o(l),n=t.pending,n===null?(l.next=t.pending=l,Sg(t,l)):(l.next=n.next,t.pending=n.next=l)}}function Sg(e,t){var n=t.action,o=t.payload,a=e.state;if(t.isTransition){var l=Y.T,i={};i.types=l!==null?l.types:null,Y.T=i;try{var c=n(a,o),r=Y.S;r!==null&&r(i,c),ub(e,t,c)}catch(u){sd(e,t,u)}finally{l!==null&&i.types!==null&&(l.types=i.types),Y.T=l}}else try{l=n(a,o),ub(e,t,l)}catch(u){sd(e,t,u)}}function ub(e,t,n){n!==null&&typeof n=="object"&&typeof n.then=="function"?n.then(function(o){sb(e,t,o)},function(o){return sd(e,t,o)}):sb(e,t,n)}function sb(e,t,n){t.status="fulfilled",t.value=n,kg(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Sg(e,n)))}function sd(e,t,n){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do t.status="rejected",t.reason=n,kg(t),t=t.next;while(t!==o)}e.action=null}function kg(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Eg(e,t){return t}function db(e,t){if(J){var n=be.formState;if(n!==null){e:{var o=Q;if(J){if(we){t:{for(var a=we,l=Gt;a.nodeType!==8;){if(!l){a=null;break t}if(a=Qt(a.nextSibling),a===null){a=null;break t}}l=a.data,a=l==="F!"||l==="F"?a:null}if(a){we=Qt(a.nextSibling),o=a.data==="F!";break e}}Mo(o)}o=!1}o&&(t=n[0])}}return n=dt(),n.memoizedState=n.baseState=t,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Eg,lastRenderedState:t},n.queue=o,n=Yg.bind(null,Q,o),o.dispatch=n,o=ud(!1),l=Cf.bind(null,Q,!1,o.queue),o=dt(),a={state:t,dispatch:null,action:e,pending:null},o.queue=a,n=$x.bind(null,Q,a,l,n),a.dispatch=n,o.memoizedState=e,[t,n,!1]}function fb(e){var t=Oe();return Tg(t,me,e)}function Tg(e,t,n){if(t=xf(e,t,Eg)[0],e=Fc(Vn)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var o=Zi(t)}catch(i){throw i===Cl?Qr:i}else o=t;t=Oe();var a=t.queue,l=a.dispatch;return n!==t.memoizedState&&(Q.flags|=2048,ml(9,{destroy:void 0},Px.bind(null,a,n),null)),[o,l,e]}function Px(e,t){e.action=t}function pb(e){var t=Oe(),n=me;if(n!==null)return Tg(t,n,e);Oe(),t=t.memoizedState,n=Oe();var o=n.queue.dispatch;return n.memoizedState=e,[t,o,!1]}function ml(e,t,n,o){return e={tag:e,create:n,deps:o,inst:t,next:null},t=Q.updateQueue,t===null&&(t=Zr(),Q.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(o=n.next,n.next=e,e.next=o,t.lastEffect=e),e}function Cg(){return Oe().memoizedState}function Ic(e,t,n,o){var a=dt();Q.flags|=e,a.memoizedState=ml(1|t,{destroy:void 0},n,o===void 0?null:o)}function $r(e,t,n,o){var a=Oe();o=o===void 0?null:o;var l=a.memoizedState.inst;me!==null&&o!==null&&bf(o,me.memoizedState.deps)?a.memoizedState=ml(t,l,n,o):(Q.flags|=e,a.memoizedState=ml(1|t,l,n,o))}function mb(e,t){Ic(8390656,8,e,t)}function Sf(e,t){$r(2048,8,e,t)}function Fx(e){Q.flags|=4;var t=Q.updateQueue;if(t===null)t=Zr(),Q.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Ng(e){var t=Oe().memoizedState;return Fx({ref:t,nextImpl:e}),function(){if((le&2)!==0)throw Error(C(440));return t.impl.apply(void 0,arguments)}}function Mg(e,t){return $r(4,2,e,t)}function zg(e,t){return $r(4,4,e,t)}function Ag(e,t){if(typeof t=="function"){e=e();var n=t(e);return function(){typeof n=="function"?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Og(e,t,n){n=n!=null?n.concat([e]):null,$r(4,4,Ag.bind(null,t,e),n)}function kf(){}function Rg(e,t){var n=Oe();t=t===void 0?null:t;var o=n.memoizedState;return t!==null&&bf(t,o[1])?o[0]:(n.memoizedState=[e,t],e)}function Dg(e,t){var n=Oe();t=t===void 0?null:t;var o=n.memoizedState;if(t!==null&&bf(t,o[1]))return o[0];if(o=e(),pa){so(!0);try{e()}finally{so(!1)}}return n.memoizedState=[o,t],o}function Ef(e,t,n){return n===void 0||(Yn&1073741824)!==0&&(I&261930)===0?e.memoizedState=t:(e.memoizedState=n,e=Tv(),Q.lanes|=e,Oo|=e,n)}function _g(e,t,n,o){return _t(n,t)?n:zo.current!==null?(e=Ef(e,n,o),_t(e,t)||(Ue=!0),e):(Yn&106)===0||(Yn&1073741824)!==0&&(I&261930)===0?(Ue=!0,e.memoizedState=n):(e=Tv(),Q.lanes|=e,Oo|=e,t)}function Ug(e,t,n,o,a){var l=ie.p;ie.p=l!==0&&8>l?l:8;var i=Y.T,c={};c.types=i!==null?i.types:null,Y.T=c,Cf(e,!1,t,n);try{var r=a(),u=Y.S;if(u!==null&&u(c,r),r!==null&&typeof r=="object"&&typeof r.then=="function"){var h=Qx(r,o);vi(e,t,h,Dt(e))}else vi(e,t,o,Dt(e))}catch(m){vi(e,t,{then:function(){},status:"rejected",reason:m},Dt())}finally{ie.p=l,i!==null&&c.types!==null&&(i.types=c.types),Y.T=i}}function Ix(){}function dd(e,t,n,o){if(e.tag!==5)throw Error(C(476));var a=Hg(e).queue;Ug(e,a,t,oa,n===null?Ix:function(){return Bg(e),n(o)})}function Hg(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:oa,baseState:oa,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Vn,lastRenderedState:oa},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Vn,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function Bg(e){var t=Hg(e);t.next===null&&(t=e.alternate.memoizedState),vi(e,t.next.queue,{},Dt())}function Tf(){return Pe(xl)}function Lg(){return Oe().memoizedState}function qg(){return Oe().memoizedState}function Wx(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=Dt();e=yo(n);var o=wo(t,e,n);o!==null&&(yt(o,t,n),bi(o,t,n)),t={cache:uf()},e.payload=t;return}t=t.return}}function eS(e,t,n){var o=Dt();n={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},Pr(e)?Vg(t,n):(n=lf(e,t,n,o),n!==null&&(yt(n,e,o),jg(n,t,o)))}function Yg(e,t,n){var o=Dt();vi(e,t,n,o)}function vi(e,t,n,o){var a={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(Pr(e))Vg(t,a);else{var l=e.alternate;if(e.lanes===0&&(l===null||l.lanes===0)&&(l=t.lastRenderedReducer,l!==null))try{var i=t.lastRenderedState,c=l(i,n);if(a.hasEagerState=!0,a.eagerState=c,_t(c,i))return Kr(e,t,a,0),be===null&&Xr(),!1}catch{}if(n=lf(e,t,a,o),n!==null)return yt(n,e,o),jg(n,t,o),!0}return!1}function Cf(e,t,n,o){if(o={lane:2,revertLane:Bf(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Pr(e)){if(t)throw Error(C(479))}else t=lf(e,n,o,2),t!==null&&yt(t,e,2)}function Pr(e){var t=e.alternate;return e===Q||t!==null&&t===Q}function Vg(e,t){il=Sr=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function jg(e,t,n){if((n&4194048)!==0){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Ch(e,n)}}var Er={readContext:Pe,use:Jr,useCallback:ze,useContext:ze,useEffect:ze,useImperativeHandle:ze,useLayoutEffect:ze,useInsertionEffect:ze,useMemo:ze,useReducer:ze,useRef:ze,useState:ze,useDebugValue:ze,useDeferredValue:ze,useTransition:ze,useSyncExternalStore:ze,useId:ze,useHostTransitionStatus:ze,useFormState:ze,useActionState:ze,useOptimistic:ze,useMemoCache:ze,useCacheRefresh:ze,useEffectEvent:ze},Xg={readContext:Pe,use:Jr,useCallback:function(e,t){return dt().memoizedState=[e,t===void 0?null:t],e},useContext:Pe,useEffect:mb,useImperativeHandle:function(e,t,n){n=n!=null?n.concat([e]):null,Ic(4194308,4,Ag.bind(null,t,e),n)},useLayoutEffect:function(e,t){return Ic(4194308,4,e,t)},useInsertionEffect:function(e,t){Ic(4,2,e,t)},useMemo:function(e,t){var n=dt();t=t===void 0?null:t;var o=e();if(pa){so(!0);try{e()}finally{so(!1)}}return n.memoizedState=[o,t],o},useReducer:function(e,t,n){var o=dt();if(n!==void 0){var a=n(t);if(pa){so(!0);try{n(t)}finally{so(!1)}}}else a=t;return o.memoizedState=o.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:a},o.queue=e,e=e.dispatch=eS.bind(null,Q,e),[o.memoizedState,e]},useRef:function(e){var t=dt();return e={current:e},t.memoizedState=e},useState:function(e){e=ud(e);var t=e.queue,n=Yg.bind(null,Q,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:kf,useDeferredValue:function(e,t){var n=dt();return Ef(n,e,t)},useTransition:function(){var e=ud(!1);return e=Ug.bind(null,Q,e.queue,!0,!1),dt().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var o=Q,a=dt();if(J){if(n===void 0)throw Error(C(407));n=n()}else{if(n=t(),be===null)throw Error(C(349));(I&127)!==0||hg(o,t,n)}a.memoizedState=n;var l={value:n,getSnapshot:t};return a.queue=l,mb(vg.bind(null,o,l,e),[e]),o.flags|=2048,ml(9,{destroy:void 0},gg.bind(null,o,l,n,t),null),n},useId:function(){var e=dt(),t=be.identifierPrefix;if(J){var n=yn,o=vn;n=(o&~(1<<32-Rt(o)-1)).toString(32)+n,t="_"+t+"R_"+n,n=kr++,0<n&&(t+="H"+n.toString(32)),t+="_"}else n=Zx++,t="_"+t+"r_"+n.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:Tf,useFormState:db,useActionState:db,useOptimistic:function(e){var t=dt();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=Cf.bind(null,Q,!0,n),n.dispatch=t,[e,t]},useMemoCache:wf,useCacheRefresh:function(){return dt().memoizedState=Wx.bind(null,Q)},useEffectEvent:function(e){var t=dt(),n={impl:e};return t.memoizedState=n,function(){if((le&2)!==0)throw Error(C(440));return n.impl.apply(void 0,arguments)}}},Kg={readContext:Pe,use:Jr,useCallback:Rg,useContext:Pe,useEffect:Sf,useImperativeHandle:Og,useInsertionEffect:Mg,useLayoutEffect:zg,useMemo:Dg,useReducer:Fc,useRef:Cg,useState:function(){return Fc(Vn)},useDebugValue:kf,useDeferredValue:function(e,t){var n=Oe();return _g(n,me.memoizedState,e,t)},useTransition:function(){var e=Fc(Vn)[0],t=Oe().memoizedState;return[typeof e=="boolean"?e:Zi(e),t]},useSyncExternalStore:bg,useId:Lg,useHostTransitionStatus:Tf,useFormState:fb,useActionState:fb,useOptimistic:function(e,t){var n=Oe();return xg(n,me,e,t)},useMemoCache:wf,useCacheRefresh:qg,useEffectEvent:Ng},tS={readContext:Pe,use:Jr,useCallback:Rg,useContext:Pe,useEffect:Sf,useImperativeHandle:Og,useInsertionEffect:Mg,useLayoutEffect:zg,useMemo:Dg,useReducer:xs,useRef:Cg,useState:function(){return xs(Vn)},useDebugValue:kf,useDeferredValue:function(e,t){var n=Oe();return me===null?Ef(n,e,t):_g(n,me.memoizedState,e,t)},useTransition:function(){var e=xs(Vn)[0],t=Oe().memoizedState;return[typeof e=="boolean"?e:Zi(e),t]},useSyncExternalStore:bg,useId:Lg,useHostTransitionStatus:Tf,useFormState:pb,useActionState:pb,useOptimistic:function(e,t){var n=Oe();return me!==null?xg(n,me,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:wf,useCacheRefresh:qg,useEffectEvent:Ng};function Ss(e,t,n,o){t=e.memoizedState,n=n(o,t),n=n==null?t:he({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var fd={enqueueSetState:function(e,t,n){e=e._reactInternals;var o=Dt(),a=yo(o);a.payload=t,n!=null&&(a.callback=n),t=wo(e,a,o),t!==null&&(yt(t,e,o),bi(t,e,o))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var o=Dt(),a=yo(o);a.tag=1,a.payload=t,n!=null&&(a.callback=n),t=wo(e,a,o),t!==null&&(yt(t,e,o),bi(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Dt(),o=yo(n);o.tag=2,t!=null&&(o.callback=t),t=wo(e,o,n),t!==null&&(yt(t,e,n),bi(t,e,n))}};function bb(e,t,n,o,a,l,i){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,l,i):t.prototype&&t.prototype.isPureReactComponent?!Ni(n,o)||!Ni(a,l):!0}function hb(e,t,n,o){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,o),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,o),t.state!==e&&fd.enqueueReplaceState(t,t.state,null)}function ma(e,t){var n=t;if("ref"in t){n={};for(var o in t)o!=="ref"&&(n[o]=t[o])}if(e=e.defaultProps){n===t&&(n=he({},n));for(var a in e)n[a]===void 0&&(n[a]=e[a])}return n}function Gg(e){mr(e)}function Qg(e){console.error(e)}function Zg(e){mr(e)}function Tr(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(o){setTimeout(function(){throw o})}}function gb(e,t,n){try{var o=e.onCaughtError;o(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(a){setTimeout(function(){throw a})}}function pd(e,t,n){return n=yo(n),n.tag=3,n.payload={element:null},n.callback=function(){Tr(e,t)},n}function Jg(e){return e=yo(e),e.tag=3,e}function $g(e,t,n,o){var a=n.type.getDerivedStateFromError;if(typeof a=="function"){var l=o.value;e.payload=function(){return a(l)},e.callback=function(){gb(t,n,o)}}var i=n.stateNode;i!==null&&typeof i.componentDidCatch=="function"&&(e.callback=function(){gb(t,n,o),typeof a!="function"&&(ko===null?ko=new Set([this]):ko.add(this));var c=o.stack;this.componentDidCatch(o.value,{componentStack:c!==null?c:""})})}function nS(e,t,n,o,a){if(n.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(t=n.alternate,t!==null&&ua(t,n,a,!0),n=et.current,n!==null){switch(n.tag){case 31:case 13:case 19:return it===null?Dr():n.alternate===null&&Ae===0&&(Ae=3),n.flags&=-257,n.flags|=65536,n.lanes=a,o===yr?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([o]):t.add(o),zs(e,o,a)),!1;case 22:return n.flags|=65536,o===yr?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([o])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([o]):n.add(o)),zs(e,o,a)),!1}throw Error(C(435,n.tag))}return zs(e,o,a),Dr(),!1}if(J)return t=et.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=a,o!==td&&(e=Error(C(422),{cause:o}),zi(Kt(e,n)))):(o!==td&&(t=Error(C(423),{cause:o}),zi(Kt(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,o=Kt(o,n),a=pd(e.stateNode,o,a),ws(e,a),Ae!==4&&(Ae=2)),!1;var l=Error(C(520),{cause:o});if(l=Kt(l,n),Si===null?Si=[l]:Si.push(l),Ae!==4&&(Ae=2),t===null)return!0;o=Kt(o,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=pd(n.stateNode,o,e),ws(n,e),!1;case 1:if(t=n.type,l=n.stateNode,(n.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||l!==null&&typeof l.componentDidCatch=="function"&&(ko===null||!ko.has(l))))return n.flags|=65536,a&=-a,n.lanes|=a,a=Jg(a),$g(a,e,n,o),ws(n,a),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var Nf=Error(C(461)),Ue=!1;function Be(e,t,n,o){t.child=e===null?ug(t,null,n,o):fa(t,e.child,n,o)}function vb(e,t,n,o,a){n=n.render;var l=t.ref;if("ref"in o){var i={};for(var c in o)c!=="ref"&&(i[c]=o[c])}else i=o;return sa(t),o=hf(e,t,n,i,l,a),c=gf(),e!==null&&!Ue?(vf(e,t,a),jn(e,t,a)):(J&&c&&Gr(t),t.flags|=1,Be(e,t,o,a),t.child)}function yb(e,t,n,o,a){if(e===null){var l=n.type;return typeof l=="function"&&!cf(l)&&l.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=l,Pg(e,t,l,o,a)):(e=Jc(n.type,null,o,t,t.mode,a),e.ref=t.ref,e.return=t,t.child=e)}if(l=e.child,!zf(e,a)){var i=l.memoizedProps;if(n=n.compare,n=n!==null?n:Ni,n(i,o)&&e.ref===t.ref)return jn(e,t,a)}return t.flags|=1,e=Hn(l,o),e.ref=t.ref,e.return=t,t.child=e}function Pg(e,t,n,o,a){if(e!==null){var l=e.memoizedProps;if(Ni(l,o)&&e.ref===t.ref)if(Ue=!1,t.pendingProps=o=l,zf(e,a))(e.flags&131072)!==0&&(Ue=!0);else return t.lanes=e.lanes,jn(e,t,a)}return md(e,t,n,o,a)}function Fg(e,t,n,o){var a=o.children,l=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((t.flags&128)!==0){if(l=l!==null?l.baseLanes|n:n,e!==null){for(o=t.child=e.child,a=0;o!==null;)a=a|o.lanes|o.childLanes,o=o.sibling;o=a&~l}else o=0,t.child=null;return wb(e,t,l,n,o)}if((n&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Pc(t,l!==null?l.cachePool:null),l!==null?rb(t,l):cd(),fg(t);else return o=t.lanes=536870912,wb(e,t,l!==null?l.baseLanes|n:n,n,o)}else l!==null?(Pc(t,l.cachePool),rb(t,l),So(),t.memoizedState=null):(e!==null&&Pc(t,null),cd(),So());return Be(e,t,a,n),t.child}function yi(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function wb(e,t,n,o,a){var l=sf();return l=l===null?null:{parent:_e._currentValue,pool:l},t.memoizedState={baseLanes:n,cachePool:l},e!==null&&Pc(t,null),cd(),fg(t),e!==null&&ua(e,t,o,!0),t.childLanes=a,null}function Wc(e,t){return t=Fr({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function xb(e,t,n){return fa(t,e.child,null,n),e=Wc(t,t.pendingProps),e.flags|=2,Nt(t),t.memoizedState=null,e}function oS(e,t,n){var o=t.pendingProps,a=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(J){if(o.mode==="hidden")return e=Wc(t,o),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},yi(null,e);if(rd(t),(e=we)?(e=Fv(e,Gt),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:No!==null?{id:vn,overflow:yn}:null,retryLane:536870912,hydrationErrors:null},n=ng(e),n.return=t,t.child=n,Ke=t,we=null)):e=null,e===null)throw Mo(t);return t.lanes=536870912,null}return Wc(t,o)}var l=e.memoizedState;if(l!==null){var i=l.dehydrated;if(rd(t),a)if(t.flags&256)t.flags&=-257,t=xb(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(C(558));else if(Ue||ua(e,t,n,!1),a=(n&e.childLanes)!==0,Ue||a){if(zo.current===null){if(o=be,o!==null&&(i=Nh(o,n),i!==0&&i!==l.retryLane))throw l.retryLane=i,ya(e,i),yt(o,e,i),Nf;Dr()}t=xb(e,t,n)}else e=l.treeContext,we=Qt(i.nextSibling),Ke=t,J=!0,vo=null,Gt=!1,e!==null&&ag(t,e),t=Wc(t,o),t.flags|=134221824;return t}return e=Hn(e.child,{mode:o.mode,children:o.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Ya(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!="function"&&typeof n!="object")throw Error(C(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function md(e,t,n,o,a){return sa(t),n=hf(e,t,n,o,void 0,a),o=gf(),e!==null&&!Ue?(vf(e,t,a),jn(e,t,a)):(J&&o&&Gr(t),t.flags|=1,Be(e,t,n,a),t.child)}function Sb(e,t,n,o,a,l){return sa(t),t.updateQueue=null,n=mg(t,o,n,a),pg(e),o=gf(),e!==null&&!Ue?(vf(e,t,l),jn(e,t,l)):(J&&o&&Gr(t),t.flags|=1,Be(e,t,n,l),t.child)}function kb(e,t,n,o,a){if(sa(t),t.stateNode===null){var l=Fa,i=n.contextType;typeof i=="object"&&i!==null&&(l=Pe(i)),l=new n(o,l),t.memoizedState=l.state!==null&&l.state!==void 0?l.state:null,l.updater=fd,t.stateNode=l,l._reactInternals=t,l=t.stateNode,l.props=o,l.state=t.memoizedState,l.refs={},ff(t),i=n.contextType,l.context=typeof i=="object"&&i!==null?Pe(i):Fa,l.state=t.memoizedState,i=n.getDerivedStateFromProps,typeof i=="function"&&(Ss(t,n,i,o),l.state=t.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof l.getSnapshotBeforeUpdate=="function"||typeof l.UNSAFE_componentWillMount!="function"&&typeof l.componentWillMount!="function"||(i=l.state,typeof l.componentWillMount=="function"&&l.componentWillMount(),typeof l.UNSAFE_componentWillMount=="function"&&l.UNSAFE_componentWillMount(),i!==l.state&&fd.enqueueReplaceState(l,l.state,null),gi(t,o,l,a),hi(),l.state=t.memoizedState),typeof l.componentDidMount=="function"&&(t.flags|=4194308),o=!0}else if(e===null){l=t.stateNode;var c=t.memoizedProps,r=ma(n,c);l.props=r;var u=l.context,h=n.contextType;i=Fa,typeof h=="object"&&h!==null&&(i=Pe(h));var m=n.getDerivedStateFromProps;h=typeof m=="function"||typeof l.getSnapshotBeforeUpdate=="function",c=t.pendingProps!==c,h||typeof l.UNSAFE_componentWillReceiveProps!="function"&&typeof l.componentWillReceiveProps!="function"||(c||u!==i)&&hb(t,l,o,i),ro=!1;var p=t.memoizedState;l.state=p,gi(t,o,l,a),hi(),u=t.memoizedState,c||p!==u||ro?(typeof m=="function"&&(Ss(t,n,m,o),u=t.memoizedState),(r=ro||bb(t,n,r,o,p,u,i))?(h||typeof l.UNSAFE_componentWillMount!="function"&&typeof l.componentWillMount!="function"||(typeof l.componentWillMount=="function"&&l.componentWillMount(),typeof l.UNSAFE_componentWillMount=="function"&&l.UNSAFE_componentWillMount()),typeof l.componentDidMount=="function"&&(t.flags|=4194308)):(typeof l.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=o,t.memoizedState=u),l.props=o,l.state=u,l.context=i,o=r):(typeof l.componentDidMount=="function"&&(t.flags|=4194308),o=!1)}else{l=t.stateNode,ld(e,t),i=t.memoizedProps,h=ma(n,i),l.props=h,m=t.pendingProps,p=l.context,u=n.contextType,r=Fa,typeof u=="object"&&u!==null&&(r=Pe(u)),c=n.getDerivedStateFromProps,(u=typeof c=="function"||typeof l.getSnapshotBeforeUpdate=="function")||typeof l.UNSAFE_componentWillReceiveProps!="function"&&typeof l.componentWillReceiveProps!="function"||(i!==m||p!==r)&&hb(t,l,o,r),ro=!1,p=t.memoizedState,l.state=p,gi(t,o,l,a),hi();var f=t.memoizedState;i!==m||p!==f||ro||e!==null&&e.dependencies!==null&&vr(e.dependencies)?(typeof c=="function"&&(Ss(t,n,c,o),f=t.memoizedState),(h=ro||bb(t,n,h,o,p,f,r)||e!==null&&e.dependencies!==null&&vr(e.dependencies))?(u||typeof l.UNSAFE_componentWillUpdate!="function"&&typeof l.componentWillUpdate!="function"||(typeof l.componentWillUpdate=="function"&&l.componentWillUpdate(o,f,r),typeof l.UNSAFE_componentWillUpdate=="function"&&l.UNSAFE_componentWillUpdate(o,f,r)),typeof l.componentDidUpdate=="function"&&(t.flags|=4),typeof l.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof l.componentDidUpdate!="function"||i===e.memoizedProps&&p===e.memoizedState||(t.flags|=4),typeof l.getSnapshotBeforeUpdate!="function"||i===e.memoizedProps&&p===e.memoizedState||(t.flags|=1024),t.memoizedProps=o,t.memoizedState=f),l.props=o,l.state=f,l.context=r,o=h):(typeof l.componentDidUpdate!="function"||i===e.memoizedProps&&p===e.memoizedState||(t.flags|=4),typeof l.getSnapshotBeforeUpdate!="function"||i===e.memoizedProps&&p===e.memoizedState||(t.flags|=1024),o=!1)}return l=o,Ya(e,t),o=(t.flags&128)!==0,l||o?(l=t.stateNode,n=o&&typeof n.getDerivedStateFromError!="function"?null:l.render(),t.flags|=1,e!==null&&o?(t.child=fa(t,e.child,null,a),t.child=fa(t,null,n,a)):Be(e,t,n,a),t.memoizedState=l.state,e=t.child):e=jn(e,t,a),e}function Eb(e,t,n,o){return ra(),t.flags|=256,Be(e,t,n,o),t.child}var bd={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function hd(e){return{baseLanes:e,cachePool:ig()}}function gd(e,t,n){return e=e!==null?e.childLanes&~n:0,t&&(e|=zt),e}function Ig(e,t,n){var o=t.pendingProps,a=!1,l=(t.flags&128)!==0,i;if((i=l)||(i=e!==null&&e.memoizedState===null?!1:(Ie.current&2)!==0),i&&(a=!0,t.flags&=-129),i=(t.flags&32)!==0,t.flags&=-33,e===null){if(J){if(a?xo(t):So(),(e=we)?(e=Fv(e,Gt),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:No!==null?{id:vn,overflow:yn}:null,retryLane:536870912,hydrationErrors:null},n=ng(e),n.return=t,t.child=n,Ke=t,we=null)):e=null,e===null)throw Mo(t);return Vf(e)?t.lanes=32:t.lanes=536870912,null}return l=o.children,o=o.fallback,a?(So(),a=t.mode,l=Fr({mode:"hidden",children:l},a),o=aa(o,a,n,null),l.return=t,o.return=t,l.sibling=o,t.child=l,o=t.child,o.memoizedState=hd(n),o.childLanes=gd(e,i,n),t.memoizedState=bd,yi(null,o)):(xo(t),Mf(t,l))}var c=e.memoizedState;if(c!==null){var r=c.dehydrated;if(r!==null)return aS(e,t,l,i,o,r,c,n)}return a?(So(),a=o.fallback,l=t.mode,c=e.child,r=c.sibling,o=Hn(c,{mode:"hidden",children:o.children}),o.subtreeFlags=c.subtreeFlags&1206910976,r!==null?a=Hn(r,a):(a=aa(a,l,n,null),a.flags|=2),a.return=t,o.return=t,o.sibling=a,t.child=o,yi(null,o),o=t.child,a=e.child.memoizedState,a===null?a=hd(n):(l=a.cachePool,l!==null?(c=_e._currentValue,l=l.parent!==c?{parent:c,pool:c}:l):l=ig(),a={baseLanes:a.baseLanes|n,cachePool:l}),o.memoizedState=a,o.childLanes=gd(e,i,n),t.memoizedState=bd,yi(e.child,o)):(xo(t),n=e.child,e=n.sibling,n=Hn(n,{mode:"visible",children:o.children}),n.return=t,n.sibling=null,e!==null&&(i=t.deletions,i===null?(t.deletions=[e],t.flags|=16):i.push(e)),t.child=n,t.memoizedState=null,n)}function Mf(e,t){return t=Fr({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function Fr(e,t){return e=vt(22,e,null,t),e.lanes=0,e}function _c(e,t,n){return fa(t,e.child,null,n),e=Mf(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function aS(e,t,n,o,a,l,i,c){if(n)return t.flags&256?(xo(t),t.flags&=-257,_c(e,t,c)):t.memoizedState!==null?(So(),t.child=e.child,t.flags|=128,null):(So(),l=a.fallback,i=t.mode,a=Fr({mode:"visible",children:a.children},i),l=aa(l,i,c,null),l.flags|=2,a.return=t,l.return=t,a.sibling=l,t.child=a,fa(t,e.child,null,c),a=t.child,a.memoizedState=hd(c),a.childLanes=gd(e,o,c),t.memoizedState=bd,yi(null,a));if(xo(t),Vf(l)){if(o=l.nextSibling&&l.nextSibling.dataset,o)var r=o.dgst;return o=r,o!==""&&(a=Error(C(419)),a.stack="",a.digest=o,zi({value:a,source:null,stack:null})),_c(e,t,c)}if(Ue||ua(e,t,c,!1),o=(c&e.childLanes)!==0,Ue||o){if(zo.current!==null)return _c(e,t,c);if(o=be,o!==null&&(a=Nh(o,c),a!==0&&a!==i.retryLane))throw i.retryLane=a,ya(e,a),yt(o,e,a),Nf;return jd(l)||Dr(),_c(e,t,c)}return jd(l)?(t.flags|=192,t.child=e.child,null):(e=i.treeContext,we=Qt(l.nextSibling),Ke=t,J=!0,vo=null,Gt=!1,e!==null&&ag(t,e),t=Mf(t,a.children),t.flags|=134221824,t)}function Tb(e,t,n){e.lanes|=t;var o=e.alternate;o!==null&&(o.lanes|=t),$c(e.return,t,n)}function Cb(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&xr(n)===null&&(t=e),e=e.sibling}return t}function Uc(e,t,n,o,a,l){var i=e.memoizedState;i===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:o,tail:n,tailMode:a,treeForkCount:l}:(i.isBackwards=t,i.rendering=null,i.renderingStartTime=0,i.last=o,i.tail=n,i.tailMode=a,i.treeForkCount=l)}function ks(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function vd(e,t,n){var o=t.pendingProps,a=o.revealOrder,l=o.tail;o=o.children;var i=Ie.current;if(t.flags&128)return Oi(t,i),null;var c=(i&2)!==0;if(c?(i=i&1|2,t.flags|=128):i&=1,Oi(t,i),a==="backwards"&&e!==null?(ks(e),Be(e,t,o,n),ks(e)):Be(e,t,o,n),o=J?Mi:0,!c&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Tb(e,n,t);else if(e.tag===19)Tb(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(a){case"backwards":n=Cb(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null,ks(t)),Uc(t,!0,a,null,l,o);break;case"unstable_legacy-backwards":for(n=null,a=t.child,t.child=null;a!==null;){if(e=a.alternate,e!==null&&xr(e)===null){t.child=a;break}e=a.sibling,a.sibling=n,n=a,a=e}Uc(t,!0,n,null,l,o);break;case"together":Uc(t,!1,null,null,void 0,o);break;case"independent":t.memoizedState=null;break;default:n=Cb(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null),Uc(t,!1,a,n,l,o)}return t.child}function Nb(e,t,n){var o=t.pendingProps;return po(t,t.type,o.value),Be(e,t,o.children,n),t.child}function jn(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Oo|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(ua(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(C(153));if(t.child!==null){for(e=t.child,n=Hn(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Hn(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function zf(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&vr(e)))}function lS(e,t,n){switch(t.tag){case 3:sr(t,t.stateNode.containerInfo),po(t,_e,e.memoizedState.cache),ra();break;case 27:case 5:Gs(t);break;case 4:sr(t,t.stateNode.containerInfo);break;case 10:po(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,rd(t),null;break;case 13:var o=t.memoizedState;if(o!==null){if(o.dehydrated!==null)return xo(t),t.flags|=128,null;o=ua(e,t,n,!1);var a=t.child.childLanes;return o||(n&a)!==0?Ig(e,t,n):(xo(t),e=jn(e,t,n),e!==null?e.sibling:null)}xo(t);break;case 19:if(t.flags&128)return vd(e,t,n);if(a=(e.flags&128)!==0,o=(n&t.childLanes)!==0,o||(ua(e,t,n,!1),o=(n&t.childLanes)!==0),a){if(o)return vd(e,t,n);t.flags|=128}if(a=t.memoizedState,a!==null&&(a.rendering=null,a.tail=null,a.lastEffect=null),Oi(t,Ie.current),o)break;return null;case 22:return t.lanes=0,Fg(e,t,n,t.pendingProps);case 24:po(t,_e,e.memoizedState.cache)}return jn(e,t,n)}function Wg(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)Ue=!0;else{if(!zf(e,n)&&(t.flags&128)===0)return Ue=!1,lS(e,t,n);Ue=(e.flags&131072)!==0}else Ue=!1,J&&(t.flags&1048576)!==0&&og(t,Mi,t.index);switch(t.lanes=0,t.tag){case 16:e:{var o=t.pendingProps;if(e=Wo(t.elementType),t.type=e,typeof e=="function")cf(e)?(o=ma(e,o),t.tag=1,t=kb(null,t,e,o,n)):(t.tag=0,t=md(null,t,e,o,n));else{if(e!=null){var a=e.$$typeof;if(a===Zd){t.tag=11,t=vb(null,t,e,o,n);break e}else if(a===Jd){t.tag=14,t=yb(null,t,e,o,n);break e}else if(a===hn){t.tag=10,t.type=e,t=Nb(null,t,n);break e}}throw t=Xs(e)||e,Error(C(306,t,""))}}return t;case 0:return md(e,t,t.type,t.pendingProps,n);case 1:return o=t.type,a=ma(o,t.pendingProps),kb(e,t,o,a,n);case 3:e:{if(sr(t,t.stateNode.containerInfo),e===null)throw Error(C(387));o=t.pendingProps;var l=t.memoizedState;a=l.element,ld(e,t),gi(t,o,null,n);var i=t.memoizedState;if(o=i.cache,po(t,_e,o),o!==l.cache&&od(t,[_e],n,!0),hi(),o=i.element,l.isDehydrated)if(l={element:o,isDehydrated:!1,cache:i.cache},t.updateQueue.baseState=l,t.memoizedState=l,t.flags&256){t=Eb(e,t,o,n);break e}else if(o!==a){a=Kt(Error(C(424)),t),zi(a),t=Eb(e,t,o,n);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,we=Qt(e.firstChild),Ke=t,J=!0,vo=null,Gt=!0,n=ug(t,null,o,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling;else{if(ra(),o===a){t=jn(e,t,n);break e}Be(e,t,o,n)}t=t.child}return t;case 26:return Ya(e,t),e===null?(n=eh(t.type,null,t.pendingProps,null))?t.memoizedState=n:J||(t.stateNode=jv(t.type,t.pendingProps,go.current,t)):t.memoizedState=eh(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return Gs(t),e===null&&J&&(o=t.stateNode=Iv(t.type,t.pendingProps,go.current),Ke=t,Gt=!0,a=we,Do(t.type)?(Xd=a,we=Qt(o.firstChild)):we=a),Be(e,t,t.pendingProps.children,n),Ya(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&J&&((a=o=we)&&(o=FS(o,t.type,t.pendingProps,Gt),o!==null?(t.stateNode=o,Ke=t,we=Qt(o.firstChild),Gt=!1,a=!0):a=!1),a||Mo(t)),Gs(t),a=t.type,l=t.pendingProps,i=e!==null?e.memoizedProps:null,o=l.children,qd(a,l)?o=null:i!==null&&qd(a,i)&&(t.flags|=32),t.memoizedState!==null&&(a=hf(e,t,Jx,null,null,n),xl._currentValue=a),Ya(e,t),Be(e,t,o,n),t.child;case 6:return e===null&&J&&((e=n=we)&&(n=IS(n,t.pendingProps,Gt),n!==null?(t.stateNode=n,Ke=t,we=null,e=!0):e=!1),e||Mo(t)),null;case 13:return Ig(e,t,n);case 4:return sr(t,t.stateNode.containerInfo),o=t.pendingProps,e===null?t.child=fa(t,null,o,n):Be(e,t,o,n),t.child;case 11:return vb(e,t,t.type,t.pendingProps,n);case 7:return o=t.pendingProps,Ya(e,t),Be(e,t,o,n),t.child;case 8:return Be(e,t,t.pendingProps.children,n),t.child;case 12:return Be(e,t,t.pendingProps.children,n),t.child;case 10:return Nb(e,t,n);case 9:return a=t.type._context,o=t.pendingProps.children,sa(t),a=Pe(a),o=o(a),t.flags|=1,Be(e,t,o,n),t.child;case 14:return yb(e,t,t.type,t.pendingProps,n);case 15:return Pg(e,t,t.type,t.pendingProps,n);case 19:return vd(e,t,n);case 31:return oS(e,t,n);case 22:return Fg(e,t,n,t.pendingProps);case 24:return sa(t),o=Pe(_e),e===null?(a=sf(),a===null&&(a=be,l=uf(),a.pooledCache=l,l.refCount++,l!==null&&(a.pooledCacheLanes|=n),a=l),t.memoizedState={parent:o,cache:a},ff(t),po(t,_e,a)):((e.lanes&n)!==0&&(ld(e,t),gi(t,null,null,n),hi()),a=e.memoizedState,l=t.memoizedState,a.parent!==o?(a={parent:o,cache:o},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),po(t,_e,o)):(o=l.cache,po(t,_e,o),o!==a.cache&&od(t,[_e],n,!0))),Be(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),o=t.pendingProps,o.name!=null&&o.name!=="auto"?t.flags|=e===null?18882560:18874368:J&&Gr(t),e!==null&&e.memoizedProps.name!==o.name?t.flags|=4194816:Ya(e,t),Be(e,t,o.children,n),t.child;case 29:throw t.pendingProps}throw Error(C(156,t.tag))}function Dn(e){e.flags|=4}function Es(e,t,n,o,a){var l;if((l=(e.mode&32)!==0)&&(l=n===null?oh(t,o):oh(t,o)&&(o.src!==n.src||o.srcSet!==n.srcSet)),l){if(e.flags|=16777216,(a&335544128)===a)if(e.stateNode.complete)e.flags|=8192;else if(Mv())e.flags|=8192;else throw ia=yr,df}else e.flags&=-16777217}function Mb(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!n0(t))if(Mv())e.flags|=8192;else throw ia=yr,df}function Hc(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?Eh():536870912,e.lanes|=t,bl|=t)}function ni(e,t){if(!J)switch(e.tailMode){case"visible":break;case"collapsed":for(var n=e.tail,o=null;n!==null;)n.alternate!==null&&(o=n),n=n.sibling;o===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function ye(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,o=0;if(t)for(var a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags&1206910976,o|=a.flags&1206910976,a.return=e,a=a.sibling;else for(a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags,o|=a.flags,a.return=e,a=a.sibling;return e.subtreeFlags|=o,e.childLanes=n,t}function iS(e,t,n){var o=t.pendingProps;switch(rf(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return ye(t),null;case 1:return ye(t),null;case 3:return n=t.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),t.memoizedState.cache!==o&&(t.flags|=2048),Bn(_e),dl(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(La(t)?Dn(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,ys())),ye(t),null;case 26:var a=t.type,l=t.memoizedState;return e===null?(Dn(t),l!==null?(ye(t),Mb(t,l)):(ye(t),Es(t,a,null,o,n))):l?l!==e.memoizedState?(Dn(t),ye(t),Mb(t,l)):(ye(t),t.flags&=-16777217):(e=e.memoizedProps,e!==o&&Dn(t),ye(t),Es(t,a,e,o,n)),null;case 27:if(dr(t),n=go.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&Dn(t);else{if(!o){if(t.stateNode===null)throw Error(C(166));return ye(t),t.subtreeFlags&=-33554433,null}e=wn.current,La(t)?tb(t,e):(e=Iv(a,o,n),t.stateNode=e,Dn(t))}return ye(t),t.subtreeFlags&=-33554433,null;case 5:if(dr(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&Dn(t);else{if(!o){if(t.stateNode===null)throw Error(C(166));return ye(t),t.subtreeFlags&=-33554433,null}if(l=wn.current,La(t))tb(t,l);else{var i=Ui(go.current);switch(l){case 1:l=i.createElementNS("http://www.w3.org/2000/svg",a);break;case 2:l=i.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;default:switch(a){case"svg":l=i.createElementNS("http://www.w3.org/2000/svg",a);break;case"math":l=i.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;case"script":l=i.createElement("div"),l.innerHTML="<script><\/script>",l=l.removeChild(l.firstChild);break;case"select":l=typeof o.is=="string"?i.createElement("select",{is:o.is}):i.createElement("select"),o.multiple?l.multiple=!0:o.size&&(l.size=o.size);break;default:l=typeof o.is=="string"?i.createElement(a,{is:o.is}):i.createElement(a)}}l[$e]=t,l[xt]=o;e:for(i=t.child;i!==null;){if(i.tag===5||i.tag===6)l.appendChild(i.stateNode);else if(i.tag!==4&&i.tag!==27&&i.child!==null){i.child.return=i,i=i.child;continue}if(i===t)break e;for(;i.sibling===null;){if(i.return===null||i.return===t)break e;i=i.return}i.sibling.return=i.return,i=i.sibling}t.stateNode=l;e:switch(We(l,a,o),a){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&Dn(t)}}return ye(t),t.subtreeFlags&=-33554433,Es(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==o&&Dn(t);else{if(typeof o!="string"&&t.stateNode===null)throw Error(C(166));if(e=go.current,La(t)){if(e=t.stateNode,n=t.memoizedProps,o=null,a=Ke,a!==null)switch(a.tag){case 27:case 5:o=a.memoizedProps}e[$e]=t,e=!!(e.nodeValue===n||o!==null&&o.suppressHydrationWarning===!0||Yv(e.nodeValue,n)),e||Mo(t,!0)}else e=Ui(e).createTextNode(o),e[$e]=t,t.stateNode=e}return ye(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(o=La(t),n!==null){if(e===null){if(!o)throw Error(C(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(C(557));e[$e]=t}else ra(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;ye(t),e=!1}else n=ys(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(Nt(t),t):(Nt(t),null);if((t.flags&128)!==0)throw Error(C(558))}return ye(t),null;case 13:if(o=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=La(t),o!==null&&o.dehydrated!==null){if(e===null){if(!a)throw Error(C(318));if(a=t.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(C(317));a[$e]=t}else ra(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;ye(t),a=!1}else a=ys(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(Nt(t),t):(Nt(t),null)}return Nt(t),(t.flags&128)!==0?(t.lanes=n,t):(n=o!==null,e=e!==null&&e.memoizedState!==null,n&&(o=t.child,a=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(a=o.alternate.memoizedState.cachePool.pool),l=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(l=o.memoizedState.cachePool.pool),l!==a&&(o.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),Hc(t,t.updateQueue),ye(t),null);case 4:return dl(),e===null&&Lf(t.stateNode.containerInfo),t.flags|=67108864,ye(t),null;case 10:return Bn(t.type),ye(t),null;case 19:if(mf(t),o=t.memoizedState,o===null)return ye(t),null;if(a=(t.flags&128)!==0,l=o.rendering,l===null)if(a)ni(o,!1);else{if(Ae!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(l=xr(e),l!==null){for(t.flags|=128,ni(o,!1),e=l.updateQueue,t.updateQueue=e,Hc(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)tg(n,e),n=n.sibling;return Oi(t,Ie.current&1|2),J&&_n(t,o.treeForkCount),t.child}e=e.sibling}o.tail!==null&&At()>Or&&(t.flags|=128,a=!0,ni(o,!1),t.lanes=4194304)}else{if(!a)if(e=xr(l),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,Hc(t,e),ni(o,!0),o.tail===null&&o.tailMode!=="collapsed"&&o.tailMode!=="visible"&&!l.alternate&&!J)return ye(t),null}else 2*At()-o.renderingStartTime>Or&&n!==536870912&&(t.flags|=128,a=!0,ni(o,!1),t.lanes=4194304);o.isBackwards?(l.sibling=t.child,t.child=l):(e=o.last,e!==null?e.sibling=l:t.child=l,o.last=l)}if(o.tail!==null){e=o.tail;e:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break e}n=n.sibling}n=!0}return o.rendering=e,o.tail=e.sibling,o.renderingStartTime=At(),e.sibling=null,l=Ie.current,l=a?l&1|2:l&1,o.tailMode==="visible"||o.tailMode==="collapsed"||!n||J?Oi(t,l):(n=l,xe(et,t),xe(Ie,n),it===null&&(it=t)),J&&_n(t,o.treeForkCount),e}return ye(t),null;case 22:case 23:return Nt(t),pf(),o=t.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(t.flags|=8192):o&&(t.flags|=8192),o?(n&536870912)!==0&&(t.flags&128)===0&&(ye(t),t.subtreeFlags&6&&(t.flags|=8192)):ye(t),n=t.updateQueue,n!==null&&Hc(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),o=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),o!==n&&(t.flags|=2048),e!==null&&Fe(la),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),Bn(_e),ye(t),null;case 25:return null;case 30:return t.flags|=33554432,ye(t),null}throw Error(C(156,t.tag))}function cS(e,t){switch(rf(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return Bn(_e),dl(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return dr(t),null;case 31:if(t.memoizedState!==null){if(Nt(t),t.alternate===null)throw Error(C(340));ra()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(Nt(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(C(340));ra()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return mf(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return dl(),null;case 10:return Bn(t.type),null;case 22:case 23:return Nt(t),pf(),e!==null&&Fe(la),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return Bn(_e),null;case 25:return null;default:return null}}function ev(e,t){switch(rf(t),t.tag){case 3:Bn(_e),dl();break;case 26:case 27:case 5:dr(t);break;case 4:dl();break;case 31:t.memoizedState!==null&&Nt(t);break;case 13:Nt(t);break;case 19:mf(t);break;case 10:Bn(t.type);break;case 22:case 23:Nt(t),pf(),e!==null&&Fe(la);break;case 24:Bn(_e)}}function Ji(e,t){try{var n=t.updateQueue,o=n!==null?n.lastEffect:null;if(o!==null){var a=o.next;n=a;do{if((n.tag&e)===e){o=void 0;var l=n.create,i=n.inst;o=l(),i.destroy=o}n=n.next}while(n!==a)}}catch(c){pe(t,t.return,c)}}function Ao(e,t,n){try{var o=t.updateQueue,a=o!==null?o.lastEffect:null;if(a!==null){var l=a.next;o=l;do{if((o.tag&e)===e){var i=o.inst,c=i.destroy;if(c!==void 0){i.destroy=void 0,a=t;var r=n,u=c;try{u()}catch(h){pe(a,r,h)}}}o=o.next}while(o!==l)}}catch(h){pe(t,t.return,h)}}function tv(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{dg(t,n)}catch(o){pe(e,e.return,o)}}}function nv(e,t,n){n.props=ma(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(o){pe(e,t,o)}}function mn(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:var a=e.stateNode,l=qn(e.memoizedProps,a);(a.ref===null||a.ref.name!==l)&&(a.ref=Qv(l)),o=a.ref;break;case 7:if(e.stateNode===null){var i=new Ut(e);wt(e.child,!1,$S,i,void 0,void 0),e.stateNode=i}o=e.stateNode;break;default:o=e.stateNode}typeof n=="function"?e.refCleanup=n(o):n.current=o}}catch(c){pe(e,t,c)}}function Je(e,t){var n=e.ref,o=e.refCleanup;if(n!==null)if(typeof o=="function")try{o()}catch(a){pe(e,t,a)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n=="function")try{n(null)}catch(a){pe(e,t,a)}else n.current=null}function Cr(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)Pv(e.stateNode,t[n])}function zb(e){for(var t=e.return;t!==null&&(Of(t)&&Pv(e.stateNode,t.stateNode),!Af(t));)t=t.return}function wi(e){for(var t=e.return;t!==null&&(Of(t)&&PS(e.stateNode,t.stateNode),!Af(t));)t=t.return}function Af(e){return e.tag===5||e.tag===3||e.tag===27}function Of(e){return e&&e.tag===7&&e.stateNode!==null}function yd(e){var t=e.type,n=e.memoizedProps,o=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&o.focus();break e;case"img":n.src?o.src=n.src:n.srcSet&&(o.srcset=n.srcSet)}}catch(a){pe(e,e.return,a)}}function Ts(e,t,n){try{var o=e.stateNode;OS(o,e.type,n,t),o[xt]=t}catch(a){pe(e,e.return,a)}}function ov(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Do(e.type)||e.tag===4}function Cs(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||ov(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Do(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function wd(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n).insertBefore(a,t):(t=n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.appendChild(a),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=gn)),Cr(e,o),oe=!0;else if(a!==4&&(a===27&&(Cr(e,o),o=null,Do(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(wd(e,t,n,o),e=e.sibling;e!==null;)wd(e,t,n,o),e=e.sibling}function Nr(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?n.insertBefore(a,t):n.appendChild(a),Cr(e,o),oe=!0;else if(a!==4&&(a===27&&(Cr(e,o),o=null,Do(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(Nr(e,t,n,o),e=e.sibling;e!==null;)Nr(e,t,n,o),e=e.sibling}function av(e){var t=e.stateNode,n=e.memoizedProps;try{for(var o=e.type,a=t.attributes;a.length;)t.removeAttributeNode(a[0]);We(t,o,n),t[$e]=e,t[xt]=n}catch(l){pe(e,e.return,l)}}var Mr=!1,Mt=null;function Ab(e){(e.tag===30||(e.subtreeFlags&33554432)!==0)&&(Mr=!0)}var bn=null;function Ob(){var e=bn;return bn=null,e}var gt=0;function Nl(e,t,n,o,a){return gt=0,lv(e.child,t,n,o,a)}function lv(e,t,n,o,a){for(var l=!1;e!==null;){if(e.tag===5){var i=e.stateNode;if(o!==null){var c=Yd(i);o.push(c),c.view&&(l=!0)}else l||Yd(i).view&&(l=!0);Mr=!0,Xv(i,gt===0?t:t+"_"+gt,n),gt++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&a||lv(e.child,t,n,o,a)&&(l=!0));e=e.sibling}return l}function Sn(e,t){for(;e!==null;)e.tag===5?Kv(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||Sn(e.child,t)),e=e.sibling}function er(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(er(e),e.tag===30&&(e.flags&18874368)!==0&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name==="auto")throw Error(C(544));var n=t.name;t=Gn(t.default,t.share),t!=="none"&&(Nl(e,n,t,null,!1)||Sn(e.child,!1))}e=e.sibling}}function xd(e,t){if(e.tag===30){var n=e.stateNode,o=e.memoizedProps,a=qn(o,n),l=Gn(o.default,n.paired?o.share:o.enter);l!=="none"?Nl(e,a,l,null,!1)?(er(e),n.paired||t||hl(e,o.onEnter)):Sn(e.child,!1):er(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)xd(e,t),e=e.sibling;else er(e)}function Sd(e){if(Mt!==null&&Mt.size!==0){var t=Mt;if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var n=e.memoizedProps,o=n.name;if(o!=null&&o!=="auto"){var a=t.get(o);if(a!==void 0){var l=Gn(n.default,n.share);if(l!=="none"&&(Nl(e,o,l,null,!1)?(l=e.stateNode,a.paired=l,l.paired=a,hl(e,n.onShare)):Sn(e.child,!1)),t.delete(o),t.size===0)break}}}Sd(e)}e=e.sibling}}}function kd(e){if(e.tag===30){var t=e.memoizedProps,n=qn(t,e.stateNode),o=Mt!==null?Mt.get(n):void 0,a=Gn(t.default,o!==void 0?t.share:t.exit);a!=="none"&&(Nl(e,n,a,null,!1)?o!==void 0?(a=e.stateNode,o.paired=a,a.paired=o,Mt.delete(n),hl(e,t.onShare)):hl(e,t.onExit):Sn(e.child,!1)),Mt!==null&&Sd(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)kd(e),e=e.sibling;else Mt!==null&&Sd(e)}function iv(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=qn(t,e.stateNode);t=Gn(t.default,t.update),e.flags&=-5,t!=="none"&&Nl(e,n,t,e.memoizedState=[],!1)}else(e.subtreeFlags&33554432)!==0&&iv(e);e=e.sibling}}function Ed(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var t=e.stateNode;t.paired!==null&&(t.paired=null,Sn(e.child,!1))}Ed(e)}e=e.sibling}}function tr(e){if(e.tag===30)e.stateNode.paired=null,Sn(e.child,!1),Ed(e);else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)tr(e),e=e.sibling;else Ed(e)}function cv(e){for(e=e.child;e!==null;)e.tag===30?Sn(e.child,!1):(e.subtreeFlags&33554432)!==0&&cv(e),e=e.sibling}function Rf(e,t,n,o,a,l,i){for(var c=!1;t!==null;){if(t.tag===5){var r=t.stateNode;if(l!==null&&gt<l.length){var u=l[gt],h=Yd(r);(u.view||h.view)&&(c=!0);var m;if(m=(e.flags&4)===0)if(h.clip)m=!0;else{m=u.rect;var p=h.rect;m=m.y!==p.y||m.x!==p.x||m.height!==p.height||m.width!==p.width}m&&(e.flags|=4),h.abs?h=!u.abs:(u=u.rect,h=h.rect,h=u.height!==h.height||u.width!==h.width),h&&(e.flags|=32)}else e.flags|=32;(e.flags&4)!==0&&Xv(r,gt===0?n:n+"_"+gt,a),c&&(e.flags&4)!==0||(bn===null&&(bn=[]),bn.push(r,gt===0?o:o+"_"+gt,t.memoizedProps)),gt++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&i?e.flags|=t.flags&32:Rf(e,t.child,n,o,a,l,i)&&(c=!0));t=t.sibling}return c}function rv(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,o=e.stateNode,a=qn(n,o),l=Gn(n.default,n.update);if(t){o=o.clones;var i=o===null?null:o.map(BS)}else i=e.memoizedState,e.memoizedState=null;o=e;var c=e.child;gt=0,a=Rf(o,c,a,a,l,i,!1),(e.flags&4)!==0&&a&&(t||hl(e,n.onUpdate))}else(e.subtreeFlags&33554432)!==0&&rv(e,t);e=e.sibling}}var Ve=!1,se=!1,dn=!1,Ns=!1,Rb=typeof WeakSet=="function"?WeakSet:Set,je=null,fn=!1,si=!1,zr=!1,Td=!1;function rS(e,t,n){if(e=e.containerInfo,Bd=Sl,e=Zh(e),of(e)){if("selectionStart"in e)var o={start:e.selectionStart,end:e.selectionEnd};else e:{o=(o=e.ownerDocument)&&o.defaultView||window;var a=o.getSelection&&o.getSelection();if(a&&a.rangeCount!==0){o=a.anchorNode;var l=a.anchorOffset,i=a.focusNode;a=a.focusOffset;try{o.nodeType,i.nodeType}catch{o=null;break e}var c=0,r=-1,u=-1,h=0,m=0,p=e,f=null;t:for(;;){for(var x;p!==o||l!==0&&p.nodeType!==3||(r=c+l),p!==i||a!==0&&p.nodeType!==3||(u=c+a),p.nodeType===3&&(c+=p.nodeValue.length),(x=p.firstChild)!==null;)f=p,p=x;for(;;){if(p===e)break t;if(f===o&&++h===l&&(r=c),f===i&&++m===a&&(u=c),(x=p.nextSibling)!==null)break;p=f,f=p.parentNode}p=x}o=r===-1||u===-1?null:{start:r,end:u}}else o=null}o=o||{start:0,end:0}}else o=null;for(Ld={focusedElem:e,selectionRange:o},Sl=!1,n=(n&335544064)===n,je=t,t=n?9270:1024;je!==null;){if(e=je,n&&(o=e.deletions,o!==null))for(l=0;l<o.length;l++)n&&kd(o[l]);if(e.alternate===null&&(e.flags&2)!==0)n&&Ab(e),Bc(n);else{if(e.tag===22){if(o=e.alternate,e.memoizedState!==null){o!==null&&o.memoizedState===null&&n&&kd(o),Bc(n);continue}else if(o!==null&&o.memoizedState!==null){n&&Ab(e),Bc(n);continue}}o=e.child,(e.subtreeFlags&t)!==0&&o!==null?(o.return=e,je=o):(n&&iv(e),Bc(n))}}Mt=null}function Bc(e){for(;je!==null;){var t=je,n=e,o=t.alternate,a=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if((a&1024)!==0&&o!==null){n=void 0,a=o.memoizedProps,o=o.memoizedState;var l=t.stateNode;try{var i=ma(t.type,a);n=l.getSnapshotBeforeUpdate(i,o),l.__reactInternalSnapshotBeforeUpdate=n}catch(c){pe(t,t.return,c)}}break;case 3:if((a&1024)!==0){if(o=t.stateNode.containerInfo,n=o.nodeType,n===9)Vd(o);else if(n===1)switch(o.nodeName){case"HEAD":case"HTML":case"BODY":Vd(o);break;default:o.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&o!==null&&(n=qn(o.memoizedProps,o.stateNode),a=t.memoizedProps,a=Gn(a.default,a.update),a!=="none"&&Nl(o,n,a,o.memoizedState=[],!0));break;default:if((a&1024)!==0)throw Error(C(163))}if(o=t.sibling,o!==null){o.return=t.return,je=o;break}je=t.return}}function uv(e,t,n){var o=n.flags;switch(n.tag){case 0:case 11:case 15:pn(e,n),o&4&&Ji(5,n);break;case 1:if(pn(e,n),o&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(i){pe(n,n.return,i)}else{var a=ma(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(a,t,e.__reactInternalSnapshotBeforeUpdate)}catch(i){pe(n,n.return,i)}}o&64&&tv(n),o&512&&mn(n,n.return);break;case 3:if(pn(e,n),o&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{dg(e,t)}catch(i){pe(n,n.return,i)}}break;case 27:t===null&&o&4&&av(n);case 26:case 5:pn(e,n),t===null&&o&4&&yd(n),o&512&&mn(n,n.return);break;case 12:pn(e,n);break;case 31:pn(e,n),o&4&&pv(e,n);break;case 13:pn(e,n),o&4&&mv(e,n),o&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=wS.bind(null,n),WS(e,n))));break;case 22:if(o=n.memoizedState!==null||Ve,!o){var l=t!==null&&t.memoizedState!==null||se;t=Ve,a=se,Ve=o,(se=l)&&!a?(o=2,(n.subtreeFlags&8772)!==0&&(o|=1),It(e,n,o)):pn(e,n),Ve=t,se=a}break;case 30:pn(e,n),o&512&&mn(n,n.return);break;case 7:o&512&&mn(n,n.return);default:pn(e,n)}}function Cd(e,t){for(e=e.child;e!==null;)sv(e,t),e=e.sibling}function sv(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var o=n.style;typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"}else{var a=e.stateNode,l=e.memoizedProps.style,i=l!=null&&l.hasOwnProperty("display")?l.display:null;a.style.display=i==null||typeof i=="boolean"?"":(""+i).trim()}}catch(r){pe(e,e.return,r)}Nd(e,t);break;case 6:try{e.stateNode.nodeValue=t?"":e.memoizedProps,oe=!0}catch(r){pe(e,e.return,r)}break;case 18:try{var c=e.stateNode;t?Jb(c,!0):Jb(e.stateNode,!1)}catch(r){pe(e,e.return,r)}break;case 22:case 23:e.memoizedState===null&&Cd(e,t);break;default:Cd(e,t)}}function Nd(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){e:{var n=e,o=t;switch(n.tag){case 4:sv(n,o);break e;case 22:n.memoizedState===null&&Nd(n,o);break e;default:Nd(n,o)}}e=e.sibling}}function dv(e){var t=e.alternate;t!==null&&(e.alternate=null,dv(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&qr(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var Ee=null,bt=!1;function Ft(e,t,n){for(n=n.child;n!==null;)fv(e,t,n),n=n.sibling}function fv(e,t,n){if(Ot&&typeof Ot.onCommitFiberUnmount=="function")try{Ot.onCommitFiberUnmount(Vi,n)}catch{}switch(n.tag){case 26:se||Je(n,t),Ft(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!se&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:se||Je(n,t),wi(n);var o=Ee,a=bt;Do(n.type)&&(Ee=n.stateNode,bt=!1),Ft(e,t,n),Wv(n.stateNode,n.type,n.memoizedProps),Ee=o,bt=a;break;case 5:se||Je(n,t),wi(n);case 6:if(n.tag===6&&wi(n),o=Ee,a=bt,Ee=null,Ft(e,t,n),Ee=o,bt=a,Ee!==null)if(bt)try{(Ee.nodeType===9?Ee.body:Ee.nodeName==="HTML"?Ee.ownerDocument.body:Ee).removeChild(n.stateNode),oe=!0}catch(l){pe(n,t,l)}else try{Ee.removeChild(n.stateNode),oe=!0}catch(l){pe(n,t,l)}break;case 18:Ee!==null&&(bt?(e=Ee,Zb(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,n.stateNode),kl(e)):Zb(Ee,n.stateNode));break;case 4:o=Ee,a=bt,Ee=n.stateNode.containerInfo,bt=!0,Ft(e,t,n),Ee=o,bt=a;break;case 0:case 11:case 14:case 15:Ao(2,n,t),se||Ao(4,n,t),Ft(e,t,n);break;case 1:se||(Je(n,t),o=n.stateNode,typeof o.componentWillUnmount=="function"&&nv(n,t,o)),Ft(e,t,n);break;case 21:Ft(e,t,n);break;case 22:se=(o=se)||n.memoizedState!==null,Ft(e,t,n),se=o;break;case 30:Je(n,t),Ft(e,t,n);break;case 7:se||Je(n,t),Ft(e,t,n);break;default:Ft(e,t,n)}}function pv(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{kl(e)}catch(n){pe(t,t.return,n)}}}function mv(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{kl(e)}catch(n){pe(t,t.return,n)}}function uS(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Rb),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Rb),t;default:throw Error(C(435,e.tag))}}function Lc(e,t){var n=uS(e);t.forEach(function(o){if(!n.has(o)){n.add(o);var a=xS.bind(null,e,o);o.then(a,a)}})}function ut(e,t,n){var o=t.deletions;if(o!==null)for(var a=0;a<o.length;a++){var l=o[a],i=e,c=t,r=c;e:for(;r!==null;){switch(r.tag){case 27:if(Do(r.type)){Ee=r.stateNode,bt=!1;break e}break;case 5:Ee=r.stateNode,bt=!1;break e;case 3:case 4:Ee=r.stateNode.containerInfo,bt=!0;break e}r=r.return}if(Ee===null)throw Error(C(160));fv(i,c,l),Ee=null,bt=!1,i=l.alternate,i!==null&&(i.return=null),l.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)bv(t,e,n),t=t.sibling}var Wt=null;function bv(e,t,n){var o=e.alternate,a=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(a&4&&(o=e.updateQueue,o=o!==null?o.events:null,o!==null))for(var l=0;l<o.length;l++){var i=o[l];i.ref.impl=i.nextImpl}ut(t,e,n),st(e),a&4&&(Ao(3,e,e.return),Ji(3,e),Ao(5,e,e.return));break;case 1:ut(t,e,n),st(e),a&512&&(se||o===null||Je(o,o.return)),a&64&&Ve&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(l=Wt,ut(t,e,n),st(e),a&512&&(se||o===null||Je(o,o.return)),a&4)if(a=o!==null?o.memoizedState:null,n=e.memoizedState,o===null)if(n===null)if(e.stateNode===null)if(Ve)e.stateNode=jv(e.type,e.memoizedProps,t.containerInfo,e);else{e:{t=e.type,n=e.memoizedProps,a=l.ownerDocument||l;t:switch(t){case"title":o=a.getElementsByTagName("title")[0],(!o||o[Ki]||o[$e]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=a.createElement(t),a.head.insertBefore(o,a.querySelector("head > title"))),We(o,t,n),o[$e]=e,Xe(o),t=o;break e;case"link":if(l=nh("link","href",a).get(t+(n.href||""))){for(i=0;i<l.length;i++)if(o=l[i],o.getAttribute("href")===(n.href==null||n.href===""?null:n.href)&&o.getAttribute("rel")===(n.rel==null?null:n.rel)&&o.getAttribute("title")===(n.title==null?null:n.title)&&o.getAttribute("crossorigin")===(n.crossOrigin==null?null:n.crossOrigin)){l.splice(i,1);break t}}o=a.createElement(t),We(o,t,n),a.head.appendChild(o);break;case"meta":if(l=nh("meta","content",a).get(t+(n.content||""))){for(i=0;i<l.length;i++)if(o=l[i],o.getAttribute("content")===(n.content==null?null:""+n.content)&&o.getAttribute("name")===(n.name==null?null:n.name)&&o.getAttribute("property")===(n.property==null?null:n.property)&&o.getAttribute("http-equiv")===(n.httpEquiv==null?null:n.httpEquiv)&&o.getAttribute("charset")===(n.charSet==null?null:n.charSet)){l.splice(i,1);break t}}o=a.createElement(t),We(o,t,n),a.head.appendChild(o);break;default:throw Error(C(468,t))}o[$e]=e,Xe(o),t=o}e.stateNode=t}else Ve||Kd(l,e.type,e.stateNode);else e.stateNode=th(l,n,e.memoizedProps);else a!==n?(a===null?(t=o.stateNode,t===null||se||t.parentNode.removeChild(t)):a.count--,n===null?Ve||Kd(l,e.type,e.stateNode):th(l,n,e.memoizedProps)):n===null&&e.stateNode!==null&&Ts(e,e.memoizedProps,o.memoizedProps);break;case 27:ut(t,e,n),st(e),a&512&&(se||o===null||Je(o,o.return)),o!==null&&a&4&&Ts(e,e.memoizedProps,o.memoizedProps);break;case 5:if(l=dn,dn=!1,ut(t,e,n),dn=l,st(e),a&512&&(se||o===null||Je(o,o.return)),e.flags&32){t=e.stateNode;try{pl(t,""),oe=!0}catch(h){pe(e,e.return,h)}}a&4&&e.stateNode!=null&&(t=e.memoizedProps,Ts(e,t,o!==null?o.memoizedProps:t)),a&1024&&(Ns=!0);break;case 6:if(ut(t,e,n),st(e),a&4){if(e.stateNode===null)throw Error(C(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,oe=!0}catch(h){pe(e,e.return,h)}}break;case 3:if(oe=!1,lr=null,l=Wt,Wt=Hi(t.containerInfo),ut(t,e,n),Wt=l,st(e),a&4&&o!==null&&o.memoizedState.isDehydrated)try{kl(t.containerInfo)}catch(h){pe(e,e.return,h)}Ns&&(Ns=!1,hv(e)),oe=!1;break;case 4:a=dn,dn=Ve,o=Lm(),l=Wt,Wt=Hi(e.stateNode.containerInfo),ut(t,e,n),st(e),Wt=l,oe&&si&&(zr=!0),oe=o,dn=a;break;case 12:ut(t,e,n),st(e);break;case 31:ut(t,e,n),st(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Lc(e,t)));break;case 13:ut(t,e,n),st(e),e.child.flags&8192&&e.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(Ir=At()),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Lc(e,t)));break;case 22:l=e.memoizedState!==null,i=o!==null&&o.memoizedState!==null;var c=Ve,r=se,u=dn;Ve=c||l,dn=u||l,se=r||i,ut(t,e,n),se=r,dn=u,Ve=c,st(e),a&8192&&(t=e.stateNode,t._visibility=l?t._visibility&-2:t._visibility|1,!l||o===null||i||Ve||se||(t=i||se,n=Ve,o=se,Ve=l||Ve,se=t,io(e,2),Ve=n,se=o),!l&&dn||Cd(e,l)),a&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,Lc(e,n))));break;case 19:ut(t,e,n),st(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Lc(e,t)));break;case 30:a&512&&(se||o===null||Je(o,o.return)),a=Lm(),l=si,i=(n&335544064)===n,c=e.memoizedProps,si=i&&Gn(c.default,c.update)!=="none",ut(t,e,n),st(e),i&&o!==null&&oe&&(e.flags|=4),si=l,oe=a;break;case 21:break;case 7:a&512&&(se||o===null||Je(o,o.return)),o&&o.stateNode!==null&&(o.stateNode._fragmentFiber=e);default:ut(t,e,n),st(e)}}function st(e){var t=e.flags;if(t&2){try{for(var n,o=e.return;o!==null;){if(ov(o)){n=o;break}o=o.return}o=null;for(var a=e.return;a!==null;){if(Of(a)){var l=a.stateNode;o===null?o=[l]:o.push(l)}if(Af(a))break;a=a.return}var i=o;if(n==null)throw Error(C(160));switch(n.tag){case 27:var c=n.stateNode,r=Cs(e);Nr(e,r,c,i);break;case 5:var u=n.stateNode;n.flags&32&&(pl(u,""),n.flags&=-33);var h=Cs(e);Nr(e,h,u,i);break;case 3:case 4:var m=n.stateNode.containerInfo,p=Cs(e);wd(e,p,m,i);break;default:throw Error(C(161))}}catch(f){pe(e,e.return,f)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function hv(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;hv(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,Sl=!0,t.reset(),Sl=!1),e=e.sibling}}function qa(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)gv(t,e),t=t.sibling;else rv(t,!1)}function gv(e,t){var n=e.alternate;if(n===null)xd(e,!1);else switch(e.tag){case 3:if(Td=fn=!1,Ob(),qa(t,e),!fn&&!zr){if(e=bn,e!==null)for(var o=0;o<e.length;o+=3){n=e[o];var a=e[o+1];Kv(n,e[o+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+a+")"})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===""&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),Td=!0}bn=null;break;case 5:qa(t,e);break;case 4:o=fn,fn=!1,qa(t,e),fn&&(zr=!0),fn=o;break;case 22:e.memoizedState===null&&(n.memoizedState!==null?xd(e,!1):qa(t,e));break;case 30:o=fn,a=Ob(),fn=!1,qa(t,e),fn&&(e.flags|=4);var l=e.memoizedProps,i=e.stateNode;t=qn(l,i),i=qn(n.memoizedProps,i);var c=Gn(l.default,l.update);c==="none"?t=!1:(l=n.memoizedState,n.memoizedState=null,n=e.child,gt=0,t=Rf(e,n,t,i,c,l,!0),gt!==(l===null?0:l.length)&&(e.flags|=32)),(e.flags&4)!==0&&t?(hl(e,e.memoizedProps.onUpdate),bn=a):a!==null&&(a.push.apply(a,bn),bn=a),fn=(e.flags&32)!==0?!0:o;break;default:qa(t,e)}}function pn(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)uv(e,t.alternate,t),t=t.sibling}function io(e,t){for(e=e.child;e!==null;){var n=e,o=t;switch(n.tag){case 0:case 11:case 14:case 15:Ao(4,n,n.return),io(n,o);break;case 1:Je(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&nv(n,n.return,a),io(n,o);break;case 27:(o&2)!==0&&Wv(n.stateNode,n.type,n.memoizedProps);case 5:Je(n,n.return),n.tag!==5&&n.tag!==27||wi(n),io(n,o);break;case 6:wi(n);break;case 26:Je(n,n.return),a=n.stateNode,n.memoizedState!==null||a===null||se||a.parentNode.removeChild(a),io(n,o);break;case 22:n.memoizedState===null&&io(n,o);break;case 30:Je(n,n.return),io(n,o);break;case 7:Je(n,n.return);default:io(n,o)}e=e.sibling}}function It(e,t,n){for(n=(t.subtreeFlags&8772)!==0?n:n&-2,t=t.child;t!==null;){var o=t.alternate,a=e,l=t,i=l.flags,c=(n&1)!==0;switch(l.tag){case 0:case 11:case 15:It(a,l,n),Ji(4,l);break;case 1:if(It(a,l,n),o=l,a=o.stateNode,typeof a.componentDidMount=="function")try{a.componentDidMount()}catch(h){pe(o,o.return,h)}if(o=l,a=o.updateQueue,a!==null){var r=o.stateNode;try{var u=a.shared.hiddenCallbacks;if(u!==null)for(a.shared.hiddenCallbacks=null,a=0;a<u.length;a++)sg(u[a],r)}catch(h){pe(o,o.return,h)}}c&&i&64&&tv(l),mn(l,l.return);break;case 27:(n&2)!==0&&av(l);case 5:l.tag!==5&&l.tag!==27||zb(l),It(a,l,n),c&&o===null&&i&4&&yd(l),mn(l,l.return);break;case 6:zb(l);break;case 26:r=l.stateNode,l.memoizedState!==null||r===null||Ve||Kd(Hi(r.ownerDocument),l.type,r),It(a,l,n),c&&o===null&&i&4&&yd(l),mn(l,l.return);break;case 12:It(a,l,n);break;case 31:It(a,l,n),c&&i&4&&pv(a,l);break;case 13:It(a,l,n),c&&i&4&&mv(a,l);break;case 22:l.memoizedState===null&&It(a,l,n),mn(l,l.return);break;case 30:It(a,l,n),mn(l,l.return);break;case 7:mn(l,l.return);default:It(a,l,n)}t=t.sibling}}function Df(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&Qi(n))}function _f(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Qi(e))}function qt(e,t,n,o){var a=(n&335544064)===n;if(t.subtreeFlags&(a?10262:10256))for(t=t.child;t!==null;)vv(e,t,n,o),t=t.sibling;else a&&cv(t)}function vv(e,t,n,o){var a=(n&335544064)===n;a&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&tr(t);var l=t.flags;switch(t.tag){case 0:case 11:case 15:qt(e,t,n,o),l&2048&&Ji(9,t);break;case 1:qt(e,t,n,o);break;case 3:qt(e,t,n,o),a&&Td&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,e.style.viewTransitionName==="root"&&(e.style.viewTransitionName=""),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName==="none"&&(e.style.viewTransitionName="")),l&2048&&(l=null,t.alternate!==null&&(l=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==l&&(t.refCount++,l!=null&&Qi(l)));break;case 12:if(l&2048){qt(e,t,n,o),l=t.stateNode;try{var i=t.memoizedProps,c=i.id,r=i.onPostCommit;typeof r=="function"&&r(c,t.alternate===null?"mount":"update",l.passiveEffectDuration,-0)}catch(u){pe(t,t.return,u)}}else qt(e,t,n,o);break;case 31:qt(e,t,n,o);break;case 13:qt(e,t,n,o);break;case 23:break;case 22:i=t.stateNode,c=t.alternate,t.memoizedState!==null?(a&&c!==null&&c.memoizedState===null&&tr(c),i._visibility&2?qt(e,t,n,o):xi(e,t)):(a&&c!==null&&c.memoizedState!==null&&tr(t),i._visibility&2?qt(e,t,n,o):(i._visibility|=2,Va(e,t,n,o,(t.subtreeFlags&10256)!==0||!1))),l&2048&&Df(c,t);break;case 24:qt(e,t,n,o),l&2048&&_f(t.alternate,t);break;case 30:a&&(l=t.alternate,l!==null&&(Sn(l.child,!0),Sn(t.child,!0))),qt(e,t,n,o);break;default:qt(e,t,n,o)}}function Va(e,t,n,o,a){for(a=a&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var l=e,i=t,c=n,r=o,u=i.flags;switch(i.tag){case 0:case 11:case 15:Va(l,i,c,r,a),Ji(8,i);break;case 23:break;case 22:var h=i.stateNode;i.memoizedState!==null?h._visibility&2?Va(l,i,c,r,a):xi(l,i):(h._visibility|=2,Va(l,i,c,r,a)),a&&u&2048&&Df(i.alternate,i);break;case 24:Va(l,i,c,r,a),a&&u&2048&&_f(i.alternate,i);break;default:Va(l,i,c,r,a)}t=t.sibling}}function xi(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,o=t,a=o.flags;switch(o.tag){case 22:xi(n,o),a&2048&&Df(o.alternate,o);break;case 24:xi(n,o),a&2048&&_f(o.alternate,o);break;default:xi(n,o)}t=t.sibling}}var ea=8192;function Fo(e,t,n){if(e.subtreeFlags&ea)for(e=e.child;e!==null;)yv(e,t,n),e=e.sibling}function yv(e,t,n){switch(e.tag){case 26:Fo(e,t,n),e.flags&ea&&(e.memoizedState!==null?pk(n,Wt,e.memoizedState,e.memoizedProps):(e=e.stateNode,(t&335544128)===t&&ah(n,e)));break;case 5:Fo(e,t,n),e.flags&ea&&(e=e.stateNode,(t&335544128)===t&&ah(n,e));break;case 3:case 4:var o=Wt;Wt=Hi(e.stateNode.containerInfo),Fo(e,t,n),Wt=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=ea,ea=16777216,Fo(e,t,n),ea=o):Fo(e,t,n));break;case 30:if((e.flags&ea)!==0&&(o=e.memoizedProps.name,o!=null&&o!=="auto")){var a=e.stateNode;a.paired=null,Mt===null&&(Mt=new Map),Mt.set(o,a)}Fo(e,t,n);break;default:Fo(e,t,n)}}function wv(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function oi(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];je=o,Sv(o,e)}wv(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)xv(e),e=e.sibling}function xv(e){switch(e.tag){case 0:case 11:case 15:oi(e),e.flags&2048&&Ao(9,e,e.return);break;case 3:oi(e);break;case 12:oi(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,nr(e)):oi(e);break;default:oi(e)}}function nr(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];je=o,Sv(o,e)}wv(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Ao(8,t,t.return),nr(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,nr(t));break;default:nr(t)}e=e.sibling}}function Sv(e,t){for(;je!==null;){var n=je;switch(n.tag){case 0:case 11:case 15:Ao(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var o=n.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:Qi(n.memoizedState.cache)}if(o=n.child,o!==null)o.return=n,je=o;else e:for(n=e;je!==null;){o=je;var a=o.sibling,l=o.return;if(dv(o),o===n){je=null;break e}if(a!==null){a.return=l,je=a;break e}je=l}}}var sS={getCacheForType:function(e){var t=Pe(_e),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return Pe(_e).controller.signal}},dS=typeof WeakMap=="function"?WeakMap:Map,le=0,be=null,F=null,I=0,de=0,Tt=null,mo=!1,Ml=!1,Uf=!1,Xn=0,Ae=0,Oo=0,ca=0,Ar=0,zt=0,bl=0,Si=null,ht=null,Md=!1,Ir=0,kv=0,Or=1/0,Rr=null,ko=null,Ce=0,tn=null,ba=null,xn=0,zd=0,Ad=null,Ev=null,rl=null,ul=null,sl=null,ki=0,or=null;function Dt(){return(le&2)!==0&&I!==0?I&-I:Y.T!==null?Bf():Mh()}function Tv(){if(zt===0)if((I&536870912)===0||J){var e=Tc;Tc<<=1,(Tc&3932160)===0&&(Tc=262144),zt=e}else zt=536870912;return e=et.current,e!==null&&(e.flags|=32),zt}function hl(e,t){if(t!=null){var n=e.stateNode,o=n.ref;o===null&&(o=n.ref=Qv(qn(e.memoizedProps,n))),ul===null&&(ul=[]),ul.push(t.bind(null,o))}}function yt(e,t,n){(e===be&&(de===2||de===9)||e.cancelPendingCommit!==null)&&(gl(e,0),bo(e,I,zt,!1)),Xi(e,n),((le&2)===0||e!==be)&&(e===be&&((le&2)===0&&(ca|=n),Ae===4&&bo(e,I,zt,!1)),En(e))}function Cv(e,t,n){if((le&6)!==0)throw Error(C(327));var o=!n&&(t&127)===0&&(t&e.expiredLanes)===0||ji(e,t),a=o?mS(e,t):Ms(e,t,!0),l=o;do{if(a===0){Ml&&!o&&bo(e,t,0,!1);break}else{if(n=e.current.alternate,l&&!fS(n)){a=Ms(e,t,!1),l=!1;continue}if(a===2){if(l=t,e.errorRecoveryDisabledLanes&l)var i=0;else i=e.pendingLanes&-536870913,i=i!==0?i:i&536870912?536870912:0;if(i!==0){t=i;e:{var c=e;a=Si;var r=c.current.memoizedState.isDehydrated;if(r&&(gl(c,i).flags|=256),i=Ms(c,i,!1),i!==2&&i!==6){if(Uf&&!r){c.errorRecoveryDisabledLanes|=l,ca|=l,a=4;break e}l=ht,ht=a,l!==null&&(ht===null?ht=l:ht.push.apply(ht,l))}a=i}if(l=!1,a!==2)continue}}if(a===1){gl(e,0),bo(e,t,0,!0);break}e:{switch(o=e,l=a,l){case 0:case 1:throw Error(C(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:bo(o,t,zt,!mo);break e;case 2:ht=null;break;case 3:case 5:break;default:throw Error(C(329))}if((t&62914560)===t&&(a=Ir+300-At(),10<a)){if(bo(o,t,zt,!mo),Lr(o,0,!0)!==0)break e;xn=t,o.timeoutHandle=qf(Db.bind(null,o,n,ht,Rr,Md,t,zt,ca,bl,mo,l,"Throttled",-0,0),a);break e}Db(o,n,ht,Rr,Md,t,zt,ca,bl,mo,l,null,-0,0)}}break}while(!0);En(e)}function Db(e,t,n,o,a,l,i,c,r,u,h,m,p,f){e.timeoutHandle=-1;var x=t.subtreeFlags,k=(l&335544064)===l;if(m=null,(k||x&8192||(x&16785408)===16785408)&&(m={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:gn},Mt=null,yv(t,l,m),k&&(x=m,k=e.containerInfo,k=(k.nodeType===9?k:k.ownerDocument).__reactViewTransition,k!=null&&(x.count++,x.waitingForViewTransition=!0,x=Bi.bind(x),k.finished.then(x,x))),x=(l&62914560)===l?Ir-At():(l&4194048)===l?kv-At():0,x=mk(m,x),x!==null)){xn=l,e.cancelPendingCommit=x(Ub.bind(null,e,t,l,n,o,a,i,c,r,u,h,m,null,p,f)),bo(e,l,i,!u);return}Ub(e,t,l,n,o,a,i,c,r,u,h,m)}function fS(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var o=0;o<n.length;o++){var a=n[o],l=a.getSnapshot;a=a.value;try{if(!_t(l(),a))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function bo(e,t,n,o){t=kh(e,t),t&=~Ar,t&=~ca,e.suspendedLanes|=t,e.pingedLanes&=~t,o&&(e.warmLanes|=t),o=e.expirationTimes;for(var a=t;0<a;){var l=31-Rt(a),i=1<<l;o[l]=-1,a&=~i}n!==0&&Th(e,n,t)}function Wr(){return(le&6)===0?($i(0,!1),!1):!0}function Hf(){if(F!==null){if(de===0)var e=F.return;else e=F,Un=wa=null,yf(e),ll=null,Ai=0,e=F;for(;e!==null;)ev(e.alternate,e),e=e.return;F=null}}function gl(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,_S(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),xn=0,Hf(),be=e,F=n=Hn(e.current,null),I=t,de=0,Tt=null,mo=!1,Ml=ji(e,t),Uf=!1,bl=zt=Ar=ca=Oo=Ae=0,ht=Si=null,Md=!1,Xn=kh(e,t),Xr(),n}function Nv(e,t){Q=null,Y.H=Er,t===Cl||t===Qr?(t=ib(),de=3):t===df?(t=ib(),de=4):de=t===Nf?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,Tt=t,F===null&&(Ae=1,Tr(e,Kt(t,e.current)))}function Mv(){var e=et.current;return e===null?!0:(I&4194048)===I?it===null:(I&62914560)===I||(I&536870912)!==0?e===it:!1}function zv(){var e=Y.H;return Y.H=Er,e===null?Er:e}function Av(){var e=Y.A;return Y.A=sS,e}function Dr(){Ae=4,mo||(I&4194048)!==I&&et.current!==null||(Ml=!0),(Oo&134217727)===0&&(ca&134217727)===0||be===null||bo(be,I,zt,!1)}function Ms(e,t,n){var o=le;le|=2;var a=zv(),l=Av();(be!==e||I!==t)&&(Rr=null,gl(e,t)),t=!1;var i=Ae;e:do try{if(de!==0&&F!==null){var c=F,r=Tt;switch(de){case 8:Hf(),i=6;break e;case 3:case 2:case 9:case 6:et.current===null&&(t=!0);var u=de;if(de=0,Tt=null,el(e,c,r,u),n&&Ml){i=0;break e}break;default:u=de,de=0,Tt=null,el(e,c,r,u)}}pS(),i=Ae;break}catch(h){Nv(e,h)}while(!0);return t&&e.shellSuspendCounter++,Un=wa=null,le=o,Y.H=a,Y.A=l,F===null&&(be=null,I=0,Xr()),i}function pS(){for(;F!==null;)Ov(F)}function mS(e,t){var n=le;le|=2;var o=zv(),a=Av();be!==e||I!==t?(Rr=null,Or=At()+500,gl(e,t)):Ml=ji(e,t);e:do try{if(de!==0&&F!==null){t=F;var l=Tt;t:switch(de){case 1:de=0,Tt=null,el(e,t,l,1);break;case 2:case 9:if(lb(l)){de=0,Tt=null,_b(t);break}t=function(){de!==2&&de!==9||be!==e||(de=7),En(e)},l.then(t,t);break e;case 3:de=7;break e;case 4:de=5;break e;case 7:lb(l)?(de=0,Tt=null,_b(t)):(de=0,Tt=null,el(e,t,l,7));break;case 5:var i=null;switch(F.tag){case 26:i=F.memoizedState;case 5:case 27:var c=F;if(i?n0(i):c.stateNode.complete){de=0,Tt=null;var r=c.sibling;if(r!==null)F=r;else{var u=c.return;u!==null?(F=u,eu(u)):F=null}break t}}de=0,Tt=null,el(e,t,l,5);break;case 6:de=0,Tt=null,el(e,t,l,6);break;case 8:Hf(),Ae=6;break e;default:throw Error(C(462))}}bS();break}catch(h){Nv(e,h)}while(!0);return Un=wa=null,Y.H=o,Y.A=a,le=n,F!==null?0:(be=null,I=0,Xr(),Ae)}function bS(){for(;F!==null&&!Rw();)Ov(F)}function Ov(e){var t=Wg(e.alternate,e,Xn);e.memoizedProps=e.pendingProps,t===null?eu(e):F=t}function _b(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Sb(n,t,t.pendingProps,t.type,void 0,I);break;case 11:t=Sb(n,t,t.pendingProps,t.type.render,t.ref,I);break;case 5:yf(t);var o=t;o===Ke&&(J?(gr(o),o.tag===5&&o.stateNode!=null&&(we=o.stateNode)):(gr(o),J=!0));default:ev(n,t),t=F=tg(t,Xn),t=Wg(n,t,Xn)}e.memoizedProps=e.pendingProps,t===null?eu(e):F=t}function el(e,t,n,o){Un=wa=null,yf(t),ll=null,Ai=0;var a=t.return;try{if(nS(e,a,t,n,I)){Ae=1,Tr(e,Kt(n,e.current)),F=null;return}}catch(l){if(a!==null)throw F=a,l;Ae=1,Tr(e,Kt(n,e.current)),F=null;return}t.flags&32768?(J||o===1?e=!0:Ml||(I&536870912)!==0?e=!1:(mo=e=!0,(o===2||o===9||o===3||o===6)&&(o=et.current,o!==null&&o.tag===13&&(o.flags|=16384))),Rv(t,e)):eu(t)}function eu(e){var t=e;do{if((t.flags&32768)!==0){Rv(t,mo);return}e=t.return;var n=iS(t.alternate,t,Xn);if(n!==null){F=n;return}if(t=t.sibling,t!==null){F=t;return}F=t=e}while(t!==null);Ae===0&&(Ae=5)}function Rv(e,t){do{var n=cS(e.alternate,e);if(n!==null){n.flags&=32767,F=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){F=e;return}F=e=n}while(e!==null);Ae=6,F=null}function Ub(e,t,n,o,a,l,i,c,r,u,h,m){e.cancelPendingCommit=null;do tu();while(Ce!==0);if((le&6)!==0)throw Error(C(327));if(t!==null){if(t===e.current)throw Error(C(177));e===be&&(F=be=null,I=0),ba=t,tn=e,xn=n,Ad=a,Ev=o,hS(e,t,n,i,c,r,m)}}function hS(e,t,n,o,a,l,i){var c=t.lanes|t.childLanes;if(zd=c,c|=af,jw(e,n,c,o,a,l),ul=null,(n&335544064)===n?(sl=Kx(e),o=10262):(sl=null,o=10256),(t.subtreeFlags&o)!==0||(t.flags&o)!==0?(e.callbackNode=null,e.callbackPriority=0,SS(fr,function(){return _d(),null})):(e.callbackNode=null,e.callbackPriority=0),Mr=!1,o=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||o){o=Y.T,Y.T=null,a=ie.p,ie.p=2,l=le,le|=4;try{rS(e,t,n)}finally{le=l,ie.p=a,Y.T=o}}Ce=1,Mr?rl=YS(i,e.containerInfo,sl,Od,Rd,vS,Dd,_d,gS,null,null):(Od(),Rd(),Dd())}function gS(e){if(Ce!==0){var t=tn.onRecoverableError;t(e,{componentStack:null})}}function vS(){Ce===3&&(Ce=0,gv(ba,tn),Ce=4)}function Od(){if(Ce===1){Ce=0;var e=tn,t=ba,n=xn,o=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||o){o=Y.T,Y.T=null;var a=ie.p;ie.p=2;var l=le;le|=4;try{si=zr=!1,bv(t,e,n),n=Ld;var i=Zh(e.containerInfo),c=n.focusedElem,r=n.selectionRange;if(i!==c&&c&&c.ownerDocument&&Qh(c.ownerDocument.documentElement,c)){if(r!==null&&of(c)){var u=r.start,h=r.end;if(h===void 0&&(h=u),"selectionStart"in c)c.selectionStart=u,c.selectionEnd=Math.min(h,c.value.length);else{var m=c.ownerDocument||document,p=m&&m.defaultView||window;if(p.getSelection){var f=p.getSelection(),x=c.textContent.length,k=Math.min(r.start,x),E=r.end===void 0?k:Math.min(r.end,x);!f.extend&&k>E&&(i=E,E=k,k=i);var b=Fm(c,k),s=Fm(c,E);if(b&&s&&(f.rangeCount!==1||f.anchorNode!==b.node||f.anchorOffset!==b.offset||f.focusNode!==s.node||f.focusOffset!==s.offset)){var d=m.createRange();d.setStart(b.node,b.offset),f.removeAllRanges(),k>E?(f.addRange(d),f.extend(s.node,s.offset)):(d.setEnd(s.node,s.offset),f.addRange(d))}}}}for(m=[],f=c;f=f.parentNode;)f.nodeType===1&&m.push({element:f,left:f.scrollLeft,top:f.scrollTop});for(typeof c.focus=="function"&&c.focus(),c=0;c<m.length;c++){var v=m[c];v.element.scrollLeft=v.left,v.element.scrollTop=v.top}}Sl=!!Bd,Ld=Bd=null}finally{le=l,ie.p=a,Y.T=o}}e.current=t,Ce=2}}function Rd(){if(Ce===2){Ce=0;var e=tn,t=ba,n=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||n){n=Y.T,Y.T=null;var o=ie.p;ie.p=2;var a=le;le|=4;try{uv(e,t.alternate,t)}finally{le=a,ie.p=o,Y.T=n}}Ce=3}}function Dd(){if(Ce===4||Ce===3){Ce=0;var e=rl;rl=null,Dw();var t=tn,n=ba,o=xn,a=Ev,l=(o&335544064)===o?10262:10256;if((n.subtreeFlags&l)!==0||(n.flags&l)!==0?Ce=5:(Ce=0,ba=tn=null,Dv(t,t.pendingLanes)),l=t.pendingLanes,l===0&&(ko=null),Fd(o),n=n.stateNode,Ot&&typeof Ot.onCommitFiberRoot=="function")try{Ot.onCommitFiberRoot(Vi,n,void 0,(n.current.flags&128)===128)}catch{}if(a!==null){n=Y.T,l=ie.p,ie.p=2,Y.T=null;try{for(var i=t.onRecoverableError,c=0;c<a.length;c++){var r=a[c];i(r.value,{componentStack:r.stack})}}finally{Y.T=n,ie.p=l}}if(a=ul,i=sl,sl=null,a!==null&&(ul=null,i===null&&(i=[]),e!==null))for(r=0;r<a.length;r++)n=(0,a[r])(i),n!==void 0&&e.finished.finally(n);(xn&3)!==0&&tu(),En(t),l=t.pendingLanes,(o&261930)!==0&&(l&42)!==0?t===or?ki++:(ki=0,or=t):(ki=0,or=null),$i(0,!1)}}function Dv(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Qi(t)))}function tu(){return rl!==null&&(rl.skipTransition(),rl=null),Od(),Rd(),Dd(),_d()}function _d(){if(Ce!==5)return!1;var e=tn,t=zd;zd=0;var n=Fd(xn),o=Y.T,a=ie.p;try{ie.p=32>n?32:n,Y.T=null,n=Ad,Ad=null;var l=tn,i=xn;if(Ce=0,ba=tn=null,xn=0,(le&6)!==0)throw Error(C(331));var c=le;if(le|=4,xv(l.current),vv(l,l.current,i,n),le=c,$i(0,!1),Ot&&typeof Ot.onPostCommitFiberRoot=="function")try{Ot.onPostCommitFiberRoot(Vi,l)}catch{}return!0}finally{ie.p=a,Y.T=o,Dv(e,t)}}function Hb(e,t,n){t=Kt(n,t),t=pd(e.stateNode,t,2),e=wo(e,t,2),e!==null&&(Xi(e,2),En(e))}function pe(e,t,n){if(e.tag===3)Hb(e,e,n);else for(;t!==null;){if(t.tag===3){Hb(t,e,n);break}else if(t.tag===1){var o=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(ko===null||!ko.has(o))){e=Kt(n,e),n=Jg(2),o=wo(t,n,2),o!==null&&($g(n,o,t,e),Xi(o,2),En(o));break}}t=t.return}}function zs(e,t,n){var o=e.pingCache;if(o===null){o=e.pingCache=new dS;var a=new Set;o.set(t,a)}else a=o.get(t),a===void 0&&(a=new Set,o.set(t,a));a.has(n)||(Uf=!0,a.add(n),e=yS.bind(null,e,t,n),t.then(e,e))}function yS(e,t,n){var o=e.pingCache;o!==null&&o.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,be===e&&(I&n)===n&&((Ae===4||Ae===3&&(I&62914560)===I&&300>At()-Ir)&&(le&2)===0?gl(e,0):Ar|=n,bl===I&&(bl=0)),En(e)}function _v(e,t){t===0&&(t=Eh()),e=ya(e,t),e!==null&&(Xi(e,t),En(e))}function wS(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),_v(e,n)}function xS(e,t){var n=0;switch(e.tag){case 31:case 13:var o=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(C(314))}o!==null&&o.delete(t),_v(e,n)}function SS(e,t){return $d(e,t)}var vl=null,ja=null,Ud=!1,_r=!1,As=!1,ho=0;function En(e){e!==ja&&e.next===null&&(ja===null?vl=ja=e:ja=ja.next=e),_r=!0,Ud||(Ud=!0,ES())}function $i(e,t){if(!As&&_r){As=!0;do for(var n=!1,o=vl;o!==null;){if(!t)if(e!==0){var a=o.pendingLanes;if(a===0)var l=0;else{var i=o.suspendedLanes,c=o.pingedLanes;l=(1<<31-Rt(42|e)+1)-1,l&=a&~(i&~c),l=l&201326741?l&201326741|1:l?l|2:0}l!==0&&(n=!0,Bb(o,l))}else l=I,l=Lr(o,o===be?l:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(l&3)===0||ji(o,l)||(n=!0,Bb(o,l));o=o.next}while(n);As=!1}}function kS(){Uv()}function Uv(){_r=Ud=!1;var e=0;ho!==0&&DS()&&(e=ho);for(var t=At(),n=null,o=vl;o!==null;){var a=o.next,l=Hv(o,t);l===0?(o.next=null,n===null?vl=a:n.next=a,a===null&&(ja=n)):(n=o,(e!==0||(l&3)!==0)&&(_r=!0)),o=a}Ce!==0&&Ce!==5||$i(e,!1),ho!==0&&(ho=0)}function Hv(e,t){for(var n=e.suspendedLanes,o=e.pingedLanes,a=e.expirationTimes,l=e.pendingLanes&-62914561;0<l;){var i=31-Rt(l),c=1<<i,r=a[i];r===-1?((c&n)===0||(c&o)!==0)&&(a[i]=Vw(c,t)):r<=t&&(e.expiredLanes|=c),l&=~c}if(t=be,n=I,n=Lr(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,n===0||e===t&&(de===2||de===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&rs(o),e.callbackNode=null,e.callbackPriority=0;if((n&3)===0||ji(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(o!==null&&rs(o),Fd(n)){case 2:case 8:n=xh;break;case 32:n=fr;break;case 268435456:n=Sh;break;default:n=fr}return o=Bv.bind(null,e),n=$d(n,o),e.callbackPriority=t,e.callbackNode=n,t}return o!==null&&o!==null&&rs(o),e.callbackPriority=2,e.callbackNode=null,2}function Bv(e,t){if(Ce!==0&&Ce!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(tu()&&e.callbackNode!==n)return null;var o=I;return o=Lr(e,e===be?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(Cv(e,o,t),Hv(e,At()),e.callbackNode!=null&&e.callbackNode===n?Bv.bind(null,e):null)}function Bb(e,t){if(tu())return null;Cv(e,t,!0)}function ES(){US(function(){(le&6)!==0?$d(wh,kS):Uv()})}function Bf(){if(ho===0){var e=da;e===0&&(e=Ec,Ec<<=1,(Ec&261888)===0&&(Ec=256)),ho=e}return ho}function Lb(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:Gc(e)}function TS(e,t,n,o,a){if(t==="submit"&&n&&n.stateNode===a){var l=Lb((a[xt]||null).action),i=o.submitter;i&&(t=(t=i[xt]||null)?Lb(t.formAction):i.getAttribute("formAction"),t!==null&&(l=t,i=null));var c=new Yr("action","action",null,o,a);e.push({event:c,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(ho!==0){var r=new FormData(a,i);dd(n,{pending:!0,data:r,method:a.method,action:l},null,r)}}else typeof l=="function"&&(c.preventDefault(),r=new FormData(a,i),dd(n,{pending:!0,data:r,method:a.method,action:l},l,r))},currentTarget:a}]})}}for(qc=0;qc<ed.length;qc++)Yc=ed[qc],qb=Yc.toLowerCase(),Yb=Yc[0].toUpperCase()+Yc.slice(1),nn(qb,"on"+Yb);var Yc,qb,Yb,qc;nn($h,"onAnimationEnd");nn(Ph,"onAnimationIteration");nn(Fh,"onAnimationStart");nn("dblclick","onDoubleClick");nn("focusin","onFocus");nn("focusout","onBlur");nn(Hx,"onTransitionRun");nn(Bx,"onTransitionStart");nn(Lx,"onTransitionCancel");nn(Ih,"onTransitionEnd");fl("onMouseEnter",["mouseout","mouseover"]);fl("onMouseLeave",["mouseout","mouseover"]);fl("onPointerEnter",["pointerout","pointerover"]);fl("onPointerLeave",["pointerout","pointerover"]);ga("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));ga("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));ga("onBeforeInput",["compositionend","keypress","textInput","paste"]);ga("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));ga("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));ga("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Di="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),CS=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Di));function Lv(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var o=e[n],a=o.event;o=o.listeners;e:{var l=void 0;if(t)for(var i=o.length-1;0<=i;i--){var c=o[i],r=c.instance,u=c.currentTarget;if(c=c.listener,r!==l&&a.isPropagationStopped())break e;l=c,a.currentTarget=u;try{l(a)}catch(h){mr(h)}a.currentTarget=null,l=r}else for(i=0;i<o.length;i++){if(c=o[i],r=c.instance,u=c.currentTarget,c=c.listener,r!==l&&a.isPropagationStopped())break e;l=c,a.currentTarget=u;try{l(a)}catch(h){mr(h)}a.currentTarget=null,l=r}}}}function P(e,t){var n=t[_m];n===void 0&&(n=t[_m]=new Set);var o=e+"__bubble";n.has(o)||(qv(t,e,2,!1),n.add(o))}function Os(e,t,n){var o=0;t&&(o|=4),qv(n,e,o,t)}var Vc="_reactListening"+Math.random().toString(36).slice(2);function Lf(e){if(!e[Vc]){e[Vc]=!0,Ah.forEach(function(n){n!=="selectionchange"&&(CS.has(n)||Os(n,!1,e),Os(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Vc]||(t[Vc]=!0,Os("selectionchange",!1,t))}}function qv(e,t,n,o){switch(u0(t)){case 2:var a=vk;break;case 8:a=yk;break;default:a=Gf}n=a.bind(null,t,n,e),a=void 0,!Ps||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(a=!0),o?a!==void 0?e.addEventListener(t,n,{capture:!0,passive:a}):e.addEventListener(t,n,!0):a!==void 0?e.addEventListener(t,n,{passive:a}):e.addEventListener(t,n,!1)}function Rs(e,t,n,o,a){var l=o;if((t&1)===0&&(t&2)===0&&o!==null)e:for(;;){if(o===null)return;var i=o.tag;if(i===3||i===4){var c=o.stateNode.containerInfo;if(c===a)break;if(i===4)for(i=o.return;i!==null;){var r=i.tag;if((r===3||r===4)&&i.stateNode.containerInfo===a)return;i=i.return}for(;c!==null;){if(i=ta(c),i===null)return;if(r=i.tag,r===5||r===6||r===26||r===27){o=l=i;continue e}c=c.parentNode}}o=o.return}Lh(function(){var u=l,h=Wd(n),m=[];e:{var p=Wh.get(e);if(p!==void 0){var f=Yr,x=e;switch(e){case"keypress":if(Zc(n)===0)break e;case"keydown":case"keyup":f=fx;break;case"focusin":x="focus",f=ms;break;case"focusout":x="blur",f=ms;break;case"beforeblur":case"afterblur":f=ms;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":f=jm;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":f=ex;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":f=gx;break;case $h:case Ph:case Fh:f=ox;break;case Ih:f=yx;break;case"scroll":case"scrollend":f=Iw;break;case"wheel":f=xx;break;case"copy":case"cut":case"paste":f=lx;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":f=Km;break;case"submit":f=bx;break;case"toggle":case"beforetoggle":f=kx}var k=(t&4)!==0,E=!k&&(e==="scroll"||e==="scrollend"),b=k?p!==null?p+"Capture":null:p;k=[];for(var s=u,d;s!==null;){var v=s;if(d=v.stateNode,v=v.tag,v!==5&&v!==26&&v!==27||d===null||b===null||(v=Ti(s,b),v!=null&&k.push(_i(s,v,d))),E)break;s=s.return}0<k.length&&(p=new f(p,x,null,n,h),m.push({event:p,listeners:k}))}}if((t&7)===0){e:{if(f=e==="mouseover"||e==="pointerover",p=e==="mouseout"||e==="pointerout",f&&n!==$s&&(x=n.relatedTarget||n.fromElement)&&(ta(x)||x[El]))break e;(p||f)&&(x=h.window===h?h:(f=h.ownerDocument)?f.defaultView||f.parentWindow:window,p?(f=n.relatedTarget||n.toElement,p=u,f=f?ta(f):null,f!==null&&(E=Yi(f),k=f.tag,f!==E||k!==5&&k!==27&&k!==6)&&(f=null)):(p=null,f=u),p!==f&&(k=jm,v="onMouseLeave",b="onMouseEnter",s="mouse",(e==="pointerout"||e==="pointerover")&&(k=Km,v="onPointerLeave",b="onPointerEnter",s="pointer"),E=p==null?x:ri(p),d=f==null?x:ri(f),x=new k(v,s+"leave",p,n,h),x.target=E,x.relatedTarget=d,v=null,ta(h)===u&&(k=new k(b,s+"enter",f,n,h),k.target=d,k.relatedTarget=E,v=k),E=v,k=p&&f?Bs(p,f,NS):null,p!==null&&Vb(m,x,p,k,!1),f!==null&&E!==null&&Vb(m,E,f,k,!0)))}e:{if(p=u?ri(u):window,f=p.nodeName&&p.nodeName.toLowerCase(),f==="select"||f==="input"&&p.type==="file")var y=Jm;else if(Zm(p))if(Kh)y=Dx;else{y=Ox;var T=Ax}else f=p.nodeName,!f||f.toLowerCase()!=="input"||p.type!=="checkbox"&&p.type!=="radio"?u&&Id(u.elementType)&&(y=Jm):y=Rx;if(y&&(y=y(e,u))){Xh(m,y,n,h);break e}T&&T(e,p,u)}switch(T=u?ri(u):window,e){case"focusin":(Zm(T)||T.contentEditable==="true")&&(Ja=T,Is=u,pi=null);break;case"focusout":pi=Is=Ja=null;break;case"mousedown":Ws=!0;break;case"contextmenu":case"mouseup":case"dragend":Ws=!1,Im(m,n,h);break;case"selectionchange":if(Ux)break;case"keydown":case"keyup":Im(m,n,h)}var w;if(nf)e:{switch(e){case"compositionstart":var M="onCompositionStart";break e;case"compositionend":M="onCompositionEnd";break e;case"compositionupdate":M="onCompositionUpdate";break e}M=void 0}else Za?Vh(e,n)&&(M="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(M="onCompositionStart");M&&(Yh&&n.locale!=="ko"&&(Za||M!=="onCompositionStart"?M==="onCompositionEnd"&&Za&&(w=qh()):(fo=h,ef="value"in fo?fo.value:fo.textContent,Za=!0)),T=Ur(u,M),0<T.length&&(M=new Xm(M,e,null,n,h),m.push({event:M,listeners:T}),w?M.data=w:(w=jh(n),w!==null&&(M.data=w)))),(w=Tx?Cx(e,n):Nx(e,n))&&(M=Ur(u,"onBeforeInput"),0<M.length&&(T=new Xm("onBeforeInput","beforeinput",null,n,h),m.push({event:T,listeners:M}),T.data=w)),TS(m,e,u,n,h)}Lv(m,t)})}function _i(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Ur(e,t){for(var n=t+"Capture",o=[];e!==null;){var a=e,l=a.stateNode;if(a=a.tag,a!==5&&a!==26&&a!==27||l===null||(a=Ti(e,n),a!=null&&o.unshift(_i(e,a,l)),a=Ti(e,t),a!=null&&o.push(_i(e,a,l))),e.tag===3)return o;e=e.return}return[]}function NS(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Vb(e,t,n,o,a){for(var l=t._reactName,i=[];n!==null&&n!==o;){var c=n,r=c.alternate,u=c.stateNode;if(c=c.tag,r!==null&&r===o)break;c!==5&&c!==26&&c!==27||u===null||(r=u,a?(u=Ti(n,l),u!=null&&i.unshift(_i(n,u,r))):a||(u=Ti(n,l),u!=null&&i.push(_i(n,u,r)))),n=n.return}i.length!==0&&e.push({event:t,listeners:i})}var MS=/\r\n?/g,zS=/\u0000|\uFFFD/g;function jb(e){return(typeof e=="string"?e:""+e).replace(MS,`
`).replace(zS,"")}function Yv(e,t){return t=jb(t),jb(e)===t}function fe(e,t,n,o,a,l){switch(n){case"children":if(typeof o=="string")t==="body"||t==="textarea"&&o===""||pl(e,o);else if(typeof o=="number"||typeof o=="bigint")t!=="body"&&pl(e,""+o);else return;break;case"className":Nc(e,"class",o);break;case"tabIndex":Nc(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":Nc(e,n,o);break;case"style":Bh(e,o,l);return;case"data":if(t!=="object"){Nc(e,"data",o);break}case"src":case"href":if(o===""&&(t!=="a"||n!=="href")){e.removeAttribute(n);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=Gc(o),e.setAttribute(n,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof l=="function"&&(n==="formAction"?(t!=="input"&&fe(e,t,"name",a.name,a,null),fe(e,t,"formEncType",a.formEncType,a,null),fe(e,t,"formMethod",a.formMethod,a,null),fe(e,t,"formTarget",a.formTarget,a,null)):(fe(e,t,"encType",a.encType,a,null),fe(e,t,"method",a.method,a,null),fe(e,t,"target",a.target,a,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=Gc(o),e.setAttribute(n,o);break;case"onClick":o!=null&&(e.onclick=gn);return;case"onScroll":o!=null&&P("scroll",e);return;case"onScrollEnd":o!=null&&P("scrollend",e);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(C(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(C(60));l?.__html!==n&&(e.innerHTML=n)}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}n=Gc(o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":o===!0?e.setAttribute(n,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(n,o):e.removeAttribute(n);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(n):e.setAttribute(n,o);break;case"popover":P("beforetoggle",e),P("toggle",e),Kc(e,"popover",o);break;case"xlinkActuate":Rn(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Rn(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Rn(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Rn(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Rn(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Rn(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Rn(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Rn(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Rn(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":Kc(e,"is",o);break;case"innerText":case"textContent":return;default:if(!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")n=Pw.get(n)||n,Kc(e,n,o);else return}oe=!0}function Hd(e,t,n,o,a,l){switch(n){case"style":Bh(e,o,l);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(C(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(C(60));l?.__html!==n&&(e.innerHTML=n)}}break;case"children":if(typeof o=="string")pl(e,o);else if(typeof o=="number"||typeof o=="bigint")pl(e,""+o);else return;break;case"onScroll":o!=null&&P("scroll",e);return;case"onScrollEnd":o!=null&&P("scrollend",e);return;case"onClick":o!=null&&(e.onclick=gn);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!Oh.hasOwnProperty(n))e:{if(n[0]==="o"&&n[1]==="n"&&(a=n.endsWith("Capture"),l=n.slice(2,a?n.length-7:void 0),t=e[xt]||null,t=t!=null?t[n]:null,typeof t=="function"&&e.removeEventListener(l,t,a),typeof o=="function")){typeof t!="function"&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(l,o,a);break e}oe=!0,n in e?e[n]=o:o===!0?e.setAttribute(n,""):Kc(e,n,o)}return}oe=!0}function We(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":P("error",e),P("load",e);var o=!1,a=!1,l;for(l in n)if(n.hasOwnProperty(l)){var i=n[l];if(i!=null)switch(l){case"src":o=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(C(137,t));default:fe(e,t,l,i,n,null)}}a&&fe(e,t,"srcSet",n.srcSet,n,null),o&&fe(e,t,"src",n.src,n,null);return;case"input":P("invalid",e);var c=l=i=a=null,r=null,u=null;for(o in n)if(n.hasOwnProperty(o)){var h=n[o];if(h!=null)switch(o){case"name":a=h;break;case"type":i=h;break;case"checked":r=h;break;case"defaultChecked":u=h;break;case"value":l=h;break;case"defaultValue":c=h;break;case"children":case"dangerouslySetInnerHTML":if(h!=null)throw Error(C(137,t));break;default:fe(e,t,o,h,n,null)}}_h(e,l,c,r,u,i,a,!1);return;case"select":P("invalid",e),o=i=l=null;for(a in n)if(n.hasOwnProperty(a)&&(c=n[a],c!=null))switch(a){case"value":l=c;break;case"defaultValue":i=c;break;case"multiple":o=c;default:fe(e,t,a,c,n,null)}t=l,n=i,e.multiple=!!o,t!=null?nl(e,!!o,t,!1):n!=null&&nl(e,!!o,n,!0);return;case"textarea":P("invalid",e),l=a=o=null;for(i in n)if(n.hasOwnProperty(i)&&(c=n[i],c!=null))switch(i){case"value":o=c;break;case"defaultValue":a=c;break;case"children":l=c;break;case"dangerouslySetInnerHTML":if(c!=null)throw Error(C(91));break;default:fe(e,t,i,c,n,null)}Hh(e,o,a,l);return;case"option":for(r in n)n.hasOwnProperty(r)&&(o=n[r],o!=null)&&(r==="selected"?e.selected=o&&typeof o!="function"&&typeof o!="symbol":fe(e,t,r,o,n,null));return;case"dialog":P("beforetoggle",e),P("toggle",e),P("cancel",e),P("close",e);break;case"iframe":case"object":P("load",e);break;case"video":case"audio":for(o=0;o<Di.length;o++)P(Di[o],e);break;case"image":P("error",e),P("load",e);break;case"details":P("toggle",e);break;case"embed":case"source":case"link":P("error",e),P("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(u in n)if(n.hasOwnProperty(u)&&(o=n[u],o!=null))switch(u){case"children":case"dangerouslySetInnerHTML":throw Error(C(137,t));default:fe(e,t,u,o,n,null)}return;default:if(Id(t)){for(h in n)n.hasOwnProperty(h)&&(o=n[h],o!==void 0&&Hd(e,t,h,o,n,void 0));return}}for(c in n)n.hasOwnProperty(c)&&(o=n[c],o!=null&&fe(e,t,c,o,n,null))}var AS={};function OS(e,t,n,o){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var a=null,l=null,i=null,c=null,r=null,u=null,h=null;for(f in n){var m=n[f];if(n.hasOwnProperty(f)&&m!=null)switch(f){case"checked":break;case"value":break;case"defaultValue":r=m;default:o.hasOwnProperty(f)||fe(e,t,f,null,o,m)}}for(var p in o){var f=o[p];if(m=n[p],o.hasOwnProperty(p)&&(f!=null||m!=null))switch(p){case"type":f!==m&&(oe=!0),l=f;break;case"name":f!==m&&(oe=!0),a=f;break;case"checked":f!==m&&(oe=!0),u=f;break;case"defaultChecked":f!==m&&(oe=!0),h=f;break;case"value":f!==m&&(oe=!0),i=f;break;case"defaultValue":f!==m&&(oe=!0),c=f;break;case"children":case"dangerouslySetInnerHTML":if(f!=null)throw Error(C(137,t));break;default:f!==m&&fe(e,t,p,f,o,m)}}Js(e,i,c,r,u,h,l,a);return;case"select":f=i=c=p=null;for(l in n)if(r=n[l],n.hasOwnProperty(l)&&r!=null)switch(l){case"value":break;case"multiple":f=r;default:o.hasOwnProperty(l)||fe(e,t,l,null,o,r)}for(a in o)if(l=o[a],r=n[a],o.hasOwnProperty(a)&&(l!=null||r!=null))switch(a){case"value":l!==r&&(oe=!0),p=l;break;case"defaultValue":l!==r&&(oe=!0),c=l;break;case"multiple":l!==r&&(oe=!0),i=l;default:l!==r&&fe(e,t,a,l,o,r)}t=c,n=i,o=f,p!=null?nl(e,!!n,p,!1):!!o!=!!n&&(t!=null?nl(e,!!n,t,!0):nl(e,!!n,n?[]:"",!1));return;case"textarea":f=p=null;for(c in n)if(a=n[c],n.hasOwnProperty(c)&&a!=null&&!o.hasOwnProperty(c))switch(c){case"value":break;case"children":break;default:fe(e,t,c,null,o,a)}for(i in o)if(a=o[i],l=n[i],o.hasOwnProperty(i)&&(a!=null||l!=null))switch(i){case"value":a!==l&&(oe=!0),p=a;break;case"defaultValue":a!==l&&(oe=!0),f=a;break;case"children":break;case"dangerouslySetInnerHTML":if(a!=null)throw Error(C(91));break;default:a!==l&&fe(e,t,i,a,o,l)}Uh(e,p,f);return;case"option":for(var x in n)p=n[x],n.hasOwnProperty(x)&&p!=null&&!o.hasOwnProperty(x)&&(x==="selected"?e.selected=!1:fe(e,t,x,null,o,p));for(r in o)p=o[r],f=n[r],o.hasOwnProperty(r)&&p!==f&&(p!=null||f!=null)&&(r==="selected"?(p!==f&&(oe=!0),e.selected=p&&typeof p!="function"&&typeof p!="symbol"):fe(e,t,r,p,o,f));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var k in n)p=n[k],n.hasOwnProperty(k)&&p!=null&&!o.hasOwnProperty(k)&&fe(e,t,k,null,o,p);for(u in o)if(p=o[u],f=n[u],o.hasOwnProperty(u)&&p!==f&&(p!=null||f!=null))switch(u){case"children":case"dangerouslySetInnerHTML":if(p!=null)throw Error(C(137,t));break;default:fe(e,t,u,p,o,f)}return;default:if(Id(t)){for(var E in n)p=n[E],n.hasOwnProperty(E)&&p!==void 0&&!o.hasOwnProperty(E)&&Hd(e,t,E,void 0,o,p);for(h in o)p=o[h],f=n[h],!o.hasOwnProperty(h)||p===f||p===void 0&&f===void 0||Hd(e,t,h,p,o,f);return}}for(var b in n)p=n[b],n.hasOwnProperty(b)&&p!=null&&!o.hasOwnProperty(b)&&fe(e,t,b,null,o,p);for(m in o)p=o[m],f=n[m],!o.hasOwnProperty(m)||p===f||p==null&&f==null||fe(e,t,m,p,o,f)}function Xb(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function RS(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,n=performance.getEntriesByType("resource"),o=0;o<n.length;o++){var a=n[o],l=a.transferSize,i=a.initiatorType,c=a.duration;if(l&&c&&Xb(i)){for(i=0,c=a.responseEnd,o+=1;o<n.length;o++){var r=n[o],u=r.startTime;if(u>c)break;var h=r.transferSize,m=r.initiatorType;h&&Xb(m)&&(r=r.responseEnd,i+=h*(r<c?1:(c-u)/(r-u)))}if(--o,t+=8*(l+i)/(a.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Bd=null,Ld=null;function Ui(e){return e.nodeType===9?e:e.ownerDocument}function Kb(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Vv(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function jv(e,t,n,o){return n=Ui(n).createElement(e),n[$e]=o,n[xt]=t,We(n,e,t),Xe(n),n}function qd(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Ds=null;function DS(){var e=window.event;return e&&e.type==="popstate"?e===Ds?!1:(Ds=e,!0):(Ds=null,!1)}var qf=typeof setTimeout=="function"?setTimeout:void 0,_S=typeof clearTimeout=="function"?clearTimeout:void 0,Gb=typeof Promise=="function"?Promise:void 0,Qb=typeof requestAnimationFrame=="function"?requestAnimationFrame:qf,US=typeof queueMicrotask=="function"?queueMicrotask:typeof Gb<"u"?function(e){return Gb.resolve(null).then(e).catch(HS)}:qf;function HS(e){setTimeout(function(){throw e})}function Do(e){return e==="head"}function Zb(e,t){var n=t,o=0;do{var a=n.nextSibling;if(e.removeChild(n),a&&a.nodeType===8)if(n=a.data,n==="/$"||n==="/&"){if(o===0){e.removeChild(a),kl(t);return}o--}else if(n==="$"||n==="$?"||n==="$~"||n==="$!"||n==="&")o++;else if(n==="html")Us(e.ownerDocument.documentElement);else if(n==="head"){n=e.ownerDocument.head,Us(n);for(var l=n.firstChild;l;){var i=l.nextSibling,c=l.nodeName;l[Ki]||c==="SCRIPT"||c==="STYLE"||c==="LINK"&&l.rel.toLowerCase()==="stylesheet"||n.removeChild(l),l=i}}else n==="body"&&Us(e.ownerDocument.body);n=a}while(n);kl(t)}function Jb(e,t){var n=e;e=0;do{var o=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",n.getAttribute("style")===""&&n.removeAttribute("style")):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),o&&o.nodeType===8)if(n=o.data,n==="/$"){if(e===0)break;e--}else n!=="$"&&n!=="$?"&&n!=="$~"&&n!=="$!"||e++;n=o}while(n)}function Xv(e,t,n){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display==="inline"){if(t=e.getClientRects(),t.length===1)var o=1;else for(var a=o=0;a<t.length;a++){var l=t[a];0<l.width&&0<l.height&&o++}o===1&&(e=e.style,e.display=t.length===1?"inline-block":"block",e.marginTop="-"+n.paddingTop,e.marginBottom="-"+n.paddingBottom)}}function Kv(e,t){e=e.style,t=t.style;var n=t!=null?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=n==null||typeof n=="boolean"?"":(""+n).trim(),n=t!=null?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=n==null||typeof n=="boolean"?"":(""+n).trim(),e.display==="inline-block"&&(t==null?e.display=e.margin="":(n=t.display,e.display=n==null||typeof n=="boolean"?"":n,n=t.margin,n!=null?e.margin=n:(n=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=n==null||typeof n=="boolean"?"":n,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=t==null||typeof t=="boolean"?"":t)))}function Gv(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position==="absolute"||t.position==="fixed",clip:t.clipPath!=="none"||t.overflow!=="visible"||t.filter!=="none"||t.mask!=="none"||t.mask!=="none"||t.borderRadius!=="0px",view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function Yd(e){var t=e.getBoundingClientRect(),n=getComputedStyle(e);return Gv(t,n,e)}function BS(e){var t=e.getBoundingClientRect();t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height);var n=getComputedStyle(e);return Gv(t,n,e)}function LS(e){return e.documentElement.clientHeight}function qS(e){this.addEventListener("load",e),this.addEventListener("error",e)}function YS(e,t,n,o,a,l,i,c,r){var u=t.nodeType===9?t:t.ownerDocument;try{var h=u.startViewTransition({update:function(){var p=u.defaultView,f=p.navigation&&p.navigation.transition,x=u.fonts.status;o();var k=[];if(x==="loaded"&&(LS(u),u.fonts.status==="loading"&&k.push(u.fonts.ready)),x=k.length,e!==null)for(var E=e.suspenseyImages,b=0,s=0;s<E.length;s++){var d=E[s];if(!d.complete){var v=d.getBoundingClientRect();if(0<v.bottom&&0<v.right&&v.top<p.innerHeight&&v.left<p.innerWidth){if(b+=o0(d),b>ir){k.length=x;break}d=new Promise(qS.bind(d)),k.push(d)}}}if(0<k.length)return p=Promise.race([Promise.all(k),new Promise(function(y){return setTimeout(y,500)})]).then(a,a),(f?Promise.allSettled([f.finished,p]):p).then(l,l);if(a(),f)return f.finished.then(l,l);l()},types:n});u.__reactViewTransition=h;var m=[];return h.ready.then(function(){for(var p=u.documentElement.getAnimations({subtree:!0}),f=0;f<p.length;f++){var x=p[f],k=x.effect,E=k.pseudoElement;if(E!=null&&E.startsWith("::view-transition")){m.push(x),x=k.getKeyframes();for(var b=E=void 0,s=!0,d=0;d<x.length;d++){var v=x[d],y=v.width;if(E===void 0)E=y;else if(E!==y){s=!1;break}if(y=v.height,b===void 0)b=y;else if(b!==y){s=!1;break}delete v.width,delete v.height,v.transform==="none"&&delete v.transform}s&&E!==void 0&&b!==void 0&&(k.setKeyframes(x),s=getComputedStyle(k.target,k.pseudoElement),s.width!==E||s.height!==b)&&(s=x[0],s.width=E,s.height=b,s=x[x.length-1],s.width=E,s.height=b,k.setKeyframes(x))}}i()},function(p){u.__reactViewTransition===h&&(u.__reactViewTransition=null);try{typeof p=="object"&&p!==null&&p.name==="InvalidStateError"&&(p.message==="View transition was skipped because document visibility state is hidden."||p.message==="Skipping view transition because document visibility state has become hidden."||p.message==="Skipping view transition because viewport size changed."||p.message==="Transition was aborted because of invalid state")&&(p=null),p!==null&&r(p)}finally{o(),a(),i()}}),h.finished.finally(function(){for(var p=0;p<m.length;p++)m[p].cancel();u.__reactViewTransition===h&&(u.__reactViewTransition=null),c()}),h}catch{return o(),a(),i(),null}}function na(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}na.prototype.animate=function(e,t){return t=typeof t=="number"?{duration:t}:he({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)};na.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),o=[],a=0;a<n.length;a++){var l=n[a].effect;l!==null&&l.target===e&&l.pseudoElement===t&&o.push(n[a])}return o};na.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function Qv(e){return{name:e,group:new na("group",e),imagePair:new na("image-pair",e),old:new na("old",e),new:new na("new",e)}}function Ut(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}Ut.prototype.addEventListener=function(e,t,n){var o=null,a=null;if(!(n!=null&&typeof n!="boolean"&&(o=n.signal||null,o!==null&&o.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var l=this._eventListeners;if(Zv(l,e,t,n)===-1){var i=this,c=t;n!=null&&typeof n!="boolean"&&n.once===!0&&(c=function(r){i.removeEventListener(e,t,n),typeof t=="function"?t.call(this,r):t.handleEvent(r)}),o!==null&&(a=i.removeEventListener.bind(i,e,t,n),o.addEventListener("abort",a,{once:!0}),a=o.removeEventListener.bind(o,"abort",a)),o=yl(n),l.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:c,cleanup:a}),wt(this._fragmentFiber.child,!1,VS,e,c,o)}this._eventListeners=l}};function VS(e,t,n,o){return Le(e).addEventListener(t,n,o),!1}Ut.prototype.removeEventListener=function(e,t,n){var o=this._eventListeners;if(o!==null&&(t=Zv(o,e,t,n),t!==-1)){var a=o[t];n=a.attachedListener;var l=a.cleanup;a=yl(a.optionsOrUseCapture),wt(this._fragmentFiber.child,!1,jS,e,n,a),o.splice(t,1),l!==null&&l()}};function jS(e,t,n,o){return Le(e).removeEventListener(t,n,o),!1}function yl(e){return e!=null&&typeof e!="boolean"&&(e.once===!0||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function $b(e){return e==null?"c=0":typeof e=="boolean"?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")}function Zv(e,t,n,o){if(e.length===0)return-1;o=$b(o);for(var a=0;a<e.length;a++){var l=e[a];if(l.type===t&&l.listener===n&&$b(l.optionsOrUseCapture)===o)return a}return-1}Ut.prototype.dispatchEvent=function(e){var t=ha(this._fragmentFiber);if(t===null)return!0;t=Le(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var o=t.nodeType===9?t.createComment(""):document.createTextNode("");if(n)for(var a=0;a<n.length;a++){var l=n[a];o.addEventListener(l.type,l.attachedListener,yl(l.optionsOrUseCapture))}if(t.appendChild(o),e=o.dispatchEvent(e),n)for(a=0;a<n.length;a++)l=n[a],o.removeEventListener(l.type,l.attachedListener,yl(l.optionsOrUseCapture));return t.removeChild(o),e}return t.dispatchEvent(e)};Ut.prototype.focus=function(e){wt(this._fragmentFiber.child,!0,Jv,e,void 0,void 0)};function Jv(e,t){return e.tag===6?!1:(e=Le(e),ek(e,t))}Ut.prototype.focusLast=function(e){var t=[];wt(this._fragmentFiber.child,!0,Yf,t,void 0,void 0);for(var n=t.length-1;0<=n&&!Jv(t[n],e);n--);};function Yf(e,t){return t.push(e),!1}Ut.prototype.blur=function(){var e=ha(this._fragmentFiber);e!==null&&(e=Le(e),e=Ui(e).activeElement,e!==null&&wt(this._fragmentFiber.child,!1,XS,e,void 0,void 0))};function XS(e,t){return e.tag===6?!1:(e=Le(e),e===t||e.contains(t)?(t.blur(),!0):!1)}Ut.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),wt(this._fragmentFiber.child,!1,KS,e,void 0,void 0)};function KS(e,t){return e.tag===6||(e=Le(e),t.observe(e)),!1}Ut.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),wt(this._fragmentFiber.child,!1,GS,e,void 0,void 0);for(var n=t=0;n<en.length;n++){var o=en[n];o.fragmentInstance===this&&o.observer===e?e.unobserve(o.instance):en[t++]=o}en.length=t}};function GS(e,t){return e.tag===6||(e=Le(e),t.unobserve(e)),!1}var en=[],_s=!1;function QS(e,t,n){en.push({fragmentInstance:e,observer:t,instance:n}),_s||(_s=!0,tk(function(){_s=!1;var o=en;en=[];for(var a=0;a<o.length;a++){var l=o[a];l.observer.unobserve(l.instance)}}))}Ut.prototype.getClientRects=function(){var e=[];return wt(this._fragmentFiber.child,!1,ZS,e,void 0,void 0),e};function ZS(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=Le(e),t.push.apply(t,e.getClientRects());return!1}Ut.prototype.getRootNode=function(e){var t=ha(this._fragmentFiber);return t===null?this:Le(t).getRootNode(e)};Ut.prototype.compareDocumentPosition=function(e){var t=ha(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];wt(this._fragmentFiber.child,!1,Yf,n,void 0,void 0);var o=Le(t);if(n.length===0){if(n=o,Mm(this._fragmentFiber)){e:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break e}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var a=o=n.compareDocumentPosition(e);return n===e?a=Node.DOCUMENT_POSITION_CONTAINS:o&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=hh(t)[1],n===null?a=Node.DOCUMENT_POSITION_PRECEDING:(e=Le(n).compareDocumentPosition(e),a=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),a|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=Le(n[0]),a=Le(n[n.length-1]);var l=Mm(this._fragmentFiber)?t.parentElement:o;if(l==null)return Node.DOCUMENT_POSITION_DISCONNECTED;o=l.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,l=l.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_CONTAINED_BY;var i=t.compareDocumentPosition(e),c=a.compareDocumentPosition(e),r=i&Node.DOCUMENT_POSITION_CONTAINED_BY||c&Node.DOCUMENT_POSITION_CONTAINED_BY;return c=o&&l&&i&Node.DOCUMENT_POSITION_FOLLOWING&&c&Node.DOCUMENT_POSITION_PRECEDING,t=o&&t===e||l&&a===e||r||c?Node.DOCUMENT_POSITION_CONTAINED_BY:!o&&t===e||!l&&a===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:i,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||JS(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function JS(e,t,n,o,a){var l=ta(a);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!l)e:{for(;l!==null;){if(l.tag===7&&(l===t||l.alternate===t)){n=!0;break e}l=l.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(l===null)return l=a.ownerDocument,a===l||a===l.documentElement||a===l.body;e:{for(l=t,t=ha(t);l!==null;){if(!(l.tag!==5&&l.tag!==3&&l.tag!==27||l!==t&&l.alternate!==t)){l=!0;break e}l=l.return}l=!1}return l}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!l)&&!(t=l===n)&&(t=Bs(n,l,zm),t===null?t=!1:(wt(t,!0,Ew,l,n),l=Xa,Xa=null,t=l!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!l)&&!(t=l===o)&&(t=Bs(o,l,zm),t===null?t=!1:(wt(t,!0,Tw,l,o),l=Xa,Hs=Xa=null,t=l!==null)),t):!1}function Pb(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}Ut.prototype.scrollIntoView=function(e){if(typeof e=="object")throw Error(C(566));var t=[];wt(this._fragmentFiber.child,!1,Yf,t,void 0,void 0);var n=e!==!1;if(t.length===0){var o=hh(this._fragmentFiber);if(o=n?o[1]||o[0]||ha(this._fragmentFiber):o[0]||o[1],o===null)return;if(o.tag===6){e=Le(o),Pb(e,n);return}if(o=Le(o),o.nodeType!==9){if(o.nodeType===11){n="host"in o?o.host:null,n!==null&&n.scrollIntoView(e);return}o.scrollIntoView(e)}}for(o=n?t.length-1:0;o!==(n?-1:t.length);){var a=t[o];a.tag===6?(a=Le(a),Pb(a,n)):Le(a).scrollIntoView(e),o+=n?-1:1}};function $S(e,t){return e=Le(e),$v(e,t),!1}function $v(e,t){e.reactFragments==null&&(e.reactFragments=new Set),e.reactFragments.add(t)}function Pv(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.addEventListener(a.type,a.attachedListener,yl(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(l){for(var i=0,c=0;c<en.length;c++){var r=en[c];(r.fragmentInstance!==t||r.observer!==l||r.instance!==e)&&(en[i++]=r)}en.length=i,l.observe(e)}),$v(e,t))}function PS(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.removeEventListener(a.type,a.attachedListener,yl(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(l){typeof l.rootMargin=="string"?QS(t,l,e):l.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function Vd(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":Vd(n),qr(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(n.rel.toLowerCase()==="stylesheet")continue}e.removeChild(n)}}function FS(e,t,n,o){for(;e.nodeType===1;){var a=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[Ki])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(l=e.getAttribute("rel"),l==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(l!==a.rel||e.getAttribute("href")!==(a.href==null||a.href===""?null:a.href)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin)||e.getAttribute("title")!==(a.title==null?null:a.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(l=e.getAttribute("src"),(l!==(a.src==null?null:a.src)||e.getAttribute("type")!==(a.type==null?null:a.type)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin))&&l&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var l=a.name==null?null:""+a.name;if(a.type==="hidden"&&e.getAttribute("name")===l)return e}else return e;if(e=Qt(e.nextSibling),e===null)break}return null}function IS(e,t,n){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=Qt(e.nextSibling),e===null))return null;return e}function Fv(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=Qt(e.nextSibling),e===null))return null;return e}function jd(e){return e.data==="$?"||e.data==="$~"}function Vf(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function WS(e,t){var n=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||n.readyState!=="loading")t();else{var o=function(){t(),n.removeEventListener("DOMContentLoaded",o)};n.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function Qt(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var Xd=null;function Fb(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"||n==="/&"){if(t===0)return Qt(e.nextSibling);t--}else n!=="$"&&n!=="$!"&&n!=="$?"&&n!=="$~"&&n!=="&"||t++}e=e.nextSibling}return null}function Ib(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"){if(t===0)return e;t--}else n!=="/$"&&n!=="/&"||t++}e=e.previousSibling}return null}function ek(e,t){function n(){o=!0}if(e.ownerDocument.activeElement===e)return!0;var o=!1;try{e.ownerDocument.addEventListener("focus",n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener("focus",n,!0)}return o}function tk(e){Qb(function(){Qb(function(t){return e(t)})})}function Iv(e,t,n){switch(t=Ui(n),e){case"html":if(e=t.documentElement,!e)throw Error(C(452));return e;case"head":if(e=t.head,!e)throw Error(C(453));return e;case"body":if(e=t.body,!e)throw Error(C(454));return e;default:throw Error(C(451))}}function Wv(e,t,n){for(var o in n){var a=n[o];n.hasOwnProperty(o)&&a!=null&&fe(e,t,o,null,AS,a)}n.dangerouslySetInnerHTML!=null&&(e.textContent=""),e.onclick===gn&&(e.onclick=null),qr(e)}function Us(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);qr(e)}var Zt=new Map,Wb=new Set;function Hi(e){if(typeof e.getRootNode=="function"){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var Qn=ie.d;ie.d={f:nk,r:ok,D:ak,C:lk,L:ik,m:ck,X:uk,S:rk,M:sk};function nk(){var e=Qn.f(),t=Wr();return e||t}function ok(e){var t=Tl(e);t!==null&&t.tag===5&&t.type==="form"?Bg(t):Qn.r(e)}var zl=typeof document>"u"?null:document;function e0(e,t,n){var o=zl;if(o&&typeof t=="string"&&t){var a=Xt(t);a='link[rel="'+e+'"][href="'+a+'"]',typeof n=="string"&&(a+='[crossorigin="'+n+'"]'),Wb.has(a)||(Wb.add(a),e={rel:e,crossOrigin:n,href:t},o.querySelector(a)===null&&(t=o.createElement("link"),We(t,"link",e),Xe(t),o.head.appendChild(t)))}}function ak(e){Qn.D(e),e0("dns-prefetch",e,null)}function lk(e,t){Qn.C(e,t),e0("preconnect",e,t)}function ik(e,t,n){Qn.L(e,t,n);var o=zl;if(o&&e&&t){var a='link[rel="preload"][as="'+Xt(t)+'"]';t==="image"&&n&&n.imageSrcSet?(a+='[imagesrcset="'+Xt(n.imageSrcSet)+'"]',typeof n.imageSizes=="string"&&(a+='[imagesizes="'+Xt(n.imageSizes)+'"]')):a+='[href="'+Xt(e)+'"]';var l=a;switch(t){case"style":l=wl(e);break;case"script":l=Al(e)}if(!(Zt.has(l)||(e=he({rel:"preload",href:t==="image"&&n&&n.imageSrcSet?void 0:e,as:t},n),Zt.set(l,e),o.querySelector(a)!==null||t==="style"&&o.querySelector(Pi(l))||t==="script"&&o.querySelector(Fi(l))))){var i=o.createElement("link");We(i,"link",e),t==="style"&&(i[pr]=!0,i.onload=i.onerror=function(){zh(i)}),Xe(i),o.head.appendChild(i)}}}function ck(e,t){Qn.m(e,t);var n=zl;if(n&&e){var o=t&&typeof t.as=="string"?t.as:"script",a='link[rel="modulepreload"][as="'+Xt(o)+'"][href="'+Xt(e)+'"]',l=a;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":l=Al(e)}if(!Zt.has(l)&&(e=he({rel:"modulepreload",href:e},t),Zt.set(l,e),n.querySelector(a)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector(Fi(l)))return}o=n.createElement("link"),We(o,"link",e),Xe(o),n.head.appendChild(o)}}}function rk(e,t,n){Qn.S(e,t,n);var o=zl;if(o&&e){var a=tl(o).hoistableStyles,l=wl(e);t=t||"default";var i=a.get(l);if(!i){var c={loading:0,preload:null};if(i=o.querySelector(Pi(l)))c.loading=5;else{e=he({rel:"stylesheet",href:e,"data-precedence":t},n),(n=Zt.get(l))&&jf(e,n);var r=i=o.createElement("link");Xe(r),We(r,"link",e),r._p=new Promise(function(u,h){r.onload=u,r.onerror=h}),r.addEventListener("load",function(){c.loading|=1}),r.addEventListener("error",function(){c.loading|=2}),c.loading|=4,ar(i,t,o)}i={type:"stylesheet",instance:i,count:1,state:c},a.set(l,i)}}}function uk(e,t){Qn.X(e,t);var n=zl;if(n&&e){var o=tl(n).hoistableScripts,a=Al(e),l=o.get(a);l||(l=n.querySelector(Fi(a)),l||(e=he({src:e,async:!0},t),(t=Zt.get(a))&&Xf(e,t),l=n.createElement("script"),Xe(l),We(l,"link",e),n.head.appendChild(l)),l={type:"script",instance:l,count:1,state:null},o.set(a,l))}}function sk(e,t){Qn.M(e,t);var n=zl;if(n&&e){var o=tl(n).hoistableScripts,a=Al(e),l=o.get(a);l||(l=n.querySelector(Fi(a)),l||(e=he({src:e,async:!0,type:"module"},t),(t=Zt.get(a))&&Xf(e,t),l=n.createElement("script"),Xe(l),We(l,"link",e),n.head.appendChild(l)),l={type:"script",instance:l,count:1,state:null},o.set(a,l))}}function eh(e,t,n,o){var a=(a=go.current)?Hi(a):null;if(!a)throw Error(C(446));switch(e){case"meta":case"title":return null;case"style":return typeof n.precedence=="string"&&typeof n.href=="string"?(n=wl(n.href),t=tl(a).hoistableStyles,o=t.get(n),o||(o={type:"style",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(n.rel==="stylesheet"&&typeof n.href=="string"&&typeof n.precedence=="string"){e=wl(n.href);var l=tl(a).hoistableStyles,i=l.get(e);if(i||(a=a.ownerDocument||a,i={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},l.set(e,i),(l=a.querySelector(Pi(e)))?l._p||(i.instance=l,i.state.loading=5):(l=Zt.get(e),l||(l={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},Zt.set(e,l)),dk(a,e,l,i.state))),t&&o===null)throw Error(C(528,""));return i}if(t&&o!==null)throw Error(C(529,""));return null;case"script":return t=n.async,n=n.src,typeof n=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(n=Al(n),t=tl(a).hoistableScripts,o=t.get(n),o||(o={type:"script",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(C(444,e))}}function wl(e){return'href="'+Xt(e)+'"'}function Pi(e){return'link[rel="stylesheet"]['+e+"]"}function t0(e){return he({},e,{"data-precedence":e.precedence,precedence:null})}function dk(e,t,n,o){if(t=e.querySelector('link[rel="preload"][as="style"]['+t+"]")){if(t[pr]!==!0){o.loading=1;return}}else t=e.createElement("link"),t[pr]=!0,t.onload=t.onerror=zh.bind(null,t),We(t,"link",n),Xe(t),e.head.appendChild(t);o.preload=t,t.addEventListener("load",function(){return o.loading|=1}),t.addEventListener("error",function(){return o.loading|=2})}function Al(e){return'[src="'+Xt(e)+'"]'}function Fi(e){return"script[async]"+e}function th(e,t,n){if(t.count++,t.instance===null)switch(t.type){case"style":var o=e.querySelector('style[data-href~="'+Xt(n.href)+'"]');if(o)return t.instance=o,Xe(o),o;var a=he({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),Xe(o),We(o,"style",a),ar(o,n.precedence,e),t.instance=o;case"stylesheet":a=wl(n.href);var l=e.querySelector(Pi(a));if(l)return t.state.loading|=4,t.instance=l,Xe(l),l;o=t0(n),(a=Zt.get(a))&&jf(o,a),l=(e.ownerDocument||e).createElement("link"),Xe(l);var i=l;return i._p=new Promise(function(c,r){i.onload=c,i.onerror=r}),We(l,"link",o),t.state.loading|=4,ar(l,n.precedence,e),t.instance=l;case"script":return l=Al(n.src),(a=e.querySelector(Fi(l)))?(t.instance=a,Xe(a),a):(o=n,(a=Zt.get(l))&&(o=he({},n),Xf(o,a)),e=e.ownerDocument||e,a=e.createElement("script"),Xe(a),We(a,"link",o),e.head.appendChild(a),t.instance=a);case"void":return null;default:throw Error(C(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(o=t.instance,t.state.loading|=4,ar(o,n.precedence,e));return t.instance}function ar(e,t,n){for(var o=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),a=o.length?o[o.length-1]:null,l=a,i=0;i<o.length;i++){var c=o[i];if(c.dataset.precedence===t)l=c;else if(l!==a)break}l?l.parentNode.insertBefore(e,l.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function jf(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function Xf(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var lr=null;function nh(e,t,n){if(lr===null){var o=new Map,a=lr=new Map;a.set(n,o)}else a=lr,o=a.get(n),o||(o=new Map,a.set(n,o));if(o.has(e))return o;for(o.set(e,null),n=n.getElementsByTagName(e),a=0;a<n.length;a++){var l=n[a];if(!(l[Ki]||l[$e]||e==="link"&&l.getAttribute("rel")==="stylesheet")&&l.namespaceURI!=="http://www.w3.org/2000/svg"){var i=l.getAttribute(t)||"";i=e+i;var c=o.get(i);c?c.push(l):o.set(i,[l])}}return o}function Kd(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t==="title"?e.querySelector("head > title"):null)}function fk(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function oh(e,t){return e==="img"&&t.src!=null&&t.src!==""&&t.onLoad==null&&t.loading!=="lazy"}function n0(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function o0(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function ah(e,t){typeof t.decode=="function"&&(e.imgCount++,t.complete||(e.imgBytes+=o0(t),e.suspenseyImages.push(t)),e=bk.bind(e),t.decode().then(e,e))}function pk(e,t,n,o){if(n.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var a=wl(o.href),l=t.querySelector(Pi(a));if(l){t=l._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=Bi.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=l,Xe(l);return}l=t.ownerDocument||t,o=t0(o),(a=Zt.get(a))&&jf(o,a),l=l.createElement("link"),Xe(l);var i=l;i._p=new Promise(function(c,r){i.onload=c,i.onerror=r}),We(l,"link",o),n.instance=l}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(e.count++,n=Bi.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}var ir=0;function mk(e,t){return e.stylesheets&&e.count===0&&cr(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var o=setTimeout(function(){if(e.stylesheets&&cr(e,e.stylesheets),e.unsuspend){var l=e.unsuspend;e.unsuspend=null,l()}},6e4+t);0<e.imgBytes&&ir===0&&(ir=62500*RS());var a=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&cr(e,e.stylesheets),e.unsuspend)){var l=e.unsuspend;e.unsuspend=null,l()}},(e.imgBytes>ir?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(a)}}:null}function a0(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)cr(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function Bi(){this.count--,a0(this)}function bk(){this.imgCount--,a0(this)}var Hr=null;function cr(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Hr=new Map,t.forEach(hk,e),Hr=null,Bi.call(e))}function hk(e,t){if(!(t.state.loading&4)){var n=Hr.get(e);if(n)var o=n.get(null);else{n=new Map,Hr.set(e,n);for(var a=e.querySelectorAll("link[data-precedence],style[data-precedence]"),l=0;l<a.length;l++){var i=a[l];(i.nodeName==="LINK"||i.getAttribute("media")!=="not all")&&(n.set(i.dataset.precedence,i),o=i)}o&&n.set(null,o)}a=t.instance,i=a.getAttribute("data-precedence"),l=n.get(i)||o,l===o&&n.set(null,a),n.set(i,a),this.count++,o=Bi.bind(this),a.addEventListener("load",o),a.addEventListener("error",o),l?l.parentNode.insertBefore(a,l.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(a,e.firstChild)),t.state.loading|=4}}var xl={$$typeof:hn,Provider:null,Consumer:null,_currentValue:oa,_currentValue2:oa,_threadCount:0};function gk(e,t,n,o,a,l,i,c,r){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=us(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=us(0),this.hiddenUpdates=us(null),this.identifierPrefix=o,this.onUncaughtError=a,this.onCaughtError=l,this.onRecoverableError=i,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=r,this.transitionTypes=null,this.incompleteTransitions=new Map}function l0(e,t,n,o,a,l,i,c,r,u,h,m){return e=new gk(e,t,n,i,r,u,h,m,c),t=1,l===!0&&(t|=24),l=vt(3,null,null,t),e.current=l,l.stateNode=e,t=uf(),t.refCount++,e.pooledCache=t,t.refCount++,l.memoizedState={element:o,isDehydrated:n,cache:t},ff(l),e}function i0(e){return e?(e=Fa,e):Fa}function c0(e,t,n,o,a,l){a=i0(a),o.context===null?o.context=a:o.pendingContext=a,o=yo(t),o.payload={element:n},l=l===void 0?null:l,l!==null&&(o.callback=l),n=wo(e,o,t),n!==null&&(yt(n,e,t),bi(n,e,t))}function lh(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function Kf(e,t){lh(e,t),(e=e.alternate)&&lh(e,t)}function r0(e){if(e.tag===13||e.tag===31){var t=ya(e,67108864);t!==null&&yt(t,e,67108864),Kf(e,67108864)}}function ih(e){if(e.tag===13||e.tag===31){var t=Dt();t=Pd(t);var n=ya(e,t);n!==null&&yt(n,e,t),Kf(e,t)}}var Sl=!0;function vk(e,t,n,o){var a=Y.T;Y.T=null;var l=ie.p;try{ie.p=2,Gf(e,t,n,o)}finally{ie.p=l,Y.T=a}}function yk(e,t,n,o){var a=Y.T;Y.T=null;var l=ie.p;try{ie.p=8,Gf(e,t,n,o)}finally{ie.p=l,Y.T=a}}function Gf(e,t,n,o){if(Sl){var a=Gd(o);if(a===null)Rs(e,t,o,Br,n),ch(e,o);else if(xk(a,e,t,n,o))o.stopPropagation();else if(ch(e,o),t&4&&-1<wk.indexOf(e)){for(;a!==null;){var l=Tl(a);if(l!==null)switch(l.tag){case 3:if(l=l.stateNode,l.current.memoizedState.isDehydrated){var i=Io(l.pendingLanes);if(i!==0){var c=l;for(c.pendingLanes|=2,c.entangledLanes|=2;i;){var r=1<<31-Rt(i);c.entanglements[1]|=r,i&=~r}En(l),(le&6)===0&&(Or=At()+500,$i(0,!1))}}break;case 31:case 13:c=ya(l,2),c!==null&&yt(c,l,2),Wr(),Kf(l,2)}if(l=Gd(o),l===null&&Rs(e,t,o,Br,n),l===a)break;a=l}a!==null&&o.stopPropagation()}else Rs(e,t,o,null,n)}}function Gd(e){return e=Wd(e),Qf(e)}var Br=null;function Qf(e){if(Br=null,e=ta(e),e!==null){var t=Yi(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=ph(t),e!==null)return e;e=null}else if(n===31){if(e=mh(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return Br=e,null}function u0(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(_w()){case wh:return 2;case xh:return 8;case fr:case Uw:return 32;case Sh:return 268435456;default:return 32}default:return 32}}var Qd=!1,Eo=null,To=null,Co=null,Li=new Map,qi=new Map,uo=[],wk="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function ch(e,t){switch(e){case"focusin":case"focusout":Eo=null;break;case"dragenter":case"dragleave":To=null;break;case"mouseover":case"mouseout":Co=null;break;case"pointerover":case"pointerout":Li.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":qi.delete(t.pointerId)}}function ai(e,t,n,o,a,l){return e===null||e.nativeEvent!==l?(e={blockedOn:t,domEventName:n,eventSystemFlags:o,nativeEvent:l,targetContainers:[a]},t!==null&&(t=Tl(t),t!==null&&r0(t)),e):(e.eventSystemFlags|=o,t=e.targetContainers,a!==null&&t.indexOf(a)===-1&&t.push(a),e)}function xk(e,t,n,o,a){switch(t){case"focusin":return Eo=ai(Eo,e,t,n,o,a),!0;case"dragenter":return To=ai(To,e,t,n,o,a),!0;case"mouseover":return Co=ai(Co,e,t,n,o,a),!0;case"pointerover":var l=a.pointerId;return Li.set(l,ai(Li.get(l)||null,e,t,n,o,a)),!0;case"gotpointercapture":return l=a.pointerId,qi.set(l,ai(qi.get(l)||null,e,t,n,o,a)),!0}return!1}function s0(e){var t=ta(e.target);if(t!==null){var n=Yi(t);if(n!==null){if(t=n.tag,t===13){if(t=ph(n),t!==null){e.blockedOn=t,Dm(e.priority,function(){ih(n)});return}}else if(t===31){if(t=mh(n),t!==null){e.blockedOn=t,Dm(e.priority,function(){ih(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function rr(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=Gd(e.nativeEvent);if(n===null){n=e.nativeEvent;var o=new n.constructor(n.type,n);$s=o,n.target.dispatchEvent(o),$s=null}else return t=Tl(n),t!==null&&r0(t),e.blockedOn=n,!1;t.shift()}return!0}function rh(e,t,n){rr(e)&&n.delete(t)}function Sk(){Qd=!1,Eo!==null&&rr(Eo)&&(Eo=null),To!==null&&rr(To)&&(To=null),Co!==null&&rr(Co)&&(Co=null),Li.forEach(rh),qi.forEach(rh)}function jc(e,t){e.blockedOn===t&&(e.blockedOn=null,Qd||(Qd=!0,qe.unstable_scheduleCallback(qe.unstable_NormalPriority,Sk)))}var Xc=null;function uh(e){Xc!==e&&(Xc=e,qe.unstable_scheduleCallback(qe.unstable_NormalPriority,function(){Xc===e&&(Xc=null);for(var t=0;t<e.length;t+=3){var n=e[t],o=e[t+1],a=e[t+2];if(typeof o!="function"){if(Qf(o||n)===null)continue;break}var l=Tl(n);l!==null&&(e.splice(t,3),t-=3,dd(l,{pending:!0,data:a,method:n.method,action:o},o,a))}}))}function kl(e){function t(r){return jc(r,e)}Eo!==null&&jc(Eo,e),To!==null&&jc(To,e),Co!==null&&jc(Co,e),Li.forEach(t),qi.forEach(t);for(var n=0;n<uo.length;n++){var o=uo[n];o.blockedOn===e&&(o.blockedOn=null)}for(;0<uo.length&&(n=uo[0],n.blockedOn===null);)s0(n),n.blockedOn===null&&uo.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(o=0;o<n.length;o+=3){var a=n[o],l=n[o+1],i=a[xt]||null;if(typeof l=="function")i||uh(n);else if(i){var c=null;if(l&&l.hasAttribute("formAction")){if(a=l,i=l[xt]||null)c=i.formAction;else if(Qf(a)!==null)continue}else c=i.action;typeof c=="function"?n[o+1]=c:(n.splice(o,3),o-=3),uh(n)}}}function d0(){function e(l){l.canIntercept&&l.info==="react-transition"&&l.intercept({handler:function(){return new Promise(function(i){return a=i})},focusReset:"manual",scroll:"manual"})}function t(){a!==null&&(a(),a=null),o||setTimeout(n,20)}function n(){if(!o&&!navigation.transition){var l=navigation.currentEntry;l&&l.url!=null&&navigation.navigate(l.url,{state:l.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,a=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),a!==null&&(a(),a=null)}}}function Zf(e){this._internalRoot=e}nu.prototype.render=Zf.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(C(409));var n=t.current,o=Dt();c0(n,o,e,t,null,null)};nu.prototype.unmount=Zf.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;c0(e.current,2,null,e,null,null),Wr(),t[El]=null}};function nu(e){this._internalRoot=e}nu.prototype.unstable_scheduleHydration=function(e){if(e){var t=Mh();e={blockedOn:null,target:e,priority:t};for(var n=0;n<uo.length&&t!==0&&t<uo[n].priority;n++);uo.splice(n,0,e),n===0&&s0(e)}};var sh=dh.version;if(sh!=="19.3.0")throw Error(C(527,sh,"19.3.0"));ie.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(C(188)):(e=Object.keys(e).join(","),Error(C(268,e)));return e=kw(t),e=e!==null?bh(e):null,e=e===null?null:e.stateNode,e};var kk={bundleType:0,version:"19.3.0",rendererPackageName:"react-dom",currentDispatcherRef:Y,reconcilerVersion:"19.3.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(li=__REACT_DEVTOOLS_GLOBAL_HOOK__,!li.isDisabled&&li.supportsFiber))try{Vi=li.inject(kk),Ot=li}catch{}var li;ou.createRoot=function(e,t){if(!fh(e))throw Error(C(299));var n=!1,o="",a=Gg,l=Qg,i=Zg;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(o=t.identifierPrefix),t.onUncaughtError!==void 0&&(a=t.onUncaughtError),t.onCaughtError!==void 0&&(l=t.onCaughtError),t.onRecoverableError!==void 0&&(i=t.onRecoverableError)),t=l0(e,1,!1,null,null,n,o,null,a,l,i,d0),e[El]=t.current,Lf(e),new Zf(t)};ou.hydrateRoot=function(e,t,n){if(!fh(e))throw Error(C(299));var o=!1,a="",l=Gg,i=Qg,c=Zg,r=null;return n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(a=n.identifierPrefix),n.onUncaughtError!==void 0&&(l=n.onUncaughtError),n.onCaughtError!==void 0&&(i=n.onCaughtError),n.onRecoverableError!==void 0&&(c=n.onRecoverableError),n.formState!==void 0&&(r=n.formState)),t=l0(e,1,!0,t,n??null,o,a,r,l,i,c,d0),t.context=i0(null),n=t.current,o=Dt(),o=Pd(o),a=yo(o),a.callback=null,wo(n,a,o),n=o,t.current.lanes=n,Xi(t,n),En(t),e[El]=t.current,Lf(e),new nu(t)};ou.version="19.3.0"});var b0=un((I2,m0)=>{"use strict";function p0(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(p0)}catch(e){console.error(e)}}p0(),m0.exports=f0()});var R0=un(mu=>{"use strict";var zk=Symbol.for("react.transitional.element"),Ak=Symbol.for("react.fragment");function O0(e,t,n){var o=null;if(n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),"key"in t){n={};for(var a in t)a!=="key"&&(n[a]=t[a])}else n=t;return t=n.ref,{$$typeof:zk,type:e,key:o,ref:t!==void 0?t:null,props:n}}mu.Fragment=Ak;mu.jsx=O0;mu.jsxs=O0});var q=un((nE,D0)=>{"use strict";D0.exports=R0()});var Jp=`/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

@font-face {
	font-family: "codicon";
	font-display: block;
	src: url("./codicon.ttf?9aab6318a6710999273bab9c78a9fd71") format("truetype");
}

.codicon[class*='codicon-'] {
	font: normal normal normal 16px/1 codicon;
	display: inline-block;
	text-decoration: none;
	text-rendering: auto;
	text-align: center;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	user-select: none;
	-webkit-user-select: none;
	-ms-user-select: none;
}

/*---------------------
 *  Modifiers
 *-------------------*/

@keyframes codicon-spin {
	100% {
		transform:rotate(360deg);
	}
}

.codicon-sync.codicon-modifier-spin,
.codicon-loading.codicon-modifier-spin,
.codicon-gear.codicon-modifier-spin {
	/* Use steps to throttle FPS to reduce CPU usage */
	animation: codicon-spin 1.5s steps(30) infinite;
}

.codicon-modifier-disabled {
	opacity: 0.5;
}

.codicon-modifier-hidden {
	opacity: 0;
}

/* custom speed & easing for loading icon */
.codicon-loading {
	animation-duration: 1s !important;
	animation-timing-function: cubic-bezier(0.53, 0.21, 0.29, 0.67) !important;
}

/*---------------------
 *  Icons
 *-------------------*/

.codicon-add:before { content: "\\ea60" }
.codicon-plus:before { content: "\\ea60" }
.codicon-gist-new:before { content: "\\ea60" }
.codicon-repo-create:before { content: "\\ea60" }
.codicon-lightbulb:before { content: "\\ea61" }
.codicon-light-bulb:before { content: "\\ea61" }
.codicon-repo:before { content: "\\ea62" }
.codicon-repo-delete:before { content: "\\ea62" }
.codicon-gist-fork:before { content: "\\ea63" }
.codicon-repo-forked:before { content: "\\ea63" }
.codicon-git-pull-request:before { content: "\\ea64" }
.codicon-git-pull-request-abandoned:before { content: "\\ea64" }
.codicon-record-keys:before { content: "\\ea65" }
.codicon-keyboard:before { content: "\\ea65" }
.codicon-tag:before { content: "\\ea66" }
.codicon-git-pull-request-label:before { content: "\\ea66" }
.codicon-tag-add:before { content: "\\ea66" }
.codicon-tag-remove:before { content: "\\ea66" }
.codicon-person:before { content: "\\ea67" }
.codicon-person-follow:before { content: "\\ea67" }
.codicon-person-outline:before { content: "\\ea67" }
.codicon-person-filled:before { content: "\\ea67" }
.codicon-source-control:before { content: "\\ea68" }
.codicon-mirror:before { content: "\\ea69" }
.codicon-mirror-public:before { content: "\\ea69" }
.codicon-star:before { content: "\\ea6a" }
.codicon-star-add:before { content: "\\ea6a" }
.codicon-star-delete:before { content: "\\ea6a" }
.codicon-star-empty:before { content: "\\ea6a" }
.codicon-comment:before { content: "\\ea6b" }
.codicon-comment-add:before { content: "\\ea6b" }
.codicon-alert:before { content: "\\ea6c" }
.codicon-warning:before { content: "\\ea6c" }
.codicon-search:before { content: "\\ea6d" }
.codicon-search-save:before { content: "\\ea6d" }
.codicon-log-out:before { content: "\\ea6e" }
.codicon-sign-out:before { content: "\\ea6e" }
.codicon-log-in:before { content: "\\ea6f" }
.codicon-sign-in:before { content: "\\ea6f" }
.codicon-eye:before { content: "\\ea70" }
.codicon-eye-unwatch:before { content: "\\ea70" }
.codicon-eye-watch:before { content: "\\ea70" }
.codicon-circle-filled:before { content: "\\ea71" }
.codicon-primitive-dot:before { content: "\\ea71" }
.codicon-close-dirty:before { content: "\\ea71" }
.codicon-debug-breakpoint:before { content: "\\ea71" }
.codicon-debug-breakpoint-disabled:before { content: "\\ea71" }
.codicon-debug-hint:before { content: "\\ea71" }
.codicon-terminal-decoration-success:before { content: "\\ea71" }
.codicon-primitive-square:before { content: "\\ea72" }
.codicon-edit:before { content: "\\ea73" }
.codicon-pencil:before { content: "\\ea73" }
.codicon-info:before { content: "\\ea74" }
.codicon-issue-opened:before { content: "\\ea74" }
.codicon-gist-private:before { content: "\\ea75" }
.codicon-git-fork-private:before { content: "\\ea75" }
.codicon-lock:before { content: "\\ea75" }
.codicon-mirror-private:before { content: "\\ea75" }
.codicon-close:before { content: "\\ea76" }
.codicon-remove-close:before { content: "\\ea76" }
.codicon-x:before { content: "\\ea76" }
.codicon-repo-sync:before { content: "\\ea77" }
.codicon-sync:before { content: "\\ea77" }
.codicon-clone:before { content: "\\ea78" }
.codicon-desktop-download:before { content: "\\ea78" }
.codicon-beaker:before { content: "\\ea79" }
.codicon-microscope:before { content: "\\ea79" }
.codicon-vm:before { content: "\\ea7a" }
.codicon-device-desktop:before { content: "\\ea7a" }
.codicon-file:before { content: "\\ea7b" }
.codicon-more:before { content: "\\ea7c" }
.codicon-ellipsis:before { content: "\\ea7c" }
.codicon-kebab-horizontal:before { content: "\\ea7c" }
.codicon-mail-reply:before { content: "\\ea7d" }
.codicon-reply:before { content: "\\ea7d" }
.codicon-organization:before { content: "\\ea7e" }
.codicon-organization-filled:before { content: "\\ea7e" }
.codicon-organization-outline:before { content: "\\ea7e" }
.codicon-new-file:before { content: "\\ea7f" }
.codicon-file-add:before { content: "\\ea7f" }
.codicon-new-folder:before { content: "\\ea80" }
.codicon-file-directory-create:before { content: "\\ea80" }
.codicon-trash:before { content: "\\ea81" }
.codicon-trashcan:before { content: "\\ea81" }
.codicon-history:before { content: "\\ea82" }
.codicon-clock:before { content: "\\ea82" }
.codicon-folder:before { content: "\\ea83" }
.codicon-file-directory:before { content: "\\ea83" }
.codicon-symbol-folder:before { content: "\\ea83" }
.codicon-logo-github:before { content: "\\ea84" }
.codicon-mark-github:before { content: "\\ea84" }
.codicon-github:before { content: "\\ea84" }
.codicon-terminal:before { content: "\\ea85" }
.codicon-console:before { content: "\\ea85" }
.codicon-repl:before { content: "\\ea85" }
.codicon-zap:before { content: "\\ea86" }
.codicon-symbol-event:before { content: "\\ea86" }
.codicon-error:before { content: "\\ea87" }
.codicon-stop:before { content: "\\ea87" }
.codicon-variable:before { content: "\\ea88" }
.codicon-symbol-variable:before { content: "\\ea88" }
.codicon-array:before { content: "\\ea8a" }
.codicon-symbol-array:before { content: "\\ea8a" }
.codicon-symbol-module:before { content: "\\ea8b" }
.codicon-symbol-package:before { content: "\\ea8b" }
.codicon-symbol-namespace:before { content: "\\ea8b" }
.codicon-symbol-object:before { content: "\\ea8b" }
.codicon-symbol-method:before { content: "\\ea8c" }
.codicon-symbol-function:before { content: "\\ea8c" }
.codicon-symbol-constructor:before { content: "\\ea8c" }
.codicon-symbol-boolean:before { content: "\\ea8f" }
.codicon-symbol-null:before { content: "\\ea8f" }
.codicon-symbol-numeric:before { content: "\\ea90" }
.codicon-symbol-number:before { content: "\\ea90" }
.codicon-symbol-structure:before { content: "\\ea91" }
.codicon-symbol-struct:before { content: "\\ea91" }
.codicon-symbol-parameter:before { content: "\\ea92" }
.codicon-symbol-type-parameter:before { content: "\\ea92" }
.codicon-symbol-key:before { content: "\\ea93" }
.codicon-symbol-text:before { content: "\\ea93" }
.codicon-symbol-reference:before { content: "\\ea94" }
.codicon-go-to-file:before { content: "\\ea94" }
.codicon-symbol-enum:before { content: "\\ea95" }
.codicon-symbol-value:before { content: "\\ea95" }
.codicon-symbol-ruler:before { content: "\\ea96" }
.codicon-symbol-unit:before { content: "\\ea96" }
.codicon-activate-breakpoints:before { content: "\\ea97" }
.codicon-archive:before { content: "\\ea98" }
.codicon-arrow-both:before { content: "\\ea99" }
.codicon-arrow-down:before { content: "\\ea9a" }
.codicon-arrow-left:before { content: "\\ea9b" }
.codicon-arrow-right:before { content: "\\ea9c" }
.codicon-arrow-small-down:before { content: "\\ea9d" }
.codicon-arrow-small-left:before { content: "\\ea9e" }
.codicon-arrow-small-right:before { content: "\\ea9f" }
.codicon-arrow-small-up:before { content: "\\eaa0" }
.codicon-arrow-up:before { content: "\\eaa1" }
.codicon-bell:before { content: "\\eaa2" }
.codicon-bold:before { content: "\\eaa3" }
.codicon-book:before { content: "\\eaa4" }
.codicon-bookmark:before { content: "\\eaa5" }
.codicon-debug-breakpoint-conditional-unverified:before { content: "\\eaa6" }
.codicon-debug-breakpoint-conditional:before { content: "\\eaa7" }
.codicon-debug-breakpoint-conditional-disabled:before { content: "\\eaa7" }
.codicon-debug-breakpoint-data-unverified:before { content: "\\eaa8" }
.codicon-debug-breakpoint-data:before { content: "\\eaa9" }
.codicon-debug-breakpoint-data-disabled:before { content: "\\eaa9" }
.codicon-debug-breakpoint-log-unverified:before { content: "\\eaaa" }
.codicon-debug-breakpoint-log:before { content: "\\eaab" }
.codicon-debug-breakpoint-log-disabled:before { content: "\\eaab" }
.codicon-briefcase:before { content: "\\eaac" }
.codicon-broadcast:before { content: "\\eaad" }
.codicon-browser:before { content: "\\eaae" }
.codicon-bug:before { content: "\\eaaf" }
.codicon-calendar:before { content: "\\eab0" }
.codicon-case-sensitive:before { content: "\\eab1" }
.codicon-check:before { content: "\\eab2" }
.codicon-checklist:before { content: "\\eab3" }
.codicon-chevron-down:before { content: "\\eab4" }
.codicon-chevron-left:before { content: "\\eab5" }
.codicon-chevron-right:before { content: "\\eab6" }
.codicon-chevron-up:before { content: "\\eab7" }
.codicon-chrome-close:before { content: "\\eab8" }
.codicon-chrome-maximize:before { content: "\\eab9" }
.codicon-chrome-minimize:before { content: "\\eaba" }
.codicon-chrome-restore:before { content: "\\eabb" }
.codicon-circle-outline:before { content: "\\eabc" }
.codicon-circle:before { content: "\\eabc" }
.codicon-debug-breakpoint-unverified:before { content: "\\eabc" }
.codicon-terminal-decoration-incomplete:before { content: "\\eabc" }
.codicon-circle-slash:before { content: "\\eabd" }
.codicon-circuit-board:before { content: "\\eabe" }
.codicon-clear-all:before { content: "\\eabf" }
.codicon-clippy:before { content: "\\eac0" }
.codicon-close-all:before { content: "\\eac1" }
.codicon-cloud-download:before { content: "\\eac2" }
.codicon-cloud-upload:before { content: "\\eac3" }
.codicon-code:before { content: "\\eac4" }
.codicon-collapse-all:before { content: "\\eac5" }
.codicon-color-mode:before { content: "\\eac6" }
.codicon-comment-discussion:before { content: "\\eac7" }
.codicon-credit-card:before { content: "\\eac9" }
.codicon-dash:before { content: "\\eacc" }
.codicon-dashboard:before { content: "\\eacd" }
.codicon-database:before { content: "\\eace" }
.codicon-debug-continue:before { content: "\\eacf" }
.codicon-debug-disconnect:before { content: "\\ead0" }
.codicon-debug-pause:before { content: "\\ead1" }
.codicon-debug-restart:before { content: "\\ead2" }
.codicon-debug-start:before { content: "\\ead3" }
.codicon-debug-step-into:before { content: "\\ead4" }
.codicon-debug-step-out:before { content: "\\ead5" }
.codicon-debug-step-over:before { content: "\\ead6" }
.codicon-debug-stop:before { content: "\\ead7" }
.codicon-debug:before { content: "\\ead8" }
.codicon-device-camera-video:before { content: "\\ead9" }
.codicon-device-camera:before { content: "\\eada" }
.codicon-device-mobile:before { content: "\\eadb" }
.codicon-diff-added:before { content: "\\eadc" }
.codicon-diff-ignored:before { content: "\\eadd" }
.codicon-diff-modified:before { content: "\\eade" }
.codicon-diff-removed:before { content: "\\eadf" }
.codicon-diff-renamed:before { content: "\\eae0" }
.codicon-diff:before { content: "\\eae1" }
.codicon-diff-sidebyside:before { content: "\\eae1" }
.codicon-discard:before { content: "\\eae2" }
.codicon-editor-layout:before { content: "\\eae3" }
.codicon-empty-window:before { content: "\\eae4" }
.codicon-exclude:before { content: "\\eae5" }
.codicon-extensions:before { content: "\\eae6" }
.codicon-eye-closed:before { content: "\\eae7" }
.codicon-file-binary:before { content: "\\eae8" }
.codicon-file-code:before { content: "\\eae9" }
.codicon-file-media:before { content: "\\eaea" }
.codicon-file-pdf:before { content: "\\eaeb" }
.codicon-file-submodule:before { content: "\\eaec" }
.codicon-file-symlink-directory:before { content: "\\eaed" }
.codicon-file-symlink-file:before { content: "\\eaee" }
.codicon-file-zip:before { content: "\\eaef" }
.codicon-files:before { content: "\\eaf0" }
.codicon-filter:before { content: "\\eaf1" }
.codicon-flame:before { content: "\\eaf2" }
.codicon-fold-down:before { content: "\\eaf3" }
.codicon-fold-up:before { content: "\\eaf4" }
.codicon-fold:before { content: "\\eaf5" }
.codicon-folder-active:before { content: "\\eaf6" }
.codicon-folder-opened:before { content: "\\eaf7" }
.codicon-gear:before { content: "\\eaf8" }
.codicon-gift:before { content: "\\eaf9" }
.codicon-gist-secret:before { content: "\\eafa" }
.codicon-gist:before { content: "\\eafb" }
.codicon-git-commit:before { content: "\\eafc" }
.codicon-git-compare:before { content: "\\eafd" }
.codicon-compare-changes:before { content: "\\eafd" }
.codicon-git-merge:before { content: "\\eafe" }
.codicon-github-action:before { content: "\\eaff" }
.codicon-github-alt:before { content: "\\eb00" }
.codicon-globe:before { content: "\\eb01" }
.codicon-grabber:before { content: "\\eb02" }
.codicon-graph:before { content: "\\eb03" }
.codicon-gripper:before { content: "\\eb04" }
.codicon-heart:before { content: "\\eb05" }
.codicon-home:before { content: "\\eb06" }
.codicon-horizontal-rule:before { content: "\\eb07" }
.codicon-hubot:before { content: "\\eb08" }
.codicon-inbox:before { content: "\\eb09" }
.codicon-issue-reopened:before { content: "\\eb0b" }
.codicon-issues:before { content: "\\eb0c" }
.codicon-italic:before { content: "\\eb0d" }
.codicon-jersey:before { content: "\\eb0e" }
.codicon-json:before { content: "\\eb0f" }
.codicon-bracket:before { content: "\\eb0f" }
.codicon-kebab-vertical:before { content: "\\eb10" }
.codicon-key:before { content: "\\eb11" }
.codicon-law:before { content: "\\eb12" }
.codicon-lightbulb-autofix:before { content: "\\eb13" }
.codicon-link-external:before { content: "\\eb14" }
.codicon-link:before { content: "\\eb15" }
.codicon-list-ordered:before { content: "\\eb16" }
.codicon-list-unordered:before { content: "\\eb17" }
.codicon-live-share:before { content: "\\eb18" }
.codicon-loading:before { content: "\\eb19" }
.codicon-location:before { content: "\\eb1a" }
.codicon-mail-read:before { content: "\\eb1b" }
.codicon-mail:before { content: "\\eb1c" }
.codicon-markdown:before { content: "\\eb1d" }
.codicon-megaphone:before { content: "\\eb1e" }
.codicon-mention:before { content: "\\eb1f" }
.codicon-milestone:before { content: "\\eb20" }
.codicon-git-pull-request-milestone:before { content: "\\eb20" }
.codicon-mortar-board:before { content: "\\eb21" }
.codicon-move:before { content: "\\eb22" }
.codicon-multiple-windows:before { content: "\\eb23" }
.codicon-mute:before { content: "\\eb24" }
.codicon-no-newline:before { content: "\\eb25" }
.codicon-note:before { content: "\\eb26" }
.codicon-octoface:before { content: "\\eb27" }
.codicon-open-preview:before { content: "\\eb28" }
.codicon-package:before { content: "\\eb29" }
.codicon-paintcan:before { content: "\\eb2a" }
.codicon-pin:before { content: "\\eb2b" }
.codicon-play:before { content: "\\eb2c" }
.codicon-run:before { content: "\\eb2c" }
.codicon-plug:before { content: "\\eb2d" }
.codicon-preserve-case:before { content: "\\eb2e" }
.codicon-preview:before { content: "\\eb2f" }
.codicon-project:before { content: "\\eb30" }
.codicon-pulse:before { content: "\\eb31" }
.codicon-question:before { content: "\\eb32" }
.codicon-quote:before { content: "\\eb33" }
.codicon-radio-tower:before { content: "\\eb34" }
.codicon-reactions:before { content: "\\eb35" }
.codicon-references:before { content: "\\eb36" }
.codicon-refresh:before { content: "\\eb37" }
.codicon-regex:before { content: "\\eb38" }
.codicon-remote-explorer:before { content: "\\eb39" }
.codicon-remote:before { content: "\\eb3a" }
.codicon-remove:before { content: "\\eb3b" }
.codicon-replace-all:before { content: "\\eb3c" }
.codicon-replace:before { content: "\\eb3d" }
.codicon-repo-clone:before { content: "\\eb3e" }
.codicon-repo-force-push:before { content: "\\eb3f" }
.codicon-repo-pull:before { content: "\\eb40" }
.codicon-repo-push:before { content: "\\eb41" }
.codicon-report:before { content: "\\eb42" }
.codicon-request-changes:before { content: "\\eb43" }
.codicon-rocket:before { content: "\\eb44" }
.codicon-root-folder-opened:before { content: "\\eb45" }
.codicon-root-folder:before { content: "\\eb46" }
.codicon-rss:before { content: "\\eb47" }
.codicon-ruby:before { content: "\\eb48" }
.codicon-save-all:before { content: "\\eb49" }
.codicon-save-as:before { content: "\\eb4a" }
.codicon-save:before { content: "\\eb4b" }
.codicon-screen-full:before { content: "\\eb4c" }
.codicon-screen-normal:before { content: "\\eb4d" }
.codicon-search-stop:before { content: "\\eb4e" }
.codicon-server:before { content: "\\eb50" }
.codicon-settings-gear:before { content: "\\eb51" }
.codicon-settings:before { content: "\\eb52" }
.codicon-shield:before { content: "\\eb53" }
.codicon-smiley:before { content: "\\eb54" }
.codicon-sort-precedence:before { content: "\\eb55" }
.codicon-split-horizontal:before { content: "\\eb56" }
.codicon-split-vertical:before { content: "\\eb57" }
.codicon-squirrel:before { content: "\\eb58" }
.codicon-star-full:before { content: "\\eb59" }
.codicon-star-half:before { content: "\\eb5a" }
.codicon-symbol-class:before { content: "\\eb5b" }
.codicon-symbol-color:before { content: "\\eb5c" }
.codicon-symbol-constant:before { content: "\\eb5d" }
.codicon-symbol-enum-member:before { content: "\\eb5e" }
.codicon-symbol-field:before { content: "\\eb5f" }
.codicon-symbol-file:before { content: "\\eb60" }
.codicon-symbol-interface:before { content: "\\eb61" }
.codicon-symbol-keyword:before { content: "\\eb62" }
.codicon-symbol-misc:before { content: "\\eb63" }
.codicon-symbol-operator:before { content: "\\eb64" }
.codicon-symbol-property:before { content: "\\eb65" }
.codicon-wrench:before { content: "\\eb65" }
.codicon-wrench-subaction:before { content: "\\eb65" }
.codicon-symbol-snippet:before { content: "\\eb66" }
.codicon-tasklist:before { content: "\\eb67" }
.codicon-telescope:before { content: "\\eb68" }
.codicon-text-size:before { content: "\\eb69" }
.codicon-three-bars:before { content: "\\eb6a" }
.codicon-thumbsdown:before { content: "\\eb6b" }
.codicon-thumbsup:before { content: "\\eb6c" }
.codicon-tools:before { content: "\\eb6d" }
.codicon-triangle-down:before { content: "\\eb6e" }
.codicon-triangle-left:before { content: "\\eb6f" }
.codicon-triangle-right:before { content: "\\eb70" }
.codicon-triangle-up:before { content: "\\eb71" }
.codicon-twitter:before { content: "\\eb72" }
.codicon-unfold:before { content: "\\eb73" }
.codicon-unlock:before { content: "\\eb74" }
.codicon-unmute:before { content: "\\eb75" }
.codicon-unverified:before { content: "\\eb76" }
.codicon-verified:before { content: "\\eb77" }
.codicon-versions:before { content: "\\eb78" }
.codicon-vm-active:before { content: "\\eb79" }
.codicon-vm-outline:before { content: "\\eb7a" }
.codicon-vm-running:before { content: "\\eb7b" }
.codicon-watch:before { content: "\\eb7c" }
.codicon-whitespace:before { content: "\\eb7d" }
.codicon-whole-word:before { content: "\\eb7e" }
.codicon-window:before { content: "\\eb7f" }
.codicon-word-wrap:before { content: "\\eb80" }
.codicon-zoom-in:before { content: "\\eb81" }
.codicon-zoom-out:before { content: "\\eb82" }
.codicon-list-filter:before { content: "\\eb83" }
.codicon-list-flat:before { content: "\\eb84" }
.codicon-list-selection:before { content: "\\eb85" }
.codicon-selection:before { content: "\\eb85" }
.codicon-list-tree:before { content: "\\eb86" }
.codicon-debug-breakpoint-function-unverified:before { content: "\\eb87" }
.codicon-debug-breakpoint-function:before { content: "\\eb88" }
.codicon-debug-breakpoint-function-disabled:before { content: "\\eb88" }
.codicon-debug-stackframe-active:before { content: "\\eb89" }
.codicon-circle-small-filled:before { content: "\\eb8a" }
.codicon-debug-stackframe-dot:before { content: "\\eb8a" }
.codicon-terminal-decoration-mark:before { content: "\\eb8a" }
.codicon-debug-stackframe:before { content: "\\eb8b" }
.codicon-debug-stackframe-focused:before { content: "\\eb8b" }
.codicon-debug-breakpoint-unsupported:before { content: "\\eb8c" }
.codicon-symbol-string:before { content: "\\eb8d" }
.codicon-debug-reverse-continue:before { content: "\\eb8e" }
.codicon-debug-step-back:before { content: "\\eb8f" }
.codicon-debug-restart-frame:before { content: "\\eb90" }
.codicon-debug-alt:before { content: "\\eb91" }
.codicon-call-incoming:before { content: "\\eb92" }
.codicon-call-outgoing:before { content: "\\eb93" }
.codicon-menu:before { content: "\\eb94" }
.codicon-expand-all:before { content: "\\eb95" }
.codicon-feedback:before { content: "\\eb96" }
.codicon-git-pull-request-reviewer:before { content: "\\eb96" }
.codicon-group-by-ref-type:before { content: "\\eb97" }
.codicon-ungroup-by-ref-type:before { content: "\\eb98" }
.codicon-account:before { content: "\\eb99" }
.codicon-git-pull-request-assignee:before { content: "\\eb99" }
.codicon-bell-dot:before { content: "\\eb9a" }
.codicon-debug-console:before { content: "\\eb9b" }
.codicon-library:before { content: "\\eb9c" }
.codicon-output:before { content: "\\eb9d" }
.codicon-run-all:before { content: "\\eb9e" }
.codicon-sync-ignored:before { content: "\\eb9f" }
.codicon-pinned:before { content: "\\eba0" }
.codicon-github-inverted:before { content: "\\eba1" }
.codicon-server-process:before { content: "\\eba2" }
.codicon-server-environment:before { content: "\\eba3" }
.codicon-pass:before { content: "\\eba4" }
.codicon-issue-closed:before { content: "\\eba4" }
.codicon-stop-circle:before { content: "\\eba5" }
.codicon-play-circle:before { content: "\\eba6" }
.codicon-record:before { content: "\\eba7" }
.codicon-debug-alt-small:before { content: "\\eba8" }
.codicon-vm-connect:before { content: "\\eba9" }
.codicon-cloud:before { content: "\\ebaa" }
.codicon-merge:before { content: "\\ebab" }
.codicon-export:before { content: "\\ebac" }
.codicon-graph-left:before { content: "\\ebad" }
.codicon-magnet:before { content: "\\ebae" }
.codicon-notebook:before { content: "\\ebaf" }
.codicon-redo:before { content: "\\ebb0" }
.codicon-check-all:before { content: "\\ebb1" }
.codicon-pinned-dirty:before { content: "\\ebb2" }
.codicon-pass-filled:before { content: "\\ebb3" }
.codicon-circle-large-filled:before { content: "\\ebb4" }
.codicon-circle-large:before { content: "\\ebb5" }
.codicon-circle-large-outline:before { content: "\\ebb5" }
.codicon-combine:before { content: "\\ebb6" }
.codicon-gather:before { content: "\\ebb6" }
.codicon-table:before { content: "\\ebb7" }
.codicon-variable-group:before { content: "\\ebb8" }
.codicon-type-hierarchy:before { content: "\\ebb9" }
.codicon-type-hierarchy-sub:before { content: "\\ebba" }
.codicon-type-hierarchy-super:before { content: "\\ebbb" }
.codicon-git-pull-request-create:before { content: "\\ebbc" }
.codicon-run-above:before { content: "\\ebbd" }
.codicon-run-below:before { content: "\\ebbe" }
.codicon-notebook-template:before { content: "\\ebbf" }
.codicon-debug-rerun:before { content: "\\ebc0" }
.codicon-workspace-trusted:before { content: "\\ebc1" }
.codicon-workspace-untrusted:before { content: "\\ebc2" }
.codicon-workspace-unknown:before { content: "\\ebc3" }
.codicon-terminal-cmd:before { content: "\\ebc4" }
.codicon-terminal-debian:before { content: "\\ebc5" }
.codicon-terminal-linux:before { content: "\\ebc6" }
.codicon-terminal-powershell:before { content: "\\ebc7" }
.codicon-terminal-tmux:before { content: "\\ebc8" }
.codicon-terminal-ubuntu:before { content: "\\ebc9" }
.codicon-terminal-bash:before { content: "\\ebca" }
.codicon-arrow-swap:before { content: "\\ebcb" }
.codicon-copy:before { content: "\\ebcc" }
.codicon-person-add:before { content: "\\ebcd" }
.codicon-filter-filled:before { content: "\\ebce" }
.codicon-wand:before { content: "\\ebcf" }
.codicon-debug-line-by-line:before { content: "\\ebd0" }
.codicon-inspect:before { content: "\\ebd1" }
.codicon-layers:before { content: "\\ebd2" }
.codicon-layers-dot:before { content: "\\ebd3" }
.codicon-layers-active:before { content: "\\ebd4" }
.codicon-compass:before { content: "\\ebd5" }
.codicon-compass-dot:before { content: "\\ebd6" }
.codicon-compass-active:before { content: "\\ebd7" }
.codicon-azure:before { content: "\\ebd8" }
.codicon-issue-draft:before { content: "\\ebd9" }
.codicon-git-pull-request-closed:before { content: "\\ebda" }
.codicon-git-pull-request-draft:before { content: "\\ebdb" }
.codicon-debug-all:before { content: "\\ebdc" }
.codicon-debug-coverage:before { content: "\\ebdd" }
.codicon-run-errors:before { content: "\\ebde" }
.codicon-folder-library:before { content: "\\ebdf" }
.codicon-debug-continue-small:before { content: "\\ebe0" }
.codicon-beaker-stop:before { content: "\\ebe1" }
.codicon-graph-line:before { content: "\\ebe2" }
.codicon-graph-scatter:before { content: "\\ebe3" }
.codicon-pie-chart:before { content: "\\ebe4" }
.codicon-bracket-dot:before { content: "\\ebe5" }
.codicon-bracket-error:before { content: "\\ebe6" }
.codicon-lock-small:before { content: "\\ebe7" }
.codicon-azure-devops:before { content: "\\ebe8" }
.codicon-verified-filled:before { content: "\\ebe9" }
.codicon-newline:before { content: "\\ebea" }
.codicon-layout:before { content: "\\ebeb" }
.codicon-layout-activitybar-left:before { content: "\\ebec" }
.codicon-layout-activitybar-right:before { content: "\\ebed" }
.codicon-layout-panel-left:before { content: "\\ebee" }
.codicon-layout-panel-center:before { content: "\\ebef" }
.codicon-layout-panel-justify:before { content: "\\ebf0" }
.codicon-layout-panel-right:before { content: "\\ebf1" }
.codicon-layout-panel:before { content: "\\ebf2" }
.codicon-layout-sidebar-left:before { content: "\\ebf3" }
.codicon-layout-sidebar-right:before { content: "\\ebf4" }
.codicon-layout-statusbar:before { content: "\\ebf5" }
.codicon-layout-menubar:before { content: "\\ebf6" }
.codicon-layout-centered:before { content: "\\ebf7" }
.codicon-target:before { content: "\\ebf8" }
.codicon-indent:before { content: "\\ebf9" }
.codicon-record-small:before { content: "\\ebfa" }
.codicon-error-small:before { content: "\\ebfb" }
.codicon-terminal-decoration-error:before { content: "\\ebfb" }
.codicon-arrow-circle-down:before { content: "\\ebfc" }
.codicon-arrow-circle-left:before { content: "\\ebfd" }
.codicon-arrow-circle-right:before { content: "\\ebfe" }
.codicon-arrow-circle-up:before { content: "\\ebff" }
.codicon-layout-sidebar-right-off:before { content: "\\ec00" }
.codicon-layout-panel-off:before { content: "\\ec01" }
.codicon-layout-sidebar-left-off:before { content: "\\ec02" }
.codicon-blank:before { content: "\\ec03" }
.codicon-heart-filled:before { content: "\\ec04" }
.codicon-map:before { content: "\\ec05" }
.codicon-map-horizontal:before { content: "\\ec05" }
.codicon-fold-horizontal:before { content: "\\ec05" }
.codicon-map-filled:before { content: "\\ec06" }
.codicon-map-horizontal-filled:before { content: "\\ec06" }
.codicon-fold-horizontal-filled:before { content: "\\ec06" }
.codicon-circle-small:before { content: "\\ec07" }
.codicon-bell-slash:before { content: "\\ec08" }
.codicon-bell-slash-dot:before { content: "\\ec09" }
.codicon-comment-unresolved:before { content: "\\ec0a" }
.codicon-git-pull-request-go-to-changes:before { content: "\\ec0b" }
.codicon-git-pull-request-new-changes:before { content: "\\ec0c" }
.codicon-search-fuzzy:before { content: "\\ec0d" }
.codicon-comment-draft:before { content: "\\ec0e" }
.codicon-send:before { content: "\\ec0f" }
.codicon-sparkle:before { content: "\\ec10" }
.codicon-insert:before { content: "\\ec11" }
.codicon-mic:before { content: "\\ec12" }
.codicon-thumbsdown-filled:before { content: "\\ec13" }
.codicon-thumbsup-filled:before { content: "\\ec14" }
.codicon-coffee:before { content: "\\ec15" }
.codicon-snake:before { content: "\\ec16" }
.codicon-game:before { content: "\\ec17" }
.codicon-vr:before { content: "\\ec18" }
.codicon-chip:before { content: "\\ec19" }
.codicon-piano:before { content: "\\ec1a" }
.codicon-music:before { content: "\\ec1b" }
.codicon-mic-filled:before { content: "\\ec1c" }
.codicon-repo-fetch:before { content: "\\ec1d" }
.codicon-copilot:before { content: "\\ec1e" }
.codicon-lightbulb-sparkle:before { content: "\\ec1f" }
.codicon-robot:before { content: "\\ec20" }
.codicon-sparkle-filled:before { content: "\\ec21" }
.codicon-diff-single:before { content: "\\ec22" }
.codicon-diff-multiple:before { content: "\\ec23" }
.codicon-surround-with:before { content: "\\ec24" }
.codicon-share:before { content: "\\ec25" }
.codicon-git-stash:before { content: "\\ec26" }
.codicon-git-stash-apply:before { content: "\\ec27" }
.codicon-git-stash-pop:before { content: "\\ec28" }
.codicon-vscode:before { content: "\\ec29" }
.codicon-vscode-insiders:before { content: "\\ec2a" }
.codicon-code-oss:before { content: "\\ec2b" }
.codicon-run-coverage:before { content: "\\ec2c" }
.codicon-run-all-coverage:before { content: "\\ec2d" }
.codicon-coverage:before { content: "\\ec2e" }
.codicon-github-project:before { content: "\\ec2f" }
.codicon-map-vertical:before { content: "\\ec30" }
.codicon-fold-vertical:before { content: "\\ec30" }
.codicon-map-vertical-filled:before { content: "\\ec31" }
.codicon-fold-vertical-filled:before { content: "\\ec31" }
.codicon-go-to-search:before { content: "\\ec32" }
.codicon-percentage:before { content: "\\ec33" }
.codicon-sort-percentage:before { content: "\\ec33" }
.codicon-attach:before { content: "\\ec34" }
.codicon-go-to-editing-session:before { content: "\\ec35" }
.codicon-edit-session:before { content: "\\ec36" }
.codicon-code-review:before { content: "\\ec37" }
.codicon-copilot-warning:before { content: "\\ec38" }
.codicon-python:before { content: "\\ec39" }
.codicon-copilot-large:before { content: "\\ec3a" }
.codicon-copilot-warning-large:before { content: "\\ec3b" }
.codicon-keyboard-tab:before { content: "\\ec3c" }
.codicon-copilot-blocked:before { content: "\\ec3d" }
.codicon-copilot-not-connected:before { content: "\\ec3e" }
.codicon-flag:before { content: "\\ec3f" }
.codicon-lightbulb-empty:before { content: "\\ec40" }
.codicon-symbol-method-arrow:before { content: "\\ec41" }
.codicon-copilot-unavailable:before { content: "\\ec42" }
.codicon-repo-pinned:before { content: "\\ec43" }
.codicon-keyboard-tab-above:before { content: "\\ec44" }
.codicon-keyboard-tab-below:before { content: "\\ec45" }
.codicon-git-pull-request-done:before { content: "\\ec46" }
.codicon-mcp:before { content: "\\ec47" }
.codicon-extensions-large:before { content: "\\ec48" }
.codicon-layout-panel-dock:before { content: "\\ec49" }
.codicon-layout-sidebar-left-dock:before { content: "\\ec4a" }
.codicon-layout-sidebar-right-dock:before { content: "\\ec4b" }
.codicon-copilot-in-progress:before { content: "\\ec4c" }
.codicon-copilot-error:before { content: "\\ec4d" }
.codicon-copilot-success:before { content: "\\ec4e" }
.codicon-chat-sparkle:before { content: "\\ec4f" }
.codicon-search-sparkle:before { content: "\\ec50" }
.codicon-edit-sparkle:before { content: "\\ec51" }
.codicon-copilot-snooze:before { content: "\\ec52" }
.codicon-send-to-remote-agent:before { content: "\\ec53" }
.codicon-comment-discussion-sparkle:before { content: "\\ec54" }
.codicon-chat-sparkle-warning:before { content: "\\ec55" }
.codicon-chat-sparkle-error:before { content: "\\ec56" }
.codicon-collection:before { content: "\\ec57" }
.codicon-new-collection:before { content: "\\ec58" }
.codicon-thinking:before { content: "\\ec59" }
.codicon-build:before { content: "\\ec5a" }
.codicon-comment-discussion-quote:before { content: "\\ec5b" }
.codicon-cursor:before { content: "\\ec5c" }
.codicon-eraser:before { content: "\\ec5d" }
.codicon-file-text:before { content: "\\ec5e" }
.codicon-quotes:before { content: "\\ec60" }
.codicon-rename:before { content: "\\ec61" }
.codicon-run-with-deps:before { content: "\\ec62" }
.codicon-debug-connected:before { content: "\\ec63" }
.codicon-strikethrough:before { content: "\\ec64" }
.codicon-open-in-product:before { content: "\\ec65" }
.codicon-index-zero:before { content: "\\ec66" }
.codicon-agent:before { content: "\\ec67" }
.codicon-edit-code:before { content: "\\ec68" }
.codicon-repo-selected:before { content: "\\ec69" }
.codicon-skip:before { content: "\\ec6a" }
.codicon-merge-into:before { content: "\\ec6b" }
.codicon-git-branch-changes:before { content: "\\ec6c" }
.codicon-git-branch-staged-changes:before { content: "\\ec6d" }
.codicon-git-branch-conflicts:before { content: "\\ec6e" }
.codicon-git-branch:before { content: "\\ec6f" }
.codicon-git-branch-create:before { content: "\\ec6f" }
.codicon-git-branch-delete:before { content: "\\ec6f" }
.codicon-search-large:before { content: "\\ec70" }
.codicon-terminal-git-bash:before { content: "\\ec71" }
.codicon-window-active:before { content: "\\ec72" }
.codicon-forward:before { content: "\\ec73" }
.codicon-download:before { content: "\\ec74" }
.codicon-clockface:before { content: "\\ec75" }
.codicon-unarchive:before { content: "\\ec76" }
.codicon-session-in-progress:before { content: "\\ec77" }
.codicon-collection-small:before { content: "\\ec78" }
.codicon-vm-small:before { content: "\\ec79" }
.codicon-cloud-small:before { content: "\\ec7a" }
.codicon-add-small:before { content: "\\ec7b" }
.codicon-remove-small:before { content: "\\ec7c" }
.codicon-worktree-small:before { content: "\\ec7d" }
.codicon-worktree:before { content: "\\ec7e" }
.codicon-screen-cut:before { content: "\\ec7f" }
.codicon-ask:before { content: "\\ec80" }
.codicon-openai:before { content: "\\ec81" }
.codicon-claude:before { content: "\\ec82" }
.codicon-open-in-window:before { content: "\\ec83" }
.codicon-new-session:before { content: "\\ec84" }
.codicon-terminal-secure:before { content: "\\ec85" }
.codicon-chat-import:before { content: "\\ec86" }
.codicon-chat-export:before { content: "\\ec87" }
.codicon-share-window:before { content: "\\ec88" }
.codicon-circle-slash-compact:before { content: "\\ec89" }
.codicon-copilot-compact:before { content: "\\ec8a" }
.codicon-folder-opened-compact:before { content: "\\ec8b" }
.codicon-folder-compact:before { content: "\\ec8c" }
.codicon-gear-compact:before { content: "\\ec8d" }
.codicon-git-branch-compact:before { content: "\\ec8e" }
.codicon-library-compact:before { content: "\\ec8f" }
.codicon-record-keys-compact:before { content: "\\ec90" }
.codicon-remote-compact:before { content: "\\ec91" }
.codicon-repo-forked-compact:before { content: "\\ec92" }
.codicon-repo-compact:before { content: "\\ec93" }
.codicon-shield-compact:before { content: "\\ec94" }
.codicon-sparkle-compact:before { content: "\\ec95" }
.codicon-symbol-color-compact:before { content: "\\ec96" }
.codicon-window-compact:before { content: "\\ec97" }
.codicon-error-compact:before { content: "\\ec98" }
.codicon-warning-compact:before { content: "\\ec99" }
.codicon-pass-compact:before { content: "\\ec9a" }
.codicon-important:before { content: "\\ec9b" }
.codicon-important-compact:before { content: "\\ec9c" }
.codicon-rocket-compact:before { content: "\\ec9d" }
.codicon-unpin:before { content: "\\ec9e" }
.codicon-add-compact:before { content: "\\ec9f" }
.codicon-attach-compact:before { content: "\\eca0" }
.codicon-beaker-compact:before { content: "\\eca1" }
.codicon-check-compact:before { content: "\\eca2" }
.codicon-checklist-compact:before { content: "\\eca3" }
.codicon-chevron-down-compact:before { content: "\\eca4" }
.codicon-chevron-left-compact:before { content: "\\eca5" }
.codicon-chevron-right-compact:before { content: "\\eca6" }
.codicon-chevron-up-compact:before { content: "\\eca7" }
.codicon-circle-filled-compact:before { content: "\\eca8" }
.codicon-circle-small-filled-compact:before { content: "\\eca9" }
.codicon-close-compact:before { content: "\\ecaa" }
.codicon-collapse-all-compact:before { content: "\\ecab" }
.codicon-comment-compact:before { content: "\\ecac" }
.codicon-comment-unresolved-compact:before { content: "\\ecad" }
.codicon-debug-connected-compact:before { content: "\\ecae" }
.codicon-debug-disconnect-compact:before { content: "\\ecaf" }
.codicon-edit-compact:before { content: "\\ecb0" }
.codicon-file-media-compact:before { content: "\\ecb1" }
.codicon-git-fetch:before { content: "\\ecb2" }
.codicon-lightbulb-compact:before { content: "\\ecb3" }
.codicon-loading-compact:before { content: "\\ecb4" }
.codicon-pass-filled-compact:before { content: "\\ecb5" }
.codicon-project-compact:before { content: "\\ecb6" }
.codicon-refresh-compact:before { content: "\\ecb7" }
.codicon-search-compact:before { content: "\\ecb8" }
.codicon-session-in-progress-compact:before { content: "\\ecb9" }
.codicon-sync-compact:before { content: "\\ecba" }
.codicon-terminal-compact:before { content: "\\ecbb" }
.codicon-vm-pending:before { content: "\\ecbc" }
.codicon-worktree-compact:before { content: "\\ecbd" }
.codicon-developer-tools:before { content: "\\ecbe" }
.codicon-cloud-compact:before { content: "\\ecbf" }
.codicon-agent-compact:before { content: "\\ecc0" }
.codicon-ask-compact:before { content: "\\ecc1" }
.codicon-settings-compact:before { content: "\\ecc2" }
.codicon-vm-compact:before { content: "\\ecc3" }
.codicon-run-compact:before { content: "\\ecc4" }
.codicon-git-pull-request-comment:before { content: "\\ecc5" }
.codicon-git-pull-request-error:before { content: "\\ecc6" }
.codicon-right-panel-hide:before { content: "\\ecc7" }
.codicon-right-panel-show:before { content: "\\ecc8" }
.codicon-vscode-insiders-outline:before { content: "\\ecc9" }
.codicon-vscode-outline:before { content: "\\ecca" }
.codicon-voice-mode:before { content: "\\eccb" }
.codicon-voice-mode-compact:before { content: "\\eccc" }
.codicon-mic-download:before { content: "\\eccd" }
.codicon-mic-download-compact:before { content: "\\ecce" }
.codicon-voice-mode-download:before { content: "\\eccf" }
.codicon-voice-mode-download-compact:before { content: "\\ecd0" }
.codicon-google-gemini:before { content: "\\ecd1" }
.codicon-kimi:before { content: "\\ecd2" }
.codicon-microsoft:before { content: "\\ecd3" }
.codicon-fish1-happy:before { content: "\\ecd4" }
.codicon-fish1-neutral:before { content: "\\ecd5" }
.codicon-fish1-sad:before { content: "\\ecd6" }
.codicon-fish1-very-sad:before { content: "\\ecd7" }
.codicon-fish2-happy:before { content: "\\ecd8" }
.codicon-fish2-neutral:before { content: "\\ecd9" }
.codicon-fish2-sad:before { content: "\\ecda" }
.codicon-fish2-very-sad:before { content: "\\ecdb" }
.codicon-fish3-happy:before { content: "\\ecdc" }
.codicon-fish3-neutral:before { content: "\\ecdd" }
.codicon-fish3-sad:before { content: "\\ecde" }
.codicon-fish3-very-sad:before { content: "\\ecdf" }
.codicon-fish4-happy:before { content: "\\ece0" }
.codicon-fish4-neutral:before { content: "\\ece1" }
.codicon-fish4-sad:before { content: "\\ece2" }
.codicon-fish4-very-sad:before { content: "\\ece3" }
.codicon-person-voice:before { content: "\\ece4" }
.codicon-person-voice-compact:before { content: "\\ece5" }
.codicon-person-voice-filled:before { content: "\\ece6" }
.codicon-person-voice-filled-compact:before { content: "\\ece7" }
`;var $p=`/* The Inkspect design system: tokens and the shared components (buttons, fields, selects,
   switches, sliders, color picker, menus, toast, drawing toolbar and layer).
   Colors come from VS Code theme variables; hosts outside VS Code define them (theme.css).
   Every surface uses the tokens below, so sizes, radii and elevation stay consistent. */

:root,
:host {
  /* Shape */
  --ink-radius-sm: 4px;
  --ink-radius: 6px;
  --ink-radius-lg: 10px;
  --ink-radius-pill: 999px;
  /* Controls */
  --ink-control-sm: 24px;
  --ink-control: 28px;
  --ink-control-lg: 36px;
  /* Spacing */
  --ink-space-1: 4px;
  --ink-space-2: 8px;
  --ink-space-3: 12px;
  --ink-space-4: 16px;
  --ink-space-5: 24px;
  --ink-space-6: 32px;
  /* Type */
  --ink-font-xs: 11px;
  --ink-font-sm: 12px;
  --ink-font: var(--vscode-font-size, 13px);
  --ink-font-lg: 15px;
  --ink-font-xl: 22px;
  /* Surfaces and lines */
  --ink-surface: var(--vscode-editorWidget-background, var(--vscode-editor-background));
  /* Popups: lifted off the menu background, since many dark themes (Tokyo Night) give menus the
     sidebar's own color, a border the same near-black, and no shadow at all. */
  --ink-surface-raised: color-mix(
    in srgb,
    var(--vscode-foreground, #888) 7%,
    var(--vscode-menu-background, var(--ink-surface))
  );
  --ink-surface-sunken: color-mix(in srgb, var(--vscode-foreground, #888) 4%, transparent);
  --ink-border: var(--vscode-widget-border, rgba(128, 128, 128, 0.35));
  --ink-border-subtle: color-mix(in srgb, var(--vscode-foreground, #888) 10%, transparent);
  --ink-border-strong: color-mix(in srgb, var(--vscode-foreground, #888) 22%, transparent);
  --ink-hover: var(--vscode-toolbar-hoverBackground, rgba(128, 128, 128, 0.18));
  --ink-pressed: var(--vscode-toolbar-activeBackground, rgba(128, 128, 128, 0.26));
  /* Focus rings follow the theme's focus border; accents use the button color, which themes keep
     vivid (the focus border can be very dim). Text on tinted backgrounds uses the link color. */
  --ink-focus: var(--vscode-focusBorder, #0078d4);
  --ink-accent: var(--vscode-button-background, var(--ink-focus));
  --ink-accent-fg: var(--vscode-textLink-foreground, var(--ink-accent));
  --ink-accent-soft: color-mix(in srgb, var(--ink-accent) 20%, transparent);
  /* Secondary text, pulled toward the foreground so it stays readable in low-contrast themes. */
  --ink-muted: color-mix(
    in srgb,
    var(--vscode-descriptionForeground, #9d9d9d) 70%,
    var(--vscode-foreground, #ccc)
  );
  --ink-danger: var(--vscode-errorForeground, #f85149);
  --ink-success: var(--vscode-testing-iconPassed, #73c991);
  --ink-warning: var(--vscode-editorWarning-foreground, #cca700);
  /* The theme's own palette. Every theme defines its terminal ANSI colors, and they are its true
     hues (Tokyo Night's are #7aa2f7, #9ece6a, #e0af68, #f7768e, #bb9af7), unlike button and
     error colors, which some themes keep dim. Pulled slightly toward the foreground so they stay
     readable as text on both light and dark backgrounds. */
  --ink-blue: color-mix(
    in srgb,
    var(--vscode-terminal-ansiBlue, #3b8eea) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-green: color-mix(
    in srgb,
    var(--vscode-terminal-ansiGreen, #23d18b) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-yellow: color-mix(
    in srgb,
    var(--vscode-terminal-ansiYellow, #e5e510) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-red: color-mix(
    in srgb,
    var(--vscode-terminal-ansiRed, #f14c4c) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-magenta: color-mix(
    in srgb,
    var(--vscode-terminal-ansiMagenta, #d670d6) 88%,
    var(--vscode-foreground, #888)
  );
  /* Elevation */
  /* Half the theme's widget shadow, half plain black: some themes make theirs transparent. */
  --ink-shadow-color: color-mix(
    in srgb,
    var(--vscode-widget-shadow, rgba(0, 0, 0, 0.3)) 50%,
    rgba(0, 0, 0, 0.5)
  );
  --ink-shadow-sm: 0 1px 3px var(--ink-shadow-color);
  --ink-shadow: 0 6px 20px var(--ink-shadow-color), 0 1px 4px var(--ink-shadow-color);
  --ink-shadow-lg: 0 12px 32px var(--ink-shadow-color), 0 2px 8px var(--ink-shadow-color);
  /* Motion */
  --ink-ease: cubic-bezier(0.2, 0, 0, 1);
  --ink-fast: 90ms;
  --ink-normal: 160ms;
}

/* Focus ------------------------------------------------------------------------------------ */

.icon-button:focus-visible,
.button:focus-visible,
.link-button:focus-visible,
.menu-item:focus-visible,
.select:focus-visible,
.switch:focus-visible,
.checkbox:focus-visible,
.segment:focus-visible,
.slider-track:focus-visible,
.swatch:focus-visible,
.color-area:focus-visible,
.color-hue:focus-visible,
.chip:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: 1px;
}

/* Icon buttons ----------------------------------------------------------------------------- */

.icon-button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: var(--ink-control);
  height: var(--ink-control);
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--vscode-icon-foreground, var(--vscode-foreground));
  font: inherit;
  cursor: pointer;
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.icon-button.small {
  width: var(--ink-control-sm);
  height: var(--ink-control-sm);
}

.icon-button:hover:not(:disabled) {
  background: var(--ink-hover);
}

.icon-button:active:not(:disabled) {
  background: var(--ink-pressed);
}

.icon-button.active {
  background: var(--ink-accent-soft);
  color: var(--vscode-inputOption-activeForeground, var(--vscode-foreground));
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--ink-accent) 60%, transparent);
}

.icon-button:disabled {
  opacity: 0.4;
  cursor: default;
}

/* Buttons ---------------------------------------------------------------------------------- */

.button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: var(--ink-control);
  padding: 0 12px;
  border: 1px solid var(--vscode-button-border, transparent);
  border-radius: var(--ink-radius-sm);
  font: inherit;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.button.small {
  gap: 4px;
  height: var(--ink-control-sm);
  padding: 0 8px;
}

.button .codicon {
  font-size: 14px;
}

.button.primary {
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.primary:hover:not(:disabled) {
  background: var(--vscode-button-hoverBackground);
}

.button.secondary {
  background: var(--vscode-button-secondaryBackground);
  color: var(--vscode-button-secondaryForeground);
}

.button.secondary:hover:not(:disabled) {
  background: var(--vscode-button-secondaryHoverBackground);
}

.button.ghost {
  border-color: transparent;
  background: transparent;
  color: inherit;
}

.button.ghost:hover:not(:disabled) {
  background: var(--ink-hover);
}

/* A solid call to action in the theme's own blue (its palette, see --ink-blue), for themes whose
   button color is dim. Dark text on dark themes, where the palette's blue is light. */
.button.accent {
  border-color: transparent;
  background: var(--ink-blue);
  color: var(--vscode-editor-background, #fff);
  font-weight: 600;
}

.button.accent:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-blue) 85%, var(--vscode-foreground, #fff));
}

body.vscode-light .button.accent {
  color: #fff;
}

body.vscode-high-contrast .button.accent {
  border-color: var(--vscode-contrastBorder, transparent);
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.danger {
  border-color: color-mix(in srgb, var(--ink-danger) 45%, transparent);
  background: transparent;
  color: var(--ink-danger);
}

.button.danger:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-danger) 12%, transparent);
}

.button:disabled {
  opacity: 0.5;
  cursor: default;
}

.link-button {
  padding: 0;
  border: none;
  background: none;
  color: var(--vscode-textLink-foreground);
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.link-button:hover:not(:disabled) {
  color: var(--vscode-textLink-activeForeground, var(--vscode-textLink-foreground));
  text-decoration: underline;
}

.link-button:disabled {
  color: inherit;
  cursor: default;
}

.link-button.danger {
  color: var(--ink-danger);
}

/* Text fields ------------------------------------------------------------------------------ */

.text-field {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: var(--ink-control);
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  transition: border-color var(--ink-fast) var(--ink-ease);
}

.text-field.size-sm {
  height: var(--ink-control-sm);
  padding: 0 6px;
}

.text-field.size-lg {
  height: var(--ink-control-lg);
  padding: 0 12px;
  border-radius: var(--ink-radius);
}

.text-field:hover:not(.disabled) {
  border-color: var(--ink-border-strong);
}

.text-field:focus-within {
  border-color: var(--ink-focus);
  box-shadow: 0 0 0 1px var(--ink-focus);
}

.text-field.invalid {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.text-field.disabled {
  opacity: 0.5;
}

.text-field input {
  flex: 1;
  width: 100%;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: none;
  outline: none;
  background: transparent;
  color: inherit;
  font: inherit;
}

.text-field input::placeholder {
  color: var(--vscode-input-placeholderForeground, var(--ink-muted));
}

/* Numbers: no spinner arrows (the fields accept typing and arrow keys). */
.text-field input::-webkit-outer-spin-button,
.text-field input::-webkit-inner-spin-button {
  margin: 0;
  appearance: none;
}

.text-field input[type='number'] {
  appearance: textfield;
  font-variant-numeric: tabular-nums;
}

.text-field input[type='search']::-webkit-search-cancel-button {
  appearance: none;
}

.text-field-icon {
  flex-shrink: 0;
  color: var(--ink-muted);
}

.text-field-clear {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.text-field-clear:hover {
  background: var(--ink-hover);
  color: inherit;
}

/* Form rows -------------------------------------------------------------------------------- */

.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: var(--ink-space-3);
}

.field.inline {
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ink-space-3);
}

.field-label {
  color: var(--vscode-foreground);
  font-weight: 600;
}

.field.inline .field-label {
  font-weight: normal;
}

.field-control {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  min-width: 0;
}

.field-control > .text-field,
.field-control > .select {
  flex: 1;
}

.field-hint {
  flex-basis: 100%;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.field-hint.error {
  color: var(--ink-danger);
}

/* Select ----------------------------------------------------------------------------------- */

.select {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  height: var(--ink-control);
  padding: 0 6px 0 8px;
  border: 1px solid var(--vscode-dropdown-border, var(--vscode-input-border, var(--ink-border)));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-dropdown-background, var(--vscode-input-background));
  color: var(--vscode-dropdown-foreground, var(--vscode-input-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.select.size-sm {
  height: var(--ink-control-sm);
  padding: 0 4px 0 6px;
}

.select:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
}

.select.open {
  border-color: var(--ink-focus);
}

.select.quiet {
  border-color: transparent;
  background: transparent;
}

.select.quiet:hover:not(:disabled),
.select.quiet.open {
  border-color: transparent;
  background: var(--ink-hover);
}

.select:disabled {
  opacity: 0.45;
  cursor: default;
}

.select-value {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.select-value.placeholder {
  color: var(--ink-muted);
}

.select-chevron {
  flex-shrink: 0;
  font-size: 14px !important;
  opacity: 0.8;
  transition: transform var(--ink-normal) var(--ink-ease);
}

.select.open .select-chevron {
  transform: rotate(180deg);
}

.select-list,
.color-picker,
.menu,
.popover {
  background: var(--ink-surface-raised);
  color: var(--vscode-menu-foreground, var(--vscode-foreground));
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow);
}

.select-list {
  position: fixed;
  z-index: 1000;
  max-height: min(340px, 60vh);
  padding: 4px;
  overflow-y: auto;
  outline: none;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.select-group {
  padding: 8px 8px 4px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.select-group:first-child {
  padding-top: 4px;
}

.select-option {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px 0 4px;
  border-radius: var(--ink-radius-sm);
  white-space: nowrap;
  cursor: pointer;
}

.select-option.active {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
}

.select-option.disabled {
  opacity: 0.45;
  cursor: default;
}

.select-check {
  flex-shrink: 0;
  font-size: 14px !important;
}

.select-option-label {
  flex: 1;
}

.select-option-detail {
  margin-left: 16px;
  opacity: 0.65;
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Switch and checkbox ---------------------------------------------------------------------- */

.switch,
.checkbox {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: var(--ink-space-2);
  padding: 2px 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.switch:disabled,
.checkbox:disabled {
  opacity: 0.45;
  cursor: default;
}

.switch-track {
  position: relative;
  flex-shrink: 0;
  width: 30px;
  height: 16px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-input-background, var(--ink-surface-sunken));
  transition:
    background-color var(--ink-normal) var(--ink-ease),
    border-color var(--ink-normal) var(--ink-ease);
}

.switch-thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--ink-muted);
  transition:
    transform var(--ink-normal) var(--ink-ease),
    background-color var(--ink-normal) var(--ink-ease);
}

.switch.on .switch-track {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
}

.switch.on .switch-thumb {
  background: var(--vscode-button-foreground, #fff);
  transform: translateX(14px);
}

.checkbox-box {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border: 1px solid var(--vscode-checkbox-border, var(--ink-border-strong));
  border-radius: 3px;
  background: var(--vscode-checkbox-background, var(--vscode-input-background));
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.checkbox.on .checkbox-box {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
  color: var(--vscode-button-foreground, #fff);
}

.checkbox-box .codicon {
  font-size: 14px !important;
}

/* Segmented control ------------------------------------------------------------------------ */

.segmented {
  display: inline-flex;
  flex-shrink: 0;
  gap: 2px;
  height: var(--ink-control);
  padding: 2px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
}

.segmented.size-sm {
  height: var(--ink-control-sm);
  padding: 1px;
  border-radius: var(--ink-radius-sm);
}

.segment {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  gap: 5px;
  min-width: 26px;
  padding: 0 10px;
  border: none;
  border-radius: calc(var(--ink-radius) - 2px);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    color var(--ink-fast) var(--ink-ease);
}

.segmented.size-sm .segment {
  padding: 0 8px;
  border-radius: 3px;
}

.segment:hover {
  color: var(--vscode-foreground);
}

.segment.checked {
  background: var(--vscode-button-secondaryBackground, var(--ink-hover));
  color: var(--vscode-button-secondaryForeground, var(--vscode-foreground));
  box-shadow: var(--ink-shadow-sm);
}

.segment-count {
  min-width: 16px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
  text-align: center;
}

.segment-count.error {
  background: var(--ink-danger);
  color: #fff;
}

/* Slider ----------------------------------------------------------------------------------- */

.slider {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  height: var(--ink-control);
}

.slider.disabled {
  opacity: 0.45;
}

.slider > .codicon {
  color: var(--ink-muted);
}

.slider-track {
  position: relative;
  width: 84px;
  height: 18px;
  cursor: pointer;
  touch-action: none;
  border-radius: var(--ink-radius-sm);
}

.slider-track::before,
.slider-fill {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  height: 4px;
  border-radius: var(--ink-radius-pill);
  transform: translateY(-50%);
}

.slider-track::before {
  right: 0;
  background: var(--ink-border-strong);
}

.slider-fill {
  background: var(--ink-accent);
}

.slider-thumb {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid var(--ink-accent);
  border-radius: 50%;
  background: var(--vscode-editor-background, #fff);
  box-shadow: var(--ink-shadow-sm);
  transform: translate(-50%, -50%);
  transition: transform var(--ink-fast) var(--ink-ease);
}

.slider-track:hover .slider-thumb,
.slider-track:active .slider-thumb {
  transform: translate(-50%, -50%) scale(1.15);
}

.slider-value {
  min-width: 34px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Swatches and color picker ---------------------------------------------------------------- */

.swatch {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  padding: 0;
  border: 1px solid color-mix(in srgb, var(--vscode-foreground, #888) 30%, transparent);
  border-radius: 50%;
  cursor: pointer;
  transition: transform var(--ink-fast) var(--ink-ease);
}

.swatch:hover {
  transform: scale(1.12);
}

.swatch.small {
  width: 16px;
  height: 16px;
}

.swatch.active {
  box-shadow:
    0 0 0 2px var(--ink-surface),
    0 0 0 3.5px var(--ink-accent);
}

.color-picker-trigger {
  background: conic-gradient(
    from 90deg,
    #f43f5e,
    #f59e0b,
    #84cc16,
    #06b6d4,
    #6366f1,
    #d946ef,
    #f43f5e
  );
}

.color-picker {
  position: fixed;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 224px;
  padding: 10px;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.color-area {
  position: relative;
  height: 140px;
  border-radius: var(--ink-radius-sm);
  background-image:
    linear-gradient(to top, #000, transparent), linear-gradient(to right, #fff, transparent) !important;
  cursor: crosshair;
  touch-action: none;
}

.color-hue {
  position: relative;
  height: 12px;
  border-radius: var(--ink-radius-pill);
  background: linear-gradient(
    to right,
    #f00 0%,
    #ff0 17%,
    #0f0 33%,
    #0ff 50%,
    #00f 67%,
    #f0f 83%,
    #f00 100%
  );
  cursor: pointer;
  touch-action: none;
}

.color-handle {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.35),
    0 1px 4px rgba(0, 0, 0, 0.4);
  transform: translate(-50%, -50%);
  pointer-events: none;
}

.color-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.color-preview {
  flex-shrink: 0;
  width: 26px;
  height: 26px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
}

.color-hex {
  flex: 1;
  min-width: 0;
  height: 26px;
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  outline: none;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-sm);
  text-transform: lowercase;
}

.color-hex:focus {
  border-color: var(--ink-focus);
}

.color-presets {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  padding-top: 8px;
  border-top: 1px solid var(--ink-border-subtle);
}

/* Chips and badges ------------------------------------------------------------------------- */

.badge {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 7px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  white-space: nowrap;
}

.badge.outline {
  border: 1px solid var(--ink-border-strong);
  background: transparent;
  color: var(--ink-muted);
}

.badge.success {
  background: color-mix(in srgb, var(--ink-success) 18%, transparent);
  color: var(--ink-success);
}

.badge.danger {
  background: color-mix(in srgb, var(--ink-danger) 18%, transparent);
  color: var(--ink-danger);
}

/* Key caps (shortcuts) --------------------------------------------------------------------- */

.keycaps {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 3px;
}

.keycap {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border: 1px solid var(--vscode-keybindingLabel-border, var(--ink-border-strong));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-keybindingLabel-background, var(--ink-surface-sunken));
  box-shadow: inset 0 -1px 0 var(--vscode-keybindingLabel-bottomBorder, var(--ink-border-strong));
  color: var(--vscode-keybindingLabel-foreground, var(--vscode-foreground));
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  line-height: 1;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.keycaps.size-sm .keycap {
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  font-size: 10.5px;
}

/* Cards ------------------------------------------------------------------------------------ */

.card {
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--ink-surface-sunken);
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--ink-space-3);
  padding: var(--ink-space-3) var(--ink-space-4);
  border-bottom: 1px solid var(--ink-border-subtle);
}

.card-title {
  margin: 0;
  font-size: var(--ink-font);
  font-weight: 600;
}

.card-body {
  padding: var(--ink-space-4);
}

.card-row {
  display: flex;
  align-items: center;
  gap: var(--ink-space-4);
  padding: var(--ink-space-3) var(--ink-space-4);
}

.card-row + .card-row {
  border-top: 1px solid var(--ink-border-subtle);
}

.card-row-text {
  flex: 1;
  min-width: 0;
}

.card-row-title {
  font-weight: 500;
}

.card-row-description {
  margin-top: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

/* Menus and popovers ----------------------------------------------------------------------- */

.menu,
.popover {
  position: fixed;
  z-index: 100;
  min-width: 200px;
  max-width: 420px;
  padding: 4px;
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

/* Long menus (a big bookmarks folder) stay short and scroll, like Chrome's. Items have a little
   room between them. */
.menu {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 5px;
  max-height: min(420px, calc(100vh - 8px));
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Submenus open without the pop animation, so they don't jump while the pointer moves. */
.menu .menu {
  animation: none;
}

.menu-item.expanded:not(:focus) {
  background: var(--ink-hover);
}

.menu-image {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  object-fit: contain;
}

.menu-arrow {
  margin-left: 12px;
  margin-right: -2px;
  opacity: 0.8;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  width: 100%;
  height: 28px;
  padding: 0 10px 0 8px;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.menu-item:hover:not(:disabled),
.menu-item:focus {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
  outline: none;
}

.menu-item:disabled {
  opacity: 0.45;
  cursor: default;
}

.menu-label {
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.menu-shortcut {
  margin-left: 16px;
  opacity: 0.7;
  font-size: 0.9em;
}

.menu-separator {
  flex-shrink: 0;
  height: 1px;
  margin: 3px 6px;
  background: var(--vscode-menu-separatorBackground, var(--ink-border));
}

/* Toast ------------------------------------------------------------------------------------ */

.toast {
  position: fixed;
  bottom: 16px;
  left: 50%;
  z-index: 200;
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: calc(100% - 32px);
  padding: 8px 14px;
  transform: translateX(-50%);
  background: var(--vscode-notifications-background, var(--ink-surface));
  color: var(--vscode-notifications-foreground, var(--vscode-foreground));
  border: 1px solid var(--vscode-notifications-border, var(--ink-border));
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow-lg);
  animation: toast-in var(--ink-normal) var(--ink-ease);
}

/* A failure: marked as one, longer on screen, and dismissible. */
.toast.error {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.toast.error > .codicon-error {
  flex-shrink: 0;
  color: var(--ink-danger);
}

.toast .toast-dismiss {
  flex-shrink: 0;
  margin: -4px -8px -4px 0;
}

.header-actions,
.button-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
}

/* Drawing ---------------------------------------------------------------------------------- */

.draw-toolbar {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  padding: 4px 8px;
  background: var(--ink-surface);
  border-top: 1px solid var(--ink-border);
  border-bottom: 1px solid var(--ink-border);
}

.draw-group {
  display: flex;
  align-items: center;
  gap: 2px;
  padding-right: 6px;
  border-right: 1px solid var(--ink-border-subtle);
}

.draw-group.colors {
  gap: 6px;
  padding: 0 8px 0 4px;
}

.draw-capture {
  margin-left: 2px;
}

.draw-close {
  margin-left: auto;
}

.drawing-layer {
  position: absolute;
  z-index: 3;
}

.drawing-layer canvas {
  position: relative;
  display: block;
  touch-action: none;
}

/* A live redaction (liveRedactions): blurs the page behind it, under the drawing canvas. Drawn
   over page content, so its colors are fixed. */
.drawing-redaction {
  position: absolute;
  pointer-events: none;
  background: rgba(128, 128, 128, 0.2);
  backdrop-filter: blur(12px) saturate(0.5);
}

.drawing-text-input {
  position: absolute;
  min-width: 160px;
  min-height: 1.6em;
  padding: 2px 4px;
  border: 1px dashed var(--ink-accent);
  background: rgba(255, 255, 255, 0.85);
  font-family: system-ui, sans-serif;
  font-weight: 600;
  resize: both;
  outline: none;
}

/* Motion ----------------------------------------------------------------------------------- */

@keyframes ink-pop-in {
  from {
    opacity: 0;
    transform: translateY(-3px) scale(0.985);
  }
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translate(-50%, 8px);
  }
}

@media (prefers-reduced-motion: reduce) {
  .select-list,
  .color-picker,
  .menu,
  .popover,
  .toast {
    animation: none;
  }
}

/* Shortcut list (ShortcutList) ------------------------------------------------------------- */

.shortcuts-warning {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 12px 8px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

/* Groups: a pinned header per mode. */
.group-header {
  position: sticky;
  top: var(--shortcut-sticky-top, 0);
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  height: 28px;
  padding: 0 12px 0 6px;
  border: none;
  border-top: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  color: var(--vscode-sideBarSectionHeader-foreground, var(--vscode-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.group-header:hover {
  background: var(--vscode-list-hoverBackground);
}

.group-header:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.group-icon {
  color: var(--ink-accent-fg);
}

.group-title {
  font-size: var(--ink-font-xs);
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.group-count {
  margin-left: auto;
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
}

/* Rows: label, then actions (on hover), then the keys in a right-aligned column. */
.shortcut-item {
  position: relative;
  padding: 0 12px 0 32px;
  border-radius: var(--ink-radius);
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.shortcut-item::before {
  content: '';
  position: absolute;
  top: 6px;
  bottom: 6px;
  left: 20px;
  width: 2px;
  border-radius: 1px;
  background: transparent;
}

.shortcut-item.changed::before {
  background: var(--ink-accent);
}

.shortcut-item.conflict::before {
  background: var(--ink-warning);
}

/* Outside VS Code (the browser extension) there is no list hover color: the kit's hover. */
.shortcut-item:hover,
.shortcut-item:focus-within {
  background: var(--vscode-list-hoverBackground, var(--ink-hover));
}

body.vscode-high-contrast .shortcut-item:hover,
body.vscode-high-contrast .shortcut-item:focus-within {
  outline: 1px dashed var(--vscode-contrastActiveBorder);
  outline-offset: -1px;
}

.shortcut-main {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 30px;
}

.shortcut-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Where a key works: VS (VS Code Browser) and BR (the browser toolbar), and the browser's own key. */
.shortcut-places {
  display: inline-flex;
  flex-shrink: 0;
  gap: 3px;
}

.shortcut-tag {
  --tag: var(--ink-muted);
  flex-shrink: 0;
  min-width: 22px;
  padding: 0 4px;
  border: 1px solid color-mix(in srgb, var(--tag) 40%, transparent);
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--tag) 10%, transparent);
  color: var(--tag);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 14px;
  text-align: center;
  letter-spacing: 0.02em;
}

.shortcut-tag.vs {
  --tag: var(--ink-blue);
}

.shortcut-tag.br {
  --tag: var(--ink-green);
}

body.vscode-high-contrast .shortcut-tag {
  border-color: var(--vscode-contrastBorder);
  background: transparent;
  color: var(--vscode-foreground);
}

.shortcut-item.changed .shortcut-label {
  font-weight: 500;
}

.shortcut-actions {
  display: inline-flex;
  flex-shrink: 0;
  justify-content: flex-end;
  gap: 1px;
  /* Room for both buttons (reset, add a key) in every row, so the columns line up. */
  min-width: calc(2 * var(--ink-control-sm) + 1px);
  opacity: 0;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.shortcut-item:hover .shortcut-actions,
.shortcut-item:focus-within .shortcut-actions {
  opacity: 1;
}

.shortcut-keys-column {
  display: inline-flex;
  flex-wrap: wrap;
  flex-shrink: 0;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  /* A steady width, so the VS/BR tags before it line up from row to row. */
  min-width: min(184px, 40%);
  max-width: 62%;
}

.key-button-wrap {
  position: relative;
  display: inline-flex;
}

.key-button {
  display: inline-flex;
  padding: 2px;
  border: 1px solid transparent;
  border-radius: var(--ink-radius);
  background: transparent;
  cursor: pointer;
}

.key-button:hover {
  border-color: var(--ink-border-strong);
  background: var(--ink-surface-sunken);
}

.key-button:focus-visible {
  outline: 1px solid var(--ink-focus);
}

/* The remove badge sits on the key's corner, so showing it doesn't move anything. */
.key-remove {
  position: absolute;
  top: -5px;
  right: -5px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 1px solid var(--ink-border-strong);
  border-radius: 50%;
  background: var(--ink-surface-raised);
  color: var(--ink-muted);
  opacity: 0;
  cursor: pointer;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.key-remove .codicon {
  font-size: 10px !important;
}

.key-button-wrap:hover .key-remove,
.key-remove:focus-visible {
  opacity: 1;
}

.key-remove:hover {
  border-color: var(--ink-danger);
  background: var(--ink-danger);
  color: #fff;
}

.key-empty {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 22px;
  padding: 0 8px;
  border: 1px dashed var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  font-size: var(--ink-font-xs);
  cursor: pointer;
}

.key-empty:hover {
  border-color: var(--ink-focus);
  color: var(--vscode-foreground);
}

.key-empty .codicon {
  font-size: 12px !important;
}

.key-recording {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  padding: 0 2px 0 8px;
  border: 1px solid var(--ink-focus);
  border-radius: var(--ink-radius-sm);
  background: var(--ink-accent-soft);
  box-shadow: 0 0 0 1px var(--ink-focus);
  font-size: var(--ink-font-xs);
}

.recording-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #ef4444;
  animation: ink-shortcut-pulse 1s ease-in-out infinite;
}

.key-recording-cancel {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.key-recording-cancel:hover {
  background: var(--ink-hover);
  color: inherit;
}

.shortcut-conflict {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 6px;
  padding: 0 0 6px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

@keyframes ink-shortcut-pulse {
  50% {
    opacity: 0.3;
  }
}

@media (prefers-reduced-motion: reduce) {
  .recording-dot {
    animation: none;
  }
}

body.vscode-high-contrast .key-button:hover {
  border-color: var(--vscode-contrastBorder);
}

/* Several keys for one action: "Ctrl T / Ctrl F4". */
.key-button-wrap + .key-button-wrap::before {
  content: '/';
  align-self: center;
  margin-right: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

/* Element picker hint (PickerHint) ------------------------------------------------------------
   Drawn over page content, so it has its own dark look (the theme's colors could vanish on the
   page), in both products. Each product places it. */
/* Two rows: what a click does (with each modifier), then the keys. */
.picker-hint {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 7px;
  /* Its own width: centered with left: 50%, it would otherwise wrap at half the page. */
  width: max-content;
  padding: 6px 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.9);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  line-height: 1;
  pointer-events: none;
  backdrop-filter: blur(6px);
}

.picker-hint-group {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 6px 14px;
}

.picker-hint-item {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
}

.picker-hint-label {
  color: rgba(250, 250, 250, 0.82);
}

/* The main action, as a sentence; the others read "[Shift] + click  select several". */
.picker-hint-lead {
  color: #fff;
  font-weight: 600;
}

.picker-hint-click {
  color: #fff;
  font-weight: 500;
}

.picker-hint .keycap {
  border-color: rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  box-shadow: inset 0 -1px 0 rgba(255, 255, 255, 0.14);
  color: #fff;
}

/* Multi-selection bar (SelectionBar) ----------------------------------------------------------
   Over page content like the picker hint, so the same dark look; each product places it. */
.selection-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px;
  width: max-content;
  max-width: calc(100vw - 32px);
  padding: 5px 6px 5px 10px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.94);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  pointer-events: auto;
}

.selection-bar-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: 6px;
  font-weight: 600;
}

.selection-bar-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: #0a84ff;
  color: #fff;
  font-size: var(--ink-font-xs);
}

.selection-bar .button.ghost,
.selection-bar .icon-button {
  color: #fafafa;
}

.selection-bar .button.ghost:hover:not(:disabled),
.selection-bar .icon-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.12);
}

.selection-bar .button-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.selection-bar .keycap {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.16);
  box-shadow: none;
  color: #fff;
}

/* Thumbnails with a checkbox each (ThumbPicker): screenshots taken together ------------------- */
.thumb-picker {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(88px, 1fr));
  gap: var(--ink-space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.thumb-picker-item {
  position: relative;
  border-radius: var(--ink-radius);
}

.thumb-picker-image {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  aspect-ratio: 16 / 10;
  padding: 0;
  overflow: hidden;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  color: var(--ink-muted);
  cursor: pointer;
  transition:
    opacity var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.thumb-picker-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

.thumb-picker-image:hover {
  border-color: var(--ink-border-strong);
}

/* Left out: dimmed, so what is sent stands out. */
.thumb-picker-item:not(.on) .thumb-picker-image {
  opacity: 0.45;
}

.thumb-picker-item.on .thumb-picker-image {
  border-color: var(--ink-accent);
}

.thumb-picker-check {
  position: absolute;
  top: 4px;
  left: 4px;
  padding: 2px;
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--vscode-editor-background) 80%, transparent);
  box-shadow: var(--ink-shadow-sm);
}

body.vscode-high-contrast .thumb-picker-item.on .thumb-picker-image {
  outline: 1px solid var(--vscode-contrastActiveBorder);
}
`;var O1=D(b0());var au=D(Ze(),1);function lu(e,t,n,o={}){let{align:a="start",gap:l=4,matchWidth:i=!1}=o;(0,au.useLayoutEffect)(()=>{if(!n)return;let c=()=>{e.current&&t.current&&Ek(e.current,t.current,{align:a,gap:l,matchWidth:i})};c();let r=new ResizeObserver(c);return t.current&&r.observe(t.current),()=>r.disconnect()},[e,t,n,a,l,i])}function Ek(e,t,{align:n,gap:o,matchWidth:a}){let l=e.getBoundingClientRect();a&&(t.style.minWidth=`${l.width}px`);let i=t.getBoundingClientRect(),c=4,r=l.bottom+o,u=r+i.height<=innerHeight-c,h=l.top-o-i.height,m=u||h<c?r:h,p=n==="end"?l.right-i.width:l.left;t.style.top=`${Math.max(c,Math.min(m,innerHeight-i.height-c))}px`,t.style.left=`${Math.max(c,Math.min(p,innerWidth-i.width-c))}px`,t.dataset.side=m===r?"bottom":"top"}function Jf(e,t,n){let o=e().find(Boolean)?.getRootNode(),a=o instanceof ShadowRoot?o:void 0,l=r=>e().some(u=>u&&r.composedPath().includes(u)),i=r=>{a&&r.composedPath().includes(a.host)||l(r)||n(r)},c=r=>{l(r)||n(r)};return window.addEventListener(t,i,!0),a?.addEventListener(t,c,!0),()=>{window.removeEventListener(t,i,!0),a?.removeEventListener(t,c,!0)}}var Ii,h0=e=>{let t=e.composedPath()[0];if(e.button!==0){Ii=void 0;return}t instanceof Element&&(Ii={element:t.closest('button, [role="button"], a')??t,at:performance.now()})};typeof window<"u"&&window.addEventListener("pointerdown",h0,!0);function g0(e){e.addEventListener("pointerdown",h0,!0)}function iu(){return Ii&&performance.now()-Ii.at<1e3?Ii.element:void 0}function Tk(e){let t=e.getRootNode(),n=[window];t instanceof ShadowRoot&&n.push(t);let o=i=>{i.composedPath().includes(e)&&(i.stopPropagation(),i.preventDefault(),a())},a=()=>{clearTimeout(l);for(let i of n)i.removeEventListener("click",o,!0)},l=setTimeout(a,1e3);for(let i of n)i.addEventListener("click",o,!0)}function cu(e,t,n,o){return Jf(e,"pointerdown",a=>{o?.(a)||(t&&a.composedPath().includes(t)&&Tk(t),n(a))})}function ru(e,t,n){(0,au.useEffect)(()=>{if(!t)return;let o=()=>e.map(r=>r.current),a=Jf(o,"pointerdown",()=>n("outside")),l=Jf(o,"scroll",()=>n("window")),i=r=>{r.key==="Escape"&&(r.preventDefault(),r.stopPropagation(),n("escape"))},c=()=>n("window");return window.addEventListener("keydown",i,!0),window.addEventListener("blur",c),window.addEventListener("resize",c),()=>{a(),l(),window.removeEventListener("keydown",i,!0),window.removeEventListener("blur",c),window.removeEventListener("resize",c)}},[t,n])}function ae(...e){return e.filter(Boolean).join(" ")}function uu(e){let t=e?.getRootNode();return t instanceof ShadowRoot?t:document.body}function v0(e){return e.composedPath().some(t=>t instanceof HTMLElement&&t.dataset.inkPopup!==void 0)}var ka=D(Ze(),1);var Wi={global:"Browser",inspect:"Element picker",draw:"Drawing",screenshot:"Screenshot",devtools:"Console and network",device:"Device",measure:"Measure",eyedropper:"Eyedropper",overlay:"Design overlay",tweak:"CSS tweak",record:"Record",a11y:"Accessibility check",capture:"After a capture"},te=e=>`vscodeBrowser.${e}`,on=[{id:"tab.new",label:"New tab",scope:"global",keys:["ctrl+t"],command:te("newTab")},{id:"tab.close",label:"Close tab",scope:"global",keys:["ctrl+w","ctrl+f4"],command:te("closeTab")},{id:"tab.reopen",label:"Reopen closed tab",scope:"global",keys:["ctrl+shift+t"],command:te("reopenClosedTab")},{id:"tab.next",label:"Next tab",scope:"global",keys:["ctrl+tab","ctrl+pagedown"],mac:["ctrl+tab","cmd+alt+right"],command:te("nextTab")},{id:"tab.previous",label:"Previous tab",scope:"global",keys:["ctrl+shift+tab","ctrl+pageup"],mac:["ctrl+shift+tab","cmd+alt+left"],command:te("previousTab")},{id:"tab.duplicate",label:"Duplicate tab",scope:"global",keys:[],command:te("duplicateTab")},{id:"tab.private",label:"New private tab",scope:"global",keys:["ctrl+shift+n"],command:te("newPrivateTab")},{id:"window.new",label:"New window",scope:"global",keys:["ctrl+n"],command:te("newWindow")},{id:"nav.address",label:"Focus the address bar",scope:"global",keys:["ctrl+l","alt+d"],mac:["cmd+l","alt+d"],command:te("focusAddressBar")},{id:"nav.back",label:"Back",scope:"global",keys:["alt+left"],mac:["cmd+["],command:te("goBack")},{id:"nav.forward",label:"Forward",scope:"global",keys:["alt+right"],mac:["cmd+]"],command:te("goForward")},{id:"nav.reload",label:"Reload",scope:"global",keys:["ctrl+r","f5"],mac:["cmd+r"],command:te("reload")},{id:"nav.hardReload",label:"Hard reload",scope:"global",keys:["ctrl+shift+r","ctrl+f5"],mac:["cmd+shift+r"],command:te("hardReload")},{id:"nav.stop",label:"Stop loading",scope:"global",keys:[],command:te("stop")},{id:"nav.home",label:"Home page",scope:"global",keys:["alt+home"],mac:["cmd+shift+h"],command:te("goHome")},{id:"page.find",label:"Find in page",scope:"global",keys:["ctrl+f"],command:te("find")},{id:"page.zoomIn",label:"Zoom in",scope:"global",keys:["ctrl+=","ctrl+shift+="],command:te("zoomIn")},{id:"page.zoomOut",label:"Zoom out",scope:"global",keys:["ctrl+-"],command:te("zoomOut")},{id:"page.zoomReset",label:"Reset zoom",scope:"global",keys:["ctrl+0"],command:te("zoomReset")},{id:"page.bookmark",label:"Bookmark this page",scope:"global",keys:["ctrl+d"],command:te("bookmarkPage")},{id:"page.source",label:"View page source",scope:"global",keys:["ctrl+u"],mac:["cmd+alt+u"],command:te("viewSource")},{id:"page.pdf",label:"Save page as PDF",scope:"global",keys:[],command:te("savePdf")},{id:"page.copyUrl",label:"Copy page address",scope:"global",keys:["ctrl+shift+l"],command:te("copyUrl")},{id:"page.external",label:"Open in system browser",scope:"global",keys:[],command:te("openInSystemBrowser")},{id:"page.devtools",label:"Open DevTools",scope:"global",keys:["f12"],command:te("openDevTools")},{id:"page.contextToAgent",label:"Send page context to agent",scope:"global",keys:["ctrl+alt+enter"],command:te("sendPageContextToChat")},{id:"agent.showContext",label:"Show agent context",scope:"global",keys:["ctrl+shift+alt+a"],command:te("showAgentContext"),everywhere:!0},{id:"agent.sendLatest",label:"Send the latest capture to the agent",scope:"global",keys:["ctrl+shift+alt+v"],command:te("sendLatestContext"),everywhere:!0},{id:"open.history",label:"History",scope:"global",keys:["ctrl+h"],mac:["cmd+y"],command:te("showHistory")},{id:"open.downloads",label:"Downloads",scope:"global",keys:["shift+alt+l"],command:te("showDownloads")},{id:"open.bookmarks",label:"Bookmark manager",scope:"global",keys:["ctrl+alt+b"],command:te("showBookmarks")},{id:"open.bookmarksBar",label:"Show or hide the bookmarks bar",scope:"global",keys:["ctrl+shift+b"]},{id:"open.quickActions",label:"Quick actions",scope:"global",keys:["ctrl+shift+k"]},{id:"open.shortcuts",label:"Change keyboard shortcuts",scope:"global",keys:["ctrl+alt+k"],command:te("editShortcuts")},{id:"open.cheatSheet",label:"Keyboard shortcuts of this mode",scope:"global",keys:["ctrl+shift+/"],mac:["cmd+alt+/"]},{id:"mode.inspect",label:"Element picker",scope:"global",keys:["shift+alt+e"]},{id:"mode.draw",label:"Draw on the page",scope:"global",keys:["shift+alt+w"]},{id:"mode.screenshot",label:"Screenshot",scope:"global",keys:["shift+alt+g"]},{id:"mode.devtools",label:"Console and network",scope:"global",keys:["shift+alt+j"]},{id:"mode.device",label:"Device toolbar",scope:"global",keys:["shift+alt+m"]},{id:"mode.measure",label:"Measure",scope:"global",keys:["shift+alt+u"]},{id:"mode.eyedropper",label:"Eyedropper",scope:"global",keys:["shift+alt+y"]},{id:"mode.overlay",label:"Design overlay",scope:"global",keys:["shift+alt+o"]},{id:"mode.tweak",label:"CSS tweak",scope:"global",keys:["shift+alt+v"]},{id:"mode.record",label:"Record the page",scope:"global",keys:["ctrl+alt+r"]},{id:"mode.a11y",label:"Accessibility check",scope:"global",keys:["shift+alt+h"]},{id:"inspect.parent",label:"Select the parent element",scope:"inspect",keys:["up"]},{id:"inspect.child",label:"Select the first child element",scope:"inspect",keys:["down"]},{id:"inspect.copy",label:"Copy the selected elements",scope:"inspect",keys:["enter","c"]},{id:"inspect.screenshot",label:"Screenshot the element",scope:"inspect",keys:["s"]},{id:"inspect.agent",label:"Send the element to the agent",scope:"inspect",keys:["a"]},{id:"inspect.help",label:"Show these shortcuts",scope:"inspect",keys:["shift+/"]},{id:"inspect.exit",label:"Exit",scope:"inspect",keys:["escape"]},{id:"draw.select",label:"Select and move",scope:"draw",keys:["v"]},{id:"draw.pen",label:"Pen",scope:"draw",keys:["p"]},{id:"draw.pencil",label:"Pencil",scope:"draw",keys:["i"]},{id:"draw.marker",label:"Marker",scope:"draw",keys:["m"]},{id:"draw.brush",label:"Brush",scope:"draw",keys:["u"]},{id:"draw.highlighter",label:"Highlighter",scope:"draw",keys:["h"]},{id:"draw.neon",label:"Neon",scope:"draw",keys:["g"]},{id:"draw.line",label:"Line",scope:"draw",keys:["l"]},{id:"draw.arrow",label:"Arrow",scope:"draw",keys:["a"]},{id:"draw.doubleArrow",label:"Double arrow",scope:"draw",keys:["d"]},{id:"draw.rect",label:"Rectangle",scope:"draw",keys:["r"]},{id:"draw.ellipse",label:"Ellipse",scope:"draw",keys:["o"]},{id:"draw.text",label:"Text",scope:"draw",keys:["t"]},{id:"draw.callout",label:"Numbered callout",scope:"draw",keys:["n"]},{id:"draw.blur",label:"Redact (pixelate)",scope:"draw",keys:["b"]},{id:"draw.eraser",label:"Eraser",scope:"draw",keys:["e"]},...[1,2,3,4,5,6,7,8,9].map(e=>({id:`draw.color${e}`,label:`Color ${e}`,scope:"draw",keys:[String(e)]})),{id:"draw.thinner",label:"Thinner stroke",scope:"draw",keys:["["]},{id:"draw.thicker",label:"Thicker stroke",scope:"draw",keys:["]"]},{id:"draw.fill",label:"Fill shapes on or off",scope:"draw",keys:["f"]},{id:"draw.undo",label:"Undo",scope:"draw",keys:["ctrl+z"]},{id:"draw.redo",label:"Redo",scope:"draw",keys:["ctrl+y","ctrl+shift+z"]},{id:"draw.clear",label:"Clear all drawings",scope:"draw",keys:["shift+backspace"]},{id:"draw.visible",label:"Hide or show drawings",scope:"draw",keys:["w"]},{id:"draw.capture",label:"Screenshot the drawing area",scope:"draw",keys:["enter"]},{id:"draw.captureAgent",label:"Screenshot the drawing area and send it to the agent",scope:"draw",keys:["shift+enter"]},{id:"draw.captureMenu",label:"Screenshot menu",scope:"draw",keys:["s"]},{id:"draw.captureGroups",label:"Screenshot each drawing separately",scope:"draw",keys:["alt+g"]},{id:"draw.captureClean",label:"Screenshot the drawing area without drawings",scope:"draw",keys:["alt+c"]},{id:"draw.captureViewport",label:"Screenshot the visible area with drawings",scope:"draw",keys:["alt+v"]},{id:"draw.captureFullPage",label:"Screenshot the full page with drawings",scope:"draw",keys:["alt+f"]},{id:"draw.help",label:"Show these shortcuts",scope:"draw",keys:["shift+/"]},{id:"draw.exit",label:"Stop drawing",scope:"draw",keys:["escape"]},{id:"shot.viewport",label:"Visible area",scope:"screenshot",keys:["v"]},{id:"shot.fullPage",label:"Full page",scope:"screenshot",keys:["f"]},{id:"shot.region",label:"Region",scope:"screenshot",keys:["r"]},{id:"shot.element",label:"Element",scope:"screenshot",keys:["e"]},{id:"shot.drawing",label:"Drawing area",scope:"screenshot",keys:["d"]},{id:"shot.lastToAgent",label:"Send the last screenshot to the agent",scope:"screenshot",keys:["a"],command:te("screenshot.sendToTerminal")},{id:"capture.chat",label:"Send to chat",scope:"capture",keys:["alt+shift+c"]},{id:"capture.terminal",label:"Send to terminal",scope:"capture",keys:["alt+shift+x"]},{id:"capture.save",label:"Save in VS Code",scope:"capture",keys:["alt+shift+s"]},{id:"capture.download",label:"Download",scope:"capture",keys:["alt+shift+d"]},{id:"dev.console",label:"Console",scope:"devtools",keys:["alt+1"]},{id:"dev.network",label:"Network",scope:"devtools",keys:["alt+2"]},{id:"dev.filter",label:"Filter",scope:"devtools",keys:["alt+f"]},{id:"dev.copyErrors",label:"Copy console errors",scope:"devtools",keys:["alt+e"]},{id:"dev.copyFailed",label:"Copy failed requests",scope:"devtools",keys:["alt+q"]},{id:"dev.copyContext",label:"Copy page context",scope:"devtools",keys:["alt+p"]},{id:"dev.contextAgent",label:"Send page context to the agent",scope:"devtools",keys:["alt+shift+p"]},{id:"dev.clear",label:"Clear",scope:"devtools",keys:["alt+k"]},{id:"dev.close",label:"Close",scope:"devtools",keys:["alt+w"]},{id:"device.previous",label:"Previous device",scope:"device",keys:["alt+["]},{id:"device.next",label:"Next device",scope:"device",keys:["alt+]"]},{id:"device.rotate",label:"Rotate",scope:"device",keys:["alt+r"]},{id:"device.touch",label:"Touch and mobile on or off",scope:"device",keys:["alt+t"]},{id:"device.fit",label:"Fit to window",scope:"device",keys:["alt+0"]},{id:"device.zoomIn",label:"Zoom in",scope:"device",keys:["alt+="]},{id:"device.zoomOut",label:"Zoom out",scope:"device",keys:["alt+-"]},{id:"device.network",label:"Next network speed",scope:"device",keys:["alt+n"]},{id:"device.theme",label:"Next color scheme",scope:"device",keys:["alt+l"]},{id:"device.close",label:"Close the device toolbar",scope:"device",keys:[]},{id:"measure.grid",label:"Rulers and grid on or off",scope:"measure",keys:["g"]},{id:"measure.copy",label:"Copy the measurements",scope:"measure",keys:["c"]},{id:"measure.clear",label:"Clear the pinned element",scope:"measure",keys:["backspace"]},{id:"measure.help",label:"Show these shortcuts",scope:"measure",keys:["shift+/"]},{id:"measure.exit",label:"Exit",scope:"measure",keys:["escape"]},{id:"eyedropper.hex",label:"Copy colors as hex",scope:"eyedropper",keys:["h"]},{id:"eyedropper.rgb",label:"Copy colors as rgb()",scope:"eyedropper",keys:["r"]},{id:"eyedropper.hsl",label:"Copy colors as hsl()",scope:"eyedropper",keys:["l"]},{id:"eyedropper.help",label:"Show these shortcuts",scope:"eyedropper",keys:["shift+/"]},{id:"eyedropper.exit",label:"Exit",scope:"eyedropper",keys:["escape"]},{id:"overlay.open",label:"Open an image",scope:"overlay",keys:["alt+o"]},{id:"overlay.fainter",label:"Less opaque",scope:"overlay",keys:["alt+,"]},{id:"overlay.stronger",label:"More opaque",scope:"overlay",keys:["alt+."]},{id:"overlay.left",label:"Nudge left",scope:"overlay",keys:["alt+left"]},{id:"overlay.right",label:"Nudge right",scope:"overlay",keys:["alt+right"]},{id:"overlay.up",label:"Nudge up",scope:"overlay",keys:["alt+up"]},{id:"overlay.down",label:"Nudge down",scope:"overlay",keys:["alt+down"]},{id:"overlay.difference",label:"Difference blend on or off",scope:"overlay",keys:["alt+x"]},{id:"overlay.hide",label:"Hide or show the overlay",scope:"overlay",keys:["alt+h"]},{id:"overlay.exit",label:"Close the overlay",scope:"overlay",keys:["alt+z"]},{id:"tweak.agent",label:"Send the CSS changes to the agent",scope:"tweak",keys:["ctrl+enter"]},{id:"tweak.copy",label:"Copy the CSS changes",scope:"tweak",keys:["ctrl+shift+c"]},{id:"tweak.undo",label:"Undo the last change",scope:"tweak",keys:["ctrl+z"]},{id:"tweak.exit",label:"Exit and revert",scope:"tweak",keys:["escape"]},{id:"record.stop",label:"Stop and save",scope:"record",keys:["alt+s"]},{id:"record.pause",label:"Pause or resume",scope:"record",keys:["alt+y"]},{id:"record.cancel",label:"Cancel",scope:"record",keys:["alt+backspace"]},{id:"a11y.next",label:"Next issue",scope:"a11y",keys:["n","down"]},{id:"a11y.previous",label:"Previous issue",scope:"a11y",keys:["p","up"]},{id:"a11y.tabOrder",label:"Tab order on or off",scope:"a11y",keys:["t"]},{id:"a11y.copy",label:"Copy the report",scope:"a11y",keys:["c"]},{id:"a11y.agent",label:"Send the report to the agent",scope:"a11y",keys:["a"]},{id:"a11y.help",label:"Show these shortcuts",scope:"a11y",keys:["shift+/"]},{id:"a11y.exit",label:"Exit",scope:"a11y",keys:["escape"]}];function ec(e,t){return t?[...e.mac??e.keys.map(n=>n.replace(/\bctrl\+/,"cmd+"))]:[...e.keys]}function su(e){let t=Ff(e.trim());return t.key?[t.ctrl&&"ctrl",t.shift&&"shift",t.alt&&"alt",t.meta&&"cmd",t.key].filter(Boolean).join("+"):""}function du(e,t){let n={};for(let o of on){let a=e[o.id],l=(a===void 0?ec(o,t):typeof a=="string"?[a]:[...a]).map(su);n[o.id]=[...new Set(l.filter(Boolean))]}return n}function T0(e){if(!e||typeof e!="object"||Array.isArray(e))return{};let t=new Set(on.map(o=>o.id)),n={};for(let[o,a]of Object.entries(e))t.has(o)&&(typeof a=="string"||Array.isArray(a)&&a.every(l=>typeof l=="string"))&&(n[o]=a);return n}var y0=new Set(["devtools","device","overlay","record","capture"]);function C0(e){let t=new Map(on.map(a=>[a.id,a.scope])),n=new Map;for(let[a,l]of Object.entries(e))for(let i of l)n.set(i,[...n.get(i)??[],a]);let o=[];for(let[a,l]of n)for(let i=0;i<l.length;i++)for(let c=i+1;c<l.length;c++){let[r,u]=[t.get(l[i]),t.get(l[c])];(r===u||y0.has(r)&&y0.has(u))&&o.push({key:a,ids:[l[i],l[c]]})}return o}function $f(e,t,n){let o=fu(n);for(let a of t){let l=on.find(i=>i.scope===a&&(e[i.id]??[]).includes(o));if(l)return l}}function fu(e){return[e.ctrl&&"ctrl",e.shift&&"shift",e.alt&&"alt",e.meta&&"cmd",e.key].filter(Boolean).join("+")}var Pf=new Set(["mode.inspect","mode.draw","mode.screenshot","mode.device","mode.devtools","page.bookmark","open.shortcuts","inspect.parent","inspect.child","inspect.copy","inspect.exit",...["select","pen","pencil","marker","brush","highlighter","neon","line","arrow","doubleArrow","rect","ellipse","text","callout","blur","eraser"].map(e=>`draw.${e}`),...Array.from({length:9},(e,t)=>`draw.color${t+1}`),"draw.thinner","draw.thicker","draw.fill","draw.undo","draw.redo","draw.clear","draw.visible","draw.capture","draw.captureMenu","draw.captureGroups","draw.captureClean","draw.captureViewport","draw.captureFullPage","draw.exit","shot.viewport","shot.fullPage","shot.region","shot.element","shot.drawing","capture.chat","capture.terminal","capture.save","capture.download"]),Ck=new Set(["capture"]),w0={id:"vs",label:"VS",title:"Works in VS Code Browser"},x0={id:"br",label:"BR",title:"Works in the Inkspect toolbar in your browser (Chrome, Edge, Firefox...)"};function N0(e){return Ck.has(e.scope)?[x0]:Pf.has(e.id)?[w0,x0]:[w0]}var Nk={control:"ctrl",ctl:"ctrl","\u2303":"ctrl",option:"alt",opt:"alt","\u2325":"alt",command:"cmd",meta:"cmd",win:"cmd",super:"cmd","\u2318":"cmd","\u21E7":"shift",esc:"escape",return:"enter","\u21A9":"enter",del:"delete","\u2191":"up","\u2193":"down","\u2190":"left","\u2192":"right",pgup:"pageup",pgdn:"pagedown","+":"="},S0=new Set(["ctrl","shift","alt","cmd"]);function M0(e,t){let n=t.toLowerCase().replace(/([⌃⌥⇧⌘↩↑↓←→])/g," $1 ").split(/\s+|[+-](?=.)/).filter(Boolean).map(r=>Nk[r]??r);if(!n.length)return!1;let o=n.filter(r=>S0.has(r)),a=n.filter(r=>!S0.has(r));if(a.length>1)return!1;let l=Ff(su(e)),i={ctrl:l.ctrl,shift:l.shift,alt:l.alt,cmd:l.meta};if(!o.every(r=>i[r]))return!1;let[c]=a;return c===void 0||l.key.startsWith(c)}function z0(e){if(!e.key)return;let t=/^f([1-9]|1\d|2[0-4])$/.test(e.key);return e.ctrl||e.alt||e.meta||t?fu(e):void 0}function _o(e,t){let n=St(e,t);return t?[...[...n.matchAll(/[⌃⌥⇧⌘]/g)].map(a=>a[0]),n.replace(/[⌃⌥⇧⌘]/g,"")]:n.split(/\+(?=.)/)}var A0={global:"browser",inspect:"inspect",draw:"edit",screenshot:"device-camera",devtools:"debug-console",device:"device-mobile",measure:"symbol-ruler",eyedropper:"symbol-color",overlay:"layers",tweak:"symbol-property",record:"record",a11y:"accessibility",capture:"check-all"};function St(e,t){let n=Ff(e),o={escape:"Esc",enter:t?"\u21A9":"Enter",backspace:t?"\u232B":"Backspace",delete:t?"\u2326":"Delete",up:"\u2191",down:"\u2193",left:"\u2190",right:"\u2192",pageup:"PgUp",pagedown:"PgDn",tab:t?"\u21E5":"Tab",space:"Space","/":n.shift?"?":"/"},a=!(n.key==="/"&&n.shift),l=o[n.key]??(n.key.length===1?n.key.toUpperCase():n.key[0].toUpperCase()+n.key.slice(1));return t?`${n.ctrl?"\u2303":""}${n.alt?"\u2325":""}${n.shift&&a?"\u21E7":""}${n.meta?"\u2318":""}${l}`:[n.ctrl&&"Ctrl",n.alt&&"Alt",n.shift&&a&&"Shift",l].filter(Boolean).join("+")}function Ff(e){let t=e.toLowerCase().split("+"),n=t.pop()??"";return{ctrl:t.includes("ctrl"),shift:t.includes("shift"),alt:t.includes("alt"),meta:t.includes("cmd")||t.includes("meta")||t.includes("win"),key:n}}var Mk={arrowleft:"left",arrowright:"right",arrowup:"up",arrowdown:"down",esc:"escape"," ":"space","+":"="},k0={Equal:"=",Minus:"-",BracketLeft:"[",BracketRight:"]",Slash:"/",Backslash:"\\",Comma:",",Period:".",Semicolon:";",Quote:"'",Backquote:"`",NumpadAdd:"=",NumpadSubtract:"-"},pu=new Set(["Control","Shift","Alt","Meta","AltGraph","OS"]),E0={"?":"/","<":",",">":".",":":";",'"':"'","{":"[","}":"]","|":"\\","~":"`",_:"-","+":"=","!":"1","@":"2","#":"3",$:"4","%":"5","^":"6","&":"7","*":"8","(":"9",")":"0"};function xa(e){let t={ctrl:e.ctrlKey,shift:e.shiftKey,alt:e.altKey,meta:e.metaKey};if(e.getModifierState?.("AltGraph"))return{...t,key:""};let n=e.key,o;return/^[a-z0-9]$/i.test(n)?o=n.toLowerCase():e.shiftKey&&E0[n]!==void 0?o=E0[n]:/^[-=[\]\\/,.;'`+]$/.test(n)?o=n:/^Key[A-Z]$/.test(e.code)?o=e.code.slice(3).toLowerCase():/^Digit\d$/.test(e.code)?o=e.code.slice(5):k0[e.code]?o=k0[e.code]:o=n.toLowerCase(),{...t,key:Mk[o]??o}}var Sa=D(q(),1);function bu({icon:e,trailing:t,size:n="md",onClear:o,invalid:a,className:l,disabled:i,...c}){let r=c.value!==void 0&&String(c.value)!=="";return(0,Sa.jsxs)("div",{className:ae("text-field",`size-${n}`,a&&"invalid",i&&"disabled",l),children:[e&&(0,Sa.jsx)("span",{className:`codicon codicon-${e} text-field-icon`,"aria-hidden":"true"}),(0,Sa.jsx)("input",{spellCheck:!1,...c,disabled:i,"aria-invalid":a||void 0}),o&&r&&(0,Sa.jsx)("button",{type:"button",className:"text-field-clear","aria-label":"Clear",title:"Clear",tabIndex:-1,onClick:o,children:(0,Sa.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})}),t]})}var H0=D(q(),1),Ok=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),Zn=null;function _0(e){return Zn?(Zn(e),!0):!1}typeof window<"u"&&window.addEventListener("keydown",e=>{if(!Zn||pu.has(e.key))return;e.stopImmediatePropagation();let t=z0(xa(e));t&&(e.preventDefault(),Zn(t))},!0);function U0({value:e,onChange:t,size:n}){let o=(0,ka.useRef)(t);(0,ka.useEffect)(()=>{o.current=t});let[a]=(0,ka.useState)(()=>l=>o.current(St(l,Ok)));return(0,ka.useEffect)(()=>()=>{Zn===a&&(Zn=null)},[a]),(0,H0.jsx)(bu,{size:n,icon:"search",placeholder:"Search actions or keys, or press a shortcut","aria-label":"Search shortcuts: type, or press a shortcut",value:e,onChange:l=>t(l.target.value),onClear:()=>t(""),onFocus:()=>{Zn=a},onBlur:()=>{Zn===a&&(Zn=null)}})}var A=D(Ze());var L0=["pen","pencil","marker","brush","highlighter","neon"],q0=["line","arrow","doubleArrow","rect","ellipse","blur"],Ol=["#ff3b30","#ff9500","#ffcc00","#34c759","#00c7be","#007aff","#af52de","#ffffff","#000000"],Ea={color:"#ff3b30",width:4,opacity:1,dash:"solid",fill:!1};function If(e){return 12+e.width*2}function Wf(e){return 10+e.width}function tc(e){let t=e.style.width/2+(e.kind==="stroke"&&e.tool==="neon"?8:0),n;switch(e.kind){case"stroke":n=e.points.map(([o,a])=>[o,a]);break;case"text":{let o=If(e.style),a=e.text.split(`
`),l=Math.max(...a.map(i=>i.length))*o*.6;n=[e.at,[e.at[0]+l,e.at[1]+a.length*o*1.25]];break}case"callout":{let o=Wf(e.style);n=[[e.at[0]-o,e.at[1]-o],[e.at[0]+o,e.at[1]+o]];break}default:{let o=e.kind==="arrow"||e.kind==="doubleArrow"?ep(e.style):0;return n=[e.start,e.end],hu(B0(n),t+o)}}return hu(B0(n),t)}function ep(e){return 8+e.width*2.5}function B0(e){let t=e.map(l=>l[0]),n=e.map(l=>l[1]),o=Math.min(...t),a=Math.min(...n);return{x:o,y:a,width:Math.max(...t)-o,height:Math.max(...n)-a}}function hu(e,t){return{x:e.x-t,y:e.y-t,width:e.width+t*2,height:e.height+t*2}}function Y0(e){if(!e.length)return;let t=Math.min(...e.map(l=>l.x)),n=Math.min(...e.map(l=>l.y)),o=Math.max(...e.map(l=>l.x+l.width)),a=Math.max(...e.map(l=>l.y+l.height));return{x:t,y:n,width:o-t,height:a-n}}function Rk(e,t){let n=Math.max(0,e.x),o=Math.max(0,e.y),a=t?Math.min(t.width,e.x+e.width):e.x+e.width,l=t?Math.min(t.height,e.y+e.height):e.y+e.height;return{x:n,y:o,width:Math.max(1,a-n),height:Math.max(1,l-o)}}function V0(e,t){let n=Y0(e.map(tc));return n&&Rk(hu(n,t))}function Dk(e,t,n){return e.x-n<=t.x+t.width&&t.x-n<=e.x+e.width&&e.y-n<=t.y+t.height&&t.y-n<=e.y+e.height}function j0(e,t){let n=[];for(let o of e){let a=tc(o),l=n.filter(c=>Dk(c.bounds,a,t)),i={shapes:[...l.flatMap(c=>c.shapes),o],bounds:Y0([a,...l.map(c=>c.bounds)])};for(let c of l)n.splice(n.indexOf(c),1);n.push(i)}return n.sort((o,a)=>o.bounds.y-a.bounds.y).map(o=>o.shapes)}function tp(e,t,n){let o=hu(tc(e),n);if(!(t[0]>=o.x&&t[0]<=o.x+o.width&&t[1]>=o.y&&t[1]<=o.y+o.height))return!1;if(e.kind==="stroke"){let l=n+e.style.width/2;return e.points.some(([i,c])=>Math.hypot(i-t[0],c-t[1])<=l+4)}return e.kind==="line"||e.kind==="arrow"||e.kind==="doubleArrow"?_k(t,e.start,e.end)<=n+e.style.width/2:!0}function _k(e,t,n){let o=n[0]-t[0],a=n[1]-t[1],l=o*o+a*a,i=l?Math.max(0,Math.min(1,((e[0]-t[0])*o+(e[1]-t[1])*a)/l)):0;return Math.hypot(e[0]-(t[0]+i*o),e[1]-(t[1]+i*a))}function X0(e,t,n){let o=([a,l])=>[a+t,l+n];switch(e.kind){case"stroke":return{...e,points:e.points.map(([a,l,i])=>[a+t,l+n,i])};case"text":case"callout":return{...e,at:o(e.at)};default:return{...e,start:o(e.start),end:o(e.end)}}}function K0(e,t,n){let o=n[0]-t[0],a=n[1]-t[1];if(e==="rect"||e==="ellipse"||e==="blur"){let c=Math.max(Math.abs(o),Math.abs(a));return[t[0]+Math.sign(o||1)*c,t[1]+Math.sign(a||1)*c]}let l=Math.round(Math.atan2(a,o)/(Math.PI/4))*(Math.PI/4),i=Math.hypot(o,a);return[t[0]+Math.cos(l)*i,t[1]+Math.sin(l)*i]}function G0(e,t,n){let o=["data-testid","data-test","data-cy","data-qa","aria-label","name"],a=m=>/^(css|sc|jsx|emotion|svelte)-|__[a-z0-9]{5,}$|[_-][a-f0-9]{6,}$|\d{3,}|[:[\]/()]/i.test(m),l=m=>{try{return t(m)===1}catch{return!1}},i=m=>{let p=m.tagName.toLowerCase(),f=[];m.id&&!a(m.id)&&f.push(`#${n(m.id)}`);for(let k of o){let E=m.getAttribute(k);E&&E.length<80&&f.push(`${p}[${k}="${E.replace(/"/g,'\\"')}"]`)}let x=Array.from(m.classList).filter(k=>!a(k)).slice(0,3).map(k=>`.${n(k)}`);return x.length&&f.push(p+x.join("")),f.push(p),f},c=m=>{let p=m.tagName.toLowerCase(),f=m.parentElement;if(!f)return p;let x=Array.from(f.children).filter(k=>k.tagName===m.tagName);return x.length>1?`${p}:nth-of-type(${x.indexOf(m)+1})`:p};for(let m of i(e))if(l(m))return m;let r=i(e).find(m=>m!==e.tagName.toLowerCase())??c(e);l(r)||(r=c(e));let u=e.parentElement;for(;u&&!l(r);){let m=i(u).find(p=>l(p));if(m)return r=`${m} > ${r}`,l(r)?r:`${m} > ${h(e,u,c)}`;r=`${c(u)} > ${r}`,u=u.parentElement}return r;function h(m,p,f){let x=[];for(let k=m;k&&k!==p;k=k.parentElement)x.unshift(f(k));return x.join(" > ")}}function Q0(e){let t=[];for(let n=e;n;n=n.parentElement){let o=n.tagName.toLowerCase(),a=n.parentElement,l=a?Array.from(a.children).filter(i=>i.tagName===n.tagName):[];t.unshift(l.length>1?`${o}[${l.indexOf(n)+1}]`:o)}return`/${t.join("/")}`}var np=["page","selector","xpath","role","component","box","text","styles","attributes","html"];function nc(e){return`${e.tag}${e.id?`#${e.id}`:""}${e.classes.slice(0,3).map(t=>`.${t}`).join("")}`}function Uk(e){let t=e.file?` (${e.file}${e.line?`:${e.line}`:""})`:"";return`\`<${e.name}>\`${t} [${e.framework}]`}function gu(e,t,n=np){switch(t){case"selector":return e.map(o=>o.selector).join(`
`);case"html":return e.map(o=>o.html).join(`

`);case"json":{let o=a=>{let l={element:nc(a)};return n.includes("page")&&(l.page={url:a.pageUrl,title:a.pageTitle,viewport:a.viewport,frameUrl:a.frameUrl}),n.includes("selector")&&(l.selector=a.selector),n.includes("xpath")&&(l.xpath=a.xpath),n.includes("role")&&(l.role=a.role?{role:a.role,name:a.name}:void 0),n.includes("component")&&(l.component=a.component),n.includes("box")&&(l.box=a.rect),n.includes("text")&&(l.text=a.text),n.includes("styles")&&(l.styles=a.styles),n.includes("attributes")&&(l.attributes=a.attributes),n.includes("html")&&(l.html=a.html),a.screenshot&&(l.screenshot=a.screenshot),l};return JSON.stringify(e.length===1?o(e[0]):e.map(o),null,2)}case"markdown":return e.map((o,a)=>{let l=[`### ${e.length>1?`${a+1}. `:""}Element: \`${nc(o)}\``];if(n.includes("page")&&(l.push(`- Page: ${o.pageUrl} (${o.viewport.width}\xD7${o.viewport.height})`),o.frameUrl&&l.push(`- Frame: ${o.frameUrl}`)),n.includes("selector")&&l.push(`- Selector: \`${o.selector}\``),n.includes("xpath")&&l.push(`- XPath: \`${o.xpath}\``),n.includes("role")&&o.role&&l.push(`- Role/name: ${o.role}${o.name?` "${o.name}"`:""}`),n.includes("component")&&o.component&&l.push(`- Component: ${Uk(o.component)}`),n.includes("box")){let i=o.rect;l.push(`- Box: ${Math.round(i.width)}\xD7${Math.round(i.height)} at (${Math.round(i.x)}, ${Math.round(i.y)})`)}if(n.includes("text")&&o.text&&l.push(`- Text: "${o.text}"`),n.includes("styles")){let i=Object.entries(o.styles).map(([c,r])=>`${c}:${r}`).join("; ");i&&l.push(`- Styles: ${i}`)}if(n.includes("attributes")){let i=Object.entries(o.attributes).filter(([c])=>c!=="class"&&c!=="id"&&c!=="style").map(([c,r])=>`${c}="${r}"`).join(" ");i&&l.push(`- Attributes: ${i}`)}return o.screenshot&&l.push(`- Screenshot: ${o.screenshot}`),n.includes("html")&&l.push("```html",o.html,"```"),l.join(`
`)}).join(`

`)}}var Hk=["display","position","width","height","margin","padding","color","background-color","font-family","font-size","font-weight","line-height","border","border-radius","z-index","flex-direction","justify-content","align-items","gap","grid-template-columns","opacity","overflow"];function Z0(e,t,n){let o=e.ownerDocument,a=o.defaultView||window,l=e.getRootNode(),i="querySelectorAll"in l?l:o,c=d=>a.CSS&&a.CSS.escape?a.CSS.escape(d):d,r=n.buildSelector(e,d=>i.querySelectorAll(d).length,c);if(i!==o&&"host"in i&&i.host){let d=i.host.getRootNode();r=n.buildSelector(i.host,y=>("querySelectorAll"in d?d:o).querySelectorAll(y).length,c)+" >>> "+r}let u=e.getBoundingClientRect(),h={};for(let d of Array.from(e.attributes||[]))h[d.name]=d.value.slice(0,300);let p=(e.innerText||e.textContent||"").replace(/\s+/g," ").trim().slice(0,200)||void 0,f=e.outerHTML||"";if(f.length>t){let d=e.cloneNode(!1);e.children.length?d.innerHTML="\u2026":d.textContent=(e.textContent||"").slice(0,80)+"\u2026",f=d.outerHTML.slice(0,t)}let x=a.getComputedStyle(e),k={};for(let d of n.styleProperties){let v=x.getPropertyValue(d);!v||/^(none|normal|auto|0px|static|visible|1|rgba\(0, 0, 0, 0\)|0px none .*)$/.test(v)||(k[d]=v.length>80?v.slice(0,80)+"\u2026":v)}let E=(()=>{try{let d=e,v=Object.keys(d).find(w=>w.startsWith("__reactFiber$")||w.startsWith("__reactInternalInstance$"));if(v)for(let w=d[v];w;w=w.return){let M=w.type;if(!M||typeof M=="string")continue;let H=M.displayName||M.name||M.render&&(M.render.displayName||M.render.name);if(!H)continue;let R=w._debugSource&&w._debugSource.fileName,K=w._debugSource&&w._debugSource.lineNumber,L=w._debugStack&&w._debugStack.stack;if(!R&&typeof L=="string"){let ne=L.split(`
`).slice(1).find(O=>!/node_modules|react-dom|react-stack|jsx-dev-runtime|chunk-/.test(O))||"",ce=/\(?((?:https?|file|webpack[\w-]*):\/\/[^\s)]+?):(\d+):\d+\)?\s*$/.exec(ne);ce&&(R=ce[1],K=Number(ce[2]))}return{framework:"react",name:H,file:R,line:K}}let y=d.__vueParentComponent;if(y){let w=y.type||{},M=w.__file;return{framework:"vue",name:w.name||w.__name||(M?String(M).split("/").pop().replace(/\.vue$/,""):"Anonymous"),file:M}}if(d.__vue__){let w=d.__vue__.$options||{};return{framework:"vue",name:w.name||w._componentTag||"Anonymous",file:w.__file}}for(let w=d;w;w=w.parentElement)if(w.__svelte_meta){let M=w.__svelte_meta.loc||{};return{framework:"svelte",name:M.file?String(M.file).split("/").pop().replace(/\.svelte$/,""):"Component",file:M.file,line:typeof M.line=="number"?M.line+1:void 0}}let T=a.ng;if(T&&T.getOwningComponent){let w=T.getComponent(e)||T.getOwningComponent(e);if(w)return{framework:"angular",name:w.constructor.name}}}catch{}})(),b=a.location.href,s=o.title;try{b=a.top.location.href,s=a.top.document.title}catch{}return{tag:e.tagName.toLowerCase(),id:e.id||void 0,classes:Array.from(e.classList||[]),selector:r,xpath:n.buildXPath(e),text:p,html:f,attributes:h,rect:{x:u.x,y:u.y,width:u.width,height:u.height},styles:k,component:E,pageUrl:b,pageTitle:s,viewport:{width:a.innerWidth,height:a.innerHeight},frameUrl:a!==a.top?a.location.href:void 0,scroll:{x:a.scrollX,y:a.scrollY}}}var J0={buildSelector:G0,buildXPath:Q0,styleProperties:Hk};var Bk={a:"link",article:"article",aside:"complementary",button:"button",dialog:"dialog",footer:"contentinfo",form:"form",h1:"heading",h2:"heading",h3:"heading",h4:"heading",h5:"heading",h6:"heading",header:"banner",hr:"separator",img:"img",li:"listitem",main:"main",nav:"navigation",ol:"list",option:"option",progress:"progressbar",section:"region",select:"combobox",table:"table",textarea:"textbox",ul:"list"},Lk={button:"button",checkbox:"checkbox",email:"textbox",image:"button",number:"spinbutton",radio:"radio",range:"slider",reset:"button",search:"searchbox",submit:"button",tel:"textbox",text:"textbox",url:"textbox"},qk=new Set(["button","link","heading","listitem","option","tab","menuitem","cell"]);function vu(e){let t=e.tagName.toLowerCase(),n=e.getAttribute("role")?.split(/\s+/)[0]||void 0;n||(t==="input"?n=Lk[(e.getAttribute("type")||"text").toLowerCase()]:t==="a"?n=e.hasAttribute("href")?"link":void 0:t==="section"?n=e.hasAttribute("aria-label")?"region":void 0:n=Bk[t]);let o=i=>(i||"").replace(/\s+/g," ").trim().slice(0,200)||void 0,a=e.getAttribute("aria-labelledby"),l;if(a&&(l=o(a.split(/\s+/).map(i=>e.ownerDocument.getElementById(i)?.textContent||"").join(" "))),l??=o(e.getAttribute("aria-label")),!l&&(t==="img"||t==="area")&&(l=o(e.getAttribute("alt"))),!l&&"labels"in e){let i=e.labels;i?.length&&(l=o(Array.from(i,c=>c.textContent).join(" ")))}if(!l&&t==="input"){let i=e;["button","submit","reset"].includes(i.type)&&(l=o(i.value)),l??=o(i.placeholder)}return!l&&n&&qk.has(n)&&(l=o(e.innerText||e.textContent)),l??=o(e.getAttribute("title")),{role:n||"generic",name:l}}function $0(e){let t=e.parentElement||(e.getRootNode().host??null);return t&&t.tagName!=="HTML"?t:null}function P0(e){return e.firstElementChild||e.shadowRoot?.firstElementChild||null}var oc=(e,t,n,o,a,l)=>({id:e,name:t,group:"Phones",width:n,height:o,dpr:a,mobile:!0,touch:!0,userAgent:l}),op=(e,t,n,o,a,l)=>({id:e,name:t,group:"Tablets",width:n,height:o,dpr:a,mobile:!0,touch:!0,userAgent:l}),Rl=(e,t,n)=>({id:`desktop-${e}x${t}`,name:`${n} ${e}\xD7${t}`,group:"Desktops",width:e,height:t,dpr:1,mobile:!1,touch:!1,userAgent:"desktop"}),Dl=[oc("iphone-se","iPhone SE",375,667,2,"iphone"),oc("iphone-16-pro","iPhone 16 Pro",402,874,3,"iphone"),oc("iphone-16-pro-max","iPhone 16 Pro Max",440,956,3,"iphone"),oc("pixel-8","Pixel 8",412,915,2.625,"android"),oc("galaxy-s24","Galaxy S24",360,780,3,"android"),op("ipad-mini","iPad Mini",768,1024,2,"ipad"),op("ipad-pro",'iPad Pro 12.9"',1024,1366,2,"ipad"),op("surface-pro","Surface Pro 7",912,1368,2,"desktop"),Rl(1280,800,"Laptop"),Rl(1366,768,"Laptop"),Rl(1440,900,"Laptop"),Rl(1920,1080,"Full HD"),Rl(2560,1440,"QHD"),Rl(3840,2160,"4K")],F0={none:{label:"No throttling",offline:!1,latency:0,download:-1,upload:-1},offline:{label:"Offline",offline:!0,latency:0,download:0,upload:0},slow3g:{label:"Slow 3G",offline:!1,latency:2e3,download:5e4,upload:5e4},fast3g:{label:"Fast 3G",offline:!1,latency:562.5,download:18e4,upload:84375},fast4g:{label:"Fast 4G",offline:!1,latency:165,download:1012500,upload:168750}},I0=[1,4,6];var ap=50,lp=7680;function yu(e){return{presetId:e.id,width:e.width,height:e.height,dpr:e.dpr,mobile:e.mobile,touch:e.touch,userAgent:e.userAgent}}function W0(e){return{...e,width:e.height,height:e.width}}function ey(e,t,n){return e!=="fit"?e:!n.width||!n.height?1:Math.min(1,n.width/t.width,n.height/t.height)}function wu(e){return!!e.error||e.status!==void 0&&e.status>=400}function ty(e){if(!e.url)return"";let t=e.line!==void 0?`:${e.line+1}`:"",n=e.line!==void 0&&e.column!==void 0?`:${e.column+1}`:"";return`${e.url}${t}${n}`}function ny(e,t,n=!1){let o=e.filter(l=>l.level==="error"||n&&l.level==="warning");if(!o.length)return`### Console errors: ${t}
No errors.`;let a=[`### Console errors: ${t} (${o.length})`];return o.forEach((l,i)=>{let[c,...r]=l.text.split(`
`);a.push(`${i+1}. ${l.level==="warning"?"[warning] ":""}${c}`);for(let h of r.slice(0,8))a.push(`   ${h.trim()}`);let u=ty(l);u&&!l.text.includes(u)&&a.push(`   at ${u}`)}),a.join(`
`)}function oy(e){let t=e.error?e.canceled?"canceled":e.error:`${e.status}${e.mimeType?` ${e.mimeType}`:""}`,n=e.duration!==void 0?`, ${Math.round(e.duration)} ms`:"";return`- ${e.method} ${e.url} \u2192 ${t} (${e.type}${n})`}function ay(e,t){let n=e.filter(wu);return n.length?[`### Failed network requests: ${t} (${n.length})`,...n.map(oy)].join(`
`):`### Failed network requests: ${t}
No failed requests.`}function ly(e){let t=["### Page context",`- URL: ${e.url}`,`- Title: ${e.title}`,`- Viewport: ${e.viewport.width}\xD7${e.viewport.height}${e.device?` (emulating ${e.device})`:""}`];e.selection&&t.push(`- Selected text: "${e.selection.slice(0,500)}"`);let n=e.console.filter(a=>a.level==="error").slice(-5);if(n.length){t.push("",`Recent console errors (${n.length}):`);for(let a of n){let l=ty(a);t.push(`- ${a.text.split(`
`)[0]}${l?` (${l})`:""}`)}}let o=e.network.filter(wu).slice(-5);return o.length&&t.push("",`Failed requests (${o.length}):`,...o.map(oy)),t.join(`
`)}var{PI:Yk}=Math,ac=Yk+1e-4,iy=.5,cy=[1,1];function ry(e,t,n,o=a=>a){return e*o(.5-t*(.5-n))}var{min:ip}=Math;function gy(e,t,n){let o=ip(1,t/n);return ip(1,e+(ip(1,1-o)-e)*(o*.275))}function Vk(e){return[-e[0],-e[1]]}function Tn(e,t){return[e[0]+t[0],e[1]+t[1]]}function uy(e,t,n){return e[0]=t[0]+n[0],e[1]=t[1]+n[1],e}function Lo(e,t){return[e[0]-t[0],e[1]-t[1]]}function up(e,t,n){return e[0]=t[0]-n[0],e[1]=t[1]-n[1],e}function Bo(e,t){return[e[0]*t,e[1]*t]}function cp(e,t,n){return e[0]=t[0]*n,e[1]=t[1]*n,e}function jk(e,t){return[e[0]/t,e[1]/t]}function vy(e){return[e[1],-e[0]]}function rp(e,t){let n=t[0];return e[0]=t[1],e[1]=-n,e}function sy(e,t){return e[0]*t[0]+e[1]*t[1]}function Xk(e,t){return e[0]===t[0]&&e[1]===t[1]}function Kk(e){return Math.hypot(e[0],e[1])}function dy(e,t){let n=e[0]-t[0],o=e[1]-t[1];return n*n+o*o}function yy(e){return jk(e,Kk(e))}function Gk(e,t){return Math.hypot(e[1]-t[1],e[0]-t[0])}function sp(e,t,n){let o=Math.sin(n),a=Math.cos(n),l=e[0]-t[0],i=e[1]-t[1],c=l*a-i*o,r=l*o+i*a;return[c+t[0],r+t[1]]}function fy(e,t,n,o){let a=Math.sin(o),l=Math.cos(o),i=t[0]-n[0],c=t[1]-n[1],r=i*l-c*a,u=i*a+c*l;return e[0]=r+n[0],e[1]=u+n[1],e}function py(e,t,n){return Tn(e,Bo(Lo(t,e),n))}function Qk(e,t,n,o){let a=n[0]-t[0],l=n[1]-t[1];return e[0]=t[0]+a*o,e[1]=t[1]+l*o,e}function wy(e,t,n){return Tn(e,Bo(t,n))}var tt=[0,0],Uo=[0,0],Ho=[0,0];function Zk(e,t){let n=wy(e,yy(vy(Lo(e,Tn(e,[1,1])))),-t),o=[],a=1/13;for(let l=a;l<=1;l+=a)o.push(sp(n,e,ac*2*l));return o}function Jk(e,t,n){let o=[],a=1/n;for(let l=a;l<=1;l+=a)o.push(sp(t,e,ac*l));return o}function $k(e,t,n){let o=Lo(t,n),a=Bo(o,.5),l=Bo(o,.51);return[Lo(e,a),Lo(e,l),Tn(e,l),Tn(e,a)]}function Pk(e,t,n,o){let a=[],l=wy(e,t,n),i=1/o;for(let c=i;c<1;c+=i)a.push(sp(l,e,ac*3*c));return a}function Fk(e,t,n){return[Tn(e,Bo(t,n)),Tn(e,Bo(t,n*.99)),Lo(e,Bo(t,n*.99)),Lo(e,Bo(t,n))]}function my(e,t,n){return e===!1||e===void 0?0:e===!0?Math.max(t,n):e}function Ik(e,t,n){return e.slice(0,10).reduce((o,a)=>{let l=a.pressure;return t&&(l=gy(o,a.distance,n)),(o+l)/2},e[0].pressure)}function Wk(e,t={}){let{size:n=16,smoothing:o=.5,thinning:a=.5,simulatePressure:l=!0,easing:i=z=>z,start:c={},end:r={},last:u=!1}=t,{cap:h=!0,easing:m=z=>z*(2-z)}=c,{cap:p=!0,easing:f=z=>--z*z*z+1}=r;if(e.length===0||n<=0)return[];let x=e[e.length-1].runningLength,k=my(c.taper,n,x),E=my(r.taper,n,x),b=(n*o)**2,s=[],d=[],v=Ik(e,l,n),y=ry(n,a,e[e.length-1].pressure,i),T,w=e[0].vector,M=e[0].point,H=M,R=M,K=H,L=!1;for(let z=0;z<e.length;z++){let{pressure:j}=e[z],{point:W,vector:Se,distance:jo,runningLength:mt}=e[z],Ge=z===e.length-1;if(!Ge&&x-mt<3)continue;a?(l&&(j=gy(v,jo,n)),y=ry(n,a,j,i)):y=n/2,T===void 0&&(T=y);let Du=mt<k?m(mt/k):1,sc=x-mt<E?f((x-mt)/E):1;y=Math.max(.01,y*Math.min(Du,sc));let Xo=(Ge?e[z]:e[z+1]).vector,$t=Ge?1:sy(Se,Xo),Vl=sy(Se,w)<0&&!L,dc=$t!==null&&$t<0;if(Vl||dc){rp(tt,w),cp(tt,tt,y);for(let Fn=0;Fn<=1;Fn+=.07692307692307693)up(Uo,W,tt),fy(Uo,Uo,W,ac*Fn),R=[Uo[0],Uo[1]],s.push(R),uy(Ho,W,tt),fy(Ho,Ho,W,ac*-Fn),K=[Ho[0],Ho[1]],d.push(K);M=R,H=K,dc&&(L=!0);continue}if(L=!1,Ge){rp(tt,Se),cp(tt,tt,y),s.push(Lo(W,tt)),d.push(Tn(W,tt));continue}Qk(tt,Xo,Se,$t),rp(tt,tt),cp(tt,tt,y),up(Uo,W,tt),R=[Uo[0],Uo[1]],(z<=1||dy(M,R)>b)&&(s.push(R),M=R),uy(Ho,W,tt),K=[Ho[0],Ho[1]],(z<=1||dy(H,K)>b)&&(d.push(K),H=K),v=j,w=Se}let ne=[e[0].point[0],e[0].point[1]],ce=e.length>1?[e[e.length-1].point[0],e[e.length-1].point[1]]:Tn(e[0].point,[1,1]),O=[],V=[];if(e.length===1){if(!(k||E)||u)return Zk(ne,T||y)}else{k||E&&e.length===1||(h?O.push(...Jk(ne,d[0],13)):O.push(...$k(ne,s[0],d[0])));let z=vy(Vk(e[e.length-1].vector));E||k&&e.length===1?V.push(ce):p?V.push(...Pk(ce,z,y,29)):V.push(...Fk(ce,z,y))}return s.concat(V,d.reverse(),O)}var by=[0,0];function hy(e){return e!=null&&e>=0}function e2(e,t={}){let{streamline:n=.5,size:o=16,last:a=!1}=t;if(e.length===0)return[];let l=.15+(1-n)*.85,i=Array.isArray(e[0])?e:e.map(({x:p,y:f,pressure:x=iy})=>[p,f,x]);if(i.length===2){let p=i[1];i=i.slice(0,-1);for(let f=1;f<5;f++)i.push(py(i[0],p,f/4))}i.length===1&&(i=[...i,[...Tn(i[0],cy),...i[0].slice(2)]]);let c=[{point:[i[0][0],i[0][1]],pressure:hy(i[0][2])?i[0][2]:.25,vector:[...cy],distance:0,runningLength:0}],r=!1,u=0,h=c[0],m=i.length-1;for(let p=1;p<i.length;p++){let f=a&&p===m?[i[p][0],i[p][1]]:py(h.point,i[p],l);if(Xk(h.point,f))continue;let x=Gk(f,h.point);if(u+=x,p<m&&!r){if(u<o)continue;r=!0}up(by,h.point,f),h={point:f,pressure:hy(i[p][2])?i[p][2]:iy,vector:yy(by),distance:x,runningLength:u},c.push(h)}return c[0].vector=c[1]?.vector||[0,0],c}function xy(e,t={}){return Wk(e2(e,t),t)}var t2={pen:{size:1.4,thinning:.5},pencil:{size:.7,thinning:.25},marker:{size:2.5,thinning:0},brush:{size:2.2,thinning:.75,taper:!0},highlighter:{size:4,thinning:0,opacity:.35},neon:{size:1.4,thinning:.3}};function xu(e,t,n,o={}){let a=([l,i])=>[(l-n.offsetX)*n.scale,(i-n.offsetY)*n.scale];for(let l of t)l.kind==="blur"&&!o.skipRedactions&&a2(e,l,a,o.pixelSource);for(let l of t)if(l.kind!=="blur"){switch(e.save(),n2(e,l.style,n.scale),l.kind){case"stroke":o2(e,l.tool,l.points,l.style,n.scale,a);break;case"line":case"arrow":case"doubleArrow":{let[i,c]=[a(l.start),a(l.end)];e.beginPath(),e.moveTo(i[0],i[1]),e.lineTo(c[0],c[1]),e.stroke(),e.setLineDash([]);let r=ep(l.style)*n.scale;l.kind!=="line"&&Sy(e,i,c,r),l.kind==="doubleArrow"&&Sy(e,c,i,r);break}case"rect":{let[i,c]=[a(l.start),a(l.end)],[r,u,h,m]=[Math.min(i[0],c[0]),Math.min(i[1],c[1]),Math.abs(c[0]-i[0]),Math.abs(c[1]-i[1])];l.style.fill&&ky(e,()=>e.fillRect(r,u,h,m)),e.strokeRect(r,u,h,m);break}case"ellipse":{let[i,c]=[a(l.start),a(l.end)];e.beginPath(),e.ellipse((i[0]+c[0])/2,(i[1]+c[1])/2,Math.abs(c[0]-i[0])/2,Math.abs(c[1]-i[1])/2,0,0,Math.PI*2),l.style.fill&&ky(e,()=>e.fill()),e.stroke();break}case"text":{let i=If(l.style)*n.scale,[c,r]=a(l.at);e.font=`600 ${i}px system-ui, sans-serif`,e.textBaseline="top",e.setLineDash([]),e.lineWidth=Math.max(2,i/6),e.strokeStyle=Ey(l.style.color)?"rgba(0,0,0,0.75)":"rgba(255,255,255,0.85)",l.text.split(`
`).forEach((u,h)=>{e.strokeText(u,c,r+h*i*1.25),e.fillText(u,c,r+h*i*1.25)});break}case"callout":{let i=Wf(l.style)*n.scale,[c,r]=a(l.at);e.setLineDash([]),e.beginPath(),e.arc(c,r,i,0,Math.PI*2),e.fill(),e.lineWidth=Math.max(1.5,i/8),e.strokeStyle="rgba(255,255,255,0.9)",e.stroke(),e.fillStyle=Ey(l.style.color)?"#000":"#fff",e.font=`700 ${i*1.1}px system-ui, sans-serif`,e.textAlign="center",e.textBaseline="middle",e.fillText(String(l.number),c,r+i*.05);break}}e.restore(),l.id===o.selectedId&&l2(e,l,n)}}function n2(e,t,n){e.globalAlpha=t.opacity,e.strokeStyle=t.color,e.fillStyle=t.color,e.lineWidth=t.width*n,e.lineCap="round",e.lineJoin="round";let o=t.width*n;e.setLineDash(t.dash==="dashed"?[o*3,o*2]:t.dash==="dotted"?[.1,o*2]:[])}function o2(e,t,n,o,a,l){let i=t2[t];i.opacity!==void 0&&(e.globalAlpha=o.opacity*i.opacity,e.globalCompositeOperation="multiply"),t==="neon"&&(e.shadowColor=o.color,e.shadowBlur=12*a);let c=n.map(u=>[...l(u),u[2]]);if(o.dash!=="solid"||c.length<2){e.lineWidth=o.width*a*i.size,e.beginPath(),c.forEach(([u,h],m)=>m?e.lineTo(u,h):e.moveTo(u,h)),c.length===1&&e.lineTo(c[0][0]+.1,c[0][1]),e.stroke();return}let r=xy(c,{size:o.width*a*i.size,thinning:i.thinning,smoothing:.5,streamline:.4,simulatePressure:c.every(([,,u])=>u===.5),start:{taper:i.taper?o.width*a*6:0,cap:!0},end:{taper:i.taper?o.width*a*6:0,cap:!0}});if(r.length){e.beginPath(),e.moveTo(r[0][0],r[0][1]);for(let u=1;u<r.length;u++){let[h,m]=r[u-1],[p,f]=r[u];e.quadraticCurveTo(h,m,(h+p)/2,(m+f)/2)}e.closePath(),e.fill(),t==="neon"&&(e.shadowBlur=0,e.globalAlpha=.8,e.lineWidth=Math.max(1,o.width*a*.3),e.strokeStyle="rgba(255,255,255,0.8)",e.beginPath(),c.forEach(([u,h],m)=>m?e.lineTo(u,h):e.moveTo(u,h)),e.stroke())}}function Sy(e,t,n,o){let a=Math.atan2(n[1]-t[1],n[0]-t[0]);e.beginPath(),e.moveTo(n[0],n[1]),e.lineTo(n[0]-o*Math.cos(a-Math.PI/7),n[1]-o*Math.sin(a-Math.PI/7)),e.lineTo(n[0]-o*Math.cos(a+Math.PI/7),n[1]-o*Math.sin(a+Math.PI/7)),e.closePath(),e.fill()}function ky(e,t){let n=e.globalAlpha;e.globalAlpha=n*.25,t(),e.globalAlpha=n}function a2(e,t,n,o){let[a,l]=[n(t.start),n(t.end)],i=Math.round(Math.min(a[0],l[0])),c=Math.round(Math.min(a[1],l[1])),r=Math.round(Math.abs(l[0]-a[0])),u=Math.round(Math.abs(l[1]-a[1]));if(!(r<2||u<2)){if(e.save(),o){let h=Math.max(10,Math.round(Math.min(r,u)/5)),m=new OffscreenCanvas(Math.max(1,Math.ceil(r/h)),Math.max(1,Math.ceil(u/h)));m.getContext("2d").drawImage(o,i,c,r,u,0,0,m.width,m.height),e.imageSmoothingEnabled=!1,e.drawImage(m,0,0,m.width,m.height,i,c,r,u)}else e.fillStyle="rgba(128,128,128,0.9)",e.fillRect(i,c,r,u);e.restore()}}function l2(e,t,n){let o=tc(t);e.save(),e.setLineDash([4,4]),e.lineWidth=1,e.strokeStyle="#0a84ff",e.strokeRect((o.x-n.offsetX)*n.scale-3,(o.y-n.offsetY)*n.scale-3,o.width*n.scale+6,o.height*n.scale+6),e.restore()}function Ey(e){let t=e.replace("#","");if(t.length!==6)return!1;let[n,o,a]=[0,2,4].map(l=>parseInt(t.slice(l,l+2),16));return n*.299+o*.587+a*.114>170}async function Ty(e,t,n,o){let a=await createImageBitmap(new Blob([e],{type:t})),l=new OffscreenCanvas(a.width,a.height),i=l.getContext("2d");i.drawImage(a,0,0),a.close(),o.length&&xu(i,o,{scale:l.width/n.width,offsetX:n.x,offsetY:n.y},{pixelSource:l});let c=await l.convertToBlob({type:"image/png"});return i2(new Uint8Array(await c.arrayBuffer()))}function i2(e){let t="";for(let n=0;n<e.length;n+=32768)t+=String.fromCharCode(...e.subarray(n,n+32768));return btoa(t)}var Ht=D(Ze(),1);var _l=D(q(),1),c2=1,Su=()=>`s${Date.now().toString(36)}${(c2++).toString(36)}`;function Cy({mapper:e,shapes:t,visible:n,interactive:o,tool:a,style:l,onChange:i,liveRedactions:c,pixelSource:r}){let u=c&&!r,h=(0,Ht.useRef)(null),[m,p]=(0,Ht.useState)(null),f=(0,Ht.useRef)(null),x=O=>{f.current=O,p(O)},[k,E]=(0,Ht.useState)(),[b,s]=(0,Ht.useState)(null),d=(0,Ht.useRef)(null),v=(0,Ht.useRef)(!1),{bounds:y,scale:T,scroll:w}=e;(0,Ht.useLayoutEffect)(()=>{let O=h.current;if(!O)return;let V=window.devicePixelRatio||1,z=Math.round(y.width*V),j=Math.round(y.height*V);(O.width!==z||O.height!==j)&&(O.width=z,O.height=j);let W=O.getContext("2d");if(W.clearRect(0,0,z,j),!n)return;let Se=O.closest(".viewport")?.querySelector(".viewport-canvas");xu(W,m?[...t,m]:t,{scale:T*V,offsetX:w.x,offsetY:w.y},{pixelSource:r??Se??void 0,skipRedactions:u,selectedId:o?k:void 0})},[u,r,t,m,n,o,k,y.width,y.height,T,w.x,w.y]),(0,Ht.useEffect)(()=>{if(!k)return;let O=V=>{(V.key==="Delete"||V.key==="Backspace")&&!r2(V)&&(V.preventDefault(),V.stopPropagation(),i(t.filter(z=>z.id!==k),!0),E(void 0))};return window.addEventListener("keydown",O,!0),()=>window.removeEventListener("keydown",O,!0)},[k,t,i]);let M=O=>{let V=O.currentTarget.getBoundingClientRect();return[(O.clientX-V.left)/T+w.x,(O.clientY-V.top)/T+w.y]},H=O=>{let V=t.filter(z=>!tp(z,O,6/T));V.length!==t.length&&i(V,!1)},R=()=>{b?.value.trim()&&i([...t,{id:Su(),kind:"text",at:b.at,text:b.value,style:l}],!0),s(null)},K=O=>{if(O.button!==0||!n)return;O.preventDefault();let V=M(O);if(b&&R(),a==="text"){let j=O.currentTarget.getBoundingClientRect();s({at:V,local:[O.clientX-j.left,O.clientY-j.top],value:""});return}if(a==="callout"){let j=Math.max(0,...t.map(W=>W.kind==="callout"?W.number:0))+1;i([...t,{id:Su(),kind:"callout",at:V,number:j,style:l}],!0);return}if(O.currentTarget.setPointerCapture(O.pointerId),a==="eraser"){v.current=!0,i(t,!0),H(V);return}if(a==="select"){let j=[...t].reverse().find(W=>tp(W,V,6/T));E(j?.id),j&&(d.current={start:V,original:j},i(t,!0));return}let z=O.pressure||.5;L0.includes(a)?x({id:Su(),kind:"stroke",tool:a,points:[[...V,z]],style:l}):q0.includes(a)&&x({id:Su(),kind:a,start:V,end:V,style:l})},L=O=>{let V=M(O);if(v.current){H(V);return}if(d.current){let{start:j,original:W}=d.current,Se=X0(W,V[0]-j[0],V[1]-j[1]);i(t.map(jo=>jo.id===W.id?Se:jo),!1);return}let z=f.current;z&&(z.kind==="stroke"?x({...z,points:[...z.points,[...V,O.pressure||.5]]}):z.kind!=="text"&&z.kind!=="callout"&&x({...z,end:O.shiftKey?K0(z.kind,z.start,V):V}))},ne=()=>{v.current=!1,d.current=null;let O=f.current;if(!O)return;O.kind!=="stroke"&&O.kind!=="text"&&O.kind!=="callout"&&Math.hypot(O.end[0]-O.start[0],O.end[1]-O.start[1])*T<3||i([...t,O],!0),x(null)},ce=a==="select"?"default":a==="text"?"text":a==="eraser"?"cell":"crosshair";return(0,_l.jsxs)("div",{className:"drawing-layer",style:{...y,pointerEvents:n&&o?"auto":"none"},children:[u&&n&&(m?[...t,m]:t).map(O=>{if(O.kind!=="blur")return null;let[V,z]=[O.start,O.end];return(0,_l.jsx)("div",{className:"drawing-redaction",style:{left:(Math.min(V[0],z[0])-w.x)*T,top:(Math.min(V[1],z[1])-w.y)*T,width:Math.abs(z[0]-V[0])*T,height:Math.abs(z[1]-V[1])*T}},O.id)}),(0,_l.jsx)("canvas",{ref:h,style:{width:y.width,height:y.height,cursor:ce},onPointerDown:K,onPointerMove:L,onPointerUp:ne,onContextMenu:O=>O.preventDefault()}),b&&(0,_l.jsx)("textarea",{className:"drawing-text-input",autoFocus:!0,value:b.value,placeholder:"Type, then Enter",style:{left:b.local[0],top:b.local[1],color:l.color,fontSize:(12+l.width*2)*T},onChange:O=>s({...b,value:O.target.value}),onBlur:R,onKeyDown:O=>{O.stopPropagation(),O.key==="Enter"&&!O.shiftKey?(O.preventDefault(),R()):O.key==="Escape"&&s(null)}})]})}function r2(e){let t=e.target;return!!t&&(t.tagName==="INPUT"||t.tagName==="TEXTAREA"||t.isContentEditable)}var Ul=D(q(),1);function kt({variant:e="secondary",size:t="md",icon:n,iconEnd:o,loading:a,className:l,children:i,disabled:c,type:r="button",...u}){let h=a?"loading":n;return(0,Ul.jsxs)("button",{type:r,className:ae("button",e,t==="sm"&&"small",l),disabled:c||a,"aria-busy":a||void 0,...u,children:[h&&(0,Ul.jsx)("span",{className:ae("codicon",`codicon-${h}`,a&&"codicon-modifier-spin"),"aria-hidden":"true"}),i!==void 0&&(0,Ul.jsx)("span",{className:"button-label",children:i}),o&&(0,Ul.jsx)("span",{className:`codicon codicon-${o}`,"aria-hidden":"true"})]})}var Cn=D(Ze(),1),Ry=D(Sc(),1);function Ta(e){let t=e.trim().toLowerCase(),n=/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/.exec(t);if(n){let a=n[4]===void 0?1:n[4].endsWith("%")?parseFloat(n[4])/100:Number(n[4]);return{r:Number(n[1]),g:Number(n[2]),b:Number(n[3]),a}}let o=/^#([\da-f]{3}|[\da-f]{6})$/.exec(t);if(o){let a=o[1].length===3?[...o[1]].map(l=>l+l).join(""):o[1];return{r:parseInt(a.slice(0,2),16),g:parseInt(a.slice(2,4),16),b:parseInt(a.slice(4,6),16),a:1}}if(t==="transparent")return{r:0,g:0,b:0,a:0}}function Hl({r:e,g:t,b:n,a:o}){let a=l=>Math.round(l).toString(16).padStart(2,"0").toUpperCase();return`#${a(e)}${a(t)}${a(n)}${o<1?a(o*255):""}`}function u2(e,t){let n=e.a+t.a*(1-e.a);if(n===0)return{r:0,g:0,b:0,a:0};let o=(a,l)=>(a*e.a+l*t.a*(1-e.a))/n;return{r:o(e.r,t.r),g:o(e.g,t.g),b:o(e.b,t.b),a:n}}function Ny({r:e,g:t,b:n}){let o=a=>{let l=a/255;return l<=.03928?l/12.92:((l+.055)/1.055)**2.4};return .2126*o(e)+.7152*o(t)+.0722*o(n)}function My(e,t){let n=Ny(u2(e,t)),o=Ny(t),[a,l]=n>o?[n,o]:[o,n];return(a+.05)/(l+.05)}function zy(e,t,n){let o=t>=24||t>=18.66&&n>=700;return e>=(o?3:4.5)}function Ay({r:e,g:t,b:n}){let[o,a,l]=[e/255,t/255,n/255],i=Math.max(o,a,l),c=i-Math.min(o,a,l),r=0;return c&&(i===o?r=(a-l)/c%6:i===a?r=(l-o)/c+2:r=(o-a)/c+4),{h:(r*60+360)%360,s:i?c/i:0,v:i}}function Oy({h:e,s:t,v:n}){let o=a=>{let l=(a+e/60)%6;return(n-n*t*Math.max(0,Math.min(l,4-l,1)))*255};return{r:o(5),g:o(3),b:o(1),a:1}}function dp(e){let t=e.trim().replace(/^#?/,"#"),n=Ta(t);return n?Hl(n).toLowerCase():void 0}var ct=D(q(),1),s2=e=>Hl(Oy(e)).toLowerCase(),lc=e=>Ay(Ta(e)??{r:0,g:0,b:0,a:1});function Dy({value:e,onChange:t,label:n,presets:o=[],className:a}){let[l,i]=(0,Cn.useState)(!1),[c,r]=(0,Cn.useState)(null),[u,h]=(0,Cn.useState)(()=>lc(e)),[m,p]=(0,Cn.useState)(null),f=(0,Cn.useRef)(null),x=(0,Cn.useRef)(null),k=(0,Cn.useCallback)(y=>{i(!1),y==="escape"&&f.current?.focus()},[]);ru([f,x],l,k),lu(f,x,l);let E=y=>{h(y),p(null),t(s2(y))},b=(y,T,w,M)=>{let H=y.getBoundingClientRect(),R=Math.min(1,Math.max(0,(T-H.left)/H.width)),K=Math.min(1,Math.max(0,(w-H.top)/H.height));E(M==="area"?{...u,s:R,v:1-K}:{...u,h:R*359.9})},s=y=>({onPointerDown:T=>{T.currentTarget.setPointerCapture(T.pointerId),T.currentTarget.focus(),b(T.currentTarget,T.clientX,T.clientY,y)},onPointerMove:T=>{T.currentTarget.hasPointerCapture(T.pointerId)&&b(T.currentTarget,T.clientX,T.clientY,y)}}),d=y=>T=>{let w=T.shiftKey?.1:.01,M={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,1],ArrowDown:[0,-1]}[T.key];if(!M)return;T.preventDefault();let H=R=>Math.min(1,Math.max(0,R));E(y==="area"?{...u,s:H(u.s+M[0]*w),v:H(u.v+M[1]*w)}:{...u,h:Math.min(359.9,Math.max(0,u.h+(M[0]||M[1])*w*360))})},v=`hsl(${u.h} 100% 50%)`;return(0,ct.jsxs)(ct.Fragment,{children:[(0,ct.jsx)("button",{ref:f,type:"button",className:ae("swatch","color-picker-trigger",l&&"active",a),"aria-label":n,title:n,"aria-haspopup":"dialog","aria-expanded":l,onClick:()=>{if(l)return k();h(lc(e)),p(null),r(uu(f.current)),i(!0)}}),l&&c&&(0,Ry.createPortal)((0,ct.jsxs)("div",{ref:x,className:"color-picker","data-ink-popup":"",role:"dialog","aria-label":n,children:[(0,ct.jsx)("div",{className:"color-area",style:{background:v},role:"slider",tabIndex:0,"aria-label":"Saturation and brightness","aria-valuetext":`Saturation ${Math.round(u.s*100)}%, brightness ${Math.round(u.v*100)}%`,onKeyDown:d("area"),...s("area"),children:(0,ct.jsx)("span",{className:"color-handle",style:{left:`${u.s*100}%`,top:`${(1-u.v)*100}%`,background:e}})}),(0,ct.jsx)("div",{className:"color-hue",role:"slider",tabIndex:0,"aria-label":"Hue","aria-valuemin":0,"aria-valuemax":360,"aria-valuenow":Math.round(u.h),onKeyDown:d("hue"),...s("hue"),children:(0,ct.jsx)("span",{className:"color-handle",style:{left:`${u.h/360*100}%`,background:v}})}),(0,ct.jsxs)("div",{className:"color-row",children:[(0,ct.jsx)("span",{className:"color-preview",style:{background:e},"aria-hidden":"true"}),(0,ct.jsx)("input",{className:"color-hex","aria-label":"Hex color",spellCheck:!1,maxLength:7,value:m??e,onChange:y=>{p(y.target.value);let T=dp(y.target.value);T&&y.target.value.replace("#","").length===6&&(h(lc(T)),t(T))},onBlur:()=>p(null),onKeyDown:y=>{if(y.key!=="Enter")return;let T=dp(y.currentTarget.value);T&&(h(lc(T)),t(T),k("escape"))}})]}),o.length>0&&(0,ct.jsx)("div",{className:"color-presets",role:"group","aria-label":"Presets",children:o.map(y=>(0,ct.jsx)("button",{type:"button",className:ae("swatch","small",y===e&&"active"),style:{background:y},"aria-label":y,title:y,onClick:()=>{h(lc(y)),t(y)}},y))})]}),c)]})}var Et=D(Ze(),1),_y=D(Sc(),1);var nt=D(q(),1);function Nn({value:e,options:t,onChange:n,label:o,title:a,placeholder:l="Select\u2026",icon:i,renderValue:c,size:r="md",appearance:u="field",disabled:h,className:m,align:p="start"}){let[f,x]=(0,Et.useState)(!1),[k,E]=(0,Et.useState)(-1),[b,s]=(0,Et.useState)(null),d=(0,Et.useRef)(null),v=(0,Et.useRef)(null),y=(0,Et.useRef)({text:"",at:0}),T=(0,Et.useId)(),w=t.findIndex(z=>z.value===e),M=t[w],H=(0,Et.useCallback)(z=>{x(!1),(z==="escape"||z==="chosen")&&d.current?.focus()},[]);ru([d,v],f,H),lu(d,v,f,{align:p,matchWidth:!0});let R=z=>z>=0&&!t[z]?.disabled,K=(z,j)=>{for(let W=1;W<=t.length;W++){let Se=(z+j*W+t.length*2)%t.length;if(R(Se))return Se}return z},L=(z=w)=>{E(R(z)?z:K(-1,1)),s(uu(d.current)),x(!0)},ne=z=>{let j=t[z];!j||j.disabled||(H("chosen"),j.value!==e&&n(j.value))};(0,Et.useLayoutEffect)(()=>{f&&(v.current?.querySelector(`[data-index="${k}"]`)?.scrollIntoView({block:"nearest"}),v.current?.focus({preventScroll:!0}))},[f,k]);let ce=z=>{let j=Date.now(),W=(j-y.current.at<700?y.current.text:"")+z.toLowerCase();y.current={text:W,at:j};let Se=f?k:w,mt=[...t.keys()].map(Ge=>(Se+(W.length>1?0:1)+Ge)%t.length).find(Ge=>R(Ge)&&t[Ge].label.toLowerCase().startsWith(W));mt!==void 0&&(f?E(mt):t[mt].value!==e&&n(t[mt].value))},O=z=>{["ArrowDown","ArrowUp","Enter"," "].includes(z.key)?(z.preventDefault(),L()):z.key.length===1&&!z.ctrlKey&&!z.metaKey&&!z.altKey&&ce(z.key)},V=z=>{let W={ArrowDown:()=>E(Se=>K(Se,1)),ArrowUp:()=>E(Se=>K(Se,-1)),Home:()=>E(K(-1,1)),End:()=>E(K(t.length,-1)),PageDown:()=>E(Se=>Math.min(K(Se,1)+7,K(t.length,-1))),PageUp:()=>E(Se=>Math.max(K(Se,-1)-7,K(-1,1))),Enter:()=>ne(k)," ":()=>y.current.text&&Date.now()-y.current.at<700?ce(" "):ne(k),Tab:()=>H()}[z.key];W?(z.key!=="Tab"&&z.preventDefault(),W()):z.key.length===1&&!z.ctrlKey&&!z.metaKey&&!z.altKey&&ce(z.key)};return(0,nt.jsxs)(nt.Fragment,{children:[(0,nt.jsxs)("button",{ref:d,type:"button",className:ae("select",`size-${r}`,u==="quiet"&&"quiet",f&&"open",m),role:"combobox","aria-haspopup":"listbox","aria-expanded":f,"aria-controls":f?`${T}-list`:void 0,"aria-label":o,title:a??o,disabled:h,onClick:()=>f?H():L(),onKeyDown:O,children:[i&&(0,nt.jsx)("span",{className:`codicon codicon-${i}`,"aria-hidden":"true"}),!i&&M?.icon&&(0,nt.jsx)("span",{className:`codicon codicon-${M.icon}`,"aria-hidden":"true"}),(0,nt.jsx)("span",{className:ae("select-value",!M&&"placeholder"),children:M?c?c(M):M.label:l}),(0,nt.jsx)("span",{className:"codicon codicon-chevron-down select-chevron","aria-hidden":"true"})]}),f&&b&&(0,_y.createPortal)((0,nt.jsx)("div",{ref:v,id:`${T}-list`,className:"select-list","data-ink-popup":"",role:"listbox","aria-label":o,tabIndex:-1,"aria-activedescendant":k>=0?`${T}-${k}`:void 0,onKeyDown:V,children:t.map((z,j)=>[z.group&&z.group!==t[j-1]?.group?(0,nt.jsx)("div",{className:"select-group",role:"presentation",children:z.group},`g-${z.group}`):null,(0,nt.jsxs)("div",{id:`${T}-${j}`,"data-index":j,role:"option","aria-selected":j===w,"aria-disabled":z.disabled||void 0,className:ae("select-option",j===k&&"active",j===w&&"selected",z.disabled&&"disabled"),style:z.indent?{paddingLeft:4+z.indent*14}:void 0,onPointerMove:()=>!z.disabled&&E(j),onClick:()=>ne(j),children:[(0,nt.jsx)("span",{className:`codicon codicon-${j===w?"check":"blank"} select-check`,"aria-hidden":"true"}),z.icon&&(0,nt.jsx)("span",{className:`codicon codicon-${z.icon}`,"aria-hidden":"true"}),(0,nt.jsx)("span",{className:"select-option-label",children:z.label}),z.detail&&(0,nt.jsx)("span",{className:"select-option-detail",children:z.detail})]},z.value)])}),b)]})}var Uy=D(Ze(),1);var qo=D(q(),1);function fp({value:e,min:t,max:n,step:o=1,onChange:a,label:l,format:i=String,icon:c,showValue:r,className:u,disabled:h}){let m=(0,Uy.useRef)(null),p=b=>Math.min(n,Math.max(t,Math.round(b/o)*o)),f=b=>{let s=p(b);s!==e&&a(s)},x=b=>{let s=m.current?.getBoundingClientRect();s?.width&&f(t+(b-s.left)/s.width*(n-t))},k=n>t?(e-t)/(n-t):0,E=b=>{let s=Math.max(o,(n-t)/10),d={ArrowRight:e+o,ArrowUp:e+o,ArrowLeft:e-o,ArrowDown:e-o,PageUp:e+s,PageDown:e-s,Home:t,End:n};b.key in d&&(b.preventDefault(),f(d[b.key]))};return(0,qo.jsxs)("div",{className:ae("slider",h&&"disabled",u),title:`${l}: ${i(e)}`,children:[c&&(0,qo.jsx)("span",{className:`codicon codicon-${c}`,"aria-hidden":"true"}),(0,qo.jsxs)("div",{ref:m,className:"slider-track",role:"slider",tabIndex:h?-1:0,"aria-label":l,"aria-valuemin":t,"aria-valuemax":n,"aria-valuenow":e,"aria-valuetext":i(e),"aria-disabled":h||void 0,onKeyDown:h?void 0:E,onPointerDown:b=>{h||b.button!==0||(b.currentTarget.setPointerCapture(b.pointerId),b.currentTarget.focus(),x(b.clientX))},onPointerMove:b=>{b.currentTarget.hasPointerCapture(b.pointerId)&&x(b.clientX)},children:[(0,qo.jsx)("span",{className:"slider-fill",style:{width:`${k*100}%`}}),(0,qo.jsx)("span",{className:"slider-thumb",style:{left:`${k*100}%`}})]}),r&&(0,qo.jsx)("span",{className:"slider-value",children:i(e)})]})}var pp=D(q(),1),d2={select:"M3 2l9 5-4 1-2 4z",pen:"M11 2l3 3-8 8H3v-3zM9.5 3.5l3 3",pencil:"M11.5 2.5l2 2L6 12l-3 1 1-3zM10 4l2 2",marker:"M10 2l4 4-6 6H4v-4zM4 12l-2 2h4",brush:"M13.5 2.5c-2 1-5 4-6.5 6l1 1c2-1.5 5-4.5 6-6.5zM6.5 9.5c-2 0-3 1.5-3 3 0 .8-.5 1.2-1.5 1.5 3 .5 5.5-1 5.5-3.5",highlighter:"M9 2l5 5-5 5-5-5zM4 7l-2 5 3-1M2 14h12",neon:"M2 12c2-6 4 2 6-4s4 2 6-4M8 1v2M3 3l1.5 1.5M13 3l-1.5 1.5",line:"M3 13L13 3",arrow:"M3 13L13 3M7 3h6v6",doubleArrow:"M3 13L13 3M7 3h6v6M9 13H3V7",rect:"M2.5 3.5h11v9h-11z",ellipse:"M8 3c3.3 0 6 2.2 6 5s-2.7 5-6 5-6-2.2-6-5 2.7-5 6-5z",blur:"M2 2h4v4H2zM6 6h4v4H6zM10 2h4v4h-4zM2 10h4v4H2zM10 10h4v4h-4z",text:"M3 3h10M8 3v10M6 13h4",callout:"M8 2a5 5 0 110 10 5 5 0 010-10zM7 5.5l1.5-1v5M7 9.5h3",eraser:"M9 2l5 5-6 6H4l-2-2zM6 5l5 5M4 13h10"};function Hy({tool:e}){return(0,pp.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.3",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:(0,pp.jsx)("path",{d:d2[e]})})}var ge=D(q(),1),By=[[{tool:"select",label:"Select and move"}],[{tool:"pen",label:"Pen"},{tool:"pencil",label:"Pencil"},{tool:"marker",label:"Marker"},{tool:"brush",label:"Brush"},{tool:"highlighter",label:"Highlighter"},{tool:"neon",label:"Neon"}],[{tool:"line",label:"Line"},{tool:"arrow",label:"Arrow"},{tool:"doubleArrow",label:"Double arrow"},{tool:"rect",label:"Rectangle"},{tool:"ellipse",label:"Ellipse"}],[{tool:"text",label:"Text"},{tool:"callout",label:"Numbered callout"},{tool:"blur",label:"Redact (pixelate)"},{tool:"eraser",label:"Eraser"}]],f2=[{value:"solid",label:"Solid"},{value:"dashed",label:"Dashed"},{value:"dotted",label:"Dotted"}],Ly=By.flat().map(e=>e.tool);function qy(e){let{tool:t,style:n}=e,o=(l,i,c)=>{let r=on.find(h=>h.id===i),u=e.keyOf?e.keyOf(i):r?.keys[0]?St(r.keys[0],!1):c;return u?`${l} (${u})`:l},a=[...Ol,...e.recentColors.filter(l=>!Ol.includes(l))];return(0,ge.jsxs)("div",{className:"draw-toolbar",role:"toolbar","aria-label":"Drawing tools",children:[By.map((l,i)=>(0,ge.jsx)("div",{className:"draw-group",children:l.map(({tool:c,label:r})=>(0,ge.jsx)("button",{type:"button",className:`icon-button${t===c?" active":""}`,title:o(r,`draw.${c}`),"aria-label":r,"aria-pressed":t===c,onClick:()=>e.onTool(c),children:(0,ge.jsx)(Hy,{tool:c})},c))},i)),(0,ge.jsxs)("div",{className:"draw-group colors",role:"radiogroup","aria-label":"Colour",children:[a.slice(0,13).map(l=>(0,ge.jsx)("button",{type:"button",role:"radio","aria-checked":n.color===l,"aria-label":l,title:l,className:`swatch${n.color===l?" active":""}`,style:{background:l},onClick:()=>e.onStyle({color:l})},l)),(0,ge.jsx)(Dy,{value:n.color,label:"Custom colour",presets:Ol,onChange:l=>e.onStyle({color:l})})]}),(0,ge.jsxs)("div",{className:"draw-group",children:[(0,ge.jsx)(fp,{icon:"circle-small-filled",label:"Width",min:1,max:24,value:n.width,format:l=>`${l}px`,onChange:l=>e.onStyle({width:l})}),(0,ge.jsx)(fp,{icon:"color-mode",label:"Opacity",min:10,max:100,step:5,value:Math.round(n.opacity*100),format:l=>`${l}%`,onChange:l=>e.onStyle({opacity:l/100})}),(0,ge.jsx)(Nn,{size:"sm",appearance:"quiet",label:"Line style",value:n.dash,options:f2,onChange:l=>e.onStyle({dash:l})}),(0,ge.jsx)("button",{type:"button",className:`icon-button${n.fill?" active":""}`,title:o("Fill shapes","draw.fill"),"aria-label":"Fill shapes","aria-pressed":n.fill,onClick:()=>e.onStyle({fill:!n.fill}),children:(0,ge.jsx)("span",{className:"codicon codicon-circle-filled","aria-hidden":"true"})})]}),(0,ge.jsxs)("div",{className:"draw-group",children:[(0,ge.jsx)("button",{type:"button",className:"icon-button",title:o("Undo","draw.undo","Ctrl+Z"),"aria-label":"Undo",disabled:!e.canUndo,onClick:e.onUndo,children:(0,ge.jsx)("span",{className:"codicon codicon-discard","aria-hidden":"true"})}),(0,ge.jsx)("button",{type:"button",className:"icon-button",title:o("Redo","draw.redo","Ctrl+Y"),"aria-label":"Redo",disabled:!e.canRedo,onClick:e.onRedo,children:(0,ge.jsx)("span",{className:"codicon codicon-redo","aria-hidden":"true"})}),(0,ge.jsx)("button",{type:"button",className:"icon-button",title:o("Clear all drawings","draw.clear"),"aria-label":"Clear all drawings",disabled:!e.hasShapes,onClick:e.onClear,children:(0,ge.jsx)("span",{className:"codicon codicon-clear-all","aria-hidden":"true"})}),(0,ge.jsx)("button",{type:"button",className:`icon-button${e.visible?"":" active"}`,title:o(e.visible?"Hide drawings":"Show drawings","draw.visible"),"aria-label":e.visible?"Hide drawings":"Show drawings",onClick:e.onToggleVisible,children:(0,ge.jsx)("span",{className:`codicon codicon-${e.visible?"eye":"eye-closed"}`,"aria-hidden":"true"})})]}),(0,ge.jsx)(kt,{variant:"primary",size:"sm",icon:"device-camera",iconEnd:"chevron-down",className:"draw-capture",disabled:!e.hasShapes,title:o("Screenshot menu","draw.captureMenu"),onClick:l=>{let i=l.currentTarget.getBoundingClientRect();e.onCapture(i.left,i.bottom+2)},children:"Screenshot"}),(0,ge.jsx)("button",{type:"button",className:"icon-button draw-close",title:o("Stop drawing","draw.exit","Esc"),"aria-label":"Stop drawing",onClick:e.onClose,children:(0,ge.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]})}var p2={area:"draw.capture",groups:"draw.captureGroups",clean:"draw.captureClean",viewport:"draw.captureViewport",fullPage:"draw.captureFullPage"};function Yy(e,t){let n=(o,a,l)=>({label:a,icon:l,shortcut:t?.(p2[o]),onSelect:()=>e(o)});return[n("area","Drawing area","device-camera"),n("groups","Each drawing separately","layers"),n("clean","Drawing area without drawings","eye-closed"),{separator:!0},n("viewport","Visible area with drawings","screen-normal"),n("fullPage","Full page with drawings","file-media")]}var mp=D(q(),1);function Ne({icon:e,label:t,onClick:n,onContextMenu:o,disabled:a,active:l,spin:i,className:c}){return(0,mp.jsx)("button",{type:"button",className:["icon-button",l&&"active",c].filter(Boolean).join(" "),title:t,"aria-label":t,"aria-pressed":l,disabled:a,onClick:n,onContextMenu:o,children:(0,mp.jsx)("span",{className:`codicon codicon-${e}${i?" codicon-modifier-spin":""}`,"aria-hidden":"true"})})}var Jt=D(Ze(),1);var Bt=D(q(),1);function Vy({menu:e,onClose:t}){let n=(0,Jt.useRef)(null),[o]=(0,Jt.useState)(iu);return(0,Jt.useEffect)(()=>{let a=cu(()=>[n.current],o,()=>t()),l=i=>{i.key==="Escape"&&(i.preventDefault(),i.stopPropagation(),t())};return window.addEventListener("keydown",l,!0),window.addEventListener("blur",t),window.addEventListener("resize",t),()=>{a(),window.removeEventListener("keydown",l,!0),window.removeEventListener("blur",t),window.removeEventListener("resize",t)}},[t,o]),(0,Bt.jsx)("div",{ref:n,className:"menu-root",onContextMenu:a=>a.preventDefault(),children:(0,Bt.jsx)(jy,{items:e.items,x:e.x,y:e.y,onClose:t,focusFirst:!0})})}function jy({items:e,x:t,y:n,onClose:o,focusFirst:a,parent:l,onBack:i}){let c=(0,Jt.useRef)(null),[r,u]=(0,Jt.useState)(null),h=(0,Jt.useRef)(void 0);(0,Jt.useLayoutEffect)(()=>{let E=c.current;if(!E)return;let b=E.getBoundingClientRect(),s=t;l&&t+b.width>innerWidth-4&&(s=l.left-b.width+2),E.style.left=`${Math.max(4,Math.min(s,innerWidth-b.width-4))}px`,E.style.top=`${Math.max(4,Math.min(n,innerHeight-b.height-4))}px`,a&&E.querySelector(":scope > button:not(:disabled)")?.focus({preventScroll:!0})},[t,n,l,a]),(0,Jt.useEffect)(()=>()=>clearTimeout(h.current),[]);let m=()=>[...c.current?.querySelectorAll(":scope > button:not(:disabled)")??[]],p=(E,b,s)=>{clearTimeout(h.current),u({index:E,rect:b.getBoundingClientRect()}),s&&setTimeout(()=>c.current?.querySelector(":scope > .menu button:not(:disabled)")?.focus({preventScroll:!0}))},f=E=>{if(E.target instanceof HTMLElement&&E.target.closest(".menu")!==c.current)return;let b=m(),s=b.indexOf(document.activeElement);if(E.key==="ArrowDown"||E.key==="ArrowUp")E.preventDefault(),b[(s+(E.key==="ArrowDown"?1:-1)+b.length)%b.length]?.focus();else if(E.key==="ArrowLeft"&&i)E.preventDefault(),E.stopPropagation(),i();else if(E.key==="ArrowRight"){let d=b[s],v=d&&e[Number(d.dataset.index)];v&&"submenu"in v&&v.submenu&&(E.preventDefault(),p(Number(d.dataset.index),d,!0))}},x=r?e[r.index]:void 0,k=x&&"submenu"in x?x.submenu?.():void 0;return(0,Bt.jsxs)("div",{ref:c,className:"menu",role:"menu",style:{left:t,top:n},onKeyDown:f,children:[e.map((E,b)=>"separator"in E?(0,Bt.jsx)("div",{className:"menu-separator",role:"separator"},b):(0,Bt.jsxs)("button",{type:"button",role:"menuitem","data-index":b,"aria-haspopup":E.submenu?"menu":void 0,"aria-expanded":E.submenu?r?.index===b:void 0,className:`menu-item${r?.index===b?" expanded":""}`,disabled:E.disabled,onPointerEnter:s=>{clearTimeout(h.current);let d=s.currentTarget;E.disabled||d.focus({preventScroll:!0}),h.current=setTimeout(()=>E.submenu?p(b,d,!1):u(null),E.submenu?120:250)},onClick:s=>{if(E.submenu){p(b,s.currentTarget,s.detail===0);return}o(),E.onSelect()},children:[E.image?(0,Bt.jsx)("img",{className:"menu-image",src:E.image,alt:"",referrerPolicy:"no-referrer"}):(0,Bt.jsx)("span",{className:`codicon codicon-${E.icon??"blank"}`,"aria-hidden":"true"}),(0,Bt.jsx)("span",{className:"menu-label",children:E.label}),E.shortcut&&(0,Bt.jsx)("span",{className:"menu-shortcut",children:E.shortcut}),E.submenu&&(0,Bt.jsx)("span",{className:"codicon codicon-chevron-right menu-arrow","aria-hidden":"true"})]},b)),r&&k&&(0,Bt.jsx)(jy,{items:k.length?k:[{label:"(empty)",disabled:!0,onSelect:()=>{}}],x:r.rect.right-2,y:r.rect.top-5,parent:r.rect,onClose:o,onBack:()=>{u(null),c.current?.querySelector(`:scope > button[data-index="${r.index}"]`)?.focus()}},r.index)]})}var Jn=D(q(),1),m2=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),b2=[{action:"copy",label:"Copy details",icon:"copy"},{action:"chat",label:"Chat agent",icon:"comment-discussion",toVsCode:!0},{action:"terminal",label:"Terminal agent",icon:"terminal",toVsCode:!0},{action:"screenshot",label:"Screenshot",icon:"device-camera"},{action:"save",label:"Save",icon:"save",toVsCode:!0}];function Xy({count:e,map:t,canSend:n=!0,onAction:o,className:a,style:l}){let i=t["inspect.copy"]?.[0];return(0,Jn.jsxs)("div",{className:ae("selection-bar",a),style:l,role:"toolbar","aria-label":"Selected elements",onPointerDown:c=>c.stopPropagation(),children:[(0,Jn.jsxs)("span",{className:"selection-bar-count",children:[(0,Jn.jsx)("span",{className:"selection-bar-badge",children:e}),"selected"]}),b2.filter(c=>n||!c.toVsCode).map(({action:c,label:r,icon:u})=>(0,Jn.jsxs)(kt,{size:"sm",variant:c==="copy"?"primary":"ghost",icon:u,onClick:()=>o(c),children:[r,c==="copy"&&i&&(0,Jn.jsx)("span",{className:"keycaps size-sm",children:_o(i,m2).map(h=>(0,Jn.jsx)("kbd",{className:"keycap",children:h},h))})]},c)),(0,Jn.jsx)(Ne,{icon:"close",label:"Clear the selection",className:"small selection-bar-clear",onClick:()=>o("clear")})]})}var Mn=D(q(),1);function bp({checked:e,onChange:t,children:n,label:o,disabled:a,className:l,title:i}){return(0,Mn.jsxs)("button",{type:"button",role:"switch","aria-checked":e,"aria-label":n?void 0:o,title:i,disabled:a,className:ae("switch",e&&"on",l),onClick:()=>t(!e),children:[(0,Mn.jsx)("span",{className:"switch-track","aria-hidden":"true",children:(0,Mn.jsx)("span",{className:"switch-thumb"})}),n&&(0,Mn.jsx)("span",{className:"toggle-label",children:n})]})}function Ky({checked:e,onChange:t,children:n,label:o,disabled:a,className:l,title:i}){return(0,Mn.jsxs)("button",{type:"button",role:"checkbox","aria-checked":e,"aria-label":n?void 0:o,title:i,disabled:a,className:ae("checkbox",e&&"on",l),onClick:()=>t(!e),children:[(0,Mn.jsx)("span",{className:"checkbox-box","aria-hidden":"true",children:e&&(0,Mn.jsx)("span",{className:"codicon codicon-check"})}),n&&(0,Mn.jsx)("span",{className:"toggle-label",children:n})]})}var Yo=D(q(),1);function Gy({items:e,checked:t,onToggle:n,onOpen:o,className:a}){return(0,Yo.jsx)("ul",{className:ae("thumb-picker",a),"aria-label":"Screenshots",children:e.map(l=>{let i=t.has(l.id);return(0,Yo.jsxs)("li",{className:ae("thumb-picker-item",i&&"on"),title:l.label,children:[(0,Yo.jsx)("button",{type:"button",className:"thumb-picker-image","aria-label":o?`Open ${l.label}`:`Include ${l.label}`,"aria-pressed":o?void 0:i,onClick:()=>o?o(l.id):n(l.id),children:l.src?(0,Yo.jsx)("img",{src:l.src,alt:""}):(0,Yo.jsx)("span",{className:"codicon codicon-file-media","aria-hidden":"true"})}),(0,Yo.jsx)(Ky,{className:"thumb-picker-check",checked:i,label:`Include ${l.label}`,onChange:()=>n(l.id)})]},l.id)})})}var Qy="inkspect:request",ku="inkspect:response",hp="data-inkspect-target";async function pt(e){try{return await chrome.runtime.sendMessage(e)??{ok:!1,error:"No reply from the extension"}}catch(t){return{ok:!1,error:t instanceof Error?t.message:String(t)}}}var Eu="inkspectShortcuts",Ca=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),Jy=on.filter(e=>Pf.has(e.id)),h2={"mode.device":"Responsive view","mode.screenshot":"Screenshot menu","open.shortcuts":"Keyboard shortcuts"},$y=e=>h2[e.id]??e.label,Py=e=>e==="global"?"General":Wi[e],Zy=["global","inspect","draw","screenshot"],Fy=[...Zy,...Object.keys(Wi).filter(e=>!Zy.includes(e))];async function Iy(){let e=(await chrome.storage.sync.get(Eu))[Eu];return{overrides:T0(e?.shortcuts??{}),updated:typeof e?.updated=="number"?e.updated:0}}async function Wy(e){let{updated:t}=await Iy();await chrome.storage.sync.set({[Eu]:{shortcuts:e,updated:Math.max(Date.now(),t+1)}})}function e1(e){let t=()=>{Iy().then(o=>e(du(o.overrides,Ca),o))},n=(o,a)=>{a==="sync"&&o[Eu]&&t()};return chrome.storage.onChanged.addListener(n),t(),()=>chrome.storage.onChanged.removeListener(n)}async function gp(e,t,n){let o={...e},a=on.find(c=>c.id===t),l=a?ec(a,Ca).map(su):[],i=n!==void 0&&n.length===l.length&&n.every(c=>l.includes(c));n===void 0||i?delete o[t]:o[t]=n,await Wy(o)}async function t1(){await Wy({})}var Ll=0,Na=new Map,Bl,ic,cc,n1;function yp(){return Ll}var o1=e=>parseFloat(e)||0;function a1(e,t){return{value:e.style.getPropertyValue(t),priority:e.style.getPropertyPriority(t)}}function Tu(e,t,n){n.value?e.style.setProperty(t,n.value,n.priority):e.style.removeProperty(t)}function l1(){for(let e of document.body?.querySelectorAll("*")??[]){if(e===n1)continue;let t=Na.get(e);if(t&&e.style.getPropertyValue("top")===t.applied)continue;let n=getComputedStyle(e);if(n.position!=="fixed"&&n.position!=="sticky"){t&&Na.delete(e);continue}if(n.top==="auto")continue;let o=o1(n.top);if(o>=Ll)continue;let a=t??a1(e,"top"),l=`${o+Ll}px`;e.style.setProperty("top",l,"important"),Na.set(e,{...a,applied:l})}}function vp(){cc||(cc=setTimeout(()=>{cc=void 0,l1()},300))}function wp(e,t){n1=t;let n=document.documentElement;if(e<=0){g2();return}Bl||(Bl=a1(n,"margin-top")),Tu(n,"margin-top",Bl);let o=o1(getComputedStyle(n).marginTop);if(n.style.setProperty("margin-top",`${o+e}px`,"important"),e!==Ll){for(let[a,l]of Na)Tu(a,"top",l);Na.clear()}Ll=e,l1(),ic||(ic=new MutationObserver(vp),ic.observe(document.documentElement,{subtree:!0,childList:!0,attributes:!0,attributeFilter:["class","style"]}),addEventListener("resize",vp))}function g2(){clearTimeout(cc),cc=void 0,ic?.disconnect(),ic=void 0,removeEventListener("resize",vp);for(let[e,t]of Na)Tu(e,"top",t);Na.clear(),Bl&&Tu(document.documentElement,"margin-top",Bl),Bl=void 0,Ll=0}var i1=(e=2)=>new Promise(t=>{let n=o=>o?requestAnimationFrame(()=>n(o-1)):setTimeout(t,30);n(e)});async function v2(e){let t=new Image;return t.src=e,await t.decode(),t}async function rc(e){let t=e();await i1();try{let n=await pt({type:"capture"});if(!n.ok||!n.dataUrl)throw new Error(n.ok?"No image":n.error);return await v2(n.dataUrl)}finally{t()}}function y2(){let e=[];for(let t of document.querySelectorAll("body *")){let n=getComputedStyle(t).position;(n==="fixed"||n==="sticky")&&(e.push([t,t.style.getPropertyValue("visibility")]),t.style.setProperty("visibility","hidden","important"))}return()=>{for(let[t,n]of e)n?t.style.setProperty("visibility",n):t.style.removeProperty("visibility")}}function w2(e,t){return Math.min(1,32e3/t,32e3/e,Math.sqrt(25e7/(e*t)))}async function uc(e,t){let n=document.documentElement,o=Math.max(n.scrollWidth,innerWidth),a=Math.max(n.scrollHeight,innerHeight),l=Math.max(0,Math.floor(e.x)),i=Math.max(0,Math.floor(e.y)),c={x:l,y:i,width:Math.max(1,Math.min(Math.ceil(e.width+e.x-l),o-l)),height:Math.max(1,Math.min(Math.ceil(e.height+e.y-i),a-i))},r={x:scrollX,y:scrollY},u=c.x>=scrollX&&c.y>=scrollY&&c.x+c.width<=scrollX+n.clientWidth&&c.y+c.height<=scrollY+n.clientHeight,h=devicePixelRatio,m=w2(c.width*h,c.height*h),p=document.createElement("canvas");p.width=Math.round(c.width*h*m),p.height=Math.round(c.height*h*m);let f=p.getContext("2d"),x=(E,b,s)=>{let d=E.width/innerWidth,v=(c.x-b)*d,y=Math.max(0,c.y-s)*d,T=Math.max(0,s-c.y),w=Math.min(c.height-T,n.clientHeight-Math.max(0,c.y-s));w<=0||f.drawImage(E,v,y,c.width*d,w*d,0,T*h*m,p.width,w*h*m)};if(u)return x(await rc(t),scrollX,scrollY),{dataUrl:p.toDataURL("image/png"),area:c};let k;try{let E=Math.min(c.x,Math.max(0,o-n.clientWidth));for(let b=c.y;b<c.y+c.height;){scrollTo(E,b),await i1(),x(await rc(t),scrollX,scrollY);let s=scrollY+n.clientHeight;if(s>=c.y+c.height||s>=a)break;b=s,k??=y2()}}finally{k?.(),scrollTo(r.x,r.y)}return{dataUrl:p.toDataURL("image/png"),area:c}}function xp(){let e=document.documentElement,t=yp();return{x:scrollX,y:scrollY+t,width:e.clientWidth,height:e.clientHeight-t}}function Sp(){let e=document.documentElement,t=yp();return{x:0,y:t,width:e.clientWidth,height:Math.max(e.scrollHeight,innerHeight)-t}}async function c1(e){let t=e.getBoundingClientRect(),n=await rc(()=>()=>{}),o=n.width/innerWidth,a=document.createElement("canvas");return a.width=Math.round(t.width*o),a.height=Math.round(t.height*o),a.getContext("2d").drawImage(n,t.x*o,t.y*o,t.width*o,t.height*o,0,0,a.width,a.height),a.toDataURL("image/png")}var Pn=D(Ze());var Te=D(q(),1),Cu=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function r1({purpose:e,map:t,altLabel:n,helpKey:o,className:a,style:l}){let i=Cu?"\u2318":"Ctrl",c=Cu?"\u21E7":"Shift",r=u=>{let h=t[u]?.[0];return h?_o(h,Cu):[]};return e==="screenshot"?(0,Te.jsxs)("div",{className:ae("picker-hint",a),style:l,role:"status",children:[(0,Te.jsx)("span",{className:"picker-hint-lead",children:"Click an element to screenshot it"}),(0,Te.jsx)($n,{caps:r("inspect.exit"),label:"cancel"})]}):(0,Te.jsxs)("div",{className:ae("picker-hint",a),style:l,role:"status",children:[(0,Te.jsxs)("span",{className:"picker-hint-group",children:[(0,Te.jsxs)("span",{className:"picker-hint-item",children:[(0,Te.jsx)("span",{className:"picker-hint-lead",children:"Click"}),(0,Te.jsx)("span",{className:"picker-hint-label",children:"copy details"})]}),(0,Te.jsx)($n,{caps:[i],click:!0,label:"chat agent"}),(0,Te.jsx)($n,{caps:[i,c],click:!0,label:"terminal agent"}),(0,Te.jsx)($n,{caps:[c],click:!0,label:"select"}),(0,Te.jsx)($n,{caps:[Cu?"\u2325":"Alt"],click:!0,label:n})]}),(0,Te.jsxs)("span",{className:"picker-hint-group",children:[(0,Te.jsx)($n,{caps:[...r("inspect.parent"),...r("inspect.child")],label:"parent / child"}),(0,Te.jsx)($n,{caps:r("inspect.copy"),label:"copy selected"}),(0,Te.jsx)($n,{caps:r("inspect.exit"),label:"stop"}),o&&(0,Te.jsx)($n,{caps:r("inspect.help"),label:"all keys"})]})]})}function $n({caps:e,click:t,label:n}){return e.length?(0,Te.jsxs)("span",{className:"picker-hint-item",children:[(0,Te.jsx)("span",{className:"keycaps size-sm",children:e.map((o,a)=>(0,Te.jsx)("kbd",{className:"keycap",children:o},a))}),t&&(0,Te.jsx)("span",{className:"picker-hint-click",children:"+ click"}),(0,Te.jsx)("span",{className:"picker-hint-label",children:n})]}):null}var Z=D(q()),x2={Escape:"inspect.exit",ArrowUp:"inspect.parent",ArrowDown:"inspect.child",Enter:"inspect.copy"},Ye=e=>parseFloat(e)||0;function S2(e){let t=e.getBoundingClientRect(),n=getComputedStyle(e),o={x:t.x,y:t.y,width:t.width,height:t.height},a={x:o.x-Ye(n.marginLeft),y:o.y-Ye(n.marginTop),width:o.width+Ye(n.marginLeft)+Ye(n.marginRight),height:o.height+Ye(n.marginTop)+Ye(n.marginBottom)},l={x:o.x+Ye(n.borderLeftWidth),y:o.y+Ye(n.borderTopWidth),width:o.width-Ye(n.borderLeftWidth)-Ye(n.borderRightWidth),height:o.height-Ye(n.borderTopWidth)-Ye(n.borderBottomWidth)},i={x:l.x+Ye(n.paddingLeft),y:l.y+Ye(n.paddingTop),width:l.width-Ye(n.paddingLeft)-Ye(n.paddingRight),height:l.height-Ye(n.paddingTop)-Ye(n.paddingBottom)};return{margin:a,border:o,padding:l,content:i}}function k2(e){let t={r:255,g:255,b:255,a:1},n=[];for(let o=e;o;o=o.parentElement){let a=Ta(getComputedStyle(o).backgroundColor);if(a&&a.a>0&&(n.push(a),a.a>=1))break}for(let o of n.reverse())t={r:o.r*o.a+t.r*(1-o.a),g:o.g*o.a+t.g*(1-o.a),b:o.b*o.a+t.b*(1-o.a),a:1};return t}function E2(e){let t=e;return t.disabled?!1:t.tabIndex>=0}var u1=(e,t)=>{let n=["Top","Right","Bottom","Left"].map(o=>e.getPropertyValue(`${t}-${o.toLowerCase()}`));return n.every(o=>o===n[0])?n[0]:n[0]===n[2]&&n[1]===n[3]?`${n[0]} ${n[1]}`:n.join(" ")};function T2(e){let t=getComputedStyle(e),n=e.getBoundingClientRect(),o=Ta(t.color),a=Ta(t.backgroundColor),l=k2(e),i=!!e.innerText?.trim(),c=o&&i?My(o,l):void 0,{role:r,name:u}=vu(e),h=u1(t,"margin"),m=u1(t,"padding");return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList).slice(0,4),size:`${Math.round(n.width*100)/100} \xD7 ${Math.round(n.height*100)/100}`,color:i&&o?Hl(o):void 0,font:i?`${t.fontSize} ${t.fontFamily.split(",")[0].replace(/["']/g,"")}`:void 0,background:a&&a.a>0?Hl(a):void 0,margin:h!=="0px"?h:void 0,padding:m!=="0px"?m:void 0,ratio:c,ratioPasses:c!==void 0?zy(c,Ye(t.fontSize),Number(t.fontWeight)||400):void 0,role:r,name:u,focusable:E2(e),rect:n}}function s1({host:e,purpose:t,selection:n,onPick:o,onCommit:a,onExit:l,actionOf:i,map:c}){let[r,u]=(0,Pn.useState)(null),[,h]=(0,Pn.useState)(0),m=(0,Pn.useRef)(null),p=(0,Pn.useRef)({onPick:o,onCommit:a,onExit:l,actionOf:i});(0,Pn.useEffect)(()=>{p.current={onPick:o,onCommit:a,onExit:l,actionOf:i}}),(0,Pn.useEffect)(()=>{let d=L=>L.composedPath().includes(e),v=(L,ne)=>document.elementsFromPoint(L,ne).find(ce=>ce!==e&&!e.contains(ce))??null,y=L=>{m.current=L,u(L)},T=L=>{if(d(L))return;let ne=v(L.clientX,L.clientY);ne!==m.current&&y(ne)},w=L=>{d(L)||(L.preventDefault(),L.stopImmediatePropagation())},M=L=>{if(d(L))return;w(L);let ne=v(L.clientX,L.clientY)??m.current;if(ne){let ce=L.ctrlKey||L.metaKey;p.current.onPick(ne,{add:L.shiftKey&&!ce,screenshot:L.altKey,send:ce?L.shiftKey?"terminal":"chat":void 0})}},H=L=>{let ne=p.current.actionOf?p.current.actionOf(L):x2[L.key];if(d(L)&&ne!=="inspect.exit")return;let ce=m.current;if(ne==="inspect.exit")p.current.onExit();else if(ne==="inspect.parent"&&ce)y($0(ce)??ce);else if(ne==="inspect.child"&&ce)y(P0(ce)??ce);else if(ne==="inspect.copy")p.current.onCommit(ce);else return;L.preventDefault(),L.stopImmediatePropagation()},R=()=>h(L=>L+1),K=["mousedown","mouseup","pointerdown","pointerup","dblclick","auxclick","contextmenu"];window.addEventListener("mousemove",T,!0),window.addEventListener("click",M,!0),window.addEventListener("keydown",H,!0),window.addEventListener("scroll",R,!0),window.addEventListener("resize",R);for(let L of K)window.addEventListener(L,w,!0);return()=>{window.removeEventListener("mousemove",T,!0),window.removeEventListener("click",M,!0),window.removeEventListener("keydown",H,!0),window.removeEventListener("scroll",R,!0),window.removeEventListener("resize",R);for(let L of K)window.removeEventListener(L,w,!0)}},[e]);let f=r?.isConnected?T2(r):void 0,x=r?.isConnected?S2(r):void 0,k=d=>({left:d.x,top:d.y,width:Math.max(0,d.width),height:Math.max(0,d.height)}),E=250,b=f?f.rect.bottom+8+220<innerHeight?f.rect.bottom+8:Math.max(4,f.rect.top-8-220):0,s=f?Math.max(4,Math.min(f.rect.left,innerWidth-E-8)):0;return(0,Z.jsxs)("div",{className:"inspector",children:[(0,Z.jsx)(r1,{className:"inspect-hint",purpose:t,map:c,altLabel:"screenshot"}),x&&(0,Z.jsxs)(Z.Fragment,{children:[(0,Z.jsx)("div",{className:"hl hl-margin",style:k(x.margin)}),(0,Z.jsx)("div",{className:"hl hl-border",style:k(x.border)}),(0,Z.jsx)("div",{className:"hl hl-padding",style:k(x.padding)}),(0,Z.jsx)("div",{className:"hl hl-content",style:k(x.content)}),(0,Z.jsx)("div",{className:"hl hl-outline",style:k(x.border)})]}),n.map((d,v)=>{let y=d.getBoundingClientRect();return(0,Z.jsx)("div",{className:"selection-box",style:k(y),children:(0,Z.jsx)("span",{className:"selection-badge",children:v+1})},v)}),f&&(0,Z.jsxs)("div",{className:"tip",style:{left:s,top:b,width:E},children:[(0,Z.jsxs)("div",{className:"tip-head",children:[(0,Z.jsxs)("span",{children:[(0,Z.jsx)("span",{className:"tip-tag",children:f.tag}),f.id&&(0,Z.jsxs)("span",{className:"tip-id",children:["#",f.id]}),f.classes.map(d=>(0,Z.jsxs)("span",{className:"tip-class",children:[".",d]},d))]}),(0,Z.jsx)("span",{className:"tip-size",children:f.size})]}),f.color&&(0,Z.jsx)(Ma,{label:"Color",value:f.color,swatch:f.color}),f.font&&(0,Z.jsx)(Ma,{label:"Font",value:f.font}),f.background&&(0,Z.jsx)(Ma,{label:"Background",value:f.background,swatch:f.background}),f.margin&&(0,Z.jsx)(Ma,{label:"Margin",value:f.margin}),f.padding&&(0,Z.jsx)(Ma,{label:"Padding",value:f.padding}),(0,Z.jsx)("div",{className:"tip-section",children:"Accessibility"}),f.ratio!==void 0&&(0,Z.jsxs)("div",{className:"tip-row",children:[(0,Z.jsx)("span",{children:"Contrast"}),(0,Z.jsxs)("span",{children:[(0,Z.jsx)("span",{className:"tip-aa",style:{color:f.color,background:f.background},children:"Aa"})," ",f.ratio.toFixed(2)," ",(0,Z.jsx)("span",{className:f.ratioPasses?"ok":"bad",children:f.ratioPasses?"\u2713":"!"})]})]}),(0,Z.jsx)(Ma,{label:"Name",value:f.name??""}),(0,Z.jsx)(Ma,{label:"Role",value:f.role??"generic"}),(0,Z.jsxs)("div",{className:"tip-row",children:[(0,Z.jsx)("span",{children:"Keyboard-focusable"}),(0,Z.jsx)("span",{className:f.focusable?"ok":"muted",children:f.focusable?"\u2713":"\u2298"})]})]})]})}function Ma({label:e,value:t,swatch:n}){return(0,Z.jsxs)("div",{className:"tip-row",children:[(0,Z.jsx)("span",{children:e}),(0,Z.jsxs)("span",{className:"tip-value",children:[n&&(0,Z.jsx)("span",{className:"tip-swatch",style:{background:n}}),t]})]})}var zn=D(Ze());var Nu=D(Ze(),1);var f1=D(q(),1);function d1({children:e,confirmLabel:t,onConfirm:n,icon:o,variant:a="ghost",size:l="sm",disabled:i,title:c,className:r}){let[u,h]=(0,Nu.useState)(!1);return(0,Nu.useEffect)(()=>{if(!u)return;let m=setTimeout(()=>h(!1),4e3);return()=>clearTimeout(m)},[u]),(0,f1.jsx)(kt,{size:l,variant:u?"danger":a,icon:u?"warning":o,disabled:i,title:c,className:r,"aria-live":"polite",onClick:()=>{if(!u){h(!0);return}h(!1),n()},onBlur:()=>h(!1),children:u?t:e})}var ql=D(q(),1);function Mu({label:e,hint:t,error:n,inline:o,className:a,children:l}){return(0,ql.jsxs)("label",{className:ae("field",o&&"inline",a),children:[(0,ql.jsx)("span",{className:"field-label",children:e}),(0,ql.jsx)("span",{className:"field-control",children:l}),(n||t)&&(0,ql.jsx)("span",{className:ae("field-hint",n&&"error"),role:n?"alert":void 0,children:n??t})]})}var Vo=D(Ze(),1);var kp=D(q(),1),C2=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function p1({binding:e,size:t="md"}){let n=_o(e,C2);return(0,kp.jsx)("span",{className:`keycaps size-${t}`,"aria-label":n.join("+"),children:n.map((o,a)=>(0,kp.jsx)("kbd",{className:"keycap",children:o},a))})}var $=D(q(),1),Yl=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function b1({actions:e,scopes:t,map:n,overrides:o,query:a="",labelOf:l=u=>u.label,scopeLabel:i=u=>Wi[u],onSetKeys:c,onReset:r}){let[u,h]=(0,Vo.useState)(new Set),[m,p]=(0,Vo.useState)(null),f=(0,Vo.useMemo)(()=>new Set(e.map(d=>d.id)),[e]),x=(0,Vo.useMemo)(()=>C0(n).filter(d=>d.ids.every(v=>f.has(v))),[n,f]),k=d=>x.filter(v=>v.ids.includes(d)).map(v=>({key:v.key,other:v.ids.find(y=>y!==d)}));(0,Vo.useEffect)(()=>{if(!m)return;let d=y=>{if(y.preventDefault(),y.stopImmediatePropagation(),pu.has(y.key))return;let T=xa(y);if(!T.key)return;let w=!T.ctrl&&!T.alt&&!T.meta&&!T.shift,M=[...n[m.id]??[]];if(w&&T.key==="escape"){p(null);return}if(w&&T.key==="backspace"&&m.index!==void 0)M.splice(m.index,1);else{let H=fu(T);m.index===void 0?M.push(H):M[m.index]=H}c(m.id,[...new Set(M)]),p(null)},v=y=>{y.composedPath().some(w=>w instanceof HTMLElement&&w.classList.contains("key-recording"))||p(null)};return window.addEventListener("keydown",d,!0),window.addEventListener("pointerdown",v,!0),()=>{window.removeEventListener("keydown",d,!0),window.removeEventListener("pointerdown",v,!0)}},[m,n,c]);let E=a.trim().toLowerCase(),b=d=>!E||l(d).toLowerCase().includes(E)||d.id.toLowerCase().includes(E)||i(d.scope).toLowerCase().includes(E)||(n[d.id]??[]).some(v=>St(v,Yl).toLowerCase().includes(E)||M0(v,E)),s=d=>{let v=e.find(y=>y.id===d);return v?l(v):d};return(0,$.jsxs)("div",{className:"shortcut-list",children:[x.length>0&&(0,$.jsxs)("p",{className:"shortcuts-warning",role:"alert",children:[(0,$.jsx)("span",{className:"codicon codicon-warning","aria-hidden":"true"}),x.length===1?"1 key is":`${x.length} keys are`," used twice."]}),t.map(d=>{let v=e.filter(T=>T.scope===d&&b(T));if(!v.length)return null;let y=E!==""||!u.has(d);return(0,$.jsxs)("section",{className:"shortcut-group",children:[(0,$.jsxs)("button",{type:"button",className:"group-header","aria-expanded":y,onClick:()=>h(T=>{let w=new Set(T);return w.has(d)?w.delete(d):w.add(d),w}),children:[(0,$.jsx)("span",{className:`codicon codicon-chevron-${y?"down":"right"}`,"aria-hidden":"true"}),(0,$.jsx)("span",{className:`codicon codicon-${A0[d]} group-icon`,"aria-hidden":"true"}),(0,$.jsx)("span",{className:"group-title",children:i(d)}),(0,$.jsx)("span",{className:"group-count",children:v.length})]}),y&&v.map(T=>(0,$.jsx)(N2,{action:T,label:l(T),keys:n[T.id]??[],changed:T.id in o,conflicts:k(T.id).map(w=>({...w,otherLabel:s(w.other)})),recording:m?.id===T.id?m:null,onRecord:w=>p({id:T.id,index:w}),onCancel:()=>p(null),onRemove:w=>c(T.id,(n[T.id]??[]).filter((M,H)=>H!==w)),onReset:()=>r(T.id),onResolve:(w,M)=>c(w,(n[w]??[]).filter(H=>H!==M))},T.id))]},d)})]})}function N2({action:e,label:t,keys:n,changed:o,conflicts:a,recording:l,onRecord:i,onCancel:c,onRemove:r,onReset:u,onResolve:h}){let m=ec(e,Yl).map(f=>St(f,Yl)).join(", ")||"none",p=l!==null&&l.index===void 0;return(0,$.jsxs)("div",{className:`shortcut-item${o?" changed":""}${a.length?" conflict":""}`,children:[(0,$.jsxs)("div",{className:"shortcut-main",children:[(0,$.jsx)("span",{className:"shortcut-label",title:e.id,children:t}),(0,$.jsx)("span",{className:"shortcut-places",children:N0(e).map(f=>(0,$.jsx)("span",{className:`shortcut-tag ${f.id}`,title:f.title,children:f.label},f.id))}),(0,$.jsxs)("span",{className:"shortcut-actions",children:[o&&(0,$.jsx)(Ne,{icon:"discard",label:`Reset to default (${m})`,className:"small",onClick:u}),n.length>0&&!p&&(0,$.jsx)(Ne,{icon:"add",label:"Add another key",className:"small add-key",onClick:()=>i()})]}),(0,$.jsxs)("span",{className:"shortcut-keys-column",children:[n.map((f,x)=>l?.index===x?(0,$.jsx)(m1,{onCancel:c},f):(0,$.jsxs)("span",{className:"key-button-wrap",children:[(0,$.jsx)("button",{type:"button",className:"key-button",title:"Change: click, then press the new keys","aria-label":`${St(f,Yl)}: change`,onClick:()=>i(x),children:(0,$.jsx)(p1,{binding:f,size:"sm"})}),(0,$.jsx)("button",{type:"button",className:"key-remove","aria-label":`Remove ${St(f,Yl)}`,title:"Remove this key",onClick:()=>r(x),children:(0,$.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]},f)),p&&(0,$.jsx)(m1,{onCancel:c}),!n.length&&!p&&(0,$.jsxs)("button",{type:"button",className:"key-empty",title:"Add a key: click, then press the keys",onClick:()=>i(),children:[(0,$.jsx)("span",{className:"codicon codicon-add","aria-hidden":"true"}),"Add key"]})]})]}),a.map(({key:f,other:x,otherLabel:k})=>(0,$.jsxs)("div",{className:"shortcut-conflict",children:[(0,$.jsx)("span",{className:"codicon codicon-warning","aria-hidden":"true"}),(0,$.jsxs)("span",{children:[St(f,Yl)," is also \u201C",k,"\u201D"]}),(0,$.jsx)("button",{type:"button",className:"link-button",onClick:()=>h(x,f),children:"Remove it there"})]},`${f}-${x}`))]})}function m1({onCancel:e}){return(0,$.jsxs)("span",{className:"key-recording",role:"status",children:[(0,$.jsx)("span",{className:"recording-dot","aria-hidden":"true"}),"Press keys\u2026",(0,$.jsx)("button",{type:"button",className:"key-recording-cancel","aria-label":"Cancel",onClick:e,children:(0,$.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]})}var h1=D(Ze(),1);var za=D(q(),1);function Ep({value:e,options:t,onChange:n,label:o,iconOnly:a,size:l="md",className:i}){let c=(0,h1.useRef)(null),r=u=>{let h={ArrowRight:1,ArrowDown:1,ArrowLeft:-1,ArrowUp:-1}[u.key];if(!h)return;u.preventDefault();let m=t.findIndex(f=>f.value===e),p=t[(m+h+t.length)%t.length];n(p.value),c.current?.querySelector(`[data-value="${CSS.escape(p.value)}"]`)?.focus()};return(0,za.jsx)("div",{ref:c,className:ae("segmented",`size-${l}`,i),role:"radiogroup","aria-label":o,onKeyDown:r,children:t.map(u=>{let h=u.value===e;return(0,za.jsxs)("button",{type:"button",role:"radio","aria-checked":h,"aria-label":a?u.label:void 0,title:a||u.icon?u.label:void 0,"data-value":u.value,tabIndex:h?0:-1,className:ae("segment",h&&"checked"),onClick:()=>n(u.value),children:[u.icon&&(0,za.jsx)("span",{className:`codicon codicon-${u.icon}`,"aria-hidden":"true"}),!a&&(0,za.jsx)("span",{className:"segment-label",children:u.label}),u.count!==void 0&&(0,za.jsx)("span",{className:ae("segment-count",u.tone),children:u.count})]},u.value)})})}function Aa(e,t=2e3){let n=crypto.randomUUID();return new Promise(o=>{let a=i=>{let c;try{c=JSON.parse(i.detail)}catch{return}c.id===n&&(window.removeEventListener(ku,a),clearTimeout(l),o(c.result))},l=setTimeout(()=>{window.removeEventListener(ku,a),o(void 0)},t);window.addEventListener(ku,a),window.dispatchEvent(new CustomEvent(Qy,{detail:JSON.stringify({id:n,request:e})}))})}async function Tp(e){try{return await navigator.clipboard.writeText(e),!0}catch{let t=document.createElement("textarea");t.value=e,t.style.cssText="position:fixed;left:-9999px;top:0;opacity:0",document.documentElement.appendChild(t),t.select();let n=document.execCommand("copy");return t.remove(),n}}async function g1(e){try{let t=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({"image/png":t})]),!0}catch{return!1}}var M2={copyFormat:"markdown",fields:[...np],maxHtml:2e3,annotationPadding:40};async function Cp(){let e=await chrome.storage.sync.get("settings").catch(()=>({}));return{...M2,...e.settings}}function v1(e=new Date){let t=a=>String(a).padStart(2,"0"),n=`${e.getFullYear()}-${t(e.getMonth()+1)}-${t(e.getDate())}_${t(e.getHours())}-${t(e.getMinutes())}-${t(e.getSeconds())}`,o=(location.hostname||"page").replace(/[^a-z0-9.-]+/gi,"-").slice(0,40);return`screenshot-${n}-${o}.png`}var y1=D(q()),an="last-used",zu=e=>e===an?void 0:e;function Au({windows:e,value:t,onChange:n,className:o}){if(e.length<2)return null;let a=e.find(l=>l.lastUsed)??e[0];return(0,y1.jsx)(Nn,{size:"sm",label:"VS Code window to send to",icon:"vscode",className:o,value:t,onChange:n,options:[{value:an,label:`Last used (${a?.name??"VS Code"})`,icon:"history"},...e.map(l=>({value:l.id,label:l.name,icon:"window",detail:l.lastUsed?"last used":void 0,group:"Open windows"}))]})}var _=D(q());function Ou({title:e,onClose:t,children:n}){return(0,_.jsxs)("div",{className:"panel",role:"dialog","aria-label":e,children:[(0,_.jsxs)("div",{className:"panel-head",children:[(0,_.jsx)("span",{children:e}),(0,_.jsx)("button",{type:"button",className:"icon-button","aria-label":"Close",title:"Close",onClick:t,children:(0,_.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]}),(0,_.jsx)("div",{className:"panel-body",children:n})]})}var w1={network:"none",cpu:1,colorScheme:"default",print:!1,agent:!0};function x1({onClose:e,value:t,onChange:n}){let a=l=>n({...t,...l});return(0,_.jsxs)(Ou,{title:"Emulation",onClose:e,children:[(0,_.jsx)("p",{className:"note",children:"These need Chrome, Edge or Brave. The size works everywhere."}),(0,_.jsx)(bp,{checked:t.agent,disabled:!0,onChange:l=>a({agent:l}),children:"Device user agent and touch"}),(0,_.jsxs)("div",{className:"row",children:[(0,_.jsx)(Mu,{label:"Network",children:(0,_.jsx)(Nn,{size:"sm",label:"Network",disabled:!0,value:t.network,onChange:l=>a({network:l}),options:Object.entries(F0).map(([l,i])=>({value:l,label:i.label}))})}),(0,_.jsx)(Mu,{label:"CPU",children:(0,_.jsx)(Nn,{size:"sm",label:"CPU",disabled:!0,value:String(t.cpu),onChange:l=>a({cpu:Number(l)}),options:I0.map(l=>({value:String(l),label:l===1?"Normal":`${l}\xD7 slower`}))})})]}),(0,_.jsx)(Mu,{label:"Color scheme",children:(0,_.jsx)(Ep,{size:"sm",label:"Color scheme",value:t.colorScheme,onChange:l=>!1,options:[{value:"default",label:"Page default"},{value:"light",label:"Light",icon:"color-mode"},{value:"dark",label:"Dark",icon:"color-mode"}]})}),(0,_.jsx)(bp,{checked:t.print,disabled:!0,onChange:l=>a({print:l}),children:"Print media"}),!1]})}var z2={error:"error",warning:"warning",info:"info",debug:"debug",log:"circle-small"};function S1({onClose:e,copy:t,send:n,linked:o,windows:a,pageContext:l}){let[i,c]=(0,zn.useState)({console:[],network:[]}),[r,u]=(0,zn.useState)("console"),[h,m]=(0,zn.useState)(an);(0,zn.useEffect)(()=>{let s=!0,d=async()=>{let y=await Aa({kind:"logs"});s&&y&&c(y)};d();let v=setInterval(()=>{d()},1e3);return()=>{s=!1,clearInterval(v)}},[]);let p=async()=>await Aa({kind:"logs"})??i,f=i.console.filter(s=>s.level==="error"),x=i.network.filter(wu),k=r==="console"?i.console.slice(-200).reverse():[],E=r==="console"?!k.length:!x.length,b=s=>{l().then(d=>n(s,{text:d,label:"Page context"},h))};return(0,_.jsxs)(Ou,{title:"Console and network",onClose:e,children:[(0,_.jsxs)("div",{className:"console-tabs",children:[(0,_.jsx)(Ep,{size:"sm",label:"Show",className:"console-view",value:r,onChange:u,options:[{value:"console",label:"Console",icon:"terminal",count:f.length||void 0,tone:f.length?"error":void 0},{value:"network",label:"Failed requests",icon:"globe",count:x.length||void 0,tone:x.length?"error":void 0}]}),(0,_.jsx)(Ne,{icon:"clear-all",label:"Clear",onClick:()=>{Aa({kind:"clearLogs"}).then(()=>c({console:[],network:[]}))}})]}),(0,_.jsxs)("div",{className:"log",children:[r==="console"?k.map(s=>(0,_.jsxs)("div",{className:`log-row level-${s.level}`,children:[(0,_.jsx)("span",{className:`log-icon codicon codicon-${z2[s.level]??"circle-small"}`,"aria-hidden":"true"}),(0,_.jsx)("span",{className:"log-text",children:s.text}),s.url&&(0,_.jsxs)("span",{className:"log-source",title:s.url,children:[s.url.split("/").pop(),s.line!==void 0?`:${s.line+1}`:""]})]},s.id)):x.map(s=>(0,_.jsxs)("div",{className:"log-row level-error",title:s.url,children:[(0,_.jsx)("span",{className:"log-icon codicon codicon-error","aria-hidden":"true"}),(0,_.jsxs)("span",{className:"log-text",children:[s.method," ",s.url]}),(0,_.jsx)("span",{className:"log-source",children:s.error??s.status})]},s.id)),E&&(0,_.jsxs)("div",{className:"log-empty",children:[(0,_.jsx)("span",{className:"codicon codicon-check-all","aria-hidden":"true"}),(0,_.jsx)("strong",{children:r==="console"?"No console messages yet":"No failed requests"}),(0,_.jsx)("span",{children:"They are recorded while the toolbar is open on this page."})]})]}),(0,_.jsxs)("div",{className:"panel-group",children:[(0,_.jsx)("span",{className:"panel-group-title",children:"Copy for AI"}),(0,_.jsxs)("div",{className:"button-row wrap",children:[(0,_.jsx)(kt,{size:"sm",icon:"copy",onClick:()=>{p().then(s=>t(ny(s.console,location.href),"Console errors","errors"))},children:"Copy errors"}),(0,_.jsx)(kt,{size:"sm",icon:"copy",onClick:()=>{p().then(s=>t(ay(s.network,location.href),"Failed requests","network"))},children:"Copy failed requests"}),(0,_.jsx)(kt,{size:"sm",icon:"copy",onClick:()=>{l().then(s=>t(s,"Page context","page"))},children:"Copy page context"})]})]}),o&&(0,_.jsxs)("div",{className:"panel-group",children:[(0,_.jsx)("span",{className:"panel-group-title",children:"Send page context to VS Code"}),(0,_.jsx)(Au,{windows:a,value:h,onChange:m}),(0,_.jsxs)("div",{className:"button-row wrap",children:[(0,_.jsx)(kt,{size:"sm",variant:"primary",icon:"terminal",onClick:()=>b("terminal"),children:"Send to terminal"}),(0,_.jsx)(kt,{size:"sm",icon:"comment-discussion",onClick:()=>b("chat"),children:"Send to chat"})]})]})]})}function k1({onClose:e,status:t}){let[n,o]=(0,zn.useState)(""),[a,l]=(0,zn.useState)(),[i,c]=(0,zn.useState)(!1),r=async()=>{c(!0);let u=await pt({type:"pair",code:n});c(!1),l(u.ok?u.status?.error:u.error)};return(0,_.jsxs)(Ou,{title:"VS Code link",onClose:e,children:[(0,_.jsx)("p",{className:`status status-${t.state}`,children:t.state==="connected"?`Linked with ${t.peer??"VS Code"}. Bookmarks sync both ways, and screenshots can go to VS Code.`:t.state==="unpaired"?"VS Code is running but this browser is not paired yet.":t.state==="connecting"?"Connecting to VS Code\u2026":"VS Code is not reachable. Start VS Code with the VS Code Browser extension (its link is on by default)."}),t.state==="unpaired"&&(0,_.jsxs)(_.Fragment,{children:[(0,_.jsxs)("p",{className:"note",children:["In VS Code, click ",(0,_.jsx)("b",{children:"Pair Browser Extension"})," in the Browser side panel: that links this browser, no code needed. Or type a code from"," ",(0,_.jsx)("b",{children:"Browser: Pair Browser Extension with a Code"})," here."]}),(0,_.jsxs)("div",{className:"row",children:[(0,_.jsx)("input",{className:"code-input",inputMode:"numeric",maxLength:6,placeholder:"123456","aria-label":"Pairing code",value:n,onChange:u=>o(u.target.value.replace(/\D/g,"")),onKeyDown:u=>{u.stopPropagation(),u.key==="Enter"&&n.length===6&&r()}}),(0,_.jsx)("button",{type:"button",className:"button primary small",disabled:n.length!==6||i,onClick:()=>{r()},children:"Pair"})]})]}),a&&(0,_.jsx)("p",{className:"note error",children:a}),(0,_.jsx)("div",{className:"button-row",children:(0,_.jsx)("button",{type:"button",className:"button secondary small",onClick:()=>{pt({type:"openOptions"})},children:"Settings"})})]})}function E1({onClose:e,map:t,overrides:n,linked:o}){let[a,l]=(0,zn.useState)(""),i=Object.keys(n).length;return(0,_.jsxs)(Ou,{title:"Keyboard shortcuts",onClose:e,children:[(0,_.jsxs)("div",{className:"shortcuts-bar",children:[(0,_.jsx)(U0,{size:"sm",value:a,onChange:l}),(0,_.jsx)(d1,{icon:"discard",confirmLabel:"Click again to reset",title:"Reset all shortcuts (here and in VS Code)",disabled:!i,onConfirm:()=>{t1()},children:"Reset all"})]}),(0,_.jsxs)("p",{className:"note shortcuts-sync",children:[(0,_.jsx)("span",{className:`codicon codicon-${o?"sync":"cloud"}`,"aria-hidden":"true"}),o?"Shared with VS Code: changes here apply there too, and the other way round.":"Saved to your browser account. They sync with VS Code once it is linked."]}),(0,_.jsx)(b1,{actions:on,scopes:Fy,map:t,overrides:n,query:a,labelOf:$y,scopeLabel:Py,onSetKeys:(c,r)=>{gp(n,c,r)},onReset:c=>{gp(n,c,void 0)}})]})}var ln=D(Ze());var Re=D(q()),A2=[{value:"fit",label:"Fit"},...[.5,.75,1,1.25].map(e=>({value:String(e),label:`${e*100}%`}))],O2=[{value:"custom",label:"Custom size",icon:"screen-full"},...Dl.map(e=>({value:e.id,label:e.name,detail:`${e.width}\xD7${e.height}`,group:e.group,icon:e.group==="Desktops"?"vm":"device-mobile"}))],T1=32,R2=36;function N1({top:e,device:t,onDevice:n,zoom:o,onZoom:a,src:l,frameRef:i,emulationActive:c,onEmulation:r,onClose:u}){let h=(0,ln.useRef)(null),m=(0,ln.useRef)(null),[p,f]=(0,ln.useState)({width:0,height:0});(0,ln.useLayoutEffect)(()=>{let y=h.current,T=()=>f({width:y.clientWidth,height:y.clientHeight}),w=new ResizeObserver(T);return w.observe(y),T(),()=>w.disconnect()},[]);let[x,k]=(0,ln.useState)(null),E=x??ey(o,t,{width:p.width-T1*2,height:p.height-T1*2-R2}),b=(0,ln.useRef)(null),s=(y,T)=>(0,Re.jsx)("div",{className:`rv-handle rv-handle-${y}`,role:"separator","aria-label":T,title:T,onPointerDown:w=>{w.preventDefault(),w.currentTarget.setPointerCapture(w.pointerId),b.current={x:w.clientX,y:w.clientY,width:t.width,height:t.height},k(E)},onPointerMove:w=>{let M=b.current;if(!M)return;let H=(R,K)=>Math.round(Math.min(lp,Math.max(ap,R+2*K/E)));n({...t,presetId:void 0,width:y==="y"?t.width:H(M.width,w.clientX-M.x),height:y==="x"?t.height:H(M.height,w.clientY-M.y)})},onPointerUp:()=>{b.current=null,k(null)},onPointerCancel:()=>{b.current=null,k(null)}}),d=(y,T)=>{let w=Math.round(Number(T));!Number.isFinite(w)||w<ap||n({...t,presetId:void 0,[y]:Math.min(lp,w)})},v=Dl.find(y=>y.id===t.presetId);return(0,Re.jsxs)("div",{className:`rv${x!==null?" dragging":""}`,style:{top:e},children:[(0,Re.jsxs)("div",{className:"rv-controls",role:"toolbar","aria-label":"Responsive view",children:[(0,Re.jsx)(Nn,{size:"sm",label:"Device",className:"rv-device",value:v?v.id:"custom",options:O2,onChange:y=>{let T=Dl.find(w=>w.id===y);T?n(yu(T)):(n({...t,presetId:void 0}),requestAnimationFrame(()=>m.current?.focus()))}}),(0,Re.jsx)(C1,{label:"Width",value:t.width,onCommit:y=>d("width",y),inputRef:m}),(0,Re.jsx)("span",{className:"rv-times","aria-hidden":"true",children:"\xD7"}),(0,Re.jsx)(C1,{label:"Height",value:t.height,onCommit:y=>d("height",y)}),(0,Re.jsx)(Ne,{icon:"sync",label:"Rotate",onClick:()=>n(W0(t))}),(0,Re.jsx)("span",{className:"rv-divider","aria-hidden":"true"}),(0,Re.jsx)(Nn,{size:"sm",label:"Zoom",className:"rv-zoom",value:String(o),options:A2,onChange:y=>a(y==="fit"?"fit":Number(y))}),(0,Re.jsx)(Ne,{icon:"settings",label:"Network, CPU, color scheme and user agent",active:c,onClick:r}),(0,Re.jsx)(Ne,{icon:"close",label:"Close the responsive view",onClick:u})]}),(0,Re.jsx)("div",{className:"rv-area",ref:h,children:(0,Re.jsxs)("div",{className:"rv-stage",children:[(0,Re.jsxs)("div",{className:"rv-frame",children:[(0,Re.jsx)("div",{className:"rv-screen",style:{width:t.width*E,height:t.height*E},children:l&&(0,Re.jsx)("iframe",{ref:i,title:`${v?.name??"Custom size"} preview`,src:l,sandbox:"allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-top-navigation-by-user-activation",style:{width:t.width,height:t.height,transform:`scale(${E})`}})}),s("x","Drag to change the width"),s("y","Drag to change the height"),s("xy","Drag to change the size")]}),(0,Re.jsxs)("div",{className:"rv-caption",children:[v?.name??"Custom size"," \xB7 ",t.width," \xD7 ",t.height,E!==1&&` \xB7 ${Math.round(E*100)}%`]})]})})]})}function C1({label:e,value:t,onCommit:n,inputRef:o}){let[a,l]=(0,ln.useState)(null),i=(0,ln.useRef)(!1),c=()=>{a!==null&&n(a),l(null)};return(0,Re.jsx)(bu,{size:"sm",className:"rv-size",ref:o,"aria-label":e,inputMode:"numeric",value:a??String(t),onChange:r=>l(r.target.value.replace(/\D/g,"")),onFocus:r=>{r.currentTarget.select(),i.current=!0},onMouseUp:r=>{i.current&&r.preventDefault(),i.current=!1},onBlur:c,onKeyDown:r=>{r.key==="Enter"?c():r.key==="Escape"&&l(null)}})}var B=D(q()),D2=new Set(Jy.map(e=>e.id)),Ru=" (not available in the responsive view yet)",_2=/\b(failed|could not|can't|cannot|did not|didn't|nothing was|not linked|not running)\b/i,U2={highlighter:{...Ea,color:"#ffd60a",width:16,opacity:.4},marker:{...Ea,width:8},pencil:{...Ea,width:2}},H2={area:"Drawing screenshot",groups:"Drawing screenshot",clean:"Drawing area",viewport:"Annotated viewport",fullPage:"Annotated full page"};function M1({host:e,hideHost:t,toggleSignal:n}){let[o,a]=(0,A.useState)(!1),[l,i]=(0,A.useState)(null),[c,r]=(0,A.useState)(null),[u,h]=(0,A.useState)(null),[m,p]=(0,A.useState)(null),[f,x]=(0,A.useState)([]),[k,E]=(0,A.useState)({state:"offline"}),[b,s]=(0,A.useState)(!1),[d,v]=(0,A.useState)(()=>({map:du({},Ca),overrides:{}})),[y,T]=(0,A.useState)(null),[w,M]=(0,A.useState)(!1),[H,R]=(0,A.useState)(an),K=(0,A.useRef)(an),L=(0,A.useRef)(null);(0,A.useEffect)(()=>{L.current=m},[m]);let ne=(0,A.useRef)(null),ce=(0,A.useRef)(null),[O,V]=(0,A.useState)(0),[z,j]=(0,A.useState)(null),[W,Se]=(0,A.useState)("fit"),[jo,mt]=(0,A.useState)(null),[Ge,Du]=(0,A.useState)(w1),sc=(0,A.useRef)(null),Xo=(0,A.useRef)(null),[$t,Vl]=(0,A.useState)([]),[dc,Fn]=(0,A.useState)([]),[D1,_u]=(0,A.useState)([]),[In,Np]=(0,A.useState)("pen"),[fc,_1]=(0,A.useState)(U2),[U1,H1]=(0,A.useState)([]),[Mp,zp]=(0,A.useState)(!0),[jl,B1]=(0,A.useState)({x:scrollX,y:scrollY}),[Xl,L1]=(0,A.useState)({width:innerWidth,height:innerHeight}),Kl=(0,A.useRef)($t),[Oa,q1]=(0,A.useState)(null),[Y1,Ap]=(0,A.useState)(!1);(0,A.useEffect)(()=>{Kl.current=$t},[$t]);let Op=(0,A.useRef)(0);(0,A.useEffect)(()=>{n!==Op.current&&(Op.current=n,a(g=>(g&&(i(null),r(null),h(null),j(null),mt(null)),!g)))},[n]),(0,A.useLayoutEffect)(()=>{let g=ne.current;if(!o||!g)return;let S=new ResizeObserver(()=>V(g.offsetHeight));return S.observe(g),()=>S.disconnect()},[o]),(0,A.useEffect)(()=>{wp(o?O:0,e)},[o,O,e]),(0,A.useEffect)(()=>()=>wp(0,e),[e]);let Me=z!==null;(0,A.useEffect)(()=>{if(!Me)return;let g=document.documentElement,S=g.style.getPropertyValue("overflow"),N=g.style.getPropertyPriority("overflow");return g.style.setProperty("overflow","hidden","important"),()=>{S?g.style.setProperty("overflow",S,N):g.style.removeProperty("overflow")}},[Me]),(0,A.useEffect)(()=>e1((g,S)=>v({map:g,overrides:S.overrides})),[]),(0,A.useEffect)(()=>{if(!o)return;let g="",S=(ee=!1)=>{!ee&&location.href===g||(g=location.href,pt({type:"isBookmarked",url:g}).then(G=>G.ok&&M(!!G.bookmarked)))};S(!0);let N=setInterval(()=>S(),1e3),U=()=>S(!0);return addEventListener("focus",U),()=>{clearInterval(N),removeEventListener("focus",U)}},[o]);let Ko=(0,A.useCallback)(g=>{let S=d.map[g]?.[0];return S?St(S,Ca):void 0},[d.map]),Go=(g,S)=>{let N=Ko(S);return N?`${g} (${N})`:g};(0,A.useEffect)(()=>{Cp().then(U=>Xo.current=U),pt({type:"bridgeStatus"}).then(U=>U.ok&&U.status&&E(U.status));let g=U=>{U.type==="bridgeStatus"&&U.status&&E(U.status)};chrome.runtime.onMessage.addListener(g);let S=()=>B1({x:scrollX,y:scrollY}),N=()=>L1({width:innerWidth,height:innerHeight});return window.addEventListener("scroll",S,{passive:!0}),window.addEventListener("resize",N),()=>{chrome.runtime.onMessage.removeListener(g),window.removeEventListener("scroll",S),window.removeEventListener("resize",N)}},[]);let[Uu,Rp]=(0,A.useState)(new Set),pc=(0,A.useRef)(new Set),V1=g=>{pc.current=g,Rp(g)},re=(0,A.useCallback)((g,S,N={})=>{let U=N.tone??(_2.test(g)?"error":"info");p({id:Date.now(),message:g,actions:S,...N,tone:U});let ee=new Set((N.images??[]).map((G,He)=>He));pc.current=ee,Rp(ee),R(an),K.current=an},[]),Hu=z?.userAgent,Dp=z?.touch??!1;(0,A.useEffect)(()=>{},[Me,Hu,Dp,Ge,re]);let _p=(0,A.useCallback)(async()=>{i(null),r(N=>N==="console"?null:N),j(N=>N??yu(Dl[0]));let g=location.href,S=await pt({type:"allowFraming",url:g});S.ok||re(`The page may not load in the frame: ${S.error}`),mt(g)},[re]),mc=(0,A.useCallback)(()=>{j(null),mt(null),r(g=>g==="emulation"?null:g),pt({type:"endFraming"})},[]);(0,A.useEffect)(()=>{if(!m||m.held)return;let g=setTimeout(()=>p(S=>S?.id===m.id?null:S),m.actions?12e3:m.tone==="error"?8e3:3500);return()=>clearTimeout(g)},[m]);let Qo=(0,A.useCallback)(()=>{let g=t();return s(!0),()=>{g(),s(!1)}},[t]),ot=k.state==="connected",Bu=ot?k.windows??[]:[],Wn=(0,A.useCallback)(async(g,S,N=an)=>{let U=zu(N),ee=L.current?.id,G=await pt({type:"send",target:g,pageUrl:location.href,window:U,...S}),He=L.current;G.ok&&He&&He.id!==ee&&He.actions||(G.ok?g==="save"?re("Saved to VS Code",void 0,{tone:"success",detail:G.path}):g==="terminal"?re("Sent to the terminal agent",void 0,{tone:"success",detail:G.path}):g==="chat"&&re("Sent to VS Code chat",void 0,{tone:"success"}):re(G.error,void 0,{tone:"error"}))},[re]),Zo=(0,A.useCallback)((g,S,N)=>ot?pt({type:"send",target:"context",pageUrl:location.href,window:N,capture:g,...S}).then(()=>{}):Promise.resolve(),[ot]),Up=(0,A.useCallback)(async(g,S,N="text")=>{Zo(crypto.randomUUID(),{text:g,label:S,kind:N});let U=await Tp(g);re(U?`${S} copied`:`Could not copy ${S.toLowerCase()}`,void 0,{tone:U?"success":"error"})},[Zo,re]),cn=(0,A.useCallback)(async(g,S)=>{let N=typeof g=="string"?[g]:g;if(!N.length)return;let U=N.length>1,ee=ue=>U?`${S} ${ue+1} of ${N.length}`:S,G=N.map(()=>crypto.randomUUID()),He=U?crypto.randomUUID():void 0;N.forEach((ue,rn)=>{Zo(G[rn],{image:ue,label:ee(rn),kind:"screenshot",group:He})});let Qe=await g1(N[0]),Pt=()=>N.map((ue,rn)=>rn).filter(ue=>pc.current.has(ue)),to=()=>{for(let ue of Pt())pt({type:"download",dataUrl:N[ue],filename:`Inkspect/${v1()}`})},$o=ue=>async()=>{let rn=K.current,$l=Pt();if(U&&(ue==="chat"||ue==="terminal")&&$l.length){for(let An of $l)await Zo(G[An],{image:N[An],label:ee(An),kind:"screenshot",group:He},zu(rn));await Wn(ue,{label:`${$l.length} screenshots`,kind:"screenshot",captures:$l.map(An=>G[An])},rn);return}for(let An of $l)await Wn(ue,{image:N[An],label:ee(An),capture:G[An],kind:"screenshot"},rn)},Xu=ot?[{label:"Send to terminal",icon:"terminal",shortcut:"capture.terminal",partial:ue=>`Send ${ue} to terminal`,run:()=>{$o("terminal")()},toVsCode:!0},{label:"Send to chat",icon:"comment-discussion",shortcut:"capture.chat",partial:ue=>`Send ${ue} to chat`,run:()=>{$o("chat")()},toVsCode:!0},{label:U?"Save all":"Save",icon:"save",shortcut:"capture.save",partial:ue=>`Save ${ue}`,run:()=>{$o("save")()},toVsCode:!0},{label:U?"Download all":"Download",icon:"desktop-download",shortcut:"capture.download",partial:ue=>`Download ${ue}`,run:to}]:[{label:U?"Download all":"Download",icon:"desktop-download",shortcut:"capture.download",partial:ue=>`Download ${ue}`,run:to}],Zl=U?`${N.length} ${S.toLowerCase()} captured`:`${S} ${Qe?"copied":"taken"}`;re(Zl,Xu,{images:N,tone:"success",detail:U?`${Qe?"The first is copied. ":""}Uncheck any you don't want, then ${ot?"send them to VS Code or download them":"download them"}.`:ot?"Paste it anywhere, or send it to VS Code.":Qe?"Paste it anywhere, or download it.":"Download it to keep it."}),!Qe&&!ot&&!U&&to()},[ot,Wn,Zo,re]),eo=(0,A.useCallback)(async g=>{if(g==="region")return i({kind:"region"});if(g==="element")return i({kind:"inspect",purpose:"screenshot"});try{let S=g==="viewport"?xp():Sp(),{dataUrl:N}=await uc(S,Qo);await cn(N,g==="viewport"?"Screenshot":"Full-page screenshot")}catch(S){re(`Screenshot failed: ${S instanceof Error?S.message:String(S)}`)}},[cn,Qo,re]),Hp=(0,A.useCallback)(async g=>{let S=Xo.current?.maxHtml??2e3;g.setAttribute(hp,"");try{let N=await Aa({kind:"collect",maxHtml:S},1500);if(N&&!N.error&&N.tag)return N}finally{g.removeAttribute(hp)}return{...Z0(g,S,J0),...vu(g)}},[]),bc=(0,A.useCallback)(async g=>{let S=g.getBoundingClientRect();return uc({x:S.x+scrollX,y:S.y+scrollY,width:S.width,height:S.height},Qo)},[Qo]),j1=async g=>{let S=f;if(x([]),g!=="clear")if(g==="copy")await Gl(S);else if(g==="screenshot")try{let N=[];for(let U of S)N.push((await bc(U)).dataUrl);await cn(N,S.length===1?"Element screenshot":"Element screenshots")}catch(N){re(`Screenshot failed: ${N instanceof Error?N.message:String(N)}`)}else await Gl(S,g)},Gl=(0,A.useCallback)(async(g,S)=>{let N=Xo.current??await Cp(),U=await Promise.all(g.map(Hp)),ee=U.length===1,G=ee?nc(U[0]):`${U.length} elements`,He=gu(U,"markdown",N.fields),Qe=ee?void 0:crypto.randomUUID(),Pt=U.map(()=>crypto.randomUUID()),to=Jl=>Promise.all(U.map((ue,rn)=>Zo(Pt[rn],{text:ee?He:gu([ue],"markdown",N.fields),label:`Element ${nc(ue)}`,kind:"element",group:Qe},Jl))),$o=async(Jl,ue=an)=>{if(ee){await Wn(Jl,{text:He,label:`Element ${G}`,capture:Pt[0],kind:"element"},ue);return}await to(zu(ue)),await Wn(Jl,{label:G,kind:"element",captures:Pt},ue)};if(S==="save"){await Wn("save",{text:He,label:ee?`Element ${G}`:G,kind:"element"});return}if(S){await $o(S);return}let Xu=gu(U,N.copyFormat,N.fields);to();let Zl=await Tp(Xu);re(Zl?`Copied details of ${G}`:"Could not copy",ot?[{label:"Send to chat",icon:"comment-discussion",shortcut:"capture.chat",toVsCode:!0,run:()=>{$o("chat",K.current)}},{label:"Send to terminal",icon:"terminal",shortcut:"capture.terminal",toVsCode:!0,run:()=>{$o("terminal",K.current)}}]:void 0,{tone:Zl?"success":"error",detail:Zl?"Paste it into your AI chat.":void 0})},[Hp,ot,Wn,Zo,re]),X1=(0,A.useCallback)(async(g,S)=>{if(l?.kind==="inspect"&&l.purpose==="screenshot"){i(null);try{let{dataUrl:N}=await bc(g);await cn(N,"Element screenshot")}catch(N){re(`Screenshot failed: ${N instanceof Error?N.message:String(N)}`)}return}if(S.add){x(N=>N.includes(g)?N.filter(U=>U!==g):[...N,g]);return}if(S.screenshot){try{let{dataUrl:N}=await bc(g);await cn(N,"Element screenshot")}catch(N){re(`Screenshot failed: ${N instanceof Error?N.message:String(N)}`)}return}await Gl([g],S.send)},[bc,Gl,cn,re,l]),Bp=(0,A.useCallback)(async()=>{let g=await Aa({kind:"logs"});return ly({url:location.href,title:document.title,viewport:{width:innerWidth,height:innerHeight},selection:getSelection()?.toString()||void 0,console:g?.console??[],network:g?.network??[]})},[]),Lu=(0,A.useCallback)((g,S)=>{S&&(Fn(N=>[...N.slice(-99),Kl.current]),_u([])),Vl(g)},[]),Lp=(0,A.useCallback)(()=>{Fn(g=>{let S=g.at(-1);return S?(_u(N=>[...N,Kl.current]),Vl(S),g.slice(0,-1)):g})},[]),qp=(0,A.useCallback)(()=>{_u(g=>{let S=g.at(-1);return S?(Fn(N=>[...N,Kl.current]),Vl(S),g.slice(0,-1)):g})},[]),Jo=(0,A.useCallback)(async g=>{let S=Kl.current;if(!S.length&&(g==="area"||g==="groups"||g==="clean")){re("Draw something first.");return}let N=Xo.current?.annotationPadding??40,U=g==="groups"?j0(S,80):[S],ee=[];for(let G of U){let He=g==="viewport"?xp():g==="fullPage"?Sp():V0(G,N);if(He)try{let Qe=await uc(He,Qo),Pt=new Uint8Array(await(await fetch(Qe.dataUrl)).arrayBuffer()),to=await Ty(Pt,"image/png",Qe.area,g==="clean"?[]:G);ee.push(`data:image/png;base64,${to}`)}catch(Qe){re(`Screenshot failed: ${Qe instanceof Error?Qe.message:String(Qe)}`);return}}await cn(ee,ee.length>1?"Drawings":H2[g])},[cn,Qo,re]),Yp=$t.some(g=>g.kind==="blur")||l?.kind==="draw"&&In==="blur",qu=Oa&&Oa.x===jl.x&&Oa.y===jl.y&&Oa.width===Xl.width&&Oa.height===Xl.height?Oa.canvas:void 0;(0,A.useEffect)(()=>{if(!o||!Yp||qu)return;let g=!1,S=setTimeout(()=>{let N={x:scrollX,y:scrollY,width:innerWidth,height:innerHeight};rc(()=>(Ap(!0),()=>Ap(!1))).then(U=>{if(g)return;let ee=document.createElement("canvas");ee.width=Math.round(N.width*devicePixelRatio),ee.height=Math.round(N.height*devicePixelRatio),ee.getContext("2d").drawImage(U,0,0,ee.width,ee.height),q1({canvas:ee,...N})}).catch(()=>{})},250);return()=>{g=!0,clearTimeout(S)}},[o,Yp,qu,jl.x,jl.y,Xl.width,Xl.height]);let hc=g=>i(S=>S?.kind===g.kind?null:g),K1=(g,S,N)=>{let U=g.currentTarget.getBoundingClientRect();h({x:U.left,y:U.bottom+4,items:S}),T(N??null)},Vp=(g,S,N)=>{let U=ne.current?.querySelector(g);if(!U)return;let ee=U.getBoundingClientRect();h({x:ee.left,y:ee.bottom+4,items:S}),T(N)},Yu=()=>{h(null),T(null)},Ql=g=>{let S=fc[In]??Ea;_1(N=>({...N,[In]:{...S,...g}})),g.color&&H1(N=>[g.color,...N.filter(U=>U!==g.color)].slice(0,6))},jp=()=>{pt(w?{type:"unbookmarkPage",url:location.href}:{type:"bookmarkPage",url:location.href,title:document.title}).then(g=>{if(!g.ok)return re(g.error,void 0,{tone:"error"});M(!!g.bookmarked),re(g.bookmarked?"Bookmarked":"Bookmark removed",void 0,g.bookmarked?{tone:"success",detail:ot?"It syncs to VS Code.":void 0}:{})})},Xp=()=>[{label:"Visible area",icon:"device-camera",shortcut:Ko("shot.viewport"),onSelect:()=>{eo("viewport")}},{label:"Full page",icon:"file-media",shortcut:Ko("shot.fullPage"),onSelect:()=>{eo("fullPage")}},{label:"Select region...",icon:"screen-full",shortcut:Ko("shot.region"),onSelect:()=>{eo("region")}},{label:"Select element...",icon:"inspect",shortcut:Ko("shot.element"),onSelect:()=>{eo("element")}}],Kp=()=>Yy(g=>{Jo(g)},Ko),Gp=(0,A.useRef)({});if((0,A.useEffect)(()=>{let g=Object.fromEntries(Ly.map(G=>[`draw.${G}`,()=>Np(G)])),S=Object.fromEntries(Ol.slice(0,9).map((G,He)=>[`draw.color${He+1}`,()=>Ql({color:G})])),N=fc[In]?.width??Ea.width,U=m?.images&&m.images.length>1?m.images.length:0,ee=Object.fromEntries((m?.actions??[]).filter(G=>G.shortcut).map(G=>[G.shortcut,()=>{G.partial&&U&&!pc.current.size||(G.run(),p(null))}]));Gp.current={...ee,"mode.inspect":()=>!Me&&hc({kind:"inspect",purpose:"copy"}),"mode.draw":()=>!Me&&hc({kind:"draw"}),"mode.screenshot":()=>Me?void 0:Vp(".shot-button",Xp(),"screenshot"),"mode.device":()=>Me?mc():void _p(),"mode.devtools":()=>!Me&&r(G=>G==="console"?null:"console"),"page.bookmark":jp,"open.shortcuts":()=>r(G=>G==="shortcuts"?null:"shortcuts"),...g,...S,"draw.thinner":()=>Ql({width:Math.max(1,N-(N>6?2:1))}),"draw.thicker":()=>Ql({width:Math.min(24,N+(N>=6?2:1))}),"draw.fill":()=>Ql({fill:!(fc[In]?.fill??!1)}),"draw.undo":Lp,"draw.redo":qp,"draw.clear":()=>Lu([],!0),"draw.visible":()=>zp(G=>!G),"draw.capture":()=>{Jo("area")},"draw.captureGroups":()=>{Jo("groups")},"draw.captureClean":()=>{Jo("clean")},"draw.captureViewport":()=>{Jo("viewport")},"draw.captureFullPage":()=>{Jo("fullPage")},"draw.captureMenu":()=>Vp(".draw-capture",Kp(),"draw"),"draw.exit":()=>i(null),"shot.viewport":()=>{eo("viewport")},"shot.fullPage":()=>{eo("fullPage")},"shot.region":()=>{eo("region")},"shot.element":()=>{eo("element")},"shot.drawing":()=>{Jo("area")}}}),(0,A.useEffect)(()=>{if(c)return cu(()=>[ce.current],iu(),()=>r(null),g=>!ne.current||!g.composedPath().includes(ne.current)||v0(g))},[c]),(0,A.useEffect)(()=>{if(!o)return;let g=S=>{if(c==="shortcuts")return;let N=ne.current?.getRootNode(),U=S.composedPath().includes(e)&&N instanceof ShadowRoot?N.activeElement:S.composedPath()[0];if(U instanceof HTMLElement&&(U.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(U.tagName))||l?.kind==="inspect"||l?.kind==="region")return;if(S.key==="Escape"&&(u||c&&l?.kind!=="draw")){u?Yu():r(null),S.preventDefault(),S.stopImmediatePropagation();return}let G=m?.actions?["capture"]:[],He=u?y?[y]:[]:l?.kind==="draw"?[...G,"draw","global"]:[...G,"global"],Qe=$f(d.map,He,xa(S)),Pt=Qe&&D2.has(Qe.id)&&Gp.current[Qe.id];Pt&&(S.preventDefault(),S.stopImmediatePropagation(),u&&Yu(),Pt())};return window.addEventListener("keydown",g,!0),()=>window.removeEventListener("keydown",g,!0)},[o,l,c,u,y,d.map,e,m]),!o)return null;let Ra=B2(m?.actions??[],d.map),Vu=m?.images&&m.images.length>1?m.images.length:0,ju=Vu?Uu.size:0,G1={scale:1,scroll:jl,bounds:{left:0,top:0,...Xl}},Qp=fc[In]??Ea;return(0,B.jsxs)("div",{className:`inkspect${b?" capturing":""}${Y1?" sampling":""}`,children:[($t.length>0||l?.kind==="draw")&&(0,B.jsx)("div",{className:"draw-host",children:(0,B.jsx)(Cy,{mapper:G1,shapes:$t,visible:Mp,interactive:l?.kind==="draw",tool:In,style:Qp,onChange:Lu,liveRedactions:!0,pixelSource:qu})}),l?.kind==="inspect"&&(0,B.jsx)(s1,{host:e,map:d.map,purpose:l.purpose,selection:f,onPick:(g,S)=>{X1(g,S)},onCommit:g=>{let S=f.length?f:g?[g]:[];S.length&&Gl(S),x([])},onExit:()=>{i(null),x([])},actionOf:g=>$f(d.map,["inspect"],xa(g))?.id}),l?.kind==="inspect"&&f.length>0&&(0,B.jsx)(Xy,{className:"toolbar-selection-bar",count:f.length,map:d.map,canSend:ot,onAction:g=>{j1(g)}}),l?.kind==="region"&&(0,B.jsx)(L2,{onCancel:()=>i(null),onDone:g=>{i(null),uc({...g,x:g.x+scrollX,y:g.y+scrollY},Qo).then(({dataUrl:S})=>cn(S,"Region screenshot")).catch(S=>re(`Screenshot failed: ${String(S)}`))}}),z&&(0,B.jsx)(N1,{top:O,device:z,onDevice:j,zoom:W,onZoom:Se,src:jo,frameRef:sc,emulationActive:c==="emulation",onEmulation:()=>r(g=>g==="emulation"?null:"emulation"),onClose:mc}),(0,B.jsxs)("div",{className:"bar",ref:ne,role:"toolbar","aria-label":"Inkspect",children:[(0,B.jsxs)("div",{className:"bar-row",children:[(0,B.jsxs)("span",{className:"bar-brand",children:[(0,B.jsx)("img",{src:chrome.runtime.getURL("icons/32.png"),alt:""}),"Inkspect"]}),(0,B.jsx)("span",{className:"separator"}),(0,B.jsx)(Ne,{icon:"inspect",label:`${Go("Select an element to copy its details for AI","mode.inspect")}${Me?Ru:""}`,disabled:Me,active:l?.kind==="inspect",onClick:()=>hc({kind:"inspect",purpose:"copy"})}),(0,B.jsx)(Ne,{icon:"edit",label:`${Go("Draw on the page","mode.draw")}${Me?Ru:""}`,disabled:Me,active:l?.kind==="draw",onClick:()=>hc({kind:"draw"})}),(0,B.jsx)(Ne,{icon:"device-camera",label:Go("Screenshot","mode.screenshot"),className:"shot-button",onClick:g=>K1(g,Me?[{label:"Device screen",icon:"device-mobile",onSelect:()=>{let S=sc.current?.parentElement;S&&c1(S).then(N=>cn(N,"Device screenshot")).catch(N=>re(`Screenshot failed: ${String(N)}`))}}]:Xp(),Me?void 0:"screenshot")}),(0,B.jsx)(Ne,{icon:"device-mobile",label:Go("Responsive view","mode.device"),active:Me,onClick:()=>Me?mc():void _p()}),(0,B.jsx)(Ne,{icon:"debug-console",label:`${Go("Console and network (copy errors for AI)","mode.devtools")}${Me?Ru:""}`,disabled:Me,active:c==="console",onClick:()=>r(g=>g==="console"?null:"console")}),(0,B.jsx)(Ne,{icon:"copy",label:`Copy page context for AI${Me?Ru:""}`,disabled:Me,onClick:()=>{Bp().then(g=>Up(g,"Page context","page"))}}),(0,B.jsx)(Ne,{icon:w?"star-full":"star-empty",label:Go(w?"Remove bookmark":"Bookmark this page","page.bookmark"),className:w?"bookmarked":void 0,onClick:jp}),(0,B.jsx)("span",{className:"bar-spacer"}),(0,B.jsx)(Ne,{icon:"keyboard",label:Go("Keyboard shortcuts (shared with VS Code)","open.shortcuts"),active:c==="shortcuts",onClick:()=>r(g=>g==="shortcuts"?null:"shortcuts")}),(0,B.jsx)(Ne,{icon:ot?"plug":"debug-disconnect",label:ot?`Linked with ${k.peer??"VS Code"}`:"Link with VS Code",active:c==="link",className:`link-${k.state}`,onClick:()=>r(g=>g==="link"?null:"link")}),(0,B.jsx)(Ne,{icon:"close",label:"Close toolbar",onClick:()=>{mc(),i(null),r(null),a(!1)}})]}),l?.kind==="draw"&&(0,B.jsx)(qy,{tool:In,style:Qp,recentColors:U1,canUndo:dc.length>0,canRedo:D1.length>0,hasShapes:$t.length>0,visible:Mp,onTool:Np,onStyle:Ql,keyOf:Ko,onUndo:Lp,onRedo:qp,onClear:()=>Lu([],!0),onToggleVisible:()=>zp(g=>!g),onCapture:(g,S)=>{h({x:g,y:S,items:Kp()}),T("draw")},onClose:()=>i(null)})]}),c&&(0,B.jsxs)("div",{className:"panel-dock",ref:ce,style:{top:O+8},children:[c==="emulation"&&(0,B.jsx)(x1,{onClose:()=>r(null),value:Ge,onChange:Du}),c==="console"&&(0,B.jsx)(S1,{onClose:()=>r(null),toast:re,copy:(g,S,N)=>{Up(g,S,N)},send:(g,S,N)=>{Wn(g,S,N)},linked:ot,windows:Bu,pageContext:Bp}),c==="shortcuts"&&(0,B.jsx)(E1,{onClose:()=>r(null),map:d.map,overrides:d.overrides,linked:ot}),c==="link"&&(0,B.jsx)(k1,{onClose:()=>r(null),toast:re,status:k})]}),u&&(0,B.jsx)(Vy,{menu:u,onClose:Yu}),m&&(0,B.jsxs)("div",{className:`toast tone-${m.tone??"info"}`,role:m.tone==="error"?"alert":"status",onPointerEnter:()=>p(g=>g?.id===m.id?{...g,held:!0}:g),onPointerLeave:()=>p(g=>g?.id===m.id?{...g,held:!1}:g),onFocus:()=>p(g=>g?.id===m.id?{...g,held:!0}:g),onBlur:g=>{g.currentTarget.contains(g.relatedTarget)||p(S=>S?.id===m.id?{...S,held:!1}:S)},children:[(0,B.jsxs)("div",{className:"toast-top",children:[m.images?.length===1?(0,B.jsx)("div",{className:"toast-thumbs","aria-hidden":"true",children:(0,B.jsx)("img",{className:"toast-thumb",src:m.images[0],alt:""})}):m.images?.length?(0,B.jsx)("span",{className:"toast-icon toast-count-icon","aria-hidden":"true",children:m.images.length}):m.tone!=="info"&&(0,B.jsx)("span",{className:`toast-icon codicon codicon-${m.tone==="error"?"error":"pass-filled"}`,"aria-hidden":"true"}),(0,B.jsxs)("div",{className:"toast-body",children:[(0,B.jsxs)("div",{className:"toast-title",children:[m.images?.length===1&&(0,B.jsx)("span",{className:"toast-check codicon codicon-pass-filled","aria-hidden":"true"}),m.message]}),m.detail&&(0,B.jsx)("div",{className:"toast-detail",children:m.detail})]}),(0,B.jsx)(Ne,{icon:"close",label:"Dismiss",className:"toast-close",onClick:()=>p(null)})]}),m.images&&m.images.length>1&&(0,B.jsx)(Gy,{className:"toast-picker",items:m.images.map((g,S)=>({id:String(S),src:g,label:`Screenshot ${S+1} of ${m.images.length}`})),checked:new Set([...Uu].map(String)),onToggle:g=>{let S=new Set(Uu),N=Number(g);S.has(N)?S.delete(N):S.add(N),V1(S),p(U=>U?.id===m.id?{...U,held:!0}:U)}}),m.actions&&(0,B.jsxs)("div",{className:"toast-bottom",children:[Bu.length>1&&m.actions.some(g=>g.toVsCode)&&(0,B.jsxs)("div",{className:"toast-target",children:[(0,B.jsx)("span",{className:"toast-target-label",children:"Send to"}),(0,B.jsx)(Au,{windows:Bu,className:"toast-window",value:H,onChange:g=>{R(g),K.current=g,p(S=>S?.id===m.id?{...S,held:!0}:S)}})]}),(0,B.jsxs)("div",{className:"toast-actions",children:[Ra.prefix.length>0&&(0,B.jsxs)("span",{className:"toast-keys",title:"Hold these, then press a button's key",children:[(0,B.jsx)("span",{className:"keycaps size-sm",children:Ra.prefix.map(g=>(0,B.jsx)("kbd",{className:"keycap",children:g},g))}),"+"]}),m.actions.map((g,S)=>(0,B.jsxs)(kt,{size:"sm",variant:g.toVsCode?S===0&&m.actions.length>1?"primary":"secondary":"ghost",className:g.toVsCode?void 0:"toast-local",icon:g.icon,title:Ra.titles[S],"aria-keyshortcuts":Ra.aria[S],disabled:!!g.partial&&Vu>0&&ju===0,onClick:()=>{g.run(),p(null)},children:[g.partial&&ju<Vu?g.partial(ju):g.label,Ra.caps[S].length>0&&(0,B.jsx)("span",{className:"keycaps size-sm",children:Ra.caps[S].map(N=>(0,B.jsx)("kbd",{className:"keycap",children:N},N))})]},g.label))]})]})]},m.id)]})}function B2(e,t){let n=e.map(r=>r.shortcut?t[r.shortcut]?.[0]:void 0),o=n.map(r=>r?_o(r,Ca):[]),a=o.filter(r=>r.length>0),l=a[0],i=l&&l.length>1&&a.length>1?l.slice(0,-1):[],c=a.every(r=>r.length===i.length+1&&r.slice(0,-1).join()===i.join())?i:[];return{prefix:c,caps:o.map(r=>r.slice(c.length)),titles:n.map((r,u)=>r?`${e[u].label} (${St(r,Ca)})`:void 0),aria:n.map(r=>r?.split("+").map(u=>u.charAt(0).toUpperCase()+u.slice(1)).join("+"))}}function L2({onDone:e,onCancel:t}){let[n,o]=(0,A.useState)(null),a=(0,A.useRef)(null);return(0,A.useEffect)(()=>{let l=i=>{i.key==="Escape"&&t()};return window.addEventListener("keydown",l,!0),()=>window.removeEventListener("keydown",l,!0)},[t]),(0,B.jsxs)("div",{className:"region",onPointerDown:l=>{l.currentTarget.setPointerCapture(l.pointerId),a.current={x:l.clientX,y:l.clientY},o({x:l.clientX,y:l.clientY,width:0,height:0})},onPointerMove:l=>{let i=a.current;i&&o({x:Math.min(i.x,l.clientX),y:Math.min(i.y,l.clientY),width:Math.abs(l.clientX-i.x),height:Math.abs(l.clientY-i.y)})},onPointerUp:()=>{a.current=null,n&&n.width>4&&n.height>4&&e(n)},children:[(0,B.jsx)("div",{className:"inspect-hint",children:"Drag to select a region \xB7 Esc to cancel"}),n&&(0,B.jsx)("div",{className:"region-box",style:{left:n.x,top:n.y,width:n.width,height:n.height},children:(0,B.jsxs)("span",{className:"region-size",children:[Math.round(n.width)," \xD7 ",Math.round(n.height)]})})]})}var z1=`/* The Inkspect toolbar. The shared components use VS Code theme variables, defined here in a
   dark and a light variant that follow the system theme. */

:host,
.inkspect {
  --vscode-font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  --vscode-font-size: 13px;
  --vscode-editor-font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
  --vscode-foreground: #cccccc;
  --vscode-descriptionForeground: #9d9d9d;
  --vscode-editor-background: #1f1f1f;
  --vscode-editorWidget-background: #202020;
  --vscode-widget-border: #3c3c3c;
  --vscode-widget-shadow: rgba(0, 0, 0, 0.45);
  --vscode-focusBorder: #0078d4;
  --vscode-button-background: #0078d4;
  --vscode-button-foreground: #ffffff;
  --vscode-button-hoverBackground: #026ec1;
  --vscode-button-secondaryBackground: #313131;
  --vscode-button-secondaryForeground: #cccccc;
  --vscode-button-secondaryHoverBackground: #3c3c3c;
  --vscode-toolbar-hoverBackground: rgba(90, 93, 94, 0.31);
  --vscode-toolbar-activeBackground: rgba(99, 102, 103, 0.31);
  --vscode-inputOption-activeBackground: rgba(36, 137, 219, 0.51);
  --vscode-inputOption-activeBorder: #2488db;
  --vscode-input-background: #313131;
  --vscode-input-foreground: #cccccc;
  --vscode-input-border: #3c3c3c;
  --vscode-menu-background: #1f1f1f;
  --vscode-menu-foreground: #cccccc;
  --vscode-menu-selectionBackground: #0078d4;
  --vscode-menu-selectionForeground: #ffffff;
  --vscode-menu-separatorBackground: #454545;
  --vscode-menu-border: #454545;
  --vscode-notifications-background: #1f1f1f;
  --vscode-notifications-foreground: #cccccc;
  --vscode-errorForeground: #f85149;
  --vscode-testing-iconPassed: #73c991;
  --vscode-badge-background: #616161;
  --vscode-badge-foreground: #f8f8f8;
  color-scheme: dark;
}

@media (prefers-color-scheme: light) {
  :host,
  .inkspect {
    --vscode-foreground: #3b3b3b;
    --vscode-descriptionForeground: #6f6f6f;
    --vscode-editor-background: #ffffff;
    --vscode-editorWidget-background: #f8f8f8;
    --vscode-widget-border: #d4d4d4;
    --vscode-widget-shadow: rgba(0, 0, 0, 0.16);
    --vscode-focusBorder: #005fb8;
    --vscode-button-background: #005fb8;
    --vscode-button-hoverBackground: #0258a8;
    --vscode-button-secondaryBackground: #e5e5e5;
    --vscode-button-secondaryForeground: #3b3b3b;
    --vscode-button-secondaryHoverBackground: #cccccc;
    --vscode-toolbar-hoverBackground: rgba(184, 184, 184, 0.31);
    --vscode-toolbar-activeBackground: rgba(166, 166, 166, 0.31);
    --vscode-inputOption-activeBackground: rgba(190, 195, 201, 0.51);
    --vscode-input-background: #ffffff;
    --vscode-input-foreground: #3b3b3b;
    --vscode-input-border: #cecece;
    --vscode-menu-background: #ffffff;
    --vscode-menu-foreground: #3b3b3b;
    --vscode-menu-selectionBackground: #005fb8;
    --vscode-menu-separatorBackground: #d4d4d4;
    --vscode-menu-border: #cecece;
    --vscode-notifications-background: #ffffff;
    --vscode-notifications-foreground: #3b3b3b;
    --vscode-errorForeground: #b3261e;
    --vscode-testing-iconPassed: #2e7d32;
    color-scheme: light;
  }
}

.inkspect {
  position: fixed;
  inset: 0;
  font-family: var(--vscode-font-family);
  font-size: var(--vscode-font-size);
  color: var(--vscode-foreground);
  pointer-events: none;
}

.inkspect *,
.inkspect *::before,
.inkspect *::after {
  box-sizing: border-box;
}

/* Everything interactive takes the pointer; the rest of the layer lets the page through. */
.bar,
.rv,
.panel-dock,
.toast,
.menu,
/* Popups (select lists, color pickers) are portaled to the shadow root, outside .inkspect. */
[data-ink-popup],
.select-list,
.region,
.draw-host .drawing-layer {
  pointer-events: auto;
}

.inkspect.capturing * {
  visibility: hidden !important;
}

/* Capturing the page for redactions to pixelate: everything over the page steps aside for a
   moment, except the bar (there is only more of the bar under it). Transparent rather than
   hidden, so a drag that starts meanwhile still reaches the drawing layer. */
.inkspect.sampling .draw-host,
.inkspect.sampling .panel-dock,
.inkspect.sampling .toast,
.inkspect.sampling .menu {
  opacity: 0 !important;
}

/* The toolbar: a full-width bar that slides down from the top; the page moves down to make room
   (see pagePush.ts). While drawing, the drawing tools add a second row. */
.bar {
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  border-bottom: 1px solid var(--ink-border-strong);
  background: var(--vscode-editorWidget-background);
  box-shadow: var(--ink-shadow-sm);
  user-select: none;
  animation: bar-in var(--ink-normal) var(--ink-ease);
}

.bar-row {
  display: flex;
  align-items: center;
  gap: 2px;
  height: 40px;
  padding: 0 8px;
}

.bar-brand {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 8px;
  padding: 0 4px;
  font-weight: 600;
}

.bar-brand img {
  width: 18px;
  height: 18px;
  border-radius: 4px;
}

.bar-spacer {
  flex: 1;
}

/* The drawing tools span the bar's width as its second row. */
.bar .draw-toolbar {
  justify-content: center;
  border-bottom: none;
  background: transparent;
}

@keyframes bar-in {
  from {
    transform: translateY(-100%);
  }
}

.separator {
  width: 1px;
  height: 18px;
  margin: 0 4px;
  background: var(--vscode-widget-border);
}

.bookmarked .codicon {
  color: var(--ink-blue);
}

.link-connected .codicon {
  color: var(--vscode-testing-iconPassed);
}

.link-offline .codicon,
.link-unpaired .codicon {
  color: var(--vscode-descriptionForeground);
}

.draw-host {
  position: fixed;
  inset: 0;
}

.menu {
  position: fixed;
}

/* Toast ------------------------------------------------------------------------------------ */

.inkspect .toast {
  position: fixed;
  top: auto;
  right: 16px;
  bottom: 16px;
  left: auto;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 0;
  width: min(460px, calc(100vw - 32px));
  max-width: none;
  padding: 0;
  overflow: hidden;
  transform: none;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-lg);
  background: var(--vscode-editorWidget-background);
  color: var(--vscode-foreground);
  box-shadow: var(--ink-shadow-lg);
  animation: toast-in var(--ink-normal) var(--ink-ease);
}

.inkspect .toast.tone-error {
  border-color: color-mix(in srgb, var(--ink-danger) 45%, var(--ink-border-strong));
}

.toast-top {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  padding: 14px 10px 14px 14px;
}

/* The captured image, cropped to its top: what was captured, at a glance. */
.toast-thumb {
  flex-shrink: 0;
  width: 104px;
  height: 68px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  object-fit: cover;
  object-position: top center;
}

/* Several images: stacked like cards, with their number. */
.toast-thumbs {
  position: relative;
  flex-shrink: 0;
}

.toast-thumbs.many {
  width: 118px;
  height: 80px;
}

.toast-thumbs.many .toast-thumb {
  position: absolute;
  top: 0;
  left: 0;
  box-shadow: var(--ink-shadow-sm);
}

.toast-thumbs.many .toast-thumb:nth-child(2) {
  top: 6px;
  left: 7px;
}

.toast-thumbs.many .toast-thumb:nth-child(3) {
  top: 12px;
  left: 14px;
}

.toast-count {
  position: absolute;
  right: -2px;
  bottom: -2px;
  min-width: 22px;
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 700;
  line-height: 20px;
  text-align: center;
}

.toast-icon {
  flex-shrink: 0;
  margin-top: 1px;
  font-size: 18px !important;
}

.tone-success .toast-icon,
.toast-check {
  color: var(--vscode-testing-iconPassed);
}

.tone-error .toast-icon {
  color: var(--ink-danger);
}

.toast-body {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  padding-top: 2px;
}

.toast-title {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: var(--ink-font-lg);
  font-weight: 600;
  line-height: 1.3;
  overflow-wrap: anywhere;
}

.toast-check {
  font-size: 16px !important;
}

.toast-detail {
  color: var(--ink-muted);
  overflow-wrap: anywhere;
}

.toast-close {
  flex-shrink: 0;
  margin-top: -2px;
}

/* Where it goes: the window, then the actions. */
.toast-bottom {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 12px 14px 14px;
  border-top: 1px solid var(--ink-border-subtle);
  background: color-mix(
    in srgb,
    var(--vscode-foreground) 3%,
    var(--vscode-editorWidget-background)
  );
}

.toast-target {
  display: flex;
  align-items: center;
  gap: 10px;
}

.toast-target-label {
  flex-shrink: 0;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.toast-window {
  flex: 1;
  min-width: 0;
}

.toast-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
}

/* The buttons' shared modifiers ("Alt Shift +"), then each button's own key after its label. */
.toast-keys {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

.toast-actions .button-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.toast-actions .button.primary .keycap {
  border-color: color-mix(in srgb, var(--vscode-button-foreground) 35%, transparent);
  background: color-mix(in srgb, var(--vscode-button-foreground) 16%, transparent);
  color: var(--vscode-button-foreground);
}

/* Download (stays in the browser): set apart at the end. */
.toast-actions .toast-local {
  margin-left: auto;
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
}

/* Panels ------------------------------------------------------------------------------------ */

.panel-dock {
  position: fixed;
  right: 12px;
  width: 370px;
  max-width: calc(100vw - 24px);
}

.panel {
  border: 1px solid var(--vscode-widget-border);
  border-radius: 8px;
  background: var(--vscode-editorWidget-background);
  box-shadow: 0 8px 24px var(--vscode-widget-shadow);
}

.panel-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 6px 6px 12px;
  border-bottom: 1px solid var(--vscode-widget-border);
  font-weight: 600;
}

.panel-body {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: min(70vh, 560px);
  padding: 12px;
  overflow: auto;
}

.row {
  display: flex;
  align-items: flex-end;
  gap: 8px;
}

.field {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 4px;
  color: var(--vscode-descriptionForeground);
  font-size: 12px;
}

.field select,
.field input,
.code-input {
  height: 26px;
  padding: 0 6px;
  border: 1px solid var(--vscode-input-border);
  border-radius: 4px;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font: inherit;
  font-size: 13px;
}

.code-input {
  flex: 1;
  font-family: var(--vscode-editor-font-family);
  font-size: 16px;
  letter-spacing: 4px;
}

.check {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
}

.note {
  margin: 0;
  color: var(--vscode-descriptionForeground);
  font-size: 12px;
}

.note.error,
.status-offline {
  color: var(--vscode-errorForeground);
}

.status {
  margin: 0;
}

.status-connected {
  color: var(--vscode-testing-iconPassed);
}

.button-row.wrap {
  flex-wrap: wrap;
}

/* A labelled group of actions in a panel ("Copy for AI", "Send ... to VS Code"). */
.panel-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding-top: 12px;
  border-top: 1px solid var(--ink-border-subtle);
}

.panel-group-title {
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
  font-weight: 600;
}

/* Console and network. */
.console-tabs {
  display: flex;
  align-items: center;
  gap: 6px;
}

.console-view {
  flex: 1;
}

.console-view .segment {
  flex: 1;
}

.log {
  min-height: 120px;
  max-height: 280px;
  overflow: auto;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  font-family: var(--vscode-editor-font-family);
  font-size: var(--ink-font-sm);
}

.log-row {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 5px 8px;
  border-bottom: 1px solid var(--ink-border-subtle);
}

.log-row:last-child {
  border-bottom: none;
}

.log-icon {
  flex-shrink: 0;
  margin-top: 2px;
  color: var(--ink-muted);
  font-size: 12px !important;
}

.log-row.level-error {
  background: color-mix(in srgb, var(--ink-danger) 8%, transparent);
  color: var(--ink-danger);
}

.log-row.level-error .log-icon {
  color: var(--ink-danger);
}

.log-row.level-warning {
  background: color-mix(in srgb, var(--ink-yellow) 8%, transparent);
  color: var(--ink-yellow);
}

.log-row.level-warning .log-icon {
  color: var(--ink-yellow);
}

.log-text {
  flex: 1;
  min-width: 0;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.log-source {
  flex-shrink: 0;
  color: var(--ink-muted);
}

.log-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  min-height: 118px;
  padding: 16px;
  color: var(--ink-muted);
  font-family: var(--vscode-font-family);
  text-align: center;
}

.log-empty .codicon {
  margin-bottom: 4px;
  color: var(--ink-green);
  font-size: 20px !important;
}

.log-empty strong {
  color: var(--vscode-foreground);
  font-weight: 600;
}

/* Element inspector (DevTools colors) ------------------------------------------------------- */

/* The picker's hint (PickerHint, styled in @inkspect/shared/ui): centered at the bottom. */
.inspect-hint {
  position: fixed;
  left: 50%;
  bottom: 16px;
  max-width: calc(100vw - 32px);
  transform: translateX(-50%);
}

.hl {
  position: fixed;
  pointer-events: none;
}

/* DevTools' box-model colors, lighter so the element's text stays readable, plus an outline. */
.hl-margin {
  background: rgba(246, 178, 107, 0.4);
}

.hl-border {
  background: rgba(255, 229, 153, 0.5);
}

.hl-padding {
  background: rgba(147, 196, 125, 0.4);
}

.hl-content {
  background: rgba(111, 168, 220, 0.4);
}

.hl-outline {
  box-shadow:
    0 0 0 2px #0a84ff,
    0 0 0 3px rgba(255, 255, 255, 0.85);
}

.selection-box {
  position: fixed;
  border: 2px solid #0078d4;
  pointer-events: none;
}

.selection-badge {
  position: absolute;
  top: -10px;
  left: -10px;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 10px;
  background: #0078d4;
  color: #fff;
  font-size: 12px;
  line-height: 20px;
  text-align: center;
}

/* Chrome's inspect tooltip: always light, like in DevTools. */
.tip {
  position: fixed;
  padding: 8px 10px;
  border-radius: 4px;
  background: #fff;
  color: #303942;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
  font:
    12px system-ui,
    sans-serif;
  pointer-events: none;
}

.tip-head {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 6px;
  font-weight: 600;
}

.tip-tag {
  color: #881280;
}

.tip-id,
.tip-class {
  color: #1a1aa6;
}

.tip-size {
  flex-shrink: 0;
  color: #5f6368;
  font-weight: 400;
}

.tip-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 1px 0;
  color: #5f6368;
}

.tip-row > span:last-child {
  color: #303942;
  text-align: right;
  overflow-wrap: anywhere;
}

.tip-value {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.tip-swatch {
  display: inline-block;
  width: 10px;
  height: 10px;
  border: 1px solid #ccc;
}

.tip-section {
  margin: 6px 0 2px;
  padding-top: 6px;
  border-top: 1px solid #e0e0e0;
  color: #5f6368;
  font-size: 10px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
}

.tip-aa {
  padding: 0 3px;
  border: 1px solid #ccc;
}

.ok {
  color: #188038 !important;
}

.bad {
  color: #d93025 !important;
}

/* Region selection --------------------------------------------------------------------------- */

.region {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.25);
  cursor: crosshair;
}

.region-box {
  position: fixed;
  border: 1px dashed #fff;
  outline: 1px dashed rgba(0, 0, 0, 0.6);
  box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.35);
}

.region-size {
  position: absolute;
  top: -22px;
  left: 0;
  padding: 1px 6px;
  border-radius: 3px;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  font-size: 11px;
}

/* Responsive view --------------------------------------------------------------------------- */

/* Covers the page below the bar; the page shows in a device-sized frame, centered. */
.rv {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  display: flex;
  flex-direction: column;
  background: color-mix(in srgb, var(--vscode-foreground) 6%, var(--vscode-editor-background));
}

.rv-controls {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 6px 12px;
  border-bottom: 1px solid var(--ink-border-subtle);
  background: var(--vscode-editorWidget-background);
}

.rv-device {
  width: 200px;
}

.rv-size {
  width: 64px;
}

.rv-size input {
  text-align: center;
  font-variant-numeric: tabular-nums;
}

.rv-zoom {
  width: 84px;
}

.rv-times {
  color: var(--ink-muted);
}

.rv-divider {
  width: 1px;
  height: 18px;
  margin: 0 4px;
  background: var(--ink-border-subtle);
}

.rv-area {
  flex: 1;
  min-height: 0;
  overflow: auto;
}

/* Centered while it fits; scrolls from its top-left corner when zoomed in beyond the area. */
.rv-stage {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 22px;
  min-width: 100%;
  min-height: 100%;
  width: max-content;
  padding: 24px 32px;
}

.rv-screen {
  position: relative;
  flex-shrink: 0;
  overflow: hidden;
  border-radius: 6px;
  background: #fff;
  box-shadow:
    0 0 0 1px var(--ink-border-strong),
    var(--ink-shadow-lg);
}

.rv-screen iframe {
  display: block;
  border: 0;
  transform-origin: 0 0;
  background: #fff;
}

/* The screen and its resize handles (right edge, bottom edge, corner), like DevTools'. */
.rv-frame {
  position: relative;
  flex-shrink: 0;
}

.rv-handle {
  position: absolute;
  z-index: 1;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--vscode-foreground) 28%, transparent);
  touch-action: none;
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.rv-handle:hover,
.rv.dragging .rv-handle {
  background: var(--ink-blue);
}

.rv-handle-x {
  top: 50%;
  right: -14px;
  width: 6px;
  height: 44px;
  transform: translateY(-50%);
  cursor: ew-resize;
}

.rv-handle-y {
  bottom: -14px;
  left: 50%;
  width: 44px;
  height: 6px;
  transform: translateX(-50%);
  cursor: ns-resize;
}

.rv-handle-xy {
  right: -14px;
  bottom: -14px;
  width: 12px;
  height: 12px;
  border-radius: 3px;
  cursor: nwse-resize;
}

/* The frame would take the pointer from the handle mid-drag. */
.rv.dragging iframe {
  pointer-events: none;
}

.rv.dragging {
  user-select: none;
}

.rv-caption {
  height: 14px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  font-variant-numeric: tabular-nums;
}

@media (prefers-reduced-motion: reduce) {
  .bar,
  .inkspect .toast {
    animation: none;
  }
}

/* The shortcuts panel. */
.shortcuts-bar {
  display: flex;
  align-items: center;
  gap: 6px;
}

.shortcuts-bar .text-field {
  flex: 1;
}

/* Group headers pin to the panel's top edge (sticky stops at the padding otherwise, leaving a
   strip where rows show through). */
.panel-body .shortcut-list {
  --shortcut-sticky-top: -12px;
}

.panel-body .group-header {
  background: var(--vscode-editorWidget-background);
}

.shortcuts-sync {
  display: flex;
  gap: 6px;
}

.shortcuts-sync .codicon {
  flex-shrink: 0;
  margin-top: 1px;
}

/* The bar over a Shift+click selection (SelectionBar), just above the picker's hint. */
.toolbar-selection-bar {
  position: fixed;
  left: 50%;
  bottom: 92px;
  transform: translateX(-50%);
}

/* Several screenshots: their count where a single one shows its thumbnail, and the picker. */
.toast-count-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 22px;
  height: 22px;
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--ink-accent);
  color: var(--vscode-button-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 700;
}

.toast-picker {
  max-height: 188px;
  overflow-y: auto;
  padding: 0 16px 4px;
}
`;var R1=D(q());async function Y2(){try{let e=await(await fetch(chrome.runtime.getURL("codicon.ttf"))).arrayBuffer(),t=new FontFace("codicon",e);await t.load(),document.fonts.add(t)}catch{}}function V2(){let e=document.createElement("inkspect-toolbar");e.style.cssText="all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none; display: block;";let t=e.attachShadow({mode:"closed"});g0(t);let n=document.createElement("style");n.textContent=[Jp.replace(/@font-face\s*{[^}]*}/g,""),$p,z1].join(`
`);let o=document.createElement("div");t.append(n,o),document.documentElement.appendChild(e),Y2();let a=(0,O1.createRoot)(o),l=()=>(e.style.visibility="hidden",()=>{e.style.visibility=""});return i=>{e.isConnected||document.documentElement.appendChild(e),a.render((0,R1.jsx)(M1,{host:e,hideHost:l,toggleSignal:i}))}}var A1=window;if(!A1.__inkspect){A1.__inkspect=!0;let e,t=0;chrome.runtime.onMessage.addListener(n=>{n.type==="toggle"&&(n.key&&_0(n.key)||(e??=V2(),e(++t)))})}})();
