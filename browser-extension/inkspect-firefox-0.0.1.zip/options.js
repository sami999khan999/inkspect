"use strict";(()=>{var Rp=Object.create;var Sd=Object.defineProperty;var Up=Object.getOwnPropertyDescriptor;var Bp=Object.getOwnPropertyNames;var Hp=Object.getPrototypeOf,qp=Object.prototype.hasOwnProperty;var bt=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports}catch(n){throw t=0,n}};var Yp=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of Bp(t))!qp.call(e,a)&&a!==n&&Sd(e,a,{get:()=>t[a],enumerable:!(o=Up(t,a))||o.enumerable});return e};var L=(e,t,n)=>(n=e!=null?Rp(Hp(e)):{},Yp(t||!e||!e.__esModule?Sd(n,"default",{value:e,enumerable:!0}):n,e));var Jd=bt(O=>{"use strict";var mi=Symbol.for("react.transitional.element"),Zp=Symbol.for("react.portal"),Kp=Symbol.for("react.fragment"),Jp=Symbol.for("react.strict_mode"),Fp=Symbol.for("react.profiler"),Wp=Symbol.for("react.consumer"),$p=Symbol.for("react.context"),Ip=Symbol.for("react.forward_ref"),Pp=Symbol.for("react.suspense"),ev=Symbol.for("react.memo"),Ld=Symbol.for("react.lazy"),tv=Symbol.for("react.activity"),nv=Symbol.for("react.view_transition"),Bd=Symbol.iterator;function ov(e){return e===null||typeof e!="object"?null:(e=Bd&&e[Bd]||e["@@iterator"],typeof e=="function"?e:null)}var Vd={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},Gd=Object.assign,jd={};function co(e,t,n){this.props=e,this.context=t,this.refs=jd,this.updater=n||Vd}co.prototype.isReactComponent={};co.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};co.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function Qd(){}Qd.prototype=co.prototype;function gi(e,t,n){this.props=e,this.context=t,this.refs=jd,this.updater=n||Vd}var pi=gi.prototype=new Qd;pi.constructor=gi;Gd(pi,co.prototype);pi.isPureReactComponent=!0;var Hd=Array.isArray;function bi(){}var F={H:null,A:null,T:null,S:null},Xd=Object.prototype.hasOwnProperty;function vi(e,t,n){var o=n.ref;return{$$typeof:mi,type:e,key:t,ref:o!==void 0?o:null,props:n}}function av(e,t){return vi(e.type,t,e.props)}function hi(e){return typeof e=="object"&&e!==null&&e.$$typeof===mi}function cv(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var qd=/\/+/g;function si(e,t){return typeof e=="object"&&e!==null&&e.key!=null?cv(""+e.key):t.toString(36)}function lv(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(bi,bi):(e.status="pending",e.then(function(t){e.status==="pending"&&(e.status="fulfilled",e.value=t)},function(t){e.status==="pending"&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function ao(e,t,n,o,a){var c=typeof e;(c==="undefined"||c==="boolean")&&(e=null);var l=!1;if(e===null)l=!0;else switch(c){case"bigint":case"string":case"number":l=!0;break;case"object":switch(e.$$typeof){case mi:case Zp:l=!0;break;case Ld:return l=e._init,ao(l(e._payload),t,n,o,a)}}if(l)return a=a(e),l=o===""?"."+si(e,0):o,Hd(a)?(n="",l!=null&&(n=l.replace(qd,"$&/")+"/"),ao(a,t,n,"",function(u){return u})):a!=null&&(hi(a)&&(a=av(a,n+(a.key==null||e&&e.key===a.key?"":(""+a.key).replace(qd,"$&/")+"/")+l)),t.push(a)),1;l=0;var i=o===""?".":o+":";if(Hd(e))for(var r=0;r<e.length;r++)o=e[r],c=i+si(o,r),l+=ao(o,t,n,c,a);else if(r=ov(e),typeof r=="function")for(e=r.call(e),r=0;!(o=e.next()).done;)o=o.value,c=i+si(o,r++),l+=ao(o,t,n,c,a);else if(c==="object"){if(typeof e.then=="function")return ao(lv(e),t,n,o,a);throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return l}function hc(e,t,n){if(e==null)return e;var o=[],a=0;return ao(e,o,"","",function(c){return t.call(n,c,a++)}),o}function iv(e){if(e._status===-1){var t=e._result,n=t();n.then(function(o){(e._status===0||e._status===-1)&&(e._status=1,e._result=o,n.status===void 0&&(n.status="fulfilled",n.value=o))},function(o){(e._status===0||e._status===-1)&&(e._status=2,e._result=o,n.status===void 0&&(n.status="rejected",n.reason=o))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var Yd=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)};function Zd(e){var t=F.T,n={};n.types=t!==null?t.types:null,F.T=n;try{var o=e(),a=F.S;a!==null&&a(n,o),typeof o=="object"&&o!==null&&typeof o.then=="function"&&o.then(bi,Yd)}catch(c){Yd(c)}finally{t!==null&&n.types!==null&&(t.types=n.types),F.T=t}}function Kd(e){var t=F.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else Zd(Kd.bind(null,e))}var rv={map:hc,forEach:function(e,t,n){hc(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return hc(e,function(){t++}),t},toArray:function(e){return hc(e,function(t){return t})||[]},only:function(e){if(!hi(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};O.Activity=tv;O.Children=rv;O.Component=co;O.Fragment=Kp;O.Profiler=Fp;O.PureComponent=gi;O.StrictMode=Jp;O.Suspense=Pp;O.ViewTransition=nv;O.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=F;O.__COMPILER_RUNTIME={__proto__:null,c:function(e){return F.H.useMemoCache(e)}};O.addTransitionType=Kd;O.cache=function(e){return function(){return e.apply(null,arguments)}};O.cacheSignal=function(){return null};O.cloneElement=function(e,t,n){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var o=Gd({},e.props),a=e.key;if(t!=null)for(c in t.key!==void 0&&(a=""+t.key),t)!Xd.call(t,c)||c==="key"||c==="__self"||c==="__source"||c==="ref"&&t.ref===void 0||(o[c]=t[c]);var c=arguments.length-2;if(c===1)o.children=n;else if(1<c){for(var l=Array(c),i=0;i<c;i++)l[i]=arguments[i+2];o.children=l}return vi(e.type,a,o)};O.createContext=function(e){return e={$$typeof:$p,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:Wp,_context:e},e};O.createElement=function(e,t,n){var o,a={},c=null;if(t!=null)for(o in t.key!==void 0&&(c=""+t.key),t)Xd.call(t,o)&&o!=="key"&&o!=="__self"&&o!=="__source"&&(a[o]=t[o]);var l=arguments.length-2;if(l===1)a.children=n;else if(1<l){for(var i=Array(l),r=0;r<l;r++)i[r]=arguments[r+2];a.children=i}if(e&&e.defaultProps)for(o in l=e.defaultProps,l)a[o]===void 0&&(a[o]=l[o]);return vi(e,c,a)};O.createRef=function(){return{current:null}};O.forwardRef=function(e){return{$$typeof:Ip,render:e}};O.isValidElement=hi;O.lazy=function(e){return{$$typeof:Ld,_payload:{_status:-1,_result:e},_init:iv}};O.memo=function(e,t){return{$$typeof:ev,type:e,compare:t===void 0?null:t}};O.startTransition=Zd;O.unstable_useCacheRefresh=function(){return F.H.useCacheRefresh()};O.use=function(e){return F.H.use(e)};O.useActionState=function(e,t,n){return F.H.useActionState(e,t,n)};O.useCallback=function(e,t){return F.H.useCallback(e,t)};O.useContext=function(e){return F.H.useContext(e)};O.useDebugValue=function(){};O.useDeferredValue=function(e,t){return F.H.useDeferredValue(e,t)};O.useEffect=function(e,t){return F.H.useEffect(e,t)};O.useEffectEvent=function(e){return F.H.useEffectEvent(e)};O.useId=function(){return F.H.useId()};O.useImperativeHandle=function(e,t,n){return F.H.useImperativeHandle(e,t,n)};O.useInsertionEffect=function(e,t){return F.H.useInsertionEffect(e,t)};O.useLayoutEffect=function(e,t){return F.H.useLayoutEffect(e,t)};O.useMemo=function(e,t){return F.H.useMemo(e,t)};O.useOptimistic=function(e,t){return F.H.useOptimistic(e,t)};O.useReducer=function(e,t,n){return F.H.useReducer(e,t,n)};O.useRef=function(e){return F.H.useRef(e)};O.useState=function(e){return F.H.useState(e)};O.useSyncExternalStore=function(e,t,n){return F.H.useSyncExternalStore(e,t,n)};O.useTransition=function(){return F.H.useTransition()};O.version="19.3.0"});var mt=bt((Hy,Fd)=>{"use strict";Fd.exports=Jd()});var Pd=bt(yc=>{"use strict";var dv=Symbol.for("react.transitional.element"),fv=Symbol.for("react.fragment");function Id(e,t,n){var o=null;if(n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),"key"in t){n={};for(var a in t)a!=="key"&&(n[a]=t[a])}else n=t;return t=n.ref,{$$typeof:dv,type:e,key:o,ref:t!==void 0?t:null,props:n}}yc.Fragment=fv;yc.jsx=Id;yc.jsxs=Id});var te=bt((Ly,ef)=>{"use strict";ef.exports=Pd()});var Sf=bt(P=>{"use strict";function zi(e,t){var n=e.length;e.push(t);e:for(;0<n;){var o=n-1>>>1,a=e[o];if(0<xc(a,t))e[o]=t,e[n]=a,n=o;else break e}}function gt(e){return e.length===0?null:e[0]}function wc(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;e:for(var o=0,a=e.length,c=a>>>1;o<c;){var l=2*(o+1)-1,i=e[l],r=l+1,u=e[r];if(0>xc(i,n))r<a&&0>xc(u,i)?(e[o]=u,e[r]=n,o=r):(e[o]=i,e[l]=n,o=l);else if(r<a&&0>xc(u,n))e[o]=u,e[r]=n,o=r;else break e}}return t}function xc(e,t){var n=e.sortIndex-t.sortIndex;return n!==0?n:e.id-t.id}P.unstable_now=void 0;typeof performance=="object"&&typeof performance.now=="function"?(ff=performance,P.unstable_now=function(){return ff.now()}):(wi=Date,sf=wi.now(),P.unstable_now=function(){return wi.now()-sf});var ff,wi,sf,Dt=[],It=[],gv=1,We=null,Te=3,Ni=!1,fa=!1,sa=!1,Oi=!1,gf=typeof setTimeout=="function"?setTimeout:null,pf=typeof clearTimeout=="function"?clearTimeout:null,bf=typeof setImmediate<"u"?setImmediate:null;function kc(e){for(var t=gt(It);t!==null;){if(t.callback===null)wc(It);else if(t.startTime<=e)wc(It),t.sortIndex=t.expirationTime,zi(Dt,t);else break;t=gt(It)}}function Ci(e){if(sa=!1,kc(e),!fa)if(gt(Dt)!==null)fa=!0,uo||(uo=!0,ro());else{var t=gt(It);t!==null&&Ai(Ci,t.startTime-e)}}var uo=!1,ba=-1,vf=5,hf=-1;function yf(){return Oi?!0:!(P.unstable_now()-hf<vf)}function Ti(){if(Oi=!1,uo){var e=P.unstable_now();hf=e;var t=!0;try{e:{fa=!1,sa&&(sa=!1,pf(ba),ba=-1),Ni=!0;var n=Te;try{t:{for(kc(e),We=gt(Dt);We!==null&&!(We.expirationTime>e&&yf());){var o=We.callback;if(typeof o=="function"){We.callback=null,Te=We.priorityLevel;var a=o(We.expirationTime<=e);if(e=P.unstable_now(),typeof a=="function"){We.callback=a,kc(e),t=!0;break t}We===gt(Dt)&&wc(Dt),kc(e)}else wc(Dt);We=gt(Dt)}if(We!==null)t=!0;else{var c=gt(It);c!==null&&Ai(Ci,c.startTime-e),t=!1}}break e}finally{We=null,Te=n,Ni=!1}t=void 0}}finally{t?ro():uo=!1}}}var ro;typeof bf=="function"?ro=function(){bf(Ti)}:typeof MessageChannel<"u"?(Ei=new MessageChannel,mf=Ei.port2,Ei.port1.onmessage=Ti,ro=function(){mf.postMessage(null)}):ro=function(){gf(Ti,0)};var Ei,mf;function Ai(e,t){ba=gf(function(){e(P.unstable_now())},t)}P.unstable_IdlePriority=5;P.unstable_ImmediatePriority=1;P.unstable_LowPriority=4;P.unstable_NormalPriority=3;P.unstable_Profiling=null;P.unstable_UserBlockingPriority=2;P.unstable_cancelCallback=function(e){e.callback=null};P.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):vf=0<e?Math.floor(1e3/e):5};P.unstable_getCurrentPriorityLevel=function(){return Te};P.unstable_next=function(e){switch(Te){case 1:case 2:case 3:var t=3;break;default:t=Te}var n=Te;Te=t;try{return e()}finally{Te=n}};P.unstable_requestPaint=function(){Oi=!0};P.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=Te;Te=e;try{return t()}finally{Te=n}};P.unstable_scheduleCallback=function(e,t,n){var o=P.unstable_now();switch(typeof n=="object"&&n!==null?(n=n.delay,n=typeof n=="number"&&0<n?o+n:o):n=o,e){case 1:var a=-1;break;case 2:a=250;break;case 5:a=1073741823;break;case 4:a=1e4;break;default:a=5e3}return a=n+a,e={id:gv++,callback:t,priorityLevel:e,startTime:n,expirationTime:a,sortIndex:-1},n>o?(e.sortIndex=n,zi(It,e),gt(Dt)===null&&e===gt(It)&&(sa?(pf(ba),ba=-1):sa=!0,Ai(Ci,n-o))):(e.sortIndex=a,zi(Dt,e),fa||Ni||(fa=!0,uo||(uo=!0,ro()))),e};P.unstable_shouldYield=yf;P.unstable_wrapCallback=function(e){var t=Te;return function(){var n=Te;Te=t;try{return e.apply(this,arguments)}finally{Te=n}}}});var kf=bt((l1,xf)=>{"use strict";xf.exports=Sf()});var Ef=bt(Ee=>{"use strict";var pv=mt();function Tf(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function Pt(){}var Ne={d:{f:Pt,r:function(){throw Error(Tf(522))},D:Pt,C:Pt,L:Pt,m:Pt,X:Pt,S:Pt,M:Pt},p:0,findDOMNode:null},vv=Symbol.for("react.portal"),hv=Symbol.for("react.recoverable"),wf=Symbol.for("react.optimistic_key");function yv(e,t,n){var o=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:vv,key:o==null?null:o===wf?wf:""+o,children:e,containerInfo:t,implementation:n}}var ma=pv.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function Tc(e,t){if(e==="font")return"";if(typeof t=="string")return t==="use-credentials"?t:""}Ee.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=Ne;Ee.browser=function(e){return{$$typeof:hv,_reason:e}};Ee.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(Tf(299));return yv(e,t,null,n)};Ee.flushSync=function(e){var t=ma.T,n=Ne.p;try{if(ma.T=null,Ne.p=2,e)return e()}finally{ma.T=t,Ne.p=n,Ne.d.f()}};Ee.preconnect=function(e,t){typeof e=="string"&&(t?(t=t.crossOrigin,t=typeof t=="string"?t==="use-credentials"?t:"":void 0):t=null,Ne.d.C(e,t))};Ee.prefetchDNS=function(e){typeof e=="string"&&Ne.d.D(e)};Ee.preinit=function(e,t){if(typeof e=="string"&&t&&typeof t.as=="string"){var n=t.as,o=Tc(n,t.crossOrigin),a=typeof t.integrity=="string"?t.integrity:void 0,c=typeof t.fetchPriority=="string"?t.fetchPriority:void 0;n==="style"?Ne.d.S(e,typeof t.precedence=="string"?t.precedence:void 0,{crossOrigin:o,integrity:a,fetchPriority:c}):n==="script"&&Ne.d.X(e,{crossOrigin:o,integrity:a,fetchPriority:c,nonce:typeof t.nonce=="string"?t.nonce:void 0})}};Ee.preinitModule=function(e,t){if(typeof e=="string")if(typeof t=="object"&&t!==null){if(t.as==null||t.as==="script"){var n=Tc(t.as,t.crossOrigin);Ne.d.M(e,{crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}}else t==null&&Ne.d.M(e)};Ee.preload=function(e,t){if(typeof e=="string"&&typeof t=="object"&&t!==null&&typeof t.as=="string"){var n=t.as,o=Tc(n,t.crossOrigin);Ne.d.L(e,n,{crossOrigin:o,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,type:typeof t.type=="string"?t.type:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy=="string"?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet=="string"?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes=="string"?t.imageSizes:void 0,media:typeof t.media=="string"?t.media:void 0})}};Ee.preloadModule=function(e,t){if(typeof e=="string")if(t){var n=Tc(t.as,t.crossOrigin);Ne.d.m(e,{as:typeof t.as=="string"&&t.as!=="script"?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}else Ne.d.m(e)};Ee.requestFormReset=function(e){Ne.d.r(e)};Ee.unstable_batchedUpdates=function(e,t){return e(t)};Ee.useFormState=function(e,t,n){return ma.H.useFormState(e,t,n)};Ee.useFormStatus=function(){return ma.H.useHostTransitionStatus()};Ee.version="19.3.0"});var Of=bt((r1,Nf)=>{"use strict";function zf(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(zf)}catch(e){console.error(e)}}zf(),Nf.exports=Ef()});var mp=bt(ci=>{"use strict";var se=kf(),bb=mt(),Sv=Of();function h(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function mb(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function tc(e){for(var t=e,n=t;n&&!n.alternate;)t=n,(t.flags&4098)!==0&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function gb(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function pb(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Cf(e){if(tc(e)!==e)throw Error(h(188))}function xv(e){var t=e.alternate;if(!t){if(t=tc(e),t===null)throw Error(h(188));return t!==e?null:e}for(var n=e,o=t;;){var a=n.return;if(a===null)break;var c=a.alternate;if(c===null){if(o=a.return,o!==null){n=o;continue}break}if(a.child===c.child){for(c=a.child;c;){if(c===n)return Cf(a),e;if(c===o)return Cf(a),t;c=c.sibling}throw Error(h(188))}if(n.return!==o.return)n=a,o=c;else{for(var l=!1,i=a.child;i;){if(i===n){l=!0,n=a,o=c;break}if(i===o){l=!0,o=a,n=c;break}i=i.sibling}if(!l){for(i=c.child;i;){if(i===n){l=!0,n=c,o=a;break}if(i===o){l=!0,o=c,n=a;break}i=i.sibling}if(!l)throw Error(h(189))}}if(n.alternate!==o)throw Error(h(190))}if(n.tag!==3)throw Error(h(188));return n.stateNode.current===n?e:t}function vb(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=vb(e),t!==null)return t;e=e.sibling}return null}function He(e,t,n,o,a,c){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,o,a,c)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&He(e.child,t,n,o,a,c))return!0;e=e.sibling}return!1}function Pn(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function Af(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),!(e.tag===3||e.tag===5||e.tag===27));)e=e.return;return t}function hb(e){var t=[null,null],n=Pn(e);return n===null||yb(t,e,n.child,{foundSelf:!1}),t}function yb(e,t,n,o){for(;n!==null;){if(n===t)o.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(o.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&yb(e,t,n.child,o))return!0;n=n.sibling}return!1}function fe(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(h(559))}}var vo=null,rr=null;function kv(e,t,n){return e===n?!0:e===t?(vo=e,!0):!1}function wv(e,t,n){return e===n?(rr=e,!1):e===t?(rr!==null&&(vo=e),!0):!1}function _f(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function ur(e,t,n){for(var o=0,a=e;a;a=n(a))o++;a=0;for(var c=t;c;c=n(c))a++;for(;0<o-a;)e=n(e),o--;for(;0<a-o;)t=n(t),a--;for(;o--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var J=Object.assign,Tv=Symbol.for("react.element"),Ec=Symbol.for("react.transitional.element"),xa=Symbol.for("react.portal"),ho=Symbol.for("react.fragment"),Sb=Symbol.for("react.strict_mode"),dr=Symbol.for("react.profiler"),xb=Symbol.for("react.consumer"),xt=Symbol.for("react.context"),yu=Symbol.for("react.forward_ref"),fr=Symbol.for("react.suspense"),sr=Symbol.for("react.suspense_list"),Su=Symbol.for("react.memo"),on=Symbol.for("react.lazy"),br=Symbol.for("react.activity"),Ev=Symbol.for("react.legacy_hidden"),zv=Symbol.for("react.memo_cache_sentinel"),mr=Symbol.for("react.view_transition"),Nv=Symbol.for("react.recoverable"),Mf=Symbol.iterator;function ga(e){return e===null||typeof e!="object"?null:(e=Mf&&e[Mf]||e["@@iterator"],typeof e=="function"?e:null)}var Ov=Symbol.for("react.client.reference");function gr(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===Ov?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case ho:return"Fragment";case dr:return"Profiler";case Sb:return"StrictMode";case fr:return"Suspense";case sr:return"SuspenseList";case br:return"Activity";case mr:return"ViewTransition"}if(typeof e=="object")switch(e.$$typeof){case xa:return"Portal";case xt:return e.displayName||"Context";case xb:return(e._context.displayName||"Context")+".Consumer";case yu:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Su:return t=e.displayName||null,t!==null?t:gr(e.type)||"Memo";case on:t=e._payload,e=e._init;try{return gr(e(t))}catch{}}return null}var ka=Array.isArray,N=bb.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Y=Sv.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Ln={pending:!1,data:null,method:null,action:null},pr=[],yo=-1;function Ot(e){return{current:e}}function Se(e){0>yo||(e.current=pr[yo],pr[yo]=null,yo--)}function I(e,t){yo++,pr[yo]=e.current,e.current=t}var Et=Ot(null),Ya=Ot(null),bn=Ot(null),fl=Ot(null);function sl(e,t){switch(I(bn,t),I(Ya,e),I(Et,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?Zs(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=Zs(t),e=jg(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}Se(Et),I(Et,e)}function Yo(){Se(Et),Se(Ya),Se(bn)}function vr(e){var t=e.memoizedState;t!==null&&(Fo._currentValue=t.memoizedState,I(fl,e)),t=Et.current;var n=jg(t,e.type);t!==n&&(I(Ya,e),I(Et,n))}function bl(e){Ya.current===e&&(Se(Et),Se(Ya)),fl.current===e&&(Se(fl),Fo._currentValue=Ln)}var _i,Df;function tn(e){if(_i===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);_i=t&&t[1]||"",Df=-1<n.stack.indexOf(`
    at`)?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return`
`+_i+e+Df}var Mi=!1;function Di(e,t){if(!e||Mi)return"";Mi=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(t){var p=function(){throw Error()};if(Object.defineProperty(p.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(p,[])}catch(y){var d=y}Reflect.construct(e,[],p)}else{try{p.call()}catch(y){d=y}p=!1;try{var s=Object.getOwnPropertyDescriptor(e.prototype,"props");Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),p=!0,new e}finally{p&&(s!==void 0?Object.defineProperty(e.prototype,"props",s):delete e.prototype.props)}}}else{try{throw Error()}catch(y){d=y}(p=e())&&typeof p.catch=="function"&&p.catch(function(){})}}catch(y){if(y&&d&&typeof y.stack=="string")return[y.stack,d.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var a=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");a&&a.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var c=o.DetermineComponentFrameRoot(),l=c[0],i=c[1];if(l&&i){var r=l.split(`
`),u=i.split(`
`);for(a=o=0;o<r.length&&!r[o].includes("DetermineComponentFrameRoot");)o++;for(;a<u.length&&!u[a].includes("DetermineComponentFrameRoot");)a++;if(o===r.length||a===u.length)for(o=r.length-1,a=u.length-1;1<=o&&0<=a&&r[o]!==u[a];)a--;for(;1<=o&&0<=a;o--,a--)if(r[o]!==u[a]){if(o!==1||a!==1)do if(o--,a--,0>a||r[o]!==u[a]){var m=`
`+r[o].replace(" at new "," at ");return e.displayName&&m.includes("<anonymous>")&&(m=m.replace("<anonymous>",e.displayName)),m}while(1<=o&&0<=a);break}}}finally{Mi=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?tn(n):""}function Cv(e,t){switch(e.tag){case 26:case 27:case 5:return tn(e.type);case 16:return tn("Lazy");case 13:return e.child!==t&&t!==null?tn("Suspense Fallback"):tn("Suspense");case 19:return tn("SuspenseList");case 0:case 15:return Di(e.type,!1);case 11:return Di(e.type.render,!1);case 1:return Di(e.type,!0);case 31:return tn("Activity");case 30:return tn("ViewTransition");default:return""}}function Rf(e){try{var t="",n=null;do t+=Cv(e,n),n=e,e=e.return;while(e);return t}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var hr=Object.prototype.hasOwnProperty,xu=se.unstable_scheduleCallback,Ri=se.unstable_cancelCallback,Av=se.unstable_shouldYield,_v=se.unstable_requestPaint,Qe=se.unstable_now,Mv=se.unstable_getCurrentPriorityLevel,kb=se.unstable_ImmediatePriority,wb=se.unstable_UserBlockingPriority,ml=se.unstable_NormalPriority,Dv=se.unstable_LowPriority,Tb=se.unstable_IdlePriority,Rv=se.log,Uv=se.unstable_setDisableYieldValue,nc=null,Xe=null;function ln(e){if(typeof Rv=="function"&&Uv(e),Xe&&typeof Xe.setStrictMode=="function")try{Xe.setStrictMode(nc,e)}catch{}}var Ze=Math.clz32?Math.clz32:qv,Bv=Math.log,Hv=Math.LN2;function qv(e){return e>>>=0,e===0?32:31-(Bv(e)/Hv|0)|0}var zc=256,Nc=262144,Oc=4194304;function Un(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Ll(e,t,n){var o=e.pendingLanes;if(o===0)return 0;var a=0,c=e.suspendedLanes,l=e.pingedLanes;e=e.warmLanes;var i=o&134217727;return i!==0?(o=i&~c,o!==0?a=Un(o):(l&=i,l!==0?a=Un(l):n||(n=i&~e,n!==0&&(a=Un(n))))):(i=o&~c,i!==0?a=Un(i):l!==0?a=Un(l):n||(n=o&~e,n!==0&&(a=Un(n)))),a===0?0:t!==0&&t!==a&&(t&c)===0&&(c=a&-a,n=t&-t,c>=n||c===32&&(n&4194048)!==0)?t:a}function oc(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Eb(e,t){(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var o=31-Ze(n),a=1<<o;t|=e[o],n&=~a}return t}function Yv(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function zb(){var e=Oc;return Oc<<=1,(Oc&62914560)===0&&(Oc=4194304),e}function Ui(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function ac(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Lv(e,t,n,o,a,c){var l=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var i=e.entanglements,r=e.expirationTimes,u=e.hiddenUpdates;for(n=l&~n;0<n;){var m=31-Ze(n),p=1<<m;i[m]=0,r[m]=-1;var d=u[m];if(d!==null)for(u[m]=null,m=0;m<d.length;m++){var s=d[m];s!==null&&(s.lane&=-536870913)}n&=~p}o!==0&&Nb(e,o,0),c!==0&&a===0&&e.tag!==0&&(e.suspendedLanes|=c&~(l&~t))}function Nb(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var o=31-Ze(t);e.entangledLanes|=t,e.entanglements[o]=e.entanglements[o]|1073741824|n&261930}function Ob(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var o=31-Ze(n),a=1<<o;a&t|e[o]&t&&(e[o]|=t),n&=~a}}function Cb(e,t){var n=t&-t;return n=(n&42)!==0?1:ku(n),(n&(e.suspendedLanes|t))!==0?0:n}function ku(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function wu(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Ab(){var e=Y.p;return e!==0?e:(e=window.event,e===void 0?32:fp(e.type))}function Uf(e,t){var n=Y.p;try{return Y.p=e,t()}finally{Y.p=n}}var Zt=Math.random().toString(36).slice(2),he="__reactFiber$"+Zt,qe="__reactProps$"+Zt,Io="__reactContainer$"+Zt,Bf="__reactEvents$"+Zt,Vv="__reactListeners$"+Zt,Gv="__reactHandles$"+Zt,Hf="__reactResources$"+Zt,cc="__reactMarker$"+Zt,gl="__reactLoad$"+Zt;function Vl(e){delete e[he],delete e[qe],delete e[Vv],delete e[Gv]}function qn(e){var t;if(t=e[he])return t;for(var n=e.parentNode;n;){if(t=n[Io]||n[he]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=eb(e);e!==null;){if(n=e[he])return n;e=eb(e)}return t}e=n,n=e.parentNode}return null}function Po(e){if(e=e[he]||e[Io]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function wa(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(h(33))}function Co(e){var t=e[Hf];return t||(t=e[Hf]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function ge(e){e[cc]=!0}function _b(e){e[gl]=void 0}var Mb=new Set,Db={};function eo(e,t){Lo(e,t),Lo(e+"Capture",t)}function Lo(e,t){for(Db[e]=t,e=0;e<t.length;e++)Mb.add(t[e])}var jv=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),qf={},Yf={};function Qv(e){return hr.call(Yf,e)?!0:hr.call(qf,e)?!1:jv.test(e)?Yf[e]=!0:(qf[e]=!0,!1)}var H=!1;function Lf(){var e=H;return H=!1,e}function Zc(e,t,n){if(Qv(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var o=t.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,n)}}function Cc(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,n)}}function Rt(e,t,n,o){if(o===null)e.removeAttribute(n);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,o)}}function Le(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Rb(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Xv(e,t,n){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var a=o.get,c=o.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return a.call(this)},set:function(l){n=""+l,c.call(this,l)}}),Object.defineProperty(e,t,{enumerable:o.enumerable}),{getValue:function(){return n},setValue:function(l){n=""+l},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function yr(e){if(!e._valueTracker){var t=Rb(e)?"checked":"value";e._valueTracker=Xv(e,t,""+e[t])}}function Ub(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),o="";return e&&(o=Rb(e)?e.checked?"true":"false":e.value),e=o,e!==n?(t.setValue(e),!0):!1}var Zv=/[\n"\\]/g;function tt(e){return e.replace(Zv,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function Sr(e,t,n,o,a,c,l,i){e.name="",l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"?e.type=l:e.removeAttribute("type"),t!=null?l==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+Le(t)):e.value!==""+Le(t)&&(e.value=""+Le(t)):l!=="submit"&&l!=="reset"||e.removeAttribute("value"),t!=null?l==="number"&&e.value==t?Bi(e,Le(e.value)):Bi(e,Le(t)):n!=null?Bi(e,Le(n)):o!=null&&e.removeAttribute("value"),a==null&&c!=null&&(e.defaultChecked=!!c),a!=null&&(e.checked=a&&typeof a!="function"&&typeof a!="symbol"),i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"?e.name=""+Le(i):e.removeAttribute("name")}function Bb(e,t,n,o,a,c,l,i){if(c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"&&(e.type=c),t!=null||n!=null){if(!(c!=="submit"&&c!=="reset"||t!=null)){yr(e);return}n=n!=null?""+Le(n):"",t=t!=null?""+Le(t):n,i||t===e.value||(e.value=t),e.defaultValue=t}o=o??a,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=i?e.checked:!!o,e.defaultChecked=!!o,l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"&&(e.name=l),yr(e)}function Bi(e,t){e.defaultValue!==""+t&&(e.defaultValue=""+t)}function Ao(e,t,n,o){if(e=e.options,t){t={};for(var a=0;a<n.length;a++)t["$"+n[a]]=!0;for(n=0;n<e.length;n++)a=t.hasOwnProperty("$"+e[n].value),e[n].selected!==a&&(e[n].selected=a),a&&o&&(e[n].defaultSelected=!0)}else{for(n=""+Le(n),t=null,a=0;a<e.length;a++){if(e[a].value===n){e[a].selected=!0,o&&(e[a].defaultSelected=!0);return}t!==null||e[a].disabled||(t=e[a])}t!==null&&(t.selected=!0)}}function Hb(e,t,n){if(t!=null&&(t=""+Le(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n!=null?""+Le(n):""}function qb(e,t,n,o){if(t==null){if(o!=null){if(n!=null)throw Error(h(92));if(ka(o)){if(1<o.length)throw Error(h(93));o=o[0]}n=o}n==null&&(n=""),t=n}n=Le(t),e.defaultValue=n,o=e.textContent,o===n&&o!==""&&o!==null&&(e.value=o),yr(e)}function Vo(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var Kv=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function Vf(e,t,n){var o=t.indexOf("--")===0;n==null||typeof n=="boolean"||n===""?o?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":o?e.setProperty(t,n):typeof n!="number"||n===0||Kv.has(t)?t==="float"?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function Yb(e,t,n){if(t!=null&&typeof t!="object")throw Error(h(62));if(e=e.style,n!=null){for(var o in n)!n.hasOwnProperty(o)||t!=null&&t.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="",H=!0);for(var a in t)o=t[a],t.hasOwnProperty(a)&&n[a]!==o&&(Vf(e,a,o),H=!0)}else for(var c in t)t.hasOwnProperty(c)&&Vf(e,c,t[c])}function Tu(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Jv=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Fv=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Kc(e){return Fv.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function kt(){}var xr=null;function Eu(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var So=null,_o=null;function Gf(e){var t=Po(e);if(t&&(e=t.stateNode)){var n=e[qe]||null;e:switch(e=t.stateNode,t.type){case"input":if(Sr(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+tt(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var o=n[t];if(o!==e&&o.form===e.form){var a=o[qe]||null;if(!a)throw Error(h(90));Sr(o,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)o=n[t],o.form===e.form&&Ub(o)}break e;case"textarea":Hb(e,n.value,n.defaultValue);break e;case"select":t=n.value,t!=null&&Ao(e,!!n.multiple,t,!1)}}}var Hi=!1;function Lb(e,t,n){if(Hi)return e(t,n);Hi=!0;try{var o=e(t);return o}finally{if(Hi=!1,(So!==null||_o!==null)&&(ti(),So&&(t=So,e=_o,_o=So=null,Gf(t),e)))for(t=0;t<e.length;t++)Gf(e[t])}}function La(e,t){var n=e.stateNode;if(n===null)return null;var o=n[qe]||null;if(o===null)return null;n=o[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(h(231,t,typeof n));return n}var Lt=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),kr=!1;if(Lt)try{fo={},Object.defineProperty(fo,"passive",{get:function(){kr=!0}}),window.addEventListener("test",fo,fo),window.removeEventListener("test",fo,fo)}catch{kr=!1}var fo,rn=null,zu=null,Jc=null;function Vb(){if(Jc)return Jc;var e,t=zu,n=t.length,o,a="value"in rn?rn.value:rn.textContent,c=a.length;for(e=0;e<n&&t[e]===a[e];e++);var l=n-e;for(o=1;o<=l&&t[n-o]===a[c-o];o++);return Jc=a.slice(e,1<o?1-o:void 0)}function Fc(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Ac(){return!0}function jf(){return!1}function _e(e){function t(n,o,a,c,l){this._reactName=n,this._targetInst=a,this.type=o,this.nativeEvent=c,this.target=l,this.currentTarget=null;for(var i in e)e.hasOwnProperty(i)&&(n=e[i],this[i]=n?n(c):c[i]);return this.isDefaultPrevented=(c.defaultPrevented!=null?c.defaultPrevented:c.returnValue===!1)?Ac:jf,this.isPropagationStopped=jf,this}return J(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=Ac)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=Ac)},persist:function(){},isPersistent:Ac}),t}var On={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Gl=_e(On),lc=J({},On,{view:0,detail:0}),Wv=_e(lc),qi,Yi,pa,jl=J({},lc,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Nu,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==pa&&(pa&&e.type==="mousemove"?(qi=e.screenX-pa.screenX,Yi=e.screenY-pa.screenY):Yi=qi=0,pa=e),qi)},movementY:function(e){return"movementY"in e?e.movementY:Yi}}),Qf=_e(jl),$v=J({},jl,{dataTransfer:0}),Iv=_e($v),Pv=J({},lc,{relatedTarget:0}),Li=_e(Pv),eh=J({},On,{animationName:0,elapsedTime:0,pseudoElement:0}),th=_e(eh),nh=J({},On,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),oh=_e(nh),ah=J({},On,{data:0}),Xf=_e(ah),ch={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},lh={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},ih={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function rh(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=ih[e])?!!t[e]:!1}function Nu(){return rh}var uh=J({},lc,{key:function(e){if(e.key){var t=ch[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=Fc(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?lh[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Nu,charCode:function(e){return e.type==="keypress"?Fc(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Fc(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),dh=_e(uh),fh=J({},jl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Zf=_e(fh),sh=J({},On,{submitter:0}),bh=_e(sh),mh=J({},lc,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Nu}),gh=_e(mh),ph=J({},On,{propertyName:0,elapsedTime:0,pseudoElement:0}),vh=_e(ph),hh=J({},jl,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),yh=_e(hh),Sh=J({},On,{newState:0,oldState:0,source:0}),xh=_e(Sh),kh=[9,13,27,32],Ou=Lt&&"CompositionEvent"in window,za=null;Lt&&"documentMode"in document&&(za=document.documentMode);var wh=Lt&&"TextEvent"in window&&!za,Gb=Lt&&(!Ou||za&&8<za&&11>=za),Kf=" ",Jf=!1;function jb(e,t){switch(e){case"keyup":return kh.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Qb(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var xo=!1;function Th(e,t){switch(e){case"compositionend":return Qb(t);case"keypress":return t.which!==32?null:(Jf=!0,Kf);case"textInput":return e=t.data,e===Kf&&Jf?null:e;default:return null}}function Eh(e,t){if(xo)return e==="compositionend"||!Ou&&jb(e,t)?(e=Vb(),Jc=zu=rn=null,xo=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Gb&&t.locale!=="ko"?null:t.data;default:return null}}var zh={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Ff(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!zh[e.type]:t==="textarea"}function Xb(e,t,n,o){So?_o?_o.push(o):_o=[o]:So=o,t=Hl(t,"onChange"),0<t.length&&(n=new Gl("onChange","change",null,n,o),e.push({event:n,listeners:t}))}var Na=null,Va=null;function Nh(e){Lg(e,0)}function Ql(e){var t=wa(e);if(Ub(t))return e}function Wf(e,t){if(e==="change")return t}var Zb=!1;Lt&&(Lt?(Mc="oninput"in document,Mc||(Vi=document.createElement("div"),Vi.setAttribute("oninput","return;"),Mc=typeof Vi.oninput=="function"),_c=Mc):_c=!1,Zb=_c&&(!document.documentMode||9<document.documentMode));var _c,Mc,Vi;function $f(){Na&&(Na.detachEvent("onpropertychange",Kb),Va=Na=null)}function Kb(e){if(e.propertyName==="value"&&Ql(Va)){var t=[];Xb(t,Va,e,Eu(e)),Lb(Nh,t)}}function Oh(e,t,n){e==="focusin"?($f(),Na=t,Va=n,Na.attachEvent("onpropertychange",Kb)):e==="focusout"&&$f()}function Ch(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Ql(Va)}function Ah(e,t){if(e==="click")return Ql(t)}function _h(e,t){if(e==="input"||e==="change")return Ql(t)}function Mh(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Je=typeof Object.is=="function"?Object.is:Mh;function Ga(e,t){if(Je(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),o=Object.keys(t);if(n.length!==o.length)return!1;for(o=0;o<n.length;o++){var a=n[o];if(!hr.call(t,a)||!Je(e[a],t[a]))return!1}return!0}function wr(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function If(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Pf(e,t){var n=If(e);e=0;for(var o;n;){if(n.nodeType===3){if(o=e+n.textContent.length,e<=t&&o>=t)return{node:n,offset:t-e};e=o}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=If(n)}}function Jb(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Jb(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Fb(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=wr(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=wr(e.document)}return t}function Cu(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var Dh=Lt&&"documentMode"in document&&11>=document.documentMode,ko=null,Tr=null,Oa=null,Er=!1;function es(e,t,n){var o=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Er||ko==null||ko!==wr(o)||(o=ko,"selectionStart"in o&&Cu(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),Oa&&Ga(Oa,o)||(Oa=o,o=Hl(Tr,"onSelect"),0<o.length&&(t=new Gl("onSelect","select",null,t,n),e.push({event:t,listeners:o}),t.target=ko)))}function Dn(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var wo={animationend:Dn("Animation","AnimationEnd"),animationiteration:Dn("Animation","AnimationIteration"),animationstart:Dn("Animation","AnimationStart"),transitionrun:Dn("Transition","TransitionRun"),transitionstart:Dn("Transition","TransitionStart"),transitioncancel:Dn("Transition","TransitionCancel"),transitionend:Dn("Transition","TransitionEnd")},Gi={},Wb={};Lt&&(Wb=document.createElement("div").style,"AnimationEvent"in window||(delete wo.animationend.animation,delete wo.animationiteration.animation,delete wo.animationstart.animation),"TransitionEvent"in window||delete wo.transitionend.transition);function to(e){if(Gi[e])return Gi[e];if(!wo[e])return e;var t=wo[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Wb)return Gi[e]=t[n];return e}var $b=to("animationend"),Ib=to("animationiteration"),Pb=to("animationstart"),Rh=to("transitionrun"),Uh=to("transitionstart"),Bh=to("transitioncancel"),em=to("transitionend"),tm=new Map,zr="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");zr.push("scrollEnd");function st(e,t){tm.set(e,t),eo(t,[e])}var Hh=0;function Vt(e,t){if(e.name!=null&&e.name!=="auto")return e.name;if(t.autoName!==null)return t.autoName;e=ft.identifierPrefix;var n=Hh++;return e="_"+e+"t_"+n.toString(32)+"_",t.autoName=e}function ts(e){if(e==null||typeof e=="string")return e;var t=null,n=qo;if(n!==null)for(var o=0;o<n.length;o++){var a=e[n[o]];if(a!=null){if(a==="none")return"none";t=t==null?a:t+(" "+a)}}return t??e.default}function Kt(e,t){return e=ts(e),t=ts(t),t==null?e==="auto"?null:e:t==="auto"?null:t}var pl=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Ie=[],To=0,Au=0;function Xl(){for(var e=To,t=Au=To=0;t<e;){var n=Ie[t];Ie[t++]=null;var o=Ie[t];Ie[t++]=null;var a=Ie[t];Ie[t++]=null;var c=Ie[t];if(Ie[t++]=null,o!==null&&a!==null){var l=o.pending;l===null?a.next=a:(a.next=l.next,l.next=a),o.pending=a}c!==0&&nm(n,a,c)}}function Zl(e,t,n,o){Ie[To++]=e,Ie[To++]=t,Ie[To++]=n,Ie[To++]=o,Au|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function _u(e,t,n,o){return Zl(e,t,n,o),vl(e)}function no(e,t){return Zl(e,null,null,t),vl(e)}function nm(e,t,n){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n);for(var a=!1,c=e.return;c!==null;)c.childLanes|=n,o=c.alternate,o!==null&&(o.childLanes|=n),c.tag===22&&(e=c.stateNode,e===null||e._visibility&1||(a=!0)),e=c,c=c.return;return e.tag===3?(c=e.stateNode,a&&t!==null&&(a=31-Ze(n),e=c.hiddenUpdates,o=e[a],o===null?e[a]=[t]:o.push(t),t.lane=n|536870912),c):null}function vl(e){if(50<qa)throw qa=0,cl=null,Error(h(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Eo={};function qh(e,t,n,o){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Ue(e,t,n,o){return new qh(e,t,n,o)}function Mu(e){return e=e.prototype,!(!e||!e.isReactComponent)}function qt(e,t){var n=e.alternate;return n===null?(n=Ue(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function om(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Wc(e,t,n,o,a,c){var l=0;if(o=e,typeof o=="function")Mu(o)&&(l=1);else if(typeof o=="string")l=dy(e,n,Et.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(o){case br:return e=Ue(31,n,t,a),e.elementType=br,e.lanes=c,e;case ho:return Vn(n.children,a,c,t);case Sb:l=8,a|=24;break;case dr:return e=Ue(12,n,t,a|2),e.elementType=dr,e.lanes=c,e;case fr:return e=Ue(13,n,t,a),e.elementType=fr,e.lanes=c,e;case sr:return e=Ue(19,n,t,a),e.elementType=sr,e.lanes=c,e;case Ev:case mr:return e=a|32,e=Ue(30,n,t,e),e.elementType=mr,e.lanes=c,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof o=="object"&&o!==null)switch(o.$$typeof){case xt:l=10;break e;case xb:l=9;break e;case yu:l=11;break e;case Su:l=14;break e;case on:l=16,o=null;break e}l=29,n=Error(h(130,e===null?"null":typeof e,"")),o=null}return t=Ue(l,n,t,a),t.elementType=e,t.type=o,t.lanes=c,t}function Vn(e,t,n,o){return e=Ue(7,e,o,t),e.lanes=n,e}function ji(e,t,n){return e=Ue(6,e,null,t),e.lanes=n,e}function am(e){var t=Ue(18,null,null,0);return t.stateNode=e,t}function Qi(e,t,n){return t=Ue(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var ns=new WeakMap;function nt(e,t){if(typeof e=="object"&&e!==null){var n=ns.get(e);return n!==void 0?n:(t={value:e,source:t,stack:Rf(t)},ns.set(e,t),t)}return{value:e,source:t,stack:Rf(t)}}var zo=[],No=0,hl=null,ja=0,Pe=[],et=0,wn=null,wt=1,Tt="";function Bt(e,t){zo[No++]=ja,zo[No++]=hl,hl=e,ja=t}function cm(e,t,n){Pe[et++]=wt,Pe[et++]=Tt,Pe[et++]=wn,wn=e;var o=wt;e=Tt;var a=32-Ze(o)-1;o&=~(1<<a),n+=1;var c=32-Ze(t)+a;if(30<c){var l=a-a%5;c=(o&(1<<l)-1).toString(32),o>>=l,a-=l,wt=1<<32-Ze(t)+a|n<<a|o,Tt=c+e}else wt=1<<c|n<<a|o,Tt=e}function Kl(e){e.return!==null&&(Bt(e,1),cm(e,1,0))}function Du(e){for(;e===hl;)hl=zo[--No],zo[No]=null,ja=zo[--No],zo[No]=null;for(;e===wn;)wn=Pe[--et],Pe[et]=null,Tt=Pe[--et],Pe[et]=null,wt=Pe[--et],Pe[et]=null}function lm(e,t){Pe[et++]=wt,Pe[et++]=Tt,Pe[et++]=wn,wt=t.id,Tt=t.overflow,wn=e}var pe=null,$=null,A=!1,mn=null,ot=!1,Nr=Error(h(519));function Tn(e){var t=Error(h(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Qa(nt(t,e)),Nr}function os(e){var t=e.stateNode,n=e.type,o=e.memoizedProps;switch(t[he]=e,t[qe]=o,n){case"dialog":M("cancel",t),M("close",t);break;case"iframe":case"object":case"embed":M("load",t);break;case"video":case"audio":for(n=0;n<Ja.length;n++)M(Ja[n],t);break;case"source":M("error",t);break;case"img":case"image":case"link":M("error",t),M("load",t);break;case"details":M("toggle",t);break;case"input":M("invalid",t),Bb(t,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":M("invalid",t);break;case"textarea":M("invalid",t),qb(t,o.value,o.defaultValue,o.children)}n=o.children,typeof n!="string"&&typeof n!="number"&&typeof n!="bigint"||t.textContent===""+n||o.suppressHydrationWarning===!0||Gg(t.textContent,n)?(o.popover!=null&&(M("beforetoggle",t),M("toggle",t)),o.onScroll!=null&&M("scroll",t),o.onScrollEnd!=null&&M("scrollend",t),o.onClick!=null&&(t.onclick=kt),t=!0):t=!1,t||Tn(e,!0)}function yl(e){for(pe=e.return;pe;)switch(pe.tag){case 5:case 31:case 13:ot=!1;return;case 27:case 3:ot=!0;return;default:pe=pe.return}}function so(e){if(e!==pe)return!1;if(!A)return yl(e),A=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!=="form"&&n!=="button")||fu(e.type,e.memoizedProps)),n=!n),n&&$&&Tn(e),yl(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(h(317));$=Ps(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(h(317));$=Ps(e)}else t===27?(t=$,Cn(e.type)?(e=gu,gu=null,$=e):$=t):$=pe?at(e.stateNode.nextSibling):null;return!0}function Xn(){$=pe=null,A=!1}function Xi(){var e=mn;return e!==null&&(De===null?De=e:De.push.apply(De,e),mn=null),e}function Qa(e){mn===null?mn=[e]:mn.push(e)}var Or=Ot(null),oo=null,Ht=null;function un(e,t,n){I(Or,t._currentValue),t._currentValue=n}function Yt(e){e._currentValue=Or.current,Se(Or)}function $c(e,t,n){for(;e!==null;){var o=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,o!==null&&(o.childLanes|=t)):o!==null&&(o.childLanes&t)!==t&&(o.childLanes|=t),e===n)break;e=e.return}}function Cr(e,t,n,o){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var c=a.dependencies;if(c!==null){var l=a.child;c=c.firstContext;e:for(;c!==null;){var i=c;c=a;for(var r=0;r<t.length;r++)if(i.context===t[r]){c.lanes|=n,i=c.alternate,i!==null&&(i.lanes|=n),$c(c.return,n,e),o||(l=null);break e}c=i.next}}else if(a.tag===18){if(l=a.return,l===null)throw Error(h(341));l.lanes|=n,c=l.alternate,c!==null&&(c.lanes|=n),$c(l,n,e),l=null}else a.tag===13&&a.memoizedState!==null&&a.memoizedState.dehydrated===null?(a.lanes|=n,l=a.alternate,l!==null&&(l.lanes|=n),$c(a.return,n,e),l=a.child,l=l!==null?l.sibling:null):l=a.child;if(l!==null)l.return=a;else for(l=a;l!==null;){if(l===e){l=null;break}if(a=l.sibling,a!==null){a.return=l.return,l=a;break}l=l.return}a=l}}function Zn(e,t,n,o){e=null;for(var a=t,c=!1;a!==null;){if(!c){if((a.flags&524288)!==0)c=!0;else if((a.flags&262144)!==0)break}if(a.tag===10){var l=a.alternate;if(l===null)throw Error(h(387));if(l=l.memoizedProps,l!==null){var i=a.type;Je(a.pendingProps.value,l.value)||(e!==null?e.push(i):e=[i])}}else if(a===fl.current){if(l=a.alternate,l===null)throw Error(h(387));l.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e!==null?e.push(Fo):e=[Fo])}a=a.return}return e!==null&&Cr(t,e,n,o),t.flags|=262144,e!==null}function Sl(e){for(e=e.firstContext;e!==null;){if(!Je(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function Kn(e){oo=e,Ht=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ye(e){return im(oo,e)}function Dc(e,t){return oo===null&&Kn(e),im(e,t)}function im(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},Ht===null){if(e===null)throw Error(h(308));Ht=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else Ht=Ht.next=t;return n}var Yh=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(n,o){e.push(o)}};this.abort=function(){t.aborted=!0,e.forEach(function(n){return n()})}},Lh=se.unstable_scheduleCallback,Vh=se.unstable_NormalPriority,ie={$$typeof:xt,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Ru(){return{controller:new Yh,data:new Map,refCount:0}}function ic(e){e.refCount--,e.refCount===0&&Lh(Vh,function(){e.controller.abort()})}function as(e,t){if((e.pendingLanes&4194048)!==0){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var o=t[e];n.indexOf(o)===-1&&n.push(o)}}}var Ta=null;function Gh(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var Ca=null,Ar=0,Jn=0,Mo=null;function jh(e,t){if(Ca===null){var n=Ca=[];Ar=0,Jn=rd(),Mo={status:"pending",value:void 0,then:function(o){n.push(o)}}}return Ar++,t.then(cs,cs),t}function cs(){if(--Ar===0&&(Ta=null,Ca!==null)){Mo!==null&&(Mo.status="fulfilled");var e=Ca;Ca=null,Jn=0,Mo=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Qh(e,t){var n=[],o={status:"pending",value:null,reason:null,then:function(a){n.push(a)}};return e.then(function(){o.status="fulfilled",o.value=t;for(var a=0;a<n.length;a++)(0,n[a])(t)},function(a){for(o.status="rejected",o.reason=a,a=0;a<n.length;a++)(0,n[a])(void 0)}),o}var ls=N.S;N.S=function(e,t){if(Eg=Qe(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&jh(e,t),Ta!==null)for(var n=Zo;n!==null;)as(n,Ta),n=n.next;if(n=e.types,n!==null){for(var o=Zo;o!==null;)as(o,n),o=o.next;if(Jn!==0){o=Ta,o===null&&(o=Ta=[]);for(var a=0;a<n.length;a++){var c=n[a];o.indexOf(c)===-1&&o.push(c)}}}ls!==null&&ls(e,t)};var Gn=Ot(null);function Uu(){var e=Gn.current;return e!==null?e:K.pooledCache}function Ic(e,t){t===null?I(Gn,Gn.current):I(Gn,t.pool)}function rm(){var e=Uu();return e===null?null:{parent:ie._currentValue,pool:e}}var ea=Error(h(460)),Bu=Error(h(474)),Jl=Error(h(542)),xl={then:function(){}};function is(e){return e=e.status,e==="fulfilled"||e==="rejected"}function um(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(kt,kt),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,us(e),e===void 0&&!("reason"in t)?Error(h(600)):e;default:if(typeof t.status=="string")t.then(kt,kt);else{if(e=K,e!==null&&100<e.shellSuspendCounter)throw Error(h(482));e=t,e.status="pending",e.then(function(o){if(t.status==="pending"){var a=t;a.status="fulfilled",a.value=o}},function(o){if(t.status==="pending"){var a=t;a.status="rejected",a.reason=o}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,us(e),e}throw jn=t,ea}}function Bn(e){try{var t=e._init;return t(e._payload)}catch(n){throw n!==null&&typeof n=="object"&&typeof n.then=="function"?(jn=n,ea):n}}var jn=null;function rs(){if(jn===null)throw Error(h(459));var e=jn;return jn=null,e}function us(e){if(e===ea||e===Jl)throw Error(h(483))}var Do=null,Xa=0;function Rc(e){var t=Xa;return Xa+=1,Do===null&&(Do=[]),um(Do,e,t)}function en(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function Uc(e,t){throw t.$$typeof===Tv?Error(h(525)):(e=Object.prototype.toString.call(t),Error(h(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function dm(e){function t(g,f){if(e){var b=g.deletions;b===null?(g.deletions=[f],g.flags|=16):b.push(f)}}function n(g,f){if(!e)return null;for(;f!==null;)t(g,f),f=f.sibling;return null}function o(g){for(var f=new Map;g!==null;)g.key===null?f.set(g.index,g):f.set(g.key,g),g=g.sibling;return f}function a(g,f){return g=qt(g,f),g.index=0,g.sibling=null,g}function c(g,f,b){return g.index=b,e?(b=g.alternate,b!==null?(b=b.index,b<f?(g.flags|=2,f):b):(g.flags|=134217730,f)):(g.flags|=1048576,f)}function l(g){return e&&g.alternate===null&&(g.flags|=134217730),g}function i(g,f,b,v){return f===null||f.tag!==6?(f=ji(b,g.mode,v),f.return=g,f):(f=a(f,b),f.return=g,f)}function r(g,f,b,v){var x=b.type;return x===ho?(g=m(g,f,b.props.children,v,b.key),en(g,b),g):f!==null&&(f.elementType===x||typeof x=="object"&&x!==null&&x.$$typeof===on&&Bn(x)===f.type)?(f=a(f,b.props),en(f,b),f.return=g,f):(f=Wc(b.type,b.key,b.props,null,g.mode,v),en(f,b),f.return=g,f)}function u(g,f,b,v){return f===null||f.tag!==4||f.stateNode.containerInfo!==b.containerInfo||f.stateNode.implementation!==b.implementation?(f=Qi(b,g.mode,v),f.return=g,f):(f=a(f,b.children||[]),f.return=g,f)}function m(g,f,b,v,x){return f===null||f.tag!==7?(f=Vn(b,g.mode,v,x),f.return=g,f):(f=a(f,b),f.return=g,f)}function p(g,f,b){if(typeof f=="string"&&f!==""||typeof f=="number"||typeof f=="bigint")return f=ji(""+f,g.mode,b),f.return=g,f;if(typeof f=="object"&&f!==null){switch(f.$$typeof){case Ec:return b=Wc(f.type,f.key,f.props,null,g.mode,b),en(b,f),b.return=g,b;case xa:return f=Qi(f,g.mode,b),f.return=g,f;case on:return f=Bn(f),p(g,f,b)}if(ka(f)||ga(f))return f=Vn(f,g.mode,b,null),f.return=g,f;if(typeof f.then=="function")return p(g,Rc(f),b);if(f.$$typeof===xt)return p(g,Dc(g,f),b);Uc(g,f)}return null}function d(g,f,b,v){var x=f!==null?f.key:null;if(typeof b=="string"&&b!==""||typeof b=="number"||typeof b=="bigint")return x!==null?null:i(g,f,""+b,v);if(typeof b=="object"&&b!==null){switch(b.$$typeof){case Ec:return b.key===x?r(g,f,b,v):null;case xa:return b.key===x?u(g,f,b,v):null;case on:return b=Bn(b),d(g,f,b,v)}if(ka(b)||ga(b))return x!==null?null:m(g,f,b,v,null);if(typeof b.then=="function")return d(g,f,Rc(b),v);if(b.$$typeof===xt)return d(g,f,Dc(g,b),v);Uc(g,b)}return null}function s(g,f,b,v,x){if(typeof v=="string"&&v!==""||typeof v=="number"||typeof v=="bigint")return g=g.get(b)||null,i(f,g,""+v,x);if(typeof v=="object"&&v!==null){switch(v.$$typeof){case Ec:return g=g.get(v.key===null?b:v.key)||null,r(f,g,v,x);case xa:return g=g.get(v.key===null?b:v.key)||null,u(f,g,v,x);case on:return v=Bn(v),s(g,f,b,v,x)}if(ka(v)||ga(v))return g=g.get(b)||null,m(f,g,v,x,null);if(typeof v.then=="function")return s(g,f,b,Rc(v),x);if(v.$$typeof===xt)return s(g,f,b,Dc(f,v),x);Uc(f,v)}return null}function y(g,f,b,v){for(var x=null,T=null,k=f,E=f=0,Z=null;k!==null&&E<b.length;E++){k.index>E?(Z=k,k=null):Z=k.sibling;var U=d(g,k,b[E],v);if(U===null){k===null&&(k=Z);break}e&&k&&U.alternate===null&&t(g,k),f=c(U,f,E),T===null?x=U:T.sibling=U,T=U,k=Z}if(E===b.length)return n(g,k),A&&Bt(g,E),x;if(k===null){for(;E<b.length;E++)k=p(g,b[E],v),k!==null&&(f=c(k,f,E),T===null?x=k:T.sibling=k,T=k);return A&&Bt(g,E),x}for(k=o(k);E<b.length;E++)Z=s(k,g,E,b[E],v),Z!==null&&(e&&(U=Z.alternate,U!==null&&k.delete(U.key===null?E:U.key)),f=c(Z,f,E),T===null?x=Z:T.sibling=Z,T=Z);return e&&k.forEach(function(Ft){return t(g,Ft)}),A&&Bt(g,E),x}function w(g,f,b,v){if(b==null)throw Error(h(151));for(var x=null,T=null,k=f,E=f=0,Z=null,U=b.next();k!==null&&!U.done;E++,U=b.next()){k.index>E?(Z=k,k=null):Z=k.sibling;var Ft=d(g,k,U.value,v);if(Ft===null){k===null&&(k=Z);break}e&&k&&Ft.alternate===null&&t(g,k),f=c(Ft,f,E),T===null?x=Ft:T.sibling=Ft,T=Ft,k=Z}if(U.done)return n(g,k),A&&Bt(g,E),x;if(k===null){for(;!U.done;E++,U=b.next())U=p(g,U.value,v),U!==null&&(f=c(U,f,E),T===null?x=U:T.sibling=U,T=U);return A&&Bt(g,E),x}for(k=o(k);!U.done;E++,U=b.next())U=s(k,g,E,U.value,v),U!==null&&(e&&(Z=U.alternate,Z!==null&&k.delete(Z.key===null?E:Z.key)),f=c(U,f,E),T===null?x=U:T.sibling=U,T=U);return e&&k.forEach(function(Dp){return t(g,Dp)}),A&&Bt(g,E),x}function z(g,f,b,v){if(typeof b=="object"&&b!==null&&b.type===ho&&b.key===null&&b.props.ref===void 0&&(b=b.props.children),typeof b=="object"&&b!==null){switch(b.$$typeof){case Ec:e:{for(var x=b.key;f!==null;){if(f.key===x){if(x=b.type,x===ho){if(f.tag===7){n(g,f.sibling),v=a(f,b.props.children),en(v,b),v.return=g,g=v;break e}}else if(f.elementType===x||typeof x=="object"&&x!==null&&x.$$typeof===on&&Bn(x)===f.type){n(g,f.sibling),v=a(f,b.props),en(v,b),v.return=g,g=v;break e}n(g,f);break}else t(g,f);f=f.sibling}b.type===ho?(v=Vn(b.props.children,g.mode,v,b.key),en(v,b),v.return=g,g=v):(v=Wc(b.type,b.key,b.props,null,g.mode,v),en(v,b),v.return=g,g=v)}return l(g);case xa:e:{for(x=b.key;f!==null;){if(f.key===x)if(f.tag===4&&f.stateNode.containerInfo===b.containerInfo&&f.stateNode.implementation===b.implementation){n(g,f.sibling),v=a(f,b.children||[]),v.return=g,g=v;break e}else{n(g,f);break}else t(g,f);f=f.sibling}v=Qi(b,g.mode,v),v.return=g,g=v}return l(g);case on:return b=Bn(b),z(g,f,b,v)}if(ka(b))return y(g,f,b,v);if(ga(b)){if(x=ga(b),typeof x!="function")throw Error(h(150));return b=x.call(b),w(g,f,b,v)}if(typeof b.then=="function")return z(g,f,Rc(b),v);if(b.$$typeof===xt)return z(g,f,Dc(g,b),v);Uc(g,b)}return typeof b=="string"&&b!==""||typeof b=="number"||typeof b=="bigint"?(b=""+b,f!==null&&f.tag===6?(n(g,f.sibling),v=a(f,b),v.return=g,g=v):(n(g,f),v=ji(b,g.mode,v),v.return=g,g=v),l(g)):n(g,f)}return function(g,f,b,v){try{Xa=0;var x=z(g,f,b,v);return Do=null,x}catch(k){if(k===ea||k===Jl)throw k;var T=Ue(29,k,null,g.mode);return T.lanes=v,T.return=g,T}}}var Fn=dm(!0),fm=dm(!1),an=!1;function Hu(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function _r(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function gn(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function pn(e,t,n){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(q&2)!==0){var a=o.pending;return a===null?t.next=t:(t.next=a.next,a.next=t),o.pending=t,t=vl(e),nm(e,null,n),t}return Zl(e,o,t,n),vl(e)}function Aa(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194048)!==0)){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Ob(e,n)}}function Zi(e,t){var n=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,n===o)){var a=null,c=null;if(n=n.firstBaseUpdate,n!==null){do{var l={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};c===null?a=c=l:c=c.next=l,n=n.next}while(n!==null);c===null?a=c=t:c=c.next=t}else a=c=t;n={baseState:o.baseState,firstBaseUpdate:a,lastBaseUpdate:c,shared:o.shared,callbacks:o.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var Mr=!1;function _a(){if(Mr){var e=Mo;if(e!==null)throw e}}function Ma(e,t,n,o){Mr=!1;var a=e.updateQueue;an=!1;var c=a.firstBaseUpdate,l=a.lastBaseUpdate,i=a.shared.pending;if(i!==null){a.shared.pending=null;var r=i,u=r.next;r.next=null,l===null?c=u:l.next=u,l=r;var m=e.alternate;m!==null&&(m=m.updateQueue,i=m.lastBaseUpdate,i!==l&&(i===null?m.firstBaseUpdate=u:i.next=u,m.lastBaseUpdate=r))}if(c!==null){var p=a.baseState;l=0,m=u=r=null,i=c;do{var d=i.lane&-536870913,s=d!==i.lane;if(s?(R&d)===d:(o&d)===d){d!==0&&d===Jn&&(Mr=!0),m!==null&&(m=m.next={lane:0,tag:i.tag,payload:i.payload,callback:null,next:null});e:{var y=e,w=i;d=t;var z=n;switch(w.tag){case 1:if(y=w.payload,typeof y=="function"){p=y.call(z,p,d);break e}p=y;break e;case 3:y.flags=y.flags&-65537|128;case 0:if(y=w.payload,d=typeof y=="function"?y.call(z,p,d):y,d==null)break e;p=J({},p,d);break e;case 2:an=!0}}d=i.callback,d!==null&&(e.flags|=64,s&&(e.flags|=8192),s=a.callbacks,s===null?a.callbacks=[d]:s.push(d))}else s={lane:d,tag:i.tag,payload:i.payload,callback:i.callback,next:null},m===null?(u=m=s,r=p):m=m.next=s,l|=d;if(i=i.next,i===null){if(i=a.shared.pending,i===null)break;s=i,i=s.next,s.next=null,a.lastBaseUpdate=s,a.shared.pending=null}}while(!0);m===null&&(r=p),a.baseState=r,a.firstBaseUpdate=u,a.lastBaseUpdate=m,c===null&&(a.shared.lanes=0),Nn|=l,e.lanes=l,e.memoizedState=p}}function sm(e,t){if(typeof e!="function")throw Error(h(191,e));e.call(t)}function bm(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)sm(n[e],t)}var En=Ot(null),kl=Ot(0);function ds(e,t){e=Xt,I(kl,e),I(En,t),Xt=e|t.baseLanes}function Dr(){I(kl,Xt),I(En,En.current)}function qu(){Xt=kl.current,Se(En),Se(kl)}var we=Ot(null),ze=null;function vn(e){var t=e.alternate;I(xe,xe.current&1),I(we,e),ze===null&&(t===null||En.current!==null||t.memoizedState!==null)&&(ze=e)}function Rr(e){I(xe,xe.current),I(we,e),ze===null&&(ze=e)}function mm(e){e.tag===22?(I(xe,xe.current),I(we,e),ze===null&&(ze=e)):hn()}function hn(){I(xe,xe.current),I(we,we.current)}function Ve(e){Se(we),ze===e&&(ze=null),Se(xe)}var xe=Ot(0);function Za(e,t){I(we,we.current),I(xe,t)}function Yu(e){Se(xe),Se(we),ze===e&&(ze=null)}function wl(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||mu(n)||sd(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!=="independent"){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Gt=0,C=null,X=null,le=null,Tl=!1,Ro=!1,Wn=!1,El=0,Ka=0,Uo=null,Xh=0;function oe(){throw Error(h(321))}function Lu(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Je(e[n],t[n]))return!1;return!0}function Vu(e,t,n,o,a,c){return Gt=c,C=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,N.H=e===null||e.memoizedState===null?Xm:Zm,Wn=!1,c=n(o,a),Wn=!1,Ro&&(c=pm(t,n,o,a)),gm(e),c}function gm(e){N.H=zl;var t=X!==null&&X.next!==null;if(Gt=0,le=X=C=null,Tl=!1,Ka=0,Uo=null,t)throw Error(h(300));e===null||re||(e=e.dependencies,e!==null&&Sl(e)&&(re=!0))}function pm(e,t,n,o){C=e;var a=0;do{if(Ro&&(Uo=null),Ka=0,Ro=!1,25<=a)throw Error(h(301));if(a+=1,le=X=null,e.updateQueue!=null){var c=e.updateQueue;c.lastEffect=null,c.events=null,c.stores=null,c.memoCache!=null&&(c.memoCache.index=0)}N.H=Ph,c=t(n,o)}while(Ro);return c}function Zh(){var e=N.H,t=e.useState()[0];return t=typeof t.then=="function"?rc(t):t,e=e.useState()[0],(X!==null?X.memoizedState:null)!==e&&(C.flags|=1024),t}function Gu(){var e=El!==0;return El=0,e}function ju(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function Qu(e){if(Tl){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Tl=!1}Gt=0,le=X=C=null,Ro=!1,Ka=El=0,Uo=null}function Ae(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return le===null?C.memoizedState=le=e:le=le.next=e,le}function ce(){if(X===null){var e=C.alternate;e=e!==null?e.memoizedState:null}else e=X.next;var t=le===null?C.memoizedState:le.next;if(t!==null)le=t,X=e;else{if(e===null)throw C.alternate===null?Error(h(467)):Error(h(310));X=e,e={memoizedState:X.memoizedState,baseState:X.baseState,baseQueue:X.baseQueue,queue:X.queue,next:null},le===null?C.memoizedState=le=e:le=le.next=e}return le}function Fl(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function rc(e){var t=Ka;return Ka+=1,Uo===null&&(Uo=[]),e=um(Uo,e,t),t=C,(le===null?t.memoizedState:le.next)===null&&(t=t.alternate,N.H=t===null||t.memoizedState===null?Xm:Zm),e}function Wl(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return rc(e);if(e.$$typeof===Nv)return;if(e.$$typeof===xt)return ye(e)}throw Error(h(438,String(e)))}function Xu(e){var t=null,n=C.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var o=C.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(t={data:o.data.map(function(a){return a.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),n===null&&(n=Fl(),C.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),o=0;o<e;o++)n[o]=zv;return t.index++,n}function jt(e,t){return typeof t=="function"?t(e):t}function Pc(e){var t=ce();return Zu(t,X,e)}function Zu(e,t,n){var o=e.queue;if(o===null)throw Error(h(311));o.lastRenderedReducer=n;var a=e.baseQueue,c=o.pending;if(c!==null){if(a!==null){var l=a.next;a.next=c.next,c.next=l}t.baseQueue=a=c,o.pending=null}if(c=e.baseState,a===null)e.memoizedState=c;else{t=a.next;var i=l=null,r=null,u=t,m=!1;do{var p=u.lane&-536870913;if(p!==u.lane?(R&p)===p:(Gt&p)===p){var d=u.revertLane;if(d===0)r!==null&&(r=r.next={lane:0,revertLane:0,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),p===Jn&&(m=!0);else if((Gt&d)===d){u=u.next,d===Jn&&(m=!0);continue}else p={lane:0,revertLane:u.revertLane,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},r===null?(i=r=p,l=c):r=r.next=p,C.lanes|=d,Nn|=d;p=u.action,Wn&&n(c,p),c=u.hasEagerState?u.eagerState:n(c,p)}else d={lane:p,revertLane:u.revertLane,gesture:u.gesture,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},r===null?(i=r=d,l=c):r=r.next=d,C.lanes|=p,Nn|=p;u=u.next}while(u!==null&&u!==t);if(r===null?l=c:r.next=i,!Je(c,e.memoizedState)&&(re=!0,m&&(n=Mo,n!==null)))throw n;e.memoizedState=c,e.baseState=l,e.baseQueue=r,o.lastRenderedState=c}return a===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function Ki(e){var t=ce(),n=t.queue;if(n===null)throw Error(h(311));n.lastRenderedReducer=e;var o=n.dispatch,a=n.pending,c=t.memoizedState;if(a!==null){n.pending=null;var l=a=a.next;do c=e(c,l.action),l=l.next;while(l!==a);Je(c,t.memoizedState)||(re=!0),t.memoizedState=c,t.baseQueue===null&&(t.baseState=c),n.lastRenderedState=c}return[c,o]}function vm(e,t,n){var o=C,a=ce(),c=A;if(c){if(n===void 0)throw Error(h(407));n=n()}else n=t();var l=!Je((X||a).memoizedState,n);if(l&&(a.memoizedState=n,re=!0),a=a.queue,Ku(Sm.bind(null,o,a,e),[e]),e=a.getSnapshot!==t||l||le!==null&&(le.memoizedState.tag&1)!==0,Go(e?9:8,{destroy:void 0},ym.bind(null,o,a,n,t),null),e){if(o.flags|=2048,K===null)throw Error(h(349));c||(Gt&127)!==0||hm(o,t,n)}return n}function hm(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=C.updateQueue,t===null?(t=Fl(),C.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function ym(e,t,n,o){t.value=n,t.getSnapshot=o,xm(t)&&km(e)}function Sm(e,t,n){return n(function(){xm(t)&&km(e)})}function xm(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Je(e,n)}catch{return!0}}function km(e){var t=no(e,2);t!==null&&Be(t,e,2)}function Ur(e){var t=Ae();if(typeof e=="function"){var n=e;if(e=n(),Wn){ln(!0);try{n()}finally{ln(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:jt,lastRenderedState:e},t}function wm(e,t,n,o){return e.baseState=n,Zu(e,X,typeof o=="function"?o:jt)}function Kh(e,t,n,o,a){if(Il(e))throw Error(h(485));if(e=t.action,e!==null){var c={payload:a,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(l){c.listeners.push(l)}};N.T!==null?n(!0):c.isTransition=!1,o(c),n=t.pending,n===null?(c.next=t.pending=c,Tm(t,c)):(c.next=n.next,t.pending=n.next=c)}}function Tm(e,t){var n=t.action,o=t.payload,a=e.state;if(t.isTransition){var c=N.T,l={};l.types=c!==null?c.types:null,N.T=l;try{var i=n(a,o),r=N.S;r!==null&&r(l,i),fs(e,t,i)}catch(u){Br(e,t,u)}finally{c!==null&&l.types!==null&&(c.types=l.types),N.T=c}}else try{c=n(a,o),fs(e,t,c)}catch(u){Br(e,t,u)}}function fs(e,t,n){n!==null&&typeof n=="object"&&typeof n.then=="function"?n.then(function(o){ss(e,t,o)},function(o){return Br(e,t,o)}):ss(e,t,n)}function ss(e,t,n){t.status="fulfilled",t.value=n,Em(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Tm(e,n)))}function Br(e,t,n){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do t.status="rejected",t.reason=n,Em(t),t=t.next;while(t!==o)}e.action=null}function Em(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function zm(e,t){return t}function bs(e,t){if(A){var n=K.formState;if(n!==null){e:{var o=C;if(A){if($){t:{for(var a=$,c=ot;a.nodeType!==8;){if(!c){a=null;break t}if(a=at(a.nextSibling),a===null){a=null;break t}}c=a.data,a=c==="F!"||c==="F"?a:null}if(a){$=at(a.nextSibling),o=a.data==="F!";break e}}Tn(o)}o=!1}o&&(t=n[0])}}return n=Ae(),n.memoizedState=n.baseState=t,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:zm,lastRenderedState:t},n.queue=o,n=Gm.bind(null,C,o),o.dispatch=n,o=Ur(!1),c=$u.bind(null,C,!1,o.queue),o=Ae(),a={state:t,dispatch:null,action:e,pending:null},o.queue=a,n=Kh.bind(null,C,a,c,n),a.dispatch=n,o.memoizedState=e,[t,n,!1]}function ms(e){var t=ce();return Nm(t,X,e)}function Nm(e,t,n){if(t=Zu(e,t,zm)[0],e=Pc(jt)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var o=rc(t)}catch(l){throw l===ea?Jl:l}else o=t;t=ce();var a=t.queue,c=a.dispatch;return n!==t.memoizedState&&(C.flags|=2048,Go(9,{destroy:void 0},Jh.bind(null,a,n),null)),[o,c,e]}function Jh(e,t){e.action=t}function gs(e){var t=ce(),n=X;if(n!==null)return Nm(t,n,e);ce(),t=t.memoizedState,n=ce();var o=n.queue.dispatch;return n.memoizedState=e,[t,o,!1]}function Go(e,t,n,o){return e={tag:e,create:n,deps:o,inst:t,next:null},t=C.updateQueue,t===null&&(t=Fl(),C.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(o=n.next,n.next=e,e.next=o,t.lastEffect=e),e}function Om(){return ce().memoizedState}function el(e,t,n,o){var a=Ae();C.flags|=e,a.memoizedState=Go(1|t,{destroy:void 0},n,o===void 0?null:o)}function $l(e,t,n,o){var a=ce();o=o===void 0?null:o;var c=a.memoizedState.inst;X!==null&&o!==null&&Lu(o,X.memoizedState.deps)?a.memoizedState=Go(t,c,n,o):(C.flags|=e,a.memoizedState=Go(1|t,c,n,o))}function ps(e,t){el(8390656,8,e,t)}function Ku(e,t){$l(2048,8,e,t)}function Fh(e){C.flags|=4;var t=C.updateQueue;if(t===null)t=Fl(),C.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Cm(e){var t=ce().memoizedState;return Fh({ref:t,nextImpl:e}),function(){if((q&2)!==0)throw Error(h(440));return t.impl.apply(void 0,arguments)}}function Am(e,t){return $l(4,2,e,t)}function _m(e,t){return $l(4,4,e,t)}function Mm(e,t){if(typeof t=="function"){e=e();var n=t(e);return function(){typeof n=="function"?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Dm(e,t,n){n=n!=null?n.concat([e]):null,$l(4,4,Mm.bind(null,t,e),n)}function Ju(){}function Rm(e,t){var n=ce();t=t===void 0?null:t;var o=n.memoizedState;return t!==null&&Lu(t,o[1])?o[0]:(n.memoizedState=[e,t],e)}function Um(e,t){var n=ce();t=t===void 0?null:t;var o=n.memoizedState;if(t!==null&&Lu(t,o[1]))return o[0];if(o=e(),Wn){ln(!0);try{e()}finally{ln(!1)}}return n.memoizedState=[o,t],o}function Fu(e,t,n){return n===void 0||(Gt&1073741824)!==0&&(R&261930)===0?e.memoizedState=t:(e.memoizedState=n,e=Ng(),C.lanes|=e,Nn|=e,n)}function Bm(e,t,n,o){return Je(n,t)?n:En.current!==null?(e=Fu(e,n,o),Je(e,t)||(re=!0),e):(Gt&106)===0||(Gt&1073741824)!==0&&(R&261930)===0?(re=!0,e.memoizedState=n):(e=Ng(),C.lanes|=e,Nn|=e,t)}function Hm(e,t,n,o,a){var c=Y.p;Y.p=c!==0&&8>c?c:8;var l=N.T,i={};i.types=l!==null?l.types:null,N.T=i,$u(e,!1,t,n);try{var r=a(),u=N.S;if(u!==null&&u(i,r),r!==null&&typeof r=="object"&&typeof r.then=="function"){var m=Qh(r,o);Da(e,t,m,Ke(e))}else Da(e,t,o,Ke(e))}catch(p){Da(e,t,{then:function(){},status:"rejected",reason:p},Ke())}finally{Y.p=c,l!==null&&i.types!==null&&(l.types=i.types),N.T=l}}function Wh(){}function Hr(e,t,n,o){if(e.tag!==5)throw Error(h(476));var a=qm(e).queue;Hm(e,a,t,Ln,n===null?Wh:function(){return Ym(e),n(o)})}function qm(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:Ln,baseState:Ln,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:jt,lastRenderedState:Ln},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:jt,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function Ym(e){var t=qm(e);t.next===null&&(t=e.alternate.memoizedState),Da(e,t.next.queue,{},Ke())}function Wu(){return ye(Fo)}function Lm(){return ce().memoizedState}function Vm(){return ce().memoizedState}function $h(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=Ke();e=gn(n);var o=pn(t,e,n);o!==null&&(Be(o,t,n),Aa(o,t,n)),t={cache:Ru()},e.payload=t;return}t=t.return}}function Ih(e,t,n){var o=Ke();n={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},Il(e)?jm(t,n):(n=_u(e,t,n,o),n!==null&&(Be(n,e,o),Qm(n,t,o)))}function Gm(e,t,n){var o=Ke();Da(e,t,n,o)}function Da(e,t,n,o){var a={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(Il(e))jm(t,a);else{var c=e.alternate;if(e.lanes===0&&(c===null||c.lanes===0)&&(c=t.lastRenderedReducer,c!==null))try{var l=t.lastRenderedState,i=c(l,n);if(a.hasEagerState=!0,a.eagerState=i,Je(i,l))return Zl(e,t,a,0),K===null&&Xl(),!1}catch{}if(n=_u(e,t,a,o),n!==null)return Be(n,e,o),Qm(n,t,o),!0}return!1}function $u(e,t,n,o){if(o={lane:2,revertLane:rd(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Il(e)){if(t)throw Error(h(479))}else t=_u(e,n,o,2),t!==null&&Be(t,e,2)}function Il(e){var t=e.alternate;return e===C||t!==null&&t===C}function jm(e,t){Ro=Tl=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function Qm(e,t,n){if((n&4194048)!==0){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Ob(e,n)}}var zl={readContext:ye,use:Wl,useCallback:oe,useContext:oe,useEffect:oe,useImperativeHandle:oe,useLayoutEffect:oe,useInsertionEffect:oe,useMemo:oe,useReducer:oe,useRef:oe,useState:oe,useDebugValue:oe,useDeferredValue:oe,useTransition:oe,useSyncExternalStore:oe,useId:oe,useHostTransitionStatus:oe,useFormState:oe,useActionState:oe,useOptimistic:oe,useMemoCache:oe,useCacheRefresh:oe,useEffectEvent:oe},Xm={readContext:ye,use:Wl,useCallback:function(e,t){return Ae().memoizedState=[e,t===void 0?null:t],e},useContext:ye,useEffect:ps,useImperativeHandle:function(e,t,n){n=n!=null?n.concat([e]):null,el(4194308,4,Mm.bind(null,t,e),n)},useLayoutEffect:function(e,t){return el(4194308,4,e,t)},useInsertionEffect:function(e,t){el(4,2,e,t)},useMemo:function(e,t){var n=Ae();t=t===void 0?null:t;var o=e();if(Wn){ln(!0);try{e()}finally{ln(!1)}}return n.memoizedState=[o,t],o},useReducer:function(e,t,n){var o=Ae();if(n!==void 0){var a=n(t);if(Wn){ln(!0);try{n(t)}finally{ln(!1)}}}else a=t;return o.memoizedState=o.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:a},o.queue=e,e=e.dispatch=Ih.bind(null,C,e),[o.memoizedState,e]},useRef:function(e){var t=Ae();return e={current:e},t.memoizedState=e},useState:function(e){e=Ur(e);var t=e.queue,n=Gm.bind(null,C,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:Ju,useDeferredValue:function(e,t){var n=Ae();return Fu(n,e,t)},useTransition:function(){var e=Ur(!1);return e=Hm.bind(null,C,e.queue,!0,!1),Ae().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var o=C,a=Ae();if(A){if(n===void 0)throw Error(h(407));n=n()}else{if(n=t(),K===null)throw Error(h(349));(R&127)!==0||hm(o,t,n)}a.memoizedState=n;var c={value:n,getSnapshot:t};return a.queue=c,ps(Sm.bind(null,o,c,e),[e]),o.flags|=2048,Go(9,{destroy:void 0},ym.bind(null,o,c,n,t),null),n},useId:function(){var e=Ae(),t=K.identifierPrefix;if(A){var n=Tt,o=wt;n=(o&~(1<<32-Ze(o)-1)).toString(32)+n,t="_"+t+"R_"+n,n=El++,0<n&&(t+="H"+n.toString(32)),t+="_"}else n=Xh++,t="_"+t+"r_"+n.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:Wu,useFormState:bs,useActionState:bs,useOptimistic:function(e){var t=Ae();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=$u.bind(null,C,!0,n),n.dispatch=t,[e,t]},useMemoCache:Xu,useCacheRefresh:function(){return Ae().memoizedState=$h.bind(null,C)},useEffectEvent:function(e){var t=Ae(),n={impl:e};return t.memoizedState=n,function(){if((q&2)!==0)throw Error(h(440));return n.impl.apply(void 0,arguments)}}},Zm={readContext:ye,use:Wl,useCallback:Rm,useContext:ye,useEffect:Ku,useImperativeHandle:Dm,useInsertionEffect:Am,useLayoutEffect:_m,useMemo:Um,useReducer:Pc,useRef:Om,useState:function(){return Pc(jt)},useDebugValue:Ju,useDeferredValue:function(e,t){var n=ce();return Bm(n,X.memoizedState,e,t)},useTransition:function(){var e=Pc(jt)[0],t=ce().memoizedState;return[typeof e=="boolean"?e:rc(e),t]},useSyncExternalStore:vm,useId:Lm,useHostTransitionStatus:Wu,useFormState:ms,useActionState:ms,useOptimistic:function(e,t){var n=ce();return wm(n,X,e,t)},useMemoCache:Xu,useCacheRefresh:Vm,useEffectEvent:Cm},Ph={readContext:ye,use:Wl,useCallback:Rm,useContext:ye,useEffect:Ku,useImperativeHandle:Dm,useInsertionEffect:Am,useLayoutEffect:_m,useMemo:Um,useReducer:Ki,useRef:Om,useState:function(){return Ki(jt)},useDebugValue:Ju,useDeferredValue:function(e,t){var n=ce();return X===null?Fu(n,e,t):Bm(n,X.memoizedState,e,t)},useTransition:function(){var e=Ki(jt)[0],t=ce().memoizedState;return[typeof e=="boolean"?e:rc(e),t]},useSyncExternalStore:vm,useId:Lm,useHostTransitionStatus:Wu,useFormState:gs,useActionState:gs,useOptimistic:function(e,t){var n=ce();return X!==null?wm(n,X,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:Xu,useCacheRefresh:Vm,useEffectEvent:Cm};function Ji(e,t,n,o){t=e.memoizedState,n=n(o,t),n=n==null?t:J({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var qr={enqueueSetState:function(e,t,n){e=e._reactInternals;var o=Ke(),a=gn(o);a.payload=t,n!=null&&(a.callback=n),t=pn(e,a,o),t!==null&&(Be(t,e,o),Aa(t,e,o))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var o=Ke(),a=gn(o);a.tag=1,a.payload=t,n!=null&&(a.callback=n),t=pn(e,a,o),t!==null&&(Be(t,e,o),Aa(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Ke(),o=gn(n);o.tag=2,t!=null&&(o.callback=t),t=pn(e,o,n),t!==null&&(Be(t,e,n),Aa(t,e,n))}};function vs(e,t,n,o,a,c,l){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,c,l):t.prototype&&t.prototype.isPureReactComponent?!Ga(n,o)||!Ga(a,c):!0}function hs(e,t,n,o){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,o),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,o),t.state!==e&&qr.enqueueReplaceState(t,t.state,null)}function $n(e,t){var n=t;if("ref"in t){n={};for(var o in t)o!=="ref"&&(n[o]=t[o])}if(e=e.defaultProps){n===t&&(n=J({},n));for(var a in e)n[a]===void 0&&(n[a]=e[a])}return n}function Km(e){pl(e)}function Jm(e){console.error(e)}function Fm(e){pl(e)}function Nl(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(o){setTimeout(function(){throw o})}}function ys(e,t,n){try{var o=e.onCaughtError;o(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(a){setTimeout(function(){throw a})}}function Yr(e,t,n){return n=gn(n),n.tag=3,n.payload={element:null},n.callback=function(){Nl(e,t)},n}function Wm(e){return e=gn(e),e.tag=3,e}function $m(e,t,n,o){var a=n.type.getDerivedStateFromError;if(typeof a=="function"){var c=o.value;e.payload=function(){return a(c)},e.callback=function(){ys(t,n,o)}}var l=n.stateNode;l!==null&&typeof l.componentDidCatch=="function"&&(e.callback=function(){ys(t,n,o),typeof a!="function"&&(yn===null?yn=new Set([this]):yn.add(this));var i=o.stack;this.componentDidCatch(o.value,{componentStack:i!==null?i:""})})}function e0(e,t,n,o,a){if(n.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(t=n.alternate,t!==null&&Zn(t,n,a,!0),n=we.current,n!==null){switch(n.tag){case 31:case 13:case 19:return ze===null?Ul():n.alternate===null&&ae===0&&(ae=3),n.flags&=-257,n.flags|=65536,n.lanes=a,o===xl?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([o]):t.add(o),tr(e,o,a)),!1;case 22:return n.flags|=65536,o===xl?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([o])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([o]):n.add(o)),tr(e,o,a)),!1}throw Error(h(435,n.tag))}return tr(e,o,a),Ul(),!1}if(A)return t=we.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=a,o!==Nr&&(e=Error(h(422),{cause:o}),Qa(nt(e,n)))):(o!==Nr&&(t=Error(h(423),{cause:o}),Qa(nt(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,o=nt(o,n),a=Yr(e.stateNode,o,a),Zi(e,a),ae!==4&&(ae=2)),!1;var c=Error(h(520),{cause:o});if(c=nt(c,n),Ha===null?Ha=[c]:Ha.push(c),ae!==4&&(ae=2),t===null)return!0;o=nt(o,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=Yr(n.stateNode,o,e),Zi(n,e),!1;case 1:if(t=n.type,c=n.stateNode,(n.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||c!==null&&typeof c.componentDidCatch=="function"&&(yn===null||!yn.has(c))))return n.flags|=65536,a&=-a,n.lanes|=a,a=Wm(a),$m(a,e,n,o),Zi(n,a),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var Iu=Error(h(461)),re=!1;function de(e,t,n,o){t.child=e===null?fm(t,null,n,o):Fn(t,e.child,n,o)}function Ss(e,t,n,o,a){n=n.render;var c=t.ref;if("ref"in o){var l={};for(var i in o)i!=="ref"&&(l[i]=o[i])}else l=o;return Kn(t),o=Vu(e,t,n,l,c,a),i=Gu(),e!==null&&!re?(ju(e,t,a),Qt(e,t,a)):(A&&i&&Kl(t),t.flags|=1,de(e,t,o,a),t.child)}function xs(e,t,n,o,a){if(e===null){var c=n.type;return typeof c=="function"&&!Mu(c)&&c.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=c,Im(e,t,c,o,a)):(e=Wc(n.type,null,o,t,t.mode,a),e.ref=t.ref,e.return=t,t.child=e)}if(c=e.child,!ed(e,a)){var l=c.memoizedProps;if(n=n.compare,n=n!==null?n:Ga,n(l,o)&&e.ref===t.ref)return Qt(e,t,a)}return t.flags|=1,e=qt(c,o),e.ref=t.ref,e.return=t,t.child=e}function Im(e,t,n,o,a){if(e!==null){var c=e.memoizedProps;if(Ga(c,o)&&e.ref===t.ref)if(re=!1,t.pendingProps=o=c,ed(e,a))(e.flags&131072)!==0&&(re=!0);else return t.lanes=e.lanes,Qt(e,t,a)}return Lr(e,t,n,o,a)}function Pm(e,t,n,o){var a=o.children,c=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((t.flags&128)!==0){if(c=c!==null?c.baseLanes|n:n,e!==null){for(o=t.child=e.child,a=0;o!==null;)a=a|o.lanes|o.childLanes,o=o.sibling;o=a&~c}else o=0,t.child=null;return ks(e,t,c,n,o)}if((n&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Ic(t,c!==null?c.cachePool:null),c!==null?ds(t,c):Dr(),mm(t);else return o=t.lanes=536870912,ks(e,t,c!==null?c.baseLanes|n:n,n,o)}else c!==null?(Ic(t,c.cachePool),ds(t,c),hn(),t.memoizedState=null):(e!==null&&Ic(t,null),Dr(),hn());return de(e,t,a,n),t.child}function Ra(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function ks(e,t,n,o,a){var c=Uu();return c=c===null?null:{parent:ie._currentValue,pool:c},t.memoizedState={baseLanes:n,cachePool:c},e!==null&&Ic(t,null),Dr(),mm(t),e!==null&&Zn(e,t,o,!0),t.childLanes=a,null}function tl(e,t){return t=Pl({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function ws(e,t,n){return Fn(t,e.child,null,n),e=tl(t,t.pendingProps),e.flags|=2,Ve(t),t.memoizedState=null,e}function t0(e,t,n){var o=t.pendingProps,a=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(A){if(o.mode==="hidden")return e=tl(t,o),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},Ra(null,e);if(Rr(t),(e=$)?(e=Pg(e,ot),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:wn!==null?{id:wt,overflow:Tt}:null,retryLane:536870912,hydrationErrors:null},n=am(e),n.return=t,t.child=n,pe=t,$=null)):e=null,e===null)throw Tn(t);return t.lanes=536870912,null}return tl(t,o)}var c=e.memoizedState;if(c!==null){var l=c.dehydrated;if(Rr(t),a)if(t.flags&256)t.flags&=-257,t=ws(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(h(558));else if(re||Zn(e,t,n,!1),a=(n&e.childLanes)!==0,re||a){if(En.current===null){if(o=K,o!==null&&(l=Cb(o,n),l!==0&&l!==c.retryLane))throw c.retryLane=l,no(e,l),Be(o,e,l),Iu;Ul()}t=ws(e,t,n)}else e=c.treeContext,$=at(l.nextSibling),pe=t,A=!0,mn=null,ot=!1,e!==null&&lm(t,e),t=tl(t,o),t.flags|=134221824;return t}return e=qt(e.child,{mode:o.mode,children:o.children}),e.ref=t.ref,t.child=e,e.return=t,e}function mo(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!="function"&&typeof n!="object")throw Error(h(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function Lr(e,t,n,o,a){return Kn(t),n=Vu(e,t,n,o,void 0,a),o=Gu(),e!==null&&!re?(ju(e,t,a),Qt(e,t,a)):(A&&o&&Kl(t),t.flags|=1,de(e,t,n,a),t.child)}function Ts(e,t,n,o,a,c){return Kn(t),t.updateQueue=null,n=pm(t,o,n,a),gm(e),o=Gu(),e!==null&&!re?(ju(e,t,c),Qt(e,t,c)):(A&&o&&Kl(t),t.flags|=1,de(e,t,n,c),t.child)}function Es(e,t,n,o,a){if(Kn(t),t.stateNode===null){var c=Eo,l=n.contextType;typeof l=="object"&&l!==null&&(c=ye(l)),c=new n(o,c),t.memoizedState=c.state!==null&&c.state!==void 0?c.state:null,c.updater=qr,t.stateNode=c,c._reactInternals=t,c=t.stateNode,c.props=o,c.state=t.memoizedState,c.refs={},Hu(t),l=n.contextType,c.context=typeof l=="object"&&l!==null?ye(l):Eo,c.state=t.memoizedState,l=n.getDerivedStateFromProps,typeof l=="function"&&(Ji(t,n,l,o),c.state=t.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof c.getSnapshotBeforeUpdate=="function"||typeof c.UNSAFE_componentWillMount!="function"&&typeof c.componentWillMount!="function"||(l=c.state,typeof c.componentWillMount=="function"&&c.componentWillMount(),typeof c.UNSAFE_componentWillMount=="function"&&c.UNSAFE_componentWillMount(),l!==c.state&&qr.enqueueReplaceState(c,c.state,null),Ma(t,o,c,a),_a(),c.state=t.memoizedState),typeof c.componentDidMount=="function"&&(t.flags|=4194308),o=!0}else if(e===null){c=t.stateNode;var i=t.memoizedProps,r=$n(n,i);c.props=r;var u=c.context,m=n.contextType;l=Eo,typeof m=="object"&&m!==null&&(l=ye(m));var p=n.getDerivedStateFromProps;m=typeof p=="function"||typeof c.getSnapshotBeforeUpdate=="function",i=t.pendingProps!==i,m||typeof c.UNSAFE_componentWillReceiveProps!="function"&&typeof c.componentWillReceiveProps!="function"||(i||u!==l)&&hs(t,c,o,l),an=!1;var d=t.memoizedState;c.state=d,Ma(t,o,c,a),_a(),u=t.memoizedState,i||d!==u||an?(typeof p=="function"&&(Ji(t,n,p,o),u=t.memoizedState),(r=an||vs(t,n,r,o,d,u,l))?(m||typeof c.UNSAFE_componentWillMount!="function"&&typeof c.componentWillMount!="function"||(typeof c.componentWillMount=="function"&&c.componentWillMount(),typeof c.UNSAFE_componentWillMount=="function"&&c.UNSAFE_componentWillMount()),typeof c.componentDidMount=="function"&&(t.flags|=4194308)):(typeof c.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=o,t.memoizedState=u),c.props=o,c.state=u,c.context=l,o=r):(typeof c.componentDidMount=="function"&&(t.flags|=4194308),o=!1)}else{c=t.stateNode,_r(e,t),l=t.memoizedProps,m=$n(n,l),c.props=m,p=t.pendingProps,d=c.context,u=n.contextType,r=Eo,typeof u=="object"&&u!==null&&(r=ye(u)),i=n.getDerivedStateFromProps,(u=typeof i=="function"||typeof c.getSnapshotBeforeUpdate=="function")||typeof c.UNSAFE_componentWillReceiveProps!="function"&&typeof c.componentWillReceiveProps!="function"||(l!==p||d!==r)&&hs(t,c,o,r),an=!1,d=t.memoizedState,c.state=d,Ma(t,o,c,a),_a();var s=t.memoizedState;l!==p||d!==s||an||e!==null&&e.dependencies!==null&&Sl(e.dependencies)?(typeof i=="function"&&(Ji(t,n,i,o),s=t.memoizedState),(m=an||vs(t,n,m,o,d,s,r)||e!==null&&e.dependencies!==null&&Sl(e.dependencies))?(u||typeof c.UNSAFE_componentWillUpdate!="function"&&typeof c.componentWillUpdate!="function"||(typeof c.componentWillUpdate=="function"&&c.componentWillUpdate(o,s,r),typeof c.UNSAFE_componentWillUpdate=="function"&&c.UNSAFE_componentWillUpdate(o,s,r)),typeof c.componentDidUpdate=="function"&&(t.flags|=4),typeof c.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof c.componentDidUpdate!="function"||l===e.memoizedProps&&d===e.memoizedState||(t.flags|=4),typeof c.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&d===e.memoizedState||(t.flags|=1024),t.memoizedProps=o,t.memoizedState=s),c.props=o,c.state=s,c.context=r,o=m):(typeof c.componentDidUpdate!="function"||l===e.memoizedProps&&d===e.memoizedState||(t.flags|=4),typeof c.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&d===e.memoizedState||(t.flags|=1024),o=!1)}return c=o,mo(e,t),o=(t.flags&128)!==0,c||o?(c=t.stateNode,n=o&&typeof n.getDerivedStateFromError!="function"?null:c.render(),t.flags|=1,e!==null&&o?(t.child=Fn(t,e.child,null,a),t.child=Fn(t,null,n,a)):de(e,t,n,a),t.memoizedState=c.state,e=t.child):e=Qt(e,t,a),e}function zs(e,t,n,o){return Xn(),t.flags|=256,de(e,t,n,o),t.child}var Vr={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Gr(e){return{baseLanes:e,cachePool:rm()}}function jr(e,t,n){return e=e!==null?e.childLanes&~n:0,t&&(e|=je),e}function eg(e,t,n){var o=t.pendingProps,a=!1,c=(t.flags&128)!==0,l;if((l=c)||(l=e!==null&&e.memoizedState===null?!1:(xe.current&2)!==0),l&&(a=!0,t.flags&=-129),l=(t.flags&32)!==0,t.flags&=-33,e===null){if(A){if(a?vn(t):hn(),(e=$)?(e=Pg(e,ot),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:wn!==null?{id:wt,overflow:Tt}:null,retryLane:536870912,hydrationErrors:null},n=am(e),n.return=t,t.child=n,pe=t,$=null)):e=null,e===null)throw Tn(t);return sd(e)?t.lanes=32:t.lanes=536870912,null}return c=o.children,o=o.fallback,a?(hn(),a=t.mode,c=Pl({mode:"hidden",children:c},a),o=Vn(o,a,n,null),c.return=t,o.return=t,c.sibling=o,t.child=c,o=t.child,o.memoizedState=Gr(n),o.childLanes=jr(e,l,n),t.memoizedState=Vr,Ra(null,o)):(vn(t),Pu(t,c))}var i=e.memoizedState;if(i!==null){var r=i.dehydrated;if(r!==null)return n0(e,t,c,l,o,r,i,n)}return a?(hn(),a=o.fallback,c=t.mode,i=e.child,r=i.sibling,o=qt(i,{mode:"hidden",children:o.children}),o.subtreeFlags=i.subtreeFlags&1206910976,r!==null?a=qt(r,a):(a=Vn(a,c,n,null),a.flags|=2),a.return=t,o.return=t,o.sibling=a,t.child=o,Ra(null,o),o=t.child,a=e.child.memoizedState,a===null?a=Gr(n):(c=a.cachePool,c!==null?(i=ie._currentValue,c=c.parent!==i?{parent:i,pool:i}:c):c=rm(),a={baseLanes:a.baseLanes|n,cachePool:c}),o.memoizedState=a,o.childLanes=jr(e,l,n),t.memoizedState=Vr,Ra(e.child,o)):(vn(t),n=e.child,e=n.sibling,n=qt(n,{mode:"visible",children:o.children}),n.return=t,n.sibling=null,e!==null&&(l=t.deletions,l===null?(t.deletions=[e],t.flags|=16):l.push(e)),t.child=n,t.memoizedState=null,n)}function Pu(e,t){return t=Pl({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function Pl(e,t){return e=Ue(22,e,null,t),e.lanes=0,e}function Bc(e,t,n){return Fn(t,e.child,null,n),e=Pu(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function n0(e,t,n,o,a,c,l,i){if(n)return t.flags&256?(vn(t),t.flags&=-257,Bc(e,t,i)):t.memoizedState!==null?(hn(),t.child=e.child,t.flags|=128,null):(hn(),c=a.fallback,l=t.mode,a=Pl({mode:"visible",children:a.children},l),c=Vn(c,l,i,null),c.flags|=2,a.return=t,c.return=t,a.sibling=c,t.child=a,Fn(t,e.child,null,i),a=t.child,a.memoizedState=Gr(i),a.childLanes=jr(e,o,i),t.memoizedState=Vr,Ra(null,a));if(vn(t),sd(c)){if(o=c.nextSibling&&c.nextSibling.dataset,o)var r=o.dgst;return o=r,o!==""&&(a=Error(h(419)),a.stack="",a.digest=o,Qa({value:a,source:null,stack:null})),Bc(e,t,i)}if(re||Zn(e,t,i,!1),o=(i&e.childLanes)!==0,re||o){if(En.current!==null)return Bc(e,t,i);if(o=K,o!==null&&(a=Cb(o,i),a!==0&&a!==l.retryLane))throw l.retryLane=a,no(e,a),Be(o,e,a),Iu;return mu(c)||Ul(),Bc(e,t,i)}return mu(c)?(t.flags|=192,t.child=e.child,null):(e=l.treeContext,$=at(c.nextSibling),pe=t,A=!0,mn=null,ot=!1,e!==null&&lm(t,e),t=Pu(t,a.children),t.flags|=134221824,t)}function Ns(e,t,n){e.lanes|=t;var o=e.alternate;o!==null&&(o.lanes|=t),$c(e.return,t,n)}function Os(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&wl(n)===null&&(t=e),e=e.sibling}return t}function Hc(e,t,n,o,a,c){var l=e.memoizedState;l===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:o,tail:n,tailMode:a,treeForkCount:c}:(l.isBackwards=t,l.rendering=null,l.renderingStartTime=0,l.last=o,l.tail=n,l.tailMode=a,l.treeForkCount=c)}function Fi(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function Qr(e,t,n){var o=t.pendingProps,a=o.revealOrder,c=o.tail;o=o.children;var l=xe.current;if(t.flags&128)return Za(t,l),null;var i=(l&2)!==0;if(i?(l=l&1|2,t.flags|=128):l&=1,Za(t,l),a==="backwards"&&e!==null?(Fi(e),de(e,t,o,n),Fi(e)):de(e,t,o,n),o=A?ja:0,!i&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Ns(e,n,t);else if(e.tag===19)Ns(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(a){case"backwards":n=Os(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null,Fi(t)),Hc(t,!0,a,null,c,o);break;case"unstable_legacy-backwards":for(n=null,a=t.child,t.child=null;a!==null;){if(e=a.alternate,e!==null&&wl(e)===null){t.child=a;break}e=a.sibling,a.sibling=n,n=a,a=e}Hc(t,!0,n,null,c,o);break;case"together":Hc(t,!1,null,null,void 0,o);break;case"independent":t.memoizedState=null;break;default:n=Os(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null),Hc(t,!1,a,n,c,o)}return t.child}function Cs(e,t,n){var o=t.pendingProps;return un(t,t.type,o.value),de(e,t,o.children,n),t.child}function Qt(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Nn|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(Zn(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(h(153));if(t.child!==null){for(e=t.child,n=qt(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=qt(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function ed(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&Sl(e)))}function o0(e,t,n){switch(t.tag){case 3:sl(t,t.stateNode.containerInfo),un(t,ie,e.memoizedState.cache),Xn();break;case 27:case 5:vr(t);break;case 4:sl(t,t.stateNode.containerInfo);break;case 10:un(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,Rr(t),null;break;case 13:var o=t.memoizedState;if(o!==null){if(o.dehydrated!==null)return vn(t),t.flags|=128,null;o=Zn(e,t,n,!1);var a=t.child.childLanes;return o||(n&a)!==0?eg(e,t,n):(vn(t),e=Qt(e,t,n),e!==null?e.sibling:null)}vn(t);break;case 19:if(t.flags&128)return Qr(e,t,n);if(a=(e.flags&128)!==0,o=(n&t.childLanes)!==0,o||(Zn(e,t,n,!1),o=(n&t.childLanes)!==0),a){if(o)return Qr(e,t,n);t.flags|=128}if(a=t.memoizedState,a!==null&&(a.rendering=null,a.tail=null,a.lastEffect=null),Za(t,xe.current),o)break;return null;case 22:return t.lanes=0,Pm(e,t,n,t.pendingProps);case 24:un(t,ie,e.memoizedState.cache)}return Qt(e,t,n)}function tg(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)re=!0;else{if(!ed(e,n)&&(t.flags&128)===0)return re=!1,o0(e,t,n);re=(e.flags&131072)!==0}else re=!1,A&&(t.flags&1048576)!==0&&cm(t,ja,t.index);switch(t.lanes=0,t.tag){case 16:e:{var o=t.pendingProps;if(e=Bn(t.elementType),t.type=e,typeof e=="function")Mu(e)?(o=$n(e,o),t.tag=1,t=Es(null,t,e,o,n)):(t.tag=0,t=Lr(null,t,e,o,n));else{if(e!=null){var a=e.$$typeof;if(a===yu){t.tag=11,t=Ss(null,t,e,o,n);break e}else if(a===Su){t.tag=14,t=xs(null,t,e,o,n);break e}else if(a===xt){t.tag=10,t.type=e,t=Cs(null,t,n);break e}}throw t=gr(e)||e,Error(h(306,t,""))}}return t;case 0:return Lr(e,t,t.type,t.pendingProps,n);case 1:return o=t.type,a=$n(o,t.pendingProps),Es(e,t,o,a,n);case 3:e:{if(sl(t,t.stateNode.containerInfo),e===null)throw Error(h(387));o=t.pendingProps;var c=t.memoizedState;a=c.element,_r(e,t),Ma(t,o,null,n);var l=t.memoizedState;if(o=l.cache,un(t,ie,o),o!==c.cache&&Cr(t,[ie],n,!0),_a(),o=l.element,c.isDehydrated)if(c={element:o,isDehydrated:!1,cache:l.cache},t.updateQueue.baseState=c,t.memoizedState=c,t.flags&256){t=zs(e,t,o,n);break e}else if(o!==a){a=nt(Error(h(424)),t),Qa(a),t=zs(e,t,o,n);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,$=at(e.firstChild),pe=t,A=!0,mn=null,ot=!0,n=fm(t,null,o,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling;else{if(Xn(),o===a){t=Qt(e,t,n);break e}de(e,t,o,n)}t=t.child}return t;case 26:return mo(e,t),e===null?(n=nb(t.type,null,t.pendingProps,null))?t.memoizedState=n:A||(t.stateNode=Qg(t.type,t.pendingProps,bn.current,t)):t.memoizedState=nb(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return vr(t),e===null&&A&&(o=t.stateNode=ep(t.type,t.pendingProps,bn.current),pe=t,ot=!0,a=$,Cn(t.type)?(gu=a,$=at(o.firstChild)):$=a),de(e,t,t.pendingProps.children,n),mo(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&A&&((a=o=$)&&(o=F0(o,t.type,t.pendingProps,ot),o!==null?(t.stateNode=o,pe=t,$=at(o.firstChild),ot=!1,a=!0):a=!1),a||Tn(t)),vr(t),a=t.type,c=t.pendingProps,l=e!==null?e.memoizedProps:null,o=c.children,fu(a,c)?o=null:l!==null&&fu(a,l)&&(t.flags|=32),t.memoizedState!==null&&(a=Vu(e,t,Zh,null,null,n),Fo._currentValue=a),mo(e,t),de(e,t,o,n),t.child;case 6:return e===null&&A&&((e=n=$)&&(n=W0(n,t.pendingProps,ot),n!==null?(t.stateNode=n,pe=t,$=null,e=!0):e=!1),e||Tn(t)),null;case 13:return eg(e,t,n);case 4:return sl(t,t.stateNode.containerInfo),o=t.pendingProps,e===null?t.child=Fn(t,null,o,n):de(e,t,o,n),t.child;case 11:return Ss(e,t,t.type,t.pendingProps,n);case 7:return o=t.pendingProps,mo(e,t),de(e,t,o,n),t.child;case 8:return de(e,t,t.pendingProps.children,n),t.child;case 12:return de(e,t,t.pendingProps.children,n),t.child;case 10:return Cs(e,t,n);case 9:return a=t.type._context,o=t.pendingProps.children,Kn(t),a=ye(a),o=o(a),t.flags|=1,de(e,t,o,n),t.child;case 14:return xs(e,t,t.type,t.pendingProps,n);case 15:return Im(e,t,t.type,t.pendingProps,n);case 19:return Qr(e,t,n);case 31:return t0(e,t,n);case 22:return Pm(e,t,n,t.pendingProps);case 24:return Kn(t),o=ye(ie),e===null?(a=Uu(),a===null&&(a=K,c=Ru(),a.pooledCache=c,c.refCount++,c!==null&&(a.pooledCacheLanes|=n),a=c),t.memoizedState={parent:o,cache:a},Hu(t),un(t,ie,a)):((e.lanes&n)!==0&&(_r(e,t),Ma(t,null,null,n),_a()),a=e.memoizedState,c=t.memoizedState,a.parent!==o?(a={parent:o,cache:o},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),un(t,ie,o)):(o=c.cache,un(t,ie,o),o!==a.cache&&Cr(t,[ie],n,!0))),de(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),o=t.pendingProps,o.name!=null&&o.name!=="auto"?t.flags|=e===null?18882560:18874368:A&&Kl(t),e!==null&&e.memoizedProps.name!==o.name?t.flags|=4194816:mo(e,t),de(e,t,o.children,n),t.child;case 29:throw t.pendingProps}throw Error(h(156,t.tag))}function Ut(e){e.flags|=4}function Wi(e,t,n,o,a){var c;if((c=(e.mode&32)!==0)&&(c=n===null?cb(t,o):cb(t,o)&&(o.src!==n.src||o.srcSet!==n.srcSet)),c){if(e.flags|=16777216,(a&335544128)===a)if(e.stateNode.complete)e.flags|=8192;else if(Ag())e.flags|=8192;else throw jn=xl,Bu}else e.flags&=-16777217}function As(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!ap(t))if(Ag())e.flags|=8192;else throw jn=xl,Bu}function qc(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?zb():536870912,e.lanes|=t,jo|=t)}function va(e,t){if(!A)switch(e.tailMode){case"visible":break;case"collapsed":for(var n=e.tail,o=null;n!==null;)n.alternate!==null&&(o=n),n=n.sibling;o===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function W(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,o=0;if(t)for(var a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags&1206910976,o|=a.flags&1206910976,a.return=e,a=a.sibling;else for(a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags,o|=a.flags,a.return=e,a=a.sibling;return e.subtreeFlags|=o,e.childLanes=n,t}function a0(e,t,n){var o=t.pendingProps;switch(Du(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return W(t),null;case 1:return W(t),null;case 3:return n=t.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),t.memoizedState.cache!==o&&(t.flags|=2048),Yt(ie),Yo(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(so(t)?Ut(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,Xi())),W(t),null;case 26:var a=t.type,c=t.memoizedState;return e===null?(Ut(t),c!==null?(W(t),As(t,c)):(W(t),Wi(t,a,null,o,n))):c?c!==e.memoizedState?(Ut(t),W(t),As(t,c)):(W(t),t.flags&=-16777217):(e=e.memoizedProps,e!==o&&Ut(t),W(t),Wi(t,a,e,o,n)),null;case 27:if(bl(t),n=bn.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&Ut(t);else{if(!o){if(t.stateNode===null)throw Error(h(166));return W(t),t.subtreeFlags&=-33554433,null}e=Et.current,so(t)?os(t,e):(e=ep(a,o,n),t.stateNode=e,Ut(t))}return W(t),t.subtreeFlags&=-33554433,null;case 5:if(bl(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&Ut(t);else{if(!o){if(t.stateNode===null)throw Error(h(166));return W(t),t.subtreeFlags&=-33554433,null}if(c=Et.current,so(t))os(t,c);else{var l=Wa(bn.current);switch(c){case 1:c=l.createElementNS("http://www.w3.org/2000/svg",a);break;case 2:c=l.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;default:switch(a){case"svg":c=l.createElementNS("http://www.w3.org/2000/svg",a);break;case"math":c=l.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;case"script":c=l.createElement("div"),c.innerHTML="<script><\/script>",c=c.removeChild(c.firstChild);break;case"select":c=typeof o.is=="string"?l.createElement("select",{is:o.is}):l.createElement("select"),o.multiple?c.multiple=!0:o.size&&(c.size=o.size);break;default:c=typeof o.is=="string"?l.createElement(a,{is:o.is}):l.createElement(a)}}c[he]=t,c[qe]=o;e:for(l=t.child;l!==null;){if(l.tag===5||l.tag===6)c.appendChild(l.stateNode);else if(l.tag!==4&&l.tag!==27&&l.child!==null){l.child.return=l,l=l.child;continue}if(l===t)break e;for(;l.sibling===null;){if(l.return===null||l.return===t)break e;l=l.return}l.sibling.return=l.return,l=l.sibling}t.stateNode=c;e:switch(ke(c,a,o),a){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&Ut(t)}}return W(t),t.subtreeFlags&=-33554433,Wi(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==o&&Ut(t);else{if(typeof o!="string"&&t.stateNode===null)throw Error(h(166));if(e=bn.current,so(t)){if(e=t.stateNode,n=t.memoizedProps,o=null,a=pe,a!==null)switch(a.tag){case 27:case 5:o=a.memoizedProps}e[he]=t,e=!!(e.nodeValue===n||o!==null&&o.suppressHydrationWarning===!0||Gg(e.nodeValue,n)),e||Tn(t,!0)}else e=Wa(e).createTextNode(o),e[he]=t,t.stateNode=e}return W(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(o=so(t),n!==null){if(e===null){if(!o)throw Error(h(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(h(557));e[he]=t}else Xn(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;W(t),e=!1}else n=Xi(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(Ve(t),t):(Ve(t),null);if((t.flags&128)!==0)throw Error(h(558))}return W(t),null;case 13:if(o=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=so(t),o!==null&&o.dehydrated!==null){if(e===null){if(!a)throw Error(h(318));if(a=t.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(h(317));a[he]=t}else Xn(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;W(t),a=!1}else a=Xi(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(Ve(t),t):(Ve(t),null)}return Ve(t),(t.flags&128)!==0?(t.lanes=n,t):(n=o!==null,e=e!==null&&e.memoizedState!==null,n&&(o=t.child,a=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(a=o.alternate.memoizedState.cachePool.pool),c=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(c=o.memoizedState.cachePool.pool),c!==a&&(o.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),qc(t,t.updateQueue),W(t),null);case 4:return Yo(),e===null&&ud(t.stateNode.containerInfo),t.flags|=67108864,W(t),null;case 10:return Yt(t.type),W(t),null;case 19:if(Yu(t),o=t.memoizedState,o===null)return W(t),null;if(a=(t.flags&128)!==0,c=o.rendering,c===null)if(a)va(o,!1);else{if(ae!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(c=wl(e),c!==null){for(t.flags|=128,va(o,!1),e=c.updateQueue,t.updateQueue=e,qc(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)om(n,e),n=n.sibling;return Za(t,xe.current&1|2),A&&Bt(t,o.treeForkCount),t.child}e=e.sibling}o.tail!==null&&Qe()>Dl&&(t.flags|=128,a=!0,va(o,!1),t.lanes=4194304)}else{if(!a)if(e=wl(c),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,qc(t,e),va(o,!0),o.tail===null&&o.tailMode!=="collapsed"&&o.tailMode!=="visible"&&!c.alternate&&!A)return W(t),null}else 2*Qe()-o.renderingStartTime>Dl&&n!==536870912&&(t.flags|=128,a=!0,va(o,!1),t.lanes=4194304);o.isBackwards?(c.sibling=t.child,t.child=c):(e=o.last,e!==null?e.sibling=c:t.child=c,o.last=c)}if(o.tail!==null){e=o.tail;e:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break e}n=n.sibling}n=!0}return o.rendering=e,o.tail=e.sibling,o.renderingStartTime=Qe(),e.sibling=null,c=xe.current,c=a?c&1|2:c&1,o.tailMode==="visible"||o.tailMode==="collapsed"||!n||A?Za(t,c):(n=c,I(we,t),I(xe,n),ze===null&&(ze=t)),A&&Bt(t,o.treeForkCount),e}return W(t),null;case 22:case 23:return Ve(t),qu(),o=t.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(t.flags|=8192):o&&(t.flags|=8192),o?(n&536870912)!==0&&(t.flags&128)===0&&(W(t),t.subtreeFlags&6&&(t.flags|=8192)):W(t),n=t.updateQueue,n!==null&&qc(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),o=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),o!==n&&(t.flags|=2048),e!==null&&Se(Gn),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),Yt(ie),W(t),null;case 25:return null;case 30:return t.flags|=33554432,W(t),null}throw Error(h(156,t.tag))}function c0(e,t){switch(Du(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return Yt(ie),Yo(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return bl(t),null;case 31:if(t.memoizedState!==null){if(Ve(t),t.alternate===null)throw Error(h(340));Xn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(Ve(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(h(340));Xn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return Yu(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return Yo(),null;case 10:return Yt(t.type),null;case 22:case 23:return Ve(t),qu(),e!==null&&Se(Gn),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return Yt(ie),null;case 25:return null;default:return null}}function ng(e,t){switch(Du(t),t.tag){case 3:Yt(ie),Yo();break;case 26:case 27:case 5:bl(t);break;case 4:Yo();break;case 31:t.memoizedState!==null&&Ve(t);break;case 13:Ve(t);break;case 19:Yu(t);break;case 10:Yt(t.type);break;case 22:case 23:Ve(t),qu(),e!==null&&Se(Gn);break;case 24:Yt(ie)}}function uc(e,t){try{var n=t.updateQueue,o=n!==null?n.lastEffect:null;if(o!==null){var a=o.next;n=a;do{if((n.tag&e)===e){o=void 0;var c=n.create,l=n.inst;o=c(),l.destroy=o}n=n.next}while(n!==a)}}catch(i){Q(t,t.return,i)}}function zn(e,t,n){try{var o=t.updateQueue,a=o!==null?o.lastEffect:null;if(a!==null){var c=a.next;o=c;do{if((o.tag&e)===e){var l=o.inst,i=l.destroy;if(i!==void 0){l.destroy=void 0,a=t;var r=n,u=i;try{u()}catch(m){Q(a,r,m)}}}o=o.next}while(o!==c)}}catch(m){Q(t,t.return,m)}}function og(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{bm(t,n)}catch(o){Q(e,e.return,o)}}}function ag(e,t,n){n.props=$n(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(o){Q(e,t,o)}}function yt(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:var a=e.stateNode,c=Vt(e.memoizedProps,a);(a.ref===null||a.ref.name!==c)&&(a.ref=Jg(c)),o=a.ref;break;case 7:if(e.stateNode===null){var l=new Fe(e);He(e.child,!1,K0,l,void 0,void 0),e.stateNode=l}o=e.stateNode;break;default:o=e.stateNode}typeof n=="function"?e.refCleanup=n(o):n.current=o}}catch(i){Q(e,t,i)}}function ve(e,t){var n=e.ref,o=e.refCleanup;if(n!==null)if(typeof o=="function")try{o()}catch(a){Q(e,t,a)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n=="function")try{n(null)}catch(a){Q(e,t,a)}else n.current=null}function Ol(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)Ig(e.stateNode,t[n])}function _s(e){for(var t=e.return;t!==null&&(nd(t)&&Ig(e.stateNode,t.stateNode),!td(t));)t=t.return}function Ua(e){for(var t=e.return;t!==null&&(nd(t)&&J0(e.stateNode,t.stateNode),!td(t));)t=t.return}function td(e){return e.tag===5||e.tag===3||e.tag===27}function nd(e){return e&&e.tag===7&&e.stateNode!==null}function Xr(e){var t=e.type,n=e.memoizedProps,o=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&o.focus();break e;case"img":n.src?o.src=n.src:n.srcSet&&(o.srcset=n.srcSet)}}catch(a){Q(e,e.return,a)}}function $i(e,t,n){try{var o=e.stateNode;C0(o,e.type,n,t),o[qe]=t}catch(a){Q(e,e.return,a)}}function cg(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Cn(e.type)||e.tag===4}function Ii(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||cg(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Cn(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Zr(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n).insertBefore(a,t):(t=n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.appendChild(a),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=kt)),Ol(e,o),H=!0;else if(a!==4&&(a===27&&(Ol(e,o),o=null,Cn(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(Zr(e,t,n,o),e=e.sibling;e!==null;)Zr(e,t,n,o),e=e.sibling}function Cl(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?n.insertBefore(a,t):n.appendChild(a),Ol(e,o),H=!0;else if(a!==4&&(a===27&&(Ol(e,o),o=null,Cn(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(Cl(e,t,n,o),e=e.sibling;e!==null;)Cl(e,t,n,o),e=e.sibling}function lg(e){var t=e.stateNode,n=e.memoizedProps;try{for(var o=e.type,a=t.attributes;a.length;)t.removeAttributeNode(a[0]);ke(t,o,n),t[he]=e,t[qe]=n}catch(c){Q(e,e.return,c)}}var Al=!1,Ge=null;function Ms(e){(e.tag===30||(e.subtreeFlags&33554432)!==0)&&(Al=!0)}var St=null;function Ds(){var e=St;return St=null,e}var Re=0;function ta(e,t,n,o,a){return Re=0,ig(e.child,t,n,o,a)}function ig(e,t,n,o,a){for(var c=!1;e!==null;){if(e.tag===5){var l=e.stateNode;if(o!==null){var i=su(l);o.push(i),i.view&&(c=!0)}else c||su(l).view&&(c=!0);Al=!0,Xg(l,Re===0?t:t+"_"+Re,n),Re++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&a||ig(e.child,t,n,o,a)&&(c=!0));e=e.sibling}return c}function Nt(e,t){for(;e!==null;)e.tag===5?Zg(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||Nt(e.child,t)),e=e.sibling}function nl(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(nl(e),e.tag===30&&(e.flags&18874368)!==0&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name==="auto")throw Error(h(544));var n=t.name;t=Kt(t.default,t.share),t!=="none"&&(ta(e,n,t,null,!1)||Nt(e.child,!1))}e=e.sibling}}function Kr(e,t){if(e.tag===30){var n=e.stateNode,o=e.memoizedProps,a=Vt(o,n),c=Kt(o.default,n.paired?o.share:o.enter);c!=="none"?ta(e,a,c,null,!1)?(nl(e),n.paired||t||Qo(e,o.onEnter)):Nt(e.child,!1):nl(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Kr(e,t),e=e.sibling;else nl(e)}function Jr(e){if(Ge!==null&&Ge.size!==0){var t=Ge;if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var n=e.memoizedProps,o=n.name;if(o!=null&&o!=="auto"){var a=t.get(o);if(a!==void 0){var c=Kt(n.default,n.share);if(c!=="none"&&(ta(e,o,c,null,!1)?(c=e.stateNode,a.paired=c,c.paired=a,Qo(e,n.onShare)):Nt(e.child,!1)),t.delete(o),t.size===0)break}}}Jr(e)}e=e.sibling}}}function Fr(e){if(e.tag===30){var t=e.memoizedProps,n=Vt(t,e.stateNode),o=Ge!==null?Ge.get(n):void 0,a=Kt(t.default,o!==void 0?t.share:t.exit);a!=="none"&&(ta(e,n,a,null,!1)?o!==void 0?(a=e.stateNode,o.paired=a,a.paired=o,Ge.delete(n),Qo(e,t.onShare)):Qo(e,t.onExit):Nt(e.child,!1)),Ge!==null&&Jr(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Fr(e),e=e.sibling;else Ge!==null&&Jr(e)}function rg(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=Vt(t,e.stateNode);t=Kt(t.default,t.update),e.flags&=-5,t!=="none"&&ta(e,n,t,e.memoizedState=[],!1)}else(e.subtreeFlags&33554432)!==0&&rg(e);e=e.sibling}}function Wr(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var t=e.stateNode;t.paired!==null&&(t.paired=null,Nt(e.child,!1))}Wr(e)}e=e.sibling}}function ol(e){if(e.tag===30)e.stateNode.paired=null,Nt(e.child,!1),Wr(e);else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)ol(e),e=e.sibling;else Wr(e)}function ug(e){for(e=e.child;e!==null;)e.tag===30?Nt(e.child,!1):(e.subtreeFlags&33554432)!==0&&ug(e),e=e.sibling}function od(e,t,n,o,a,c,l){for(var i=!1;t!==null;){if(t.tag===5){var r=t.stateNode;if(c!==null&&Re<c.length){var u=c[Re],m=su(r);(u.view||m.view)&&(i=!0);var p;if(p=(e.flags&4)===0)if(m.clip)p=!0;else{p=u.rect;var d=m.rect;p=p.y!==d.y||p.x!==d.x||p.height!==d.height||p.width!==d.width}p&&(e.flags|=4),m.abs?m=!u.abs:(u=u.rect,m=m.rect,m=u.height!==m.height||u.width!==m.width),m&&(e.flags|=32)}else e.flags|=32;(e.flags&4)!==0&&Xg(r,Re===0?n:n+"_"+Re,a),i&&(e.flags&4)!==0||(St===null&&(St=[]),St.push(r,Re===0?o:o+"_"+Re,t.memoizedProps)),Re++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&l?e.flags|=t.flags&32:od(e,t.child,n,o,a,c,l)&&(i=!0));t=t.sibling}return i}function dg(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,o=e.stateNode,a=Vt(n,o),c=Kt(n.default,n.update);if(t){o=o.clones;var l=o===null?null:o.map(U0)}else l=e.memoizedState,e.memoizedState=null;o=e;var i=e.child;Re=0,a=od(o,i,a,a,c,l,!1),(e.flags&4)!==0&&a&&(t||Qo(e,n.onUpdate))}else(e.subtreeFlags&33554432)!==0&&dg(e,t);e=e.sibling}}var be=!1,V=!1,pt=!1,Pi=!1,Rs=typeof WeakSet=="function"?WeakSet:Set,me=null,vt=!1,Ea=!1,_l=!1,$r=!1;function l0(e,t,n){if(e=e.containerInfo,uu=Wo,e=Fb(e),Cu(e)){if("selectionStart"in e)var o={start:e.selectionStart,end:e.selectionEnd};else e:{o=(o=e.ownerDocument)&&o.defaultView||window;var a=o.getSelection&&o.getSelection();if(a&&a.rangeCount!==0){o=a.anchorNode;var c=a.anchorOffset,l=a.focusNode;a=a.focusOffset;try{o.nodeType,l.nodeType}catch{o=null;break e}var i=0,r=-1,u=-1,m=0,p=0,d=e,s=null;t:for(;;){for(var y;d!==o||c!==0&&d.nodeType!==3||(r=i+c),d!==l||a!==0&&d.nodeType!==3||(u=i+a),d.nodeType===3&&(i+=d.nodeValue.length),(y=d.firstChild)!==null;)s=d,d=y;for(;;){if(d===e)break t;if(s===o&&++m===c&&(r=i),s===l&&++p===a&&(u=i),(y=d.nextSibling)!==null)break;d=s,s=d.parentNode}d=y}o=r===-1||u===-1?null:{start:r,end:u}}else o=null}o=o||{start:0,end:0}}else o=null;for(du={focusedElem:e,selectionRange:o},Wo=!1,n=(n&335544064)===n,me=t,t=n?9270:1024;me!==null;){if(e=me,n&&(o=e.deletions,o!==null))for(c=0;c<o.length;c++)n&&Fr(o[c]);if(e.alternate===null&&(e.flags&2)!==0)n&&Ms(e),Yc(n);else{if(e.tag===22){if(o=e.alternate,e.memoizedState!==null){o!==null&&o.memoizedState===null&&n&&Fr(o),Yc(n);continue}else if(o!==null&&o.memoizedState!==null){n&&Ms(e),Yc(n);continue}}o=e.child,(e.subtreeFlags&t)!==0&&o!==null?(o.return=e,me=o):(n&&rg(e),Yc(n))}}Ge=null}function Yc(e){for(;me!==null;){var t=me,n=e,o=t.alternate,a=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if((a&1024)!==0&&o!==null){n=void 0,a=o.memoizedProps,o=o.memoizedState;var c=t.stateNode;try{var l=$n(t.type,a);n=c.getSnapshotBeforeUpdate(l,o),c.__reactInternalSnapshotBeforeUpdate=n}catch(i){Q(t,t.return,i)}}break;case 3:if((a&1024)!==0){if(o=t.stateNode.containerInfo,n=o.nodeType,n===9)bu(o);else if(n===1)switch(o.nodeName){case"HEAD":case"HTML":case"BODY":bu(o);break;default:o.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&o!==null&&(n=Vt(o.memoizedProps,o.stateNode),a=t.memoizedProps,a=Kt(a.default,a.update),a!=="none"&&ta(o,n,a,o.memoizedState=[],!0));break;default:if((a&1024)!==0)throw Error(h(163))}if(o=t.sibling,o!==null){o.return=t.return,me=o;break}me=t.return}}function fg(e,t,n){var o=n.flags;switch(n.tag){case 0:case 11:case 15:ht(e,n),o&4&&uc(5,n);break;case 1:if(ht(e,n),o&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(l){Q(n,n.return,l)}else{var a=$n(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(a,t,e.__reactInternalSnapshotBeforeUpdate)}catch(l){Q(n,n.return,l)}}o&64&&og(n),o&512&&yt(n,n.return);break;case 3:if(ht(e,n),o&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{bm(e,t)}catch(l){Q(n,n.return,l)}}break;case 27:t===null&&o&4&&lg(n);case 26:case 5:ht(e,n),t===null&&o&4&&Xr(n),o&512&&yt(n,n.return);break;case 12:ht(e,n);break;case 31:ht(e,n),o&4&&gg(e,n);break;case 13:ht(e,n),o&4&&pg(e,n),o&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=h0.bind(null,n),$0(e,n))));break;case 22:if(o=n.memoizedState!==null||be,!o){var c=t!==null&&t.memoizedState!==null||V;t=be,a=V,be=o,(V=c)&&!a?(o=2,(n.subtreeFlags&8772)!==0&&(o|=1),rt(e,n,o)):ht(e,n),be=t,V=a}break;case 30:ht(e,n),o&512&&yt(n,n.return);break;case 7:o&512&&yt(n,n.return);default:ht(e,n)}}function Ir(e,t){for(e=e.child;e!==null;)sg(e,t),e=e.sibling}function sg(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var o=n.style;typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"}else{var a=e.stateNode,c=e.memoizedProps.style,l=c!=null&&c.hasOwnProperty("display")?c.display:null;a.style.display=l==null||typeof l=="boolean"?"":(""+l).trim()}}catch(r){Q(e,e.return,r)}Pr(e,t);break;case 6:try{e.stateNode.nodeValue=t?"":e.memoizedProps,H=!0}catch(r){Q(e,e.return,r)}break;case 18:try{var i=e.stateNode;t?Ws(i,!0):Ws(e.stateNode,!1)}catch(r){Q(e,e.return,r)}break;case 22:case 23:e.memoizedState===null&&Ir(e,t);break;default:Ir(e,t)}}function Pr(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){e:{var n=e,o=t;switch(n.tag){case 4:sg(n,o);break e;case 22:n.memoizedState===null&&Pr(n,o);break e;default:Pr(n,o)}}e=e.sibling}}function bg(e){var t=e.alternate;t!==null&&(e.alternate=null,bg(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&Vl(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var ee=null,Me=!1;function it(e,t,n){for(n=n.child;n!==null;)mg(e,t,n),n=n.sibling}function mg(e,t,n){if(Xe&&typeof Xe.onCommitFiberUnmount=="function")try{Xe.onCommitFiberUnmount(nc,n)}catch{}switch(n.tag){case 26:V||ve(n,t),it(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!V&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:V||ve(n,t),Ua(n);var o=ee,a=Me;Cn(n.type)&&(ee=n.stateNode,Me=!1),it(e,t,n),tp(n.stateNode,n.type,n.memoizedProps),ee=o,Me=a;break;case 5:V||ve(n,t),Ua(n);case 6:if(n.tag===6&&Ua(n),o=ee,a=Me,ee=null,it(e,t,n),ee=o,Me=a,ee!==null)if(Me)try{(ee.nodeType===9?ee.body:ee.nodeName==="HTML"?ee.ownerDocument.body:ee).removeChild(n.stateNode),H=!0}catch(c){Q(n,t,c)}else try{ee.removeChild(n.stateNode),H=!0}catch(c){Q(n,t,c)}break;case 18:ee!==null&&(Me?(e=ee,Fs(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,n.stateNode),$o(e)):Fs(ee,n.stateNode));break;case 4:o=ee,a=Me,ee=n.stateNode.containerInfo,Me=!0,it(e,t,n),ee=o,Me=a;break;case 0:case 11:case 14:case 15:zn(2,n,t),V||zn(4,n,t),it(e,t,n);break;case 1:V||(ve(n,t),o=n.stateNode,typeof o.componentWillUnmount=="function"&&ag(n,t,o)),it(e,t,n);break;case 21:it(e,t,n);break;case 22:V=(o=V)||n.memoizedState!==null,it(e,t,n),V=o;break;case 30:ve(n,t),it(e,t,n);break;case 7:V||ve(n,t),it(e,t,n);break;default:it(e,t,n)}}function gg(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{$o(e)}catch(n){Q(t,t.return,n)}}}function pg(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{$o(e)}catch(n){Q(t,t.return,n)}}function i0(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Rs),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Rs),t;default:throw Error(h(435,e.tag))}}function Lc(e,t){var n=i0(e);t.forEach(function(o){if(!n.has(o)){n.add(o);var a=y0.bind(null,e,o);o.then(a,a)}})}function Oe(e,t,n){var o=t.deletions;if(o!==null)for(var a=0;a<o.length;a++){var c=o[a],l=e,i=t,r=i;e:for(;r!==null;){switch(r.tag){case 27:if(Cn(r.type)){ee=r.stateNode,Me=!1;break e}break;case 5:ee=r.stateNode,Me=!1;break e;case 3:case 4:ee=r.stateNode.containerInfo,Me=!0;break e}r=r.return}if(ee===null)throw Error(h(160));mg(l,i,c),ee=null,Me=!1,l=c.alternate,l!==null&&(l.return=null),c.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)vg(t,e,n),t=t.sibling}var ut=null;function vg(e,t,n){var o=e.alternate,a=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(a&4&&(o=e.updateQueue,o=o!==null?o.events:null,o!==null))for(var c=0;c<o.length;c++){var l=o[c];l.ref.impl=l.nextImpl}Oe(t,e,n),Ce(e),a&4&&(zn(3,e,e.return),uc(3,e),zn(5,e,e.return));break;case 1:Oe(t,e,n),Ce(e),a&512&&(V||o===null||ve(o,o.return)),a&64&&be&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(c=ut,Oe(t,e,n),Ce(e),a&512&&(V||o===null||ve(o,o.return)),a&4)if(a=o!==null?o.memoizedState:null,n=e.memoizedState,o===null)if(n===null)if(e.stateNode===null)if(be)e.stateNode=Qg(e.type,e.memoizedProps,t.containerInfo,e);else{e:{t=e.type,n=e.memoizedProps,a=c.ownerDocument||c;t:switch(t){case"title":o=a.getElementsByTagName("title")[0],(!o||o[cc]||o[he]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=a.createElement(t),a.head.insertBefore(o,a.querySelector("head > title"))),ke(o,t,n),o[he]=e,ge(o),t=o;break e;case"link":if(c=ab("link","href",a).get(t+(n.href||""))){for(l=0;l<c.length;l++)if(o=c[l],o.getAttribute("href")===(n.href==null||n.href===""?null:n.href)&&o.getAttribute("rel")===(n.rel==null?null:n.rel)&&o.getAttribute("title")===(n.title==null?null:n.title)&&o.getAttribute("crossorigin")===(n.crossOrigin==null?null:n.crossOrigin)){c.splice(l,1);break t}}o=a.createElement(t),ke(o,t,n),a.head.appendChild(o);break;case"meta":if(c=ab("meta","content",a).get(t+(n.content||""))){for(l=0;l<c.length;l++)if(o=c[l],o.getAttribute("content")===(n.content==null?null:""+n.content)&&o.getAttribute("name")===(n.name==null?null:n.name)&&o.getAttribute("property")===(n.property==null?null:n.property)&&o.getAttribute("http-equiv")===(n.httpEquiv==null?null:n.httpEquiv)&&o.getAttribute("charset")===(n.charSet==null?null:n.charSet)){c.splice(l,1);break t}}o=a.createElement(t),ke(o,t,n),a.head.appendChild(o);break;default:throw Error(h(468,t))}o[he]=e,ge(o),t=o}e.stateNode=t}else be||pu(c,e.type,e.stateNode);else e.stateNode=ob(c,n,e.memoizedProps);else a!==n?(a===null?(t=o.stateNode,t===null||V||t.parentNode.removeChild(t)):a.count--,n===null?be||pu(c,e.type,e.stateNode):ob(c,n,e.memoizedProps)):n===null&&e.stateNode!==null&&$i(e,e.memoizedProps,o.memoizedProps);break;case 27:Oe(t,e,n),Ce(e),a&512&&(V||o===null||ve(o,o.return)),o!==null&&a&4&&$i(e,e.memoizedProps,o.memoizedProps);break;case 5:if(c=pt,pt=!1,Oe(t,e,n),pt=c,Ce(e),a&512&&(V||o===null||ve(o,o.return)),e.flags&32){t=e.stateNode;try{Vo(t,""),H=!0}catch(m){Q(e,e.return,m)}}a&4&&e.stateNode!=null&&(t=e.memoizedProps,$i(e,t,o!==null?o.memoizedProps:t)),a&1024&&(Pi=!0);break;case 6:if(Oe(t,e,n),Ce(e),a&4){if(e.stateNode===null)throw Error(h(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,H=!0}catch(m){Q(e,e.return,m)}}break;case 3:if(H=!1,il=null,c=ut,ut=$a(t.containerInfo),Oe(t,e,n),ut=c,Ce(e),a&4&&o!==null&&o.memoizedState.isDehydrated)try{$o(t.containerInfo)}catch(m){Q(e,e.return,m)}Pi&&(Pi=!1,hg(e)),H=!1;break;case 4:a=pt,pt=be,o=Lf(),c=ut,ut=$a(e.stateNode.containerInfo),Oe(t,e,n),Ce(e),ut=c,H&&Ea&&(_l=!0),H=o,pt=a;break;case 12:Oe(t,e,n),Ce(e);break;case 31:Oe(t,e,n),Ce(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Lc(e,t)));break;case 13:Oe(t,e,n),Ce(e),e.child.flags&8192&&e.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(ei=Qe()),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Lc(e,t)));break;case 22:c=e.memoizedState!==null,l=o!==null&&o.memoizedState!==null;var i=be,r=V,u=pt;be=i||c,pt=u||c,V=r||l,Oe(t,e,n),V=r,pt=u,be=i,Ce(e),a&8192&&(t=e.stateNode,t._visibility=c?t._visibility&-2:t._visibility|1,!c||o===null||l||be||V||(t=l||V,n=be,o=V,be=c||be,V=t,nn(e,2),be=n,V=o),!c&&pt||Ir(e,c)),a&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,Lc(e,n))));break;case 19:Oe(t,e,n),Ce(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Lc(e,t)));break;case 30:a&512&&(V||o===null||ve(o,o.return)),a=Lf(),c=Ea,l=(n&335544064)===n,i=e.memoizedProps,Ea=l&&Kt(i.default,i.update)!=="none",Oe(t,e,n),Ce(e),l&&o!==null&&H&&(e.flags|=4),Ea=c,H=a;break;case 21:break;case 7:a&512&&(V||o===null||ve(o,o.return)),o&&o.stateNode!==null&&(o.stateNode._fragmentFiber=e);default:Oe(t,e,n),Ce(e)}}function Ce(e){var t=e.flags;if(t&2){try{for(var n,o=e.return;o!==null;){if(cg(o)){n=o;break}o=o.return}o=null;for(var a=e.return;a!==null;){if(nd(a)){var c=a.stateNode;o===null?o=[c]:o.push(c)}if(td(a))break;a=a.return}var l=o;if(n==null)throw Error(h(160));switch(n.tag){case 27:var i=n.stateNode,r=Ii(e);Cl(e,r,i,l);break;case 5:var u=n.stateNode;n.flags&32&&(Vo(u,""),n.flags&=-33);var m=Ii(e);Cl(e,m,u,l);break;case 3:case 4:var p=n.stateNode.containerInfo,d=Ii(e);Zr(e,d,p,l);break;default:throw Error(h(161))}}catch(s){Q(e,e.return,s)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function hg(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;hg(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,Wo=!0,t.reset(),Wo=!1),e=e.sibling}}function bo(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)yg(t,e),t=t.sibling;else dg(t,!1)}function yg(e,t){var n=e.alternate;if(n===null)Kr(e,!1);else switch(e.tag){case 3:if($r=vt=!1,Ds(),bo(t,e),!vt&&!_l){if(e=St,e!==null)for(var o=0;o<e.length;o+=3){n=e[o];var a=e[o+1];Zg(n,e[o+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+a+")"})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===""&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),$r=!0}St=null;break;case 5:bo(t,e);break;case 4:o=vt,vt=!1,bo(t,e),vt&&(_l=!0),vt=o;break;case 22:e.memoizedState===null&&(n.memoizedState!==null?Kr(e,!1):bo(t,e));break;case 30:o=vt,a=Ds(),vt=!1,bo(t,e),vt&&(e.flags|=4);var c=e.memoizedProps,l=e.stateNode;t=Vt(c,l),l=Vt(n.memoizedProps,l);var i=Kt(c.default,c.update);i==="none"?t=!1:(c=n.memoizedState,n.memoizedState=null,n=e.child,Re=0,t=od(e,n,t,l,i,c,!0),Re!==(c===null?0:c.length)&&(e.flags|=32)),(e.flags&4)!==0&&t?(Qo(e,e.memoizedProps.onUpdate),St=a):a!==null&&(a.push.apply(a,St),St=a),vt=(e.flags&32)!==0?!0:o;break;default:bo(t,e)}}function ht(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)fg(e,t.alternate,t),t=t.sibling}function nn(e,t){for(e=e.child;e!==null;){var n=e,o=t;switch(n.tag){case 0:case 11:case 14:case 15:zn(4,n,n.return),nn(n,o);break;case 1:ve(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&ag(n,n.return,a),nn(n,o);break;case 27:(o&2)!==0&&tp(n.stateNode,n.type,n.memoizedProps);case 5:ve(n,n.return),n.tag!==5&&n.tag!==27||Ua(n),nn(n,o);break;case 6:Ua(n);break;case 26:ve(n,n.return),a=n.stateNode,n.memoizedState!==null||a===null||V||a.parentNode.removeChild(a),nn(n,o);break;case 22:n.memoizedState===null&&nn(n,o);break;case 30:ve(n,n.return),nn(n,o);break;case 7:ve(n,n.return);default:nn(n,o)}e=e.sibling}}function rt(e,t,n){for(n=(t.subtreeFlags&8772)!==0?n:n&-2,t=t.child;t!==null;){var o=t.alternate,a=e,c=t,l=c.flags,i=(n&1)!==0;switch(c.tag){case 0:case 11:case 15:rt(a,c,n),uc(4,c);break;case 1:if(rt(a,c,n),o=c,a=o.stateNode,typeof a.componentDidMount=="function")try{a.componentDidMount()}catch(m){Q(o,o.return,m)}if(o=c,a=o.updateQueue,a!==null){var r=o.stateNode;try{var u=a.shared.hiddenCallbacks;if(u!==null)for(a.shared.hiddenCallbacks=null,a=0;a<u.length;a++)sm(u[a],r)}catch(m){Q(o,o.return,m)}}i&&l&64&&og(c),yt(c,c.return);break;case 27:(n&2)!==0&&lg(c);case 5:c.tag!==5&&c.tag!==27||_s(c),rt(a,c,n),i&&o===null&&l&4&&Xr(c),yt(c,c.return);break;case 6:_s(c);break;case 26:r=c.stateNode,c.memoizedState!==null||r===null||be||pu($a(r.ownerDocument),c.type,r),rt(a,c,n),i&&o===null&&l&4&&Xr(c),yt(c,c.return);break;case 12:rt(a,c,n);break;case 31:rt(a,c,n),i&&l&4&&gg(a,c);break;case 13:rt(a,c,n),i&&l&4&&pg(a,c);break;case 22:c.memoizedState===null&&rt(a,c,n),yt(c,c.return);break;case 30:rt(a,c,n),yt(c,c.return);break;case 7:yt(c,c.return);default:rt(a,c,n)}t=t.sibling}}function ad(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&ic(n))}function cd(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&ic(e))}function $e(e,t,n,o){var a=(n&335544064)===n;if(t.subtreeFlags&(a?10262:10256))for(t=t.child;t!==null;)Sg(e,t,n,o),t=t.sibling;else a&&ug(t)}function Sg(e,t,n,o){var a=(n&335544064)===n;a&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&ol(t);var c=t.flags;switch(t.tag){case 0:case 11:case 15:$e(e,t,n,o),c&2048&&uc(9,t);break;case 1:$e(e,t,n,o);break;case 3:$e(e,t,n,o),a&&$r&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,e.style.viewTransitionName==="root"&&(e.style.viewTransitionName=""),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName==="none"&&(e.style.viewTransitionName="")),c&2048&&(c=null,t.alternate!==null&&(c=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==c&&(t.refCount++,c!=null&&ic(c)));break;case 12:if(c&2048){$e(e,t,n,o),c=t.stateNode;try{var l=t.memoizedProps,i=l.id,r=l.onPostCommit;typeof r=="function"&&r(i,t.alternate===null?"mount":"update",c.passiveEffectDuration,-0)}catch(u){Q(t,t.return,u)}}else $e(e,t,n,o);break;case 31:$e(e,t,n,o);break;case 13:$e(e,t,n,o);break;case 23:break;case 22:l=t.stateNode,i=t.alternate,t.memoizedState!==null?(a&&i!==null&&i.memoizedState===null&&ol(i),l._visibility&2?$e(e,t,n,o):Ba(e,t)):(a&&i!==null&&i.memoizedState!==null&&ol(t),l._visibility&2?$e(e,t,n,o):(l._visibility|=2,go(e,t,n,o,(t.subtreeFlags&10256)!==0||!1))),c&2048&&ad(i,t);break;case 24:$e(e,t,n,o),c&2048&&cd(t.alternate,t);break;case 30:a&&(c=t.alternate,c!==null&&(Nt(c.child,!0),Nt(t.child,!0))),$e(e,t,n,o);break;default:$e(e,t,n,o)}}function go(e,t,n,o,a){for(a=a&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var c=e,l=t,i=n,r=o,u=l.flags;switch(l.tag){case 0:case 11:case 15:go(c,l,i,r,a),uc(8,l);break;case 23:break;case 22:var m=l.stateNode;l.memoizedState!==null?m._visibility&2?go(c,l,i,r,a):Ba(c,l):(m._visibility|=2,go(c,l,i,r,a)),a&&u&2048&&ad(l.alternate,l);break;case 24:go(c,l,i,r,a),a&&u&2048&&cd(l.alternate,l);break;default:go(c,l,i,r,a)}t=t.sibling}}function Ba(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,o=t,a=o.flags;switch(o.tag){case 22:Ba(n,o),a&2048&&ad(o.alternate,o);break;case 24:Ba(n,o),a&2048&&cd(o.alternate,o);break;default:Ba(n,o)}t=t.sibling}}var Hn=8192;function Rn(e,t,n){if(e.subtreeFlags&Hn)for(e=e.child;e!==null;)xg(e,t,n),e=e.sibling}function xg(e,t,n){switch(e.tag){case 26:Rn(e,t,n),e.flags&Hn&&(e.memoizedState!==null?fy(n,ut,e.memoizedState,e.memoizedProps):(e=e.stateNode,(t&335544128)===t&&lb(n,e)));break;case 5:Rn(e,t,n),e.flags&Hn&&(e=e.stateNode,(t&335544128)===t&&lb(n,e));break;case 3:case 4:var o=ut;ut=$a(e.stateNode.containerInfo),Rn(e,t,n),ut=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=Hn,Hn=16777216,Rn(e,t,n),Hn=o):Rn(e,t,n));break;case 30:if((e.flags&Hn)!==0&&(o=e.memoizedProps.name,o!=null&&o!=="auto")){var a=e.stateNode;a.paired=null,Ge===null&&(Ge=new Map),Ge.set(o,a)}Rn(e,t,n);break;default:Rn(e,t,n)}}function kg(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function ha(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];me=o,Tg(o,e)}kg(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)wg(e),e=e.sibling}function wg(e){switch(e.tag){case 0:case 11:case 15:ha(e),e.flags&2048&&zn(9,e,e.return);break;case 3:ha(e);break;case 12:ha(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,al(e)):ha(e);break;default:ha(e)}}function al(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];me=o,Tg(o,e)}kg(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:zn(8,t,t.return),al(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,al(t));break;default:al(t)}e=e.sibling}}function Tg(e,t){for(;me!==null;){var n=me;switch(n.tag){case 0:case 11:case 15:zn(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var o=n.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:ic(n.memoizedState.cache)}if(o=n.child,o!==null)o.return=n,me=o;else e:for(n=e;me!==null;){o=me;var a=o.sibling,c=o.return;if(bg(o),o===n){me=null;break e}if(a!==null){a.return=c,me=a;break e}me=c}}}var r0={getCacheForType:function(e){var t=ye(ie),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return ye(ie).controller.signal}},u0=typeof WeakMap=="function"?WeakMap:Map,q=0,K=null,D=null,R=0,G=0,Ye=null,dn=!1,na=!1,ld=!1,Xt=0,ae=0,Nn=0,Qn=0,Ml=0,je=0,jo=0,Ha=null,De=null,eu=!1,ei=0,Eg=0,Dl=1/0,Rl=null,yn=null,ne=0,ft=null,In=null,zt=0,tu=0,nu=null,zg=null,Bo=null,Ho=null,qo=null,qa=0,cl=null;function Ke(){return(q&2)!==0&&R!==0?R&-R:N.T!==null?rd():Ab()}function Ng(){if(je===0)if((R&536870912)===0||A){var e=Nc;Nc<<=1,(Nc&3932160)===0&&(Nc=262144),je=e}else je=536870912;return e=we.current,e!==null&&(e.flags|=32),je}function Qo(e,t){if(t!=null){var n=e.stateNode,o=n.ref;o===null&&(o=n.ref=Jg(Vt(e.memoizedProps,n))),Ho===null&&(Ho=[]),Ho.push(t.bind(null,o))}}function Be(e,t,n){(e===K&&(G===2||G===9)||e.cancelPendingCommit!==null)&&(Xo(e,0),fn(e,R,je,!1)),ac(e,n),((q&2)===0||e!==K)&&(e===K&&((q&2)===0&&(Qn|=n),ae===4&&fn(e,R,je,!1)),Ct(e))}function Og(e,t,n){if((q&6)!==0)throw Error(h(327));var o=!n&&(t&127)===0&&(t&e.expiredLanes)===0||oc(e,t),a=o?s0(e,t):er(e,t,!0),c=o;do{if(a===0){na&&!o&&fn(e,t,0,!1);break}else{if(n=e.current.alternate,c&&!d0(n)){a=er(e,t,!1),c=!1;continue}if(a===2){if(c=t,e.errorRecoveryDisabledLanes&c)var l=0;else l=e.pendingLanes&-536870913,l=l!==0?l:l&536870912?536870912:0;if(l!==0){t=l;e:{var i=e;a=Ha;var r=i.current.memoizedState.isDehydrated;if(r&&(Xo(i,l).flags|=256),l=er(i,l,!1),l!==2&&l!==6){if(ld&&!r){i.errorRecoveryDisabledLanes|=c,Qn|=c,a=4;break e}c=De,De=a,c!==null&&(De===null?De=c:De.push.apply(De,c))}a=l}if(c=!1,a!==2)continue}}if(a===1){Xo(e,0),fn(e,t,0,!0);break}e:{switch(o=e,c=a,c){case 0:case 1:throw Error(h(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:fn(o,t,je,!dn);break e;case 2:De=null;break;case 3:case 5:break;default:throw Error(h(329))}if((t&62914560)===t&&(a=ei+300-Qe(),10<a)){if(fn(o,t,je,!dn),Ll(o,0,!0)!==0)break e;zt=t,o.timeoutHandle=dd(Us.bind(null,o,n,De,Rl,eu,t,je,Qn,jo,dn,c,"Throttled",-0,0),a);break e}Us(o,n,De,Rl,eu,t,je,Qn,jo,dn,c,null,-0,0)}}break}while(!0);Ct(e)}function Us(e,t,n,o,a,c,l,i,r,u,m,p,d,s){e.timeoutHandle=-1;var y=t.subtreeFlags,w=(c&335544064)===c;if(p=null,(w||y&8192||(y&16785408)===16785408)&&(p={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:kt},Ge=null,xg(t,c,p),w&&(y=p,w=e.containerInfo,w=(w.nodeType===9?w:w.ownerDocument).__reactViewTransition,w!=null&&(y.count++,y.waitingForViewTransition=!0,y=Ia.bind(y),w.finished.then(y,y))),y=(c&62914560)===c?ei-Qe():(c&4194048)===c?Eg-Qe():0,y=sy(p,y),y!==null)){zt=c,e.cancelPendingCommit=y(Hs.bind(null,e,t,c,n,o,a,l,i,r,u,m,p,null,d,s)),fn(e,c,l,!u);return}Hs(e,t,c,n,o,a,l,i,r,u,m,p)}function d0(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var o=0;o<n.length;o++){var a=n[o],c=a.getSnapshot;a=a.value;try{if(!Je(c(),a))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function fn(e,t,n,o){t=Eb(e,t),t&=~Ml,t&=~Qn,e.suspendedLanes|=t,e.pingedLanes&=~t,o&&(e.warmLanes|=t),o=e.expirationTimes;for(var a=t;0<a;){var c=31-Ze(a),l=1<<c;o[c]=-1,a&=~l}n!==0&&Nb(e,n,t)}function ti(){return(q&6)===0?(dc(0,!1),!1):!0}function id(){if(D!==null){if(G===0)var e=D.return;else e=D,Ht=oo=null,Qu(e),Do=null,Xa=0,e=D;for(;e!==null;)ng(e.alternate,e),e=e.return;D=null}}function Xo(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,M0(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),zt=0,id(),K=e,D=n=qt(e.current,null),R=t,G=0,Ye=null,dn=!1,na=oc(e,t),ld=!1,jo=je=Ml=Qn=Nn=ae=0,De=Ha=null,eu=!1,Xt=Eb(e,t),Xl(),n}function Cg(e,t){C=null,N.H=zl,t===ea||t===Jl?(t=rs(),G=3):t===Bu?(t=rs(),G=4):G=t===Iu?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,Ye=t,D===null&&(ae=1,Nl(e,nt(t,e.current)))}function Ag(){var e=we.current;return e===null?!0:(R&4194048)===R?ze===null:(R&62914560)===R||(R&536870912)!==0?e===ze:!1}function _g(){var e=N.H;return N.H=zl,e===null?zl:e}function Mg(){var e=N.A;return N.A=r0,e}function Ul(){ae=4,dn||(R&4194048)!==R&&we.current!==null||(na=!0),(Nn&134217727)===0&&(Qn&134217727)===0||K===null||fn(K,R,je,!1)}function er(e,t,n){var o=q;q|=2;var a=_g(),c=Mg();(K!==e||R!==t)&&(Rl=null,Xo(e,t)),t=!1;var l=ae;e:do try{if(G!==0&&D!==null){var i=D,r=Ye;switch(G){case 8:id(),l=6;break e;case 3:case 2:case 9:case 6:we.current===null&&(t=!0);var u=G;if(G=0,Ye=null,Oo(e,i,r,u),n&&na){l=0;break e}break;default:u=G,G=0,Ye=null,Oo(e,i,r,u)}}f0(),l=ae;break}catch(m){Cg(e,m)}while(!0);return t&&e.shellSuspendCounter++,Ht=oo=null,q=o,N.H=a,N.A=c,D===null&&(K=null,R=0,Xl()),l}function f0(){for(;D!==null;)Dg(D)}function s0(e,t){var n=q;q|=2;var o=_g(),a=Mg();K!==e||R!==t?(Rl=null,Dl=Qe()+500,Xo(e,t)):na=oc(e,t);e:do try{if(G!==0&&D!==null){t=D;var c=Ye;t:switch(G){case 1:G=0,Ye=null,Oo(e,t,c,1);break;case 2:case 9:if(is(c)){G=0,Ye=null,Bs(t);break}t=function(){G!==2&&G!==9||K!==e||(G=7),Ct(e)},c.then(t,t);break e;case 3:G=7;break e;case 4:G=5;break e;case 7:is(c)?(G=0,Ye=null,Bs(t)):(G=0,Ye=null,Oo(e,t,c,7));break;case 5:var l=null;switch(D.tag){case 26:l=D.memoizedState;case 5:case 27:var i=D;if(l?ap(l):i.stateNode.complete){G=0,Ye=null;var r=i.sibling;if(r!==null)D=r;else{var u=i.return;u!==null?(D=u,ni(u)):D=null}break t}}G=0,Ye=null,Oo(e,t,c,5);break;case 6:G=0,Ye=null,Oo(e,t,c,6);break;case 8:id(),ae=6;break e;default:throw Error(h(462))}}b0();break}catch(m){Cg(e,m)}while(!0);return Ht=oo=null,N.H=o,N.A=a,q=n,D!==null?0:(K=null,R=0,Xl(),ae)}function b0(){for(;D!==null&&!Av();)Dg(D)}function Dg(e){var t=tg(e.alternate,e,Xt);e.memoizedProps=e.pendingProps,t===null?ni(e):D=t}function Bs(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Ts(n,t,t.pendingProps,t.type,void 0,R);break;case 11:t=Ts(n,t,t.pendingProps,t.type.render,t.ref,R);break;case 5:Qu(t);var o=t;o===pe&&(A?(yl(o),o.tag===5&&o.stateNode!=null&&($=o.stateNode)):(yl(o),A=!0));default:ng(n,t),t=D=om(t,Xt),t=tg(n,t,Xt)}e.memoizedProps=e.pendingProps,t===null?ni(e):D=t}function Oo(e,t,n,o){Ht=oo=null,Qu(t),Do=null,Xa=0;var a=t.return;try{if(e0(e,a,t,n,R)){ae=1,Nl(e,nt(n,e.current)),D=null;return}}catch(c){if(a!==null)throw D=a,c;ae=1,Nl(e,nt(n,e.current)),D=null;return}t.flags&32768?(A||o===1?e=!0:na||(R&536870912)!==0?e=!1:(dn=e=!0,(o===2||o===9||o===3||o===6)&&(o=we.current,o!==null&&o.tag===13&&(o.flags|=16384))),Rg(t,e)):ni(t)}function ni(e){var t=e;do{if((t.flags&32768)!==0){Rg(t,dn);return}e=t.return;var n=a0(t.alternate,t,Xt);if(n!==null){D=n;return}if(t=t.sibling,t!==null){D=t;return}D=t=e}while(t!==null);ae===0&&(ae=5)}function Rg(e,t){do{var n=c0(e.alternate,e);if(n!==null){n.flags&=32767,D=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){D=e;return}D=e=n}while(e!==null);ae=6,D=null}function Hs(e,t,n,o,a,c,l,i,r,u,m,p){e.cancelPendingCommit=null;do oi();while(ne!==0);if((q&6)!==0)throw Error(h(327));if(t!==null){if(t===e.current)throw Error(h(177));e===K&&(D=K=null,R=0),In=t,ft=e,zt=n,nu=a,zg=o,m0(e,t,n,l,i,r,p)}}function m0(e,t,n,o,a,c,l){var i=t.lanes|t.childLanes;if(tu=i,i|=Au,Lv(e,n,i,o,a,c),Ho=null,(n&335544064)===n?(qo=Gh(e),o=10262):(qo=null,o=10256),(t.subtreeFlags&o)!==0||(t.flags&o)!==0?(e.callbackNode=null,e.callbackPriority=0,S0(ml,function(){return lu(),null})):(e.callbackNode=null,e.callbackPriority=0),Al=!1,o=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||o){o=N.T,N.T=null,a=Y.p,Y.p=2,c=q,q|=4;try{l0(e,t,n)}finally{q=c,Y.p=a,N.T=o}}ne=1,Al?Bo=q0(l,e.containerInfo,qo,ou,au,p0,cu,lu,g0,null,null):(ou(),au(),cu())}function g0(e){if(ne!==0){var t=ft.onRecoverableError;t(e,{componentStack:null})}}function p0(){ne===3&&(ne=0,yg(In,ft),ne=4)}function ou(){if(ne===1){ne=0;var e=ft,t=In,n=zt,o=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||o){o=N.T,N.T=null;var a=Y.p;Y.p=2;var c=q;q|=4;try{Ea=_l=!1,vg(t,e,n),n=du;var l=Fb(e.containerInfo),i=n.focusedElem,r=n.selectionRange;if(l!==i&&i&&i.ownerDocument&&Jb(i.ownerDocument.documentElement,i)){if(r!==null&&Cu(i)){var u=r.start,m=r.end;if(m===void 0&&(m=u),"selectionStart"in i)i.selectionStart=u,i.selectionEnd=Math.min(m,i.value.length);else{var p=i.ownerDocument||document,d=p&&p.defaultView||window;if(d.getSelection){var s=d.getSelection(),y=i.textContent.length,w=Math.min(r.start,y),z=r.end===void 0?w:Math.min(r.end,y);!s.extend&&w>z&&(l=z,z=w,w=l);var g=Pf(i,w),f=Pf(i,z);if(g&&f&&(s.rangeCount!==1||s.anchorNode!==g.node||s.anchorOffset!==g.offset||s.focusNode!==f.node||s.focusOffset!==f.offset)){var b=p.createRange();b.setStart(g.node,g.offset),s.removeAllRanges(),w>z?(s.addRange(b),s.extend(f.node,f.offset)):(b.setEnd(f.node,f.offset),s.addRange(b))}}}}for(p=[],s=i;s=s.parentNode;)s.nodeType===1&&p.push({element:s,left:s.scrollLeft,top:s.scrollTop});for(typeof i.focus=="function"&&i.focus(),i=0;i<p.length;i++){var v=p[i];v.element.scrollLeft=v.left,v.element.scrollTop=v.top}}Wo=!!uu,du=uu=null}finally{q=c,Y.p=a,N.T=o}}e.current=t,ne=2}}function au(){if(ne===2){ne=0;var e=ft,t=In,n=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||n){n=N.T,N.T=null;var o=Y.p;Y.p=2;var a=q;q|=4;try{fg(e,t.alternate,t)}finally{q=a,Y.p=o,N.T=n}}ne=3}}function cu(){if(ne===4||ne===3){ne=0;var e=Bo;Bo=null,_v();var t=ft,n=In,o=zt,a=zg,c=(o&335544064)===o?10262:10256;if((n.subtreeFlags&c)!==0||(n.flags&c)!==0?ne=5:(ne=0,In=ft=null,Ug(t,t.pendingLanes)),c=t.pendingLanes,c===0&&(yn=null),wu(o),n=n.stateNode,Xe&&typeof Xe.onCommitFiberRoot=="function")try{Xe.onCommitFiberRoot(nc,n,void 0,(n.current.flags&128)===128)}catch{}if(a!==null){n=N.T,c=Y.p,Y.p=2,N.T=null;try{for(var l=t.onRecoverableError,i=0;i<a.length;i++){var r=a[i];l(r.value,{componentStack:r.stack})}}finally{N.T=n,Y.p=c}}if(a=Ho,l=qo,qo=null,a!==null&&(Ho=null,l===null&&(l=[]),e!==null))for(r=0;r<a.length;r++)n=(0,a[r])(l),n!==void 0&&e.finished.finally(n);(zt&3)!==0&&oi(),Ct(t),c=t.pendingLanes,(o&261930)!==0&&(c&42)!==0?t===cl?qa++:(qa=0,cl=t):(qa=0,cl=null),dc(0,!1)}}function Ug(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,ic(t)))}function oi(){return Bo!==null&&(Bo.skipTransition(),Bo=null),ou(),au(),cu(),lu()}function lu(){if(ne!==5)return!1;var e=ft,t=tu;tu=0;var n=wu(zt),o=N.T,a=Y.p;try{Y.p=32>n?32:n,N.T=null,n=nu,nu=null;var c=ft,l=zt;if(ne=0,In=ft=null,zt=0,(q&6)!==0)throw Error(h(331));var i=q;if(q|=4,wg(c.current),Sg(c,c.current,l,n),q=i,dc(0,!1),Xe&&typeof Xe.onPostCommitFiberRoot=="function")try{Xe.onPostCommitFiberRoot(nc,c)}catch{}return!0}finally{Y.p=a,N.T=o,Ug(e,t)}}function qs(e,t,n){t=nt(n,t),t=Yr(e.stateNode,t,2),e=pn(e,t,2),e!==null&&(ac(e,2),Ct(e))}function Q(e,t,n){if(e.tag===3)qs(e,e,n);else for(;t!==null;){if(t.tag===3){qs(t,e,n);break}else if(t.tag===1){var o=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(yn===null||!yn.has(o))){e=nt(n,e),n=Wm(2),o=pn(t,n,2),o!==null&&($m(n,o,t,e),ac(o,2),Ct(o));break}}t=t.return}}function tr(e,t,n){var o=e.pingCache;if(o===null){o=e.pingCache=new u0;var a=new Set;o.set(t,a)}else a=o.get(t),a===void 0&&(a=new Set,o.set(t,a));a.has(n)||(ld=!0,a.add(n),e=v0.bind(null,e,t,n),t.then(e,e))}function v0(e,t,n){var o=e.pingCache;o!==null&&o.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,K===e&&(R&n)===n&&((ae===4||ae===3&&(R&62914560)===R&&300>Qe()-ei)&&(q&2)===0?Xo(e,0):Ml|=n,jo===R&&(jo=0)),Ct(e)}function Bg(e,t){t===0&&(t=zb()),e=no(e,t),e!==null&&(ac(e,t),Ct(e))}function h0(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Bg(e,n)}function y0(e,t){var n=0;switch(e.tag){case 31:case 13:var o=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(h(314))}o!==null&&o.delete(t),Bg(e,n)}function S0(e,t){return xu(e,t)}var Zo=null,po=null,iu=!1,Bl=!1,nr=!1,sn=0;function Ct(e){e!==po&&e.next===null&&(po===null?Zo=po=e:po=po.next=e),Bl=!0,iu||(iu=!0,k0())}function dc(e,t){if(!nr&&Bl){nr=!0;do for(var n=!1,o=Zo;o!==null;){if(!t)if(e!==0){var a=o.pendingLanes;if(a===0)var c=0;else{var l=o.suspendedLanes,i=o.pingedLanes;c=(1<<31-Ze(42|e)+1)-1,c&=a&~(l&~i),c=c&201326741?c&201326741|1:c?c|2:0}c!==0&&(n=!0,Ys(o,c))}else c=R,c=Ll(o,o===K?c:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(c&3)===0||oc(o,c)||(n=!0,Ys(o,c));o=o.next}while(n);nr=!1}}function x0(){Hg()}function Hg(){Bl=iu=!1;var e=0;sn!==0&&_0()&&(e=sn);for(var t=Qe(),n=null,o=Zo;o!==null;){var a=o.next,c=qg(o,t);c===0?(o.next=null,n===null?Zo=a:n.next=a,a===null&&(po=n)):(n=o,(e!==0||(c&3)!==0)&&(Bl=!0)),o=a}ne!==0&&ne!==5||dc(e,!1),sn!==0&&(sn=0)}function qg(e,t){for(var n=e.suspendedLanes,o=e.pingedLanes,a=e.expirationTimes,c=e.pendingLanes&-62914561;0<c;){var l=31-Ze(c),i=1<<l,r=a[l];r===-1?((i&n)===0||(i&o)!==0)&&(a[l]=Yv(i,t)):r<=t&&(e.expiredLanes|=i),c&=~i}if(t=K,n=R,n=Ll(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,n===0||e===t&&(G===2||G===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&Ri(o),e.callbackNode=null,e.callbackPriority=0;if((n&3)===0||oc(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(o!==null&&Ri(o),wu(n)){case 2:case 8:n=wb;break;case 32:n=ml;break;case 268435456:n=Tb;break;default:n=ml}return o=Yg.bind(null,e),n=xu(n,o),e.callbackPriority=t,e.callbackNode=n,t}return o!==null&&o!==null&&Ri(o),e.callbackPriority=2,e.callbackNode=null,2}function Yg(e,t){if(ne!==0&&ne!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(oi()&&e.callbackNode!==n)return null;var o=R;return o=Ll(e,e===K?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(Og(e,o,t),qg(e,Qe()),e.callbackNode!=null&&e.callbackNode===n?Yg.bind(null,e):null)}function Ys(e,t){if(oi())return null;Og(e,t,!0)}function k0(){D0(function(){(q&6)!==0?xu(kb,x0):Hg()})}function rd(){if(sn===0){var e=Jn;e===0&&(e=zc,zc<<=1,(zc&261888)===0&&(zc=256)),sn=e}return sn}function Ls(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:Kc(e)}function w0(e,t,n,o,a){if(t==="submit"&&n&&n.stateNode===a){var c=Ls((a[qe]||null).action),l=o.submitter;l&&(t=(t=l[qe]||null)?Ls(t.formAction):l.getAttribute("formAction"),t!==null&&(c=t,l=null));var i=new Gl("action","action",null,o,a);e.push({event:i,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(sn!==0){var r=new FormData(a,l);Hr(n,{pending:!0,data:r,method:a.method,action:c},null,r)}}else typeof c=="function"&&(i.preventDefault(),r=new FormData(a,l),Hr(n,{pending:!0,data:r,method:a.method,action:c},c,r))},currentTarget:a}]})}}for(Vc=0;Vc<zr.length;Vc++)Gc=zr[Vc],Vs=Gc.toLowerCase(),Gs=Gc[0].toUpperCase()+Gc.slice(1),st(Vs,"on"+Gs);var Gc,Vs,Gs,Vc;st($b,"onAnimationEnd");st(Ib,"onAnimationIteration");st(Pb,"onAnimationStart");st("dblclick","onDoubleClick");st("focusin","onFocus");st("focusout","onBlur");st(Rh,"onTransitionRun");st(Uh,"onTransitionStart");st(Bh,"onTransitionCancel");st(em,"onTransitionEnd");Lo("onMouseEnter",["mouseout","mouseover"]);Lo("onMouseLeave",["mouseout","mouseover"]);Lo("onPointerEnter",["pointerout","pointerover"]);Lo("onPointerLeave",["pointerout","pointerover"]);eo("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));eo("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));eo("onBeforeInput",["compositionend","keypress","textInput","paste"]);eo("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));eo("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));eo("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ja="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),T0=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Ja));function Lg(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var o=e[n],a=o.event;o=o.listeners;e:{var c=void 0;if(t)for(var l=o.length-1;0<=l;l--){var i=o[l],r=i.instance,u=i.currentTarget;if(i=i.listener,r!==c&&a.isPropagationStopped())break e;c=i,a.currentTarget=u;try{c(a)}catch(m){pl(m)}a.currentTarget=null,c=r}else for(l=0;l<o.length;l++){if(i=o[l],r=i.instance,u=i.currentTarget,i=i.listener,r!==c&&a.isPropagationStopped())break e;c=i,a.currentTarget=u;try{c(a)}catch(m){pl(m)}a.currentTarget=null,c=r}}}}function M(e,t){var n=t[Bf];n===void 0&&(n=t[Bf]=new Set);var o=e+"__bubble";n.has(o)||(Vg(t,e,2,!1),n.add(o))}function or(e,t,n){var o=0;t&&(o|=4),Vg(n,e,o,t)}var jc="_reactListening"+Math.random().toString(36).slice(2);function ud(e){if(!e[jc]){e[jc]=!0,Mb.forEach(function(n){n!=="selectionchange"&&(T0.has(n)||or(n,!1,e),or(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[jc]||(t[jc]=!0,or("selectionchange",!1,t))}}function Vg(e,t,n,o){switch(fp(t)){case 2:var a=py;break;case 8:a=vy;break;default:a=pd}n=a.bind(null,t,n,e),a=void 0,!kr||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(a=!0),o?a!==void 0?e.addEventListener(t,n,{capture:!0,passive:a}):e.addEventListener(t,n,!0):a!==void 0?e.addEventListener(t,n,{passive:a}):e.addEventListener(t,n,!1)}function ar(e,t,n,o,a){var c=o;if((t&1)===0&&(t&2)===0&&o!==null)e:for(;;){if(o===null)return;var l=o.tag;if(l===3||l===4){var i=o.stateNode.containerInfo;if(i===a)break;if(l===4)for(l=o.return;l!==null;){var r=l.tag;if((r===3||r===4)&&l.stateNode.containerInfo===a)return;l=l.return}for(;i!==null;){if(l=qn(i),l===null)return;if(r=l.tag,r===5||r===6||r===26||r===27){o=c=l;continue e}i=i.parentNode}}o=o.return}Lb(function(){var u=c,m=Eu(n),p=[];e:{var d=tm.get(e);if(d!==void 0){var s=Gl,y=e;switch(e){case"keypress":if(Fc(n)===0)break e;case"keydown":case"keyup":s=dh;break;case"focusin":y="focus",s=Li;break;case"focusout":y="blur",s=Li;break;case"beforeblur":case"afterblur":s=Li;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":s=Qf;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":s=Iv;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":s=gh;break;case $b:case Ib:case Pb:s=th;break;case em:s=vh;break;case"scroll":case"scrollend":s=Wv;break;case"wheel":s=yh;break;case"copy":case"cut":case"paste":s=oh;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":s=Zf;break;case"submit":s=bh;break;case"toggle":case"beforetoggle":s=xh}var w=(t&4)!==0,z=!w&&(e==="scroll"||e==="scrollend"),g=w?d!==null?d+"Capture":null:d;w=[];for(var f=u,b;f!==null;){var v=f;if(b=v.stateNode,v=v.tag,v!==5&&v!==26&&v!==27||b===null||g===null||(v=La(f,g),v!=null&&w.push(Fa(f,v,b))),z)break;f=f.return}0<w.length&&(d=new s(d,y,null,n,m),p.push({event:d,listeners:w}))}}if((t&7)===0){e:{if(s=e==="mouseover"||e==="pointerover",d=e==="mouseout"||e==="pointerout",s&&n!==xr&&(y=n.relatedTarget||n.fromElement)&&(qn(y)||y[Io]))break e;(d||s)&&(y=m.window===m?m:(s=m.ownerDocument)?s.defaultView||s.parentWindow:window,d?(s=n.relatedTarget||n.toElement,d=u,s=s?qn(s):null,s!==null&&(z=tc(s),w=s.tag,s!==z||w!==5&&w!==27&&w!==6)&&(s=null)):(d=null,s=u),d!==s&&(w=Qf,v="onMouseLeave",g="onMouseEnter",f="mouse",(e==="pointerout"||e==="pointerover")&&(w=Zf,v="onPointerLeave",g="onPointerEnter",f="pointer"),z=d==null?y:wa(d),b=s==null?y:wa(s),y=new w(v,f+"leave",d,n,m),y.target=z,y.relatedTarget=b,v=null,qn(m)===u&&(w=new w(g,f+"enter",s,n,m),w.target=b,w.relatedTarget=z,v=w),z=v,w=d&&s?ur(d,s,E0):null,d!==null&&js(p,y,d,w,!1),s!==null&&z!==null&&js(p,z,s,w,!0)))}e:{if(d=u?wa(u):window,s=d.nodeName&&d.nodeName.toLowerCase(),s==="select"||s==="input"&&d.type==="file")var x=Wf;else if(Ff(d))if(Zb)x=_h;else{x=Ch;var T=Oh}else s=d.nodeName,!s||s.toLowerCase()!=="input"||d.type!=="checkbox"&&d.type!=="radio"?u&&Tu(u.elementType)&&(x=Wf):x=Ah;if(x&&(x=x(e,u))){Xb(p,x,n,m);break e}T&&T(e,d,u)}switch(T=u?wa(u):window,e){case"focusin":(Ff(T)||T.contentEditable==="true")&&(ko=T,Tr=u,Oa=null);break;case"focusout":Oa=Tr=ko=null;break;case"mousedown":Er=!0;break;case"contextmenu":case"mouseup":case"dragend":Er=!1,es(p,n,m);break;case"selectionchange":if(Dh)break;case"keydown":case"keyup":es(p,n,m)}var k;if(Ou)e:{switch(e){case"compositionstart":var E="onCompositionStart";break e;case"compositionend":E="onCompositionEnd";break e;case"compositionupdate":E="onCompositionUpdate";break e}E=void 0}else xo?jb(e,n)&&(E="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(E="onCompositionStart");E&&(Gb&&n.locale!=="ko"&&(xo||E!=="onCompositionStart"?E==="onCompositionEnd"&&xo&&(k=Vb()):(rn=m,zu="value"in rn?rn.value:rn.textContent,xo=!0)),T=Hl(u,E),0<T.length&&(E=new Xf(E,e,null,n,m),p.push({event:E,listeners:T}),k?E.data=k:(k=Qb(n),k!==null&&(E.data=k)))),(k=wh?Th(e,n):Eh(e,n))&&(E=Hl(u,"onBeforeInput"),0<E.length&&(T=new Xf("onBeforeInput","beforeinput",null,n,m),p.push({event:T,listeners:E}),T.data=k)),w0(p,e,u,n,m)}Lg(p,t)})}function Fa(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Hl(e,t){for(var n=t+"Capture",o=[];e!==null;){var a=e,c=a.stateNode;if(a=a.tag,a!==5&&a!==26&&a!==27||c===null||(a=La(e,n),a!=null&&o.unshift(Fa(e,a,c)),a=La(e,t),a!=null&&o.push(Fa(e,a,c))),e.tag===3)return o;e=e.return}return[]}function E0(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function js(e,t,n,o,a){for(var c=t._reactName,l=[];n!==null&&n!==o;){var i=n,r=i.alternate,u=i.stateNode;if(i=i.tag,r!==null&&r===o)break;i!==5&&i!==26&&i!==27||u===null||(r=u,a?(u=La(n,c),u!=null&&l.unshift(Fa(n,u,r))):a||(u=La(n,c),u!=null&&l.push(Fa(n,u,r)))),n=n.return}l.length!==0&&e.push({event:t,listeners:l})}var z0=/\r\n?/g,N0=/\u0000|\uFFFD/g;function Qs(e){return(typeof e=="string"?e:""+e).replace(z0,`
`).replace(N0,"")}function Gg(e,t){return t=Qs(t),Qs(e)===t}function j(e,t,n,o,a,c){switch(n){case"children":if(typeof o=="string")t==="body"||t==="textarea"&&o===""||Vo(e,o);else if(typeof o=="number"||typeof o=="bigint")t!=="body"&&Vo(e,""+o);else return;break;case"className":Cc(e,"class",o);break;case"tabIndex":Cc(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":Cc(e,n,o);break;case"style":Yb(e,o,c);return;case"data":if(t!=="object"){Cc(e,"data",o);break}case"src":case"href":if(o===""&&(t!=="a"||n!=="href")){e.removeAttribute(n);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=Kc(o),e.setAttribute(n,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof c=="function"&&(n==="formAction"?(t!=="input"&&j(e,t,"name",a.name,a,null),j(e,t,"formEncType",a.formEncType,a,null),j(e,t,"formMethod",a.formMethod,a,null),j(e,t,"formTarget",a.formTarget,a,null)):(j(e,t,"encType",a.encType,a,null),j(e,t,"method",a.method,a,null),j(e,t,"target",a.target,a,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=Kc(o),e.setAttribute(n,o);break;case"onClick":o!=null&&(e.onclick=kt);return;case"onScroll":o!=null&&M("scroll",e);return;case"onScrollEnd":o!=null&&M("scrollend",e);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(h(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(h(60));c?.__html!==n&&(e.innerHTML=n)}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}n=Kc(o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":o===!0?e.setAttribute(n,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(n,o):e.removeAttribute(n);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(n):e.setAttribute(n,o);break;case"popover":M("beforetoggle",e),M("toggle",e),Zc(e,"popover",o);break;case"xlinkActuate":Rt(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Rt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Rt(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Rt(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Rt(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Rt(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Rt(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Rt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Rt(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":Zc(e,"is",o);break;case"innerText":case"textContent":return;default:if(!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")n=Jv.get(n)||n,Zc(e,n,o);else return}H=!0}function ru(e,t,n,o,a,c){switch(n){case"style":Yb(e,o,c);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(h(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(h(60));c?.__html!==n&&(e.innerHTML=n)}}break;case"children":if(typeof o=="string")Vo(e,o);else if(typeof o=="number"||typeof o=="bigint")Vo(e,""+o);else return;break;case"onScroll":o!=null&&M("scroll",e);return;case"onScrollEnd":o!=null&&M("scrollend",e);return;case"onClick":o!=null&&(e.onclick=kt);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!Db.hasOwnProperty(n))e:{if(n[0]==="o"&&n[1]==="n"&&(a=n.endsWith("Capture"),c=n.slice(2,a?n.length-7:void 0),t=e[qe]||null,t=t!=null?t[n]:null,typeof t=="function"&&e.removeEventListener(c,t,a),typeof o=="function")){typeof t!="function"&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(c,o,a);break e}H=!0,n in e?e[n]=o:o===!0?e.setAttribute(n,""):Zc(e,n,o)}return}H=!0}function ke(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":M("error",e),M("load",e);var o=!1,a=!1,c;for(c in n)if(n.hasOwnProperty(c)){var l=n[c];if(l!=null)switch(c){case"src":o=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(h(137,t));default:j(e,t,c,l,n,null)}}a&&j(e,t,"srcSet",n.srcSet,n,null),o&&j(e,t,"src",n.src,n,null);return;case"input":M("invalid",e);var i=c=l=a=null,r=null,u=null;for(o in n)if(n.hasOwnProperty(o)){var m=n[o];if(m!=null)switch(o){case"name":a=m;break;case"type":l=m;break;case"checked":r=m;break;case"defaultChecked":u=m;break;case"value":c=m;break;case"defaultValue":i=m;break;case"children":case"dangerouslySetInnerHTML":if(m!=null)throw Error(h(137,t));break;default:j(e,t,o,m,n,null)}}Bb(e,c,i,r,u,l,a,!1);return;case"select":M("invalid",e),o=l=c=null;for(a in n)if(n.hasOwnProperty(a)&&(i=n[a],i!=null))switch(a){case"value":c=i;break;case"defaultValue":l=i;break;case"multiple":o=i;default:j(e,t,a,i,n,null)}t=c,n=l,e.multiple=!!o,t!=null?Ao(e,!!o,t,!1):n!=null&&Ao(e,!!o,n,!0);return;case"textarea":M("invalid",e),c=a=o=null;for(l in n)if(n.hasOwnProperty(l)&&(i=n[l],i!=null))switch(l){case"value":o=i;break;case"defaultValue":a=i;break;case"children":c=i;break;case"dangerouslySetInnerHTML":if(i!=null)throw Error(h(91));break;default:j(e,t,l,i,n,null)}qb(e,o,a,c);return;case"option":for(r in n)n.hasOwnProperty(r)&&(o=n[r],o!=null)&&(r==="selected"?e.selected=o&&typeof o!="function"&&typeof o!="symbol":j(e,t,r,o,n,null));return;case"dialog":M("beforetoggle",e),M("toggle",e),M("cancel",e),M("close",e);break;case"iframe":case"object":M("load",e);break;case"video":case"audio":for(o=0;o<Ja.length;o++)M(Ja[o],e);break;case"image":M("error",e),M("load",e);break;case"details":M("toggle",e);break;case"embed":case"source":case"link":M("error",e),M("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(u in n)if(n.hasOwnProperty(u)&&(o=n[u],o!=null))switch(u){case"children":case"dangerouslySetInnerHTML":throw Error(h(137,t));default:j(e,t,u,o,n,null)}return;default:if(Tu(t)){for(m in n)n.hasOwnProperty(m)&&(o=n[m],o!==void 0&&ru(e,t,m,o,n,void 0));return}}for(i in n)n.hasOwnProperty(i)&&(o=n[i],o!=null&&j(e,t,i,o,n,null))}var O0={};function C0(e,t,n,o){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var a=null,c=null,l=null,i=null,r=null,u=null,m=null;for(s in n){var p=n[s];if(n.hasOwnProperty(s)&&p!=null)switch(s){case"checked":break;case"value":break;case"defaultValue":r=p;default:o.hasOwnProperty(s)||j(e,t,s,null,o,p)}}for(var d in o){var s=o[d];if(p=n[d],o.hasOwnProperty(d)&&(s!=null||p!=null))switch(d){case"type":s!==p&&(H=!0),c=s;break;case"name":s!==p&&(H=!0),a=s;break;case"checked":s!==p&&(H=!0),u=s;break;case"defaultChecked":s!==p&&(H=!0),m=s;break;case"value":s!==p&&(H=!0),l=s;break;case"defaultValue":s!==p&&(H=!0),i=s;break;case"children":case"dangerouslySetInnerHTML":if(s!=null)throw Error(h(137,t));break;default:s!==p&&j(e,t,d,s,o,p)}}Sr(e,l,i,r,u,m,c,a);return;case"select":s=l=i=d=null;for(c in n)if(r=n[c],n.hasOwnProperty(c)&&r!=null)switch(c){case"value":break;case"multiple":s=r;default:o.hasOwnProperty(c)||j(e,t,c,null,o,r)}for(a in o)if(c=o[a],r=n[a],o.hasOwnProperty(a)&&(c!=null||r!=null))switch(a){case"value":c!==r&&(H=!0),d=c;break;case"defaultValue":c!==r&&(H=!0),i=c;break;case"multiple":c!==r&&(H=!0),l=c;default:c!==r&&j(e,t,a,c,o,r)}t=i,n=l,o=s,d!=null?Ao(e,!!n,d,!1):!!o!=!!n&&(t!=null?Ao(e,!!n,t,!0):Ao(e,!!n,n?[]:"",!1));return;case"textarea":s=d=null;for(i in n)if(a=n[i],n.hasOwnProperty(i)&&a!=null&&!o.hasOwnProperty(i))switch(i){case"value":break;case"children":break;default:j(e,t,i,null,o,a)}for(l in o)if(a=o[l],c=n[l],o.hasOwnProperty(l)&&(a!=null||c!=null))switch(l){case"value":a!==c&&(H=!0),d=a;break;case"defaultValue":a!==c&&(H=!0),s=a;break;case"children":break;case"dangerouslySetInnerHTML":if(a!=null)throw Error(h(91));break;default:a!==c&&j(e,t,l,a,o,c)}Hb(e,d,s);return;case"option":for(var y in n)d=n[y],n.hasOwnProperty(y)&&d!=null&&!o.hasOwnProperty(y)&&(y==="selected"?e.selected=!1:j(e,t,y,null,o,d));for(r in o)d=o[r],s=n[r],o.hasOwnProperty(r)&&d!==s&&(d!=null||s!=null)&&(r==="selected"?(d!==s&&(H=!0),e.selected=d&&typeof d!="function"&&typeof d!="symbol"):j(e,t,r,d,o,s));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var w in n)d=n[w],n.hasOwnProperty(w)&&d!=null&&!o.hasOwnProperty(w)&&j(e,t,w,null,o,d);for(u in o)if(d=o[u],s=n[u],o.hasOwnProperty(u)&&d!==s&&(d!=null||s!=null))switch(u){case"children":case"dangerouslySetInnerHTML":if(d!=null)throw Error(h(137,t));break;default:j(e,t,u,d,o,s)}return;default:if(Tu(t)){for(var z in n)d=n[z],n.hasOwnProperty(z)&&d!==void 0&&!o.hasOwnProperty(z)&&ru(e,t,z,void 0,o,d);for(m in o)d=o[m],s=n[m],!o.hasOwnProperty(m)||d===s||d===void 0&&s===void 0||ru(e,t,m,d,o,s);return}}for(var g in n)d=n[g],n.hasOwnProperty(g)&&d!=null&&!o.hasOwnProperty(g)&&j(e,t,g,null,o,d);for(p in o)d=o[p],s=n[p],!o.hasOwnProperty(p)||d===s||d==null&&s==null||j(e,t,p,d,o,s)}function Xs(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function A0(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,n=performance.getEntriesByType("resource"),o=0;o<n.length;o++){var a=n[o],c=a.transferSize,l=a.initiatorType,i=a.duration;if(c&&i&&Xs(l)){for(l=0,i=a.responseEnd,o+=1;o<n.length;o++){var r=n[o],u=r.startTime;if(u>i)break;var m=r.transferSize,p=r.initiatorType;m&&Xs(p)&&(r=r.responseEnd,l+=m*(r<i?1:(i-u)/(r-u)))}if(--o,t+=8*(c+l)/(a.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var uu=null,du=null;function Wa(e){return e.nodeType===9?e:e.ownerDocument}function Zs(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function jg(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function Qg(e,t,n,o){return n=Wa(n).createElement(e),n[he]=o,n[qe]=t,ke(n,e,t),ge(n),n}function fu(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var cr=null;function _0(){var e=window.event;return e&&e.type==="popstate"?e===cr?!1:(cr=e,!0):(cr=null,!1)}var dd=typeof setTimeout=="function"?setTimeout:void 0,M0=typeof clearTimeout=="function"?clearTimeout:void 0,Ks=typeof Promise=="function"?Promise:void 0,Js=typeof requestAnimationFrame=="function"?requestAnimationFrame:dd,D0=typeof queueMicrotask=="function"?queueMicrotask:typeof Ks<"u"?function(e){return Ks.resolve(null).then(e).catch(R0)}:dd;function R0(e){setTimeout(function(){throw e})}function Cn(e){return e==="head"}function Fs(e,t){var n=t,o=0;do{var a=n.nextSibling;if(e.removeChild(n),a&&a.nodeType===8)if(n=a.data,n==="/$"||n==="/&"){if(o===0){e.removeChild(a),$o(t);return}o--}else if(n==="$"||n==="$?"||n==="$~"||n==="$!"||n==="&")o++;else if(n==="html")ir(e.ownerDocument.documentElement);else if(n==="head"){n=e.ownerDocument.head,ir(n);for(var c=n.firstChild;c;){var l=c.nextSibling,i=c.nodeName;c[cc]||i==="SCRIPT"||i==="STYLE"||i==="LINK"&&c.rel.toLowerCase()==="stylesheet"||n.removeChild(c),c=l}}else n==="body"&&ir(e.ownerDocument.body);n=a}while(n);$o(t)}function Ws(e,t){var n=e;e=0;do{var o=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",n.getAttribute("style")===""&&n.removeAttribute("style")):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),o&&o.nodeType===8)if(n=o.data,n==="/$"){if(e===0)break;e--}else n!=="$"&&n!=="$?"&&n!=="$~"&&n!=="$!"||e++;n=o}while(n)}function Xg(e,t,n){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display==="inline"){if(t=e.getClientRects(),t.length===1)var o=1;else for(var a=o=0;a<t.length;a++){var c=t[a];0<c.width&&0<c.height&&o++}o===1&&(e=e.style,e.display=t.length===1?"inline-block":"block",e.marginTop="-"+n.paddingTop,e.marginBottom="-"+n.paddingBottom)}}function Zg(e,t){e=e.style,t=t.style;var n=t!=null?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=n==null||typeof n=="boolean"?"":(""+n).trim(),n=t!=null?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=n==null||typeof n=="boolean"?"":(""+n).trim(),e.display==="inline-block"&&(t==null?e.display=e.margin="":(n=t.display,e.display=n==null||typeof n=="boolean"?"":n,n=t.margin,n!=null?e.margin=n:(n=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=n==null||typeof n=="boolean"?"":n,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=t==null||typeof t=="boolean"?"":t)))}function Kg(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position==="absolute"||t.position==="fixed",clip:t.clipPath!=="none"||t.overflow!=="visible"||t.filter!=="none"||t.mask!=="none"||t.mask!=="none"||t.borderRadius!=="0px",view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function su(e){var t=e.getBoundingClientRect(),n=getComputedStyle(e);return Kg(t,n,e)}function U0(e){var t=e.getBoundingClientRect();t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height);var n=getComputedStyle(e);return Kg(t,n,e)}function B0(e){return e.documentElement.clientHeight}function H0(e){this.addEventListener("load",e),this.addEventListener("error",e)}function q0(e,t,n,o,a,c,l,i,r){var u=t.nodeType===9?t:t.ownerDocument;try{var m=u.startViewTransition({update:function(){var d=u.defaultView,s=d.navigation&&d.navigation.transition,y=u.fonts.status;o();var w=[];if(y==="loaded"&&(B0(u),u.fonts.status==="loading"&&w.push(u.fonts.ready)),y=w.length,e!==null)for(var z=e.suspenseyImages,g=0,f=0;f<z.length;f++){var b=z[f];if(!b.complete){var v=b.getBoundingClientRect();if(0<v.bottom&&0<v.right&&v.top<d.innerHeight&&v.left<d.innerWidth){if(g+=cp(b),g>rl){w.length=y;break}b=new Promise(H0.bind(b)),w.push(b)}}}if(0<w.length)return d=Promise.race([Promise.all(w),new Promise(function(x){return setTimeout(x,500)})]).then(a,a),(s?Promise.allSettled([s.finished,d]):d).then(c,c);if(a(),s)return s.finished.then(c,c);c()},types:n});u.__reactViewTransition=m;var p=[];return m.ready.then(function(){for(var d=u.documentElement.getAnimations({subtree:!0}),s=0;s<d.length;s++){var y=d[s],w=y.effect,z=w.pseudoElement;if(z!=null&&z.startsWith("::view-transition")){p.push(y),y=w.getKeyframes();for(var g=z=void 0,f=!0,b=0;b<y.length;b++){var v=y[b],x=v.width;if(z===void 0)z=x;else if(z!==x){f=!1;break}if(x=v.height,g===void 0)g=x;else if(g!==x){f=!1;break}delete v.width,delete v.height,v.transform==="none"&&delete v.transform}f&&z!==void 0&&g!==void 0&&(w.setKeyframes(y),f=getComputedStyle(w.target,w.pseudoElement),f.width!==z||f.height!==g)&&(f=y[0],f.width=z,f.height=g,f=y[y.length-1],f.width=z,f.height=g,w.setKeyframes(y))}}l()},function(d){u.__reactViewTransition===m&&(u.__reactViewTransition=null);try{typeof d=="object"&&d!==null&&d.name==="InvalidStateError"&&(d.message==="View transition was skipped because document visibility state is hidden."||d.message==="Skipping view transition because document visibility state has become hidden."||d.message==="Skipping view transition because viewport size changed."||d.message==="Transition was aborted because of invalid state")&&(d=null),d!==null&&r(d)}finally{o(),a(),l()}}),m.finished.finally(function(){for(var d=0;d<p.length;d++)p[d].cancel();u.__reactViewTransition===m&&(u.__reactViewTransition=null),i()}),m}catch{return o(),a(),l(),null}}function Yn(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}Yn.prototype.animate=function(e,t){return t=typeof t=="number"?{duration:t}:J({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)};Yn.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),o=[],a=0;a<n.length;a++){var c=n[a].effect;c!==null&&c.target===e&&c.pseudoElement===t&&o.push(n[a])}return o};Yn.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function Jg(e){return{name:e,group:new Yn("group",e),imagePair:new Yn("image-pair",e),old:new Yn("old",e),new:new Yn("new",e)}}function Fe(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}Fe.prototype.addEventListener=function(e,t,n){var o=null,a=null;if(!(n!=null&&typeof n!="boolean"&&(o=n.signal||null,o!==null&&o.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var c=this._eventListeners;if(Fg(c,e,t,n)===-1){var l=this,i=t;n!=null&&typeof n!="boolean"&&n.once===!0&&(i=function(r){l.removeEventListener(e,t,n),typeof t=="function"?t.call(this,r):t.handleEvent(r)}),o!==null&&(a=l.removeEventListener.bind(l,e,t,n),o.addEventListener("abort",a,{once:!0}),a=o.removeEventListener.bind(o,"abort",a)),o=Ko(n),c.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:i,cleanup:a}),He(this._fragmentFiber.child,!1,Y0,e,i,o)}this._eventListeners=c}};function Y0(e,t,n,o){return fe(e).addEventListener(t,n,o),!1}Fe.prototype.removeEventListener=function(e,t,n){var o=this._eventListeners;if(o!==null&&(t=Fg(o,e,t,n),t!==-1)){var a=o[t];n=a.attachedListener;var c=a.cleanup;a=Ko(a.optionsOrUseCapture),He(this._fragmentFiber.child,!1,L0,e,n,a),o.splice(t,1),c!==null&&c()}};function L0(e,t,n,o){return fe(e).removeEventListener(t,n,o),!1}function Ko(e){return e!=null&&typeof e!="boolean"&&(e.once===!0||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function $s(e){return e==null?"c=0":typeof e=="boolean"?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")}function Fg(e,t,n,o){if(e.length===0)return-1;o=$s(o);for(var a=0;a<e.length;a++){var c=e[a];if(c.type===t&&c.listener===n&&$s(c.optionsOrUseCapture)===o)return a}return-1}Fe.prototype.dispatchEvent=function(e){var t=Pn(this._fragmentFiber);if(t===null)return!0;t=fe(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var o=t.nodeType===9?t.createComment(""):document.createTextNode("");if(n)for(var a=0;a<n.length;a++){var c=n[a];o.addEventListener(c.type,c.attachedListener,Ko(c.optionsOrUseCapture))}if(t.appendChild(o),e=o.dispatchEvent(e),n)for(a=0;a<n.length;a++)c=n[a],o.removeEventListener(c.type,c.attachedListener,Ko(c.optionsOrUseCapture));return t.removeChild(o),e}return t.dispatchEvent(e)};Fe.prototype.focus=function(e){He(this._fragmentFiber.child,!0,Wg,e,void 0,void 0)};function Wg(e,t){return e.tag===6?!1:(e=fe(e),I0(e,t))}Fe.prototype.focusLast=function(e){var t=[];He(this._fragmentFiber.child,!0,fd,t,void 0,void 0);for(var n=t.length-1;0<=n&&!Wg(t[n],e);n--);};function fd(e,t){return t.push(e),!1}Fe.prototype.blur=function(){var e=Pn(this._fragmentFiber);e!==null&&(e=fe(e),e=Wa(e).activeElement,e!==null&&He(this._fragmentFiber.child,!1,V0,e,void 0,void 0))};function V0(e,t){return e.tag===6?!1:(e=fe(e),e===t||e.contains(t)?(t.blur(),!0):!1)}Fe.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),He(this._fragmentFiber.child,!1,G0,e,void 0,void 0)};function G0(e,t){return e.tag===6||(e=fe(e),t.observe(e)),!1}Fe.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),He(this._fragmentFiber.child,!1,j0,e,void 0,void 0);for(var n=t=0;n<dt.length;n++){var o=dt[n];o.fragmentInstance===this&&o.observer===e?e.unobserve(o.instance):dt[t++]=o}dt.length=t}};function j0(e,t){return e.tag===6||(e=fe(e),t.unobserve(e)),!1}var dt=[],lr=!1;function Q0(e,t,n){dt.push({fragmentInstance:e,observer:t,instance:n}),lr||(lr=!0,P0(function(){lr=!1;var o=dt;dt=[];for(var a=0;a<o.length;a++){var c=o[a];c.observer.unobserve(c.instance)}}))}Fe.prototype.getClientRects=function(){var e=[];return He(this._fragmentFiber.child,!1,X0,e,void 0,void 0),e};function X0(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=fe(e),t.push.apply(t,e.getClientRects());return!1}Fe.prototype.getRootNode=function(e){var t=Pn(this._fragmentFiber);return t===null?this:fe(t).getRootNode(e)};Fe.prototype.compareDocumentPosition=function(e){var t=Pn(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];He(this._fragmentFiber.child,!1,fd,n,void 0,void 0);var o=fe(t);if(n.length===0){if(n=o,Af(this._fragmentFiber)){e:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break e}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var a=o=n.compareDocumentPosition(e);return n===e?a=Node.DOCUMENT_POSITION_CONTAINS:o&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=hb(t)[1],n===null?a=Node.DOCUMENT_POSITION_PRECEDING:(e=fe(n).compareDocumentPosition(e),a=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),a|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=fe(n[0]),a=fe(n[n.length-1]);var c=Af(this._fragmentFiber)?t.parentElement:o;if(c==null)return Node.DOCUMENT_POSITION_DISCONNECTED;o=c.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,c=c.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_CONTAINED_BY;var l=t.compareDocumentPosition(e),i=a.compareDocumentPosition(e),r=l&Node.DOCUMENT_POSITION_CONTAINED_BY||i&Node.DOCUMENT_POSITION_CONTAINED_BY;return i=o&&c&&l&Node.DOCUMENT_POSITION_FOLLOWING&&i&Node.DOCUMENT_POSITION_PRECEDING,t=o&&t===e||c&&a===e||r||i?Node.DOCUMENT_POSITION_CONTAINED_BY:!o&&t===e||!c&&a===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:l,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||Z0(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function Z0(e,t,n,o,a){var c=qn(a);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!c)e:{for(;c!==null;){if(c.tag===7&&(c===t||c.alternate===t)){n=!0;break e}c=c.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(c===null)return c=a.ownerDocument,a===c||a===c.documentElement||a===c.body;e:{for(c=t,t=Pn(t);c!==null;){if(!(c.tag!==5&&c.tag!==3&&c.tag!==27||c!==t&&c.alternate!==t)){c=!0;break e}c=c.return}c=!1}return c}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!c)&&!(t=c===n)&&(t=ur(n,c,_f),t===null?t=!1:(He(t,!0,kv,c,n),c=vo,vo=null,t=c!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!c)&&!(t=c===o)&&(t=ur(o,c,_f),t===null?t=!1:(He(t,!0,wv,c,o),c=vo,rr=vo=null,t=c!==null)),t):!1}function Is(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}Fe.prototype.scrollIntoView=function(e){if(typeof e=="object")throw Error(h(566));var t=[];He(this._fragmentFiber.child,!1,fd,t,void 0,void 0);var n=e!==!1;if(t.length===0){var o=hb(this._fragmentFiber);if(o=n?o[1]||o[0]||Pn(this._fragmentFiber):o[0]||o[1],o===null)return;if(o.tag===6){e=fe(o),Is(e,n);return}if(o=fe(o),o.nodeType!==9){if(o.nodeType===11){n="host"in o?o.host:null,n!==null&&n.scrollIntoView(e);return}o.scrollIntoView(e)}}for(o=n?t.length-1:0;o!==(n?-1:t.length);){var a=t[o];a.tag===6?(a=fe(a),Is(a,n)):fe(a).scrollIntoView(e),o+=n?-1:1}};function K0(e,t){return e=fe(e),$g(e,t),!1}function $g(e,t){e.reactFragments==null&&(e.reactFragments=new Set),e.reactFragments.add(t)}function Ig(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.addEventListener(a.type,a.attachedListener,Ko(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(c){for(var l=0,i=0;i<dt.length;i++){var r=dt[i];(r.fragmentInstance!==t||r.observer!==c||r.instance!==e)&&(dt[l++]=r)}dt.length=l,c.observe(e)}),$g(e,t))}function J0(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.removeEventListener(a.type,a.attachedListener,Ko(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(c){typeof c.rootMargin=="string"?Q0(t,c,e):c.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function bu(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":bu(n),Vl(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(n.rel.toLowerCase()==="stylesheet")continue}e.removeChild(n)}}function F0(e,t,n,o){for(;e.nodeType===1;){var a=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[cc])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(c=e.getAttribute("rel"),c==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(c!==a.rel||e.getAttribute("href")!==(a.href==null||a.href===""?null:a.href)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin)||e.getAttribute("title")!==(a.title==null?null:a.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(c=e.getAttribute("src"),(c!==(a.src==null?null:a.src)||e.getAttribute("type")!==(a.type==null?null:a.type)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin))&&c&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var c=a.name==null?null:""+a.name;if(a.type==="hidden"&&e.getAttribute("name")===c)return e}else return e;if(e=at(e.nextSibling),e===null)break}return null}function W0(e,t,n){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=at(e.nextSibling),e===null))return null;return e}function Pg(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=at(e.nextSibling),e===null))return null;return e}function mu(e){return e.data==="$?"||e.data==="$~"}function sd(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function $0(e,t){var n=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||n.readyState!=="loading")t();else{var o=function(){t(),n.removeEventListener("DOMContentLoaded",o)};n.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function at(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var gu=null;function Ps(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"||n==="/&"){if(t===0)return at(e.nextSibling);t--}else n!=="$"&&n!=="$!"&&n!=="$?"&&n!=="$~"&&n!=="&"||t++}e=e.nextSibling}return null}function eb(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"){if(t===0)return e;t--}else n!=="/$"&&n!=="/&"||t++}e=e.previousSibling}return null}function I0(e,t){function n(){o=!0}if(e.ownerDocument.activeElement===e)return!0;var o=!1;try{e.ownerDocument.addEventListener("focus",n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener("focus",n,!0)}return o}function P0(e){Js(function(){Js(function(t){return e(t)})})}function ep(e,t,n){switch(t=Wa(n),e){case"html":if(e=t.documentElement,!e)throw Error(h(452));return e;case"head":if(e=t.head,!e)throw Error(h(453));return e;case"body":if(e=t.body,!e)throw Error(h(454));return e;default:throw Error(h(451))}}function tp(e,t,n){for(var o in n){var a=n[o];n.hasOwnProperty(o)&&a!=null&&j(e,t,o,null,O0,a)}n.dangerouslySetInnerHTML!=null&&(e.textContent=""),e.onclick===kt&&(e.onclick=null),Vl(e)}function ir(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);Vl(e)}var ct=new Map,tb=new Set;function $a(e){if(typeof e.getRootNode=="function"){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var Jt=Y.d;Y.d={f:ey,r:ty,D:ny,C:oy,L:ay,m:cy,X:iy,S:ly,M:ry};function ey(){var e=Jt.f(),t=ti();return e||t}function ty(e){var t=Po(e);t!==null&&t.tag===5&&t.type==="form"?Ym(t):Jt.r(e)}var oa=typeof document>"u"?null:document;function np(e,t,n){var o=oa;if(o&&typeof t=="string"&&t){var a=tt(t);a='link[rel="'+e+'"][href="'+a+'"]',typeof n=="string"&&(a+='[crossorigin="'+n+'"]'),tb.has(a)||(tb.add(a),e={rel:e,crossOrigin:n,href:t},o.querySelector(a)===null&&(t=o.createElement("link"),ke(t,"link",e),ge(t),o.head.appendChild(t)))}}function ny(e){Jt.D(e),np("dns-prefetch",e,null)}function oy(e,t){Jt.C(e,t),np("preconnect",e,t)}function ay(e,t,n){Jt.L(e,t,n);var o=oa;if(o&&e&&t){var a='link[rel="preload"][as="'+tt(t)+'"]';t==="image"&&n&&n.imageSrcSet?(a+='[imagesrcset="'+tt(n.imageSrcSet)+'"]',typeof n.imageSizes=="string"&&(a+='[imagesizes="'+tt(n.imageSizes)+'"]')):a+='[href="'+tt(e)+'"]';var c=a;switch(t){case"style":c=Jo(e);break;case"script":c=aa(e)}if(!(ct.has(c)||(e=J({rel:"preload",href:t==="image"&&n&&n.imageSrcSet?void 0:e,as:t},n),ct.set(c,e),o.querySelector(a)!==null||t==="style"&&o.querySelector(fc(c))||t==="script"&&o.querySelector(sc(c))))){var l=o.createElement("link");ke(l,"link",e),t==="style"&&(l[gl]=!0,l.onload=l.onerror=function(){_b(l)}),ge(l),o.head.appendChild(l)}}}function cy(e,t){Jt.m(e,t);var n=oa;if(n&&e){var o=t&&typeof t.as=="string"?t.as:"script",a='link[rel="modulepreload"][as="'+tt(o)+'"][href="'+tt(e)+'"]',c=a;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":c=aa(e)}if(!ct.has(c)&&(e=J({rel:"modulepreload",href:e},t),ct.set(c,e),n.querySelector(a)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector(sc(c)))return}o=n.createElement("link"),ke(o,"link",e),ge(o),n.head.appendChild(o)}}}function ly(e,t,n){Jt.S(e,t,n);var o=oa;if(o&&e){var a=Co(o).hoistableStyles,c=Jo(e);t=t||"default";var l=a.get(c);if(!l){var i={loading:0,preload:null};if(l=o.querySelector(fc(c)))i.loading=5;else{e=J({rel:"stylesheet",href:e,"data-precedence":t},n),(n=ct.get(c))&&bd(e,n);var r=l=o.createElement("link");ge(r),ke(r,"link",e),r._p=new Promise(function(u,m){r.onload=u,r.onerror=m}),r.addEventListener("load",function(){i.loading|=1}),r.addEventListener("error",function(){i.loading|=2}),i.loading|=4,ll(l,t,o)}l={type:"stylesheet",instance:l,count:1,state:i},a.set(c,l)}}}function iy(e,t){Jt.X(e,t);var n=oa;if(n&&e){var o=Co(n).hoistableScripts,a=aa(e),c=o.get(a);c||(c=n.querySelector(sc(a)),c||(e=J({src:e,async:!0},t),(t=ct.get(a))&&md(e,t),c=n.createElement("script"),ge(c),ke(c,"link",e),n.head.appendChild(c)),c={type:"script",instance:c,count:1,state:null},o.set(a,c))}}function ry(e,t){Jt.M(e,t);var n=oa;if(n&&e){var o=Co(n).hoistableScripts,a=aa(e),c=o.get(a);c||(c=n.querySelector(sc(a)),c||(e=J({src:e,async:!0,type:"module"},t),(t=ct.get(a))&&md(e,t),c=n.createElement("script"),ge(c),ke(c,"link",e),n.head.appendChild(c)),c={type:"script",instance:c,count:1,state:null},o.set(a,c))}}function nb(e,t,n,o){var a=(a=bn.current)?$a(a):null;if(!a)throw Error(h(446));switch(e){case"meta":case"title":return null;case"style":return typeof n.precedence=="string"&&typeof n.href=="string"?(n=Jo(n.href),t=Co(a).hoistableStyles,o=t.get(n),o||(o={type:"style",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(n.rel==="stylesheet"&&typeof n.href=="string"&&typeof n.precedence=="string"){e=Jo(n.href);var c=Co(a).hoistableStyles,l=c.get(e);if(l||(a=a.ownerDocument||a,l={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},c.set(e,l),(c=a.querySelector(fc(e)))?c._p||(l.instance=c,l.state.loading=5):(c=ct.get(e),c||(c={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},ct.set(e,c)),uy(a,e,c,l.state))),t&&o===null)throw Error(h(528,""));return l}if(t&&o!==null)throw Error(h(529,""));return null;case"script":return t=n.async,n=n.src,typeof n=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(n=aa(n),t=Co(a).hoistableScripts,o=t.get(n),o||(o={type:"script",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(h(444,e))}}function Jo(e){return'href="'+tt(e)+'"'}function fc(e){return'link[rel="stylesheet"]['+e+"]"}function op(e){return J({},e,{"data-precedence":e.precedence,precedence:null})}function uy(e,t,n,o){if(t=e.querySelector('link[rel="preload"][as="style"]['+t+"]")){if(t[gl]!==!0){o.loading=1;return}}else t=e.createElement("link"),t[gl]=!0,t.onload=t.onerror=_b.bind(null,t),ke(t,"link",n),ge(t),e.head.appendChild(t);o.preload=t,t.addEventListener("load",function(){return o.loading|=1}),t.addEventListener("error",function(){return o.loading|=2})}function aa(e){return'[src="'+tt(e)+'"]'}function sc(e){return"script[async]"+e}function ob(e,t,n){if(t.count++,t.instance===null)switch(t.type){case"style":var o=e.querySelector('style[data-href~="'+tt(n.href)+'"]');if(o)return t.instance=o,ge(o),o;var a=J({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),ge(o),ke(o,"style",a),ll(o,n.precedence,e),t.instance=o;case"stylesheet":a=Jo(n.href);var c=e.querySelector(fc(a));if(c)return t.state.loading|=4,t.instance=c,ge(c),c;o=op(n),(a=ct.get(a))&&bd(o,a),c=(e.ownerDocument||e).createElement("link"),ge(c);var l=c;return l._p=new Promise(function(i,r){l.onload=i,l.onerror=r}),ke(c,"link",o),t.state.loading|=4,ll(c,n.precedence,e),t.instance=c;case"script":return c=aa(n.src),(a=e.querySelector(sc(c)))?(t.instance=a,ge(a),a):(o=n,(a=ct.get(c))&&(o=J({},n),md(o,a)),e=e.ownerDocument||e,a=e.createElement("script"),ge(a),ke(a,"link",o),e.head.appendChild(a),t.instance=a);case"void":return null;default:throw Error(h(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(o=t.instance,t.state.loading|=4,ll(o,n.precedence,e));return t.instance}function ll(e,t,n){for(var o=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),a=o.length?o[o.length-1]:null,c=a,l=0;l<o.length;l++){var i=o[l];if(i.dataset.precedence===t)c=i;else if(c!==a)break}c?c.parentNode.insertBefore(e,c.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function bd(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function md(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var il=null;function ab(e,t,n){if(il===null){var o=new Map,a=il=new Map;a.set(n,o)}else a=il,o=a.get(n),o||(o=new Map,a.set(n,o));if(o.has(e))return o;for(o.set(e,null),n=n.getElementsByTagName(e),a=0;a<n.length;a++){var c=n[a];if(!(c[cc]||c[he]||e==="link"&&c.getAttribute("rel")==="stylesheet")&&c.namespaceURI!=="http://www.w3.org/2000/svg"){var l=c.getAttribute(t)||"";l=e+l;var i=o.get(l);i?i.push(c):o.set(l,[c])}}return o}function pu(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t==="title"?e.querySelector("head > title"):null)}function dy(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function cb(e,t){return e==="img"&&t.src!=null&&t.src!==""&&t.onLoad==null&&t.loading!=="lazy"}function ap(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function cp(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function lb(e,t){typeof t.decode=="function"&&(e.imgCount++,t.complete||(e.imgBytes+=cp(t),e.suspenseyImages.push(t)),e=by.bind(e),t.decode().then(e,e))}function fy(e,t,n,o){if(n.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var a=Jo(o.href),c=t.querySelector(fc(a));if(c){t=c._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=Ia.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=c,ge(c);return}c=t.ownerDocument||t,o=op(o),(a=ct.get(a))&&bd(o,a),c=c.createElement("link"),ge(c);var l=c;l._p=new Promise(function(i,r){l.onload=i,l.onerror=r}),ke(c,"link",o),n.instance=c}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(e.count++,n=Ia.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}var rl=0;function sy(e,t){return e.stylesheets&&e.count===0&&ul(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var o=setTimeout(function(){if(e.stylesheets&&ul(e,e.stylesheets),e.unsuspend){var c=e.unsuspend;e.unsuspend=null,c()}},6e4+t);0<e.imgBytes&&rl===0&&(rl=62500*A0());var a=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&ul(e,e.stylesheets),e.unsuspend)){var c=e.unsuspend;e.unsuspend=null,c()}},(e.imgBytes>rl?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(a)}}:null}function lp(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)ul(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function Ia(){this.count--,lp(this)}function by(){this.imgCount--,lp(this)}var ql=null;function ul(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,ql=new Map,t.forEach(my,e),ql=null,Ia.call(e))}function my(e,t){if(!(t.state.loading&4)){var n=ql.get(e);if(n)var o=n.get(null);else{n=new Map,ql.set(e,n);for(var a=e.querySelectorAll("link[data-precedence],style[data-precedence]"),c=0;c<a.length;c++){var l=a[c];(l.nodeName==="LINK"||l.getAttribute("media")!=="not all")&&(n.set(l.dataset.precedence,l),o=l)}o&&n.set(null,o)}a=t.instance,l=a.getAttribute("data-precedence"),c=n.get(l)||o,c===o&&n.set(null,a),n.set(l,a),this.count++,o=Ia.bind(this),a.addEventListener("load",o),a.addEventListener("error",o),c?c.parentNode.insertBefore(a,c.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(a,e.firstChild)),t.state.loading|=4}}var Fo={$$typeof:xt,Provider:null,Consumer:null,_currentValue:Ln,_currentValue2:Ln,_threadCount:0};function gy(e,t,n,o,a,c,l,i,r){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Ui(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ui(0),this.hiddenUpdates=Ui(null),this.identifierPrefix=o,this.onUncaughtError=a,this.onCaughtError=c,this.onRecoverableError=l,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=r,this.transitionTypes=null,this.incompleteTransitions=new Map}function ip(e,t,n,o,a,c,l,i,r,u,m,p){return e=new gy(e,t,n,l,r,u,m,p,i),t=1,c===!0&&(t|=24),c=Ue(3,null,null,t),e.current=c,c.stateNode=e,t=Ru(),t.refCount++,e.pooledCache=t,t.refCount++,c.memoizedState={element:o,isDehydrated:n,cache:t},Hu(c),e}function rp(e){return e?(e=Eo,e):Eo}function up(e,t,n,o,a,c){a=rp(a),o.context===null?o.context=a:o.pendingContext=a,o=gn(t),o.payload={element:n},c=c===void 0?null:c,c!==null&&(o.callback=c),n=pn(e,o,t),n!==null&&(Be(n,e,t),Aa(n,e,t))}function ib(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function gd(e,t){ib(e,t),(e=e.alternate)&&ib(e,t)}function dp(e){if(e.tag===13||e.tag===31){var t=no(e,67108864);t!==null&&Be(t,e,67108864),gd(e,67108864)}}function rb(e){if(e.tag===13||e.tag===31){var t=Ke();t=ku(t);var n=no(e,t);n!==null&&Be(n,e,t),gd(e,t)}}var Wo=!0;function py(e,t,n,o){var a=N.T;N.T=null;var c=Y.p;try{Y.p=2,pd(e,t,n,o)}finally{Y.p=c,N.T=a}}function vy(e,t,n,o){var a=N.T;N.T=null;var c=Y.p;try{Y.p=8,pd(e,t,n,o)}finally{Y.p=c,N.T=a}}function pd(e,t,n,o){if(Wo){var a=vu(o);if(a===null)ar(e,t,o,Yl,n),ub(e,o);else if(yy(a,e,t,n,o))o.stopPropagation();else if(ub(e,o),t&4&&-1<hy.indexOf(e)){for(;a!==null;){var c=Po(a);if(c!==null)switch(c.tag){case 3:if(c=c.stateNode,c.current.memoizedState.isDehydrated){var l=Un(c.pendingLanes);if(l!==0){var i=c;for(i.pendingLanes|=2,i.entangledLanes|=2;l;){var r=1<<31-Ze(l);i.entanglements[1]|=r,l&=~r}Ct(c),(q&6)===0&&(Dl=Qe()+500,dc(0,!1))}}break;case 31:case 13:i=no(c,2),i!==null&&Be(i,c,2),ti(),gd(c,2)}if(c=vu(o),c===null&&ar(e,t,o,Yl,n),c===a)break;a=c}a!==null&&o.stopPropagation()}else ar(e,t,o,null,n)}}function vu(e){return e=Eu(e),vd(e)}var Yl=null;function vd(e){if(Yl=null,e=qn(e),e!==null){var t=tc(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=gb(t),e!==null)return e;e=null}else if(n===31){if(e=pb(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return Yl=e,null}function fp(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Mv()){case kb:return 2;case wb:return 8;case ml:case Dv:return 32;case Tb:return 268435456;default:return 32}default:return 32}}var hu=!1,Sn=null,xn=null,kn=null,Pa=new Map,ec=new Map,cn=[],hy="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function ub(e,t){switch(e){case"focusin":case"focusout":Sn=null;break;case"dragenter":case"dragleave":xn=null;break;case"mouseover":case"mouseout":kn=null;break;case"pointerover":case"pointerout":Pa.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":ec.delete(t.pointerId)}}function ya(e,t,n,o,a,c){return e===null||e.nativeEvent!==c?(e={blockedOn:t,domEventName:n,eventSystemFlags:o,nativeEvent:c,targetContainers:[a]},t!==null&&(t=Po(t),t!==null&&dp(t)),e):(e.eventSystemFlags|=o,t=e.targetContainers,a!==null&&t.indexOf(a)===-1&&t.push(a),e)}function yy(e,t,n,o,a){switch(t){case"focusin":return Sn=ya(Sn,e,t,n,o,a),!0;case"dragenter":return xn=ya(xn,e,t,n,o,a),!0;case"mouseover":return kn=ya(kn,e,t,n,o,a),!0;case"pointerover":var c=a.pointerId;return Pa.set(c,ya(Pa.get(c)||null,e,t,n,o,a)),!0;case"gotpointercapture":return c=a.pointerId,ec.set(c,ya(ec.get(c)||null,e,t,n,o,a)),!0}return!1}function sp(e){var t=qn(e.target);if(t!==null){var n=tc(t);if(n!==null){if(t=n.tag,t===13){if(t=gb(n),t!==null){e.blockedOn=t,Uf(e.priority,function(){rb(n)});return}}else if(t===31){if(t=pb(n),t!==null){e.blockedOn=t,Uf(e.priority,function(){rb(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function dl(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=vu(e.nativeEvent);if(n===null){n=e.nativeEvent;var o=new n.constructor(n.type,n);xr=o,n.target.dispatchEvent(o),xr=null}else return t=Po(n),t!==null&&dp(t),e.blockedOn=n,!1;t.shift()}return!0}function db(e,t,n){dl(e)&&n.delete(t)}function Sy(){hu=!1,Sn!==null&&dl(Sn)&&(Sn=null),xn!==null&&dl(xn)&&(xn=null),kn!==null&&dl(kn)&&(kn=null),Pa.forEach(db),ec.forEach(db)}function Qc(e,t){e.blockedOn===t&&(e.blockedOn=null,hu||(hu=!0,se.unstable_scheduleCallback(se.unstable_NormalPriority,Sy)))}var Xc=null;function fb(e){Xc!==e&&(Xc=e,se.unstable_scheduleCallback(se.unstable_NormalPriority,function(){Xc===e&&(Xc=null);for(var t=0;t<e.length;t+=3){var n=e[t],o=e[t+1],a=e[t+2];if(typeof o!="function"){if(vd(o||n)===null)continue;break}var c=Po(n);c!==null&&(e.splice(t,3),t-=3,Hr(c,{pending:!0,data:a,method:n.method,action:o},o,a))}}))}function $o(e){function t(r){return Qc(r,e)}Sn!==null&&Qc(Sn,e),xn!==null&&Qc(xn,e),kn!==null&&Qc(kn,e),Pa.forEach(t),ec.forEach(t);for(var n=0;n<cn.length;n++){var o=cn[n];o.blockedOn===e&&(o.blockedOn=null)}for(;0<cn.length&&(n=cn[0],n.blockedOn===null);)sp(n),n.blockedOn===null&&cn.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(o=0;o<n.length;o+=3){var a=n[o],c=n[o+1],l=a[qe]||null;if(typeof c=="function")l||fb(n);else if(l){var i=null;if(c&&c.hasAttribute("formAction")){if(a=c,l=c[qe]||null)i=l.formAction;else if(vd(a)!==null)continue}else i=l.action;typeof i=="function"?n[o+1]=i:(n.splice(o,3),o-=3),fb(n)}}}function bp(){function e(c){c.canIntercept&&c.info==="react-transition"&&c.intercept({handler:function(){return new Promise(function(l){return a=l})},focusReset:"manual",scroll:"manual"})}function t(){a!==null&&(a(),a=null),o||setTimeout(n,20)}function n(){if(!o&&!navigation.transition){var c=navigation.currentEntry;c&&c.url!=null&&navigation.navigate(c.url,{state:c.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,a=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),a!==null&&(a(),a=null)}}}function hd(e){this._internalRoot=e}ai.prototype.render=hd.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(h(409));var n=t.current,o=Ke();up(n,o,e,t,null,null)};ai.prototype.unmount=hd.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;up(e.current,2,null,e,null,null),ti(),t[Io]=null}};function ai(e){this._internalRoot=e}ai.prototype.unstable_scheduleHydration=function(e){if(e){var t=Ab();e={blockedOn:null,target:e,priority:t};for(var n=0;n<cn.length&&t!==0&&t<cn[n].priority;n++);cn.splice(n,0,e),n===0&&sp(e)}};var sb=bb.version;if(sb!=="19.3.0")throw Error(h(527,sb,"19.3.0"));Y.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(h(188)):(e=Object.keys(e).join(","),Error(h(268,e)));return e=xv(t),e=e!==null?vb(e):null,e=e===null?null:e.stateNode,e};var xy={bundleType:0,version:"19.3.0",rendererPackageName:"react-dom",currentDispatcherRef:N,reconcilerVersion:"19.3.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(Sa=__REACT_DEVTOOLS_GLOBAL_HOOK__,!Sa.isDisabled&&Sa.supportsFiber))try{nc=Sa.inject(xy),Xe=Sa}catch{}var Sa;ci.createRoot=function(e,t){if(!mb(e))throw Error(h(299));var n=!1,o="",a=Km,c=Jm,l=Fm;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(o=t.identifierPrefix),t.onUncaughtError!==void 0&&(a=t.onUncaughtError),t.onCaughtError!==void 0&&(c=t.onCaughtError),t.onRecoverableError!==void 0&&(l=t.onRecoverableError)),t=ip(e,1,!1,null,null,n,o,null,a,c,l,bp),e[Io]=t.current,ud(e),new hd(t)};ci.hydrateRoot=function(e,t,n){if(!mb(e))throw Error(h(299));var o=!1,a="",c=Km,l=Jm,i=Fm,r=null;return n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(a=n.identifierPrefix),n.onUncaughtError!==void 0&&(c=n.onUncaughtError),n.onCaughtError!==void 0&&(l=n.onCaughtError),n.onRecoverableError!==void 0&&(i=n.onRecoverableError),n.formState!==void 0&&(r=n.formState)),t=ip(e,1,!0,t,n??null,o,a,r,c,l,i,bp),t.context=rp(null),n=t.current,o=Ke(),o=ku(o),a=gn(o),a.callback=null,pn(n,a,o),n=o,t.current.lanes=n,ac(t,n),Ct(t),e[Io]=t.current,ud(e),new ai(t)};ci.version="19.3.0"});var vp=bt((d1,pp)=>{"use strict";function gp(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(gp)}catch(e){console.error(e)}}gp(),pp.exports=mp()});var xd=`/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

@font-face {
	font-family: "codicon";
	font-display: block;
	src: url("./codicon.ttf?9aab6318a6710999273bab9c78a9fd71") format("truetype");
}

.codicon[class*='codicon-'] {
	font: normal normal normal 16px/1 codicon;
	display: inline-block;
	text-decoration: none;
	text-rendering: auto;
	text-align: center;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	user-select: none;
	-webkit-user-select: none;
	-ms-user-select: none;
}

/*---------------------
 *  Modifiers
 *-------------------*/

@keyframes codicon-spin {
	100% {
		transform:rotate(360deg);
	}
}

.codicon-sync.codicon-modifier-spin,
.codicon-loading.codicon-modifier-spin,
.codicon-gear.codicon-modifier-spin {
	/* Use steps to throttle FPS to reduce CPU usage */
	animation: codicon-spin 1.5s steps(30) infinite;
}

.codicon-modifier-disabled {
	opacity: 0.5;
}

.codicon-modifier-hidden {
	opacity: 0;
}

/* custom speed & easing for loading icon */
.codicon-loading {
	animation-duration: 1s !important;
	animation-timing-function: cubic-bezier(0.53, 0.21, 0.29, 0.67) !important;
}

/*---------------------
 *  Icons
 *-------------------*/

.codicon-add:before { content: "\\ea60" }
.codicon-plus:before { content: "\\ea60" }
.codicon-gist-new:before { content: "\\ea60" }
.codicon-repo-create:before { content: "\\ea60" }
.codicon-lightbulb:before { content: "\\ea61" }
.codicon-light-bulb:before { content: "\\ea61" }
.codicon-repo:before { content: "\\ea62" }
.codicon-repo-delete:before { content: "\\ea62" }
.codicon-gist-fork:before { content: "\\ea63" }
.codicon-repo-forked:before { content: "\\ea63" }
.codicon-git-pull-request:before { content: "\\ea64" }
.codicon-git-pull-request-abandoned:before { content: "\\ea64" }
.codicon-record-keys:before { content: "\\ea65" }
.codicon-keyboard:before { content: "\\ea65" }
.codicon-tag:before { content: "\\ea66" }
.codicon-git-pull-request-label:before { content: "\\ea66" }
.codicon-tag-add:before { content: "\\ea66" }
.codicon-tag-remove:before { content: "\\ea66" }
.codicon-person:before { content: "\\ea67" }
.codicon-person-follow:before { content: "\\ea67" }
.codicon-person-outline:before { content: "\\ea67" }
.codicon-person-filled:before { content: "\\ea67" }
.codicon-source-control:before { content: "\\ea68" }
.codicon-mirror:before { content: "\\ea69" }
.codicon-mirror-public:before { content: "\\ea69" }
.codicon-star:before { content: "\\ea6a" }
.codicon-star-add:before { content: "\\ea6a" }
.codicon-star-delete:before { content: "\\ea6a" }
.codicon-star-empty:before { content: "\\ea6a" }
.codicon-comment:before { content: "\\ea6b" }
.codicon-comment-add:before { content: "\\ea6b" }
.codicon-alert:before { content: "\\ea6c" }
.codicon-warning:before { content: "\\ea6c" }
.codicon-search:before { content: "\\ea6d" }
.codicon-search-save:before { content: "\\ea6d" }
.codicon-log-out:before { content: "\\ea6e" }
.codicon-sign-out:before { content: "\\ea6e" }
.codicon-log-in:before { content: "\\ea6f" }
.codicon-sign-in:before { content: "\\ea6f" }
.codicon-eye:before { content: "\\ea70" }
.codicon-eye-unwatch:before { content: "\\ea70" }
.codicon-eye-watch:before { content: "\\ea70" }
.codicon-circle-filled:before { content: "\\ea71" }
.codicon-primitive-dot:before { content: "\\ea71" }
.codicon-close-dirty:before { content: "\\ea71" }
.codicon-debug-breakpoint:before { content: "\\ea71" }
.codicon-debug-breakpoint-disabled:before { content: "\\ea71" }
.codicon-debug-hint:before { content: "\\ea71" }
.codicon-terminal-decoration-success:before { content: "\\ea71" }
.codicon-primitive-square:before { content: "\\ea72" }
.codicon-edit:before { content: "\\ea73" }
.codicon-pencil:before { content: "\\ea73" }
.codicon-info:before { content: "\\ea74" }
.codicon-issue-opened:before { content: "\\ea74" }
.codicon-gist-private:before { content: "\\ea75" }
.codicon-git-fork-private:before { content: "\\ea75" }
.codicon-lock:before { content: "\\ea75" }
.codicon-mirror-private:before { content: "\\ea75" }
.codicon-close:before { content: "\\ea76" }
.codicon-remove-close:before { content: "\\ea76" }
.codicon-x:before { content: "\\ea76" }
.codicon-repo-sync:before { content: "\\ea77" }
.codicon-sync:before { content: "\\ea77" }
.codicon-clone:before { content: "\\ea78" }
.codicon-desktop-download:before { content: "\\ea78" }
.codicon-beaker:before { content: "\\ea79" }
.codicon-microscope:before { content: "\\ea79" }
.codicon-vm:before { content: "\\ea7a" }
.codicon-device-desktop:before { content: "\\ea7a" }
.codicon-file:before { content: "\\ea7b" }
.codicon-more:before { content: "\\ea7c" }
.codicon-ellipsis:before { content: "\\ea7c" }
.codicon-kebab-horizontal:before { content: "\\ea7c" }
.codicon-mail-reply:before { content: "\\ea7d" }
.codicon-reply:before { content: "\\ea7d" }
.codicon-organization:before { content: "\\ea7e" }
.codicon-organization-filled:before { content: "\\ea7e" }
.codicon-organization-outline:before { content: "\\ea7e" }
.codicon-new-file:before { content: "\\ea7f" }
.codicon-file-add:before { content: "\\ea7f" }
.codicon-new-folder:before { content: "\\ea80" }
.codicon-file-directory-create:before { content: "\\ea80" }
.codicon-trash:before { content: "\\ea81" }
.codicon-trashcan:before { content: "\\ea81" }
.codicon-history:before { content: "\\ea82" }
.codicon-clock:before { content: "\\ea82" }
.codicon-folder:before { content: "\\ea83" }
.codicon-file-directory:before { content: "\\ea83" }
.codicon-symbol-folder:before { content: "\\ea83" }
.codicon-logo-github:before { content: "\\ea84" }
.codicon-mark-github:before { content: "\\ea84" }
.codicon-github:before { content: "\\ea84" }
.codicon-terminal:before { content: "\\ea85" }
.codicon-console:before { content: "\\ea85" }
.codicon-repl:before { content: "\\ea85" }
.codicon-zap:before { content: "\\ea86" }
.codicon-symbol-event:before { content: "\\ea86" }
.codicon-error:before { content: "\\ea87" }
.codicon-stop:before { content: "\\ea87" }
.codicon-variable:before { content: "\\ea88" }
.codicon-symbol-variable:before { content: "\\ea88" }
.codicon-array:before { content: "\\ea8a" }
.codicon-symbol-array:before { content: "\\ea8a" }
.codicon-symbol-module:before { content: "\\ea8b" }
.codicon-symbol-package:before { content: "\\ea8b" }
.codicon-symbol-namespace:before { content: "\\ea8b" }
.codicon-symbol-object:before { content: "\\ea8b" }
.codicon-symbol-method:before { content: "\\ea8c" }
.codicon-symbol-function:before { content: "\\ea8c" }
.codicon-symbol-constructor:before { content: "\\ea8c" }
.codicon-symbol-boolean:before { content: "\\ea8f" }
.codicon-symbol-null:before { content: "\\ea8f" }
.codicon-symbol-numeric:before { content: "\\ea90" }
.codicon-symbol-number:before { content: "\\ea90" }
.codicon-symbol-structure:before { content: "\\ea91" }
.codicon-symbol-struct:before { content: "\\ea91" }
.codicon-symbol-parameter:before { content: "\\ea92" }
.codicon-symbol-type-parameter:before { content: "\\ea92" }
.codicon-symbol-key:before { content: "\\ea93" }
.codicon-symbol-text:before { content: "\\ea93" }
.codicon-symbol-reference:before { content: "\\ea94" }
.codicon-go-to-file:before { content: "\\ea94" }
.codicon-symbol-enum:before { content: "\\ea95" }
.codicon-symbol-value:before { content: "\\ea95" }
.codicon-symbol-ruler:before { content: "\\ea96" }
.codicon-symbol-unit:before { content: "\\ea96" }
.codicon-activate-breakpoints:before { content: "\\ea97" }
.codicon-archive:before { content: "\\ea98" }
.codicon-arrow-both:before { content: "\\ea99" }
.codicon-arrow-down:before { content: "\\ea9a" }
.codicon-arrow-left:before { content: "\\ea9b" }
.codicon-arrow-right:before { content: "\\ea9c" }
.codicon-arrow-small-down:before { content: "\\ea9d" }
.codicon-arrow-small-left:before { content: "\\ea9e" }
.codicon-arrow-small-right:before { content: "\\ea9f" }
.codicon-arrow-small-up:before { content: "\\eaa0" }
.codicon-arrow-up:before { content: "\\eaa1" }
.codicon-bell:before { content: "\\eaa2" }
.codicon-bold:before { content: "\\eaa3" }
.codicon-book:before { content: "\\eaa4" }
.codicon-bookmark:before { content: "\\eaa5" }
.codicon-debug-breakpoint-conditional-unverified:before { content: "\\eaa6" }
.codicon-debug-breakpoint-conditional:before { content: "\\eaa7" }
.codicon-debug-breakpoint-conditional-disabled:before { content: "\\eaa7" }
.codicon-debug-breakpoint-data-unverified:before { content: "\\eaa8" }
.codicon-debug-breakpoint-data:before { content: "\\eaa9" }
.codicon-debug-breakpoint-data-disabled:before { content: "\\eaa9" }
.codicon-debug-breakpoint-log-unverified:before { content: "\\eaaa" }
.codicon-debug-breakpoint-log:before { content: "\\eaab" }
.codicon-debug-breakpoint-log-disabled:before { content: "\\eaab" }
.codicon-briefcase:before { content: "\\eaac" }
.codicon-broadcast:before { content: "\\eaad" }
.codicon-browser:before { content: "\\eaae" }
.codicon-bug:before { content: "\\eaaf" }
.codicon-calendar:before { content: "\\eab0" }
.codicon-case-sensitive:before { content: "\\eab1" }
.codicon-check:before { content: "\\eab2" }
.codicon-checklist:before { content: "\\eab3" }
.codicon-chevron-down:before { content: "\\eab4" }
.codicon-chevron-left:before { content: "\\eab5" }
.codicon-chevron-right:before { content: "\\eab6" }
.codicon-chevron-up:before { content: "\\eab7" }
.codicon-chrome-close:before { content: "\\eab8" }
.codicon-chrome-maximize:before { content: "\\eab9" }
.codicon-chrome-minimize:before { content: "\\eaba" }
.codicon-chrome-restore:before { content: "\\eabb" }
.codicon-circle-outline:before { content: "\\eabc" }
.codicon-circle:before { content: "\\eabc" }
.codicon-debug-breakpoint-unverified:before { content: "\\eabc" }
.codicon-terminal-decoration-incomplete:before { content: "\\eabc" }
.codicon-circle-slash:before { content: "\\eabd" }
.codicon-circuit-board:before { content: "\\eabe" }
.codicon-clear-all:before { content: "\\eabf" }
.codicon-clippy:before { content: "\\eac0" }
.codicon-close-all:before { content: "\\eac1" }
.codicon-cloud-download:before { content: "\\eac2" }
.codicon-cloud-upload:before { content: "\\eac3" }
.codicon-code:before { content: "\\eac4" }
.codicon-collapse-all:before { content: "\\eac5" }
.codicon-color-mode:before { content: "\\eac6" }
.codicon-comment-discussion:before { content: "\\eac7" }
.codicon-credit-card:before { content: "\\eac9" }
.codicon-dash:before { content: "\\eacc" }
.codicon-dashboard:before { content: "\\eacd" }
.codicon-database:before { content: "\\eace" }
.codicon-debug-continue:before { content: "\\eacf" }
.codicon-debug-disconnect:before { content: "\\ead0" }
.codicon-debug-pause:before { content: "\\ead1" }
.codicon-debug-restart:before { content: "\\ead2" }
.codicon-debug-start:before { content: "\\ead3" }
.codicon-debug-step-into:before { content: "\\ead4" }
.codicon-debug-step-out:before { content: "\\ead5" }
.codicon-debug-step-over:before { content: "\\ead6" }
.codicon-debug-stop:before { content: "\\ead7" }
.codicon-debug:before { content: "\\ead8" }
.codicon-device-camera-video:before { content: "\\ead9" }
.codicon-device-camera:before { content: "\\eada" }
.codicon-device-mobile:before { content: "\\eadb" }
.codicon-diff-added:before { content: "\\eadc" }
.codicon-diff-ignored:before { content: "\\eadd" }
.codicon-diff-modified:before { content: "\\eade" }
.codicon-diff-removed:before { content: "\\eadf" }
.codicon-diff-renamed:before { content: "\\eae0" }
.codicon-diff:before { content: "\\eae1" }
.codicon-diff-sidebyside:before { content: "\\eae1" }
.codicon-discard:before { content: "\\eae2" }
.codicon-editor-layout:before { content: "\\eae3" }
.codicon-empty-window:before { content: "\\eae4" }
.codicon-exclude:before { content: "\\eae5" }
.codicon-extensions:before { content: "\\eae6" }
.codicon-eye-closed:before { content: "\\eae7" }
.codicon-file-binary:before { content: "\\eae8" }
.codicon-file-code:before { content: "\\eae9" }
.codicon-file-media:before { content: "\\eaea" }
.codicon-file-pdf:before { content: "\\eaeb" }
.codicon-file-submodule:before { content: "\\eaec" }
.codicon-file-symlink-directory:before { content: "\\eaed" }
.codicon-file-symlink-file:before { content: "\\eaee" }
.codicon-file-zip:before { content: "\\eaef" }
.codicon-files:before { content: "\\eaf0" }
.codicon-filter:before { content: "\\eaf1" }
.codicon-flame:before { content: "\\eaf2" }
.codicon-fold-down:before { content: "\\eaf3" }
.codicon-fold-up:before { content: "\\eaf4" }
.codicon-fold:before { content: "\\eaf5" }
.codicon-folder-active:before { content: "\\eaf6" }
.codicon-folder-opened:before { content: "\\eaf7" }
.codicon-gear:before { content: "\\eaf8" }
.codicon-gift:before { content: "\\eaf9" }
.codicon-gist-secret:before { content: "\\eafa" }
.codicon-gist:before { content: "\\eafb" }
.codicon-git-commit:before { content: "\\eafc" }
.codicon-git-compare:before { content: "\\eafd" }
.codicon-compare-changes:before { content: "\\eafd" }
.codicon-git-merge:before { content: "\\eafe" }
.codicon-github-action:before { content: "\\eaff" }
.codicon-github-alt:before { content: "\\eb00" }
.codicon-globe:before { content: "\\eb01" }
.codicon-grabber:before { content: "\\eb02" }
.codicon-graph:before { content: "\\eb03" }
.codicon-gripper:before { content: "\\eb04" }
.codicon-heart:before { content: "\\eb05" }
.codicon-home:before { content: "\\eb06" }
.codicon-horizontal-rule:before { content: "\\eb07" }
.codicon-hubot:before { content: "\\eb08" }
.codicon-inbox:before { content: "\\eb09" }
.codicon-issue-reopened:before { content: "\\eb0b" }
.codicon-issues:before { content: "\\eb0c" }
.codicon-italic:before { content: "\\eb0d" }
.codicon-jersey:before { content: "\\eb0e" }
.codicon-json:before { content: "\\eb0f" }
.codicon-bracket:before { content: "\\eb0f" }
.codicon-kebab-vertical:before { content: "\\eb10" }
.codicon-key:before { content: "\\eb11" }
.codicon-law:before { content: "\\eb12" }
.codicon-lightbulb-autofix:before { content: "\\eb13" }
.codicon-link-external:before { content: "\\eb14" }
.codicon-link:before { content: "\\eb15" }
.codicon-list-ordered:before { content: "\\eb16" }
.codicon-list-unordered:before { content: "\\eb17" }
.codicon-live-share:before { content: "\\eb18" }
.codicon-loading:before { content: "\\eb19" }
.codicon-location:before { content: "\\eb1a" }
.codicon-mail-read:before { content: "\\eb1b" }
.codicon-mail:before { content: "\\eb1c" }
.codicon-markdown:before { content: "\\eb1d" }
.codicon-megaphone:before { content: "\\eb1e" }
.codicon-mention:before { content: "\\eb1f" }
.codicon-milestone:before { content: "\\eb20" }
.codicon-git-pull-request-milestone:before { content: "\\eb20" }
.codicon-mortar-board:before { content: "\\eb21" }
.codicon-move:before { content: "\\eb22" }
.codicon-multiple-windows:before { content: "\\eb23" }
.codicon-mute:before { content: "\\eb24" }
.codicon-no-newline:before { content: "\\eb25" }
.codicon-note:before { content: "\\eb26" }
.codicon-octoface:before { content: "\\eb27" }
.codicon-open-preview:before { content: "\\eb28" }
.codicon-package:before { content: "\\eb29" }
.codicon-paintcan:before { content: "\\eb2a" }
.codicon-pin:before { content: "\\eb2b" }
.codicon-play:before { content: "\\eb2c" }
.codicon-run:before { content: "\\eb2c" }
.codicon-plug:before { content: "\\eb2d" }
.codicon-preserve-case:before { content: "\\eb2e" }
.codicon-preview:before { content: "\\eb2f" }
.codicon-project:before { content: "\\eb30" }
.codicon-pulse:before { content: "\\eb31" }
.codicon-question:before { content: "\\eb32" }
.codicon-quote:before { content: "\\eb33" }
.codicon-radio-tower:before { content: "\\eb34" }
.codicon-reactions:before { content: "\\eb35" }
.codicon-references:before { content: "\\eb36" }
.codicon-refresh:before { content: "\\eb37" }
.codicon-regex:before { content: "\\eb38" }
.codicon-remote-explorer:before { content: "\\eb39" }
.codicon-remote:before { content: "\\eb3a" }
.codicon-remove:before { content: "\\eb3b" }
.codicon-replace-all:before { content: "\\eb3c" }
.codicon-replace:before { content: "\\eb3d" }
.codicon-repo-clone:before { content: "\\eb3e" }
.codicon-repo-force-push:before { content: "\\eb3f" }
.codicon-repo-pull:before { content: "\\eb40" }
.codicon-repo-push:before { content: "\\eb41" }
.codicon-report:before { content: "\\eb42" }
.codicon-request-changes:before { content: "\\eb43" }
.codicon-rocket:before { content: "\\eb44" }
.codicon-root-folder-opened:before { content: "\\eb45" }
.codicon-root-folder:before { content: "\\eb46" }
.codicon-rss:before { content: "\\eb47" }
.codicon-ruby:before { content: "\\eb48" }
.codicon-save-all:before { content: "\\eb49" }
.codicon-save-as:before { content: "\\eb4a" }
.codicon-save:before { content: "\\eb4b" }
.codicon-screen-full:before { content: "\\eb4c" }
.codicon-screen-normal:before { content: "\\eb4d" }
.codicon-search-stop:before { content: "\\eb4e" }
.codicon-server:before { content: "\\eb50" }
.codicon-settings-gear:before { content: "\\eb51" }
.codicon-settings:before { content: "\\eb52" }
.codicon-shield:before { content: "\\eb53" }
.codicon-smiley:before { content: "\\eb54" }
.codicon-sort-precedence:before { content: "\\eb55" }
.codicon-split-horizontal:before { content: "\\eb56" }
.codicon-split-vertical:before { content: "\\eb57" }
.codicon-squirrel:before { content: "\\eb58" }
.codicon-star-full:before { content: "\\eb59" }
.codicon-star-half:before { content: "\\eb5a" }
.codicon-symbol-class:before { content: "\\eb5b" }
.codicon-symbol-color:before { content: "\\eb5c" }
.codicon-symbol-constant:before { content: "\\eb5d" }
.codicon-symbol-enum-member:before { content: "\\eb5e" }
.codicon-symbol-field:before { content: "\\eb5f" }
.codicon-symbol-file:before { content: "\\eb60" }
.codicon-symbol-interface:before { content: "\\eb61" }
.codicon-symbol-keyword:before { content: "\\eb62" }
.codicon-symbol-misc:before { content: "\\eb63" }
.codicon-symbol-operator:before { content: "\\eb64" }
.codicon-symbol-property:before { content: "\\eb65" }
.codicon-wrench:before { content: "\\eb65" }
.codicon-wrench-subaction:before { content: "\\eb65" }
.codicon-symbol-snippet:before { content: "\\eb66" }
.codicon-tasklist:before { content: "\\eb67" }
.codicon-telescope:before { content: "\\eb68" }
.codicon-text-size:before { content: "\\eb69" }
.codicon-three-bars:before { content: "\\eb6a" }
.codicon-thumbsdown:before { content: "\\eb6b" }
.codicon-thumbsup:before { content: "\\eb6c" }
.codicon-tools:before { content: "\\eb6d" }
.codicon-triangle-down:before { content: "\\eb6e" }
.codicon-triangle-left:before { content: "\\eb6f" }
.codicon-triangle-right:before { content: "\\eb70" }
.codicon-triangle-up:before { content: "\\eb71" }
.codicon-twitter:before { content: "\\eb72" }
.codicon-unfold:before { content: "\\eb73" }
.codicon-unlock:before { content: "\\eb74" }
.codicon-unmute:before { content: "\\eb75" }
.codicon-unverified:before { content: "\\eb76" }
.codicon-verified:before { content: "\\eb77" }
.codicon-versions:before { content: "\\eb78" }
.codicon-vm-active:before { content: "\\eb79" }
.codicon-vm-outline:before { content: "\\eb7a" }
.codicon-vm-running:before { content: "\\eb7b" }
.codicon-watch:before { content: "\\eb7c" }
.codicon-whitespace:before { content: "\\eb7d" }
.codicon-whole-word:before { content: "\\eb7e" }
.codicon-window:before { content: "\\eb7f" }
.codicon-word-wrap:before { content: "\\eb80" }
.codicon-zoom-in:before { content: "\\eb81" }
.codicon-zoom-out:before { content: "\\eb82" }
.codicon-list-filter:before { content: "\\eb83" }
.codicon-list-flat:before { content: "\\eb84" }
.codicon-list-selection:before { content: "\\eb85" }
.codicon-selection:before { content: "\\eb85" }
.codicon-list-tree:before { content: "\\eb86" }
.codicon-debug-breakpoint-function-unverified:before { content: "\\eb87" }
.codicon-debug-breakpoint-function:before { content: "\\eb88" }
.codicon-debug-breakpoint-function-disabled:before { content: "\\eb88" }
.codicon-debug-stackframe-active:before { content: "\\eb89" }
.codicon-circle-small-filled:before { content: "\\eb8a" }
.codicon-debug-stackframe-dot:before { content: "\\eb8a" }
.codicon-terminal-decoration-mark:before { content: "\\eb8a" }
.codicon-debug-stackframe:before { content: "\\eb8b" }
.codicon-debug-stackframe-focused:before { content: "\\eb8b" }
.codicon-debug-breakpoint-unsupported:before { content: "\\eb8c" }
.codicon-symbol-string:before { content: "\\eb8d" }
.codicon-debug-reverse-continue:before { content: "\\eb8e" }
.codicon-debug-step-back:before { content: "\\eb8f" }
.codicon-debug-restart-frame:before { content: "\\eb90" }
.codicon-debug-alt:before { content: "\\eb91" }
.codicon-call-incoming:before { content: "\\eb92" }
.codicon-call-outgoing:before { content: "\\eb93" }
.codicon-menu:before { content: "\\eb94" }
.codicon-expand-all:before { content: "\\eb95" }
.codicon-feedback:before { content: "\\eb96" }
.codicon-git-pull-request-reviewer:before { content: "\\eb96" }
.codicon-group-by-ref-type:before { content: "\\eb97" }
.codicon-ungroup-by-ref-type:before { content: "\\eb98" }
.codicon-account:before { content: "\\eb99" }
.codicon-git-pull-request-assignee:before { content: "\\eb99" }
.codicon-bell-dot:before { content: "\\eb9a" }
.codicon-debug-console:before { content: "\\eb9b" }
.codicon-library:before { content: "\\eb9c" }
.codicon-output:before { content: "\\eb9d" }
.codicon-run-all:before { content: "\\eb9e" }
.codicon-sync-ignored:before { content: "\\eb9f" }
.codicon-pinned:before { content: "\\eba0" }
.codicon-github-inverted:before { content: "\\eba1" }
.codicon-server-process:before { content: "\\eba2" }
.codicon-server-environment:before { content: "\\eba3" }
.codicon-pass:before { content: "\\eba4" }
.codicon-issue-closed:before { content: "\\eba4" }
.codicon-stop-circle:before { content: "\\eba5" }
.codicon-play-circle:before { content: "\\eba6" }
.codicon-record:before { content: "\\eba7" }
.codicon-debug-alt-small:before { content: "\\eba8" }
.codicon-vm-connect:before { content: "\\eba9" }
.codicon-cloud:before { content: "\\ebaa" }
.codicon-merge:before { content: "\\ebab" }
.codicon-export:before { content: "\\ebac" }
.codicon-graph-left:before { content: "\\ebad" }
.codicon-magnet:before { content: "\\ebae" }
.codicon-notebook:before { content: "\\ebaf" }
.codicon-redo:before { content: "\\ebb0" }
.codicon-check-all:before { content: "\\ebb1" }
.codicon-pinned-dirty:before { content: "\\ebb2" }
.codicon-pass-filled:before { content: "\\ebb3" }
.codicon-circle-large-filled:before { content: "\\ebb4" }
.codicon-circle-large:before { content: "\\ebb5" }
.codicon-circle-large-outline:before { content: "\\ebb5" }
.codicon-combine:before { content: "\\ebb6" }
.codicon-gather:before { content: "\\ebb6" }
.codicon-table:before { content: "\\ebb7" }
.codicon-variable-group:before { content: "\\ebb8" }
.codicon-type-hierarchy:before { content: "\\ebb9" }
.codicon-type-hierarchy-sub:before { content: "\\ebba" }
.codicon-type-hierarchy-super:before { content: "\\ebbb" }
.codicon-git-pull-request-create:before { content: "\\ebbc" }
.codicon-run-above:before { content: "\\ebbd" }
.codicon-run-below:before { content: "\\ebbe" }
.codicon-notebook-template:before { content: "\\ebbf" }
.codicon-debug-rerun:before { content: "\\ebc0" }
.codicon-workspace-trusted:before { content: "\\ebc1" }
.codicon-workspace-untrusted:before { content: "\\ebc2" }
.codicon-workspace-unknown:before { content: "\\ebc3" }
.codicon-terminal-cmd:before { content: "\\ebc4" }
.codicon-terminal-debian:before { content: "\\ebc5" }
.codicon-terminal-linux:before { content: "\\ebc6" }
.codicon-terminal-powershell:before { content: "\\ebc7" }
.codicon-terminal-tmux:before { content: "\\ebc8" }
.codicon-terminal-ubuntu:before { content: "\\ebc9" }
.codicon-terminal-bash:before { content: "\\ebca" }
.codicon-arrow-swap:before { content: "\\ebcb" }
.codicon-copy:before { content: "\\ebcc" }
.codicon-person-add:before { content: "\\ebcd" }
.codicon-filter-filled:before { content: "\\ebce" }
.codicon-wand:before { content: "\\ebcf" }
.codicon-debug-line-by-line:before { content: "\\ebd0" }
.codicon-inspect:before { content: "\\ebd1" }
.codicon-layers:before { content: "\\ebd2" }
.codicon-layers-dot:before { content: "\\ebd3" }
.codicon-layers-active:before { content: "\\ebd4" }
.codicon-compass:before { content: "\\ebd5" }
.codicon-compass-dot:before { content: "\\ebd6" }
.codicon-compass-active:before { content: "\\ebd7" }
.codicon-azure:before { content: "\\ebd8" }
.codicon-issue-draft:before { content: "\\ebd9" }
.codicon-git-pull-request-closed:before { content: "\\ebda" }
.codicon-git-pull-request-draft:before { content: "\\ebdb" }
.codicon-debug-all:before { content: "\\ebdc" }
.codicon-debug-coverage:before { content: "\\ebdd" }
.codicon-run-errors:before { content: "\\ebde" }
.codicon-folder-library:before { content: "\\ebdf" }
.codicon-debug-continue-small:before { content: "\\ebe0" }
.codicon-beaker-stop:before { content: "\\ebe1" }
.codicon-graph-line:before { content: "\\ebe2" }
.codicon-graph-scatter:before { content: "\\ebe3" }
.codicon-pie-chart:before { content: "\\ebe4" }
.codicon-bracket-dot:before { content: "\\ebe5" }
.codicon-bracket-error:before { content: "\\ebe6" }
.codicon-lock-small:before { content: "\\ebe7" }
.codicon-azure-devops:before { content: "\\ebe8" }
.codicon-verified-filled:before { content: "\\ebe9" }
.codicon-newline:before { content: "\\ebea" }
.codicon-layout:before { content: "\\ebeb" }
.codicon-layout-activitybar-left:before { content: "\\ebec" }
.codicon-layout-activitybar-right:before { content: "\\ebed" }
.codicon-layout-panel-left:before { content: "\\ebee" }
.codicon-layout-panel-center:before { content: "\\ebef" }
.codicon-layout-panel-justify:before { content: "\\ebf0" }
.codicon-layout-panel-right:before { content: "\\ebf1" }
.codicon-layout-panel:before { content: "\\ebf2" }
.codicon-layout-sidebar-left:before { content: "\\ebf3" }
.codicon-layout-sidebar-right:before { content: "\\ebf4" }
.codicon-layout-statusbar:before { content: "\\ebf5" }
.codicon-layout-menubar:before { content: "\\ebf6" }
.codicon-layout-centered:before { content: "\\ebf7" }
.codicon-target:before { content: "\\ebf8" }
.codicon-indent:before { content: "\\ebf9" }
.codicon-record-small:before { content: "\\ebfa" }
.codicon-error-small:before { content: "\\ebfb" }
.codicon-terminal-decoration-error:before { content: "\\ebfb" }
.codicon-arrow-circle-down:before { content: "\\ebfc" }
.codicon-arrow-circle-left:before { content: "\\ebfd" }
.codicon-arrow-circle-right:before { content: "\\ebfe" }
.codicon-arrow-circle-up:before { content: "\\ebff" }
.codicon-layout-sidebar-right-off:before { content: "\\ec00" }
.codicon-layout-panel-off:before { content: "\\ec01" }
.codicon-layout-sidebar-left-off:before { content: "\\ec02" }
.codicon-blank:before { content: "\\ec03" }
.codicon-heart-filled:before { content: "\\ec04" }
.codicon-map:before { content: "\\ec05" }
.codicon-map-horizontal:before { content: "\\ec05" }
.codicon-fold-horizontal:before { content: "\\ec05" }
.codicon-map-filled:before { content: "\\ec06" }
.codicon-map-horizontal-filled:before { content: "\\ec06" }
.codicon-fold-horizontal-filled:before { content: "\\ec06" }
.codicon-circle-small:before { content: "\\ec07" }
.codicon-bell-slash:before { content: "\\ec08" }
.codicon-bell-slash-dot:before { content: "\\ec09" }
.codicon-comment-unresolved:before { content: "\\ec0a" }
.codicon-git-pull-request-go-to-changes:before { content: "\\ec0b" }
.codicon-git-pull-request-new-changes:before { content: "\\ec0c" }
.codicon-search-fuzzy:before { content: "\\ec0d" }
.codicon-comment-draft:before { content: "\\ec0e" }
.codicon-send:before { content: "\\ec0f" }
.codicon-sparkle:before { content: "\\ec10" }
.codicon-insert:before { content: "\\ec11" }
.codicon-mic:before { content: "\\ec12" }
.codicon-thumbsdown-filled:before { content: "\\ec13" }
.codicon-thumbsup-filled:before { content: "\\ec14" }
.codicon-coffee:before { content: "\\ec15" }
.codicon-snake:before { content: "\\ec16" }
.codicon-game:before { content: "\\ec17" }
.codicon-vr:before { content: "\\ec18" }
.codicon-chip:before { content: "\\ec19" }
.codicon-piano:before { content: "\\ec1a" }
.codicon-music:before { content: "\\ec1b" }
.codicon-mic-filled:before { content: "\\ec1c" }
.codicon-repo-fetch:before { content: "\\ec1d" }
.codicon-copilot:before { content: "\\ec1e" }
.codicon-lightbulb-sparkle:before { content: "\\ec1f" }
.codicon-robot:before { content: "\\ec20" }
.codicon-sparkle-filled:before { content: "\\ec21" }
.codicon-diff-single:before { content: "\\ec22" }
.codicon-diff-multiple:before { content: "\\ec23" }
.codicon-surround-with:before { content: "\\ec24" }
.codicon-share:before { content: "\\ec25" }
.codicon-git-stash:before { content: "\\ec26" }
.codicon-git-stash-apply:before { content: "\\ec27" }
.codicon-git-stash-pop:before { content: "\\ec28" }
.codicon-vscode:before { content: "\\ec29" }
.codicon-vscode-insiders:before { content: "\\ec2a" }
.codicon-code-oss:before { content: "\\ec2b" }
.codicon-run-coverage:before { content: "\\ec2c" }
.codicon-run-all-coverage:before { content: "\\ec2d" }
.codicon-coverage:before { content: "\\ec2e" }
.codicon-github-project:before { content: "\\ec2f" }
.codicon-map-vertical:before { content: "\\ec30" }
.codicon-fold-vertical:before { content: "\\ec30" }
.codicon-map-vertical-filled:before { content: "\\ec31" }
.codicon-fold-vertical-filled:before { content: "\\ec31" }
.codicon-go-to-search:before { content: "\\ec32" }
.codicon-percentage:before { content: "\\ec33" }
.codicon-sort-percentage:before { content: "\\ec33" }
.codicon-attach:before { content: "\\ec34" }
.codicon-go-to-editing-session:before { content: "\\ec35" }
.codicon-edit-session:before { content: "\\ec36" }
.codicon-code-review:before { content: "\\ec37" }
.codicon-copilot-warning:before { content: "\\ec38" }
.codicon-python:before { content: "\\ec39" }
.codicon-copilot-large:before { content: "\\ec3a" }
.codicon-copilot-warning-large:before { content: "\\ec3b" }
.codicon-keyboard-tab:before { content: "\\ec3c" }
.codicon-copilot-blocked:before { content: "\\ec3d" }
.codicon-copilot-not-connected:before { content: "\\ec3e" }
.codicon-flag:before { content: "\\ec3f" }
.codicon-lightbulb-empty:before { content: "\\ec40" }
.codicon-symbol-method-arrow:before { content: "\\ec41" }
.codicon-copilot-unavailable:before { content: "\\ec42" }
.codicon-repo-pinned:before { content: "\\ec43" }
.codicon-keyboard-tab-above:before { content: "\\ec44" }
.codicon-keyboard-tab-below:before { content: "\\ec45" }
.codicon-git-pull-request-done:before { content: "\\ec46" }
.codicon-mcp:before { content: "\\ec47" }
.codicon-extensions-large:before { content: "\\ec48" }
.codicon-layout-panel-dock:before { content: "\\ec49" }
.codicon-layout-sidebar-left-dock:before { content: "\\ec4a" }
.codicon-layout-sidebar-right-dock:before { content: "\\ec4b" }
.codicon-copilot-in-progress:before { content: "\\ec4c" }
.codicon-copilot-error:before { content: "\\ec4d" }
.codicon-copilot-success:before { content: "\\ec4e" }
.codicon-chat-sparkle:before { content: "\\ec4f" }
.codicon-search-sparkle:before { content: "\\ec50" }
.codicon-edit-sparkle:before { content: "\\ec51" }
.codicon-copilot-snooze:before { content: "\\ec52" }
.codicon-send-to-remote-agent:before { content: "\\ec53" }
.codicon-comment-discussion-sparkle:before { content: "\\ec54" }
.codicon-chat-sparkle-warning:before { content: "\\ec55" }
.codicon-chat-sparkle-error:before { content: "\\ec56" }
.codicon-collection:before { content: "\\ec57" }
.codicon-new-collection:before { content: "\\ec58" }
.codicon-thinking:before { content: "\\ec59" }
.codicon-build:before { content: "\\ec5a" }
.codicon-comment-discussion-quote:before { content: "\\ec5b" }
.codicon-cursor:before { content: "\\ec5c" }
.codicon-eraser:before { content: "\\ec5d" }
.codicon-file-text:before { content: "\\ec5e" }
.codicon-quotes:before { content: "\\ec60" }
.codicon-rename:before { content: "\\ec61" }
.codicon-run-with-deps:before { content: "\\ec62" }
.codicon-debug-connected:before { content: "\\ec63" }
.codicon-strikethrough:before { content: "\\ec64" }
.codicon-open-in-product:before { content: "\\ec65" }
.codicon-index-zero:before { content: "\\ec66" }
.codicon-agent:before { content: "\\ec67" }
.codicon-edit-code:before { content: "\\ec68" }
.codicon-repo-selected:before { content: "\\ec69" }
.codicon-skip:before { content: "\\ec6a" }
.codicon-merge-into:before { content: "\\ec6b" }
.codicon-git-branch-changes:before { content: "\\ec6c" }
.codicon-git-branch-staged-changes:before { content: "\\ec6d" }
.codicon-git-branch-conflicts:before { content: "\\ec6e" }
.codicon-git-branch:before { content: "\\ec6f" }
.codicon-git-branch-create:before { content: "\\ec6f" }
.codicon-git-branch-delete:before { content: "\\ec6f" }
.codicon-search-large:before { content: "\\ec70" }
.codicon-terminal-git-bash:before { content: "\\ec71" }
.codicon-window-active:before { content: "\\ec72" }
.codicon-forward:before { content: "\\ec73" }
.codicon-download:before { content: "\\ec74" }
.codicon-clockface:before { content: "\\ec75" }
.codicon-unarchive:before { content: "\\ec76" }
.codicon-session-in-progress:before { content: "\\ec77" }
.codicon-collection-small:before { content: "\\ec78" }
.codicon-vm-small:before { content: "\\ec79" }
.codicon-cloud-small:before { content: "\\ec7a" }
.codicon-add-small:before { content: "\\ec7b" }
.codicon-remove-small:before { content: "\\ec7c" }
.codicon-worktree-small:before { content: "\\ec7d" }
.codicon-worktree:before { content: "\\ec7e" }
.codicon-screen-cut:before { content: "\\ec7f" }
.codicon-ask:before { content: "\\ec80" }
.codicon-openai:before { content: "\\ec81" }
.codicon-claude:before { content: "\\ec82" }
.codicon-open-in-window:before { content: "\\ec83" }
.codicon-new-session:before { content: "\\ec84" }
.codicon-terminal-secure:before { content: "\\ec85" }
.codicon-chat-import:before { content: "\\ec86" }
.codicon-chat-export:before { content: "\\ec87" }
.codicon-share-window:before { content: "\\ec88" }
.codicon-circle-slash-compact:before { content: "\\ec89" }
.codicon-copilot-compact:before { content: "\\ec8a" }
.codicon-folder-opened-compact:before { content: "\\ec8b" }
.codicon-folder-compact:before { content: "\\ec8c" }
.codicon-gear-compact:before { content: "\\ec8d" }
.codicon-git-branch-compact:before { content: "\\ec8e" }
.codicon-library-compact:before { content: "\\ec8f" }
.codicon-record-keys-compact:before { content: "\\ec90" }
.codicon-remote-compact:before { content: "\\ec91" }
.codicon-repo-forked-compact:before { content: "\\ec92" }
.codicon-repo-compact:before { content: "\\ec93" }
.codicon-shield-compact:before { content: "\\ec94" }
.codicon-sparkle-compact:before { content: "\\ec95" }
.codicon-symbol-color-compact:before { content: "\\ec96" }
.codicon-window-compact:before { content: "\\ec97" }
.codicon-error-compact:before { content: "\\ec98" }
.codicon-warning-compact:before { content: "\\ec99" }
.codicon-pass-compact:before { content: "\\ec9a" }
.codicon-important:before { content: "\\ec9b" }
.codicon-important-compact:before { content: "\\ec9c" }
.codicon-rocket-compact:before { content: "\\ec9d" }
.codicon-unpin:before { content: "\\ec9e" }
.codicon-add-compact:before { content: "\\ec9f" }
.codicon-attach-compact:before { content: "\\eca0" }
.codicon-beaker-compact:before { content: "\\eca1" }
.codicon-check-compact:before { content: "\\eca2" }
.codicon-checklist-compact:before { content: "\\eca3" }
.codicon-chevron-down-compact:before { content: "\\eca4" }
.codicon-chevron-left-compact:before { content: "\\eca5" }
.codicon-chevron-right-compact:before { content: "\\eca6" }
.codicon-chevron-up-compact:before { content: "\\eca7" }
.codicon-circle-filled-compact:before { content: "\\eca8" }
.codicon-circle-small-filled-compact:before { content: "\\eca9" }
.codicon-close-compact:before { content: "\\ecaa" }
.codicon-collapse-all-compact:before { content: "\\ecab" }
.codicon-comment-compact:before { content: "\\ecac" }
.codicon-comment-unresolved-compact:before { content: "\\ecad" }
.codicon-debug-connected-compact:before { content: "\\ecae" }
.codicon-debug-disconnect-compact:before { content: "\\ecaf" }
.codicon-edit-compact:before { content: "\\ecb0" }
.codicon-file-media-compact:before { content: "\\ecb1" }
.codicon-git-fetch:before { content: "\\ecb2" }
.codicon-lightbulb-compact:before { content: "\\ecb3" }
.codicon-loading-compact:before { content: "\\ecb4" }
.codicon-pass-filled-compact:before { content: "\\ecb5" }
.codicon-project-compact:before { content: "\\ecb6" }
.codicon-refresh-compact:before { content: "\\ecb7" }
.codicon-search-compact:before { content: "\\ecb8" }
.codicon-session-in-progress-compact:before { content: "\\ecb9" }
.codicon-sync-compact:before { content: "\\ecba" }
.codicon-terminal-compact:before { content: "\\ecbb" }
.codicon-vm-pending:before { content: "\\ecbc" }
.codicon-worktree-compact:before { content: "\\ecbd" }
.codicon-developer-tools:before { content: "\\ecbe" }
.codicon-cloud-compact:before { content: "\\ecbf" }
.codicon-agent-compact:before { content: "\\ecc0" }
.codicon-ask-compact:before { content: "\\ecc1" }
.codicon-settings-compact:before { content: "\\ecc2" }
.codicon-vm-compact:before { content: "\\ecc3" }
.codicon-run-compact:before { content: "\\ecc4" }
.codicon-git-pull-request-comment:before { content: "\\ecc5" }
.codicon-git-pull-request-error:before { content: "\\ecc6" }
.codicon-right-panel-hide:before { content: "\\ecc7" }
.codicon-right-panel-show:before { content: "\\ecc8" }
.codicon-vscode-insiders-outline:before { content: "\\ecc9" }
.codicon-vscode-outline:before { content: "\\ecca" }
.codicon-voice-mode:before { content: "\\eccb" }
.codicon-voice-mode-compact:before { content: "\\eccc" }
.codicon-mic-download:before { content: "\\eccd" }
.codicon-mic-download-compact:before { content: "\\ecce" }
.codicon-voice-mode-download:before { content: "\\eccf" }
.codicon-voice-mode-download-compact:before { content: "\\ecd0" }
.codicon-google-gemini:before { content: "\\ecd1" }
.codicon-kimi:before { content: "\\ecd2" }
.codicon-microsoft:before { content: "\\ecd3" }
.codicon-fish1-happy:before { content: "\\ecd4" }
.codicon-fish1-neutral:before { content: "\\ecd5" }
.codicon-fish1-sad:before { content: "\\ecd6" }
.codicon-fish1-very-sad:before { content: "\\ecd7" }
.codicon-fish2-happy:before { content: "\\ecd8" }
.codicon-fish2-neutral:before { content: "\\ecd9" }
.codicon-fish2-sad:before { content: "\\ecda" }
.codicon-fish2-very-sad:before { content: "\\ecdb" }
.codicon-fish3-happy:before { content: "\\ecdc" }
.codicon-fish3-neutral:before { content: "\\ecdd" }
.codicon-fish3-sad:before { content: "\\ecde" }
.codicon-fish3-very-sad:before { content: "\\ecdf" }
.codicon-fish4-happy:before { content: "\\ece0" }
.codicon-fish4-neutral:before { content: "\\ece1" }
.codicon-fish4-sad:before { content: "\\ece2" }
.codicon-fish4-very-sad:before { content: "\\ece3" }
.codicon-person-voice:before { content: "\\ece4" }
.codicon-person-voice-compact:before { content: "\\ece5" }
.codicon-person-voice-filled:before { content: "\\ece6" }
.codicon-person-voice-filled-compact:before { content: "\\ece7" }
`;var kd=`/* VS Code theme variables for hosts outside VS Code (the browser extension's pages): a dark and
   a light set that follow the system theme, matching VS Code's Dark Modern and Light Modern. */

.ink-theme {
  --vscode-font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  --vscode-font-size: 13px;
  --vscode-editor-font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
  --vscode-foreground: #cccccc;
  --vscode-descriptionForeground: #9d9d9d;
  --vscode-icon-foreground: #cccccc;
  --vscode-editor-background: #1f1f1f;
  --vscode-editorWidget-background: #202020;
  --vscode-widget-border: #313131;
  --vscode-widget-shadow: rgba(0, 0, 0, 0.36);
  --vscode-focusBorder: #0078d4;
  --vscode-button-background: #0078d4;
  --vscode-button-foreground: #ffffff;
  --vscode-button-hoverBackground: #026ec1;
  --vscode-button-border: rgba(255, 255, 255, 0.07);
  --vscode-button-secondaryBackground: #313131;
  --vscode-button-secondaryForeground: #cccccc;
  --vscode-button-secondaryHoverBackground: #3c3c3c;
  --vscode-toolbar-hoverBackground: rgba(90, 93, 94, 0.31);
  --vscode-toolbar-activeBackground: rgba(99, 102, 103, 0.31);
  --vscode-input-background: #313131;
  --vscode-input-foreground: #cccccc;
  --vscode-input-border: #3c3c3c;
  --vscode-input-placeholderForeground: #989898;
  --vscode-dropdown-background: #313131;
  --vscode-dropdown-foreground: #cccccc;
  --vscode-dropdown-border: #3c3c3c;
  --vscode-checkbox-background: #313131;
  --vscode-checkbox-border: #3c3c3c;
  --vscode-menu-background: #1f1f1f;
  --vscode-menu-foreground: #cccccc;
  --vscode-menu-selectionBackground: #0078d4;
  --vscode-menu-selectionForeground: #ffffff;
  --vscode-menu-separatorBackground: #454545;
  --vscode-menu-border: #454545;
  --vscode-notifications-background: #1f1f1f;
  --vscode-notifications-foreground: #cccccc;
  --vscode-notifications-border: #2b2b2b;
  --vscode-textLink-foreground: #4daafc;
  --vscode-errorForeground: #f85149;
  --vscode-testing-iconPassed: #73c991;
  --vscode-editorWarning-foreground: #cca700;
  --vscode-terminal-ansiBlue: #4daafc;
  --vscode-terminal-ansiGreen: #3fb950;
  --vscode-terminal-ansiYellow: #d7ba7d;
  --vscode-terminal-ansiRed: #f85149;
  --vscode-terminal-ansiMagenta: #d670d6;
  --vscode-badge-background: #616161;
  --vscode-badge-foreground: #f8f8f8;
  --vscode-keybindingLabel-background: rgba(128, 128, 128, 0.17);
  --vscode-keybindingLabel-foreground: #cccccc;
  --vscode-keybindingLabel-border: rgba(51, 51, 51, 0.6);
  color-scheme: dark;
}

@media (prefers-color-scheme: light) {
  .ink-theme {
    --vscode-foreground: #3b3b3b;
    --vscode-descriptionForeground: #6f6f6f;
    --vscode-icon-foreground: #3b3b3b;
    --vscode-editor-background: #ffffff;
    --vscode-editorWidget-background: #f8f8f8;
    --vscode-widget-border: #e5e5e5;
    --vscode-widget-shadow: rgba(0, 0, 0, 0.16);
    --vscode-focusBorder: #005fb8;
    --vscode-button-background: #005fb8;
    --vscode-button-hoverBackground: #0258a8;
    --vscode-button-border: rgba(0, 0, 0, 0.1);
    --vscode-button-secondaryBackground: #e5e5e5;
    --vscode-button-secondaryForeground: #3b3b3b;
    --vscode-button-secondaryHoverBackground: #cccccc;
    --vscode-toolbar-hoverBackground: rgba(184, 184, 184, 0.31);
    --vscode-toolbar-activeBackground: rgba(166, 166, 166, 0.31);
    --vscode-input-background: #ffffff;
    --vscode-input-foreground: #3b3b3b;
    --vscode-input-border: #cecece;
    --vscode-input-placeholderForeground: #767676;
    --vscode-dropdown-background: #ffffff;
    --vscode-dropdown-foreground: #3b3b3b;
    --vscode-dropdown-border: #cecece;
    --vscode-checkbox-background: #f8f8f8;
    --vscode-checkbox-border: #cecece;
    --vscode-menu-background: #ffffff;
    --vscode-menu-foreground: #3b3b3b;
    --vscode-menu-selectionBackground: #005fb8;
    --vscode-menu-separatorBackground: #d4d4d4;
    --vscode-menu-border: #cecece;
    --vscode-notifications-background: #ffffff;
    --vscode-notifications-foreground: #3b3b3b;
    --vscode-notifications-border: #e5e5e5;
    --vscode-textLink-foreground: #005fb8;
    --vscode-errorForeground: #b3261e;
    --vscode-testing-iconPassed: #2e7d32;
    --vscode-editorWarning-foreground: #895503;
    --vscode-terminal-ansiBlue: #005fb8;
    --vscode-terminal-ansiGreen: #1a7f37;
    --vscode-terminal-ansiYellow: #895503;
    --vscode-terminal-ansiRed: #c72e0f;
    --vscode-terminal-ansiMagenta: #a626a4;
    --vscode-badge-background: #cccccc;
    --vscode-badge-foreground: #3b3b3b;
    --vscode-keybindingLabel-foreground: #3b3b3b;
    --vscode-keybindingLabel-border: rgba(204, 204, 204, 0.4);
    color-scheme: light;
  }
}
`;var wd=`/* The Inkspect design system: tokens and the shared components (buttons, fields, selects,
   switches, sliders, color picker, menus, toast, drawing toolbar and layer).
   Colors come from VS Code theme variables; hosts outside VS Code define them (theme.css).
   Every surface uses the tokens below, so sizes, radii and elevation stay consistent. */

:root,
:host {
  /* Shape */
  --ink-radius-sm: 4px;
  --ink-radius: 6px;
  --ink-radius-lg: 10px;
  --ink-radius-pill: 999px;
  /* Controls */
  --ink-control-sm: 24px;
  --ink-control: 28px;
  --ink-control-lg: 36px;
  /* Spacing */
  --ink-space-1: 4px;
  --ink-space-2: 8px;
  --ink-space-3: 12px;
  --ink-space-4: 16px;
  --ink-space-5: 24px;
  --ink-space-6: 32px;
  /* Type */
  --ink-font-xs: 11px;
  --ink-font-sm: 12px;
  --ink-font: var(--vscode-font-size, 13px);
  --ink-font-lg: 15px;
  --ink-font-xl: 22px;
  /* Surfaces and lines */
  --ink-surface: var(--vscode-editorWidget-background, var(--vscode-editor-background));
  /* Popups: lifted off the menu background, since many dark themes (Tokyo Night) give menus the
     sidebar's own color, a border the same near-black, and no shadow at all. */
  --ink-surface-raised: color-mix(
    in srgb,
    var(--vscode-foreground, #888) 7%,
    var(--vscode-menu-background, var(--ink-surface))
  );
  --ink-surface-sunken: color-mix(in srgb, var(--vscode-foreground, #888) 4%, transparent);
  --ink-border: var(--vscode-widget-border, rgba(128, 128, 128, 0.35));
  --ink-border-subtle: color-mix(in srgb, var(--vscode-foreground, #888) 10%, transparent);
  --ink-border-strong: color-mix(in srgb, var(--vscode-foreground, #888) 22%, transparent);
  --ink-hover: var(--vscode-toolbar-hoverBackground, rgba(128, 128, 128, 0.18));
  --ink-pressed: var(--vscode-toolbar-activeBackground, rgba(128, 128, 128, 0.26));
  /* Focus rings follow the theme's focus border; accents use the button color, which themes keep
     vivid (the focus border can be very dim). Text on tinted backgrounds uses the link color. */
  --ink-focus: var(--vscode-focusBorder, #0078d4);
  --ink-accent: var(--vscode-button-background, var(--ink-focus));
  --ink-accent-fg: var(--vscode-textLink-foreground, var(--ink-accent));
  --ink-accent-soft: color-mix(in srgb, var(--ink-accent) 20%, transparent);
  /* Secondary text, pulled toward the foreground so it stays readable in low-contrast themes. */
  --ink-muted: color-mix(
    in srgb,
    var(--vscode-descriptionForeground, #9d9d9d) 70%,
    var(--vscode-foreground, #ccc)
  );
  --ink-danger: var(--vscode-errorForeground, #f85149);
  --ink-success: var(--vscode-testing-iconPassed, #73c991);
  --ink-warning: var(--vscode-editorWarning-foreground, #cca700);
  /* The theme's own palette. Every theme defines its terminal ANSI colors, and they are its true
     hues (Tokyo Night's are #7aa2f7, #9ece6a, #e0af68, #f7768e, #bb9af7), unlike button and
     error colors, which some themes keep dim. Pulled slightly toward the foreground so they stay
     readable as text on both light and dark backgrounds. */
  --ink-blue: color-mix(
    in srgb,
    var(--vscode-terminal-ansiBlue, #3b8eea) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-green: color-mix(
    in srgb,
    var(--vscode-terminal-ansiGreen, #23d18b) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-yellow: color-mix(
    in srgb,
    var(--vscode-terminal-ansiYellow, #e5e510) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-red: color-mix(
    in srgb,
    var(--vscode-terminal-ansiRed, #f14c4c) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-magenta: color-mix(
    in srgb,
    var(--vscode-terminal-ansiMagenta, #d670d6) 88%,
    var(--vscode-foreground, #888)
  );
  /* Elevation */
  /* Half the theme's widget shadow, half plain black: some themes make theirs transparent. */
  --ink-shadow-color: color-mix(
    in srgb,
    var(--vscode-widget-shadow, rgba(0, 0, 0, 0.3)) 50%,
    rgba(0, 0, 0, 0.5)
  );
  --ink-shadow-sm: 0 1px 3px var(--ink-shadow-color);
  --ink-shadow: 0 6px 20px var(--ink-shadow-color), 0 1px 4px var(--ink-shadow-color);
  --ink-shadow-lg: 0 12px 32px var(--ink-shadow-color), 0 2px 8px var(--ink-shadow-color);
  /* Motion */
  --ink-ease: cubic-bezier(0.2, 0, 0, 1);
  --ink-fast: 90ms;
  --ink-normal: 160ms;
}

/* Focus ------------------------------------------------------------------------------------ */

.icon-button:focus-visible,
.button:focus-visible,
.link-button:focus-visible,
.menu-item:focus-visible,
.select:focus-visible,
.switch:focus-visible,
.checkbox:focus-visible,
.segment:focus-visible,
.slider-track:focus-visible,
.swatch:focus-visible,
.color-area:focus-visible,
.color-hue:focus-visible,
.chip:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: 1px;
}

/* Icon buttons ----------------------------------------------------------------------------- */

.icon-button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: var(--ink-control);
  height: var(--ink-control);
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--vscode-icon-foreground, var(--vscode-foreground));
  font: inherit;
  cursor: pointer;
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.icon-button.small {
  width: var(--ink-control-sm);
  height: var(--ink-control-sm);
}

.icon-button:hover:not(:disabled) {
  background: var(--ink-hover);
}

.icon-button:active:not(:disabled) {
  background: var(--ink-pressed);
}

.icon-button.active {
  background: var(--ink-accent-soft);
  color: var(--vscode-inputOption-activeForeground, var(--vscode-foreground));
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--ink-accent) 60%, transparent);
}

.icon-button:disabled {
  opacity: 0.4;
  cursor: default;
}

/* Buttons ---------------------------------------------------------------------------------- */

.button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: var(--ink-control);
  padding: 0 12px;
  border: 1px solid var(--vscode-button-border, transparent);
  border-radius: var(--ink-radius-sm);
  font: inherit;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.button.small {
  gap: 4px;
  height: var(--ink-control-sm);
  padding: 0 8px;
}

.button .codicon {
  font-size: 14px;
}

.button.primary {
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.primary:hover:not(:disabled) {
  background: var(--vscode-button-hoverBackground);
}

.button.secondary {
  background: var(--vscode-button-secondaryBackground);
  color: var(--vscode-button-secondaryForeground);
}

.button.secondary:hover:not(:disabled) {
  background: var(--vscode-button-secondaryHoverBackground);
}

.button.ghost {
  border-color: transparent;
  background: transparent;
  color: inherit;
}

.button.ghost:hover:not(:disabled) {
  background: var(--ink-hover);
}

/* A solid call to action in the theme's own blue (its palette, see --ink-blue), for themes whose
   button color is dim. Dark text on dark themes, where the palette's blue is light. */
.button.accent {
  border-color: transparent;
  background: var(--ink-blue);
  color: var(--vscode-editor-background, #fff);
  font-weight: 600;
}

.button.accent:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-blue) 85%, var(--vscode-foreground, #fff));
}

body.vscode-light .button.accent {
  color: #fff;
}

body.vscode-high-contrast .button.accent {
  border-color: var(--vscode-contrastBorder, transparent);
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.danger {
  border-color: color-mix(in srgb, var(--ink-danger) 45%, transparent);
  background: transparent;
  color: var(--ink-danger);
}

.button.danger:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-danger) 12%, transparent);
}

.button:disabled {
  opacity: 0.5;
  cursor: default;
}

.link-button {
  padding: 0;
  border: none;
  background: none;
  color: var(--vscode-textLink-foreground);
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.link-button:hover:not(:disabled) {
  color: var(--vscode-textLink-activeForeground, var(--vscode-textLink-foreground));
  text-decoration: underline;
}

.link-button:disabled {
  color: inherit;
  cursor: default;
}

.link-button.danger {
  color: var(--ink-danger);
}

/* Text fields ------------------------------------------------------------------------------ */

.text-field {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: var(--ink-control);
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  transition: border-color var(--ink-fast) var(--ink-ease);
}

.text-field.size-sm {
  height: var(--ink-control-sm);
  padding: 0 6px;
}

.text-field.size-lg {
  height: var(--ink-control-lg);
  padding: 0 12px;
  border-radius: var(--ink-radius);
}

.text-field:hover:not(.disabled) {
  border-color: var(--ink-border-strong);
}

.text-field:focus-within {
  border-color: var(--ink-focus);
  box-shadow: 0 0 0 1px var(--ink-focus);
}

.text-field.invalid {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.text-field.disabled {
  opacity: 0.5;
}

.text-field input {
  flex: 1;
  width: 100%;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: none;
  outline: none;
  background: transparent;
  color: inherit;
  font: inherit;
}

.text-field input::placeholder {
  color: var(--vscode-input-placeholderForeground, var(--ink-muted));
}

/* Numbers: no spinner arrows (the fields accept typing and arrow keys). */
.text-field input::-webkit-outer-spin-button,
.text-field input::-webkit-inner-spin-button {
  margin: 0;
  appearance: none;
}

.text-field input[type='number'] {
  appearance: textfield;
  font-variant-numeric: tabular-nums;
}

.text-field input[type='search']::-webkit-search-cancel-button {
  appearance: none;
}

.text-field-icon {
  flex-shrink: 0;
  color: var(--ink-muted);
}

.text-field-clear {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.text-field-clear:hover {
  background: var(--ink-hover);
  color: inherit;
}

/* Form rows -------------------------------------------------------------------------------- */

.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: var(--ink-space-3);
}

.field.inline {
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ink-space-3);
}

.field-label {
  color: var(--vscode-foreground);
  font-weight: 600;
}

.field.inline .field-label {
  font-weight: normal;
}

.field-control {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  min-width: 0;
}

.field-control > .text-field,
.field-control > .select {
  flex: 1;
}

.field-hint {
  flex-basis: 100%;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.field-hint.error {
  color: var(--ink-danger);
}

/* Select ----------------------------------------------------------------------------------- */

.select {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  height: var(--ink-control);
  padding: 0 6px 0 8px;
  border: 1px solid var(--vscode-dropdown-border, var(--vscode-input-border, var(--ink-border)));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-dropdown-background, var(--vscode-input-background));
  color: var(--vscode-dropdown-foreground, var(--vscode-input-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.select.size-sm {
  height: var(--ink-control-sm);
  padding: 0 4px 0 6px;
}

.select:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
}

.select.open {
  border-color: var(--ink-focus);
}

.select.quiet {
  border-color: transparent;
  background: transparent;
}

.select.quiet:hover:not(:disabled),
.select.quiet.open {
  border-color: transparent;
  background: var(--ink-hover);
}

.select:disabled {
  opacity: 0.45;
  cursor: default;
}

.select-value {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.select-value.placeholder {
  color: var(--ink-muted);
}

.select-chevron {
  flex-shrink: 0;
  font-size: 14px !important;
  opacity: 0.8;
  transition: transform var(--ink-normal) var(--ink-ease);
}

.select.open .select-chevron {
  transform: rotate(180deg);
}

.select-list,
.color-picker,
.menu,
.popover {
  background: var(--ink-surface-raised);
  color: var(--vscode-menu-foreground, var(--vscode-foreground));
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow);
}

.select-list {
  position: fixed;
  z-index: 1000;
  max-height: min(340px, 60vh);
  padding: 4px;
  overflow-y: auto;
  outline: none;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.select-group {
  padding: 8px 8px 4px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.select-group:first-child {
  padding-top: 4px;
}

.select-option {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px 0 4px;
  border-radius: var(--ink-radius-sm);
  white-space: nowrap;
  cursor: pointer;
}

.select-option.active {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
}

.select-option.disabled {
  opacity: 0.45;
  cursor: default;
}

.select-check {
  flex-shrink: 0;
  font-size: 14px !important;
}

.select-option-label {
  flex: 1;
}

.select-option-detail {
  margin-left: 16px;
  opacity: 0.65;
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Switch and checkbox ---------------------------------------------------------------------- */

.switch,
.checkbox {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: var(--ink-space-2);
  padding: 2px 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.switch:disabled,
.checkbox:disabled {
  opacity: 0.45;
  cursor: default;
}

.switch-track {
  position: relative;
  flex-shrink: 0;
  width: 30px;
  height: 16px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-input-background, var(--ink-surface-sunken));
  transition:
    background-color var(--ink-normal) var(--ink-ease),
    border-color var(--ink-normal) var(--ink-ease);
}

.switch-thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--ink-muted);
  transition:
    transform var(--ink-normal) var(--ink-ease),
    background-color var(--ink-normal) var(--ink-ease);
}

.switch.on .switch-track {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
}

.switch.on .switch-thumb {
  background: var(--vscode-button-foreground, #fff);
  transform: translateX(14px);
}

.checkbox-box {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border: 1px solid var(--vscode-checkbox-border, var(--ink-border-strong));
  border-radius: 3px;
  background: var(--vscode-checkbox-background, var(--vscode-input-background));
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.checkbox.on .checkbox-box {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
  color: var(--vscode-button-foreground, #fff);
}

.checkbox-box .codicon {
  font-size: 14px !important;
}

/* Segmented control ------------------------------------------------------------------------ */

.segmented {
  display: inline-flex;
  flex-shrink: 0;
  gap: 2px;
  height: var(--ink-control);
  padding: 2px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
}

.segmented.size-sm {
  height: var(--ink-control-sm);
  padding: 1px;
  border-radius: var(--ink-radius-sm);
}

.segment {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  gap: 5px;
  min-width: 26px;
  padding: 0 10px;
  border: none;
  border-radius: calc(var(--ink-radius) - 2px);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    color var(--ink-fast) var(--ink-ease);
}

.segmented.size-sm .segment {
  padding: 0 8px;
  border-radius: 3px;
}

.segment:hover {
  color: var(--vscode-foreground);
}

.segment.checked {
  background: var(--vscode-button-secondaryBackground, var(--ink-hover));
  color: var(--vscode-button-secondaryForeground, var(--vscode-foreground));
  box-shadow: var(--ink-shadow-sm);
}

.segment-count {
  min-width: 16px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
  text-align: center;
}

.segment-count.error {
  background: var(--ink-danger);
  color: #fff;
}

/* Slider ----------------------------------------------------------------------------------- */

.slider {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  height: var(--ink-control);
}

.slider.disabled {
  opacity: 0.45;
}

.slider > .codicon {
  color: var(--ink-muted);
}

.slider-track {
  position: relative;
  width: 84px;
  height: 18px;
  cursor: pointer;
  touch-action: none;
  border-radius: var(--ink-radius-sm);
}

.slider-track::before,
.slider-fill {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  height: 4px;
  border-radius: var(--ink-radius-pill);
  transform: translateY(-50%);
}

.slider-track::before {
  right: 0;
  background: var(--ink-border-strong);
}

.slider-fill {
  background: var(--ink-accent);
}

.slider-thumb {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid var(--ink-accent);
  border-radius: 50%;
  background: var(--vscode-editor-background, #fff);
  box-shadow: var(--ink-shadow-sm);
  transform: translate(-50%, -50%);
  transition: transform var(--ink-fast) var(--ink-ease);
}

.slider-track:hover .slider-thumb,
.slider-track:active .slider-thumb {
  transform: translate(-50%, -50%) scale(1.15);
}

.slider-value {
  min-width: 34px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Swatches and color picker ---------------------------------------------------------------- */

.swatch {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  padding: 0;
  border: 1px solid color-mix(in srgb, var(--vscode-foreground, #888) 30%, transparent);
  border-radius: 50%;
  cursor: pointer;
  transition: transform var(--ink-fast) var(--ink-ease);
}

.swatch:hover {
  transform: scale(1.12);
}

.swatch.small {
  width: 16px;
  height: 16px;
}

.swatch.active {
  box-shadow:
    0 0 0 2px var(--ink-surface),
    0 0 0 3.5px var(--ink-accent);
}

.color-picker-trigger {
  background: conic-gradient(
    from 90deg,
    #f43f5e,
    #f59e0b,
    #84cc16,
    #06b6d4,
    #6366f1,
    #d946ef,
    #f43f5e
  );
}

.color-picker {
  position: fixed;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 224px;
  padding: 10px;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.color-area {
  position: relative;
  height: 140px;
  border-radius: var(--ink-radius-sm);
  background-image:
    linear-gradient(to top, #000, transparent), linear-gradient(to right, #fff, transparent) !important;
  cursor: crosshair;
  touch-action: none;
}

.color-hue {
  position: relative;
  height: 12px;
  border-radius: var(--ink-radius-pill);
  background: linear-gradient(
    to right,
    #f00 0%,
    #ff0 17%,
    #0f0 33%,
    #0ff 50%,
    #00f 67%,
    #f0f 83%,
    #f00 100%
  );
  cursor: pointer;
  touch-action: none;
}

.color-handle {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.35),
    0 1px 4px rgba(0, 0, 0, 0.4);
  transform: translate(-50%, -50%);
  pointer-events: none;
}

.color-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.color-preview {
  flex-shrink: 0;
  width: 26px;
  height: 26px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
}

.color-hex {
  flex: 1;
  min-width: 0;
  height: 26px;
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  outline: none;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-sm);
  text-transform: lowercase;
}

.color-hex:focus {
  border-color: var(--ink-focus);
}

.color-presets {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  padding-top: 8px;
  border-top: 1px solid var(--ink-border-subtle);
}

/* Chips and badges ------------------------------------------------------------------------- */

.badge {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 7px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  white-space: nowrap;
}

.badge.outline {
  border: 1px solid var(--ink-border-strong);
  background: transparent;
  color: var(--ink-muted);
}

.badge.success {
  background: color-mix(in srgb, var(--ink-success) 18%, transparent);
  color: var(--ink-success);
}

.badge.danger {
  background: color-mix(in srgb, var(--ink-danger) 18%, transparent);
  color: var(--ink-danger);
}

/* Key caps (shortcuts) --------------------------------------------------------------------- */

.keycaps {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 3px;
}

.keycap {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border: 1px solid var(--vscode-keybindingLabel-border, var(--ink-border-strong));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-keybindingLabel-background, var(--ink-surface-sunken));
  box-shadow: inset 0 -1px 0 var(--vscode-keybindingLabel-bottomBorder, var(--ink-border-strong));
  color: var(--vscode-keybindingLabel-foreground, var(--vscode-foreground));
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  line-height: 1;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.keycaps.size-sm .keycap {
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  font-size: 10.5px;
}

/* Cards ------------------------------------------------------------------------------------ */

.card {
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--ink-surface-sunken);
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--ink-space-3);
  padding: var(--ink-space-3) var(--ink-space-4);
  border-bottom: 1px solid var(--ink-border-subtle);
}

.card-title {
  margin: 0;
  font-size: var(--ink-font);
  font-weight: 600;
}

.card-body {
  padding: var(--ink-space-4);
}

.card-row {
  display: flex;
  align-items: center;
  gap: var(--ink-space-4);
  padding: var(--ink-space-3) var(--ink-space-4);
}

.card-row + .card-row {
  border-top: 1px solid var(--ink-border-subtle);
}

.card-row-text {
  flex: 1;
  min-width: 0;
}

.card-row-title {
  font-weight: 500;
}

.card-row-description {
  margin-top: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

/* Menus and popovers ----------------------------------------------------------------------- */

.menu,
.popover {
  position: fixed;
  z-index: 100;
  min-width: 200px;
  max-width: 420px;
  padding: 4px;
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

/* Long menus (a big bookmarks folder) stay short and scroll, like Chrome's. Items have a little
   room between them. */
.menu {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 5px;
  max-height: min(420px, calc(100vh - 8px));
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Submenus open without the pop animation, so they don't jump while the pointer moves. */
.menu .menu {
  animation: none;
}

.menu-item.expanded:not(:focus) {
  background: var(--ink-hover);
}

.menu-image {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  object-fit: contain;
}

.menu-arrow {
  margin-left: 12px;
  margin-right: -2px;
  opacity: 0.8;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  width: 100%;
  height: 28px;
  padding: 0 10px 0 8px;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.menu-item:hover:not(:disabled),
.menu-item:focus {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
  outline: none;
}

.menu-item:disabled {
  opacity: 0.45;
  cursor: default;
}

.menu-label {
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.menu-shortcut {
  margin-left: 16px;
  opacity: 0.7;
  font-size: 0.9em;
}

.menu-separator {
  flex-shrink: 0;
  height: 1px;
  margin: 3px 6px;
  background: var(--vscode-menu-separatorBackground, var(--ink-border));
}

/* Toast ------------------------------------------------------------------------------------ */

.toast {
  position: fixed;
  bottom: 16px;
  left: 50%;
  z-index: 200;
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: calc(100% - 32px);
  padding: 8px 14px;
  transform: translateX(-50%);
  background: var(--vscode-notifications-background, var(--ink-surface));
  color: var(--vscode-notifications-foreground, var(--vscode-foreground));
  border: 1px solid var(--vscode-notifications-border, var(--ink-border));
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow-lg);
  animation: toast-in var(--ink-normal) var(--ink-ease);
}

/* A failure: marked as one, longer on screen, and dismissible. */
.toast.error {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.toast.error > .codicon-error {
  flex-shrink: 0;
  color: var(--ink-danger);
}

.toast .toast-dismiss {
  flex-shrink: 0;
  margin: -4px -8px -4px 0;
}

.header-actions,
.button-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
}

/* Drawing ---------------------------------------------------------------------------------- */

.draw-toolbar {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  padding: 4px 8px;
  background: var(--ink-surface);
  border-top: 1px solid var(--ink-border);
  border-bottom: 1px solid var(--ink-border);
}

.draw-group {
  display: flex;
  align-items: center;
  gap: 2px;
  padding-right: 6px;
  border-right: 1px solid var(--ink-border-subtle);
}

.draw-group.colors {
  gap: 6px;
  padding: 0 8px 0 4px;
}

.draw-capture {
  margin-left: 2px;
}

.draw-close {
  margin-left: auto;
}

.drawing-layer {
  position: absolute;
  z-index: 3;
}

.drawing-layer canvas {
  position: relative;
  display: block;
  touch-action: none;
}

/* A live redaction (liveRedactions): blurs the page behind it, under the drawing canvas. Drawn
   over page content, so its colors are fixed. */
.drawing-redaction {
  position: absolute;
  pointer-events: none;
  background: rgba(128, 128, 128, 0.2);
  backdrop-filter: blur(12px) saturate(0.5);
}

.drawing-text-input {
  position: absolute;
  min-width: 160px;
  min-height: 1.6em;
  padding: 2px 4px;
  border: 1px dashed var(--ink-accent);
  background: rgba(255, 255, 255, 0.85);
  font-family: system-ui, sans-serif;
  font-weight: 600;
  resize: both;
  outline: none;
}

/* Motion ----------------------------------------------------------------------------------- */

@keyframes ink-pop-in {
  from {
    opacity: 0;
    transform: translateY(-3px) scale(0.985);
  }
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translate(-50%, 8px);
  }
}

@media (prefers-reduced-motion: reduce) {
  .select-list,
  .color-picker,
  .menu,
  .popover,
  .toast {
    animation: none;
  }
}

/* Shortcut list (ShortcutList) ------------------------------------------------------------- */

.shortcuts-warning {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 12px 8px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

/* Groups: a pinned header per mode. */
.group-header {
  position: sticky;
  top: var(--shortcut-sticky-top, 0);
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  height: 28px;
  padding: 0 12px 0 6px;
  border: none;
  border-top: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  color: var(--vscode-sideBarSectionHeader-foreground, var(--vscode-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.group-header:hover {
  background: var(--vscode-list-hoverBackground);
}

.group-header:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.group-icon {
  color: var(--ink-accent-fg);
}

.group-title {
  font-size: var(--ink-font-xs);
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.group-count {
  margin-left: auto;
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
}

/* Rows: label, then actions (on hover), then the keys in a right-aligned column. */
.shortcut-item {
  position: relative;
  padding: 0 12px 0 32px;
  border-radius: var(--ink-radius);
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.shortcut-item::before {
  content: '';
  position: absolute;
  top: 6px;
  bottom: 6px;
  left: 20px;
  width: 2px;
  border-radius: 1px;
  background: transparent;
}

.shortcut-item.changed::before {
  background: var(--ink-accent);
}

.shortcut-item.conflict::before {
  background: var(--ink-warning);
}

/* Outside VS Code (the browser extension) there is no list hover color: the kit's hover. */
.shortcut-item:hover,
.shortcut-item:focus-within {
  background: var(--vscode-list-hoverBackground, var(--ink-hover));
}

body.vscode-high-contrast .shortcut-item:hover,
body.vscode-high-contrast .shortcut-item:focus-within {
  outline: 1px dashed var(--vscode-contrastActiveBorder);
  outline-offset: -1px;
}

.shortcut-main {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 30px;
}

.shortcut-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Where a key works: VS (VS Code Browser) and BR (the browser toolbar), and the browser's own key. */
.shortcut-places {
  display: inline-flex;
  flex-shrink: 0;
  gap: 3px;
}

.shortcut-tag {
  --tag: var(--ink-muted);
  flex-shrink: 0;
  min-width: 22px;
  padding: 0 4px;
  border: 1px solid color-mix(in srgb, var(--tag) 40%, transparent);
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--tag) 10%, transparent);
  color: var(--tag);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 14px;
  text-align: center;
  letter-spacing: 0.02em;
}

.shortcut-tag.vs {
  --tag: var(--ink-blue);
}

.shortcut-tag.br {
  --tag: var(--ink-green);
}

body.vscode-high-contrast .shortcut-tag {
  border-color: var(--vscode-contrastBorder);
  background: transparent;
  color: var(--vscode-foreground);
}

.shortcut-item.changed .shortcut-label {
  font-weight: 500;
}

.shortcut-actions {
  display: inline-flex;
  flex-shrink: 0;
  justify-content: flex-end;
  gap: 1px;
  /* Room for both buttons (reset, add a key) in every row, so the columns line up. */
  min-width: calc(2 * var(--ink-control-sm) + 1px);
  opacity: 0;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.shortcut-item:hover .shortcut-actions,
.shortcut-item:focus-within .shortcut-actions {
  opacity: 1;
}

.shortcut-keys-column {
  display: inline-flex;
  flex-wrap: wrap;
  flex-shrink: 0;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  /* A steady width, so the VS/BR tags before it line up from row to row. */
  min-width: min(184px, 40%);
  max-width: 62%;
}

.key-button-wrap {
  position: relative;
  display: inline-flex;
}

.key-button {
  display: inline-flex;
  padding: 2px;
  border: 1px solid transparent;
  border-radius: var(--ink-radius);
  background: transparent;
  cursor: pointer;
}

.key-button:hover {
  border-color: var(--ink-border-strong);
  background: var(--ink-surface-sunken);
}

.key-button:focus-visible {
  outline: 1px solid var(--ink-focus);
}

/* The remove badge sits on the key's corner, so showing it doesn't move anything. */
.key-remove {
  position: absolute;
  top: -5px;
  right: -5px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 1px solid var(--ink-border-strong);
  border-radius: 50%;
  background: var(--ink-surface-raised);
  color: var(--ink-muted);
  opacity: 0;
  cursor: pointer;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.key-remove .codicon {
  font-size: 10px !important;
}

.key-button-wrap:hover .key-remove,
.key-remove:focus-visible {
  opacity: 1;
}

.key-remove:hover {
  border-color: var(--ink-danger);
  background: var(--ink-danger);
  color: #fff;
}

.key-empty {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 22px;
  padding: 0 8px;
  border: 1px dashed var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  font-size: var(--ink-font-xs);
  cursor: pointer;
}

.key-empty:hover {
  border-color: var(--ink-focus);
  color: var(--vscode-foreground);
}

.key-empty .codicon {
  font-size: 12px !important;
}

.key-recording {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  padding: 0 2px 0 8px;
  border: 1px solid var(--ink-focus);
  border-radius: var(--ink-radius-sm);
  background: var(--ink-accent-soft);
  box-shadow: 0 0 0 1px var(--ink-focus);
  font-size: var(--ink-font-xs);
}

.recording-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #ef4444;
  animation: ink-shortcut-pulse 1s ease-in-out infinite;
}

.key-recording-cancel {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.key-recording-cancel:hover {
  background: var(--ink-hover);
  color: inherit;
}

.shortcut-conflict {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 6px;
  padding: 0 0 6px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

@keyframes ink-shortcut-pulse {
  50% {
    opacity: 0.3;
  }
}

@media (prefers-reduced-motion: reduce) {
  .recording-dot {
    animation: none;
  }
}

body.vscode-high-contrast .key-button:hover {
  border-color: var(--vscode-contrastBorder);
}

/* Several keys for one action: "Ctrl T / Ctrl F4". */
.key-button-wrap + .key-button-wrap::before {
  content: '/';
  align-self: center;
  margin-right: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

/* Element picker hint (PickerHint) ------------------------------------------------------------
   Drawn over page content, so it has its own dark look (the theme's colors could vanish on the
   page), in both products. Each product places it. */
/* Two rows: what a click does (with each modifier), then the keys. */
.picker-hint {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 7px;
  /* Its own width: centered with left: 50%, it would otherwise wrap at half the page. */
  width: max-content;
  padding: 6px 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.9);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  line-height: 1;
  pointer-events: none;
  backdrop-filter: blur(6px);
}

.picker-hint-group {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 6px 14px;
}

.picker-hint-item {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
}

.picker-hint-label {
  color: rgba(250, 250, 250, 0.82);
}

/* The main action, as a sentence; the others read "[Shift] + click  select several". */
.picker-hint-lead {
  color: #fff;
  font-weight: 600;
}

.picker-hint-click {
  color: #fff;
  font-weight: 500;
}

.picker-hint .keycap {
  border-color: rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  box-shadow: inset 0 -1px 0 rgba(255, 255, 255, 0.14);
  color: #fff;
}

/* Multi-selection bar (SelectionBar) ----------------------------------------------------------
   Over page content like the picker hint, so the same dark look; each product places it. */
.selection-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px;
  width: max-content;
  max-width: calc(100vw - 32px);
  padding: 5px 6px 5px 10px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.94);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  pointer-events: auto;
}

.selection-bar-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: 6px;
  font-weight: 600;
}

.selection-bar-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: #0a84ff;
  color: #fff;
  font-size: var(--ink-font-xs);
}

.selection-bar .button.ghost,
.selection-bar .icon-button {
  color: #fafafa;
}

.selection-bar .button.ghost:hover:not(:disabled),
.selection-bar .icon-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.12);
}

.selection-bar .button-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.selection-bar .keycap {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.16);
  box-shadow: none;
  color: #fff;
}

/* Thumbnails with a checkbox each (ThumbPicker): screenshots taken together ------------------- */
.thumb-picker {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(88px, 1fr));
  gap: var(--ink-space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.thumb-picker-item {
  position: relative;
  border-radius: var(--ink-radius);
}

.thumb-picker-image {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  aspect-ratio: 16 / 10;
  padding: 0;
  overflow: hidden;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  color: var(--ink-muted);
  cursor: pointer;
  transition:
    opacity var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.thumb-picker-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

.thumb-picker-image:hover {
  border-color: var(--ink-border-strong);
}

/* Left out: dimmed, so what is sent stands out. */
.thumb-picker-item:not(.on) .thumb-picker-image {
  opacity: 0.45;
}

.thumb-picker-item.on .thumb-picker-image {
  border-color: var(--ink-accent);
}

.thumb-picker-check {
  position: absolute;
  top: 4px;
  left: 4px;
  padding: 2px;
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--vscode-editor-background) 80%, transparent);
  box-shadow: var(--ink-shadow-sm);
}

body.vscode-high-contrast .thumb-picker-item.on .thumb-picker-image {
  outline: 1px solid var(--vscode-contrastActiveBorder);
}
`;var ia={global:"Browser",inspect:"Element picker",draw:"Drawing",screenshot:"Screenshot",devtools:"Console and network",device:"Device",measure:"Measure",eyedropper:"Eyedropper",overlay:"Design overlay",tweak:"CSS tweak",record:"Record",a11y:"Accessibility check",capture:"After a capture"},B=e=>`vscodeBrowser.${e}`,Wt=[{id:"tab.new",label:"New tab",scope:"global",keys:["ctrl+t"],command:B("newTab")},{id:"tab.close",label:"Close tab",scope:"global",keys:["ctrl+w","ctrl+f4"],command:B("closeTab")},{id:"tab.reopen",label:"Reopen closed tab",scope:"global",keys:["ctrl+shift+t"],command:B("reopenClosedTab")},{id:"tab.next",label:"Next tab",scope:"global",keys:["ctrl+tab","ctrl+pagedown"],mac:["ctrl+tab","cmd+alt+right"],command:B("nextTab")},{id:"tab.previous",label:"Previous tab",scope:"global",keys:["ctrl+shift+tab","ctrl+pageup"],mac:["ctrl+shift+tab","cmd+alt+left"],command:B("previousTab")},{id:"tab.duplicate",label:"Duplicate tab",scope:"global",keys:[],command:B("duplicateTab")},{id:"tab.private",label:"New private tab",scope:"global",keys:["ctrl+shift+n"],command:B("newPrivateTab")},{id:"window.new",label:"New window",scope:"global",keys:["ctrl+n"],command:B("newWindow")},{id:"nav.address",label:"Focus the address bar",scope:"global",keys:["ctrl+l","alt+d"],mac:["cmd+l","alt+d"],command:B("focusAddressBar")},{id:"nav.back",label:"Back",scope:"global",keys:["alt+left"],mac:["cmd+["],command:B("goBack")},{id:"nav.forward",label:"Forward",scope:"global",keys:["alt+right"],mac:["cmd+]"],command:B("goForward")},{id:"nav.reload",label:"Reload",scope:"global",keys:["ctrl+r","f5"],mac:["cmd+r"],command:B("reload")},{id:"nav.hardReload",label:"Hard reload",scope:"global",keys:["ctrl+shift+r","ctrl+f5"],mac:["cmd+shift+r"],command:B("hardReload")},{id:"nav.stop",label:"Stop loading",scope:"global",keys:[],command:B("stop")},{id:"nav.home",label:"Home page",scope:"global",keys:["alt+home"],mac:["cmd+shift+h"],command:B("goHome")},{id:"page.find",label:"Find in page",scope:"global",keys:["ctrl+f"],command:B("find")},{id:"page.zoomIn",label:"Zoom in",scope:"global",keys:["ctrl+=","ctrl+shift+="],command:B("zoomIn")},{id:"page.zoomOut",label:"Zoom out",scope:"global",keys:["ctrl+-"],command:B("zoomOut")},{id:"page.zoomReset",label:"Reset zoom",scope:"global",keys:["ctrl+0"],command:B("zoomReset")},{id:"page.bookmark",label:"Bookmark this page",scope:"global",keys:["ctrl+d"],command:B("bookmarkPage")},{id:"page.source",label:"View page source",scope:"global",keys:["ctrl+u"],mac:["cmd+alt+u"],command:B("viewSource")},{id:"page.pdf",label:"Save page as PDF",scope:"global",keys:[],command:B("savePdf")},{id:"page.copyUrl",label:"Copy page address",scope:"global",keys:["ctrl+shift+l"],command:B("copyUrl")},{id:"page.external",label:"Open in system browser",scope:"global",keys:[],command:B("openInSystemBrowser")},{id:"page.devtools",label:"Open DevTools",scope:"global",keys:["f12"],command:B("openDevTools")},{id:"page.contextToAgent",label:"Send page context to agent",scope:"global",keys:["ctrl+alt+enter"],command:B("sendPageContextToChat")},{id:"agent.showContext",label:"Show agent context",scope:"global",keys:["ctrl+shift+alt+a"],command:B("showAgentContext"),everywhere:!0},{id:"agent.sendLatest",label:"Send the latest capture to the agent",scope:"global",keys:["ctrl+shift+alt+v"],command:B("sendLatestContext"),everywhere:!0},{id:"open.history",label:"History",scope:"global",keys:["ctrl+h"],mac:["cmd+y"],command:B("showHistory")},{id:"open.downloads",label:"Downloads",scope:"global",keys:["shift+alt+l"],command:B("showDownloads")},{id:"open.bookmarks",label:"Bookmark manager",scope:"global",keys:["ctrl+alt+b"],command:B("showBookmarks")},{id:"open.bookmarksBar",label:"Show or hide the bookmarks bar",scope:"global",keys:["ctrl+shift+b"]},{id:"open.quickActions",label:"Quick actions",scope:"global",keys:["ctrl+shift+k"]},{id:"open.shortcuts",label:"Change keyboard shortcuts",scope:"global",keys:["ctrl+alt+k"],command:B("editShortcuts")},{id:"open.cheatSheet",label:"Keyboard shortcuts of this mode",scope:"global",keys:["ctrl+shift+/"],mac:["cmd+alt+/"]},{id:"mode.inspect",label:"Element picker",scope:"global",keys:["shift+alt+e"]},{id:"mode.draw",label:"Draw on the page",scope:"global",keys:["shift+alt+w"]},{id:"mode.screenshot",label:"Screenshot",scope:"global",keys:["shift+alt+g"]},{id:"mode.devtools",label:"Console and network",scope:"global",keys:["shift+alt+j"]},{id:"mode.device",label:"Device toolbar",scope:"global",keys:["shift+alt+m"]},{id:"mode.measure",label:"Measure",scope:"global",keys:["shift+alt+u"]},{id:"mode.eyedropper",label:"Eyedropper",scope:"global",keys:["shift+alt+y"]},{id:"mode.overlay",label:"Design overlay",scope:"global",keys:["shift+alt+o"]},{id:"mode.tweak",label:"CSS tweak",scope:"global",keys:["shift+alt+v"]},{id:"mode.record",label:"Record the page",scope:"global",keys:["ctrl+alt+r"]},{id:"mode.a11y",label:"Accessibility check",scope:"global",keys:["shift+alt+h"]},{id:"inspect.parent",label:"Select the parent element",scope:"inspect",keys:["up"]},{id:"inspect.child",label:"Select the first child element",scope:"inspect",keys:["down"]},{id:"inspect.copy",label:"Copy the selected elements",scope:"inspect",keys:["enter","c"]},{id:"inspect.screenshot",label:"Screenshot the element",scope:"inspect",keys:["s"]},{id:"inspect.agent",label:"Send the element to the agent",scope:"inspect",keys:["a"]},{id:"inspect.help",label:"Show these shortcuts",scope:"inspect",keys:["shift+/"]},{id:"inspect.exit",label:"Exit",scope:"inspect",keys:["escape"]},{id:"draw.select",label:"Select and move",scope:"draw",keys:["v"]},{id:"draw.pen",label:"Pen",scope:"draw",keys:["p"]},{id:"draw.pencil",label:"Pencil",scope:"draw",keys:["i"]},{id:"draw.marker",label:"Marker",scope:"draw",keys:["m"]},{id:"draw.brush",label:"Brush",scope:"draw",keys:["u"]},{id:"draw.highlighter",label:"Highlighter",scope:"draw",keys:["h"]},{id:"draw.neon",label:"Neon",scope:"draw",keys:["g"]},{id:"draw.line",label:"Line",scope:"draw",keys:["l"]},{id:"draw.arrow",label:"Arrow",scope:"draw",keys:["a"]},{id:"draw.doubleArrow",label:"Double arrow",scope:"draw",keys:["d"]},{id:"draw.rect",label:"Rectangle",scope:"draw",keys:["r"]},{id:"draw.ellipse",label:"Ellipse",scope:"draw",keys:["o"]},{id:"draw.text",label:"Text",scope:"draw",keys:["t"]},{id:"draw.callout",label:"Numbered callout",scope:"draw",keys:["n"]},{id:"draw.blur",label:"Redact (pixelate)",scope:"draw",keys:["b"]},{id:"draw.eraser",label:"Eraser",scope:"draw",keys:["e"]},...[1,2,3,4,5,6,7,8,9].map(e=>({id:`draw.color${e}`,label:`Color ${e}`,scope:"draw",keys:[String(e)]})),{id:"draw.thinner",label:"Thinner stroke",scope:"draw",keys:["["]},{id:"draw.thicker",label:"Thicker stroke",scope:"draw",keys:["]"]},{id:"draw.fill",label:"Fill shapes on or off",scope:"draw",keys:["f"]},{id:"draw.undo",label:"Undo",scope:"draw",keys:["ctrl+z"]},{id:"draw.redo",label:"Redo",scope:"draw",keys:["ctrl+y","ctrl+shift+z"]},{id:"draw.clear",label:"Clear all drawings",scope:"draw",keys:["shift+backspace"]},{id:"draw.visible",label:"Hide or show drawings",scope:"draw",keys:["w"]},{id:"draw.capture",label:"Screenshot the drawing area",scope:"draw",keys:["enter"]},{id:"draw.captureAgent",label:"Screenshot the drawing area and send it to the agent",scope:"draw",keys:["shift+enter"]},{id:"draw.captureMenu",label:"Screenshot menu",scope:"draw",keys:["s"]},{id:"draw.captureGroups",label:"Screenshot each drawing separately",scope:"draw",keys:["alt+g"]},{id:"draw.captureClean",label:"Screenshot the drawing area without drawings",scope:"draw",keys:["alt+c"]},{id:"draw.captureViewport",label:"Screenshot the visible area with drawings",scope:"draw",keys:["alt+v"]},{id:"draw.captureFullPage",label:"Screenshot the full page with drawings",scope:"draw",keys:["alt+f"]},{id:"draw.help",label:"Show these shortcuts",scope:"draw",keys:["shift+/"]},{id:"draw.exit",label:"Stop drawing",scope:"draw",keys:["escape"]},{id:"shot.viewport",label:"Visible area",scope:"screenshot",keys:["v"]},{id:"shot.fullPage",label:"Full page",scope:"screenshot",keys:["f"]},{id:"shot.region",label:"Region",scope:"screenshot",keys:["r"]},{id:"shot.element",label:"Element",scope:"screenshot",keys:["e"]},{id:"shot.drawing",label:"Drawing area",scope:"screenshot",keys:["d"]},{id:"shot.lastToAgent",label:"Send the last screenshot to the agent",scope:"screenshot",keys:["a"],command:B("screenshot.sendToTerminal")},{id:"capture.chat",label:"Send to chat",scope:"capture",keys:["alt+shift+c"]},{id:"capture.terminal",label:"Send to terminal",scope:"capture",keys:["alt+shift+x"]},{id:"capture.save",label:"Save in VS Code",scope:"capture",keys:["alt+shift+s"]},{id:"capture.download",label:"Download",scope:"capture",keys:["alt+shift+d"]},{id:"dev.console",label:"Console",scope:"devtools",keys:["alt+1"]},{id:"dev.network",label:"Network",scope:"devtools",keys:["alt+2"]},{id:"dev.filter",label:"Filter",scope:"devtools",keys:["alt+f"]},{id:"dev.copyErrors",label:"Copy console errors",scope:"devtools",keys:["alt+e"]},{id:"dev.copyFailed",label:"Copy failed requests",scope:"devtools",keys:["alt+q"]},{id:"dev.copyContext",label:"Copy page context",scope:"devtools",keys:["alt+p"]},{id:"dev.contextAgent",label:"Send page context to the agent",scope:"devtools",keys:["alt+shift+p"]},{id:"dev.clear",label:"Clear",scope:"devtools",keys:["alt+k"]},{id:"dev.close",label:"Close",scope:"devtools",keys:["alt+w"]},{id:"device.previous",label:"Previous device",scope:"device",keys:["alt+["]},{id:"device.next",label:"Next device",scope:"device",keys:["alt+]"]},{id:"device.rotate",label:"Rotate",scope:"device",keys:["alt+r"]},{id:"device.touch",label:"Touch and mobile on or off",scope:"device",keys:["alt+t"]},{id:"device.fit",label:"Fit to window",scope:"device",keys:["alt+0"]},{id:"device.zoomIn",label:"Zoom in",scope:"device",keys:["alt+="]},{id:"device.zoomOut",label:"Zoom out",scope:"device",keys:["alt+-"]},{id:"device.network",label:"Next network speed",scope:"device",keys:["alt+n"]},{id:"device.theme",label:"Next color scheme",scope:"device",keys:["alt+l"]},{id:"device.close",label:"Close the device toolbar",scope:"device",keys:[]},{id:"measure.grid",label:"Rulers and grid on or off",scope:"measure",keys:["g"]},{id:"measure.copy",label:"Copy the measurements",scope:"measure",keys:["c"]},{id:"measure.clear",label:"Clear the pinned element",scope:"measure",keys:["backspace"]},{id:"measure.help",label:"Show these shortcuts",scope:"measure",keys:["shift+/"]},{id:"measure.exit",label:"Exit",scope:"measure",keys:["escape"]},{id:"eyedropper.hex",label:"Copy colors as hex",scope:"eyedropper",keys:["h"]},{id:"eyedropper.rgb",label:"Copy colors as rgb()",scope:"eyedropper",keys:["r"]},{id:"eyedropper.hsl",label:"Copy colors as hsl()",scope:"eyedropper",keys:["l"]},{id:"eyedropper.help",label:"Show these shortcuts",scope:"eyedropper",keys:["shift+/"]},{id:"eyedropper.exit",label:"Exit",scope:"eyedropper",keys:["escape"]},{id:"overlay.open",label:"Open an image",scope:"overlay",keys:["alt+o"]},{id:"overlay.fainter",label:"Less opaque",scope:"overlay",keys:["alt+,"]},{id:"overlay.stronger",label:"More opaque",scope:"overlay",keys:["alt+."]},{id:"overlay.left",label:"Nudge left",scope:"overlay",keys:["alt+left"]},{id:"overlay.right",label:"Nudge right",scope:"overlay",keys:["alt+right"]},{id:"overlay.up",label:"Nudge up",scope:"overlay",keys:["alt+up"]},{id:"overlay.down",label:"Nudge down",scope:"overlay",keys:["alt+down"]},{id:"overlay.difference",label:"Difference blend on or off",scope:"overlay",keys:["alt+x"]},{id:"overlay.hide",label:"Hide or show the overlay",scope:"overlay",keys:["alt+h"]},{id:"overlay.exit",label:"Close the overlay",scope:"overlay",keys:["alt+z"]},{id:"tweak.agent",label:"Send the CSS changes to the agent",scope:"tweak",keys:["ctrl+enter"]},{id:"tweak.copy",label:"Copy the CSS changes",scope:"tweak",keys:["ctrl+shift+c"]},{id:"tweak.undo",label:"Undo the last change",scope:"tweak",keys:["ctrl+z"]},{id:"tweak.exit",label:"Exit and revert",scope:"tweak",keys:["escape"]},{id:"record.stop",label:"Stop and save",scope:"record",keys:["alt+s"]},{id:"record.pause",label:"Pause or resume",scope:"record",keys:["alt+y"]},{id:"record.cancel",label:"Cancel",scope:"record",keys:["alt+backspace"]},{id:"a11y.next",label:"Next issue",scope:"a11y",keys:["n","down"]},{id:"a11y.previous",label:"Previous issue",scope:"a11y",keys:["p","up"]},{id:"a11y.tabOrder",label:"Tab order on or off",scope:"a11y",keys:["t"]},{id:"a11y.copy",label:"Copy the report",scope:"a11y",keys:["c"]},{id:"a11y.agent",label:"Send the report to the agent",scope:"a11y",keys:["a"]},{id:"a11y.help",label:"Show these shortcuts",scope:"a11y",keys:["shift+/"]},{id:"a11y.exit",label:"Exit",scope:"a11y",keys:["escape"]}];function ra(e,t){return t?[...e.mac??e.keys.map(n=>n.replace(/\bctrl\+/,"cmd+"))]:[...e.keys]}function bc(e){let t=fi(e.trim());return t.key?[t.ctrl&&"ctrl",t.shift&&"shift",t.alt&&"alt",t.meta&&"cmd",t.key].filter(Boolean).join("+"):""}function mc(e,t){let n={};for(let o of Wt){let a=e[o.id],c=(a===void 0?ra(o,t):typeof a=="string"?[a]:[...a]).map(bc);n[o.id]=[...new Set(c.filter(Boolean))]}return n}function Ad(e){if(!e||typeof e!="object"||Array.isArray(e))return{};let t=new Set(Wt.map(o=>o.id)),n={};for(let[o,a]of Object.entries(e))t.has(o)&&(typeof a=="string"||Array.isArray(a)&&a.every(c=>typeof c=="string"))&&(n[o]=a);return n}var Td=new Set(["devtools","device","overlay","record","capture"]);function _d(e){let t=new Map(Wt.map(a=>[a.id,a.scope])),n=new Map;for(let[a,c]of Object.entries(e))for(let l of c)n.set(l,[...n.get(l)??[],a]);let o=[];for(let[a,c]of n)for(let l=0;l<c.length;l++)for(let i=l+1;i<c.length;i++){let[r,u]=[t.get(c[l]),t.get(c[i])];(r===u||Td.has(r)&&Td.has(u))&&o.push({key:a,ids:[c[l],c[i]]})}return o}function ui(e){return[e.ctrl&&"ctrl",e.shift&&"shift",e.alt&&"alt",e.meta&&"cmd",e.key].filter(Boolean).join("+")}var di=new Set(["mode.inspect","mode.draw","mode.screenshot","mode.device","mode.devtools","page.bookmark","open.shortcuts","inspect.parent","inspect.child","inspect.copy","inspect.exit",...["select","pen","pencil","marker","brush","highlighter","neon","line","arrow","doubleArrow","rect","ellipse","text","callout","blur","eraser"].map(e=>`draw.${e}`),...Array.from({length:9},(e,t)=>`draw.color${t+1}`),"draw.thinner","draw.thicker","draw.fill","draw.undo","draw.redo","draw.clear","draw.visible","draw.capture","draw.captureMenu","draw.captureGroups","draw.captureClean","draw.captureViewport","draw.captureFullPage","draw.exit","shot.viewport","shot.fullPage","shot.region","shot.element","shot.drawing","capture.chat","capture.terminal","capture.save","capture.download"]),jp=new Set(["capture"]),Ed={id:"vs",label:"VS",title:"Works in VS Code Browser"},zd={id:"br",label:"BR",title:"Works in the Inkspect toolbar in your browser (Chrome, Edge, Firefox...)"};function Md(e){return jp.has(e.scope)?[zd]:di.has(e.id)?[Ed,zd]:[Ed]}var Qp={control:"ctrl",ctl:"ctrl","\u2303":"ctrl",option:"alt",opt:"alt","\u2325":"alt",command:"cmd",meta:"cmd",win:"cmd",super:"cmd","\u2318":"cmd","\u21E7":"shift",esc:"escape",return:"enter","\u21A9":"enter",del:"delete","\u2191":"up","\u2193":"down","\u2190":"left","\u2192":"right",pgup:"pageup",pgdn:"pagedown","+":"="},Nd=new Set(["ctrl","shift","alt","cmd"]);function gc(e,t){let n=t.toLowerCase().replace(/([⌃⌥⇧⌘↩↑↓←→])/g," $1 ").split(/\s+|[+-](?=.)/).filter(Boolean).map(r=>Qp[r]??r);if(!n.length)return!1;let o=n.filter(r=>Nd.has(r)),a=n.filter(r=>!Nd.has(r));if(a.length>1)return!1;let c=fi(bc(e)),l={ctrl:c.ctrl,shift:c.shift,alt:c.alt,cmd:c.meta};if(!o.every(r=>l[r]))return!1;let[i]=a;return i===void 0||c.key.startsWith(i)}function Dd(e){if(!e.key)return;let t=/^f([1-9]|1\d|2[0-4])$/.test(e.key);return e.ctrl||e.alt||e.meta||t?ui(e):void 0}function Rd(e,t){let n=At(e,t);return t?[...[...n.matchAll(/[⌃⌥⇧⌘]/g)].map(a=>a[0]),n.replace(/[⌃⌥⇧⌘]/g,"")]:n.split(/\+(?=.)/)}var Ud={global:"browser",inspect:"inspect",draw:"edit",screenshot:"device-camera",devtools:"debug-console",device:"device-mobile",measure:"symbol-ruler",eyedropper:"symbol-color",overlay:"layers",tweak:"symbol-property",record:"record",a11y:"accessibility",capture:"check-all"};function At(e,t){let n=fi(e),o={escape:"Esc",enter:t?"\u21A9":"Enter",backspace:t?"\u232B":"Backspace",delete:t?"\u2326":"Delete",up:"\u2191",down:"\u2193",left:"\u2190",right:"\u2192",pageup:"PgUp",pagedown:"PgDn",tab:t?"\u21E5":"Tab",space:"Space","/":n.shift?"?":"/"},a=!(n.key==="/"&&n.shift),c=o[n.key]??(n.key.length===1?n.key.toUpperCase():n.key[0].toUpperCase()+n.key.slice(1));return t?`${n.ctrl?"\u2303":""}${n.alt?"\u2325":""}${n.shift&&a?"\u21E7":""}${n.meta?"\u2318":""}${c}`:[n.ctrl&&"Ctrl",n.alt&&"Alt",n.shift&&a&&"Shift",c].filter(Boolean).join("+")}function fi(e){let t=e.toLowerCase().split("+"),n=t.pop()??"";return{ctrl:t.includes("ctrl"),shift:t.includes("shift"),alt:t.includes("alt"),meta:t.includes("cmd")||t.includes("meta")||t.includes("win"),key:n}}var Xp={arrowleft:"left",arrowright:"right",arrowup:"up",arrowdown:"down",esc:"escape"," ":"space","+":"="},Od={Equal:"=",Minus:"-",BracketLeft:"[",BracketRight:"]",Slash:"/",Backslash:"\\",Comma:",",Period:".",Semicolon:";",Quote:"'",Backquote:"`",NumpadAdd:"=",NumpadSubtract:"-"},pc=new Set(["Control","Shift","Alt","Meta","AltGraph","OS"]),Cd={"?":"/","<":",",">":".",":":";",'"':"'","{":"[","}":"]","|":"\\","~":"`",_:"-","+":"=","!":"1","@":"2","#":"3",$:"4","%":"5","^":"6","&":"7","*":"8","(":"9",")":"0"};function vc(e){let t={ctrl:e.ctrlKey,shift:e.shiftKey,alt:e.altKey,meta:e.metaKey};if(e.getModifierState?.("AltGraph"))return{...t,key:""};let n=e.key,o;return/^[a-z0-9]$/i.test(n)?o=n.toLowerCase():e.shiftKey&&Cd[n]!==void 0?o=Cd[n]:/^[-=[\]\\/,.;'`+]$/.test(n)?o=n:/^Key[A-Z]$/.test(e.code)?o=e.code.slice(3).toLowerCase():/^Digit\d$/.test(e.code)?o=e.code.slice(5):Od[e.code]?o=Od[e.code]:o=n.toLowerCase(),{...t,key:Xp[o]??o}}var $d=L(mt(),1);var Wd,uv=e=>{let t=e.composedPath()[0];if(e.button!==0){Wd=void 0;return}t instanceof Element&&(Wd={element:t.closest('button, [role="button"], a')??t,at:performance.now()})};typeof window<"u"&&window.addEventListener("pointerdown",uv,!0);function _t(...e){return e.filter(Boolean).join(" ")}var lo=L(te(),1);function ua({variant:e="secondary",size:t="md",icon:n,iconEnd:o,loading:a,className:c,children:l,disabled:i,type:r="button",...u}){let m=a?"loading":n;return(0,lo.jsxs)("button",{type:r,className:_t("button",e,t==="sm"&&"small",c),disabled:i||a,"aria-busy":a||void 0,...u,children:[m&&(0,lo.jsx)("span",{className:_t("codicon",`codicon-${m}`,a&&"codicon-modifier-spin"),"aria-hidden":"true"}),l!==void 0&&(0,lo.jsx)("span",{className:"button-label",children:l}),o&&(0,lo.jsx)("span",{className:`codicon codicon-${o}`,"aria-hidden":"true"})]})}var Sc=L(mt(),1);var tf=L(te(),1);function yi({children:e,confirmLabel:t,onConfirm:n,icon:o,variant:a="ghost",size:c="sm",disabled:l,title:i,className:r}){let[u,m]=(0,Sc.useState)(!1);return(0,Sc.useEffect)(()=>{if(!u)return;let p=setTimeout(()=>m(!1),4e3);return()=>clearTimeout(p)},[u]),(0,tf.jsx)(ua,{size:c,variant:u?"danger":a,icon:u?"warning":o,disabled:l,title:i,className:r,"aria-live":"polite",onClick:()=>{if(!u){m(!0);return}m(!1),n()},onBlur:()=>m(!1),children:u?t:e})}var Si=L(te(),1),sv=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function da({binding:e,size:t="md"}){let n=Rd(e,sv);return(0,Si.jsx)("span",{className:`keycaps size-${t}`,"aria-label":n.join("+"),children:n.map((o,a)=>(0,Si.jsx)("kbd",{className:"keycap",children:o},a))})}var nf=L(mt(),1);var An=L(te(),1);function of({value:e,options:t,onChange:n,label:o,iconOnly:a,size:c="md",className:l}){let i=(0,nf.useRef)(null),r=u=>{let m={ArrowRight:1,ArrowDown:1,ArrowLeft:-1,ArrowUp:-1}[u.key];if(!m)return;u.preventDefault();let p=t.findIndex(s=>s.value===e),d=t[(p+m+t.length)%t.length];n(d.value),i.current?.querySelector(`[data-value="${CSS.escape(d.value)}"]`)?.focus()};return(0,An.jsx)("div",{ref:i,className:_t("segmented",`size-${c}`,l),role:"radiogroup","aria-label":o,onKeyDown:r,children:t.map(u=>{let m=u.value===e;return(0,An.jsxs)("button",{type:"button",role:"radio","aria-checked":m,"aria-label":a?u.label:void 0,title:a||u.icon?u.label:void 0,"data-value":u.value,tabIndex:m?0:-1,className:_t("segment",m&&"checked"),onClick:()=>n(u.value),children:[u.icon&&(0,An.jsx)("span",{className:`codicon codicon-${u.icon}`,"aria-hidden":"true"}),!a&&(0,An.jsx)("span",{className:"segment-label",children:u.label}),u.count!==void 0&&(0,An.jsx)("span",{className:_t("segment-count",u.tone),children:u.count})]},u.value)})})}var $t=L(mt(),1);var xi=L(te(),1);function ki({icon:e,label:t,onClick:n,onContextMenu:o,disabled:a,active:c,spin:l,className:i}){return(0,xi.jsx)("button",{type:"button",className:["icon-button",c&&"active",i].filter(Boolean).join(" "),title:t,"aria-label":t,"aria-pressed":c,disabled:a,onClick:n,onContextMenu:o,children:(0,xi.jsx)("span",{className:`codicon codicon-${e}${l?" codicon-modifier-spin":""}`,"aria-hidden":"true"})})}var _=L(te(),1),io=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function cf({actions:e,scopes:t,map:n,overrides:o,query:a="",labelOf:c=u=>u.label,scopeLabel:l=u=>ia[u],onSetKeys:i,onReset:r}){let[u,m]=(0,$t.useState)(new Set),[p,d]=(0,$t.useState)(null),s=(0,$t.useMemo)(()=>new Set(e.map(b=>b.id)),[e]),y=(0,$t.useMemo)(()=>_d(n).filter(b=>b.ids.every(v=>s.has(v))),[n,s]),w=b=>y.filter(v=>v.ids.includes(b)).map(v=>({key:v.key,other:v.ids.find(x=>x!==b)}));(0,$t.useEffect)(()=>{if(!p)return;let b=x=>{if(x.preventDefault(),x.stopImmediatePropagation(),pc.has(x.key))return;let T=vc(x);if(!T.key)return;let k=!T.ctrl&&!T.alt&&!T.meta&&!T.shift,E=[...n[p.id]??[]];if(k&&T.key==="escape"){d(null);return}if(k&&T.key==="backspace"&&p.index!==void 0)E.splice(p.index,1);else{let Z=ui(T);p.index===void 0?E.push(Z):E[p.index]=Z}i(p.id,[...new Set(E)]),d(null)},v=x=>{x.composedPath().some(k=>k instanceof HTMLElement&&k.classList.contains("key-recording"))||d(null)};return window.addEventListener("keydown",b,!0),window.addEventListener("pointerdown",v,!0),()=>{window.removeEventListener("keydown",b,!0),window.removeEventListener("pointerdown",v,!0)}},[p,n,i]);let z=a.trim().toLowerCase(),g=b=>!z||c(b).toLowerCase().includes(z)||b.id.toLowerCase().includes(z)||l(b.scope).toLowerCase().includes(z)||(n[b.id]??[]).some(v=>At(v,io).toLowerCase().includes(z)||gc(v,z)),f=b=>{let v=e.find(x=>x.id===b);return v?c(v):b};return(0,_.jsxs)("div",{className:"shortcut-list",children:[y.length>0&&(0,_.jsxs)("p",{className:"shortcuts-warning",role:"alert",children:[(0,_.jsx)("span",{className:"codicon codicon-warning","aria-hidden":"true"}),y.length===1?"1 key is":`${y.length} keys are`," used twice."]}),t.map(b=>{let v=e.filter(T=>T.scope===b&&g(T));if(!v.length)return null;let x=z!==""||!u.has(b);return(0,_.jsxs)("section",{className:"shortcut-group",children:[(0,_.jsxs)("button",{type:"button",className:"group-header","aria-expanded":x,onClick:()=>m(T=>{let k=new Set(T);return k.has(b)?k.delete(b):k.add(b),k}),children:[(0,_.jsx)("span",{className:`codicon codicon-chevron-${x?"down":"right"}`,"aria-hidden":"true"}),(0,_.jsx)("span",{className:`codicon codicon-${Ud[b]} group-icon`,"aria-hidden":"true"}),(0,_.jsx)("span",{className:"group-title",children:l(b)}),(0,_.jsx)("span",{className:"group-count",children:v.length})]}),x&&v.map(T=>(0,_.jsx)(bv,{action:T,label:c(T),keys:n[T.id]??[],changed:T.id in o,conflicts:w(T.id).map(k=>({...k,otherLabel:f(k.other)})),recording:p?.id===T.id?p:null,onRecord:k=>d({id:T.id,index:k}),onCancel:()=>d(null),onRemove:k=>i(T.id,(n[T.id]??[]).filter((E,Z)=>Z!==k)),onReset:()=>r(T.id),onResolve:(k,E)=>i(k,(n[k]??[]).filter(Z=>Z!==E))},T.id))]},b)})]})}function bv({action:e,label:t,keys:n,changed:o,conflicts:a,recording:c,onRecord:l,onCancel:i,onRemove:r,onReset:u,onResolve:m}){let p=ra(e,io).map(s=>At(s,io)).join(", ")||"none",d=c!==null&&c.index===void 0;return(0,_.jsxs)("div",{className:`shortcut-item${o?" changed":""}${a.length?" conflict":""}`,children:[(0,_.jsxs)("div",{className:"shortcut-main",children:[(0,_.jsx)("span",{className:"shortcut-label",title:e.id,children:t}),(0,_.jsx)("span",{className:"shortcut-places",children:Md(e).map(s=>(0,_.jsx)("span",{className:`shortcut-tag ${s.id}`,title:s.title,children:s.label},s.id))}),(0,_.jsxs)("span",{className:"shortcut-actions",children:[o&&(0,_.jsx)(ki,{icon:"discard",label:`Reset to default (${p})`,className:"small",onClick:u}),n.length>0&&!d&&(0,_.jsx)(ki,{icon:"add",label:"Add another key",className:"small add-key",onClick:()=>l()})]}),(0,_.jsxs)("span",{className:"shortcut-keys-column",children:[n.map((s,y)=>c?.index===y?(0,_.jsx)(af,{onCancel:i},s):(0,_.jsxs)("span",{className:"key-button-wrap",children:[(0,_.jsx)("button",{type:"button",className:"key-button",title:"Change: click, then press the new keys","aria-label":`${At(s,io)}: change`,onClick:()=>l(y),children:(0,_.jsx)(da,{binding:s,size:"sm"})}),(0,_.jsx)("button",{type:"button",className:"key-remove","aria-label":`Remove ${At(s,io)}`,title:"Remove this key",onClick:()=>r(y),children:(0,_.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]},s)),d&&(0,_.jsx)(af,{onCancel:i}),!n.length&&!d&&(0,_.jsxs)("button",{type:"button",className:"key-empty",title:"Add a key: click, then press the keys",onClick:()=>l(),children:[(0,_.jsx)("span",{className:"codicon codicon-add","aria-hidden":"true"}),"Add key"]})]})]}),a.map(({key:s,other:y,otherLabel:w})=>(0,_.jsxs)("div",{className:"shortcut-conflict",children:[(0,_.jsx)("span",{className:"codicon codicon-warning","aria-hidden":"true"}),(0,_.jsxs)("span",{children:[At(s,io)," is also \u201C",w,"\u201D"]}),(0,_.jsx)("button",{type:"button",className:"link-button",onClick:()=>m(y,s),children:"Remove it there"})]},`${s}-${y}`))]})}function af({onCancel:e}){return(0,_.jsxs)("span",{className:"key-recording",role:"status",children:[(0,_.jsx)("span",{className:"recording-dot","aria-hidden":"true"}),"Press keys\u2026",(0,_.jsx)("button",{type:"button",className:"key-recording-cancel","aria-label":"Cancel",onClick:e,children:(0,_.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]})}var Mn=L(mt(),1);var _n=L(te(),1);function lf({icon:e,trailing:t,size:n="md",onClear:o,invalid:a,className:c,disabled:l,...i}){let r=i.value!==void 0&&String(i.value)!=="";return(0,_n.jsxs)("div",{className:_t("text-field",`size-${n}`,a&&"invalid",l&&"disabled",c),children:[e&&(0,_n.jsx)("span",{className:`codicon codicon-${e} text-field-icon`,"aria-hidden":"true"}),(0,_n.jsx)("input",{spellCheck:!1,...i,disabled:l,"aria-invalid":a||void 0}),o&&r&&(0,_n.jsx)("button",{type:"button",className:"text-field-clear","aria-label":"Clear",title:"Clear",tabIndex:-1,onClick:o,children:(0,_n.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})}),t]})}var df=L(te(),1),mv=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),Mt=null;function rf(e){return Mt?(Mt(e),!0):!1}typeof window<"u"&&window.addEventListener("keydown",e=>{if(!Mt||pc.has(e.key))return;e.stopImmediatePropagation();let t=Dd(vc(e));t&&(e.preventDefault(),Mt(t))},!0);function uf({value:e,onChange:t,size:n}){let o=(0,Mn.useRef)(t);(0,Mn.useEffect)(()=>{o.current=t});let[a]=(0,Mn.useState)(()=>c=>o.current(At(c,mv)));return(0,Mn.useEffect)(()=>()=>{Mt===a&&(Mt=null)},[a]),(0,df.jsx)(lf,{size:n,icon:"search",placeholder:"Search actions or keys, or press a shortcut","aria-label":"Search shortcuts: type, or press a shortcut",value:e,onChange:c=>t(c.target.value),onClear:()=>t(""),onFocus:()=>{Mt=a},onBlur:()=>{Mt===a&&(Mt=null)}})}var lt=L(mt()),_p=L(vp());var li="inkspectShortcuts",ii=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),s1=Wt.filter(e=>di.has(e.id)),ky={"mode.device":"Responsive view","mode.screenshot":"Screenshot menu","open.shortcuts":"Keyboard shortcuts"},yp=e=>ky[e.id]??e.label,Sp=e=>e==="global"?"General":ia[e],hp=["global","inspect","draw","screenshot"],xp=[...hp,...Object.keys(ia).filter(e=>!hp.includes(e))];async function kp(){let e=(await chrome.storage.sync.get(li))[li];return{overrides:Ad(e?.shortcuts??{}),updated:typeof e?.updated=="number"?e.updated:0}}async function wp(e){let{updated:t}=await kp();await chrome.storage.sync.set({[li]:{shortcuts:e,updated:Math.max(Date.now(),t+1)}})}function Tp(e){let t=()=>{kp().then(o=>e(mc(o.overrides,ii),o))},n=(o,a)=>{a==="sync"&&o[li]&&t()};return chrome.storage.onChanged.addListener(n),t(),()=>chrome.storage.onChanged.removeListener(n)}async function yd(e,t,n){let o={...e},a=Wt.find(i=>i.id===t),c=a?ra(a,ii).map(bc):[],l=n!==void 0&&n.length===c.length&&n.every(i=>c.includes(i));n===void 0||l?delete o[t]:o[t]=n,await wp(o)}async function Ep(){await wp({})}var ue=L(te());function zp({status:e,limit:t=1/0,size:n="lg"}){let o=e.state==="connected",a=o?e.windows?.length?[...e.windows].sort((r,u)=>r.name.localeCompare(u.name)||r.id.localeCompare(u.id)):[{id:"peer",name:e.peer??"VS Code",lastUsed:!0}]:[],c=a.slice(0,t),l=a.length-c.length,i=c.findIndex(r=>r.lastUsed);return(0,ue.jsxs)("div",{className:`link-graph size-${n} state-${e.state}`,"aria-hidden":"true",children:[(0,ue.jsx)("span",{className:"graph-node source",children:(0,ue.jsx)("span",{className:"codicon codicon-globe"})}),(0,ue.jsx)("ul",{className:"graph-targets",children:o?(0,ue.jsxs)(ue.Fragment,{children:[c.map((r,u)=>(0,ue.jsxs)("li",{className:`graph-target${r.lastUsed?" lit":u<i?" on-path":""}`,children:[(0,ue.jsx)("span",{className:"graph-node",children:(0,ue.jsx)("span",{className:"codicon codicon-vscode"})}),(0,ue.jsx)("span",{className:"graph-name",children:r.name}),r.lastUsed&&(0,ue.jsx)("span",{className:"graph-tag",children:"Sends go here"})]},r.id)),l>0&&(0,ue.jsx)("li",{className:"graph-target more",children:(0,ue.jsxs)("span",{className:"graph-name",children:["and ",l," more"]})})]}):(0,ue.jsxs)("li",{className:"graph-target pending",children:[(0,ue.jsx)("span",{className:"graph-node",children:(0,ue.jsx)("span",{className:"codicon codicon-vscode"})}),(0,ue.jsx)("span",{className:"graph-name",children:"VS Code"})]})})]})}var Np=`/* LinkGraph: the browser, and a branch to each VS Code window (a tree connector drawn in CSS).
   The branch to the window used last is lit: that is where sends go. */

.link-graph {
  --line: color-mix(in srgb, var(--vscode-foreground) 20%, transparent);
  --lit: var(--ink-blue);
  --node: 44px;
  --stem: 32px;
  --stroke: 2px;
  --row-pad: 5px;
  display: flex;
  align-items: flex-start;
  min-width: 0;
}

.link-graph.size-sm {
  --node: 30px;
  --stem: 18px;
  --row-pad: 3px;
}

.link-graph.state-unpaired {
  --line: color-mix(in srgb, var(--ink-yellow) 70%, transparent);
}

.link-graph.state-connecting {
  --line: color-mix(in srgb, var(--ink-blue) 55%, transparent);
}

.graph-node {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: var(--node);
  height: var(--node);
  border: 1px solid var(--ink-border-strong);
  border-radius: calc(var(--node) / 3.2);
  background: linear-gradient(
    180deg,
    color-mix(in srgb, var(--vscode-foreground) 7%, var(--vscode-editor-background)),
    var(--vscode-editor-background)
  );
  color: var(--vscode-foreground);
  box-shadow: var(--ink-shadow-sm);
}

.size-lg .graph-node .codicon {
  font-size: 22px !important;
}

.size-sm .graph-node .codicon {
  font-size: 15px !important;
}

/* The source sits level with the first branch; its stem runs straight into it (the border is
   outside the pseudo-element's box, so it starts one pixel further out to meet the bus). */
.graph-node.source {
  position: relative;
  margin-top: var(--row-pad);
  margin-right: var(--stem);
}

.graph-node.source::after {
  content: '';
  position: absolute;
  top: calc(50% - var(--stroke) / 2);
  left: calc(100% + 1px);
  width: var(--stem);
  height: var(--stroke);
  background: var(--line);
}

.link-graph.state-connected .graph-node.source::after {
  background: var(--lit);
}

.link-graph:not(.state-connected) .graph-node.source::after {
  background: repeating-linear-gradient(90deg, var(--line) 0 5px, transparent 5px 9px);
}

.graph-targets {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  margin: 0;
  padding: 0;
  list-style: none;
}

.graph-target {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  padding: var(--row-pad) 0 var(--row-pad) var(--stem);
}

.size-sm .graph-target {
  gap: 9px;
}

/* The branch into this target, and the bus down to the next (rounded into the bus). */
.graph-target::before {
  content: '';
  position: absolute;
  top: calc(50% - var(--stroke) / 2);
  left: 0;
  width: var(--stem);
  height: var(--stroke);
  border-radius: var(--stroke);
  background: var(--line);
}

.graph-target::after {
  content: '';
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: var(--stroke);
  background: var(--line);
}

.graph-target:first-child::after {
  top: 50%;
}

.graph-target:last-child::after {
  bottom: 50%;
}

.graph-target:only-child::after {
  display: none;
}

.graph-target.pending::before {
  background: repeating-linear-gradient(90deg, var(--line) 0 5px, transparent 5px 9px);
}

/* Where sends go: lit, and so is the bus from the browser down to it. */
.graph-target.lit::before {
  z-index: 1;
  background: var(--lit);
}

.graph-target::before,
.graph-target::after,
.graph-node {
  transition:
    background-color 0.2s ease,
    border-color 0.2s ease,
    color 0.2s ease;
}

.graph-target.on-path::after {
  background: var(--lit);
}

/* The lit row: the bus is lit down to its branch, and plain below it. */
.graph-target.lit:not(:first-child)::after {
  background: linear-gradient(var(--lit) 0 50%, var(--line) 50% 100%);
}

.graph-target.lit:last-child:not(:first-child)::after {
  background: var(--lit);
}

.graph-target.lit .graph-node {
  border-color: var(--lit);
  background: color-mix(in srgb, var(--lit) 14%, var(--vscode-editor-background));
  color: var(--lit);
}

.graph-target.pending .graph-node {
  color: var(--ink-blue);
}

.graph-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.graph-target.lit .graph-name {
  font-weight: 600;
}

.graph-target.more .graph-name {
  color: var(--ink-muted);
}

.graph-target.more::before {
  background: repeating-linear-gradient(90deg, var(--line) 0 2px, transparent 2px 5px);
}

.graph-tag {
  flex-shrink: 0;
  padding: 1px 8px;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--lit) 16%, transparent);
  color: var(--lit);
  font-size: var(--ink-font-xs);
  font-weight: 600;
}
`;var ri=L(mt()),ca=L(te());function Op({value:e,onChange:t,onComplete:n,length:o=6,disabled:a}){let c=(0,ri.useRef)([]),l=Array.from({length:o},(u,m)=>e[m]??""),i=u=>c.current[Math.max(0,Math.min(o-1,u))]?.focus(),r=(u,m)=>{let p=m.replace(/\D/g,"");if(!p)return;let d=(e.slice(0,u)+p).slice(0,o);t(d),i(d.length),d.length===o&&n?.(d)};return(0,ca.jsx)("div",{className:"code-input",role:"group","aria-label":"Pairing code",children:l.map((u,m)=>(0,ca.jsxs)(ri.Fragment,{children:[m===o/2&&(0,ca.jsx)("span",{className:"code-sep","aria-hidden":"true"}),(0,ca.jsx)("input",{ref:p=>{c.current[m]=p},className:"code-box",inputMode:"numeric",autoComplete:"one-time-code","aria-label":`Digit ${m+1}`,maxLength:o,disabled:a,value:u,onFocus:p=>p.currentTarget.select(),onChange:p=>r(Math.min(m,e.length),p.target.value),onPaste:p=>{p.preventDefault(),r(0,p.clipboardData.getData("text"))},onKeyDown:p=>{if(p.key==="Backspace"){p.preventDefault();let d=u?m:m-1;d>=0&&t(e.slice(0,d)),i(d)}else p.key==="ArrowLeft"?(p.preventDefault(),i(m-1)):p.key==="ArrowRight"&&(p.preventDefault(),i(m+1))}})]},m))})}var Cp=`/* The full page. Components and tokens come from @inkspect/shared/ui (ui.css, theme.css); the
   link graph from ../ui/link-graph.css. */

* {
  box-sizing: border-box;
}

html,
body {
  margin: 0;
  min-height: 100vh;
  background: var(--vscode-editor-background);
  color: var(--vscode-foreground);
  font-family: var(--vscode-font-family);
  font-size: var(--vscode-font-size);
  line-height: 1.5;
}

.muted {
  color: var(--ink-muted);
}

/* Top bar: brand, sections, state ------------------------------------------------------------ */

.topbar {
  position: sticky;
  top: 0;
  z-index: 10;
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  align-items: center;
  gap: 16px;
  padding: 12px 24px;
  border-bottom: 1px solid var(--ink-border-subtle);
  background: color-mix(in srgb, var(--vscode-editor-background) 78%, transparent);
  backdrop-filter: blur(14px) saturate(1.4);
}

.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: var(--ink-font-lg);
  font-weight: 700;
  letter-spacing: -0.01em;
}

.brand img {
  width: 28px;
  height: 28px;
  border-radius: 8px;
}

/* The sections, as pills. */
.page-nav.segmented {
  height: 36px;
  padding: 3px;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--vscode-foreground) 6%, transparent);
}

.page-nav .segment {
  gap: 7px;
  padding: 0 16px;
  border-radius: var(--ink-radius-pill);
  font-weight: 500;
}

.page-nav .segment.checked {
  background: var(--vscode-editorWidget-background);
  color: var(--vscode-foreground);
  box-shadow: var(--ink-shadow-sm);
}

.status-chip {
  --tone: var(--ink-muted);
  display: inline-flex;
  align-items: center;
  justify-self: end;
  gap: 8px;
  height: 30px;
  padding: 0 12px;
  border: 1px solid color-mix(in srgb, var(--tone) 35%, transparent);
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--tone) 10%, transparent);
  font-size: var(--ink-font-sm);
  font-weight: 600;
}

.status-chip.tone-ok {
  --tone: var(--ink-green);
}

.status-chip.tone-warn {
  --tone: var(--ink-yellow);
}

.status-chip.tone-busy {
  --tone: var(--ink-blue);
}

.status-dot {
  flex-shrink: 0;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--tone);
}

/* Content ------------------------------------------------------------------------------------ */

.main {
  display: flex;
  flex-direction: column;
  gap: 20px;
  width: min(880px, 100% - 48px);
  margin: 0 auto;
  padding: 40px 0 64px;
}

/* The hero: the section's headline, and for VS Code the link, drawn. */
.hero {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1.1fr);
  align-items: center;
  gap: 32px;
  padding: 8px 0 12px;
}

.hero.compact {
  grid-template-columns: 1fr;
  padding-bottom: 0;
}

.hero h1 {
  margin: 0 0 10px;
  font-size: 30px;
  font-weight: 700;
  line-height: 1.15;
  letter-spacing: -0.025em;
}

.hero p {
  max-width: 52ch;
  margin: 0;
  color: var(--ink-muted);
  font-size: 14px;
  line-height: 1.6;
}

/* A canvas with a dot grid: where the link is drawn. */
.canvas {
  display: flex;
  align-items: center;
  min-height: 220px;
  padding: 28px 32px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: 16px;
  background:
    radial-gradient(
        circle at 1px 1px,
        color-mix(in srgb, var(--vscode-foreground) 16%, transparent) 1px,
        transparent 0
      )
      0 0 / 18px 18px,
    var(--vscode-editorWidget-background);
  box-shadow: var(--ink-shadow);
}

.card {
  border: 1px solid var(--ink-border-subtle);
  border-radius: 16px;
  background: var(--vscode-editorWidget-background);
  box-shadow: var(--ink-shadow-sm);
}

.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 16px;
}

.info-card {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 20px;
}

.card-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  margin-bottom: 8px;
  border-radius: 10px;
  background: color-mix(in srgb, var(--ink-blue) 14%, transparent);
  color: var(--ink-blue);
}

.card-icon .codicon {
  font-size: 18px !important;
}

.info-card h2 {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
}

.info-card p {
  margin: 0;
  color: var(--ink-muted);
}

.card-bottom {
  display: flex;
  align-items: center;
  margin-top: auto;
  padding-top: 12px;
}

.card-value {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.card-foot {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  margin: 0;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.card-foot .codicon {
  margin-top: 2px;
}

/* Pairing: one click in VS Code; the code is the fallback. */
.pair-card {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 16px;
  padding: 24px;
}

.pair-lead {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin: 0;
  font-size: var(--ink-font-lg);
}

.pair-lead .codicon {
  margin-top: 3px;
  color: var(--ink-blue);
}

.pair-card kbd {
  padding: 1px 6px;
  border: 1px solid var(--vscode-keybindingLabel-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-keybindingLabel-background, var(--ink-surface-sunken));
  font-family: inherit;
  font-size: 0.92em;
  font-weight: 600;
  white-space: nowrap;
}

.pair-card > .muted {
  margin: 0;
}

.pair-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
}

.code-input {
  display: flex;
  align-items: center;
  gap: 8px;
}

.code-sep {
  width: 10px;
  height: 2px;
  margin: 0 2px;
  border-radius: 1px;
  background: var(--ink-border-strong);
}

.code-box {
  width: 46px;
  height: 56px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: 12px;
  outline: none;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font-family: var(--vscode-editor-font-family);
  font-size: 24px;
  font-weight: 600;
  text-align: center;
  caret-color: var(--ink-blue);
  transition:
    border-color var(--ink-fast) var(--ink-ease),
    box-shadow var(--ink-fast) var(--ink-ease);
}

.code-box:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
}

.code-box:focus {
  border-color: var(--ink-focus);
  box-shadow: 0 0 0 1px var(--ink-focus);
}

.code-box:disabled {
  opacity: 0.6;
}

.pair-button {
  height: 56px;
  padding: 0 26px;
  border-radius: 12px;
  font-weight: 600;
}

.pair-message {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin: 0;
  color: var(--ink-danger);
}

.pair-message .codicon {
  margin-top: 2px;
}

/* Shortcuts ------------------------------------------------------------------------------------- */

/* Group headers pin just below the sticky top bar. */
.shortcuts-card .shortcut-list {
  --shortcut-sticky-top: 61px;
}

.shortcuts-card .group-header {
  background: var(--vscode-editorWidget-background);
}

.shortcuts-card {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 16px 16px 18px;
}

.shortcuts-bar {
  display: flex;
  align-items: center;
  gap: 6px;
}

.shortcuts-bar .text-field {
  flex: 1;
}

/* The browser's own key (opens the toolbar), above the synced list. */
.browser-key {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
}

.browser-key > .codicon {
  color: var(--ink-blue);
}

.browser-key-label {
  flex: 1;
}

@media (max-width: 760px) {
  .topbar {
    grid-template-columns: 1fr auto;
    padding: 10px 16px;
  }

  .page-nav.segmented {
    grid-column: 1 / -1;
    grid-row: 2;
    justify-self: stretch;
  }

  .page-nav .segment {
    flex: 1;
  }

  .main {
    width: calc(100% - 32px);
    padding-top: 24px;
  }

  .hero {
    grid-template-columns: 1fr;
  }

  .pair-row,
  .pair-message {
    padding-left: 0;
    margin-left: 0;
  }
}
`;var S=L(te()),Ey=["vscode","shortcuts","about"],Ap=()=>{let e=location.hash.slice(1);return Ey.includes(e)?e:"vscode"},zy={connected:{label:"Linked",tone:"ok"},connecting:{label:"Connecting",tone:"busy"},unpaired:{label:"Not paired",tone:"warn"},offline:{label:"VS Code not running",tone:"off"}};function Ny(){let[e,t]=(0,lt.useState)({state:"connecting"}),[n,o]=(0,lt.useState)(Ap),[a,c]=(0,lt.useState)(()=>({map:mc({},ii),overrides:{}})),[l,i]=(0,lt.useState)();(0,lt.useEffect)(()=>{let p=()=>{chrome.runtime.sendMessage({type:"status"}).then(w=>w&&t(w))};p();let d=setInterval(p,2e3),s=()=>o(Ap());addEventListener("hashchange",s);let y=Tp((w,z)=>c({map:w,overrides:z.overrides}));return chrome.commands.getAll().then(w=>i(w.find(z=>z.name==="toggle-toolbar")?.shortcut)),()=>{clearInterval(d),removeEventListener("hashchange",s),y()}},[]);let r=p=>{o(p),history.replaceState(null,"",`#${p}`)},u=zy[e.state],m=e.state==="connected"?e.windows?.length??1:0;return(0,S.jsxs)("div",{className:"page",children:[(0,S.jsxs)("header",{className:"topbar",children:[(0,S.jsxs)("div",{className:"brand",children:[(0,S.jsx)("img",{src:"icons/48.png",alt:""}),(0,S.jsx)("span",{children:"Inkspect"})]}),(0,S.jsx)(of,{label:"Sections",className:"page-nav",value:n,onChange:r,options:[{value:"vscode",label:"VS Code",icon:"vscode",count:m||void 0},{value:"shortcuts",label:"Shortcuts",icon:"keyboard"},{value:"about",label:"About",icon:"info"}]}),(0,S.jsxs)("span",{className:`status-chip tone-${u.tone}`,role:"status",children:[(0,S.jsx)("span",{className:"status-dot","aria-hidden":"true"}),u.label]})]}),(0,S.jsxs)("main",{className:"main",children:[n==="vscode"&&(0,S.jsx)(Oy,{status:e,setStatus:t}),n==="shortcuts"&&(0,S.jsx)(Cy,{map:a.map,overrides:a.overrides,linked:e.state==="connected",toolbarKey:l}),n==="about"&&(0,S.jsx)(Ay,{status:e,toolbarKey:l,stateLabel:u.label})]})]})}function Oy({status:e,setStatus:t}){let[n,o]=(0,lt.useState)(""),[a,c]=(0,lt.useState)(""),[l,i]=(0,lt.useState)(!1),[r,u]=(0,lt.useState)(()=>location.hash==="#vscode-code"),m=e.state==="connected",p=e.windows?.length??1,d=async(s=n)=>{if(s.length!==6||l)return;i(!0),c("");let y=await chrome.runtime.sendMessage({type:"pair",code:s}).catch(()=>{});if(i(!1),!y){c("The extension did not answer. Reload it at chrome://extensions and try again.");return}t(y),c(y.error??""),y.state==="connected"&&o("")};return(0,S.jsxs)(S.Fragment,{children:[(0,S.jsxs)("section",{className:"hero",children:[(0,S.jsxs)("div",{className:"hero-text",children:[(0,S.jsx)("h1",{children:m?`Linked with ${p} VS Code window${p===1?"":"s"}`:e.state==="unpaired"?"Pair with VS Code":e.state==="connecting"?"Looking for VS Code":"Waiting for VS Code"}),(0,S.jsx)("p",{children:m?"Screenshots and elements you send from the toolbar go to the window you used last, unless you pick another after a capture. Bookmarks sync both ways.":e.state==="unpaired"?"VS Code is running. Pair once to send captures to it and keep bookmarks in sync.":"Start VS Code with the VS Code Browser extension. This page finds it by itself."})]}),(0,S.jsx)("div",{className:"canvas","aria-label":"The link",children:(0,S.jsx)(zp,{status:e})})]}),m?(0,S.jsxs)("div",{className:"cards",children:[(0,S.jsx)(la,{icon:"debug-disconnect",title:"This browser",text:"Unlinking stops sends and bookmark sync until you pair again.",children:(0,S.jsx)(yi,{variant:"danger",icon:"debug-disconnect",confirmLabel:"Click again to unlink",onConfirm:()=>{chrome.runtime.sendMessage({type:"unpair"}).then(s=>s&&t(s))},children:"Unlink"})}),(0,S.jsx)(la,{icon:"lock",title:"Private by design",text:"The link only talks to VS Code on this computer (127.0.0.1), and only after pairing."})]}):e.state!=="unpaired"?(0,S.jsxs)("div",{className:"card pair-card",children:[(0,S.jsxs)("p",{className:"pair-lead",children:[(0,S.jsx)("span",{className:"codicon codicon-loading codicon-modifier-spin","aria-hidden":"true"}),"Open VS Code with the VS Code Browser extension. Then click"," ",(0,S.jsx)("b",{children:"Pair Browser Extension"})," in its ",(0,S.jsx)("b",{children:"Browser"})," side panel."]}),(0,S.jsxs)("p",{className:"card-foot",children:[(0,S.jsx)("span",{className:"codicon codicon-lock","aria-hidden":"true"}),"The link only talks to VS Code on this computer (127.0.0.1), and only after pairing."]})]}):(0,S.jsxs)("form",{className:"card pair-card",onSubmit:s=>{s.preventDefault(),d()},children:[(0,S.jsxs)("p",{className:"pair-lead",children:[(0,S.jsx)("span",{className:"codicon codicon-plug","aria-hidden":"true"}),(0,S.jsxs)("span",{children:["In VS Code, click ",(0,S.jsx)("b",{children:"Pair Browser Extension"})," in the ",(0,S.jsx)("b",{children:"Browser"})," side panel (or"," ",(0,S.jsx)("b",{children:"Pair"})," on its notification). No code needed: this page updates by itself."]})]}),r?(0,S.jsxs)(S.Fragment,{children:[(0,S.jsxs)("p",{className:"muted",children:["Run ",(0,S.jsx)("kbd",{children:"Browser: Pair Browser Extension with a Code"})," in VS Code, then type the code it shows."]}),(0,S.jsxs)("div",{className:"pair-row",children:[(0,S.jsx)(Op,{value:n,onChange:o,disabled:l,onComplete:s=>{d(s)}}),(0,S.jsx)(ua,{type:"submit",variant:"primary",icon:"link",className:"pair-button",loading:l,disabled:n.length!==6,children:"Pair"})]})]}):(0,S.jsx)(ua,{size:"sm",variant:"ghost",icon:"key",className:"use-code",onClick:()=>u(!0),children:"Use a code instead"}),a&&(0,S.jsxs)("p",{className:"pair-message",role:"alert",children:[(0,S.jsx)("span",{className:"codicon codicon-error","aria-hidden":"true"}),a]}),(0,S.jsxs)("p",{className:"card-foot",children:[(0,S.jsx)("span",{className:"codicon codicon-lock","aria-hidden":"true"}),"The link only talks to VS Code on this computer (127.0.0.1), and only after pairing."]})]})]})}function Cy({map:e,overrides:t,linked:n,toolbarKey:o}){let[a,c]=(0,lt.useState)(""),l=a.trim().toLowerCase(),i=!l||l.split(/\s+/).every(r=>"open the toolbar browser".includes(r))||!!o&&(o.toLowerCase().includes(l)||gc(o,l));return(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)("section",{className:"hero compact",children:(0,S.jsxs)("div",{className:"hero-text",children:[(0,S.jsx)("h1",{children:"Shortcuts"}),(0,S.jsxs)("p",{children:["Every shortcut of the toolbar and VS Code Browser, one key map:"," ",n?"a change here applies in VS Code too, and the other way round.":"they sync with VS Code once it is linked, and follow your browser account."," ","Click a key, then press the new one."]})]})}),(0,S.jsxs)("div",{className:"card shortcuts-card",children:[(0,S.jsxs)("div",{className:"shortcuts-bar",children:[(0,S.jsx)(uf,{value:a,onChange:c}),(0,S.jsx)(yi,{icon:"discard",confirmLabel:"Click again to reset",title:"Reset all shortcuts (here and in VS Code)",disabled:!Object.keys(t).length,onConfirm:()=>{Ep()},children:"Reset all"})]}),i&&(0,S.jsxs)("div",{className:"browser-key",children:[(0,S.jsx)("span",{className:"codicon codicon-inspect","aria-hidden":"true"}),(0,S.jsx)("span",{className:"browser-key-label",children:"Open the toolbar"}),(0,S.jsx)("span",{className:"shortcut-tag br",title:"Works in your browser. Set by the browser itself, so it does not sync with VS Code",children:"BR"}),o?(0,S.jsx)(da,{binding:o.toLowerCase(),size:"sm"}):(0,S.jsx)("span",{className:"muted",children:"No key"}),!1]}),(0,S.jsx)(cf,{actions:Wt,scopes:xp,map:e,overrides:t,query:a,labelOf:yp,scopeLabel:Sp,onSetKeys:(r,u)=>{yd(t,r,u)},onReset:r=>{yd(t,r,void 0)}}),(0,S.jsxs)("p",{className:"card-foot",children:[(0,S.jsx)("span",{className:"codicon codicon-info","aria-hidden":"true"}),"VS: works in VS Code Browser. BR: works in this browser's toolbar. It is one key map: changing a key here changes it in VS Code too."]})]})]})}function Ay({status:e,toolbarKey:t,stateLabel:n}){let o=e.state==="connected";return(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)("section",{className:"hero compact",children:(0,S.jsxs)("div",{className:"hero-text",children:[(0,S.jsx)("h1",{children:"About"}),(0,S.jsxs)("p",{children:["Inkspect ",chrome.runtime.getManifest().version,": a toolbar for working with AI agents on any page, linked with VS Code."]})]})}),(0,S.jsxs)("div",{className:"cards",children:[(0,S.jsx)(la,{icon:"keyboard",title:"Open the toolbar",text:"On any page. The toolbar button opens the popup, which can open it too.",children:(0,S.jsxs)("span",{className:"card-value",children:[t?(0,S.jsx)(da,{binding:t.toLowerCase(),size:"sm"}):(0,S.jsx)("span",{className:"muted",children:"No key"}),!1]})}),(0,S.jsx)(la,{icon:"vscode",title:"VS Code",text:o?`Linked with ${e.peer??"VS Code"}.`:"Not linked yet.",children:(0,S.jsx)("span",{className:"card-value muted",children:n})}),(0,S.jsx)(la,{icon:"bookmark",title:"Bookmarks",text:"Synced with VS Code both ways, live, while it is linked.",children:(0,S.jsx)("span",{className:"card-value muted",children:o?"Syncing":"Paused"})}),(0,S.jsx)(la,{icon:"shield",title:"Access",text:"Only the tab you open the toolbar on, while it is open. Nothing leaves this computer except to VS Code on 127.0.0.1."})]})]})}function la({icon:e,title:t,text:n,children:o}){return(0,S.jsxs)("section",{className:"card info-card",children:[(0,S.jsx)("span",{className:"card-icon","aria-hidden":"true",children:(0,S.jsx)("span",{className:`codicon codicon-${e}`})}),(0,S.jsx)("h2",{children:t}),(0,S.jsx)("p",{children:n}),o&&(0,S.jsx)("div",{className:"card-bottom",children:o})]})}chrome.runtime.onMessage.addListener(e=>{e?.type==="shortcutPressed"&&typeof e.key=="string"&&rf(e.key)});var Mp=document.createElement("style");Mp.textContent=[xd,kd,wd,Np,Cp].join(`
`);document.head.append(Mp);document.documentElement.classList.add("ink-theme");(0,_p.createRoot)(document.getElementById("root")).render((0,S.jsx)(Ny,{}));})();
