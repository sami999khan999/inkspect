"use strict";(()=>{var Qx=Object.create;var mm=Object.defineProperty;var Zx=Object.getOwnPropertyDescriptor;var Px=Object.getOwnPropertyNames;var $x=Object.getPrototypeOf,Jx=Object.prototype.hasOwnProperty;var En=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports}catch(n){throw t=0,n}};var Ix=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of Px(t))!Jx.call(e,a)&&a!==n&&mm(e,a,{get:()=>t[a],enumerable:!(o=Zx(t,a))||o.enumerable});return e};var _=(e,t,n)=>(n=e!=null?Qx($x(e)):{},Ix(t||!e||!e.__esModule?mm(n,"default",{value:e,enumerable:!0}):n,e));var Cm=En(Ae=>{"use strict";function ou(e,t){var n=e.length;e.push(t);e:for(;0<n;){var o=n-1>>>1,a=e[o];if(0<Al(a,t))e[o]=t,e[n]=a,n=o;else break e}}function Tn(e){return e.length===0?null:e[0]}function Ol(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;e:for(var o=0,a=e.length,i=a>>>1;o<i;){var r=2*(o+1)-1,l=e[r],c=r+1,s=e[c];if(0>Al(l,n))c<a&&0>Al(s,l)?(e[o]=s,e[c]=n,o=c):(e[o]=l,e[r]=n,o=r);else if(c<a&&0>Al(s,n))e[o]=s,e[c]=n,o=c;else break e}}return t}function Al(e,t){var n=e.sortIndex-t.sortIndex;return n!==0?n:e.id-t.id}Ae.unstable_now=void 0;typeof performance=="object"&&typeof performance.now=="function"?(hm=performance,Ae.unstable_now=function(){return hm.now()}):(eu=Date,vm=eu.now(),Ae.unstable_now=function(){return eu.now()-vm});var hm,eu,vm,Pn=[],bo=[],ew=1,en=null,gt=3,au=!1,ar=!1,ir=!1,iu=!1,wm=typeof setTimeout=="function"?setTimeout:null,km=typeof clearTimeout=="function"?clearTimeout:null,ym=typeof setImmediate<"u"?setImmediate:null;function zl(e){for(var t=Tn(bo);t!==null;){if(t.callback===null)Ol(bo);else if(t.startTime<=e)Ol(bo),t.sortIndex=t.expirationTime,ou(Pn,t);else break;t=Tn(bo)}}function ru(e){if(ir=!1,zl(e),!ar)if(Tn(Pn)!==null)ar=!0,Xa||(Xa=!0,Ka());else{var t=Tn(bo);t!==null&&lu(ru,t.startTime-e)}}var Xa=!1,rr=-1,Sm=5,Em=-1;function Tm(){return iu?!0:!(Ae.unstable_now()-Em<Sm)}function tu(){if(iu=!1,Xa){var e=Ae.unstable_now();Em=e;var t=!0;try{e:{ar=!1,ir&&(ir=!1,km(rr),rr=-1),au=!0;var n=gt;try{t:{for(zl(e),en=Tn(Pn);en!==null&&!(en.expirationTime>e&&Tm());){var o=en.callback;if(typeof o=="function"){en.callback=null,gt=en.priorityLevel;var a=o(en.expirationTime<=e);if(e=Ae.unstable_now(),typeof a=="function"){en.callback=a,zl(e),t=!0;break t}en===Tn(Pn)&&Ol(Pn),zl(e)}else Ol(Pn);en=Tn(Pn)}if(en!==null)t=!0;else{var i=Tn(bo);i!==null&&lu(ru,i.startTime-e),t=!1}}break e}finally{en=null,gt=n,au=!1}t=void 0}}finally{t?Ka():Xa=!1}}}var Ka;typeof ym=="function"?Ka=function(){ym(tu)}:typeof MessageChannel<"u"?(nu=new MessageChannel,xm=nu.port2,nu.port1.onmessage=tu,Ka=function(){xm.postMessage(null)}):Ka=function(){wm(tu,0)};var nu,xm;function lu(e,t){rr=wm(function(){e(Ae.unstable_now())},t)}Ae.unstable_IdlePriority=5;Ae.unstable_ImmediatePriority=1;Ae.unstable_LowPriority=4;Ae.unstable_NormalPriority=3;Ae.unstable_Profiling=null;Ae.unstable_UserBlockingPriority=2;Ae.unstable_cancelCallback=function(e){e.callback=null};Ae.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):Sm=0<e?Math.floor(1e3/e):5};Ae.unstable_getCurrentPriorityLevel=function(){return gt};Ae.unstable_next=function(e){switch(gt){case 1:case 2:case 3:var t=3;break;default:t=gt}var n=gt;gt=t;try{return e()}finally{gt=n}};Ae.unstable_requestPaint=function(){iu=!0};Ae.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=gt;gt=e;try{return t()}finally{gt=n}};Ae.unstable_scheduleCallback=function(e,t,n){var o=Ae.unstable_now();switch(typeof n=="object"&&n!==null?(n=n.delay,n=typeof n=="number"&&0<n?o+n:o):n=o,e){case 1:var a=-1;break;case 2:a=250;break;case 5:a=1073741823;break;case 4:a=1e4;break;default:a=5e3}return a=n+a,e={id:ew++,callback:t,priorityLevel:e,startTime:n,expirationTime:a,sortIndex:-1},n>o?(e.sortIndex=n,ou(bo,e),Tn(Pn)===null&&e===Tn(bo)&&(ir?(km(rr),rr=-1):ir=!0,lu(ru,n-o))):(e.sortIndex=a,ou(Pn,e),ar||au||(ar=!0,Xa||(Xa=!0,Ka()))),e};Ae.unstable_shouldYield=Tm;Ae.unstable_wrapCallback=function(e){var t=gt;return function(){var n=gt;gt=t;try{return e.apply(this,arguments)}finally{gt=n}}}});var Mm=En((cT,Nm)=>{"use strict";Nm.exports=Cm()});var Ym=En(X=>{"use strict";var uu=Symbol.for("react.transitional.element"),tw=Symbol.for("react.portal"),nw=Symbol.for("react.fragment"),ow=Symbol.for("react.strict_mode"),aw=Symbol.for("react.profiler"),iw=Symbol.for("react.consumer"),rw=Symbol.for("react.context"),lw=Symbol.for("react.forward_ref"),cw=Symbol.for("react.suspense"),sw=Symbol.for("react.memo"),Dm=Symbol.for("react.lazy"),uw=Symbol.for("react.activity"),dw=Symbol.for("react.view_transition"),Am=Symbol.iterator;function fw(e){return e===null||typeof e!="object"?null:(e=Am&&e[Am]||e["@@iterator"],typeof e=="function"?e:null)}var _m={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},Hm=Object.assign,Bm={};function Qa(e,t,n){this.props=e,this.context=t,this.refs=Bm,this.updater=n||_m}Qa.prototype.isReactComponent={};Qa.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};Qa.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function Lm(){}Lm.prototype=Qa.prototype;function du(e,t,n){this.props=e,this.context=t,this.refs=Bm,this.updater=n||_m}var fu=du.prototype=new Lm;fu.constructor=du;Hm(fu,Qa.prototype);fu.isPureReactComponent=!0;var zm=Array.isArray;function su(){}var xe={H:null,A:null,T:null,S:null},Um=Object.prototype.hasOwnProperty;function pu(e,t,n){var o=n.ref;return{$$typeof:uu,type:e,key:t,ref:o!==void 0?o:null,props:n}}function pw(e,t){return pu(e.type,t,e.props)}function mu(e){return typeof e=="object"&&e!==null&&e.$$typeof===uu}function mw(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var Om=/\/+/g;function cu(e,t){return typeof e=="object"&&e!==null&&e.key!=null?mw(""+e.key):t.toString(36)}function gw(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(su,su):(e.status="pending",e.then(function(t){e.status==="pending"&&(e.status="fulfilled",e.value=t)},function(t){e.status==="pending"&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function Ga(e,t,n,o,a){var i=typeof e;(i==="undefined"||i==="boolean")&&(e=null);var r=!1;if(e===null)r=!0;else switch(i){case"bigint":case"string":case"number":r=!0;break;case"object":switch(e.$$typeof){case uu:case tw:r=!0;break;case Dm:return r=e._init,Ga(r(e._payload),t,n,o,a)}}if(r)return a=a(e),r=o===""?"."+cu(e,0):o,zm(a)?(n="",r!=null&&(n=r.replace(Om,"$&/")+"/"),Ga(a,t,n,"",function(s){return s})):a!=null&&(mu(a)&&(a=pw(a,n+(a.key==null||e&&e.key===a.key?"":(""+a.key).replace(Om,"$&/")+"/")+r)),t.push(a)),1;r=0;var l=o===""?".":o+":";if(zm(e))for(var c=0;c<e.length;c++)o=e[c],i=l+cu(o,c),r+=Ga(o,t,n,i,a);else if(c=fw(e),typeof c=="function")for(e=c.call(e),c=0;!(o=e.next()).done;)o=o.value,i=l+cu(o,c++),r+=Ga(o,t,n,i,a);else if(i==="object"){if(typeof e.then=="function")return Ga(gw(e),t,n,o,a);throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return r}function Rl(e,t,n){if(e==null)return e;var o=[],a=0;return Ga(e,o,"","",function(i){return t.call(n,i,a++)}),o}function bw(e){if(e._status===-1){var t=e._result,n=t();n.then(function(o){(e._status===0||e._status===-1)&&(e._status=1,e._result=o,n.status===void 0&&(n.status="fulfilled",n.value=o))},function(o){(e._status===0||e._status===-1)&&(e._status=2,e._result=o,n.status===void 0&&(n.status="rejected",n.reason=o))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var Rm=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)};function jm(e){var t=xe.T,n={};n.types=t!==null?t.types:null,xe.T=n;try{var o=e(),a=xe.S;a!==null&&a(n,o),typeof o=="object"&&o!==null&&typeof o.then=="function"&&o.then(su,Rm)}catch(i){Rm(i)}finally{t!==null&&n.types!==null&&(t.types=n.types),xe.T=t}}function qm(e){var t=xe.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else jm(qm.bind(null,e))}var hw={map:Rl,forEach:function(e,t,n){Rl(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return Rl(e,function(){t++}),t},toArray:function(e){return Rl(e,function(t){return t})||[]},only:function(e){if(!mu(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};X.Activity=uw;X.Children=hw;X.Component=Qa;X.Fragment=nw;X.Profiler=aw;X.PureComponent=du;X.StrictMode=ow;X.Suspense=cw;X.ViewTransition=dw;X.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=xe;X.__COMPILER_RUNTIME={__proto__:null,c:function(e){return xe.H.useMemoCache(e)}};X.addTransitionType=qm;X.cache=function(e){return function(){return e.apply(null,arguments)}};X.cacheSignal=function(){return null};X.cloneElement=function(e,t,n){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var o=Hm({},e.props),a=e.key;if(t!=null)for(i in t.key!==void 0&&(a=""+t.key),t)!Um.call(t,i)||i==="key"||i==="__self"||i==="__source"||i==="ref"&&t.ref===void 0||(o[i]=t[i]);var i=arguments.length-2;if(i===1)o.children=n;else if(1<i){for(var r=Array(i),l=0;l<i;l++)r[l]=arguments[l+2];o.children=r}return pu(e.type,a,o)};X.createContext=function(e){return e={$$typeof:rw,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:iw,_context:e},e};X.createElement=function(e,t,n){var o,a={},i=null;if(t!=null)for(o in t.key!==void 0&&(i=""+t.key),t)Um.call(t,o)&&o!=="key"&&o!=="__self"&&o!=="__source"&&(a[o]=t[o]);var r=arguments.length-2;if(r===1)a.children=n;else if(1<r){for(var l=Array(r),c=0;c<r;c++)l[c]=arguments[c+2];a.children=l}if(e&&e.defaultProps)for(o in r=e.defaultProps,r)a[o]===void 0&&(a[o]=r[o]);return pu(e,i,a)};X.createRef=function(){return{current:null}};X.forwardRef=function(e){return{$$typeof:lw,render:e}};X.isValidElement=mu;X.lazy=function(e){return{$$typeof:Dm,_payload:{_status:-1,_result:e},_init:bw}};X.memo=function(e,t){return{$$typeof:sw,type:e,compare:t===void 0?null:t}};X.startTransition=jm;X.unstable_useCacheRefresh=function(){return xe.H.useCacheRefresh()};X.use=function(e){return xe.H.use(e)};X.useActionState=function(e,t,n){return xe.H.useActionState(e,t,n)};X.useCallback=function(e,t){return xe.H.useCallback(e,t)};X.useContext=function(e){return xe.H.useContext(e)};X.useDebugValue=function(){};X.useDeferredValue=function(e,t){return xe.H.useDeferredValue(e,t)};X.useEffect=function(e,t){return xe.H.useEffect(e,t)};X.useEffectEvent=function(e){return xe.H.useEffectEvent(e)};X.useId=function(){return xe.H.useId()};X.useImperativeHandle=function(e,t,n){return xe.H.useImperativeHandle(e,t,n)};X.useInsertionEffect=function(e,t){return xe.H.useInsertionEffect(e,t)};X.useLayoutEffect=function(e,t){return xe.H.useLayoutEffect(e,t)};X.useMemo=function(e,t){return xe.H.useMemo(e,t)};X.useOptimistic=function(e,t){return xe.H.useOptimistic(e,t)};X.useReducer=function(e,t,n){return xe.H.useReducer(e,t,n)};X.useRef=function(e){return xe.H.useRef(e)};X.useState=function(e){return xe.H.useState(e)};X.useSyncExternalStore=function(e,t,n){return xe.H.useSyncExternalStore(e,t,n)};X.useTransition=function(){return xe.H.useTransition()};X.version="19.3.0"});var _e=En((uT,Vm)=>{"use strict";Vm.exports=Ym()});var Gm=En(bt=>{"use strict";var vw=_e();function Xm(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function ho(){}var kt={d:{f:ho,r:function(){throw Error(Xm(522))},D:ho,C:ho,L:ho,m:ho,X:ho,S:ho,M:ho},p:0,findDOMNode:null},yw=Symbol.for("react.portal"),xw=Symbol.for("react.recoverable"),Km=Symbol.for("react.optimistic_key");function ww(e,t,n){var o=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:yw,key:o==null?null:o===Km?Km:""+o,children:e,containerInfo:t,implementation:n}}var lr=vw.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function Dl(e,t){if(e==="font")return"";if(typeof t=="string")return t==="use-credentials"?t:""}bt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=kt;bt.browser=function(e){return{$$typeof:xw,_reason:e}};bt.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(Xm(299));return ww(e,t,null,n)};bt.flushSync=function(e){var t=lr.T,n=kt.p;try{if(lr.T=null,kt.p=2,e)return e()}finally{lr.T=t,kt.p=n,kt.d.f()}};bt.preconnect=function(e,t){typeof e=="string"&&(t?(t=t.crossOrigin,t=typeof t=="string"?t==="use-credentials"?t:"":void 0):t=null,kt.d.C(e,t))};bt.prefetchDNS=function(e){typeof e=="string"&&kt.d.D(e)};bt.preinit=function(e,t){if(typeof e=="string"&&t&&typeof t.as=="string"){var n=t.as,o=Dl(n,t.crossOrigin),a=typeof t.integrity=="string"?t.integrity:void 0,i=typeof t.fetchPriority=="string"?t.fetchPriority:void 0;n==="style"?kt.d.S(e,typeof t.precedence=="string"?t.precedence:void 0,{crossOrigin:o,integrity:a,fetchPriority:i}):n==="script"&&kt.d.X(e,{crossOrigin:o,integrity:a,fetchPriority:i,nonce:typeof t.nonce=="string"?t.nonce:void 0})}};bt.preinitModule=function(e,t){if(typeof e=="string")if(typeof t=="object"&&t!==null){if(t.as==null||t.as==="script"){var n=Dl(t.as,t.crossOrigin);kt.d.M(e,{crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}}else t==null&&kt.d.M(e)};bt.preload=function(e,t){if(typeof e=="string"&&typeof t=="object"&&t!==null&&typeof t.as=="string"){var n=t.as,o=Dl(n,t.crossOrigin);kt.d.L(e,n,{crossOrigin:o,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,type:typeof t.type=="string"?t.type:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy=="string"?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet=="string"?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes=="string"?t.imageSizes:void 0,media:typeof t.media=="string"?t.media:void 0})}};bt.preloadModule=function(e,t){if(typeof e=="string")if(t){var n=Dl(t.as,t.crossOrigin);kt.d.m(e,{as:typeof t.as=="string"&&t.as!=="script"?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}else kt.d.m(e)};bt.requestFormReset=function(e){kt.d.r(e)};bt.unstable_batchedUpdates=function(e,t){return e(t)};bt.useFormState=function(e,t,n){return lr.H.useFormState(e,t,n)};bt.useFormStatus=function(){return lr.H.useHostTransitionStatus()};bt.version="19.3.0"});var _l=En((fT,Zm)=>{"use strict";function Qm(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Qm)}catch(e){console.error(e)}}Qm(),Zm.exports=Gm()});var D0=En(gs=>{"use strict";var $e=Mm(),Rb=_e(),kw=_l();function N(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function Db(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Pr(e){for(var t=e,n=t;n&&!n.alternate;)t=n,(t.flags&4098)!==0&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function _b(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Hb(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Pm(e){if(Pr(e)!==e)throw Error(N(188))}function Sw(e){var t=e.alternate;if(!t){if(t=Pr(e),t===null)throw Error(N(188));return t!==e?null:e}for(var n=e,o=t;;){var a=n.return;if(a===null)break;var i=a.alternate;if(i===null){if(o=a.return,o!==null){n=o;continue}break}if(a.child===i.child){for(i=a.child;i;){if(i===n)return Pm(a),e;if(i===o)return Pm(a),t;i=i.sibling}throw Error(N(188))}if(n.return!==o.return)n=a,o=i;else{for(var r=!1,l=a.child;l;){if(l===n){r=!0,n=a,o=i;break}if(l===o){r=!0,o=a,n=i;break}l=l.sibling}if(!r){for(l=i.child;l;){if(l===n){r=!0,n=i,o=a;break}if(l===o){r=!0,o=i,n=a;break}l=l.sibling}if(!r)throw Error(N(189))}}if(n.alternate!==o)throw Error(N(190))}if(n.tag!==3)throw Error(N(188));return n.stateNode.current===n?e:t}function Bb(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=Bb(e),t!==null)return t;e=e.sibling}return null}function Dt(e,t,n,o,a,i){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,o,a,i)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&Dt(e.child,t,n,o,a,i))return!0;e=e.sibling}return!1}function Sa(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function $m(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),!(e.tag===3||e.tag===5||e.tag===27));)e=e.return;return t}function Lb(e){var t=[null,null],n=Sa(e);return n===null||Ub(t,e,n.child,{foundSelf:!1}),t}function Ub(e,t,n,o){for(;n!==null;){if(n===t)o.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(o.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&Ub(e,t,n.child,o))return!0;n=n.sibling}return!1}function Pe(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(N(559))}}var Wa=null,Qu=null;function Ew(e,t,n){return e===n?!0:e===t?(Wa=e,!0):!1}function Tw(e,t,n){return e===n?(Qu=e,!1):e===t?(Qu!==null&&(Wa=e),!0):!1}function Jm(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function Zu(e,t,n){for(var o=0,a=e;a;a=n(a))o++;a=0;for(var i=t;i;i=n(i))a++;for(;0<o-a;)e=n(e),o--;for(;0<a-o;)t=n(t),a--;for(;o--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var ve=Object.assign,Cw=Symbol.for("react.element"),Hl=Symbol.for("react.transitional.element"),mr=Symbol.for("react.portal"),ei=Symbol.for("react.fragment"),jb=Symbol.for("react.strict_mode"),Pu=Symbol.for("react.profiler"),qb=Symbol.for("react.consumer"),On=Symbol.for("react.context"),of=Symbol.for("react.forward_ref"),$u=Symbol.for("react.suspense"),Ju=Symbol.for("react.suspense_list"),af=Symbol.for("react.memo"),wo=Symbol.for("react.lazy"),Iu=Symbol.for("react.activity"),Nw=Symbol.for("react.legacy_hidden"),Mw=Symbol.for("react.memo_cache_sentinel"),Fu=Symbol.for("react.view_transition"),Aw=Symbol.for("react.recoverable"),Im=Symbol.iterator;function cr(e){return e===null||typeof e!="object"?null:(e=Im&&e[Im]||e["@@iterator"],typeof e=="function"?e:null)}var zw=Symbol.for("react.client.reference");function Wu(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===zw?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case ei:return"Fragment";case Pu:return"Profiler";case jb:return"StrictMode";case $u:return"Suspense";case Ju:return"SuspenseList";case Iu:return"Activity";case Fu:return"ViewTransition"}if(typeof e=="object")switch(e.$$typeof){case mr:return"Portal";case On:return e.displayName||"Context";case qb:return(e._context.displayName||"Context")+".Consumer";case of:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case af:return t=e.displayName||null,t!==null?t:Wu(e.type)||"Memo";case wo:t=e._payload,e=e._init;try{return Wu(e(t))}catch{}}return null}var gr=Array.isArray,V=Rb.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,se=kw.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ua={pending:!1,data:null,method:null,action:null},ed=[],ti=-1;function Un(e){return{current:e}}function lt(e){0>ti||(e.current=ed[ti],ed[ti]=null,ti--)}function Se(e,t){ti++,ed[ti]=e.current,e.current=t}var Hn=Un(null),Rr=Un(null),zo=Un(null),wc=Un(null);function kc(e,t){switch(Se(zo,t),Se(Rr,e),Se(Hn,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?db(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=db(t),e=c0(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}lt(Hn),Se(Hn,e)}function wi(){lt(Hn),lt(Rr),lt(zo)}function td(e){var t=e.memoizedState;t!==null&&(Oi._currentValue=t.memoizedState,Se(wc,e)),t=Hn.current;var n=c0(t,e.type);t!==n&&(Se(Rr,e),Se(Hn,n))}function Sc(e){Rr.current===e&&(lt(Hn),lt(Rr)),wc.current===e&&(lt(wc),Oi._currentValue=ua)}var gu,Fm;function yo(e){if(gu===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);gu=t&&t[1]||"",Fm=-1<n.stack.indexOf(`
    at`)?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return`
`+gu+e+Fm}var bu=!1;function hu(e,t){if(!e||bu)return"";bu=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(t){var m=function(){throw Error()};if(Object.defineProperty(m.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(m,[])}catch(x){var u=x}Reflect.construct(e,[],m)}else{try{m.call()}catch(x){u=x}m=!1;try{var d=Object.getOwnPropertyDescriptor(e.prototype,"props");Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),m=!0,new e}finally{m&&(d!==void 0?Object.defineProperty(e.prototype,"props",d):delete e.prototype.props)}}}else{try{throw Error()}catch(x){u=x}(m=e())&&typeof m.catch=="function"&&m.catch(function(){})}}catch(x){if(x&&u&&typeof x.stack=="string")return[x.stack,u.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var a=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");a&&a.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var i=o.DetermineComponentFrameRoot(),r=i[0],l=i[1];if(r&&l){var c=r.split(`
`),s=l.split(`
`);for(a=o=0;o<c.length&&!c[o].includes("DetermineComponentFrameRoot");)o++;for(;a<s.length&&!s[a].includes("DetermineComponentFrameRoot");)a++;if(o===c.length||a===s.length)for(o=c.length-1,a=s.length-1;1<=o&&0<=a&&c[o]!==s[a];)a--;for(;1<=o&&0<=a;o--,a--)if(c[o]!==s[a]){if(o!==1||a!==1)do if(o--,a--,0>a||c[o]!==s[a]){var f=`
`+c[o].replace(" at new "," at ");return e.displayName&&f.includes("<anonymous>")&&(f=f.replace("<anonymous>",e.displayName)),f}while(1<=o&&0<=a);break}}}finally{bu=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?yo(n):""}function Ow(e,t){switch(e.tag){case 26:case 27:case 5:return yo(e.type);case 16:return yo("Lazy");case 13:return e.child!==t&&t!==null?yo("Suspense Fallback"):yo("Suspense");case 19:return yo("SuspenseList");case 0:case 15:return hu(e.type,!1);case 11:return hu(e.type.render,!1);case 1:return hu(e.type,!0);case 31:return yo("Activity");case 30:return yo("ViewTransition");default:return""}}function Wm(e){try{var t="",n=null;do t+=Ow(e,n),n=e,e=e.return;while(e);return t}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var nd=Object.prototype.hasOwnProperty,rf=$e.unstable_scheduleCallback,vu=$e.unstable_cancelCallback,Rw=$e.unstable_shouldYield,Dw=$e.unstable_requestPaint,Gt=$e.unstable_now,_w=$e.unstable_getCurrentPriorityLevel,Yb=$e.unstable_ImmediatePriority,Vb=$e.unstable_UserBlockingPriority,Ec=$e.unstable_NormalPriority,Hw=$e.unstable_LowPriority,Kb=$e.unstable_IdlePriority,Bw=$e.log,Lw=$e.unstable_setDisableYieldValue,$r=null,Qt=null;function Eo(e){if(typeof Bw=="function"&&Lw(e),Qt&&typeof Qt.setStrictMode=="function")try{Qt.setStrictMode($r,e)}catch{}}var Zt=Math.clz32?Math.clz32:qw,Uw=Math.log,jw=Math.LN2;function qw(e){return e>>>=0,e===0?32:31-(Uw(e)/jw|0)|0}var Bl=256,Ll=262144,Ul=4194304;function ia(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Jc(e,t,n){var o=e.pendingLanes;if(o===0)return 0;var a=0,i=e.suspendedLanes,r=e.pingedLanes;e=e.warmLanes;var l=o&134217727;return l!==0?(o=l&~i,o!==0?a=ia(o):(r&=l,r!==0?a=ia(r):n||(n=l&~e,n!==0&&(a=ia(n))))):(l=o&~i,l!==0?a=ia(l):r!==0?a=ia(r):n||(n=o&~e,n!==0&&(a=ia(n)))),a===0?0:t!==0&&t!==a&&(t&i)===0&&(i=a&-a,n=t&-t,i>=n||i===32&&(n&4194048)!==0)?t:a}function Jr(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Xb(e,t){(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var o=31-Zt(n),a=1<<o;t|=e[o],n&=~a}return t}function Yw(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Gb(){var e=Ul;return Ul<<=1,(Ul&62914560)===0&&(Ul=4194304),e}function yu(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Ir(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Vw(e,t,n,o,a,i){var r=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var l=e.entanglements,c=e.expirationTimes,s=e.hiddenUpdates;for(n=r&~n;0<n;){var f=31-Zt(n),m=1<<f;l[f]=0,c[f]=-1;var u=s[f];if(u!==null)for(s[f]=null,f=0;f<u.length;f++){var d=u[f];d!==null&&(d.lane&=-536870913)}n&=~m}o!==0&&Qb(e,o,0),i!==0&&a===0&&e.tag!==0&&(e.suspendedLanes|=i&~(r&~t))}function Qb(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var o=31-Zt(t);e.entangledLanes|=t,e.entanglements[o]=e.entanglements[o]|1073741824|n&261930}function Zb(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var o=31-Zt(n),a=1<<o;a&t|e[o]&t&&(e[o]|=t),n&=~a}}function Pb(e,t){var n=t&-t;return n=(n&42)!==0?1:lf(n),(n&(e.suspendedLanes|t))!==0?0:n}function lf(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function cf(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function $b(){var e=se.p;return e!==0?e:(e=window.event,e===void 0?32:z0(e.type))}function eg(e,t){var n=se.p;try{return se.p=e,t()}finally{se.p=n}}var lo=Math.random().toString(36).slice(2),it="__reactFiber$"+lo,_t="__reactProps$"+lo,_i="__reactContainer$"+lo,tg="__reactEvents$"+lo,Kw="__reactListeners$"+lo,Xw="__reactHandles$"+lo,ng="__reactResources$"+lo,Fr="__reactMarker$"+lo,Tc="__reactLoad$"+lo;function Ic(e){delete e[it],delete e[_t],delete e[Kw],delete e[Xw]}function ca(e){var t;if(t=e[it])return t;for(var n=e.parentNode;n;){if(t=n[_i]||n[it]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=yb(e);e!==null;){if(n=e[it])return n;e=yb(e)}return t}e=n,n=e.parentNode}return null}function Hi(e){if(e=e[it]||e[_i]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function br(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(N(33))}function di(e){var t=e[ng];return t||(t=e[ng]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function et(e){e[Fr]=!0}function Jb(e){e[Tc]=void 0}var Ib=new Set,Fb={};function Ea(e,t){ki(e,t),ki(e+"Capture",t)}function ki(e,t){for(Fb[e]=t,e=0;e<t.length;e++)Ib.add(t[e])}var Gw=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),og={},ag={};function Qw(e){return nd.call(ag,e)?!0:nd.call(og,e)?!1:Gw.test(e)?ag[e]=!0:(og[e]=!0,!1)}var re=!1;function ig(){var e=re;return re=!1,e}function nc(e,t,n){if(Qw(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var o=t.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,n)}}function jl(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,n)}}function $n(e,t,n,o){if(o===null)e.removeAttribute(n);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,o)}}function Yt(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Wb(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Zw(e,t,n){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var a=o.get,i=o.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return a.call(this)},set:function(r){n=""+r,i.call(this,r)}}),Object.defineProperty(e,t,{enumerable:o.enumerable}),{getValue:function(){return n},setValue:function(r){n=""+r},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function od(e){if(!e._valueTracker){var t=Wb(e)?"checked":"value";e._valueTracker=Zw(e,t,""+e[t])}}function eh(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),o="";return e&&(o=Wb(e)?e.checked?"true":"false":e.value),e=o,e!==n?(t.setValue(e),!0):!1}var Pw=/[\n"\\]/g;function rn(e){return e.replace(Pw,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function ad(e,t,n,o,a,i,r,l){e.name="",r!=null&&typeof r!="function"&&typeof r!="symbol"&&typeof r!="boolean"?e.type=r:e.removeAttribute("type"),t!=null?r==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+Yt(t)):e.value!==""+Yt(t)&&(e.value=""+Yt(t)):r!=="submit"&&r!=="reset"||e.removeAttribute("value"),t!=null?r==="number"&&e.value==t?xu(e,Yt(e.value)):xu(e,Yt(t)):n!=null?xu(e,Yt(n)):o!=null&&e.removeAttribute("value"),a==null&&i!=null&&(e.defaultChecked=!!i),a!=null&&(e.checked=a&&typeof a!="function"&&typeof a!="symbol"),l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"?e.name=""+Yt(l):e.removeAttribute("name")}function th(e,t,n,o,a,i,r,l){if(i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"&&(e.type=i),t!=null||n!=null){if(!(i!=="submit"&&i!=="reset"||t!=null)){od(e);return}n=n!=null?""+Yt(n):"",t=t!=null?""+Yt(t):n,l||t===e.value||(e.value=t),e.defaultValue=t}o=o??a,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=l?e.checked:!!o,e.defaultChecked=!!o,r!=null&&typeof r!="function"&&typeof r!="symbol"&&typeof r!="boolean"&&(e.name=r),od(e)}function xu(e,t){e.defaultValue!==""+t&&(e.defaultValue=""+t)}function fi(e,t,n,o){if(e=e.options,t){t={};for(var a=0;a<n.length;a++)t["$"+n[a]]=!0;for(n=0;n<e.length;n++)a=t.hasOwnProperty("$"+e[n].value),e[n].selected!==a&&(e[n].selected=a),a&&o&&(e[n].defaultSelected=!0)}else{for(n=""+Yt(n),t=null,a=0;a<e.length;a++){if(e[a].value===n){e[a].selected=!0,o&&(e[a].defaultSelected=!0);return}t!==null||e[a].disabled||(t=e[a])}t!==null&&(t.selected=!0)}}function nh(e,t,n){if(t!=null&&(t=""+Yt(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n!=null?""+Yt(n):""}function oh(e,t,n,o){if(t==null){if(o!=null){if(n!=null)throw Error(N(92));if(gr(o)){if(1<o.length)throw Error(N(93));o=o[0]}n=o}n==null&&(n=""),t=n}n=Yt(t),e.defaultValue=n,o=e.textContent,o===n&&o!==""&&o!==null&&(e.value=o),od(e)}function Si(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var $w=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function rg(e,t,n){var o=t.indexOf("--")===0;n==null||typeof n=="boolean"||n===""?o?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":o?e.setProperty(t,n):typeof n!="number"||n===0||$w.has(t)?t==="float"?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function ah(e,t,n){if(t!=null&&typeof t!="object")throw Error(N(62));if(e=e.style,n!=null){for(var o in n)!n.hasOwnProperty(o)||t!=null&&t.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="",re=!0);for(var a in t)o=t[a],t.hasOwnProperty(a)&&n[a]!==o&&(rg(e,a,o),re=!0)}else for(var i in t)t.hasOwnProperty(i)&&rg(e,i,t[i])}function sf(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Jw=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Iw=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function oc(e){return Iw.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function Rn(){}var id=null;function uf(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var ni=null,pi=null;function lg(e){var t=Hi(e);if(t&&(e=t.stateNode)){var n=e[_t]||null;e:switch(e=t.stateNode,t.type){case"input":if(ad(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+rn(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var o=n[t];if(o!==e&&o.form===e.form){var a=o[_t]||null;if(!a)throw Error(N(90));ad(o,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)o=n[t],o.form===e.form&&eh(o)}break e;case"textarea":nh(e,n.value,n.defaultValue);break e;case"select":t=n.value,t!=null&&fi(e,!!n.multiple,t,!1)}}}var wu=!1;function ih(e,t,n){if(wu)return e(t,n);wu=!0;try{var o=e(t);return o}finally{if(wu=!1,(ni!==null||pi!==null)&&(ds(),ni&&(t=ni,e=pi,pi=ni=null,lg(t),e)))for(t=0;t<e.length;t++)lg(e[t])}}function Dr(e,t){var n=e.stateNode;if(n===null)return null;var o=n[_t]||null;if(o===null)return null;n=o[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(N(231,t,typeof n));return n}var to=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),rd=!1;if(to)try{Za={},Object.defineProperty(Za,"passive",{get:function(){rd=!0}}),window.addEventListener("test",Za,Za),window.removeEventListener("test",Za,Za)}catch{rd=!1}var Za,To=null,df=null,ac=null;function rh(){if(ac)return ac;var e,t=df,n=t.length,o,a="value"in To?To.value:To.textContent,i=a.length;for(e=0;e<n&&t[e]===a[e];e++);var r=n-e;for(o=1;o<=r&&t[n-o]===a[i-o];o++);return ac=a.slice(e,1<o?1-o:void 0)}function ic(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function ql(){return!0}function cg(){return!1}function Ct(e){function t(n,o,a,i,r){this._reactName=n,this._targetInst=a,this.type=o,this.nativeEvent=i,this.target=r,this.currentTarget=null;for(var l in e)e.hasOwnProperty(l)&&(n=e[l],this[l]=n?n(i):i[l]);return this.isDefaultPrevented=(i.defaultPrevented!=null?i.defaultPrevented:i.returnValue===!1)?ql:cg,this.isPropagationStopped=cg,this}return ve(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=ql)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=ql)},persist:function(){},isPersistent:ql}),t}var Go={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Fc=Ct(Go),Wr=ve({},Go,{view:0,detail:0}),Fw=Ct(Wr),ku,Su,sr,Wc=ve({},Wr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ff,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==sr&&(sr&&e.type==="mousemove"?(ku=e.screenX-sr.screenX,Su=e.screenY-sr.screenY):Su=ku=0,sr=e),ku)},movementY:function(e){return"movementY"in e?e.movementY:Su}}),sg=Ct(Wc),Ww=ve({},Wc,{dataTransfer:0}),ek=Ct(Ww),tk=ve({},Wr,{relatedTarget:0}),Eu=Ct(tk),nk=ve({},Go,{animationName:0,elapsedTime:0,pseudoElement:0}),ok=Ct(nk),ak=ve({},Go,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),ik=Ct(ak),rk=ve({},Go,{data:0}),ug=Ct(rk),lk={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},ck={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},sk={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function uk(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=sk[e])?!!t[e]:!1}function ff(){return uk}var dk=ve({},Wr,{key:function(e){if(e.key){var t=lk[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=ic(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?ck[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ff,charCode:function(e){return e.type==="keypress"?ic(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?ic(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),fk=Ct(dk),pk=ve({},Wc,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),dg=Ct(pk),mk=ve({},Go,{submitter:0}),gk=Ct(mk),bk=ve({},Wr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ff}),hk=Ct(bk),vk=ve({},Go,{propertyName:0,elapsedTime:0,pseudoElement:0}),yk=Ct(vk),xk=ve({},Wc,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),wk=Ct(xk),kk=ve({},Go,{newState:0,oldState:0,source:0}),Sk=Ct(kk),Ek=[9,13,27,32],pf=to&&"CompositionEvent"in window,yr=null;to&&"documentMode"in document&&(yr=document.documentMode);var Tk=to&&"TextEvent"in window&&!yr,lh=to&&(!pf||yr&&8<yr&&11>=yr),fg=" ",pg=!1;function ch(e,t){switch(e){case"keyup":return Ek.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function sh(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var oi=!1;function Ck(e,t){switch(e){case"compositionend":return sh(t);case"keypress":return t.which!==32?null:(pg=!0,fg);case"textInput":return e=t.data,e===fg&&pg?null:e;default:return null}}function Nk(e,t){if(oi)return e==="compositionend"||!pf&&ch(e,t)?(e=rh(),ac=df=To=null,oi=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return lh&&t.locale!=="ko"?null:t.data;default:return null}}var Mk={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function mg(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Mk[e.type]:t==="textarea"}function uh(e,t,n,o){ni?pi?pi.push(o):pi=[o]:ni=o,t=Zc(t,"onChange"),0<t.length&&(n=new Fc("onChange","change",null,n,o),e.push({event:n,listeners:t}))}var xr=null,_r=null;function Ak(e){i0(e,0)}function es(e){var t=br(e);if(eh(t))return e}function gg(e,t){if(e==="change")return t}var dh=!1;to&&(to?(Vl="oninput"in document,Vl||(Tu=document.createElement("div"),Tu.setAttribute("oninput","return;"),Vl=typeof Tu.oninput=="function"),Yl=Vl):Yl=!1,dh=Yl&&(!document.documentMode||9<document.documentMode));var Yl,Vl,Tu;function bg(){xr&&(xr.detachEvent("onpropertychange",fh),_r=xr=null)}function fh(e){if(e.propertyName==="value"&&es(_r)){var t=[];uh(t,_r,e,uf(e)),ih(Ak,t)}}function zk(e,t,n){e==="focusin"?(bg(),xr=t,_r=n,xr.attachEvent("onpropertychange",fh)):e==="focusout"&&bg()}function Ok(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return es(_r)}function Rk(e,t){if(e==="click")return es(t)}function Dk(e,t){if(e==="input"||e==="change")return es(t)}function _k(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var $t=typeof Object.is=="function"?Object.is:_k;function Hr(e,t){if($t(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),o=Object.keys(t);if(n.length!==o.length)return!1;for(o=0;o<n.length;o++){var a=n[o];if(!nd.call(t,a)||!$t(e[a],t[a]))return!1}return!0}function ld(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function hg(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function vg(e,t){var n=hg(e);e=0;for(var o;n;){if(n.nodeType===3){if(o=e+n.textContent.length,e<=t&&o>=t)return{node:n,offset:t-e};e=o}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=hg(n)}}function ph(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?ph(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function mh(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=ld(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=ld(e.document)}return t}function mf(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var Hk=to&&"documentMode"in document&&11>=document.documentMode,ai=null,cd=null,wr=null,sd=!1;function yg(e,t,n){var o=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;sd||ai==null||ai!==ld(o)||(o=ai,"selectionStart"in o&&mf(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),wr&&Hr(wr,o)||(wr=o,o=Zc(cd,"onSelect"),0<o.length&&(t=new Fc("onSelect","select",null,t,n),e.push({event:t,listeners:o}),t.target=ai)))}function oa(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var ii={animationend:oa("Animation","AnimationEnd"),animationiteration:oa("Animation","AnimationIteration"),animationstart:oa("Animation","AnimationStart"),transitionrun:oa("Transition","TransitionRun"),transitionstart:oa("Transition","TransitionStart"),transitioncancel:oa("Transition","TransitionCancel"),transitionend:oa("Transition","TransitionEnd")},Cu={},gh={};to&&(gh=document.createElement("div").style,"AnimationEvent"in window||(delete ii.animationend.animation,delete ii.animationiteration.animation,delete ii.animationstart.animation),"TransitionEvent"in window||delete ii.transitionend.transition);function Ta(e){if(Cu[e])return Cu[e];if(!ii[e])return e;var t=ii[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in gh)return Cu[e]=t[n];return e}var bh=Ta("animationend"),hh=Ta("animationiteration"),vh=Ta("animationstart"),Bk=Ta("transitionrun"),Lk=Ta("transitionstart"),Uk=Ta("transitioncancel"),yh=Ta("transitionend"),xh=new Map,ud="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");ud.push("scrollEnd");function wn(e,t){xh.set(e,t),Ea(t,[e])}var jk=0;function no(e,t){if(e.name!=null&&e.name!=="auto")return e.name;if(t.autoName!==null)return t.autoName;e=xn.identifierPrefix;var n=jk++;return e="_"+e+"t_"+n.toString(32)+"_",t.autoName=e}function xg(e){if(e==null||typeof e=="string")return e;var t=null,n=xi;if(n!==null)for(var o=0;o<n.length;o++){var a=e[n[o]];if(a!=null){if(a==="none")return"none";t=t==null?a:t+(" "+a)}}return t??e.default}function co(e,t){return e=xg(e),t=xg(t),t==null?e==="auto"?null:e:t==="auto"?null:t}var Cc=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},nn=[],ri=0,gf=0;function ts(){for(var e=ri,t=gf=ri=0;t<e;){var n=nn[t];nn[t++]=null;var o=nn[t];nn[t++]=null;var a=nn[t];nn[t++]=null;var i=nn[t];if(nn[t++]=null,o!==null&&a!==null){var r=o.pending;r===null?a.next=a:(a.next=r.next,r.next=a),o.pending=a}i!==0&&wh(n,a,i)}}function ns(e,t,n,o){nn[ri++]=e,nn[ri++]=t,nn[ri++]=n,nn[ri++]=o,gf|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function bf(e,t,n,o){return ns(e,t,n,o),Nc(e)}function Ca(e,t){return ns(e,null,null,t),Nc(e)}function wh(e,t,n){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n);for(var a=!1,i=e.return;i!==null;)i.childLanes|=n,o=i.alternate,o!==null&&(o.childLanes|=n),i.tag===22&&(e=i.stateNode,e===null||e._visibility&1||(a=!0)),e=i,i=i.return;return e.tag===3?(i=e.stateNode,a&&t!==null&&(a=31-Zt(n),e=i.hiddenUpdates,o=e[a],o===null?e[a]=[t]:o.push(t),t.lane=n|536870912),i):null}function Nc(e){if(50<Or)throw Or=0,gc=null,Error(N(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var li={};function qk(e,t,n,o){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Ot(e,t,n,o){return new qk(e,t,n,o)}function hf(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Wn(e,t){var n=e.alternate;return n===null?(n=Ot(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function kh(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function rc(e,t,n,o,a,i){var r=0;if(o=e,typeof o=="function")hf(o)&&(r=1);else if(typeof o=="string")r=f2(e,n,Hn.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(o){case Iu:return e=Ot(31,n,t,a),e.elementType=Iu,e.lanes=i,e;case ei:return da(n.children,a,i,t);case jb:r=8,a|=24;break;case Pu:return e=Ot(12,n,t,a|2),e.elementType=Pu,e.lanes=i,e;case $u:return e=Ot(13,n,t,a),e.elementType=$u,e.lanes=i,e;case Ju:return e=Ot(19,n,t,a),e.elementType=Ju,e.lanes=i,e;case Nw:case Fu:return e=a|32,e=Ot(30,n,t,e),e.elementType=Fu,e.lanes=i,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof o=="object"&&o!==null)switch(o.$$typeof){case On:r=10;break e;case qb:r=9;break e;case of:r=11;break e;case af:r=14;break e;case wo:r=16,o=null;break e}r=29,n=Error(N(130,e===null?"null":typeof e,"")),o=null}return t=Ot(r,n,t,a),t.elementType=e,t.type=o,t.lanes=i,t}function da(e,t,n,o){return e=Ot(7,e,o,t),e.lanes=n,e}function Nu(e,t,n){return e=Ot(6,e,null,t),e.lanes=n,e}function Sh(e){var t=Ot(18,null,null,0);return t.stateNode=e,t}function Mu(e,t,n){return t=Ot(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var wg=new WeakMap;function ln(e,t){if(typeof e=="object"&&e!==null){var n=wg.get(e);return n!==void 0?n:(t={value:e,source:t,stack:Wm(t)},wg.set(e,t),t)}return{value:e,source:t,stack:Wm(t)}}var ci=[],si=0,Mc=null,Br=0,on=[],an=0,qo=null,Dn=1,_n="";function In(e,t){ci[si++]=Br,ci[si++]=Mc,Mc=e,Br=t}function Eh(e,t,n){on[an++]=Dn,on[an++]=_n,on[an++]=qo,qo=e;var o=Dn;e=_n;var a=32-Zt(o)-1;o&=~(1<<a),n+=1;var i=32-Zt(t)+a;if(30<i){var r=a-a%5;i=(o&(1<<r)-1).toString(32),o>>=r,a-=r,Dn=1<<32-Zt(t)+a|n<<a|o,_n=i+e}else Dn=1<<i|n<<a|o,_n=e}function os(e){e.return!==null&&(In(e,1),Eh(e,1,0))}function vf(e){for(;e===Mc;)Mc=ci[--si],ci[si]=null,Br=ci[--si],ci[si]=null;for(;e===qo;)qo=on[--an],on[an]=null,_n=on[--an],on[an]=null,Dn=on[--an],on[an]=null}function Th(e,t){on[an++]=Dn,on[an++]=_n,on[an++]=qo,Dn=t.id,_n=t.overflow,qo=e}var tt=null,ke=null,F=!1,Oo=null,cn=!1,dd=Error(N(519));function Yo(e){var t=Error(N(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Lr(ln(t,e)),dd}function kg(e){var t=e.stateNode,n=e.type,o=e.memoizedProps;switch(t[it]=e,t[_t]=o,n){case"dialog":ee("cancel",t),ee("close",t);break;case"iframe":case"object":case"embed":ee("load",t);break;case"video":case"audio":for(n=0;n<Yr.length;n++)ee(Yr[n],t);break;case"source":ee("error",t);break;case"img":case"image":case"link":ee("error",t),ee("load",t);break;case"details":ee("toggle",t);break;case"input":ee("invalid",t),th(t,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":ee("invalid",t);break;case"textarea":ee("invalid",t),oh(t,o.value,o.defaultValue,o.children)}n=o.children,typeof n!="string"&&typeof n!="number"&&typeof n!="bigint"||t.textContent===""+n||o.suppressHydrationWarning===!0||l0(t.textContent,n)?(o.popover!=null&&(ee("beforetoggle",t),ee("toggle",t)),o.onScroll!=null&&ee("scroll",t),o.onScrollEnd!=null&&ee("scrollend",t),o.onClick!=null&&(t.onclick=Rn),t=!0):t=!1,t||Yo(e,!0)}function Ac(e){for(tt=e.return;tt;)switch(tt.tag){case 5:case 31:case 13:cn=!1;return;case 27:case 3:cn=!0;return;default:tt=tt.return}}function Pa(e){if(e!==tt)return!1;if(!F)return Ac(e),F=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!=="form"&&n!=="button")||$d(e.type,e.memoizedProps)),n=!n),n&&ke&&Yo(e),Ac(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(N(317));ke=vb(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(N(317));ke=vb(e)}else t===27?(t=ke,Qo(e.type)?(e=Wd,Wd=null,ke=e):ke=t):ke=tt?sn(e.stateNode.nextSibling):null;return!0}function ga(){ke=tt=null,F=!1}function Au(){var e=Oo;return e!==null&&(At===null?At=e:At.push.apply(At,e),Oo=null),e}function Lr(e){Oo===null?Oo=[e]:Oo.push(e)}var fd=Un(null),Na=null,Fn=null;function Co(e,t,n){Se(fd,t._currentValue),t._currentValue=n}function eo(e){e._currentValue=fd.current,lt(fd)}function lc(e,t,n){for(;e!==null;){var o=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,o!==null&&(o.childLanes|=t)):o!==null&&(o.childLanes&t)!==t&&(o.childLanes|=t),e===n)break;e=e.return}}function pd(e,t,n,o){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var i=a.dependencies;if(i!==null){var r=a.child;i=i.firstContext;e:for(;i!==null;){var l=i;i=a;for(var c=0;c<t.length;c++)if(l.context===t[c]){i.lanes|=n,l=i.alternate,l!==null&&(l.lanes|=n),lc(i.return,n,e),o||(r=null);break e}i=l.next}}else if(a.tag===18){if(r=a.return,r===null)throw Error(N(341));r.lanes|=n,i=r.alternate,i!==null&&(i.lanes|=n),lc(r,n,e),r=null}else a.tag===13&&a.memoizedState!==null&&a.memoizedState.dehydrated===null?(a.lanes|=n,r=a.alternate,r!==null&&(r.lanes|=n),lc(a.return,n,e),r=a.child,r=r!==null?r.sibling:null):r=a.child;if(r!==null)r.return=a;else for(r=a;r!==null;){if(r===e){r=null;break}if(a=r.sibling,a!==null){a.return=r.return,r=a;break}r=r.return}a=r}}function ba(e,t,n,o){e=null;for(var a=t,i=!1;a!==null;){if(!i){if((a.flags&524288)!==0)i=!0;else if((a.flags&262144)!==0)break}if(a.tag===10){var r=a.alternate;if(r===null)throw Error(N(387));if(r=r.memoizedProps,r!==null){var l=a.type;$t(a.pendingProps.value,r.value)||(e!==null?e.push(l):e=[l])}}else if(a===wc.current){if(r=a.alternate,r===null)throw Error(N(387));r.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e!==null?e.push(Oi):e=[Oi])}a=a.return}return e!==null&&pd(t,e,n,o),t.flags|=262144,e!==null}function zc(e){for(e=e.firstContext;e!==null;){if(!$t(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function ha(e){Na=e,Fn=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function rt(e){return Ch(Na,e)}function Kl(e,t){return Na===null&&ha(e),Ch(e,t)}function Ch(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},Fn===null){if(e===null)throw Error(N(308));Fn=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else Fn=Fn.next=t;return n}var Yk=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(n,o){e.push(o)}};this.abort=function(){t.aborted=!0,e.forEach(function(n){return n()})}},Vk=$e.unstable_scheduleCallback,Kk=$e.unstable_NormalPriority,Ve={$$typeof:On,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function yf(){return{controller:new Yk,data:new Map,refCount:0}}function el(e){e.refCount--,e.refCount===0&&Vk(Kk,function(){e.controller.abort()})}function Sg(e,t){if((e.pendingLanes&4194048)!==0){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var o=t[e];n.indexOf(o)===-1&&n.push(o)}}}var hr=null;function Xk(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var kr=null,md=0,va=0,mi=null;function Gk(e,t){if(kr===null){var n=kr=[];md=0,va=Zf(),mi={status:"pending",value:void 0,then:function(o){n.push(o)}}}return md++,t.then(Eg,Eg),t}function Eg(){if(--md===0&&(hr=null,kr!==null)){mi!==null&&(mi.status="fulfilled");var e=kr;kr=null,va=0,mi=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Qk(e,t){var n=[],o={status:"pending",value:null,reason:null,then:function(a){n.push(a)}};return e.then(function(){o.status="fulfilled",o.value=t;for(var a=0;a<n.length;a++)(0,n[a])(t)},function(a){for(o.status="rejected",o.reason=a,a=0;a<n.length;a++)(0,n[a])(void 0)}),o}var Tg=V.S;V.S=function(e,t){if(Xv=Gt(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&Gk(e,t),hr!==null)for(var n=Mi;n!==null;)Sg(n,hr),n=n.next;if(n=e.types,n!==null){for(var o=Mi;o!==null;)Sg(o,n),o=o.next;if(va!==0){o=hr,o===null&&(o=hr=[]);for(var a=0;a<n.length;a++){var i=n[a];o.indexOf(i)===-1&&o.push(i)}}}Tg!==null&&Tg(e,t)};var fa=Un(null);function xf(){var e=fa.current;return e!==null?e:he.pooledCache}function cc(e,t){t===null?Se(fa,fa.current):Se(fa,t.pool)}function Nh(){var e=xf();return e===null?null:{parent:Ve._currentValue,pool:e}}var Bi=Error(N(460)),wf=Error(N(474)),as=Error(N(542)),Oc={then:function(){}};function Cg(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Mh(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(Rn,Rn),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Mg(e),e===void 0&&!("reason"in t)?Error(N(600)):e;default:if(typeof t.status=="string")t.then(Rn,Rn);else{if(e=he,e!==null&&100<e.shellSuspendCounter)throw Error(N(482));e=t,e.status="pending",e.then(function(o){if(t.status==="pending"){var a=t;a.status="fulfilled",a.value=o}},function(o){if(t.status==="pending"){var a=t;a.status="rejected",a.reason=o}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Mg(e),e}throw pa=t,Bi}}function ra(e){try{var t=e._init;return t(e._payload)}catch(n){throw n!==null&&typeof n=="object"&&typeof n.then=="function"?(pa=n,Bi):n}}var pa=null;function Ng(){if(pa===null)throw Error(N(459));var e=pa;return pa=null,e}function Mg(e){if(e===Bi||e===as)throw Error(N(483))}var gi=null,Ur=0;function Xl(e){var t=Ur;return Ur+=1,gi===null&&(gi=[]),Mh(gi,e,t)}function vo(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function Gl(e,t){throw t.$$typeof===Cw?Error(N(525)):(e=Object.prototype.toString.call(t),Error(N(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function Ah(e){function t(g,b){if(e){var p=g.deletions;p===null?(g.deletions=[b],g.flags|=16):p.push(b)}}function n(g,b){if(!e)return null;for(;b!==null;)t(g,b),b=b.sibling;return null}function o(g){for(var b=new Map;g!==null;)g.key===null?b.set(g.index,g):b.set(g.key,g),g=g.sibling;return b}function a(g,b){return g=Wn(g,b),g.index=0,g.sibling=null,g}function i(g,b,p){return g.index=p,e?(p=g.alternate,p!==null?(p=p.index,p<b?(g.flags|=2,b):p):(g.flags|=134217730,b)):(g.flags|=1048576,b)}function r(g){return e&&g.alternate===null&&(g.flags|=134217730),g}function l(g,b,p,v){return b===null||b.tag!==6?(b=Nu(p,g.mode,v),b.return=g,b):(b=a(b,p),b.return=g,b)}function c(g,b,p,v){var h=p.type;return h===ei?(g=f(g,b,p.props.children,v,p.key),vo(g,p),g):b!==null&&(b.elementType===h||typeof h=="object"&&h!==null&&h.$$typeof===wo&&ra(h)===b.type)?(b=a(b,p.props),vo(b,p),b.return=g,b):(b=rc(p.type,p.key,p.props,null,g.mode,v),vo(b,p),b.return=g,b)}function s(g,b,p,v){return b===null||b.tag!==4||b.stateNode.containerInfo!==p.containerInfo||b.stateNode.implementation!==p.implementation?(b=Mu(p,g.mode,v),b.return=g,b):(b=a(b,p.children||[]),b.return=g,b)}function f(g,b,p,v,h){return b===null||b.tag!==7?(b=da(p,g.mode,v,h),b.return=g,b):(b=a(b,p),b.return=g,b)}function m(g,b,p){if(typeof b=="string"&&b!==""||typeof b=="number"||typeof b=="bigint")return b=Nu(""+b,g.mode,p),b.return=g,b;if(typeof b=="object"&&b!==null){switch(b.$$typeof){case Hl:return p=rc(b.type,b.key,b.props,null,g.mode,p),vo(p,b),p.return=g,p;case mr:return b=Mu(b,g.mode,p),b.return=g,b;case wo:return b=ra(b),m(g,b,p)}if(gr(b)||cr(b))return b=da(b,g.mode,p,null),b.return=g,b;if(typeof b.then=="function")return m(g,Xl(b),p);if(b.$$typeof===On)return m(g,Kl(g,b),p);Gl(g,b)}return null}function u(g,b,p,v){var h=b!==null?b.key:null;if(typeof p=="string"&&p!==""||typeof p=="number"||typeof p=="bigint")return h!==null?null:l(g,b,""+p,v);if(typeof p=="object"&&p!==null){switch(p.$$typeof){case Hl:return p.key===h?c(g,b,p,v):null;case mr:return p.key===h?s(g,b,p,v):null;case wo:return p=ra(p),u(g,b,p,v)}if(gr(p)||cr(p))return h!==null?null:f(g,b,p,v,null);if(typeof p.then=="function")return u(g,b,Xl(p),v);if(p.$$typeof===On)return u(g,b,Kl(g,p),v);Gl(g,p)}return null}function d(g,b,p,v,h){if(typeof v=="string"&&v!==""||typeof v=="number"||typeof v=="bigint")return g=g.get(p)||null,l(b,g,""+v,h);if(typeof v=="object"&&v!==null){switch(v.$$typeof){case Hl:return g=g.get(v.key===null?p:v.key)||null,c(b,g,v,h);case mr:return g=g.get(v.key===null?p:v.key)||null,s(b,g,v,h);case wo:return v=ra(v),d(g,b,p,v,h)}if(gr(v)||cr(v))return g=g.get(p)||null,f(b,g,v,h,null);if(typeof v.then=="function")return d(g,b,p,Xl(v),h);if(v.$$typeof===On)return d(g,b,p,Kl(b,v),h);Gl(b,v)}return null}function x(g,b,p,v){for(var h=null,T=null,w=b,S=b=0,M=null;w!==null&&S<p.length;S++){w.index>S?(M=w,w=null):M=w.sibling;var A=u(g,w,p[S],v);if(A===null){w===null&&(w=M);break}e&&w&&A.alternate===null&&t(g,w),b=i(A,b,S),T===null?h=A:T.sibling=A,T=A,w=M}if(S===p.length)return n(g,w),F&&In(g,S),h;if(w===null){for(;S<p.length;S++)w=m(g,p[S],v),w!==null&&(b=i(w,b,S),T===null?h=w:T.sibling=w,T=w);return F&&In(g,S),h}for(w=o(w);S<p.length;S++)M=d(w,g,S,p[S],v),M!==null&&(e&&(A=M.alternate,A!==null&&w.delete(A.key===null?S:A.key)),b=i(M,b,S),T===null?h=M:T.sibling=M,T=M);return e&&w.forEach(function(H){return t(g,H)}),F&&In(g,S),h}function k(g,b,p,v){if(p==null)throw Error(N(151));for(var h=null,T=null,w=b,S=b=0,M=null,A=p.next();w!==null&&!A.done;S++,A=p.next()){w.index>S?(M=w,w=null):M=w.sibling;var H=u(g,w,A.value,v);if(H===null){w===null&&(w=M);break}e&&w&&H.alternate===null&&t(g,w),b=i(H,b,S),T===null?h=H:T.sibling=H,T=H,w=M}if(A.done)return n(g,w),F&&In(g,S),h;if(w===null){for(;!A.done;S++,A=p.next())A=m(g,A.value,v),A!==null&&(b=i(A,b,S),T===null?h=A:T.sibling=A,T=A);return F&&In(g,S),h}for(w=o(w);!A.done;S++,A=p.next())A=d(w,g,S,A.value,v),A!==null&&(e&&(M=A.alternate,M!==null&&w.delete(M.key===null?S:M.key)),b=i(A,b,S),T===null?h=A:T.sibling=A,T=A);return e&&w.forEach(function(B){return t(g,B)}),F&&In(g,S),h}function E(g,b,p,v){if(typeof p=="object"&&p!==null&&p.type===ei&&p.key===null&&p.props.ref===void 0&&(p=p.props.children),typeof p=="object"&&p!==null){switch(p.$$typeof){case Hl:e:{for(var h=p.key;b!==null;){if(b.key===h){if(h=p.type,h===ei){if(b.tag===7){n(g,b.sibling),v=a(b,p.props.children),vo(v,p),v.return=g,g=v;break e}}else if(b.elementType===h||typeof h=="object"&&h!==null&&h.$$typeof===wo&&ra(h)===b.type){n(g,b.sibling),v=a(b,p.props),vo(v,p),v.return=g,g=v;break e}n(g,b);break}else t(g,b);b=b.sibling}p.type===ei?(v=da(p.props.children,g.mode,v,p.key),vo(v,p),v.return=g,g=v):(v=rc(p.type,p.key,p.props,null,g.mode,v),vo(v,p),v.return=g,g=v)}return r(g);case mr:e:{for(h=p.key;b!==null;){if(b.key===h)if(b.tag===4&&b.stateNode.containerInfo===p.containerInfo&&b.stateNode.implementation===p.implementation){n(g,b.sibling),v=a(b,p.children||[]),v.return=g,g=v;break e}else{n(g,b);break}else t(g,b);b=b.sibling}v=Mu(p,g.mode,v),v.return=g,g=v}return r(g);case wo:return p=ra(p),E(g,b,p,v)}if(gr(p))return x(g,b,p,v);if(cr(p)){if(h=cr(p),typeof h!="function")throw Error(N(150));return p=h.call(p),k(g,b,p,v)}if(typeof p.then=="function")return E(g,b,Xl(p),v);if(p.$$typeof===On)return E(g,b,Kl(g,p),v);Gl(g,p)}return typeof p=="string"&&p!==""||typeof p=="number"||typeof p=="bigint"?(p=""+p,b!==null&&b.tag===6?(n(g,b.sibling),v=a(b,p),v.return=g,g=v):(n(g,b),v=Nu(p,g.mode,v),v.return=g,g=v),r(g)):n(g,b)}return function(g,b,p,v){try{Ur=0;var h=E(g,b,p,v);return gi=null,h}catch(w){if(w===Bi||w===as)throw w;var T=Ot(29,w,null,g.mode);return T.lanes=v,T.return=g,T}}}var ya=Ah(!0),zh=Ah(!1),ko=!1;function kf(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function gd(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Ro(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Do(e,t,n){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(ce&2)!==0){var a=o.pending;return a===null?t.next=t:(t.next=a.next,a.next=t),o.pending=t,t=Nc(e),wh(e,null,n),t}return ns(e,o,t,n),Nc(e)}function Sr(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194048)!==0)){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Zb(e,n)}}function zu(e,t){var n=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,n===o)){var a=null,i=null;if(n=n.firstBaseUpdate,n!==null){do{var r={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};i===null?a=i=r:i=i.next=r,n=n.next}while(n!==null);i===null?a=i=t:i=i.next=t}else a=i=t;n={baseState:o.baseState,firstBaseUpdate:a,lastBaseUpdate:i,shared:o.shared,callbacks:o.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var bd=!1;function Er(){if(bd){var e=mi;if(e!==null)throw e}}function Tr(e,t,n,o){bd=!1;var a=e.updateQueue;ko=!1;var i=a.firstBaseUpdate,r=a.lastBaseUpdate,l=a.shared.pending;if(l!==null){a.shared.pending=null;var c=l,s=c.next;c.next=null,r===null?i=s:r.next=s,r=c;var f=e.alternate;f!==null&&(f=f.updateQueue,l=f.lastBaseUpdate,l!==r&&(l===null?f.firstBaseUpdate=s:l.next=s,f.lastBaseUpdate=c))}if(i!==null){var m=a.baseState;r=0,f=s=c=null,l=i;do{var u=l.lane&-536870913,d=u!==l.lane;if(d?(ne&u)===u:(o&u)===u){u!==0&&u===va&&(bd=!0),f!==null&&(f=f.next={lane:0,tag:l.tag,payload:l.payload,callback:null,next:null});e:{var x=e,k=l;u=t;var E=n;switch(k.tag){case 1:if(x=k.payload,typeof x=="function"){m=x.call(E,m,u);break e}m=x;break e;case 3:x.flags=x.flags&-65537|128;case 0:if(x=k.payload,u=typeof x=="function"?x.call(E,m,u):x,u==null)break e;m=ve({},m,u);break e;case 2:ko=!0}}u=l.callback,u!==null&&(e.flags|=64,d&&(e.flags|=8192),d=a.callbacks,d===null?a.callbacks=[u]:d.push(u))}else d={lane:u,tag:l.tag,payload:l.payload,callback:l.callback,next:null},f===null?(s=f=d,c=m):f=f.next=d,r|=u;if(l=l.next,l===null){if(l=a.shared.pending,l===null)break;d=l,l=d.next,d.next=null,a.lastBaseUpdate=d,a.shared.pending=null}}while(!0);f===null&&(c=m),a.baseState=c,a.firstBaseUpdate=s,a.lastBaseUpdate=f,i===null&&(a.shared.lanes=0),Xo|=r,e.lanes=r,e.memoizedState=m}}function Oh(e,t){if(typeof e!="function")throw Error(N(191,e));e.call(t)}function Rh(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)Oh(n[e],t)}var Vo=Un(null),Rc=Un(0);function Ag(e,t){e=ro,Se(Rc,e),Se(Vo,t),ro=e|t.baseLanes}function hd(){Se(Rc,ro),Se(Vo,Vo.current)}function Sf(){ro=Rc.current,lt(Vo),lt(Rc)}var ut=Un(null),ht=null;function _o(e){var t=e.alternate;Se(ct,ct.current&1),Se(ut,e),ht===null&&(t===null||Vo.current!==null||t.memoizedState!==null)&&(ht=e)}function vd(e){Se(ct,ct.current),Se(ut,e),ht===null&&(ht=e)}function Dh(e){e.tag===22?(Se(ct,ct.current),Se(ut,e),ht===null&&(ht=e)):Ho()}function Ho(){Se(ct,ct.current),Se(ut,ut.current)}function Vt(e){lt(ut),ht===e&&(ht=null),lt(ct)}var ct=Un(0);function jr(e,t){Se(ut,ut.current),Se(ct,t)}function Ef(e){lt(ct),lt(ut),ht===e&&(ht=null)}function Dc(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||Fd(n)||If(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!=="independent"){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var oo=0,Z=null,be=null,Ye=null,_c=!1,bi=!1,xa=!1,Hc=0,qr=0,hi=null,Zk=0;function He(){throw Error(N(321))}function Tf(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!$t(e[n],t[n]))return!1;return!0}function Cf(e,t,n,o,a,i){return oo=i,Z=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,V.H=e===null||e.memoizedState===null?uv:dv,xa=!1,i=n(o,a),xa=!1,bi&&(i=Hh(t,n,o,a)),_h(e),i}function _h(e){V.H=Bc;var t=be!==null&&be.next!==null;if(oo=0,Ye=be=Z=null,_c=!1,qr=0,hi=null,t)throw Error(N(300));e===null||Ke||(e=e.dependencies,e!==null&&zc(e)&&(Ke=!0))}function Hh(e,t,n,o){Z=e;var a=0;do{if(bi&&(hi=null),qr=0,bi=!1,25<=a)throw Error(N(301));if(a+=1,Ye=be=null,e.updateQueue!=null){var i=e.updateQueue;i.lastEffect=null,i.events=null,i.stores=null,i.memoCache!=null&&(i.memoCache.index=0)}V.H=tS,i=t(n,o)}while(bi);return i}function Pk(){var e=V.H,t=e.useState()[0];return t=typeof t.then=="function"?tl(t):t,e=e.useState()[0],(be!==null?be.memoizedState:null)!==e&&(Z.flags|=1024),t}function Nf(){var e=Hc!==0;return Hc=0,e}function Mf(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function Af(e){if(_c){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}_c=!1}oo=0,Ye=be=Z=null,bi=!1,qr=Hc=0,hi=null}function Tt(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Ye===null?Z.memoizedState=Ye=e:Ye=Ye.next=e,Ye}function Ue(){if(be===null){var e=Z.alternate;e=e!==null?e.memoizedState:null}else e=be.next;var t=Ye===null?Z.memoizedState:Ye.next;if(t!==null)Ye=t,be=e;else{if(e===null)throw Z.alternate===null?Error(N(467)):Error(N(310));be=e,e={memoizedState:be.memoizedState,baseState:be.baseState,baseQueue:be.baseQueue,queue:be.queue,next:null},Ye===null?Z.memoizedState=Ye=e:Ye=Ye.next=e}return Ye}function is(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function tl(e){var t=qr;return qr+=1,hi===null&&(hi=[]),e=Mh(hi,e,t),t=Z,(Ye===null?t.memoizedState:Ye.next)===null&&(t=t.alternate,V.H=t===null||t.memoizedState===null?uv:dv),e}function rs(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return tl(e);if(e.$$typeof===Aw)return;if(e.$$typeof===On)return rt(e)}throw Error(N(438,String(e)))}function zf(e){var t=null,n=Z.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var o=Z.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(t={data:o.data.map(function(a){return a.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),n===null&&(n=is(),Z.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),o=0;o<e;o++)n[o]=Mw;return t.index++,n}function ao(e,t){return typeof t=="function"?t(e):t}function sc(e){var t=Ue();return Of(t,be,e)}function Of(e,t,n){var o=e.queue;if(o===null)throw Error(N(311));o.lastRenderedReducer=n;var a=e.baseQueue,i=o.pending;if(i!==null){if(a!==null){var r=a.next;a.next=i.next,i.next=r}t.baseQueue=a=i,o.pending=null}if(i=e.baseState,a===null)e.memoizedState=i;else{t=a.next;var l=r=null,c=null,s=t,f=!1;do{var m=s.lane&-536870913;if(m!==s.lane?(ne&m)===m:(oo&m)===m){var u=s.revertLane;if(u===0)c!==null&&(c=c.next={lane:0,revertLane:0,gesture:null,action:s.action,hasEagerState:s.hasEagerState,eagerState:s.eagerState,next:null}),m===va&&(f=!0);else if((oo&u)===u){s=s.next,u===va&&(f=!0);continue}else m={lane:0,revertLane:s.revertLane,gesture:null,action:s.action,hasEagerState:s.hasEagerState,eagerState:s.eagerState,next:null},c===null?(l=c=m,r=i):c=c.next=m,Z.lanes|=u,Xo|=u;m=s.action,xa&&n(i,m),i=s.hasEagerState?s.eagerState:n(i,m)}else u={lane:m,revertLane:s.revertLane,gesture:s.gesture,action:s.action,hasEagerState:s.hasEagerState,eagerState:s.eagerState,next:null},c===null?(l=c=u,r=i):c=c.next=u,Z.lanes|=m,Xo|=m;s=s.next}while(s!==null&&s!==t);if(c===null?r=i:c.next=l,!$t(i,e.memoizedState)&&(Ke=!0,f&&(n=mi,n!==null)))throw n;e.memoizedState=i,e.baseState=r,e.baseQueue=c,o.lastRenderedState=i}return a===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function Ou(e){var t=Ue(),n=t.queue;if(n===null)throw Error(N(311));n.lastRenderedReducer=e;var o=n.dispatch,a=n.pending,i=t.memoizedState;if(a!==null){n.pending=null;var r=a=a.next;do i=e(i,r.action),r=r.next;while(r!==a);$t(i,t.memoizedState)||(Ke=!0),t.memoizedState=i,t.baseQueue===null&&(t.baseState=i),n.lastRenderedState=i}return[i,o]}function Bh(e,t,n){var o=Z,a=Ue(),i=F;if(i){if(n===void 0)throw Error(N(407));n=n()}else n=t();var r=!$t((be||a).memoizedState,n);if(r&&(a.memoizedState=n,Ke=!0),a=a.queue,Rf(jh.bind(null,o,a,e),[e]),e=a.getSnapshot!==t||r||Ye!==null&&(Ye.memoizedState.tag&1)!==0,Ei(e?9:8,{destroy:void 0},Uh.bind(null,o,a,n,t),null),e){if(o.flags|=2048,he===null)throw Error(N(349));i||(oo&127)!==0||Lh(o,t,n)}return n}function Lh(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=Z.updateQueue,t===null?(t=is(),Z.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Uh(e,t,n,o){t.value=n,t.getSnapshot=o,qh(t)&&Yh(e)}function jh(e,t,n){return n(function(){qh(t)&&Yh(e)})}function qh(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!$t(e,n)}catch{return!0}}function Yh(e){var t=Ca(e,2);t!==null&&Rt(t,e,2)}function yd(e){var t=Tt();if(typeof e=="function"){var n=e;if(e=n(),xa){Eo(!0);try{n()}finally{Eo(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ao,lastRenderedState:e},t}function Vh(e,t,n,o){return e.baseState=n,Of(e,be,typeof o=="function"?o:ao)}function $k(e,t,n,o,a){if(cs(e))throw Error(N(485));if(e=t.action,e!==null){var i={payload:a,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(r){i.listeners.push(r)}};V.T!==null?n(!0):i.isTransition=!1,o(i),n=t.pending,n===null?(i.next=t.pending=i,Kh(t,i)):(i.next=n.next,t.pending=n.next=i)}}function Kh(e,t){var n=t.action,o=t.payload,a=e.state;if(t.isTransition){var i=V.T,r={};r.types=i!==null?i.types:null,V.T=r;try{var l=n(a,o),c=V.S;c!==null&&c(r,l),zg(e,t,l)}catch(s){xd(e,t,s)}finally{i!==null&&r.types!==null&&(i.types=r.types),V.T=i}}else try{i=n(a,o),zg(e,t,i)}catch(s){xd(e,t,s)}}function zg(e,t,n){n!==null&&typeof n=="object"&&typeof n.then=="function"?n.then(function(o){Og(e,t,o)},function(o){return xd(e,t,o)}):Og(e,t,n)}function Og(e,t,n){t.status="fulfilled",t.value=n,Xh(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Kh(e,n)))}function xd(e,t,n){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do t.status="rejected",t.reason=n,Xh(t),t=t.next;while(t!==o)}e.action=null}function Xh(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Gh(e,t){return t}function Rg(e,t){if(F){var n=he.formState;if(n!==null){e:{var o=Z;if(F){if(ke){t:{for(var a=ke,i=cn;a.nodeType!==8;){if(!i){a=null;break t}if(a=sn(a.nextSibling),a===null){a=null;break t}}i=a.data,a=i==="F!"||i==="F"?a:null}if(a){ke=sn(a.nextSibling),o=a.data==="F!";break e}}Yo(o)}o=!1}o&&(t=n[0])}}return n=Tt(),n.memoizedState=n.baseState=t,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Gh,lastRenderedState:t},n.queue=o,n=lv.bind(null,Z,o),o.dispatch=n,o=yd(!1),i=Bf.bind(null,Z,!1,o.queue),o=Tt(),a={state:t,dispatch:null,action:e,pending:null},o.queue=a,n=$k.bind(null,Z,a,i,n),a.dispatch=n,o.memoizedState=e,[t,n,!1]}function Dg(e){var t=Ue();return Qh(t,be,e)}function Qh(e,t,n){if(t=Of(e,t,Gh)[0],e=sc(ao)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var o=tl(t)}catch(r){throw r===Bi?as:r}else o=t;t=Ue();var a=t.queue,i=a.dispatch;return n!==t.memoizedState&&(Z.flags|=2048,Ei(9,{destroy:void 0},Jk.bind(null,a,n),null)),[o,i,e]}function Jk(e,t){e.action=t}function _g(e){var t=Ue(),n=be;if(n!==null)return Qh(t,n,e);Ue(),t=t.memoizedState,n=Ue();var o=n.queue.dispatch;return n.memoizedState=e,[t,o,!1]}function Ei(e,t,n,o){return e={tag:e,create:n,deps:o,inst:t,next:null},t=Z.updateQueue,t===null&&(t=is(),Z.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(o=n.next,n.next=e,e.next=o,t.lastEffect=e),e}function Zh(){return Ue().memoizedState}function uc(e,t,n,o){var a=Tt();Z.flags|=e,a.memoizedState=Ei(1|t,{destroy:void 0},n,o===void 0?null:o)}function ls(e,t,n,o){var a=Ue();o=o===void 0?null:o;var i=a.memoizedState.inst;be!==null&&o!==null&&Tf(o,be.memoizedState.deps)?a.memoizedState=Ei(t,i,n,o):(Z.flags|=e,a.memoizedState=Ei(1|t,i,n,o))}function Hg(e,t){uc(8390656,8,e,t)}function Rf(e,t){ls(2048,8,e,t)}function Ik(e){Z.flags|=4;var t=Z.updateQueue;if(t===null)t=is(),Z.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Ph(e){var t=Ue().memoizedState;return Ik({ref:t,nextImpl:e}),function(){if((ce&2)!==0)throw Error(N(440));return t.impl.apply(void 0,arguments)}}function $h(e,t){return ls(4,2,e,t)}function Jh(e,t){return ls(4,4,e,t)}function Ih(e,t){if(typeof t=="function"){e=e();var n=t(e);return function(){typeof n=="function"?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Fh(e,t,n){n=n!=null?n.concat([e]):null,ls(4,4,Ih.bind(null,t,e),n)}function Df(){}function Wh(e,t){var n=Ue();t=t===void 0?null:t;var o=n.memoizedState;return t!==null&&Tf(t,o[1])?o[0]:(n.memoizedState=[e,t],e)}function ev(e,t){var n=Ue();t=t===void 0?null:t;var o=n.memoizedState;if(t!==null&&Tf(t,o[1]))return o[0];if(o=e(),xa){Eo(!0);try{e()}finally{Eo(!1)}}return n.memoizedState=[o,t],o}function _f(e,t,n){return n===void 0||(oo&1073741824)!==0&&(ne&261930)===0?e.memoizedState=t:(e.memoizedState=n,e=Qv(),Z.lanes|=e,Xo|=e,n)}function tv(e,t,n,o){return $t(n,t)?n:Vo.current!==null?(e=_f(e,n,o),$t(e,t)||(Ke=!0),e):(oo&106)===0||(oo&1073741824)!==0&&(ne&261930)===0?(Ke=!0,e.memoizedState=n):(e=Qv(),Z.lanes|=e,Xo|=e,t)}function nv(e,t,n,o,a){var i=se.p;se.p=i!==0&&8>i?i:8;var r=V.T,l={};l.types=r!==null?r.types:null,V.T=l,Bf(e,!1,t,n);try{var c=a(),s=V.S;if(s!==null&&s(l,c),c!==null&&typeof c=="object"&&typeof c.then=="function"){var f=Qk(c,o);Cr(e,t,f,Pt(e))}else Cr(e,t,o,Pt(e))}catch(m){Cr(e,t,{then:function(){},status:"rejected",reason:m},Pt())}finally{se.p=i,r!==null&&l.types!==null&&(r.types=l.types),V.T=r}}function Fk(){}function wd(e,t,n,o){if(e.tag!==5)throw Error(N(476));var a=ov(e).queue;nv(e,a,t,ua,n===null?Fk:function(){return av(e),n(o)})}function ov(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:ua,baseState:ua,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ao,lastRenderedState:ua},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ao,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function av(e){var t=ov(e);t.next===null&&(t=e.alternate.memoizedState),Cr(e,t.next.queue,{},Pt())}function Hf(){return rt(Oi)}function iv(){return Ue().memoizedState}function rv(){return Ue().memoizedState}function Wk(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=Pt();e=Ro(n);var o=Do(t,e,n);o!==null&&(Rt(o,t,n),Sr(o,t,n)),t={cache:yf()},e.payload=t;return}t=t.return}}function eS(e,t,n){var o=Pt();n={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},cs(e)?cv(t,n):(n=bf(e,t,n,o),n!==null&&(Rt(n,e,o),sv(n,t,o)))}function lv(e,t,n){var o=Pt();Cr(e,t,n,o)}function Cr(e,t,n,o){var a={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(cs(e))cv(t,a);else{var i=e.alternate;if(e.lanes===0&&(i===null||i.lanes===0)&&(i=t.lastRenderedReducer,i!==null))try{var r=t.lastRenderedState,l=i(r,n);if(a.hasEagerState=!0,a.eagerState=l,$t(l,r))return ns(e,t,a,0),he===null&&ts(),!1}catch{}if(n=bf(e,t,a,o),n!==null)return Rt(n,e,o),sv(n,t,o),!0}return!1}function Bf(e,t,n,o){if(o={lane:2,revertLane:Zf(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},cs(e)){if(t)throw Error(N(479))}else t=bf(e,n,o,2),t!==null&&Rt(t,e,2)}function cs(e){var t=e.alternate;return e===Z||t!==null&&t===Z}function cv(e,t){bi=_c=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function sv(e,t,n){if((n&4194048)!==0){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Zb(e,n)}}var Bc={readContext:rt,use:rs,useCallback:He,useContext:He,useEffect:He,useImperativeHandle:He,useLayoutEffect:He,useInsertionEffect:He,useMemo:He,useReducer:He,useRef:He,useState:He,useDebugValue:He,useDeferredValue:He,useTransition:He,useSyncExternalStore:He,useId:He,useHostTransitionStatus:He,useFormState:He,useActionState:He,useOptimistic:He,useMemoCache:He,useCacheRefresh:He,useEffectEvent:He},uv={readContext:rt,use:rs,useCallback:function(e,t){return Tt().memoizedState=[e,t===void 0?null:t],e},useContext:rt,useEffect:Hg,useImperativeHandle:function(e,t,n){n=n!=null?n.concat([e]):null,uc(4194308,4,Ih.bind(null,t,e),n)},useLayoutEffect:function(e,t){return uc(4194308,4,e,t)},useInsertionEffect:function(e,t){uc(4,2,e,t)},useMemo:function(e,t){var n=Tt();t=t===void 0?null:t;var o=e();if(xa){Eo(!0);try{e()}finally{Eo(!1)}}return n.memoizedState=[o,t],o},useReducer:function(e,t,n){var o=Tt();if(n!==void 0){var a=n(t);if(xa){Eo(!0);try{n(t)}finally{Eo(!1)}}}else a=t;return o.memoizedState=o.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:a},o.queue=e,e=e.dispatch=eS.bind(null,Z,e),[o.memoizedState,e]},useRef:function(e){var t=Tt();return e={current:e},t.memoizedState=e},useState:function(e){e=yd(e);var t=e.queue,n=lv.bind(null,Z,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:Df,useDeferredValue:function(e,t){var n=Tt();return _f(n,e,t)},useTransition:function(){var e=yd(!1);return e=nv.bind(null,Z,e.queue,!0,!1),Tt().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var o=Z,a=Tt();if(F){if(n===void 0)throw Error(N(407));n=n()}else{if(n=t(),he===null)throw Error(N(349));(ne&127)!==0||Lh(o,t,n)}a.memoizedState=n;var i={value:n,getSnapshot:t};return a.queue=i,Hg(jh.bind(null,o,i,e),[e]),o.flags|=2048,Ei(9,{destroy:void 0},Uh.bind(null,o,i,n,t),null),n},useId:function(){var e=Tt(),t=he.identifierPrefix;if(F){var n=_n,o=Dn;n=(o&~(1<<32-Zt(o)-1)).toString(32)+n,t="_"+t+"R_"+n,n=Hc++,0<n&&(t+="H"+n.toString(32)),t+="_"}else n=Zk++,t="_"+t+"r_"+n.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:Hf,useFormState:Rg,useActionState:Rg,useOptimistic:function(e){var t=Tt();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=Bf.bind(null,Z,!0,n),n.dispatch=t,[e,t]},useMemoCache:zf,useCacheRefresh:function(){return Tt().memoizedState=Wk.bind(null,Z)},useEffectEvent:function(e){var t=Tt(),n={impl:e};return t.memoizedState=n,function(){if((ce&2)!==0)throw Error(N(440));return n.impl.apply(void 0,arguments)}}},dv={readContext:rt,use:rs,useCallback:Wh,useContext:rt,useEffect:Rf,useImperativeHandle:Fh,useInsertionEffect:$h,useLayoutEffect:Jh,useMemo:ev,useReducer:sc,useRef:Zh,useState:function(){return sc(ao)},useDebugValue:Df,useDeferredValue:function(e,t){var n=Ue();return tv(n,be.memoizedState,e,t)},useTransition:function(){var e=sc(ao)[0],t=Ue().memoizedState;return[typeof e=="boolean"?e:tl(e),t]},useSyncExternalStore:Bh,useId:iv,useHostTransitionStatus:Hf,useFormState:Dg,useActionState:Dg,useOptimistic:function(e,t){var n=Ue();return Vh(n,be,e,t)},useMemoCache:zf,useCacheRefresh:rv,useEffectEvent:Ph},tS={readContext:rt,use:rs,useCallback:Wh,useContext:rt,useEffect:Rf,useImperativeHandle:Fh,useInsertionEffect:$h,useLayoutEffect:Jh,useMemo:ev,useReducer:Ou,useRef:Zh,useState:function(){return Ou(ao)},useDebugValue:Df,useDeferredValue:function(e,t){var n=Ue();return be===null?_f(n,e,t):tv(n,be.memoizedState,e,t)},useTransition:function(){var e=Ou(ao)[0],t=Ue().memoizedState;return[typeof e=="boolean"?e:tl(e),t]},useSyncExternalStore:Bh,useId:iv,useHostTransitionStatus:Hf,useFormState:_g,useActionState:_g,useOptimistic:function(e,t){var n=Ue();return be!==null?Vh(n,be,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:zf,useCacheRefresh:rv,useEffectEvent:Ph};function Ru(e,t,n,o){t=e.memoizedState,n=n(o,t),n=n==null?t:ve({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var kd={enqueueSetState:function(e,t,n){e=e._reactInternals;var o=Pt(),a=Ro(o);a.payload=t,n!=null&&(a.callback=n),t=Do(e,a,o),t!==null&&(Rt(t,e,o),Sr(t,e,o))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var o=Pt(),a=Ro(o);a.tag=1,a.payload=t,n!=null&&(a.callback=n),t=Do(e,a,o),t!==null&&(Rt(t,e,o),Sr(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Pt(),o=Ro(n);o.tag=2,t!=null&&(o.callback=t),t=Do(e,o,n),t!==null&&(Rt(t,e,n),Sr(t,e,n))}};function Bg(e,t,n,o,a,i,r){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,i,r):t.prototype&&t.prototype.isPureReactComponent?!Hr(n,o)||!Hr(a,i):!0}function Lg(e,t,n,o){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,o),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,o),t.state!==e&&kd.enqueueReplaceState(t,t.state,null)}function wa(e,t){var n=t;if("ref"in t){n={};for(var o in t)o!=="ref"&&(n[o]=t[o])}if(e=e.defaultProps){n===t&&(n=ve({},n));for(var a in e)n[a]===void 0&&(n[a]=e[a])}return n}function fv(e){Cc(e)}function pv(e){console.error(e)}function mv(e){Cc(e)}function Lc(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(o){setTimeout(function(){throw o})}}function Ug(e,t,n){try{var o=e.onCaughtError;o(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(a){setTimeout(function(){throw a})}}function Sd(e,t,n){return n=Ro(n),n.tag=3,n.payload={element:null},n.callback=function(){Lc(e,t)},n}function gv(e){return e=Ro(e),e.tag=3,e}function bv(e,t,n,o){var a=n.type.getDerivedStateFromError;if(typeof a=="function"){var i=o.value;e.payload=function(){return a(i)},e.callback=function(){Ug(t,n,o)}}var r=n.stateNode;r!==null&&typeof r.componentDidCatch=="function"&&(e.callback=function(){Ug(t,n,o),typeof a!="function"&&(Bo===null?Bo=new Set([this]):Bo.add(this));var l=o.stack;this.componentDidCatch(o.value,{componentStack:l!==null?l:""})})}function nS(e,t,n,o,a){if(n.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(t=n.alternate,t!==null&&ba(t,n,a,!0),n=ut.current,n!==null){switch(n.tag){case 31:case 13:case 19:return ht===null?Gc():n.alternate===null&&Be===0&&(Be=3),n.flags&=-257,n.flags|=65536,n.lanes=a,o===Oc?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([o]):t.add(o),ju(e,o,a)),!1;case 22:return n.flags|=65536,o===Oc?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([o])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([o]):n.add(o)),ju(e,o,a)),!1}throw Error(N(435,n.tag))}return ju(e,o,a),Gc(),!1}if(F)return t=ut.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=a,o!==dd&&(e=Error(N(422),{cause:o}),Lr(ln(e,n)))):(o!==dd&&(t=Error(N(423),{cause:o}),Lr(ln(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,o=ln(o,n),a=Sd(e.stateNode,o,a),zu(e,a),Be!==4&&(Be=2)),!1;var i=Error(N(520),{cause:o});if(i=ln(i,n),zr===null?zr=[i]:zr.push(i),Be!==4&&(Be=2),t===null)return!0;o=ln(o,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=Sd(n.stateNode,o,e),zu(n,e),!1;case 1:if(t=n.type,i=n.stateNode,(n.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||i!==null&&typeof i.componentDidCatch=="function"&&(Bo===null||!Bo.has(i))))return n.flags|=65536,a&=-a,n.lanes|=a,a=gv(a),bv(a,e,n,o),zu(n,a),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var Lf=Error(N(461)),Ke=!1;function Ze(e,t,n,o){t.child=e===null?zh(t,null,n,o):ya(t,e.child,n,o)}function jg(e,t,n,o,a){n=n.render;var i=t.ref;if("ref"in o){var r={};for(var l in o)l!=="ref"&&(r[l]=o[l])}else r=o;return ha(t),o=Cf(e,t,n,r,i,a),l=Nf(),e!==null&&!Ke?(Mf(e,t,a),io(e,t,a)):(F&&l&&os(t),t.flags|=1,Ze(e,t,o,a),t.child)}function qg(e,t,n,o,a){if(e===null){var i=n.type;return typeof i=="function"&&!hf(i)&&i.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=i,hv(e,t,i,o,a)):(e=rc(n.type,null,o,t,t.mode,a),e.ref=t.ref,e.return=t,t.child=e)}if(i=e.child,!jf(e,a)){var r=i.memoizedProps;if(n=n.compare,n=n!==null?n:Hr,n(r,o)&&e.ref===t.ref)return io(e,t,a)}return t.flags|=1,e=Wn(i,o),e.ref=t.ref,e.return=t,t.child=e}function hv(e,t,n,o,a){if(e!==null){var i=e.memoizedProps;if(Hr(i,o)&&e.ref===t.ref)if(Ke=!1,t.pendingProps=o=i,jf(e,a))(e.flags&131072)!==0&&(Ke=!0);else return t.lanes=e.lanes,io(e,t,a)}return Ed(e,t,n,o,a)}function vv(e,t,n,o){var a=o.children,i=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((t.flags&128)!==0){if(i=i!==null?i.baseLanes|n:n,e!==null){for(o=t.child=e.child,a=0;o!==null;)a=a|o.lanes|o.childLanes,o=o.sibling;o=a&~i}else o=0,t.child=null;return Yg(e,t,i,n,o)}if((n&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&cc(t,i!==null?i.cachePool:null),i!==null?Ag(t,i):hd(),Dh(t);else return o=t.lanes=536870912,Yg(e,t,i!==null?i.baseLanes|n:n,n,o)}else i!==null?(cc(t,i.cachePool),Ag(t,i),Ho(),t.memoizedState=null):(e!==null&&cc(t,null),hd(),Ho());return Ze(e,t,a,n),t.child}function Nr(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Yg(e,t,n,o,a){var i=xf();return i=i===null?null:{parent:Ve._currentValue,pool:i},t.memoizedState={baseLanes:n,cachePool:i},e!==null&&cc(t,null),hd(),Dh(t),e!==null&&ba(e,t,o,!0),t.childLanes=a,null}function dc(e,t){return t=ss({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Vg(e,t,n){return ya(t,e.child,null,n),e=dc(t,t.pendingProps),e.flags|=2,Vt(t),t.memoizedState=null,e}function oS(e,t,n){var o=t.pendingProps,a=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(F){if(o.mode==="hidden")return e=dc(t,o),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},Nr(null,e);if(vd(t),(e=ke)?(e=v0(e,cn),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:qo!==null?{id:Dn,overflow:_n}:null,retryLane:536870912,hydrationErrors:null},n=Sh(e),n.return=t,t.child=n,tt=t,ke=null)):e=null,e===null)throw Yo(t);return t.lanes=536870912,null}return dc(t,o)}var i=e.memoizedState;if(i!==null){var r=i.dehydrated;if(vd(t),a)if(t.flags&256)t.flags&=-257,t=Vg(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(N(558));else if(Ke||ba(e,t,n,!1),a=(n&e.childLanes)!==0,Ke||a){if(Vo.current===null){if(o=he,o!==null&&(r=Pb(o,n),r!==0&&r!==i.retryLane))throw i.retryLane=r,Ca(e,r),Rt(o,e,r),Lf;Gc()}t=Vg(e,t,n)}else e=i.treeContext,ke=sn(r.nextSibling),tt=t,F=!0,Oo=null,cn=!1,e!==null&&Th(t,e),t=dc(t,o),t.flags|=134221824;return t}return e=Wn(e.child,{mode:o.mode,children:o.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Ja(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!="function"&&typeof n!="object")throw Error(N(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function Ed(e,t,n,o,a){return ha(t),n=Cf(e,t,n,o,void 0,a),o=Nf(),e!==null&&!Ke?(Mf(e,t,a),io(e,t,a)):(F&&o&&os(t),t.flags|=1,Ze(e,t,n,a),t.child)}function Kg(e,t,n,o,a,i){return ha(t),t.updateQueue=null,n=Hh(t,o,n,a),_h(e),o=Nf(),e!==null&&!Ke?(Mf(e,t,i),io(e,t,i)):(F&&o&&os(t),t.flags|=1,Ze(e,t,n,i),t.child)}function Xg(e,t,n,o,a){if(ha(t),t.stateNode===null){var i=li,r=n.contextType;typeof r=="object"&&r!==null&&(i=rt(r)),i=new n(o,i),t.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=kd,t.stateNode=i,i._reactInternals=t,i=t.stateNode,i.props=o,i.state=t.memoizedState,i.refs={},kf(t),r=n.contextType,i.context=typeof r=="object"&&r!==null?rt(r):li,i.state=t.memoizedState,r=n.getDerivedStateFromProps,typeof r=="function"&&(Ru(t,n,r,o),i.state=t.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof i.getSnapshotBeforeUpdate=="function"||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(r=i.state,typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount(),r!==i.state&&kd.enqueueReplaceState(i,i.state,null),Tr(t,o,i,a),Er(),i.state=t.memoizedState),typeof i.componentDidMount=="function"&&(t.flags|=4194308),o=!0}else if(e===null){i=t.stateNode;var l=t.memoizedProps,c=wa(n,l);i.props=c;var s=i.context,f=n.contextType;r=li,typeof f=="object"&&f!==null&&(r=rt(f));var m=n.getDerivedStateFromProps;f=typeof m=="function"||typeof i.getSnapshotBeforeUpdate=="function",l=t.pendingProps!==l,f||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(l||s!==r)&&Lg(t,i,o,r),ko=!1;var u=t.memoizedState;i.state=u,Tr(t,o,i,a),Er(),s=t.memoizedState,l||u!==s||ko?(typeof m=="function"&&(Ru(t,n,m,o),s=t.memoizedState),(c=ko||Bg(t,n,c,o,u,s,r))?(f||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount()),typeof i.componentDidMount=="function"&&(t.flags|=4194308)):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=o,t.memoizedState=s),i.props=o,i.state=s,i.context=r,o=c):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),o=!1)}else{i=t.stateNode,gd(e,t),r=t.memoizedProps,f=wa(n,r),i.props=f,m=t.pendingProps,u=i.context,s=n.contextType,c=li,typeof s=="object"&&s!==null&&(c=rt(s)),l=n.getDerivedStateFromProps,(s=typeof l=="function"||typeof i.getSnapshotBeforeUpdate=="function")||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(r!==m||u!==c)&&Lg(t,i,o,c),ko=!1,u=t.memoizedState,i.state=u,Tr(t,o,i,a),Er();var d=t.memoizedState;r!==m||u!==d||ko||e!==null&&e.dependencies!==null&&zc(e.dependencies)?(typeof l=="function"&&(Ru(t,n,l,o),d=t.memoizedState),(f=ko||Bg(t,n,f,o,u,d,c)||e!==null&&e.dependencies!==null&&zc(e.dependencies))?(s||typeof i.UNSAFE_componentWillUpdate!="function"&&typeof i.componentWillUpdate!="function"||(typeof i.componentWillUpdate=="function"&&i.componentWillUpdate(o,d,c),typeof i.UNSAFE_componentWillUpdate=="function"&&i.UNSAFE_componentWillUpdate(o,d,c)),typeof i.componentDidUpdate=="function"&&(t.flags|=4),typeof i.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof i.componentDidUpdate!="function"||r===e.memoizedProps&&u===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||r===e.memoizedProps&&u===e.memoizedState||(t.flags|=1024),t.memoizedProps=o,t.memoizedState=d),i.props=o,i.state=d,i.context=c,o=f):(typeof i.componentDidUpdate!="function"||r===e.memoizedProps&&u===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||r===e.memoizedProps&&u===e.memoizedState||(t.flags|=1024),o=!1)}return i=o,Ja(e,t),o=(t.flags&128)!==0,i||o?(i=t.stateNode,n=o&&typeof n.getDerivedStateFromError!="function"?null:i.render(),t.flags|=1,e!==null&&o?(t.child=ya(t,e.child,null,a),t.child=ya(t,null,n,a)):Ze(e,t,n,a),t.memoizedState=i.state,e=t.child):e=io(e,t,a),e}function Gg(e,t,n,o){return ga(),t.flags|=256,Ze(e,t,n,o),t.child}var Td={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Cd(e){return{baseLanes:e,cachePool:Nh()}}function Nd(e,t,n){return e=e!==null?e.childLanes&~n:0,t&&(e|=Xt),e}function yv(e,t,n){var o=t.pendingProps,a=!1,i=(t.flags&128)!==0,r;if((r=i)||(r=e!==null&&e.memoizedState===null?!1:(ct.current&2)!==0),r&&(a=!0,t.flags&=-129),r=(t.flags&32)!==0,t.flags&=-33,e===null){if(F){if(a?_o(t):Ho(),(e=ke)?(e=v0(e,cn),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:qo!==null?{id:Dn,overflow:_n}:null,retryLane:536870912,hydrationErrors:null},n=Sh(e),n.return=t,t.child=n,tt=t,ke=null)):e=null,e===null)throw Yo(t);return If(e)?t.lanes=32:t.lanes=536870912,null}return i=o.children,o=o.fallback,a?(Ho(),a=t.mode,i=ss({mode:"hidden",children:i},a),o=da(o,a,n,null),i.return=t,o.return=t,i.sibling=o,t.child=i,o=t.child,o.memoizedState=Cd(n),o.childLanes=Nd(e,r,n),t.memoizedState=Td,Nr(null,o)):(_o(t),Uf(t,i))}var l=e.memoizedState;if(l!==null){var c=l.dehydrated;if(c!==null)return aS(e,t,i,r,o,c,l,n)}return a?(Ho(),a=o.fallback,i=t.mode,l=e.child,c=l.sibling,o=Wn(l,{mode:"hidden",children:o.children}),o.subtreeFlags=l.subtreeFlags&1206910976,c!==null?a=Wn(c,a):(a=da(a,i,n,null),a.flags|=2),a.return=t,o.return=t,o.sibling=a,t.child=o,Nr(null,o),o=t.child,a=e.child.memoizedState,a===null?a=Cd(n):(i=a.cachePool,i!==null?(l=Ve._currentValue,i=i.parent!==l?{parent:l,pool:l}:i):i=Nh(),a={baseLanes:a.baseLanes|n,cachePool:i}),o.memoizedState=a,o.childLanes=Nd(e,r,n),t.memoizedState=Td,Nr(e.child,o)):(_o(t),n=e.child,e=n.sibling,n=Wn(n,{mode:"visible",children:o.children}),n.return=t,n.sibling=null,e!==null&&(r=t.deletions,r===null?(t.deletions=[e],t.flags|=16):r.push(e)),t.child=n,t.memoizedState=null,n)}function Uf(e,t){return t=ss({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function ss(e,t){return e=Ot(22,e,null,t),e.lanes=0,e}function Ql(e,t,n){return ya(t,e.child,null,n),e=Uf(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function aS(e,t,n,o,a,i,r,l){if(n)return t.flags&256?(_o(t),t.flags&=-257,Ql(e,t,l)):t.memoizedState!==null?(Ho(),t.child=e.child,t.flags|=128,null):(Ho(),i=a.fallback,r=t.mode,a=ss({mode:"visible",children:a.children},r),i=da(i,r,l,null),i.flags|=2,a.return=t,i.return=t,a.sibling=i,t.child=a,ya(t,e.child,null,l),a=t.child,a.memoizedState=Cd(l),a.childLanes=Nd(e,o,l),t.memoizedState=Td,Nr(null,a));if(_o(t),If(i)){if(o=i.nextSibling&&i.nextSibling.dataset,o)var c=o.dgst;return o=c,o!==""&&(a=Error(N(419)),a.stack="",a.digest=o,Lr({value:a,source:null,stack:null})),Ql(e,t,l)}if(Ke||ba(e,t,l,!1),o=(l&e.childLanes)!==0,Ke||o){if(Vo.current!==null)return Ql(e,t,l);if(o=he,o!==null&&(a=Pb(o,l),a!==0&&a!==r.retryLane))throw r.retryLane=a,Ca(e,a),Rt(o,e,a),Lf;return Fd(i)||Gc(),Ql(e,t,l)}return Fd(i)?(t.flags|=192,t.child=e.child,null):(e=r.treeContext,ke=sn(i.nextSibling),tt=t,F=!0,Oo=null,cn=!1,e!==null&&Th(t,e),t=Uf(t,a.children),t.flags|=134221824,t)}function Qg(e,t,n){e.lanes|=t;var o=e.alternate;o!==null&&(o.lanes|=t),lc(e.return,t,n)}function Zg(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&Dc(n)===null&&(t=e),e=e.sibling}return t}function Zl(e,t,n,o,a,i){var r=e.memoizedState;r===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:o,tail:n,tailMode:a,treeForkCount:i}:(r.isBackwards=t,r.rendering=null,r.renderingStartTime=0,r.last=o,r.tail=n,r.tailMode=a,r.treeForkCount=i)}function Du(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function Md(e,t,n){var o=t.pendingProps,a=o.revealOrder,i=o.tail;o=o.children;var r=ct.current;if(t.flags&128)return jr(t,r),null;var l=(r&2)!==0;if(l?(r=r&1|2,t.flags|=128):r&=1,jr(t,r),a==="backwards"&&e!==null?(Du(e),Ze(e,t,o,n),Du(e)):Ze(e,t,o,n),o=F?Br:0,!l&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Qg(e,n,t);else if(e.tag===19)Qg(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(a){case"backwards":n=Zg(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null,Du(t)),Zl(t,!0,a,null,i,o);break;case"unstable_legacy-backwards":for(n=null,a=t.child,t.child=null;a!==null;){if(e=a.alternate,e!==null&&Dc(e)===null){t.child=a;break}e=a.sibling,a.sibling=n,n=a,a=e}Zl(t,!0,n,null,i,o);break;case"together":Zl(t,!1,null,null,void 0,o);break;case"independent":t.memoizedState=null;break;default:n=Zg(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null),Zl(t,!1,a,n,i,o)}return t.child}function Pg(e,t,n){var o=t.pendingProps;return Co(t,t.type,o.value),Ze(e,t,o.children,n),t.child}function io(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Xo|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(ba(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(N(153));if(t.child!==null){for(e=t.child,n=Wn(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Wn(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function jf(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&zc(e)))}function iS(e,t,n){switch(t.tag){case 3:kc(t,t.stateNode.containerInfo),Co(t,Ve,e.memoizedState.cache),ga();break;case 27:case 5:td(t);break;case 4:kc(t,t.stateNode.containerInfo);break;case 10:Co(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,vd(t),null;break;case 13:var o=t.memoizedState;if(o!==null){if(o.dehydrated!==null)return _o(t),t.flags|=128,null;o=ba(e,t,n,!1);var a=t.child.childLanes;return o||(n&a)!==0?yv(e,t,n):(_o(t),e=io(e,t,n),e!==null?e.sibling:null)}_o(t);break;case 19:if(t.flags&128)return Md(e,t,n);if(a=(e.flags&128)!==0,o=(n&t.childLanes)!==0,o||(ba(e,t,n,!1),o=(n&t.childLanes)!==0),a){if(o)return Md(e,t,n);t.flags|=128}if(a=t.memoizedState,a!==null&&(a.rendering=null,a.tail=null,a.lastEffect=null),jr(t,ct.current),o)break;return null;case 22:return t.lanes=0,vv(e,t,n,t.pendingProps);case 24:Co(t,Ve,e.memoizedState.cache)}return io(e,t,n)}function xv(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)Ke=!0;else{if(!jf(e,n)&&(t.flags&128)===0)return Ke=!1,iS(e,t,n);Ke=(e.flags&131072)!==0}else Ke=!1,F&&(t.flags&1048576)!==0&&Eh(t,Br,t.index);switch(t.lanes=0,t.tag){case 16:e:{var o=t.pendingProps;if(e=ra(t.elementType),t.type=e,typeof e=="function")hf(e)?(o=wa(e,o),t.tag=1,t=Xg(null,t,e,o,n)):(t.tag=0,t=Ed(null,t,e,o,n));else{if(e!=null){var a=e.$$typeof;if(a===of){t.tag=11,t=jg(null,t,e,o,n);break e}else if(a===af){t.tag=14,t=qg(null,t,e,o,n);break e}else if(a===On){t.tag=10,t.type=e,t=Pg(null,t,n);break e}}throw t=Wu(e)||e,Error(N(306,t,""))}}return t;case 0:return Ed(e,t,t.type,t.pendingProps,n);case 1:return o=t.type,a=wa(o,t.pendingProps),Xg(e,t,o,a,n);case 3:e:{if(kc(t,t.stateNode.containerInfo),e===null)throw Error(N(387));o=t.pendingProps;var i=t.memoizedState;a=i.element,gd(e,t),Tr(t,o,null,n);var r=t.memoizedState;if(o=r.cache,Co(t,Ve,o),o!==i.cache&&pd(t,[Ve],n,!0),Er(),o=r.element,i.isDehydrated)if(i={element:o,isDehydrated:!1,cache:r.cache},t.updateQueue.baseState=i,t.memoizedState=i,t.flags&256){t=Gg(e,t,o,n);break e}else if(o!==a){a=ln(Error(N(424)),t),Lr(a),t=Gg(e,t,o,n);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,ke=sn(e.firstChild),tt=t,F=!0,Oo=null,cn=!0,n=zh(t,null,o,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling;else{if(ga(),o===a){t=io(e,t,n);break e}Ze(e,t,o,n)}t=t.child}return t;case 26:return Ja(e,t),e===null?(n=wb(t.type,null,t.pendingProps,null))?t.memoizedState=n:F||(t.stateNode=s0(t.type,t.pendingProps,zo.current,t)):t.memoizedState=wb(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return td(t),e===null&&F&&(o=t.stateNode=y0(t.type,t.pendingProps,zo.current),tt=t,cn=!0,a=ke,Qo(t.type)?(Wd=a,ke=sn(o.firstChild)):ke=a),Ze(e,t,t.pendingProps.children,n),Ja(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&F&&((a=o=ke)&&(o=IS(o,t.type,t.pendingProps,cn),o!==null?(t.stateNode=o,tt=t,ke=sn(o.firstChild),cn=!1,a=!0):a=!1),a||Yo(t)),td(t),a=t.type,i=t.pendingProps,r=e!==null?e.memoizedProps:null,o=i.children,$d(a,i)?o=null:r!==null&&$d(a,r)&&(t.flags|=32),t.memoizedState!==null&&(a=Cf(e,t,Pk,null,null,n),Oi._currentValue=a),Ja(e,t),Ze(e,t,o,n),t.child;case 6:return e===null&&F&&((e=n=ke)&&(n=FS(n,t.pendingProps,cn),n!==null?(t.stateNode=n,tt=t,ke=null,e=!0):e=!1),e||Yo(t)),null;case 13:return yv(e,t,n);case 4:return kc(t,t.stateNode.containerInfo),o=t.pendingProps,e===null?t.child=ya(t,null,o,n):Ze(e,t,o,n),t.child;case 11:return jg(e,t,t.type,t.pendingProps,n);case 7:return o=t.pendingProps,Ja(e,t),Ze(e,t,o,n),t.child;case 8:return Ze(e,t,t.pendingProps.children,n),t.child;case 12:return Ze(e,t,t.pendingProps.children,n),t.child;case 10:return Pg(e,t,n);case 9:return a=t.type._context,o=t.pendingProps.children,ha(t),a=rt(a),o=o(a),t.flags|=1,Ze(e,t,o,n),t.child;case 14:return qg(e,t,t.type,t.pendingProps,n);case 15:return hv(e,t,t.type,t.pendingProps,n);case 19:return Md(e,t,n);case 31:return oS(e,t,n);case 22:return vv(e,t,n,t.pendingProps);case 24:return ha(t),o=rt(Ve),e===null?(a=xf(),a===null&&(a=he,i=yf(),a.pooledCache=i,i.refCount++,i!==null&&(a.pooledCacheLanes|=n),a=i),t.memoizedState={parent:o,cache:a},kf(t),Co(t,Ve,a)):((e.lanes&n)!==0&&(gd(e,t),Tr(t,null,null,n),Er()),a=e.memoizedState,i=t.memoizedState,a.parent!==o?(a={parent:o,cache:o},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),Co(t,Ve,o)):(o=i.cache,Co(t,Ve,o),o!==a.cache&&pd(t,[Ve],n,!0))),Ze(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),o=t.pendingProps,o.name!=null&&o.name!=="auto"?t.flags|=e===null?18882560:18874368:F&&os(t),e!==null&&e.memoizedProps.name!==o.name?t.flags|=4194816:Ja(e,t),Ze(e,t,o.children,n),t.child;case 29:throw t.pendingProps}throw Error(N(156,t.tag))}function Jn(e){e.flags|=4}function _u(e,t,n,o,a){var i;if((i=(e.mode&32)!==0)&&(i=n===null?Eb(t,o):Eb(t,o)&&(o.src!==n.src||o.srcSet!==n.srcSet)),i){if(e.flags|=16777216,(a&335544128)===a)if(e.stateNode.complete)e.flags|=8192;else if($v())e.flags|=8192;else throw pa=Oc,wf}else e.flags&=-16777217}function $g(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!S0(t))if($v())e.flags|=8192;else throw pa=Oc,wf}function Pl(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?Gb():536870912,e.lanes|=t,Ti|=t)}function ur(e,t){if(!F)switch(e.tailMode){case"visible":break;case"collapsed":for(var n=e.tail,o=null;n!==null;)n.alternate!==null&&(o=n),n=n.sibling;o===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function we(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,o=0;if(t)for(var a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags&1206910976,o|=a.flags&1206910976,a.return=e,a=a.sibling;else for(a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags,o|=a.flags,a.return=e,a=a.sibling;return e.subtreeFlags|=o,e.childLanes=n,t}function rS(e,t,n){var o=t.pendingProps;switch(vf(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return we(t),null;case 1:return we(t),null;case 3:return n=t.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),t.memoizedState.cache!==o&&(t.flags|=2048),eo(Ve),wi(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(Pa(t)?Jn(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,Au())),we(t),null;case 26:var a=t.type,i=t.memoizedState;return e===null?(Jn(t),i!==null?(we(t),$g(t,i)):(we(t),_u(t,a,null,o,n))):i?i!==e.memoizedState?(Jn(t),we(t),$g(t,i)):(we(t),t.flags&=-16777217):(e=e.memoizedProps,e!==o&&Jn(t),we(t),_u(t,a,e,o,n)),null;case 27:if(Sc(t),n=zo.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&Jn(t);else{if(!o){if(t.stateNode===null)throw Error(N(166));return we(t),t.subtreeFlags&=-33554433,null}e=Hn.current,Pa(t)?kg(t,e):(e=y0(a,o,n),t.stateNode=e,Jn(t))}return we(t),t.subtreeFlags&=-33554433,null;case 5:if(Sc(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&Jn(t);else{if(!o){if(t.stateNode===null)throw Error(N(166));return we(t),t.subtreeFlags&=-33554433,null}if(i=Hn.current,Pa(t))kg(t,i);else{var r=Kr(zo.current);switch(i){case 1:i=r.createElementNS("http://www.w3.org/2000/svg",a);break;case 2:i=r.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;default:switch(a){case"svg":i=r.createElementNS("http://www.w3.org/2000/svg",a);break;case"math":i=r.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;case"script":i=r.createElement("div"),i.innerHTML="<script><\/script>",i=i.removeChild(i.firstChild);break;case"select":i=typeof o.is=="string"?r.createElement("select",{is:o.is}):r.createElement("select"),o.multiple?i.multiple=!0:o.size&&(i.size=o.size);break;default:i=typeof o.is=="string"?r.createElement(a,{is:o.is}):r.createElement(a)}}i[it]=t,i[_t]=o;e:for(r=t.child;r!==null;){if(r.tag===5||r.tag===6)i.appendChild(r.stateNode);else if(r.tag!==4&&r.tag!==27&&r.child!==null){r.child.return=r,r=r.child;continue}if(r===t)break e;for(;r.sibling===null;){if(r.return===null||r.return===t)break e;r=r.return}r.sibling.return=r.return,r=r.sibling}t.stateNode=i;e:switch(st(i,a,o),a){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&Jn(t)}}return we(t),t.subtreeFlags&=-33554433,_u(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==o&&Jn(t);else{if(typeof o!="string"&&t.stateNode===null)throw Error(N(166));if(e=zo.current,Pa(t)){if(e=t.stateNode,n=t.memoizedProps,o=null,a=tt,a!==null)switch(a.tag){case 27:case 5:o=a.memoizedProps}e[it]=t,e=!!(e.nodeValue===n||o!==null&&o.suppressHydrationWarning===!0||l0(e.nodeValue,n)),e||Yo(t,!0)}else e=Kr(e).createTextNode(o),e[it]=t,t.stateNode=e}return we(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(o=Pa(t),n!==null){if(e===null){if(!o)throw Error(N(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(N(557));e[it]=t}else ga(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;we(t),e=!1}else n=Au(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(Vt(t),t):(Vt(t),null);if((t.flags&128)!==0)throw Error(N(558))}return we(t),null;case 13:if(o=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=Pa(t),o!==null&&o.dehydrated!==null){if(e===null){if(!a)throw Error(N(318));if(a=t.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(N(317));a[it]=t}else ga(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;we(t),a=!1}else a=Au(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(Vt(t),t):(Vt(t),null)}return Vt(t),(t.flags&128)!==0?(t.lanes=n,t):(n=o!==null,e=e!==null&&e.memoizedState!==null,n&&(o=t.child,a=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(a=o.alternate.memoizedState.cachePool.pool),i=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(i=o.memoizedState.cachePool.pool),i!==a&&(o.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),Pl(t,t.updateQueue),we(t),null);case 4:return wi(),e===null&&Pf(t.stateNode.containerInfo),t.flags|=67108864,we(t),null;case 10:return eo(t.type),we(t),null;case 19:if(Ef(t),o=t.memoizedState,o===null)return we(t),null;if(a=(t.flags&128)!==0,i=o.rendering,i===null)if(a)ur(o,!1);else{if(Be!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(i=Dc(e),i!==null){for(t.flags|=128,ur(o,!1),e=i.updateQueue,t.updateQueue=e,Pl(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)kh(n,e),n=n.sibling;return jr(t,ct.current&1|2),F&&In(t,o.treeForkCount),t.child}e=e.sibling}o.tail!==null&&Gt()>Kc&&(t.flags|=128,a=!0,ur(o,!1),t.lanes=4194304)}else{if(!a)if(e=Dc(i),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,Pl(t,e),ur(o,!0),o.tail===null&&o.tailMode!=="collapsed"&&o.tailMode!=="visible"&&!i.alternate&&!F)return we(t),null}else 2*Gt()-o.renderingStartTime>Kc&&n!==536870912&&(t.flags|=128,a=!0,ur(o,!1),t.lanes=4194304);o.isBackwards?(i.sibling=t.child,t.child=i):(e=o.last,e!==null?e.sibling=i:t.child=i,o.last=i)}if(o.tail!==null){e=o.tail;e:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break e}n=n.sibling}n=!0}return o.rendering=e,o.tail=e.sibling,o.renderingStartTime=Gt(),e.sibling=null,i=ct.current,i=a?i&1|2:i&1,o.tailMode==="visible"||o.tailMode==="collapsed"||!n||F?jr(t,i):(n=i,Se(ut,t),Se(ct,n),ht===null&&(ht=t)),F&&In(t,o.treeForkCount),e}return we(t),null;case 22:case 23:return Vt(t),Sf(),o=t.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(t.flags|=8192):o&&(t.flags|=8192),o?(n&536870912)!==0&&(t.flags&128)===0&&(we(t),t.subtreeFlags&6&&(t.flags|=8192)):we(t),n=t.updateQueue,n!==null&&Pl(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),o=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),o!==n&&(t.flags|=2048),e!==null&&lt(fa),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),eo(Ve),we(t),null;case 25:return null;case 30:return t.flags|=33554432,we(t),null}throw Error(N(156,t.tag))}function lS(e,t){switch(vf(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return eo(Ve),wi(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return Sc(t),null;case 31:if(t.memoizedState!==null){if(Vt(t),t.alternate===null)throw Error(N(340));ga()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(Vt(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(N(340));ga()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return Ef(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return wi(),null;case 10:return eo(t.type),null;case 22:case 23:return Vt(t),Sf(),e!==null&&lt(fa),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return eo(Ve),null;case 25:return null;default:return null}}function wv(e,t){switch(vf(t),t.tag){case 3:eo(Ve),wi();break;case 26:case 27:case 5:Sc(t);break;case 4:wi();break;case 31:t.memoizedState!==null&&Vt(t);break;case 13:Vt(t);break;case 19:Ef(t);break;case 10:eo(t.type);break;case 22:case 23:Vt(t),Sf(),e!==null&&lt(fa);break;case 24:eo(Ve)}}function nl(e,t){try{var n=t.updateQueue,o=n!==null?n.lastEffect:null;if(o!==null){var a=o.next;n=a;do{if((n.tag&e)===e){o=void 0;var i=n.create,r=n.inst;o=i(),r.destroy=o}n=n.next}while(n!==a)}}catch(l){ge(t,t.return,l)}}function Ko(e,t,n){try{var o=t.updateQueue,a=o!==null?o.lastEffect:null;if(a!==null){var i=a.next;o=i;do{if((o.tag&e)===e){var r=o.inst,l=r.destroy;if(l!==void 0){r.destroy=void 0,a=t;var c=n,s=l;try{s()}catch(f){ge(a,c,f)}}}o=o.next}while(o!==i)}}catch(f){ge(t,t.return,f)}}function kv(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{Rh(t,n)}catch(o){ge(e,e.return,o)}}}function Sv(e,t,n){n.props=wa(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(o){ge(e,t,o)}}function An(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:var a=e.stateNode,i=no(e.memoizedProps,a);(a.ref===null||a.ref.name!==i)&&(a.ref=p0(i)),o=a.ref;break;case 7:if(e.stateNode===null){var r=new Jt(e);Dt(e.child,!1,$S,r,void 0,void 0),e.stateNode=r}o=e.stateNode;break;default:o=e.stateNode}typeof n=="function"?e.refCleanup=n(o):n.current=o}}catch(l){ge(e,t,l)}}function at(e,t){var n=e.ref,o=e.refCleanup;if(n!==null)if(typeof o=="function")try{o()}catch(a){ge(e,t,a)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n=="function")try{n(null)}catch(a){ge(e,t,a)}else n.current=null}function Uc(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)h0(e.stateNode,t[n])}function Jg(e){for(var t=e.return;t!==null&&(Yf(t)&&h0(e.stateNode,t.stateNode),!qf(t));)t=t.return}function Mr(e){for(var t=e.return;t!==null&&(Yf(t)&&JS(e.stateNode,t.stateNode),!qf(t));)t=t.return}function qf(e){return e.tag===5||e.tag===3||e.tag===27}function Yf(e){return e&&e.tag===7&&e.stateNode!==null}function Ad(e){var t=e.type,n=e.memoizedProps,o=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&o.focus();break e;case"img":n.src?o.src=n.src:n.srcSet&&(o.srcset=n.srcSet)}}catch(a){ge(e,e.return,a)}}function Hu(e,t,n){try{var o=e.stateNode;OS(o,e.type,n,t),o[_t]=t}catch(a){ge(e,e.return,a)}}function Ev(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Qo(e.type)||e.tag===4}function Bu(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Ev(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Qo(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function zd(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n).insertBefore(a,t):(t=n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.appendChild(a),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=Rn)),Uc(e,o),re=!0;else if(a!==4&&(a===27&&(Uc(e,o),o=null,Qo(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(zd(e,t,n,o),e=e.sibling;e!==null;)zd(e,t,n,o),e=e.sibling}function jc(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?n.insertBefore(a,t):n.appendChild(a),Uc(e,o),re=!0;else if(a!==4&&(a===27&&(Uc(e,o),o=null,Qo(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(jc(e,t,n,o),e=e.sibling;e!==null;)jc(e,t,n,o),e=e.sibling}function Tv(e){var t=e.stateNode,n=e.memoizedProps;try{for(var o=e.type,a=t.attributes;a.length;)t.removeAttributeNode(a[0]);st(t,o,n),t[it]=e,t[_t]=n}catch(i){ge(e,e.return,i)}}var qc=!1,Kt=null;function Ig(e){(e.tag===30||(e.subtreeFlags&33554432)!==0)&&(qc=!0)}var zn=null;function Fg(){var e=zn;return zn=null,e}var zt=0;function Li(e,t,n,o,a){return zt=0,Cv(e.child,t,n,o,a)}function Cv(e,t,n,o,a){for(var i=!1;e!==null;){if(e.tag===5){var r=e.stateNode;if(o!==null){var l=Jd(r);o.push(l),l.view&&(i=!0)}else i||Jd(r).view&&(i=!0);qc=!0,u0(r,zt===0?t:t+"_"+zt,n),zt++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&a||Cv(e.child,t,n,o,a)&&(i=!0));e=e.sibling}return i}function Ln(e,t){for(;e!==null;)e.tag===5?d0(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||Ln(e.child,t)),e=e.sibling}function fc(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(fc(e),e.tag===30&&(e.flags&18874368)!==0&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name==="auto")throw Error(N(544));var n=t.name;t=co(t.default,t.share),t!=="none"&&(Li(e,n,t,null,!1)||Ln(e.child,!1))}e=e.sibling}}function Od(e,t){if(e.tag===30){var n=e.stateNode,o=e.memoizedProps,a=no(o,n),i=co(o.default,n.paired?o.share:o.enter);i!=="none"?Li(e,a,i,null,!1)?(fc(e),n.paired||t||Ci(e,o.onEnter)):Ln(e.child,!1):fc(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Od(e,t),e=e.sibling;else fc(e)}function Rd(e){if(Kt!==null&&Kt.size!==0){var t=Kt;if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var n=e.memoizedProps,o=n.name;if(o!=null&&o!=="auto"){var a=t.get(o);if(a!==void 0){var i=co(n.default,n.share);if(i!=="none"&&(Li(e,o,i,null,!1)?(i=e.stateNode,a.paired=i,i.paired=a,Ci(e,n.onShare)):Ln(e.child,!1)),t.delete(o),t.size===0)break}}}Rd(e)}e=e.sibling}}}function Dd(e){if(e.tag===30){var t=e.memoizedProps,n=no(t,e.stateNode),o=Kt!==null?Kt.get(n):void 0,a=co(t.default,o!==void 0?t.share:t.exit);a!=="none"&&(Li(e,n,a,null,!1)?o!==void 0?(a=e.stateNode,o.paired=a,a.paired=o,Kt.delete(n),Ci(e,t.onShare)):Ci(e,t.onExit):Ln(e.child,!1)),Kt!==null&&Rd(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Dd(e),e=e.sibling;else Kt!==null&&Rd(e)}function Nv(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=no(t,e.stateNode);t=co(t.default,t.update),e.flags&=-5,t!=="none"&&Li(e,n,t,e.memoizedState=[],!1)}else(e.subtreeFlags&33554432)!==0&&Nv(e);e=e.sibling}}function _d(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var t=e.stateNode;t.paired!==null&&(t.paired=null,Ln(e.child,!1))}_d(e)}e=e.sibling}}function pc(e){if(e.tag===30)e.stateNode.paired=null,Ln(e.child,!1),_d(e);else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)pc(e),e=e.sibling;else _d(e)}function Mv(e){for(e=e.child;e!==null;)e.tag===30?Ln(e.child,!1):(e.subtreeFlags&33554432)!==0&&Mv(e),e=e.sibling}function Vf(e,t,n,o,a,i,r){for(var l=!1;t!==null;){if(t.tag===5){var c=t.stateNode;if(i!==null&&zt<i.length){var s=i[zt],f=Jd(c);(s.view||f.view)&&(l=!0);var m;if(m=(e.flags&4)===0)if(f.clip)m=!0;else{m=s.rect;var u=f.rect;m=m.y!==u.y||m.x!==u.x||m.height!==u.height||m.width!==u.width}m&&(e.flags|=4),f.abs?f=!s.abs:(s=s.rect,f=f.rect,f=s.height!==f.height||s.width!==f.width),f&&(e.flags|=32)}else e.flags|=32;(e.flags&4)!==0&&u0(c,zt===0?n:n+"_"+zt,a),l&&(e.flags&4)!==0||(zn===null&&(zn=[]),zn.push(c,zt===0?o:o+"_"+zt,t.memoizedProps)),zt++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&r?e.flags|=t.flags&32:Vf(e,t.child,n,o,a,i,r)&&(l=!0));t=t.sibling}return l}function Av(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,o=e.stateNode,a=no(n,o),i=co(n.default,n.update);if(t){o=o.clones;var r=o===null?null:o.map(LS)}else r=e.memoizedState,e.memoizedState=null;o=e;var l=e.child;zt=0,a=Vf(o,l,a,a,i,r,!1),(e.flags&4)!==0&&a&&(t||Ci(e,n.onUpdate))}else(e.subtreeFlags&33554432)!==0&&Av(e,t);e=e.sibling}}var Fe=!1,fe=!1,Cn=!1,Lu=!1,Wg=typeof WeakSet=="function"?WeakSet:Set,We=null,Nn=!1,vr=!1,Yc=!1,Hd=!1;function cS(e,t,n){if(e=e.containerInfo,Zd=Ri,e=mh(e),mf(e)){if("selectionStart"in e)var o={start:e.selectionStart,end:e.selectionEnd};else e:{o=(o=e.ownerDocument)&&o.defaultView||window;var a=o.getSelection&&o.getSelection();if(a&&a.rangeCount!==0){o=a.anchorNode;var i=a.anchorOffset,r=a.focusNode;a=a.focusOffset;try{o.nodeType,r.nodeType}catch{o=null;break e}var l=0,c=-1,s=-1,f=0,m=0,u=e,d=null;t:for(;;){for(var x;u!==o||i!==0&&u.nodeType!==3||(c=l+i),u!==r||a!==0&&u.nodeType!==3||(s=l+a),u.nodeType===3&&(l+=u.nodeValue.length),(x=u.firstChild)!==null;)d=u,u=x;for(;;){if(u===e)break t;if(d===o&&++f===i&&(c=l),d===r&&++m===a&&(s=l),(x=u.nextSibling)!==null)break;u=d,d=u.parentNode}u=x}o=c===-1||s===-1?null:{start:c,end:s}}else o=null}o=o||{start:0,end:0}}else o=null;for(Pd={focusedElem:e,selectionRange:o},Ri=!1,n=(n&335544064)===n,We=t,t=n?9270:1024;We!==null;){if(e=We,n&&(o=e.deletions,o!==null))for(i=0;i<o.length;i++)n&&Dd(o[i]);if(e.alternate===null&&(e.flags&2)!==0)n&&Ig(e),$l(n);else{if(e.tag===22){if(o=e.alternate,e.memoizedState!==null){o!==null&&o.memoizedState===null&&n&&Dd(o),$l(n);continue}else if(o!==null&&o.memoizedState!==null){n&&Ig(e),$l(n);continue}}o=e.child,(e.subtreeFlags&t)!==0&&o!==null?(o.return=e,We=o):(n&&Nv(e),$l(n))}}Kt=null}function $l(e){for(;We!==null;){var t=We,n=e,o=t.alternate,a=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if((a&1024)!==0&&o!==null){n=void 0,a=o.memoizedProps,o=o.memoizedState;var i=t.stateNode;try{var r=wa(t.type,a);n=i.getSnapshotBeforeUpdate(r,o),i.__reactInternalSnapshotBeforeUpdate=n}catch(l){ge(t,t.return,l)}}break;case 3:if((a&1024)!==0){if(o=t.stateNode.containerInfo,n=o.nodeType,n===9)Id(o);else if(n===1)switch(o.nodeName){case"HEAD":case"HTML":case"BODY":Id(o);break;default:o.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&o!==null&&(n=no(o.memoizedProps,o.stateNode),a=t.memoizedProps,a=co(a.default,a.update),a!=="none"&&Li(o,n,a,o.memoizedState=[],!0));break;default:if((a&1024)!==0)throw Error(N(163))}if(o=t.sibling,o!==null){o.return=t.return,We=o;break}We=t.return}}function zv(e,t,n){var o=n.flags;switch(n.tag){case 0:case 11:case 15:Mn(e,n),o&4&&nl(5,n);break;case 1:if(Mn(e,n),o&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(r){ge(n,n.return,r)}else{var a=wa(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(a,t,e.__reactInternalSnapshotBeforeUpdate)}catch(r){ge(n,n.return,r)}}o&64&&kv(n),o&512&&An(n,n.return);break;case 3:if(Mn(e,n),o&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{Rh(e,t)}catch(r){ge(n,n.return,r)}}break;case 27:t===null&&o&4&&Tv(n);case 26:case 5:Mn(e,n),t===null&&o&4&&Ad(n),o&512&&An(n,n.return);break;case 12:Mn(e,n);break;case 31:Mn(e,n),o&4&&_v(e,n);break;case 13:Mn(e,n),o&4&&Hv(e,n),o&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=xS.bind(null,n),WS(e,n))));break;case 22:if(o=n.memoizedState!==null||Fe,!o){var i=t!==null&&t.memoizedState!==null||fe;t=Fe,a=fe,Fe=o,(fe=i)&&!a?(o=2,(n.subtreeFlags&8772)!==0&&(o|=1),hn(e,n,o)):Mn(e,n),Fe=t,fe=a}break;case 30:Mn(e,n),o&512&&An(n,n.return);break;case 7:o&512&&An(n,n.return);default:Mn(e,n)}}function Bd(e,t){for(e=e.child;e!==null;)Ov(e,t),e=e.sibling}function Ov(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var o=n.style;typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"}else{var a=e.stateNode,i=e.memoizedProps.style,r=i!=null&&i.hasOwnProperty("display")?i.display:null;a.style.display=r==null||typeof r=="boolean"?"":(""+r).trim()}}catch(c){ge(e,e.return,c)}Ld(e,t);break;case 6:try{e.stateNode.nodeValue=t?"":e.memoizedProps,re=!0}catch(c){ge(e,e.return,c)}break;case 18:try{var l=e.stateNode;t?gb(l,!0):gb(e.stateNode,!1)}catch(c){ge(e,e.return,c)}break;case 22:case 23:e.memoizedState===null&&Bd(e,t);break;default:Bd(e,t)}}function Ld(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){e:{var n=e,o=t;switch(n.tag){case 4:Ov(n,o);break e;case 22:n.memoizedState===null&&Ld(n,o);break e;default:Ld(n,o)}}e=e.sibling}}function Rv(e){var t=e.alternate;t!==null&&(e.alternate=null,Rv(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&Ic(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var ze=null,Mt=!1;function bn(e,t,n){for(n=n.child;n!==null;)Dv(e,t,n),n=n.sibling}function Dv(e,t,n){if(Qt&&typeof Qt.onCommitFiberUnmount=="function")try{Qt.onCommitFiberUnmount($r,n)}catch{}switch(n.tag){case 26:fe||at(n,t),bn(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!fe&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:fe||at(n,t),Mr(n);var o=ze,a=Mt;Qo(n.type)&&(ze=n.stateNode,Mt=!1),bn(e,t,n),x0(n.stateNode,n.type,n.memoizedProps),ze=o,Mt=a;break;case 5:fe||at(n,t),Mr(n);case 6:if(n.tag===6&&Mr(n),o=ze,a=Mt,ze=null,bn(e,t,n),ze=o,Mt=a,ze!==null)if(Mt)try{(ze.nodeType===9?ze.body:ze.nodeName==="HTML"?ze.ownerDocument.body:ze).removeChild(n.stateNode),re=!0}catch(i){ge(n,t,i)}else try{ze.removeChild(n.stateNode),re=!0}catch(i){ge(n,t,i)}break;case 18:ze!==null&&(Mt?(e=ze,mb(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,n.stateNode),Di(e)):mb(ze,n.stateNode));break;case 4:o=ze,a=Mt,ze=n.stateNode.containerInfo,Mt=!0,bn(e,t,n),ze=o,Mt=a;break;case 0:case 11:case 14:case 15:Ko(2,n,t),fe||Ko(4,n,t),bn(e,t,n);break;case 1:fe||(at(n,t),o=n.stateNode,typeof o.componentWillUnmount=="function"&&Sv(n,t,o)),bn(e,t,n);break;case 21:bn(e,t,n);break;case 22:fe=(o=fe)||n.memoizedState!==null,bn(e,t,n),fe=o;break;case 30:at(n,t),bn(e,t,n);break;case 7:fe||at(n,t),bn(e,t,n);break;default:bn(e,t,n)}}function _v(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Di(e)}catch(n){ge(t,t.return,n)}}}function Hv(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Di(e)}catch(n){ge(t,t.return,n)}}function sS(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Wg),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Wg),t;default:throw Error(N(435,e.tag))}}function Jl(e,t){var n=sS(e);t.forEach(function(o){if(!n.has(o)){n.add(o);var a=wS.bind(null,e,o);o.then(a,a)}})}function St(e,t,n){var o=t.deletions;if(o!==null)for(var a=0;a<o.length;a++){var i=o[a],r=e,l=t,c=l;e:for(;c!==null;){switch(c.tag){case 27:if(Qo(c.type)){ze=c.stateNode,Mt=!1;break e}break;case 5:ze=c.stateNode,Mt=!1;break e;case 3:case 4:ze=c.stateNode.containerInfo,Mt=!0;break e}c=c.return}if(ze===null)throw Error(N(160));Dv(r,l,i),ze=null,Mt=!1,r=i.alternate,r!==null&&(r.return=null),i.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)Bv(t,e,n),t=t.sibling}var vn=null;function Bv(e,t,n){var o=e.alternate,a=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(a&4&&(o=e.updateQueue,o=o!==null?o.events:null,o!==null))for(var i=0;i<o.length;i++){var r=o[i];r.ref.impl=r.nextImpl}St(t,e,n),Et(e),a&4&&(Ko(3,e,e.return),nl(3,e),Ko(5,e,e.return));break;case 1:St(t,e,n),Et(e),a&512&&(fe||o===null||at(o,o.return)),a&64&&Fe&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(i=vn,St(t,e,n),Et(e),a&512&&(fe||o===null||at(o,o.return)),a&4)if(a=o!==null?o.memoizedState:null,n=e.memoizedState,o===null)if(n===null)if(e.stateNode===null)if(Fe)e.stateNode=s0(e.type,e.memoizedProps,t.containerInfo,e);else{e:{t=e.type,n=e.memoizedProps,a=i.ownerDocument||i;t:switch(t){case"title":o=a.getElementsByTagName("title")[0],(!o||o[Fr]||o[it]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=a.createElement(t),a.head.insertBefore(o,a.querySelector("head > title"))),st(o,t,n),o[it]=e,et(o),t=o;break e;case"link":if(i=Sb("link","href",a).get(t+(n.href||""))){for(r=0;r<i.length;r++)if(o=i[r],o.getAttribute("href")===(n.href==null||n.href===""?null:n.href)&&o.getAttribute("rel")===(n.rel==null?null:n.rel)&&o.getAttribute("title")===(n.title==null?null:n.title)&&o.getAttribute("crossorigin")===(n.crossOrigin==null?null:n.crossOrigin)){i.splice(r,1);break t}}o=a.createElement(t),st(o,t,n),a.head.appendChild(o);break;case"meta":if(i=Sb("meta","content",a).get(t+(n.content||""))){for(r=0;r<i.length;r++)if(o=i[r],o.getAttribute("content")===(n.content==null?null:""+n.content)&&o.getAttribute("name")===(n.name==null?null:n.name)&&o.getAttribute("property")===(n.property==null?null:n.property)&&o.getAttribute("http-equiv")===(n.httpEquiv==null?null:n.httpEquiv)&&o.getAttribute("charset")===(n.charSet==null?null:n.charSet)){i.splice(r,1);break t}}o=a.createElement(t),st(o,t,n),a.head.appendChild(o);break;default:throw Error(N(468,t))}o[it]=e,et(o),t=o}e.stateNode=t}else Fe||ef(i,e.type,e.stateNode);else e.stateNode=kb(i,n,e.memoizedProps);else a!==n?(a===null?(t=o.stateNode,t===null||fe||t.parentNode.removeChild(t)):a.count--,n===null?Fe||ef(i,e.type,e.stateNode):kb(i,n,e.memoizedProps)):n===null&&e.stateNode!==null&&Hu(e,e.memoizedProps,o.memoizedProps);break;case 27:St(t,e,n),Et(e),a&512&&(fe||o===null||at(o,o.return)),o!==null&&a&4&&Hu(e,e.memoizedProps,o.memoizedProps);break;case 5:if(i=Cn,Cn=!1,St(t,e,n),Cn=i,Et(e),a&512&&(fe||o===null||at(o,o.return)),e.flags&32){t=e.stateNode;try{Si(t,""),re=!0}catch(f){ge(e,e.return,f)}}a&4&&e.stateNode!=null&&(t=e.memoizedProps,Hu(e,t,o!==null?o.memoizedProps:t)),a&1024&&(Lu=!0);break;case 6:if(St(t,e,n),Et(e),a&4){if(e.stateNode===null)throw Error(N(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,re=!0}catch(f){ge(e,e.return,f)}}break;case 3:if(re=!1,hc=null,i=vn,vn=Xr(t.containerInfo),St(t,e,n),vn=i,Et(e),a&4&&o!==null&&o.memoizedState.isDehydrated)try{Di(t.containerInfo)}catch(f){ge(e,e.return,f)}Lu&&(Lu=!1,Lv(e)),re=!1;break;case 4:a=Cn,Cn=Fe,o=ig(),i=vn,vn=Xr(e.stateNode.containerInfo),St(t,e,n),Et(e),vn=i,re&&vr&&(Yc=!0),re=o,Cn=a;break;case 12:St(t,e,n),Et(e);break;case 31:St(t,e,n),Et(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Jl(e,t)));break;case 13:St(t,e,n),Et(e),e.child.flags&8192&&e.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(us=Gt()),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Jl(e,t)));break;case 22:i=e.memoizedState!==null,r=o!==null&&o.memoizedState!==null;var l=Fe,c=fe,s=Cn;Fe=l||i,Cn=s||i,fe=c||r,St(t,e,n),fe=c,Cn=s,Fe=l,Et(e),a&8192&&(t=e.stateNode,t._visibility=i?t._visibility&-2:t._visibility|1,!i||o===null||r||Fe||fe||(t=r||fe,n=Fe,o=fe,Fe=i||Fe,fe=t,xo(e,2),Fe=n,fe=o),!i&&Cn||Bd(e,i)),a&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,Jl(e,n))));break;case 19:St(t,e,n),Et(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Jl(e,t)));break;case 30:a&512&&(fe||o===null||at(o,o.return)),a=ig(),i=vr,r=(n&335544064)===n,l=e.memoizedProps,vr=r&&co(l.default,l.update)!=="none",St(t,e,n),Et(e),r&&o!==null&&re&&(e.flags|=4),vr=i,re=a;break;case 21:break;case 7:a&512&&(fe||o===null||at(o,o.return)),o&&o.stateNode!==null&&(o.stateNode._fragmentFiber=e);default:St(t,e,n),Et(e)}}function Et(e){var t=e.flags;if(t&2){try{for(var n,o=e.return;o!==null;){if(Ev(o)){n=o;break}o=o.return}o=null;for(var a=e.return;a!==null;){if(Yf(a)){var i=a.stateNode;o===null?o=[i]:o.push(i)}if(qf(a))break;a=a.return}var r=o;if(n==null)throw Error(N(160));switch(n.tag){case 27:var l=n.stateNode,c=Bu(e);jc(e,c,l,r);break;case 5:var s=n.stateNode;n.flags&32&&(Si(s,""),n.flags&=-33);var f=Bu(e);jc(e,f,s,r);break;case 3:case 4:var m=n.stateNode.containerInfo,u=Bu(e);zd(e,u,m,r);break;default:throw Error(N(161))}}catch(d){ge(e,e.return,d)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Lv(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Lv(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,Ri=!0,t.reset(),Ri=!1),e=e.sibling}}function $a(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)Uv(t,e),t=t.sibling;else Av(t,!1)}function Uv(e,t){var n=e.alternate;if(n===null)Od(e,!1);else switch(e.tag){case 3:if(Hd=Nn=!1,Fg(),$a(t,e),!Nn&&!Yc){if(e=zn,e!==null)for(var o=0;o<e.length;o+=3){n=e[o];var a=e[o+1];d0(n,e[o+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+a+")"})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===""&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),Hd=!0}zn=null;break;case 5:$a(t,e);break;case 4:o=Nn,Nn=!1,$a(t,e),Nn&&(Yc=!0),Nn=o;break;case 22:e.memoizedState===null&&(n.memoizedState!==null?Od(e,!1):$a(t,e));break;case 30:o=Nn,a=Fg(),Nn=!1,$a(t,e),Nn&&(e.flags|=4);var i=e.memoizedProps,r=e.stateNode;t=no(i,r),r=no(n.memoizedProps,r);var l=co(i.default,i.update);l==="none"?t=!1:(i=n.memoizedState,n.memoizedState=null,n=e.child,zt=0,t=Vf(e,n,t,r,l,i,!0),zt!==(i===null?0:i.length)&&(e.flags|=32)),(e.flags&4)!==0&&t?(Ci(e,e.memoizedProps.onUpdate),zn=a):a!==null&&(a.push.apply(a,zn),zn=a),Nn=(e.flags&32)!==0?!0:o;break;default:$a(t,e)}}function Mn(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)zv(e,t.alternate,t),t=t.sibling}function xo(e,t){for(e=e.child;e!==null;){var n=e,o=t;switch(n.tag){case 0:case 11:case 14:case 15:Ko(4,n,n.return),xo(n,o);break;case 1:at(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&Sv(n,n.return,a),xo(n,o);break;case 27:(o&2)!==0&&x0(n.stateNode,n.type,n.memoizedProps);case 5:at(n,n.return),n.tag!==5&&n.tag!==27||Mr(n),xo(n,o);break;case 6:Mr(n);break;case 26:at(n,n.return),a=n.stateNode,n.memoizedState!==null||a===null||fe||a.parentNode.removeChild(a),xo(n,o);break;case 22:n.memoizedState===null&&xo(n,o);break;case 30:at(n,n.return),xo(n,o);break;case 7:at(n,n.return);default:xo(n,o)}e=e.sibling}}function hn(e,t,n){for(n=(t.subtreeFlags&8772)!==0?n:n&-2,t=t.child;t!==null;){var o=t.alternate,a=e,i=t,r=i.flags,l=(n&1)!==0;switch(i.tag){case 0:case 11:case 15:hn(a,i,n),nl(4,i);break;case 1:if(hn(a,i,n),o=i,a=o.stateNode,typeof a.componentDidMount=="function")try{a.componentDidMount()}catch(f){ge(o,o.return,f)}if(o=i,a=o.updateQueue,a!==null){var c=o.stateNode;try{var s=a.shared.hiddenCallbacks;if(s!==null)for(a.shared.hiddenCallbacks=null,a=0;a<s.length;a++)Oh(s[a],c)}catch(f){ge(o,o.return,f)}}l&&r&64&&kv(i),An(i,i.return);break;case 27:(n&2)!==0&&Tv(i);case 5:i.tag!==5&&i.tag!==27||Jg(i),hn(a,i,n),l&&o===null&&r&4&&Ad(i),An(i,i.return);break;case 6:Jg(i);break;case 26:c=i.stateNode,i.memoizedState!==null||c===null||Fe||ef(Xr(c.ownerDocument),i.type,c),hn(a,i,n),l&&o===null&&r&4&&Ad(i),An(i,i.return);break;case 12:hn(a,i,n);break;case 31:hn(a,i,n),l&&r&4&&_v(a,i);break;case 13:hn(a,i,n),l&&r&4&&Hv(a,i);break;case 22:i.memoizedState===null&&hn(a,i,n),An(i,i.return);break;case 30:hn(a,i,n),An(i,i.return);break;case 7:An(i,i.return);default:hn(a,i,n)}t=t.sibling}}function Kf(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&el(n))}function Xf(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&el(e))}function tn(e,t,n,o){var a=(n&335544064)===n;if(t.subtreeFlags&(a?10262:10256))for(t=t.child;t!==null;)jv(e,t,n,o),t=t.sibling;else a&&Mv(t)}function jv(e,t,n,o){var a=(n&335544064)===n;a&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&pc(t);var i=t.flags;switch(t.tag){case 0:case 11:case 15:tn(e,t,n,o),i&2048&&nl(9,t);break;case 1:tn(e,t,n,o);break;case 3:tn(e,t,n,o),a&&Hd&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,e.style.viewTransitionName==="root"&&(e.style.viewTransitionName=""),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName==="none"&&(e.style.viewTransitionName="")),i&2048&&(i=null,t.alternate!==null&&(i=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==i&&(t.refCount++,i!=null&&el(i)));break;case 12:if(i&2048){tn(e,t,n,o),i=t.stateNode;try{var r=t.memoizedProps,l=r.id,c=r.onPostCommit;typeof c=="function"&&c(l,t.alternate===null?"mount":"update",i.passiveEffectDuration,-0)}catch(s){ge(t,t.return,s)}}else tn(e,t,n,o);break;case 31:tn(e,t,n,o);break;case 13:tn(e,t,n,o);break;case 23:break;case 22:r=t.stateNode,l=t.alternate,t.memoizedState!==null?(a&&l!==null&&l.memoizedState===null&&pc(l),r._visibility&2?tn(e,t,n,o):Ar(e,t)):(a&&l!==null&&l.memoizedState!==null&&pc(t),r._visibility&2?tn(e,t,n,o):(r._visibility|=2,Ia(e,t,n,o,(t.subtreeFlags&10256)!==0||!1))),i&2048&&Kf(l,t);break;case 24:tn(e,t,n,o),i&2048&&Xf(t.alternate,t);break;case 30:a&&(i=t.alternate,i!==null&&(Ln(i.child,!0),Ln(t.child,!0))),tn(e,t,n,o);break;default:tn(e,t,n,o)}}function Ia(e,t,n,o,a){for(a=a&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var i=e,r=t,l=n,c=o,s=r.flags;switch(r.tag){case 0:case 11:case 15:Ia(i,r,l,c,a),nl(8,r);break;case 23:break;case 22:var f=r.stateNode;r.memoizedState!==null?f._visibility&2?Ia(i,r,l,c,a):Ar(i,r):(f._visibility|=2,Ia(i,r,l,c,a)),a&&s&2048&&Kf(r.alternate,r);break;case 24:Ia(i,r,l,c,a),a&&s&2048&&Xf(r.alternate,r);break;default:Ia(i,r,l,c,a)}t=t.sibling}}function Ar(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,o=t,a=o.flags;switch(o.tag){case 22:Ar(n,o),a&2048&&Kf(o.alternate,o);break;case 24:Ar(n,o),a&2048&&Xf(o.alternate,o);break;default:Ar(n,o)}t=t.sibling}}var la=8192;function aa(e,t,n){if(e.subtreeFlags&la)for(e=e.child;e!==null;)qv(e,t,n),e=e.sibling}function qv(e,t,n){switch(e.tag){case 26:aa(e,t,n),e.flags&la&&(e.memoizedState!==null?p2(n,vn,e.memoizedState,e.memoizedProps):(e=e.stateNode,(t&335544128)===t&&Tb(n,e)));break;case 5:aa(e,t,n),e.flags&la&&(e=e.stateNode,(t&335544128)===t&&Tb(n,e));break;case 3:case 4:var o=vn;vn=Xr(e.stateNode.containerInfo),aa(e,t,n),vn=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=la,la=16777216,aa(e,t,n),la=o):aa(e,t,n));break;case 30:if((e.flags&la)!==0&&(o=e.memoizedProps.name,o!=null&&o!=="auto")){var a=e.stateNode;a.paired=null,Kt===null&&(Kt=new Map),Kt.set(o,a)}aa(e,t,n);break;default:aa(e,t,n)}}function Yv(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function dr(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];We=o,Kv(o,e)}Yv(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Vv(e),e=e.sibling}function Vv(e){switch(e.tag){case 0:case 11:case 15:dr(e),e.flags&2048&&Ko(9,e,e.return);break;case 3:dr(e);break;case 12:dr(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,mc(e)):dr(e);break;default:dr(e)}}function mc(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];We=o,Kv(o,e)}Yv(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Ko(8,t,t.return),mc(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,mc(t));break;default:mc(t)}e=e.sibling}}function Kv(e,t){for(;We!==null;){var n=We;switch(n.tag){case 0:case 11:case 15:Ko(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var o=n.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:el(n.memoizedState.cache)}if(o=n.child,o!==null)o.return=n,We=o;else e:for(n=e;We!==null;){o=We;var a=o.sibling,i=o.return;if(Rv(o),o===n){We=null;break e}if(a!==null){a.return=i,We=a;break e}We=i}}}var uS={getCacheForType:function(e){var t=rt(Ve),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return rt(Ve).controller.signal}},dS=typeof WeakMap=="function"?WeakMap:Map,ce=0,he=null,te=null,ne=0,pe=0,qt=null,No=!1,Ui=!1,Gf=!1,ro=0,Be=0,Xo=0,ma=0,Vc=0,Xt=0,Ti=0,zr=null,At=null,Ud=!1,us=0,Xv=0,Kc=1/0,Xc=null,Bo=null,Oe=0,xn=null,ka=null,Bn=0,jd=0,qd=null,Gv=null,vi=null,yi=null,xi=null,Or=0,gc=null;function Pt(){return(ce&2)!==0&&ne!==0?ne&-ne:V.T!==null?Zf():$b()}function Qv(){if(Xt===0)if((ne&536870912)===0||F){var e=Ll;Ll<<=1,(Ll&3932160)===0&&(Ll=262144),Xt=e}else Xt=536870912;return e=ut.current,e!==null&&(e.flags|=32),Xt}function Ci(e,t){if(t!=null){var n=e.stateNode,o=n.ref;o===null&&(o=n.ref=p0(no(e.memoizedProps,n))),yi===null&&(yi=[]),yi.push(t.bind(null,o))}}function Rt(e,t,n){(e===he&&(pe===2||pe===9)||e.cancelPendingCommit!==null)&&(Ni(e,0),Mo(e,ne,Xt,!1)),Ir(e,n),((ce&2)===0||e!==he)&&(e===he&&((ce&2)===0&&(ma|=n),Be===4&&Mo(e,ne,Xt,!1)),jn(e))}function Zv(e,t,n){if((ce&6)!==0)throw Error(N(327));var o=!n&&(t&127)===0&&(t&e.expiredLanes)===0||Jr(e,t),a=o?mS(e,t):Uu(e,t,!0),i=o;do{if(a===0){Ui&&!o&&Mo(e,t,0,!1);break}else{if(n=e.current.alternate,i&&!fS(n)){a=Uu(e,t,!1),i=!1;continue}if(a===2){if(i=t,e.errorRecoveryDisabledLanes&i)var r=0;else r=e.pendingLanes&-536870913,r=r!==0?r:r&536870912?536870912:0;if(r!==0){t=r;e:{var l=e;a=zr;var c=l.current.memoizedState.isDehydrated;if(c&&(Ni(l,r).flags|=256),r=Uu(l,r,!1),r!==2&&r!==6){if(Gf&&!c){l.errorRecoveryDisabledLanes|=i,ma|=i,a=4;break e}i=At,At=a,i!==null&&(At===null?At=i:At.push.apply(At,i))}a=r}if(i=!1,a!==2)continue}}if(a===1){Ni(e,0),Mo(e,t,0,!0);break}e:{switch(o=e,i=a,i){case 0:case 1:throw Error(N(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:Mo(o,t,Xt,!No);break e;case 2:At=null;break;case 3:case 5:break;default:throw Error(N(329))}if((t&62914560)===t&&(a=us+300-Gt(),10<a)){if(Mo(o,t,Xt,!No),Jc(o,0,!0)!==0)break e;Bn=t,o.timeoutHandle=$f(eb.bind(null,o,n,At,Xc,Ud,t,Xt,ma,Ti,No,i,"Throttled",-0,0),a);break e}eb(o,n,At,Xc,Ud,t,Xt,ma,Ti,No,i,null,-0,0)}}break}while(!0);jn(e)}function eb(e,t,n,o,a,i,r,l,c,s,f,m,u,d){e.timeoutHandle=-1;var x=t.subtreeFlags,k=(i&335544064)===i;if(m=null,(k||x&8192||(x&16785408)===16785408)&&(m={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Rn},Kt=null,qv(t,i,m),k&&(x=m,k=e.containerInfo,k=(k.nodeType===9?k:k.ownerDocument).__reactViewTransition,k!=null&&(x.count++,x.waitingForViewTransition=!0,x=Gr.bind(x),k.finished.then(x,x))),x=(i&62914560)===i?us-Gt():(i&4194048)===i?Xv-Gt():0,x=m2(m,x),x!==null)){Bn=i,e.cancelPendingCommit=x(nb.bind(null,e,t,i,n,o,a,r,l,c,s,f,m,null,u,d)),Mo(e,i,r,!s);return}nb(e,t,i,n,o,a,r,l,c,s,f,m)}function fS(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var o=0;o<n.length;o++){var a=n[o],i=a.getSnapshot;a=a.value;try{if(!$t(i(),a))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Mo(e,t,n,o){t=Xb(e,t),t&=~Vc,t&=~ma,e.suspendedLanes|=t,e.pingedLanes&=~t,o&&(e.warmLanes|=t),o=e.expirationTimes;for(var a=t;0<a;){var i=31-Zt(a),r=1<<i;o[i]=-1,a&=~r}n!==0&&Qb(e,n,t)}function ds(){return(ce&6)===0?(ol(0,!1),!1):!0}function Qf(){if(te!==null){if(pe===0)var e=te.return;else e=te,Fn=Na=null,Af(e),gi=null,Ur=0,e=te;for(;e!==null;)wv(e.alternate,e),e=e.return;te=null}}function Ni(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,_S(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),Bn=0,Qf(),he=e,te=n=Wn(e.current,null),ne=t,pe=0,qt=null,No=!1,Ui=Jr(e,t),Gf=!1,Ti=Xt=Vc=ma=Xo=Be=0,At=zr=null,Ud=!1,ro=Xb(e,t),ts(),n}function Pv(e,t){Z=null,V.H=Bc,t===Bi||t===as?(t=Ng(),pe=3):t===wf?(t=Ng(),pe=4):pe=t===Lf?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,qt=t,te===null&&(Be=1,Lc(e,ln(t,e.current)))}function $v(){var e=ut.current;return e===null?!0:(ne&4194048)===ne?ht===null:(ne&62914560)===ne||(ne&536870912)!==0?e===ht:!1}function Jv(){var e=V.H;return V.H=Bc,e===null?Bc:e}function Iv(){var e=V.A;return V.A=uS,e}function Gc(){Be=4,No||(ne&4194048)!==ne&&ut.current!==null||(Ui=!0),(Xo&134217727)===0&&(ma&134217727)===0||he===null||Mo(he,ne,Xt,!1)}function Uu(e,t,n){var o=ce;ce|=2;var a=Jv(),i=Iv();(he!==e||ne!==t)&&(Xc=null,Ni(e,t)),t=!1;var r=Be;e:do try{if(pe!==0&&te!==null){var l=te,c=qt;switch(pe){case 8:Qf(),r=6;break e;case 3:case 2:case 9:case 6:ut.current===null&&(t=!0);var s=pe;if(pe=0,qt=null,ui(e,l,c,s),n&&Ui){r=0;break e}break;default:s=pe,pe=0,qt=null,ui(e,l,c,s)}}pS(),r=Be;break}catch(f){Pv(e,f)}while(!0);return t&&e.shellSuspendCounter++,Fn=Na=null,ce=o,V.H=a,V.A=i,te===null&&(he=null,ne=0,ts()),r}function pS(){for(;te!==null;)Fv(te)}function mS(e,t){var n=ce;ce|=2;var o=Jv(),a=Iv();he!==e||ne!==t?(Xc=null,Kc=Gt()+500,Ni(e,t)):Ui=Jr(e,t);e:do try{if(pe!==0&&te!==null){t=te;var i=qt;t:switch(pe){case 1:pe=0,qt=null,ui(e,t,i,1);break;case 2:case 9:if(Cg(i)){pe=0,qt=null,tb(t);break}t=function(){pe!==2&&pe!==9||he!==e||(pe=7),jn(e)},i.then(t,t);break e;case 3:pe=7;break e;case 4:pe=5;break e;case 7:Cg(i)?(pe=0,qt=null,tb(t)):(pe=0,qt=null,ui(e,t,i,7));break;case 5:var r=null;switch(te.tag){case 26:r=te.memoizedState;case 5:case 27:var l=te;if(r?S0(r):l.stateNode.complete){pe=0,qt=null;var c=l.sibling;if(c!==null)te=c;else{var s=l.return;s!==null?(te=s,fs(s)):te=null}break t}}pe=0,qt=null,ui(e,t,i,5);break;case 6:pe=0,qt=null,ui(e,t,i,6);break;case 8:Qf(),Be=6;break e;default:throw Error(N(462))}}gS();break}catch(f){Pv(e,f)}while(!0);return Fn=Na=null,V.H=o,V.A=a,ce=n,te!==null?0:(he=null,ne=0,ts(),Be)}function gS(){for(;te!==null&&!Rw();)Fv(te)}function Fv(e){var t=xv(e.alternate,e,ro);e.memoizedProps=e.pendingProps,t===null?fs(e):te=t}function tb(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Kg(n,t,t.pendingProps,t.type,void 0,ne);break;case 11:t=Kg(n,t,t.pendingProps,t.type.render,t.ref,ne);break;case 5:Af(t);var o=t;o===tt&&(F?(Ac(o),o.tag===5&&o.stateNode!=null&&(ke=o.stateNode)):(Ac(o),F=!0));default:wv(n,t),t=te=kh(t,ro),t=xv(n,t,ro)}e.memoizedProps=e.pendingProps,t===null?fs(e):te=t}function ui(e,t,n,o){Fn=Na=null,Af(t),gi=null,Ur=0;var a=t.return;try{if(nS(e,a,t,n,ne)){Be=1,Lc(e,ln(n,e.current)),te=null;return}}catch(i){if(a!==null)throw te=a,i;Be=1,Lc(e,ln(n,e.current)),te=null;return}t.flags&32768?(F||o===1?e=!0:Ui||(ne&536870912)!==0?e=!1:(No=e=!0,(o===2||o===9||o===3||o===6)&&(o=ut.current,o!==null&&o.tag===13&&(o.flags|=16384))),Wv(t,e)):fs(t)}function fs(e){var t=e;do{if((t.flags&32768)!==0){Wv(t,No);return}e=t.return;var n=rS(t.alternate,t,ro);if(n!==null){te=n;return}if(t=t.sibling,t!==null){te=t;return}te=t=e}while(t!==null);Be===0&&(Be=5)}function Wv(e,t){do{var n=lS(e.alternate,e);if(n!==null){n.flags&=32767,te=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){te=e;return}te=e=n}while(e!==null);Be=6,te=null}function nb(e,t,n,o,a,i,r,l,c,s,f,m){e.cancelPendingCommit=null;do ps();while(Oe!==0);if((ce&6)!==0)throw Error(N(327));if(t!==null){if(t===e.current)throw Error(N(177));e===he&&(te=he=null,ne=0),ka=t,xn=e,Bn=n,qd=a,Gv=o,bS(e,t,n,r,l,c,m)}}function bS(e,t,n,o,a,i,r){var l=t.lanes|t.childLanes;if(jd=l,l|=gf,Vw(e,n,l,o,a,i),yi=null,(n&335544064)===n?(xi=Xk(e),o=10262):(xi=null,o=10256),(t.subtreeFlags&o)!==0||(t.flags&o)!==0?(e.callbackNode=null,e.callbackPriority=0,kS(Ec,function(){return Xd(),null})):(e.callbackNode=null,e.callbackPriority=0),qc=!1,o=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||o){o=V.T,V.T=null,a=se.p,se.p=2,i=ce,ce|=4;try{cS(e,t,n)}finally{ce=i,se.p=a,V.T=o}}Oe=1,qc?vi=qS(r,e.containerInfo,xi,Yd,Vd,vS,Kd,Xd,hS,null,null):(Yd(),Vd(),Kd())}function hS(e){if(Oe!==0){var t=xn.onRecoverableError;t(e,{componentStack:null})}}function vS(){Oe===3&&(Oe=0,Uv(ka,xn),Oe=4)}function Yd(){if(Oe===1){Oe=0;var e=xn,t=ka,n=Bn,o=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||o){o=V.T,V.T=null;var a=se.p;se.p=2;var i=ce;ce|=4;try{vr=Yc=!1,Bv(t,e,n),n=Pd;var r=mh(e.containerInfo),l=n.focusedElem,c=n.selectionRange;if(r!==l&&l&&l.ownerDocument&&ph(l.ownerDocument.documentElement,l)){if(c!==null&&mf(l)){var s=c.start,f=c.end;if(f===void 0&&(f=s),"selectionStart"in l)l.selectionStart=s,l.selectionEnd=Math.min(f,l.value.length);else{var m=l.ownerDocument||document,u=m&&m.defaultView||window;if(u.getSelection){var d=u.getSelection(),x=l.textContent.length,k=Math.min(c.start,x),E=c.end===void 0?k:Math.min(c.end,x);!d.extend&&k>E&&(r=E,E=k,k=r);var g=vg(l,k),b=vg(l,E);if(g&&b&&(d.rangeCount!==1||d.anchorNode!==g.node||d.anchorOffset!==g.offset||d.focusNode!==b.node||d.focusOffset!==b.offset)){var p=m.createRange();p.setStart(g.node,g.offset),d.removeAllRanges(),k>E?(d.addRange(p),d.extend(b.node,b.offset)):(p.setEnd(b.node,b.offset),d.addRange(p))}}}}for(m=[],d=l;d=d.parentNode;)d.nodeType===1&&m.push({element:d,left:d.scrollLeft,top:d.scrollTop});for(typeof l.focus=="function"&&l.focus(),l=0;l<m.length;l++){var v=m[l];v.element.scrollLeft=v.left,v.element.scrollTop=v.top}}Ri=!!Zd,Pd=Zd=null}finally{ce=i,se.p=a,V.T=o}}e.current=t,Oe=2}}function Vd(){if(Oe===2){Oe=0;var e=xn,t=ka,n=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||n){n=V.T,V.T=null;var o=se.p;se.p=2;var a=ce;ce|=4;try{zv(e,t.alternate,t)}finally{ce=a,se.p=o,V.T=n}}Oe=3}}function Kd(){if(Oe===4||Oe===3){Oe=0;var e=vi;vi=null,Dw();var t=xn,n=ka,o=Bn,a=Gv,i=(o&335544064)===o?10262:10256;if((n.subtreeFlags&i)!==0||(n.flags&i)!==0?Oe=5:(Oe=0,ka=xn=null,e0(t,t.pendingLanes)),i=t.pendingLanes,i===0&&(Bo=null),cf(o),n=n.stateNode,Qt&&typeof Qt.onCommitFiberRoot=="function")try{Qt.onCommitFiberRoot($r,n,void 0,(n.current.flags&128)===128)}catch{}if(a!==null){n=V.T,i=se.p,se.p=2,V.T=null;try{for(var r=t.onRecoverableError,l=0;l<a.length;l++){var c=a[l];r(c.value,{componentStack:c.stack})}}finally{V.T=n,se.p=i}}if(a=yi,r=xi,xi=null,a!==null&&(yi=null,r===null&&(r=[]),e!==null))for(c=0;c<a.length;c++)n=(0,a[c])(r),n!==void 0&&e.finished.finally(n);(Bn&3)!==0&&ps(),jn(t),i=t.pendingLanes,(o&261930)!==0&&(i&42)!==0?t===gc?Or++:(Or=0,gc=t):(Or=0,gc=null),ol(0,!1)}}function e0(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,el(t)))}function ps(){return vi!==null&&(vi.skipTransition(),vi=null),Yd(),Vd(),Kd(),Xd()}function Xd(){if(Oe!==5)return!1;var e=xn,t=jd;jd=0;var n=cf(Bn),o=V.T,a=se.p;try{se.p=32>n?32:n,V.T=null,n=qd,qd=null;var i=xn,r=Bn;if(Oe=0,ka=xn=null,Bn=0,(ce&6)!==0)throw Error(N(331));var l=ce;if(ce|=4,Vv(i.current),jv(i,i.current,r,n),ce=l,ol(0,!1),Qt&&typeof Qt.onPostCommitFiberRoot=="function")try{Qt.onPostCommitFiberRoot($r,i)}catch{}return!0}finally{se.p=a,V.T=o,e0(e,t)}}function ob(e,t,n){t=ln(n,t),t=Sd(e.stateNode,t,2),e=Do(e,t,2),e!==null&&(Ir(e,2),jn(e))}function ge(e,t,n){if(e.tag===3)ob(e,e,n);else for(;t!==null;){if(t.tag===3){ob(t,e,n);break}else if(t.tag===1){var o=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(Bo===null||!Bo.has(o))){e=ln(n,e),n=gv(2),o=Do(t,n,2),o!==null&&(bv(n,o,t,e),Ir(o,2),jn(o));break}}t=t.return}}function ju(e,t,n){var o=e.pingCache;if(o===null){o=e.pingCache=new dS;var a=new Set;o.set(t,a)}else a=o.get(t),a===void 0&&(a=new Set,o.set(t,a));a.has(n)||(Gf=!0,a.add(n),e=yS.bind(null,e,t,n),t.then(e,e))}function yS(e,t,n){var o=e.pingCache;o!==null&&o.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,he===e&&(ne&n)===n&&((Be===4||Be===3&&(ne&62914560)===ne&&300>Gt()-us)&&(ce&2)===0?Ni(e,0):Vc|=n,Ti===ne&&(Ti=0)),jn(e)}function t0(e,t){t===0&&(t=Gb()),e=Ca(e,t),e!==null&&(Ir(e,t),jn(e))}function xS(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),t0(e,n)}function wS(e,t){var n=0;switch(e.tag){case 31:case 13:var o=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(N(314))}o!==null&&o.delete(t),t0(e,n)}function kS(e,t){return rf(e,t)}var Mi=null,Fa=null,Gd=!1,Qc=!1,qu=!1,Ao=0;function jn(e){e!==Fa&&e.next===null&&(Fa===null?Mi=Fa=e:Fa=Fa.next=e),Qc=!0,Gd||(Gd=!0,ES())}function ol(e,t){if(!qu&&Qc){qu=!0;do for(var n=!1,o=Mi;o!==null;){if(!t)if(e!==0){var a=o.pendingLanes;if(a===0)var i=0;else{var r=o.suspendedLanes,l=o.pingedLanes;i=(1<<31-Zt(42|e)+1)-1,i&=a&~(r&~l),i=i&201326741?i&201326741|1:i?i|2:0}i!==0&&(n=!0,ab(o,i))}else i=ne,i=Jc(o,o===he?i:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(i&3)===0||Jr(o,i)||(n=!0,ab(o,i));o=o.next}while(n);qu=!1}}function SS(){n0()}function n0(){Qc=Gd=!1;var e=0;Ao!==0&&DS()&&(e=Ao);for(var t=Gt(),n=null,o=Mi;o!==null;){var a=o.next,i=o0(o,t);i===0?(o.next=null,n===null?Mi=a:n.next=a,a===null&&(Fa=n)):(n=o,(e!==0||(i&3)!==0)&&(Qc=!0)),o=a}Oe!==0&&Oe!==5||ol(e,!1),Ao!==0&&(Ao=0)}function o0(e,t){for(var n=e.suspendedLanes,o=e.pingedLanes,a=e.expirationTimes,i=e.pendingLanes&-62914561;0<i;){var r=31-Zt(i),l=1<<r,c=a[r];c===-1?((l&n)===0||(l&o)!==0)&&(a[r]=Yw(l,t)):c<=t&&(e.expiredLanes|=l),i&=~l}if(t=he,n=ne,n=Jc(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,n===0||e===t&&(pe===2||pe===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&vu(o),e.callbackNode=null,e.callbackPriority=0;if((n&3)===0||Jr(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(o!==null&&vu(o),cf(n)){case 2:case 8:n=Vb;break;case 32:n=Ec;break;case 268435456:n=Kb;break;default:n=Ec}return o=a0.bind(null,e),n=rf(n,o),e.callbackPriority=t,e.callbackNode=n,t}return o!==null&&o!==null&&vu(o),e.callbackPriority=2,e.callbackNode=null,2}function a0(e,t){if(Oe!==0&&Oe!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(ps()&&e.callbackNode!==n)return null;var o=ne;return o=Jc(e,e===he?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(Zv(e,o,t),o0(e,Gt()),e.callbackNode!=null&&e.callbackNode===n?a0.bind(null,e):null)}function ab(e,t){if(ps())return null;Zv(e,t,!0)}function ES(){HS(function(){(ce&6)!==0?rf(Yb,SS):n0()})}function Zf(){if(Ao===0){var e=va;e===0&&(e=Bl,Bl<<=1,(Bl&261888)===0&&(Bl=256)),Ao=e}return Ao}function ib(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:oc(e)}function TS(e,t,n,o,a){if(t==="submit"&&n&&n.stateNode===a){var i=ib((a[_t]||null).action),r=o.submitter;r&&(t=(t=r[_t]||null)?ib(t.formAction):r.getAttribute("formAction"),t!==null&&(i=t,r=null));var l=new Fc("action","action",null,o,a);e.push({event:l,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(Ao!==0){var c=new FormData(a,r);wd(n,{pending:!0,data:c,method:a.method,action:i},null,c)}}else typeof i=="function"&&(l.preventDefault(),c=new FormData(a,r),wd(n,{pending:!0,data:c,method:a.method,action:i},i,c))},currentTarget:a}]})}}for(Il=0;Il<ud.length;Il++)Fl=ud[Il],rb=Fl.toLowerCase(),lb=Fl[0].toUpperCase()+Fl.slice(1),wn(rb,"on"+lb);var Fl,rb,lb,Il;wn(bh,"onAnimationEnd");wn(hh,"onAnimationIteration");wn(vh,"onAnimationStart");wn("dblclick","onDoubleClick");wn("focusin","onFocus");wn("focusout","onBlur");wn(Bk,"onTransitionRun");wn(Lk,"onTransitionStart");wn(Uk,"onTransitionCancel");wn(yh,"onTransitionEnd");ki("onMouseEnter",["mouseout","mouseover"]);ki("onMouseLeave",["mouseout","mouseover"]);ki("onPointerEnter",["pointerout","pointerover"]);ki("onPointerLeave",["pointerout","pointerover"]);Ea("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));Ea("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));Ea("onBeforeInput",["compositionend","keypress","textInput","paste"]);Ea("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));Ea("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));Ea("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Yr="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),CS=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Yr));function i0(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var o=e[n],a=o.event;o=o.listeners;e:{var i=void 0;if(t)for(var r=o.length-1;0<=r;r--){var l=o[r],c=l.instance,s=l.currentTarget;if(l=l.listener,c!==i&&a.isPropagationStopped())break e;i=l,a.currentTarget=s;try{i(a)}catch(f){Cc(f)}a.currentTarget=null,i=c}else for(r=0;r<o.length;r++){if(l=o[r],c=l.instance,s=l.currentTarget,l=l.listener,c!==i&&a.isPropagationStopped())break e;i=l,a.currentTarget=s;try{i(a)}catch(f){Cc(f)}a.currentTarget=null,i=c}}}}function ee(e,t){var n=t[tg];n===void 0&&(n=t[tg]=new Set);var o=e+"__bubble";n.has(o)||(r0(t,e,2,!1),n.add(o))}function Yu(e,t,n){var o=0;t&&(o|=4),r0(n,e,o,t)}var Wl="_reactListening"+Math.random().toString(36).slice(2);function Pf(e){if(!e[Wl]){e[Wl]=!0,Ib.forEach(function(n){n!=="selectionchange"&&(CS.has(n)||Yu(n,!1,e),Yu(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Wl]||(t[Wl]=!0,Yu("selectionchange",!1,t))}}function r0(e,t,n,o){switch(z0(t)){case 2:var a=v2;break;case 8:a=y2;break;default:a=tp}n=a.bind(null,t,n,e),a=void 0,!rd||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(a=!0),o?a!==void 0?e.addEventListener(t,n,{capture:!0,passive:a}):e.addEventListener(t,n,!0):a!==void 0?e.addEventListener(t,n,{passive:a}):e.addEventListener(t,n,!1)}function Vu(e,t,n,o,a){var i=o;if((t&1)===0&&(t&2)===0&&o!==null)e:for(;;){if(o===null)return;var r=o.tag;if(r===3||r===4){var l=o.stateNode.containerInfo;if(l===a)break;if(r===4)for(r=o.return;r!==null;){var c=r.tag;if((c===3||c===4)&&r.stateNode.containerInfo===a)return;r=r.return}for(;l!==null;){if(r=ca(l),r===null)return;if(c=r.tag,c===5||c===6||c===26||c===27){o=i=r;continue e}l=l.parentNode}}o=o.return}ih(function(){var s=i,f=uf(n),m=[];e:{var u=xh.get(e);if(u!==void 0){var d=Fc,x=e;switch(e){case"keypress":if(ic(n)===0)break e;case"keydown":case"keyup":d=fk;break;case"focusin":x="focus",d=Eu;break;case"focusout":x="blur",d=Eu;break;case"beforeblur":case"afterblur":d=Eu;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":d=sg;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":d=ek;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":d=hk;break;case bh:case hh:case vh:d=ok;break;case yh:d=yk;break;case"scroll":case"scrollend":d=Fw;break;case"wheel":d=wk;break;case"copy":case"cut":case"paste":d=ik;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":d=dg;break;case"submit":d=gk;break;case"toggle":case"beforetoggle":d=Sk}var k=(t&4)!==0,E=!k&&(e==="scroll"||e==="scrollend"),g=k?u!==null?u+"Capture":null:u;k=[];for(var b=s,p;b!==null;){var v=b;if(p=v.stateNode,v=v.tag,v!==5&&v!==26&&v!==27||p===null||g===null||(v=Dr(b,g),v!=null&&k.push(Vr(b,v,p))),E)break;b=b.return}0<k.length&&(u=new d(u,x,null,n,f),m.push({event:u,listeners:k}))}}if((t&7)===0){e:{if(d=e==="mouseover"||e==="pointerover",u=e==="mouseout"||e==="pointerout",d&&n!==id&&(x=n.relatedTarget||n.fromElement)&&(ca(x)||x[_i]))break e;(u||d)&&(x=f.window===f?f:(d=f.ownerDocument)?d.defaultView||d.parentWindow:window,u?(d=n.relatedTarget||n.toElement,u=s,d=d?ca(d):null,d!==null&&(E=Pr(d),k=d.tag,d!==E||k!==5&&k!==27&&k!==6)&&(d=null)):(u=null,d=s),u!==d&&(k=sg,v="onMouseLeave",g="onMouseEnter",b="mouse",(e==="pointerout"||e==="pointerover")&&(k=dg,v="onPointerLeave",g="onPointerEnter",b="pointer"),E=u==null?x:br(u),p=d==null?x:br(d),x=new k(v,b+"leave",u,n,f),x.target=E,x.relatedTarget=p,v=null,ca(f)===s&&(k=new k(g,b+"enter",d,n,f),k.target=p,k.relatedTarget=E,v=k),E=v,k=u&&d?Zu(u,d,NS):null,u!==null&&cb(m,x,u,k,!1),d!==null&&E!==null&&cb(m,E,d,k,!0)))}e:{if(u=s?br(s):window,d=u.nodeName&&u.nodeName.toLowerCase(),d==="select"||d==="input"&&u.type==="file")var h=gg;else if(mg(u))if(dh)h=Dk;else{h=Ok;var T=zk}else d=u.nodeName,!d||d.toLowerCase()!=="input"||u.type!=="checkbox"&&u.type!=="radio"?s&&sf(s.elementType)&&(h=gg):h=Rk;if(h&&(h=h(e,s))){uh(m,h,n,f);break e}T&&T(e,u,s)}switch(T=s?br(s):window,e){case"focusin":(mg(T)||T.contentEditable==="true")&&(ai=T,cd=s,wr=null);break;case"focusout":wr=cd=ai=null;break;case"mousedown":sd=!0;break;case"contextmenu":case"mouseup":case"dragend":sd=!1,yg(m,n,f);break;case"selectionchange":if(Hk)break;case"keydown":case"keyup":yg(m,n,f)}var w;if(pf)e:{switch(e){case"compositionstart":var S="onCompositionStart";break e;case"compositionend":S="onCompositionEnd";break e;case"compositionupdate":S="onCompositionUpdate";break e}S=void 0}else oi?ch(e,n)&&(S="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(S="onCompositionStart");S&&(lh&&n.locale!=="ko"&&(oi||S!=="onCompositionStart"?S==="onCompositionEnd"&&oi&&(w=rh()):(To=f,df="value"in To?To.value:To.textContent,oi=!0)),T=Zc(s,S),0<T.length&&(S=new ug(S,e,null,n,f),m.push({event:S,listeners:T}),w?S.data=w:(w=sh(n),w!==null&&(S.data=w)))),(w=Tk?Ck(e,n):Nk(e,n))&&(S=Zc(s,"onBeforeInput"),0<S.length&&(T=new ug("onBeforeInput","beforeinput",null,n,f),m.push({event:T,listeners:S}),T.data=w)),TS(m,e,s,n,f)}i0(m,t)})}function Vr(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Zc(e,t){for(var n=t+"Capture",o=[];e!==null;){var a=e,i=a.stateNode;if(a=a.tag,a!==5&&a!==26&&a!==27||i===null||(a=Dr(e,n),a!=null&&o.unshift(Vr(e,a,i)),a=Dr(e,t),a!=null&&o.push(Vr(e,a,i))),e.tag===3)return o;e=e.return}return[]}function NS(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function cb(e,t,n,o,a){for(var i=t._reactName,r=[];n!==null&&n!==o;){var l=n,c=l.alternate,s=l.stateNode;if(l=l.tag,c!==null&&c===o)break;l!==5&&l!==26&&l!==27||s===null||(c=s,a?(s=Dr(n,i),s!=null&&r.unshift(Vr(n,s,c))):a||(s=Dr(n,i),s!=null&&r.push(Vr(n,s,c)))),n=n.return}r.length!==0&&e.push({event:t,listeners:r})}var MS=/\r\n?/g,AS=/\u0000|\uFFFD/g;function sb(e){return(typeof e=="string"?e:""+e).replace(MS,`
`).replace(AS,"")}function l0(e,t){return t=sb(t),sb(e)===t}function me(e,t,n,o,a,i){switch(n){case"children":if(typeof o=="string")t==="body"||t==="textarea"&&o===""||Si(e,o);else if(typeof o=="number"||typeof o=="bigint")t!=="body"&&Si(e,""+o);else return;break;case"className":jl(e,"class",o);break;case"tabIndex":jl(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":jl(e,n,o);break;case"style":ah(e,o,i);return;case"data":if(t!=="object"){jl(e,"data",o);break}case"src":case"href":if(o===""&&(t!=="a"||n!=="href")){e.removeAttribute(n);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=oc(o),e.setAttribute(n,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof i=="function"&&(n==="formAction"?(t!=="input"&&me(e,t,"name",a.name,a,null),me(e,t,"formEncType",a.formEncType,a,null),me(e,t,"formMethod",a.formMethod,a,null),me(e,t,"formTarget",a.formTarget,a,null)):(me(e,t,"encType",a.encType,a,null),me(e,t,"method",a.method,a,null),me(e,t,"target",a.target,a,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=oc(o),e.setAttribute(n,o);break;case"onClick":o!=null&&(e.onclick=Rn);return;case"onScroll":o!=null&&ee("scroll",e);return;case"onScrollEnd":o!=null&&ee("scrollend",e);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(N(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(N(60));i?.__html!==n&&(e.innerHTML=n)}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}n=oc(o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":o===!0?e.setAttribute(n,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(n,o):e.removeAttribute(n);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(n):e.setAttribute(n,o);break;case"popover":ee("beforetoggle",e),ee("toggle",e),nc(e,"popover",o);break;case"xlinkActuate":$n(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":$n(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":$n(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":$n(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":$n(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":$n(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":$n(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":$n(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":$n(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":nc(e,"is",o);break;case"innerText":case"textContent":return;default:if(!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")n=Jw.get(n)||n,nc(e,n,o);else return}re=!0}function Qd(e,t,n,o,a,i){switch(n){case"style":ah(e,o,i);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(N(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(N(60));i?.__html!==n&&(e.innerHTML=n)}}break;case"children":if(typeof o=="string")Si(e,o);else if(typeof o=="number"||typeof o=="bigint")Si(e,""+o);else return;break;case"onScroll":o!=null&&ee("scroll",e);return;case"onScrollEnd":o!=null&&ee("scrollend",e);return;case"onClick":o!=null&&(e.onclick=Rn);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!Fb.hasOwnProperty(n))e:{if(n[0]==="o"&&n[1]==="n"&&(a=n.endsWith("Capture"),i=n.slice(2,a?n.length-7:void 0),t=e[_t]||null,t=t!=null?t[n]:null,typeof t=="function"&&e.removeEventListener(i,t,a),typeof o=="function")){typeof t!="function"&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(i,o,a);break e}re=!0,n in e?e[n]=o:o===!0?e.setAttribute(n,""):nc(e,n,o)}return}re=!0}function st(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":ee("error",e),ee("load",e);var o=!1,a=!1,i;for(i in n)if(n.hasOwnProperty(i)){var r=n[i];if(r!=null)switch(i){case"src":o=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(N(137,t));default:me(e,t,i,r,n,null)}}a&&me(e,t,"srcSet",n.srcSet,n,null),o&&me(e,t,"src",n.src,n,null);return;case"input":ee("invalid",e);var l=i=r=a=null,c=null,s=null;for(o in n)if(n.hasOwnProperty(o)){var f=n[o];if(f!=null)switch(o){case"name":a=f;break;case"type":r=f;break;case"checked":c=f;break;case"defaultChecked":s=f;break;case"value":i=f;break;case"defaultValue":l=f;break;case"children":case"dangerouslySetInnerHTML":if(f!=null)throw Error(N(137,t));break;default:me(e,t,o,f,n,null)}}th(e,i,l,c,s,r,a,!1);return;case"select":ee("invalid",e),o=r=i=null;for(a in n)if(n.hasOwnProperty(a)&&(l=n[a],l!=null))switch(a){case"value":i=l;break;case"defaultValue":r=l;break;case"multiple":o=l;default:me(e,t,a,l,n,null)}t=i,n=r,e.multiple=!!o,t!=null?fi(e,!!o,t,!1):n!=null&&fi(e,!!o,n,!0);return;case"textarea":ee("invalid",e),i=a=o=null;for(r in n)if(n.hasOwnProperty(r)&&(l=n[r],l!=null))switch(r){case"value":o=l;break;case"defaultValue":a=l;break;case"children":i=l;break;case"dangerouslySetInnerHTML":if(l!=null)throw Error(N(91));break;default:me(e,t,r,l,n,null)}oh(e,o,a,i);return;case"option":for(c in n)n.hasOwnProperty(c)&&(o=n[c],o!=null)&&(c==="selected"?e.selected=o&&typeof o!="function"&&typeof o!="symbol":me(e,t,c,o,n,null));return;case"dialog":ee("beforetoggle",e),ee("toggle",e),ee("cancel",e),ee("close",e);break;case"iframe":case"object":ee("load",e);break;case"video":case"audio":for(o=0;o<Yr.length;o++)ee(Yr[o],e);break;case"image":ee("error",e),ee("load",e);break;case"details":ee("toggle",e);break;case"embed":case"source":case"link":ee("error",e),ee("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(s in n)if(n.hasOwnProperty(s)&&(o=n[s],o!=null))switch(s){case"children":case"dangerouslySetInnerHTML":throw Error(N(137,t));default:me(e,t,s,o,n,null)}return;default:if(sf(t)){for(f in n)n.hasOwnProperty(f)&&(o=n[f],o!==void 0&&Qd(e,t,f,o,n,void 0));return}}for(l in n)n.hasOwnProperty(l)&&(o=n[l],o!=null&&me(e,t,l,o,n,null))}var zS={};function OS(e,t,n,o){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var a=null,i=null,r=null,l=null,c=null,s=null,f=null;for(d in n){var m=n[d];if(n.hasOwnProperty(d)&&m!=null)switch(d){case"checked":break;case"value":break;case"defaultValue":c=m;default:o.hasOwnProperty(d)||me(e,t,d,null,o,m)}}for(var u in o){var d=o[u];if(m=n[u],o.hasOwnProperty(u)&&(d!=null||m!=null))switch(u){case"type":d!==m&&(re=!0),i=d;break;case"name":d!==m&&(re=!0),a=d;break;case"checked":d!==m&&(re=!0),s=d;break;case"defaultChecked":d!==m&&(re=!0),f=d;break;case"value":d!==m&&(re=!0),r=d;break;case"defaultValue":d!==m&&(re=!0),l=d;break;case"children":case"dangerouslySetInnerHTML":if(d!=null)throw Error(N(137,t));break;default:d!==m&&me(e,t,u,d,o,m)}}ad(e,r,l,c,s,f,i,a);return;case"select":d=r=l=u=null;for(i in n)if(c=n[i],n.hasOwnProperty(i)&&c!=null)switch(i){case"value":break;case"multiple":d=c;default:o.hasOwnProperty(i)||me(e,t,i,null,o,c)}for(a in o)if(i=o[a],c=n[a],o.hasOwnProperty(a)&&(i!=null||c!=null))switch(a){case"value":i!==c&&(re=!0),u=i;break;case"defaultValue":i!==c&&(re=!0),l=i;break;case"multiple":i!==c&&(re=!0),r=i;default:i!==c&&me(e,t,a,i,o,c)}t=l,n=r,o=d,u!=null?fi(e,!!n,u,!1):!!o!=!!n&&(t!=null?fi(e,!!n,t,!0):fi(e,!!n,n?[]:"",!1));return;case"textarea":d=u=null;for(l in n)if(a=n[l],n.hasOwnProperty(l)&&a!=null&&!o.hasOwnProperty(l))switch(l){case"value":break;case"children":break;default:me(e,t,l,null,o,a)}for(r in o)if(a=o[r],i=n[r],o.hasOwnProperty(r)&&(a!=null||i!=null))switch(r){case"value":a!==i&&(re=!0),u=a;break;case"defaultValue":a!==i&&(re=!0),d=a;break;case"children":break;case"dangerouslySetInnerHTML":if(a!=null)throw Error(N(91));break;default:a!==i&&me(e,t,r,a,o,i)}nh(e,u,d);return;case"option":for(var x in n)u=n[x],n.hasOwnProperty(x)&&u!=null&&!o.hasOwnProperty(x)&&(x==="selected"?e.selected=!1:me(e,t,x,null,o,u));for(c in o)u=o[c],d=n[c],o.hasOwnProperty(c)&&u!==d&&(u!=null||d!=null)&&(c==="selected"?(u!==d&&(re=!0),e.selected=u&&typeof u!="function"&&typeof u!="symbol"):me(e,t,c,u,o,d));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var k in n)u=n[k],n.hasOwnProperty(k)&&u!=null&&!o.hasOwnProperty(k)&&me(e,t,k,null,o,u);for(s in o)if(u=o[s],d=n[s],o.hasOwnProperty(s)&&u!==d&&(u!=null||d!=null))switch(s){case"children":case"dangerouslySetInnerHTML":if(u!=null)throw Error(N(137,t));break;default:me(e,t,s,u,o,d)}return;default:if(sf(t)){for(var E in n)u=n[E],n.hasOwnProperty(E)&&u!==void 0&&!o.hasOwnProperty(E)&&Qd(e,t,E,void 0,o,u);for(f in o)u=o[f],d=n[f],!o.hasOwnProperty(f)||u===d||u===void 0&&d===void 0||Qd(e,t,f,u,o,d);return}}for(var g in n)u=n[g],n.hasOwnProperty(g)&&u!=null&&!o.hasOwnProperty(g)&&me(e,t,g,null,o,u);for(m in o)u=o[m],d=n[m],!o.hasOwnProperty(m)||u===d||u==null&&d==null||me(e,t,m,u,o,d)}function ub(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function RS(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,n=performance.getEntriesByType("resource"),o=0;o<n.length;o++){var a=n[o],i=a.transferSize,r=a.initiatorType,l=a.duration;if(i&&l&&ub(r)){for(r=0,l=a.responseEnd,o+=1;o<n.length;o++){var c=n[o],s=c.startTime;if(s>l)break;var f=c.transferSize,m=c.initiatorType;f&&ub(m)&&(c=c.responseEnd,r+=f*(c<l?1:(l-s)/(c-s)))}if(--o,t+=8*(i+r)/(a.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Zd=null,Pd=null;function Kr(e){return e.nodeType===9?e:e.ownerDocument}function db(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function c0(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function s0(e,t,n,o){return n=Kr(n).createElement(e),n[it]=o,n[_t]=t,st(n,e,t),et(n),n}function $d(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Ku=null;function DS(){var e=window.event;return e&&e.type==="popstate"?e===Ku?!1:(Ku=e,!0):(Ku=null,!1)}var $f=typeof setTimeout=="function"?setTimeout:void 0,_S=typeof clearTimeout=="function"?clearTimeout:void 0,fb=typeof Promise=="function"?Promise:void 0,pb=typeof requestAnimationFrame=="function"?requestAnimationFrame:$f,HS=typeof queueMicrotask=="function"?queueMicrotask:typeof fb<"u"?function(e){return fb.resolve(null).then(e).catch(BS)}:$f;function BS(e){setTimeout(function(){throw e})}function Qo(e){return e==="head"}function mb(e,t){var n=t,o=0;do{var a=n.nextSibling;if(e.removeChild(n),a&&a.nodeType===8)if(n=a.data,n==="/$"||n==="/&"){if(o===0){e.removeChild(a),Di(t);return}o--}else if(n==="$"||n==="$?"||n==="$~"||n==="$!"||n==="&")o++;else if(n==="html")Gu(e.ownerDocument.documentElement);else if(n==="head"){n=e.ownerDocument.head,Gu(n);for(var i=n.firstChild;i;){var r=i.nextSibling,l=i.nodeName;i[Fr]||l==="SCRIPT"||l==="STYLE"||l==="LINK"&&i.rel.toLowerCase()==="stylesheet"||n.removeChild(i),i=r}}else n==="body"&&Gu(e.ownerDocument.body);n=a}while(n);Di(t)}function gb(e,t){var n=e;e=0;do{var o=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",n.getAttribute("style")===""&&n.removeAttribute("style")):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),o&&o.nodeType===8)if(n=o.data,n==="/$"){if(e===0)break;e--}else n!=="$"&&n!=="$?"&&n!=="$~"&&n!=="$!"||e++;n=o}while(n)}function u0(e,t,n){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display==="inline"){if(t=e.getClientRects(),t.length===1)var o=1;else for(var a=o=0;a<t.length;a++){var i=t[a];0<i.width&&0<i.height&&o++}o===1&&(e=e.style,e.display=t.length===1?"inline-block":"block",e.marginTop="-"+n.paddingTop,e.marginBottom="-"+n.paddingBottom)}}function d0(e,t){e=e.style,t=t.style;var n=t!=null?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=n==null||typeof n=="boolean"?"":(""+n).trim(),n=t!=null?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=n==null||typeof n=="boolean"?"":(""+n).trim(),e.display==="inline-block"&&(t==null?e.display=e.margin="":(n=t.display,e.display=n==null||typeof n=="boolean"?"":n,n=t.margin,n!=null?e.margin=n:(n=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=n==null||typeof n=="boolean"?"":n,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=t==null||typeof t=="boolean"?"":t)))}function f0(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position==="absolute"||t.position==="fixed",clip:t.clipPath!=="none"||t.overflow!=="visible"||t.filter!=="none"||t.mask!=="none"||t.mask!=="none"||t.borderRadius!=="0px",view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function Jd(e){var t=e.getBoundingClientRect(),n=getComputedStyle(e);return f0(t,n,e)}function LS(e){var t=e.getBoundingClientRect();t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height);var n=getComputedStyle(e);return f0(t,n,e)}function US(e){return e.documentElement.clientHeight}function jS(e){this.addEventListener("load",e),this.addEventListener("error",e)}function qS(e,t,n,o,a,i,r,l,c){var s=t.nodeType===9?t:t.ownerDocument;try{var f=s.startViewTransition({update:function(){var u=s.defaultView,d=u.navigation&&u.navigation.transition,x=s.fonts.status;o();var k=[];if(x==="loaded"&&(US(s),s.fonts.status==="loading"&&k.push(s.fonts.ready)),x=k.length,e!==null)for(var E=e.suspenseyImages,g=0,b=0;b<E.length;b++){var p=E[b];if(!p.complete){var v=p.getBoundingClientRect();if(0<v.bottom&&0<v.right&&v.top<u.innerHeight&&v.left<u.innerWidth){if(g+=E0(p),g>vc){k.length=x;break}p=new Promise(jS.bind(p)),k.push(p)}}}if(0<k.length)return u=Promise.race([Promise.all(k),new Promise(function(h){return setTimeout(h,500)})]).then(a,a),(d?Promise.allSettled([d.finished,u]):u).then(i,i);if(a(),d)return d.finished.then(i,i);i()},types:n});s.__reactViewTransition=f;var m=[];return f.ready.then(function(){for(var u=s.documentElement.getAnimations({subtree:!0}),d=0;d<u.length;d++){var x=u[d],k=x.effect,E=k.pseudoElement;if(E!=null&&E.startsWith("::view-transition")){m.push(x),x=k.getKeyframes();for(var g=E=void 0,b=!0,p=0;p<x.length;p++){var v=x[p],h=v.width;if(E===void 0)E=h;else if(E!==h){b=!1;break}if(h=v.height,g===void 0)g=h;else if(g!==h){b=!1;break}delete v.width,delete v.height,v.transform==="none"&&delete v.transform}b&&E!==void 0&&g!==void 0&&(k.setKeyframes(x),b=getComputedStyle(k.target,k.pseudoElement),b.width!==E||b.height!==g)&&(b=x[0],b.width=E,b.height=g,b=x[x.length-1],b.width=E,b.height=g,k.setKeyframes(x))}}r()},function(u){s.__reactViewTransition===f&&(s.__reactViewTransition=null);try{typeof u=="object"&&u!==null&&u.name==="InvalidStateError"&&(u.message==="View transition was skipped because document visibility state is hidden."||u.message==="Skipping view transition because document visibility state has become hidden."||u.message==="Skipping view transition because viewport size changed."||u.message==="Transition was aborted because of invalid state")&&(u=null),u!==null&&c(u)}finally{o(),a(),r()}}),f.finished.finally(function(){for(var u=0;u<m.length;u++)m[u].cancel();s.__reactViewTransition===f&&(s.__reactViewTransition=null),l()}),f}catch{return o(),a(),r(),null}}function sa(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}sa.prototype.animate=function(e,t){return t=typeof t=="number"?{duration:t}:ve({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)};sa.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),o=[],a=0;a<n.length;a++){var i=n[a].effect;i!==null&&i.target===e&&i.pseudoElement===t&&o.push(n[a])}return o};sa.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function p0(e){return{name:e,group:new sa("group",e),imagePair:new sa("image-pair",e),old:new sa("old",e),new:new sa("new",e)}}function Jt(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}Jt.prototype.addEventListener=function(e,t,n){var o=null,a=null;if(!(n!=null&&typeof n!="boolean"&&(o=n.signal||null,o!==null&&o.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var i=this._eventListeners;if(m0(i,e,t,n)===-1){var r=this,l=t;n!=null&&typeof n!="boolean"&&n.once===!0&&(l=function(c){r.removeEventListener(e,t,n),typeof t=="function"?t.call(this,c):t.handleEvent(c)}),o!==null&&(a=r.removeEventListener.bind(r,e,t,n),o.addEventListener("abort",a,{once:!0}),a=o.removeEventListener.bind(o,"abort",a)),o=Ai(n),i.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:l,cleanup:a}),Dt(this._fragmentFiber.child,!1,YS,e,l,o)}this._eventListeners=i}};function YS(e,t,n,o){return Pe(e).addEventListener(t,n,o),!1}Jt.prototype.removeEventListener=function(e,t,n){var o=this._eventListeners;if(o!==null&&(t=m0(o,e,t,n),t!==-1)){var a=o[t];n=a.attachedListener;var i=a.cleanup;a=Ai(a.optionsOrUseCapture),Dt(this._fragmentFiber.child,!1,VS,e,n,a),o.splice(t,1),i!==null&&i()}};function VS(e,t,n,o){return Pe(e).removeEventListener(t,n,o),!1}function Ai(e){return e!=null&&typeof e!="boolean"&&(e.once===!0||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function bb(e){return e==null?"c=0":typeof e=="boolean"?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")}function m0(e,t,n,o){if(e.length===0)return-1;o=bb(o);for(var a=0;a<e.length;a++){var i=e[a];if(i.type===t&&i.listener===n&&bb(i.optionsOrUseCapture)===o)return a}return-1}Jt.prototype.dispatchEvent=function(e){var t=Sa(this._fragmentFiber);if(t===null)return!0;t=Pe(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var o=t.nodeType===9?t.createComment(""):document.createTextNode("");if(n)for(var a=0;a<n.length;a++){var i=n[a];o.addEventListener(i.type,i.attachedListener,Ai(i.optionsOrUseCapture))}if(t.appendChild(o),e=o.dispatchEvent(e),n)for(a=0;a<n.length;a++)i=n[a],o.removeEventListener(i.type,i.attachedListener,Ai(i.optionsOrUseCapture));return t.removeChild(o),e}return t.dispatchEvent(e)};Jt.prototype.focus=function(e){Dt(this._fragmentFiber.child,!0,g0,e,void 0,void 0)};function g0(e,t){return e.tag===6?!1:(e=Pe(e),e2(e,t))}Jt.prototype.focusLast=function(e){var t=[];Dt(this._fragmentFiber.child,!0,Jf,t,void 0,void 0);for(var n=t.length-1;0<=n&&!g0(t[n],e);n--);};function Jf(e,t){return t.push(e),!1}Jt.prototype.blur=function(){var e=Sa(this._fragmentFiber);e!==null&&(e=Pe(e),e=Kr(e).activeElement,e!==null&&Dt(this._fragmentFiber.child,!1,KS,e,void 0,void 0))};function KS(e,t){return e.tag===6?!1:(e=Pe(e),e===t||e.contains(t)?(t.blur(),!0):!1)}Jt.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),Dt(this._fragmentFiber.child,!1,XS,e,void 0,void 0)};function XS(e,t){return e.tag===6||(e=Pe(e),t.observe(e)),!1}Jt.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),Dt(this._fragmentFiber.child,!1,GS,e,void 0,void 0);for(var n=t=0;n<yn.length;n++){var o=yn[n];o.fragmentInstance===this&&o.observer===e?e.unobserve(o.instance):yn[t++]=o}yn.length=t}};function GS(e,t){return e.tag===6||(e=Pe(e),t.unobserve(e)),!1}var yn=[],Xu=!1;function QS(e,t,n){yn.push({fragmentInstance:e,observer:t,instance:n}),Xu||(Xu=!0,t2(function(){Xu=!1;var o=yn;yn=[];for(var a=0;a<o.length;a++){var i=o[a];i.observer.unobserve(i.instance)}}))}Jt.prototype.getClientRects=function(){var e=[];return Dt(this._fragmentFiber.child,!1,ZS,e,void 0,void 0),e};function ZS(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=Pe(e),t.push.apply(t,e.getClientRects());return!1}Jt.prototype.getRootNode=function(e){var t=Sa(this._fragmentFiber);return t===null?this:Pe(t).getRootNode(e)};Jt.prototype.compareDocumentPosition=function(e){var t=Sa(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];Dt(this._fragmentFiber.child,!1,Jf,n,void 0,void 0);var o=Pe(t);if(n.length===0){if(n=o,$m(this._fragmentFiber)){e:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break e}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var a=o=n.compareDocumentPosition(e);return n===e?a=Node.DOCUMENT_POSITION_CONTAINS:o&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=Lb(t)[1],n===null?a=Node.DOCUMENT_POSITION_PRECEDING:(e=Pe(n).compareDocumentPosition(e),a=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),a|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=Pe(n[0]),a=Pe(n[n.length-1]);var i=$m(this._fragmentFiber)?t.parentElement:o;if(i==null)return Node.DOCUMENT_POSITION_DISCONNECTED;o=i.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,i=i.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_CONTAINED_BY;var r=t.compareDocumentPosition(e),l=a.compareDocumentPosition(e),c=r&Node.DOCUMENT_POSITION_CONTAINED_BY||l&Node.DOCUMENT_POSITION_CONTAINED_BY;return l=o&&i&&r&Node.DOCUMENT_POSITION_FOLLOWING&&l&Node.DOCUMENT_POSITION_PRECEDING,t=o&&t===e||i&&a===e||c||l?Node.DOCUMENT_POSITION_CONTAINED_BY:!o&&t===e||!i&&a===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:r,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||PS(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function PS(e,t,n,o,a){var i=ca(a);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!i)e:{for(;i!==null;){if(i.tag===7&&(i===t||i.alternate===t)){n=!0;break e}i=i.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(i===null)return i=a.ownerDocument,a===i||a===i.documentElement||a===i.body;e:{for(i=t,t=Sa(t);i!==null;){if(!(i.tag!==5&&i.tag!==3&&i.tag!==27||i!==t&&i.alternate!==t)){i=!0;break e}i=i.return}i=!1}return i}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!i)&&!(t=i===n)&&(t=Zu(n,i,Jm),t===null?t=!1:(Dt(t,!0,Ew,i,n),i=Wa,Wa=null,t=i!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!i)&&!(t=i===o)&&(t=Zu(o,i,Jm),t===null?t=!1:(Dt(t,!0,Tw,i,o),i=Wa,Qu=Wa=null,t=i!==null)),t):!1}function hb(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}Jt.prototype.scrollIntoView=function(e){if(typeof e=="object")throw Error(N(566));var t=[];Dt(this._fragmentFiber.child,!1,Jf,t,void 0,void 0);var n=e!==!1;if(t.length===0){var o=Lb(this._fragmentFiber);if(o=n?o[1]||o[0]||Sa(this._fragmentFiber):o[0]||o[1],o===null)return;if(o.tag===6){e=Pe(o),hb(e,n);return}if(o=Pe(o),o.nodeType!==9){if(o.nodeType===11){n="host"in o?o.host:null,n!==null&&n.scrollIntoView(e);return}o.scrollIntoView(e)}}for(o=n?t.length-1:0;o!==(n?-1:t.length);){var a=t[o];a.tag===6?(a=Pe(a),hb(a,n)):Pe(a).scrollIntoView(e),o+=n?-1:1}};function $S(e,t){return e=Pe(e),b0(e,t),!1}function b0(e,t){e.reactFragments==null&&(e.reactFragments=new Set),e.reactFragments.add(t)}function h0(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.addEventListener(a.type,a.attachedListener,Ai(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(i){for(var r=0,l=0;l<yn.length;l++){var c=yn[l];(c.fragmentInstance!==t||c.observer!==i||c.instance!==e)&&(yn[r++]=c)}yn.length=r,i.observe(e)}),b0(e,t))}function JS(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.removeEventListener(a.type,a.attachedListener,Ai(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(i){typeof i.rootMargin=="string"?QS(t,i,e):i.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function Id(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":Id(n),Ic(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(n.rel.toLowerCase()==="stylesheet")continue}e.removeChild(n)}}function IS(e,t,n,o){for(;e.nodeType===1;){var a=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[Fr])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(i=e.getAttribute("rel"),i==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(i!==a.rel||e.getAttribute("href")!==(a.href==null||a.href===""?null:a.href)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin)||e.getAttribute("title")!==(a.title==null?null:a.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(i=e.getAttribute("src"),(i!==(a.src==null?null:a.src)||e.getAttribute("type")!==(a.type==null?null:a.type)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin))&&i&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var i=a.name==null?null:""+a.name;if(a.type==="hidden"&&e.getAttribute("name")===i)return e}else return e;if(e=sn(e.nextSibling),e===null)break}return null}function FS(e,t,n){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=sn(e.nextSibling),e===null))return null;return e}function v0(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=sn(e.nextSibling),e===null))return null;return e}function Fd(e){return e.data==="$?"||e.data==="$~"}function If(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function WS(e,t){var n=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||n.readyState!=="loading")t();else{var o=function(){t(),n.removeEventListener("DOMContentLoaded",o)};n.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function sn(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var Wd=null;function vb(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"||n==="/&"){if(t===0)return sn(e.nextSibling);t--}else n!=="$"&&n!=="$!"&&n!=="$?"&&n!=="$~"&&n!=="&"||t++}e=e.nextSibling}return null}function yb(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"){if(t===0)return e;t--}else n!=="/$"&&n!=="/&"||t++}e=e.previousSibling}return null}function e2(e,t){function n(){o=!0}if(e.ownerDocument.activeElement===e)return!0;var o=!1;try{e.ownerDocument.addEventListener("focus",n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener("focus",n,!0)}return o}function t2(e){pb(function(){pb(function(t){return e(t)})})}function y0(e,t,n){switch(t=Kr(n),e){case"html":if(e=t.documentElement,!e)throw Error(N(452));return e;case"head":if(e=t.head,!e)throw Error(N(453));return e;case"body":if(e=t.body,!e)throw Error(N(454));return e;default:throw Error(N(451))}}function x0(e,t,n){for(var o in n){var a=n[o];n.hasOwnProperty(o)&&a!=null&&me(e,t,o,null,zS,a)}n.dangerouslySetInnerHTML!=null&&(e.textContent=""),e.onclick===Rn&&(e.onclick=null),Ic(e)}function Gu(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);Ic(e)}var un=new Map,xb=new Set;function Xr(e){if(typeof e.getRootNode=="function"){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var so=se.d;se.d={f:n2,r:o2,D:a2,C:i2,L:r2,m:l2,X:s2,S:c2,M:u2};function n2(){var e=so.f(),t=ds();return e||t}function o2(e){var t=Hi(e);t!==null&&t.tag===5&&t.type==="form"?av(t):so.r(e)}var ji=typeof document>"u"?null:document;function w0(e,t,n){var o=ji;if(o&&typeof t=="string"&&t){var a=rn(t);a='link[rel="'+e+'"][href="'+a+'"]',typeof n=="string"&&(a+='[crossorigin="'+n+'"]'),xb.has(a)||(xb.add(a),e={rel:e,crossOrigin:n,href:t},o.querySelector(a)===null&&(t=o.createElement("link"),st(t,"link",e),et(t),o.head.appendChild(t)))}}function a2(e){so.D(e),w0("dns-prefetch",e,null)}function i2(e,t){so.C(e,t),w0("preconnect",e,t)}function r2(e,t,n){so.L(e,t,n);var o=ji;if(o&&e&&t){var a='link[rel="preload"][as="'+rn(t)+'"]';t==="image"&&n&&n.imageSrcSet?(a+='[imagesrcset="'+rn(n.imageSrcSet)+'"]',typeof n.imageSizes=="string"&&(a+='[imagesizes="'+rn(n.imageSizes)+'"]')):a+='[href="'+rn(e)+'"]';var i=a;switch(t){case"style":i=zi(e);break;case"script":i=qi(e)}if(!(un.has(i)||(e=ve({rel:"preload",href:t==="image"&&n&&n.imageSrcSet?void 0:e,as:t},n),un.set(i,e),o.querySelector(a)!==null||t==="style"&&o.querySelector(al(i))||t==="script"&&o.querySelector(il(i))))){var r=o.createElement("link");st(r,"link",e),t==="style"&&(r[Tc]=!0,r.onload=r.onerror=function(){Jb(r)}),et(r),o.head.appendChild(r)}}}function l2(e,t){so.m(e,t);var n=ji;if(n&&e){var o=t&&typeof t.as=="string"?t.as:"script",a='link[rel="modulepreload"][as="'+rn(o)+'"][href="'+rn(e)+'"]',i=a;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":i=qi(e)}if(!un.has(i)&&(e=ve({rel:"modulepreload",href:e},t),un.set(i,e),n.querySelector(a)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector(il(i)))return}o=n.createElement("link"),st(o,"link",e),et(o),n.head.appendChild(o)}}}function c2(e,t,n){so.S(e,t,n);var o=ji;if(o&&e){var a=di(o).hoistableStyles,i=zi(e);t=t||"default";var r=a.get(i);if(!r){var l={loading:0,preload:null};if(r=o.querySelector(al(i)))l.loading=5;else{e=ve({rel:"stylesheet",href:e,"data-precedence":t},n),(n=un.get(i))&&Ff(e,n);var c=r=o.createElement("link");et(c),st(c,"link",e),c._p=new Promise(function(s,f){c.onload=s,c.onerror=f}),c.addEventListener("load",function(){l.loading|=1}),c.addEventListener("error",function(){l.loading|=2}),l.loading|=4,bc(r,t,o)}r={type:"stylesheet",instance:r,count:1,state:l},a.set(i,r)}}}function s2(e,t){so.X(e,t);var n=ji;if(n&&e){var o=di(n).hoistableScripts,a=qi(e),i=o.get(a);i||(i=n.querySelector(il(a)),i||(e=ve({src:e,async:!0},t),(t=un.get(a))&&Wf(e,t),i=n.createElement("script"),et(i),st(i,"link",e),n.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},o.set(a,i))}}function u2(e,t){so.M(e,t);var n=ji;if(n&&e){var o=di(n).hoistableScripts,a=qi(e),i=o.get(a);i||(i=n.querySelector(il(a)),i||(e=ve({src:e,async:!0,type:"module"},t),(t=un.get(a))&&Wf(e,t),i=n.createElement("script"),et(i),st(i,"link",e),n.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},o.set(a,i))}}function wb(e,t,n,o){var a=(a=zo.current)?Xr(a):null;if(!a)throw Error(N(446));switch(e){case"meta":case"title":return null;case"style":return typeof n.precedence=="string"&&typeof n.href=="string"?(n=zi(n.href),t=di(a).hoistableStyles,o=t.get(n),o||(o={type:"style",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(n.rel==="stylesheet"&&typeof n.href=="string"&&typeof n.precedence=="string"){e=zi(n.href);var i=di(a).hoistableStyles,r=i.get(e);if(r||(a=a.ownerDocument||a,r={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},i.set(e,r),(i=a.querySelector(al(e)))?i._p||(r.instance=i,r.state.loading=5):(i=un.get(e),i||(i={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},un.set(e,i)),d2(a,e,i,r.state))),t&&o===null)throw Error(N(528,""));return r}if(t&&o!==null)throw Error(N(529,""));return null;case"script":return t=n.async,n=n.src,typeof n=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(n=qi(n),t=di(a).hoistableScripts,o=t.get(n),o||(o={type:"script",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(N(444,e))}}function zi(e){return'href="'+rn(e)+'"'}function al(e){return'link[rel="stylesheet"]['+e+"]"}function k0(e){return ve({},e,{"data-precedence":e.precedence,precedence:null})}function d2(e,t,n,o){if(t=e.querySelector('link[rel="preload"][as="style"]['+t+"]")){if(t[Tc]!==!0){o.loading=1;return}}else t=e.createElement("link"),t[Tc]=!0,t.onload=t.onerror=Jb.bind(null,t),st(t,"link",n),et(t),e.head.appendChild(t);o.preload=t,t.addEventListener("load",function(){return o.loading|=1}),t.addEventListener("error",function(){return o.loading|=2})}function qi(e){return'[src="'+rn(e)+'"]'}function il(e){return"script[async]"+e}function kb(e,t,n){if(t.count++,t.instance===null)switch(t.type){case"style":var o=e.querySelector('style[data-href~="'+rn(n.href)+'"]');if(o)return t.instance=o,et(o),o;var a=ve({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),et(o),st(o,"style",a),bc(o,n.precedence,e),t.instance=o;case"stylesheet":a=zi(n.href);var i=e.querySelector(al(a));if(i)return t.state.loading|=4,t.instance=i,et(i),i;o=k0(n),(a=un.get(a))&&Ff(o,a),i=(e.ownerDocument||e).createElement("link"),et(i);var r=i;return r._p=new Promise(function(l,c){r.onload=l,r.onerror=c}),st(i,"link",o),t.state.loading|=4,bc(i,n.precedence,e),t.instance=i;case"script":return i=qi(n.src),(a=e.querySelector(il(i)))?(t.instance=a,et(a),a):(o=n,(a=un.get(i))&&(o=ve({},n),Wf(o,a)),e=e.ownerDocument||e,a=e.createElement("script"),et(a),st(a,"link",o),e.head.appendChild(a),t.instance=a);case"void":return null;default:throw Error(N(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(o=t.instance,t.state.loading|=4,bc(o,n.precedence,e));return t.instance}function bc(e,t,n){for(var o=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),a=o.length?o[o.length-1]:null,i=a,r=0;r<o.length;r++){var l=o[r];if(l.dataset.precedence===t)i=l;else if(i!==a)break}i?i.parentNode.insertBefore(e,i.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Ff(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function Wf(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var hc=null;function Sb(e,t,n){if(hc===null){var o=new Map,a=hc=new Map;a.set(n,o)}else a=hc,o=a.get(n),o||(o=new Map,a.set(n,o));if(o.has(e))return o;for(o.set(e,null),n=n.getElementsByTagName(e),a=0;a<n.length;a++){var i=n[a];if(!(i[Fr]||i[it]||e==="link"&&i.getAttribute("rel")==="stylesheet")&&i.namespaceURI!=="http://www.w3.org/2000/svg"){var r=i.getAttribute(t)||"";r=e+r;var l=o.get(r);l?l.push(i):o.set(r,[i])}}return o}function ef(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t==="title"?e.querySelector("head > title"):null)}function f2(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function Eb(e,t){return e==="img"&&t.src!=null&&t.src!==""&&t.onLoad==null&&t.loading!=="lazy"}function S0(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function E0(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function Tb(e,t){typeof t.decode=="function"&&(e.imgCount++,t.complete||(e.imgBytes+=E0(t),e.suspenseyImages.push(t)),e=g2.bind(e),t.decode().then(e,e))}function p2(e,t,n,o){if(n.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var a=zi(o.href),i=t.querySelector(al(a));if(i){t=i._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=Gr.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=i,et(i);return}i=t.ownerDocument||t,o=k0(o),(a=un.get(a))&&Ff(o,a),i=i.createElement("link"),et(i);var r=i;r._p=new Promise(function(l,c){r.onload=l,r.onerror=c}),st(i,"link",o),n.instance=i}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(e.count++,n=Gr.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}var vc=0;function m2(e,t){return e.stylesheets&&e.count===0&&yc(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var o=setTimeout(function(){if(e.stylesheets&&yc(e,e.stylesheets),e.unsuspend){var i=e.unsuspend;e.unsuspend=null,i()}},6e4+t);0<e.imgBytes&&vc===0&&(vc=62500*RS());var a=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&yc(e,e.stylesheets),e.unsuspend)){var i=e.unsuspend;e.unsuspend=null,i()}},(e.imgBytes>vc?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(a)}}:null}function T0(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)yc(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function Gr(){this.count--,T0(this)}function g2(){this.imgCount--,T0(this)}var Pc=null;function yc(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Pc=new Map,t.forEach(b2,e),Pc=null,Gr.call(e))}function b2(e,t){if(!(t.state.loading&4)){var n=Pc.get(e);if(n)var o=n.get(null);else{n=new Map,Pc.set(e,n);for(var a=e.querySelectorAll("link[data-precedence],style[data-precedence]"),i=0;i<a.length;i++){var r=a[i];(r.nodeName==="LINK"||r.getAttribute("media")!=="not all")&&(n.set(r.dataset.precedence,r),o=r)}o&&n.set(null,o)}a=t.instance,r=a.getAttribute("data-precedence"),i=n.get(r)||o,i===o&&n.set(null,a),n.set(r,a),this.count++,o=Gr.bind(this),a.addEventListener("load",o),a.addEventListener("error",o),i?i.parentNode.insertBefore(a,i.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(a,e.firstChild)),t.state.loading|=4}}var Oi={$$typeof:On,Provider:null,Consumer:null,_currentValue:ua,_currentValue2:ua,_threadCount:0};function h2(e,t,n,o,a,i,r,l,c){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=yu(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=yu(0),this.hiddenUpdates=yu(null),this.identifierPrefix=o,this.onUncaughtError=a,this.onCaughtError=i,this.onRecoverableError=r,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=c,this.transitionTypes=null,this.incompleteTransitions=new Map}function C0(e,t,n,o,a,i,r,l,c,s,f,m){return e=new h2(e,t,n,r,c,s,f,m,l),t=1,i===!0&&(t|=24),i=Ot(3,null,null,t),e.current=i,i.stateNode=e,t=yf(),t.refCount++,e.pooledCache=t,t.refCount++,i.memoizedState={element:o,isDehydrated:n,cache:t},kf(i),e}function N0(e){return e?(e=li,e):li}function M0(e,t,n,o,a,i){a=N0(a),o.context===null?o.context=a:o.pendingContext=a,o=Ro(t),o.payload={element:n},i=i===void 0?null:i,i!==null&&(o.callback=i),n=Do(e,o,t),n!==null&&(Rt(n,e,t),Sr(n,e,t))}function Cb(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function ep(e,t){Cb(e,t),(e=e.alternate)&&Cb(e,t)}function A0(e){if(e.tag===13||e.tag===31){var t=Ca(e,67108864);t!==null&&Rt(t,e,67108864),ep(e,67108864)}}function Nb(e){if(e.tag===13||e.tag===31){var t=Pt();t=lf(t);var n=Ca(e,t);n!==null&&Rt(n,e,t),ep(e,t)}}var Ri=!0;function v2(e,t,n,o){var a=V.T;V.T=null;var i=se.p;try{se.p=2,tp(e,t,n,o)}finally{se.p=i,V.T=a}}function y2(e,t,n,o){var a=V.T;V.T=null;var i=se.p;try{se.p=8,tp(e,t,n,o)}finally{se.p=i,V.T=a}}function tp(e,t,n,o){if(Ri){var a=tf(o);if(a===null)Vu(e,t,o,$c,n),Mb(e,o);else if(w2(a,e,t,n,o))o.stopPropagation();else if(Mb(e,o),t&4&&-1<x2.indexOf(e)){for(;a!==null;){var i=Hi(a);if(i!==null)switch(i.tag){case 3:if(i=i.stateNode,i.current.memoizedState.isDehydrated){var r=ia(i.pendingLanes);if(r!==0){var l=i;for(l.pendingLanes|=2,l.entangledLanes|=2;r;){var c=1<<31-Zt(r);l.entanglements[1]|=c,r&=~c}jn(i),(ce&6)===0&&(Kc=Gt()+500,ol(0,!1))}}break;case 31:case 13:l=Ca(i,2),l!==null&&Rt(l,i,2),ds(),ep(i,2)}if(i=tf(o),i===null&&Vu(e,t,o,$c,n),i===a)break;a=i}a!==null&&o.stopPropagation()}else Vu(e,t,o,null,n)}}function tf(e){return e=uf(e),np(e)}var $c=null;function np(e){if($c=null,e=ca(e),e!==null){var t=Pr(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=_b(t),e!==null)return e;e=null}else if(n===31){if(e=Hb(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return $c=e,null}function z0(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(_w()){case Yb:return 2;case Vb:return 8;case Ec:case Hw:return 32;case Kb:return 268435456;default:return 32}default:return 32}}var nf=!1,Lo=null,Uo=null,jo=null,Qr=new Map,Zr=new Map,So=[],x2="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Mb(e,t){switch(e){case"focusin":case"focusout":Lo=null;break;case"dragenter":case"dragleave":Uo=null;break;case"mouseover":case"mouseout":jo=null;break;case"pointerover":case"pointerout":Qr.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Zr.delete(t.pointerId)}}function fr(e,t,n,o,a,i){return e===null||e.nativeEvent!==i?(e={blockedOn:t,domEventName:n,eventSystemFlags:o,nativeEvent:i,targetContainers:[a]},t!==null&&(t=Hi(t),t!==null&&A0(t)),e):(e.eventSystemFlags|=o,t=e.targetContainers,a!==null&&t.indexOf(a)===-1&&t.push(a),e)}function w2(e,t,n,o,a){switch(t){case"focusin":return Lo=fr(Lo,e,t,n,o,a),!0;case"dragenter":return Uo=fr(Uo,e,t,n,o,a),!0;case"mouseover":return jo=fr(jo,e,t,n,o,a),!0;case"pointerover":var i=a.pointerId;return Qr.set(i,fr(Qr.get(i)||null,e,t,n,o,a)),!0;case"gotpointercapture":return i=a.pointerId,Zr.set(i,fr(Zr.get(i)||null,e,t,n,o,a)),!0}return!1}function O0(e){var t=ca(e.target);if(t!==null){var n=Pr(t);if(n!==null){if(t=n.tag,t===13){if(t=_b(n),t!==null){e.blockedOn=t,eg(e.priority,function(){Nb(n)});return}}else if(t===31){if(t=Hb(n),t!==null){e.blockedOn=t,eg(e.priority,function(){Nb(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function xc(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=tf(e.nativeEvent);if(n===null){n=e.nativeEvent;var o=new n.constructor(n.type,n);id=o,n.target.dispatchEvent(o),id=null}else return t=Hi(n),t!==null&&A0(t),e.blockedOn=n,!1;t.shift()}return!0}function Ab(e,t,n){xc(e)&&n.delete(t)}function k2(){nf=!1,Lo!==null&&xc(Lo)&&(Lo=null),Uo!==null&&xc(Uo)&&(Uo=null),jo!==null&&xc(jo)&&(jo=null),Qr.forEach(Ab),Zr.forEach(Ab)}function ec(e,t){e.blockedOn===t&&(e.blockedOn=null,nf||(nf=!0,$e.unstable_scheduleCallback($e.unstable_NormalPriority,k2)))}var tc=null;function zb(e){tc!==e&&(tc=e,$e.unstable_scheduleCallback($e.unstable_NormalPriority,function(){tc===e&&(tc=null);for(var t=0;t<e.length;t+=3){var n=e[t],o=e[t+1],a=e[t+2];if(typeof o!="function"){if(np(o||n)===null)continue;break}var i=Hi(n);i!==null&&(e.splice(t,3),t-=3,wd(i,{pending:!0,data:a,method:n.method,action:o},o,a))}}))}function Di(e){function t(c){return ec(c,e)}Lo!==null&&ec(Lo,e),Uo!==null&&ec(Uo,e),jo!==null&&ec(jo,e),Qr.forEach(t),Zr.forEach(t);for(var n=0;n<So.length;n++){var o=So[n];o.blockedOn===e&&(o.blockedOn=null)}for(;0<So.length&&(n=So[0],n.blockedOn===null);)O0(n),n.blockedOn===null&&So.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(o=0;o<n.length;o+=3){var a=n[o],i=n[o+1],r=a[_t]||null;if(typeof i=="function")r||zb(n);else if(r){var l=null;if(i&&i.hasAttribute("formAction")){if(a=i,r=i[_t]||null)l=r.formAction;else if(np(a)!==null)continue}else l=r.action;typeof l=="function"?n[o+1]=l:(n.splice(o,3),o-=3),zb(n)}}}function R0(){function e(i){i.canIntercept&&i.info==="react-transition"&&i.intercept({handler:function(){return new Promise(function(r){return a=r})},focusReset:"manual",scroll:"manual"})}function t(){a!==null&&(a(),a=null),o||setTimeout(n,20)}function n(){if(!o&&!navigation.transition){var i=navigation.currentEntry;i&&i.url!=null&&navigation.navigate(i.url,{state:i.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,a=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),a!==null&&(a(),a=null)}}}function op(e){this._internalRoot=e}ms.prototype.render=op.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(N(409));var n=t.current,o=Pt();M0(n,o,e,t,null,null)};ms.prototype.unmount=op.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;M0(e.current,2,null,e,null,null),ds(),t[_i]=null}};function ms(e){this._internalRoot=e}ms.prototype.unstable_scheduleHydration=function(e){if(e){var t=$b();e={blockedOn:null,target:e,priority:t};for(var n=0;n<So.length&&t!==0&&t<So[n].priority;n++);So.splice(n,0,e),n===0&&O0(e)}};var Ob=Rb.version;if(Ob!=="19.3.0")throw Error(N(527,Ob,"19.3.0"));se.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(N(188)):(e=Object.keys(e).join(","),Error(N(268,e)));return e=Sw(t),e=e!==null?Bb(e):null,e=e===null?null:e.stateNode,e};var S2={bundleType:0,version:"19.3.0",rendererPackageName:"react-dom",currentDispatcherRef:V,reconcilerVersion:"19.3.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(pr=__REACT_DEVTOOLS_GLOBAL_HOOK__,!pr.isDisabled&&pr.supportsFiber))try{$r=pr.inject(S2),Qt=pr}catch{}var pr;gs.createRoot=function(e,t){if(!Db(e))throw Error(N(299));var n=!1,o="",a=fv,i=pv,r=mv;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(o=t.identifierPrefix),t.onUncaughtError!==void 0&&(a=t.onUncaughtError),t.onCaughtError!==void 0&&(i=t.onCaughtError),t.onRecoverableError!==void 0&&(r=t.onRecoverableError)),t=C0(e,1,!1,null,null,n,o,null,a,i,r,R0),e[_i]=t.current,Pf(e),new op(t)};gs.hydrateRoot=function(e,t,n){if(!Db(e))throw Error(N(299));var o=!1,a="",i=fv,r=pv,l=mv,c=null;return n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(a=n.identifierPrefix),n.onUncaughtError!==void 0&&(i=n.onUncaughtError),n.onCaughtError!==void 0&&(r=n.onCaughtError),n.onRecoverableError!==void 0&&(l=n.onRecoverableError),n.formState!==void 0&&(c=n.formState)),t=C0(e,1,!0,t,n??null,o,a,c,i,r,l,R0),t.context=N0(null),n=t.current,o=Pt(),o=lf(o),a=Ro(o),a.callback=null,Do(n,a,o),n=o,t.current.lanes=n,Ir(t,n),jn(t),e[_i]=t.current,Pf(e),new ms(t)};gs.version="19.3.0"});var B0=En((mT,H0)=>{"use strict";function _0(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(_0)}catch(e){console.error(e)}}_0(),H0.exports=D0()});var W0=En(Cs=>{"use strict";var A2=Symbol.for("react.transitional.element"),z2=Symbol.for("react.fragment");function F0(e,t,n){var o=null;if(n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),"key"in t){n={};for(var a in t)a!=="key"&&(n[a]=t[a])}else n=t;return t=n.ref,{$$typeof:A2,type:e,key:o,ref:t!==void 0?t:null,props:n}}Cs.Fragment=z2;Cs.jsx=F0;Cs.jsxs=F0});var U=En((vT,ey)=>{"use strict";ey.exports=W0()});var gm=`/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

@font-face {
	font-family: "codicon";
	font-display: block;
	src: url("./codicon.ttf?9aab6318a6710999273bab9c78a9fd71") format("truetype");
}

.codicon[class*='codicon-'] {
	font: normal normal normal 16px/1 codicon;
	display: inline-block;
	text-decoration: none;
	text-rendering: auto;
	text-align: center;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	user-select: none;
	-webkit-user-select: none;
	-ms-user-select: none;
}

/*---------------------
 *  Modifiers
 *-------------------*/

@keyframes codicon-spin {
	100% {
		transform:rotate(360deg);
	}
}

.codicon-sync.codicon-modifier-spin,
.codicon-loading.codicon-modifier-spin,
.codicon-gear.codicon-modifier-spin {
	/* Use steps to throttle FPS to reduce CPU usage */
	animation: codicon-spin 1.5s steps(30) infinite;
}

.codicon-modifier-disabled {
	opacity: 0.5;
}

.codicon-modifier-hidden {
	opacity: 0;
}

/* custom speed & easing for loading icon */
.codicon-loading {
	animation-duration: 1s !important;
	animation-timing-function: cubic-bezier(0.53, 0.21, 0.29, 0.67) !important;
}

/*---------------------
 *  Icons
 *-------------------*/

.codicon-add:before { content: "\\ea60" }
.codicon-plus:before { content: "\\ea60" }
.codicon-gist-new:before { content: "\\ea60" }
.codicon-repo-create:before { content: "\\ea60" }
.codicon-lightbulb:before { content: "\\ea61" }
.codicon-light-bulb:before { content: "\\ea61" }
.codicon-repo:before { content: "\\ea62" }
.codicon-repo-delete:before { content: "\\ea62" }
.codicon-gist-fork:before { content: "\\ea63" }
.codicon-repo-forked:before { content: "\\ea63" }
.codicon-git-pull-request:before { content: "\\ea64" }
.codicon-git-pull-request-abandoned:before { content: "\\ea64" }
.codicon-record-keys:before { content: "\\ea65" }
.codicon-keyboard:before { content: "\\ea65" }
.codicon-tag:before { content: "\\ea66" }
.codicon-git-pull-request-label:before { content: "\\ea66" }
.codicon-tag-add:before { content: "\\ea66" }
.codicon-tag-remove:before { content: "\\ea66" }
.codicon-person:before { content: "\\ea67" }
.codicon-person-follow:before { content: "\\ea67" }
.codicon-person-outline:before { content: "\\ea67" }
.codicon-person-filled:before { content: "\\ea67" }
.codicon-source-control:before { content: "\\ea68" }
.codicon-mirror:before { content: "\\ea69" }
.codicon-mirror-public:before { content: "\\ea69" }
.codicon-star:before { content: "\\ea6a" }
.codicon-star-add:before { content: "\\ea6a" }
.codicon-star-delete:before { content: "\\ea6a" }
.codicon-star-empty:before { content: "\\ea6a" }
.codicon-comment:before { content: "\\ea6b" }
.codicon-comment-add:before { content: "\\ea6b" }
.codicon-alert:before { content: "\\ea6c" }
.codicon-warning:before { content: "\\ea6c" }
.codicon-search:before { content: "\\ea6d" }
.codicon-search-save:before { content: "\\ea6d" }
.codicon-log-out:before { content: "\\ea6e" }
.codicon-sign-out:before { content: "\\ea6e" }
.codicon-log-in:before { content: "\\ea6f" }
.codicon-sign-in:before { content: "\\ea6f" }
.codicon-eye:before { content: "\\ea70" }
.codicon-eye-unwatch:before { content: "\\ea70" }
.codicon-eye-watch:before { content: "\\ea70" }
.codicon-circle-filled:before { content: "\\ea71" }
.codicon-primitive-dot:before { content: "\\ea71" }
.codicon-close-dirty:before { content: "\\ea71" }
.codicon-debug-breakpoint:before { content: "\\ea71" }
.codicon-debug-breakpoint-disabled:before { content: "\\ea71" }
.codicon-debug-hint:before { content: "\\ea71" }
.codicon-terminal-decoration-success:before { content: "\\ea71" }
.codicon-primitive-square:before { content: "\\ea72" }
.codicon-edit:before { content: "\\ea73" }
.codicon-pencil:before { content: "\\ea73" }
.codicon-info:before { content: "\\ea74" }
.codicon-issue-opened:before { content: "\\ea74" }
.codicon-gist-private:before { content: "\\ea75" }
.codicon-git-fork-private:before { content: "\\ea75" }
.codicon-lock:before { content: "\\ea75" }
.codicon-mirror-private:before { content: "\\ea75" }
.codicon-close:before { content: "\\ea76" }
.codicon-remove-close:before { content: "\\ea76" }
.codicon-x:before { content: "\\ea76" }
.codicon-repo-sync:before { content: "\\ea77" }
.codicon-sync:before { content: "\\ea77" }
.codicon-clone:before { content: "\\ea78" }
.codicon-desktop-download:before { content: "\\ea78" }
.codicon-beaker:before { content: "\\ea79" }
.codicon-microscope:before { content: "\\ea79" }
.codicon-vm:before { content: "\\ea7a" }
.codicon-device-desktop:before { content: "\\ea7a" }
.codicon-file:before { content: "\\ea7b" }
.codicon-more:before { content: "\\ea7c" }
.codicon-ellipsis:before { content: "\\ea7c" }
.codicon-kebab-horizontal:before { content: "\\ea7c" }
.codicon-mail-reply:before { content: "\\ea7d" }
.codicon-reply:before { content: "\\ea7d" }
.codicon-organization:before { content: "\\ea7e" }
.codicon-organization-filled:before { content: "\\ea7e" }
.codicon-organization-outline:before { content: "\\ea7e" }
.codicon-new-file:before { content: "\\ea7f" }
.codicon-file-add:before { content: "\\ea7f" }
.codicon-new-folder:before { content: "\\ea80" }
.codicon-file-directory-create:before { content: "\\ea80" }
.codicon-trash:before { content: "\\ea81" }
.codicon-trashcan:before { content: "\\ea81" }
.codicon-history:before { content: "\\ea82" }
.codicon-clock:before { content: "\\ea82" }
.codicon-folder:before { content: "\\ea83" }
.codicon-file-directory:before { content: "\\ea83" }
.codicon-symbol-folder:before { content: "\\ea83" }
.codicon-logo-github:before { content: "\\ea84" }
.codicon-mark-github:before { content: "\\ea84" }
.codicon-github:before { content: "\\ea84" }
.codicon-terminal:before { content: "\\ea85" }
.codicon-console:before { content: "\\ea85" }
.codicon-repl:before { content: "\\ea85" }
.codicon-zap:before { content: "\\ea86" }
.codicon-symbol-event:before { content: "\\ea86" }
.codicon-error:before { content: "\\ea87" }
.codicon-stop:before { content: "\\ea87" }
.codicon-variable:before { content: "\\ea88" }
.codicon-symbol-variable:before { content: "\\ea88" }
.codicon-array:before { content: "\\ea8a" }
.codicon-symbol-array:before { content: "\\ea8a" }
.codicon-symbol-module:before { content: "\\ea8b" }
.codicon-symbol-package:before { content: "\\ea8b" }
.codicon-symbol-namespace:before { content: "\\ea8b" }
.codicon-symbol-object:before { content: "\\ea8b" }
.codicon-symbol-method:before { content: "\\ea8c" }
.codicon-symbol-function:before { content: "\\ea8c" }
.codicon-symbol-constructor:before { content: "\\ea8c" }
.codicon-symbol-boolean:before { content: "\\ea8f" }
.codicon-symbol-null:before { content: "\\ea8f" }
.codicon-symbol-numeric:before { content: "\\ea90" }
.codicon-symbol-number:before { content: "\\ea90" }
.codicon-symbol-structure:before { content: "\\ea91" }
.codicon-symbol-struct:before { content: "\\ea91" }
.codicon-symbol-parameter:before { content: "\\ea92" }
.codicon-symbol-type-parameter:before { content: "\\ea92" }
.codicon-symbol-key:before { content: "\\ea93" }
.codicon-symbol-text:before { content: "\\ea93" }
.codicon-symbol-reference:before { content: "\\ea94" }
.codicon-go-to-file:before { content: "\\ea94" }
.codicon-symbol-enum:before { content: "\\ea95" }
.codicon-symbol-value:before { content: "\\ea95" }
.codicon-symbol-ruler:before { content: "\\ea96" }
.codicon-symbol-unit:before { content: "\\ea96" }
.codicon-activate-breakpoints:before { content: "\\ea97" }
.codicon-archive:before { content: "\\ea98" }
.codicon-arrow-both:before { content: "\\ea99" }
.codicon-arrow-down:before { content: "\\ea9a" }
.codicon-arrow-left:before { content: "\\ea9b" }
.codicon-arrow-right:before { content: "\\ea9c" }
.codicon-arrow-small-down:before { content: "\\ea9d" }
.codicon-arrow-small-left:before { content: "\\ea9e" }
.codicon-arrow-small-right:before { content: "\\ea9f" }
.codicon-arrow-small-up:before { content: "\\eaa0" }
.codicon-arrow-up:before { content: "\\eaa1" }
.codicon-bell:before { content: "\\eaa2" }
.codicon-bold:before { content: "\\eaa3" }
.codicon-book:before { content: "\\eaa4" }
.codicon-bookmark:before { content: "\\eaa5" }
.codicon-debug-breakpoint-conditional-unverified:before { content: "\\eaa6" }
.codicon-debug-breakpoint-conditional:before { content: "\\eaa7" }
.codicon-debug-breakpoint-conditional-disabled:before { content: "\\eaa7" }
.codicon-debug-breakpoint-data-unverified:before { content: "\\eaa8" }
.codicon-debug-breakpoint-data:before { content: "\\eaa9" }
.codicon-debug-breakpoint-data-disabled:before { content: "\\eaa9" }
.codicon-debug-breakpoint-log-unverified:before { content: "\\eaaa" }
.codicon-debug-breakpoint-log:before { content: "\\eaab" }
.codicon-debug-breakpoint-log-disabled:before { content: "\\eaab" }
.codicon-briefcase:before { content: "\\eaac" }
.codicon-broadcast:before { content: "\\eaad" }
.codicon-browser:before { content: "\\eaae" }
.codicon-bug:before { content: "\\eaaf" }
.codicon-calendar:before { content: "\\eab0" }
.codicon-case-sensitive:before { content: "\\eab1" }
.codicon-check:before { content: "\\eab2" }
.codicon-checklist:before { content: "\\eab3" }
.codicon-chevron-down:before { content: "\\eab4" }
.codicon-chevron-left:before { content: "\\eab5" }
.codicon-chevron-right:before { content: "\\eab6" }
.codicon-chevron-up:before { content: "\\eab7" }
.codicon-chrome-close:before { content: "\\eab8" }
.codicon-chrome-maximize:before { content: "\\eab9" }
.codicon-chrome-minimize:before { content: "\\eaba" }
.codicon-chrome-restore:before { content: "\\eabb" }
.codicon-circle-outline:before { content: "\\eabc" }
.codicon-circle:before { content: "\\eabc" }
.codicon-debug-breakpoint-unverified:before { content: "\\eabc" }
.codicon-terminal-decoration-incomplete:before { content: "\\eabc" }
.codicon-circle-slash:before { content: "\\eabd" }
.codicon-circuit-board:before { content: "\\eabe" }
.codicon-clear-all:before { content: "\\eabf" }
.codicon-clippy:before { content: "\\eac0" }
.codicon-close-all:before { content: "\\eac1" }
.codicon-cloud-download:before { content: "\\eac2" }
.codicon-cloud-upload:before { content: "\\eac3" }
.codicon-code:before { content: "\\eac4" }
.codicon-collapse-all:before { content: "\\eac5" }
.codicon-color-mode:before { content: "\\eac6" }
.codicon-comment-discussion:before { content: "\\eac7" }
.codicon-credit-card:before { content: "\\eac9" }
.codicon-dash:before { content: "\\eacc" }
.codicon-dashboard:before { content: "\\eacd" }
.codicon-database:before { content: "\\eace" }
.codicon-debug-continue:before { content: "\\eacf" }
.codicon-debug-disconnect:before { content: "\\ead0" }
.codicon-debug-pause:before { content: "\\ead1" }
.codicon-debug-restart:before { content: "\\ead2" }
.codicon-debug-start:before { content: "\\ead3" }
.codicon-debug-step-into:before { content: "\\ead4" }
.codicon-debug-step-out:before { content: "\\ead5" }
.codicon-debug-step-over:before { content: "\\ead6" }
.codicon-debug-stop:before { content: "\\ead7" }
.codicon-debug:before { content: "\\ead8" }
.codicon-device-camera-video:before { content: "\\ead9" }
.codicon-device-camera:before { content: "\\eada" }
.codicon-device-mobile:before { content: "\\eadb" }
.codicon-diff-added:before { content: "\\eadc" }
.codicon-diff-ignored:before { content: "\\eadd" }
.codicon-diff-modified:before { content: "\\eade" }
.codicon-diff-removed:before { content: "\\eadf" }
.codicon-diff-renamed:before { content: "\\eae0" }
.codicon-diff:before { content: "\\eae1" }
.codicon-diff-sidebyside:before { content: "\\eae1" }
.codicon-discard:before { content: "\\eae2" }
.codicon-editor-layout:before { content: "\\eae3" }
.codicon-empty-window:before { content: "\\eae4" }
.codicon-exclude:before { content: "\\eae5" }
.codicon-extensions:before { content: "\\eae6" }
.codicon-eye-closed:before { content: "\\eae7" }
.codicon-file-binary:before { content: "\\eae8" }
.codicon-file-code:before { content: "\\eae9" }
.codicon-file-media:before { content: "\\eaea" }
.codicon-file-pdf:before { content: "\\eaeb" }
.codicon-file-submodule:before { content: "\\eaec" }
.codicon-file-symlink-directory:before { content: "\\eaed" }
.codicon-file-symlink-file:before { content: "\\eaee" }
.codicon-file-zip:before { content: "\\eaef" }
.codicon-files:before { content: "\\eaf0" }
.codicon-filter:before { content: "\\eaf1" }
.codicon-flame:before { content: "\\eaf2" }
.codicon-fold-down:before { content: "\\eaf3" }
.codicon-fold-up:before { content: "\\eaf4" }
.codicon-fold:before { content: "\\eaf5" }
.codicon-folder-active:before { content: "\\eaf6" }
.codicon-folder-opened:before { content: "\\eaf7" }
.codicon-gear:before { content: "\\eaf8" }
.codicon-gift:before { content: "\\eaf9" }
.codicon-gist-secret:before { content: "\\eafa" }
.codicon-gist:before { content: "\\eafb" }
.codicon-git-commit:before { content: "\\eafc" }
.codicon-git-compare:before { content: "\\eafd" }
.codicon-compare-changes:before { content: "\\eafd" }
.codicon-git-merge:before { content: "\\eafe" }
.codicon-github-action:before { content: "\\eaff" }
.codicon-github-alt:before { content: "\\eb00" }
.codicon-globe:before { content: "\\eb01" }
.codicon-grabber:before { content: "\\eb02" }
.codicon-graph:before { content: "\\eb03" }
.codicon-gripper:before { content: "\\eb04" }
.codicon-heart:before { content: "\\eb05" }
.codicon-home:before { content: "\\eb06" }
.codicon-horizontal-rule:before { content: "\\eb07" }
.codicon-hubot:before { content: "\\eb08" }
.codicon-inbox:before { content: "\\eb09" }
.codicon-issue-reopened:before { content: "\\eb0b" }
.codicon-issues:before { content: "\\eb0c" }
.codicon-italic:before { content: "\\eb0d" }
.codicon-jersey:before { content: "\\eb0e" }
.codicon-json:before { content: "\\eb0f" }
.codicon-bracket:before { content: "\\eb0f" }
.codicon-kebab-vertical:before { content: "\\eb10" }
.codicon-key:before { content: "\\eb11" }
.codicon-law:before { content: "\\eb12" }
.codicon-lightbulb-autofix:before { content: "\\eb13" }
.codicon-link-external:before { content: "\\eb14" }
.codicon-link:before { content: "\\eb15" }
.codicon-list-ordered:before { content: "\\eb16" }
.codicon-list-unordered:before { content: "\\eb17" }
.codicon-live-share:before { content: "\\eb18" }
.codicon-loading:before { content: "\\eb19" }
.codicon-location:before { content: "\\eb1a" }
.codicon-mail-read:before { content: "\\eb1b" }
.codicon-mail:before { content: "\\eb1c" }
.codicon-markdown:before { content: "\\eb1d" }
.codicon-megaphone:before { content: "\\eb1e" }
.codicon-mention:before { content: "\\eb1f" }
.codicon-milestone:before { content: "\\eb20" }
.codicon-git-pull-request-milestone:before { content: "\\eb20" }
.codicon-mortar-board:before { content: "\\eb21" }
.codicon-move:before { content: "\\eb22" }
.codicon-multiple-windows:before { content: "\\eb23" }
.codicon-mute:before { content: "\\eb24" }
.codicon-no-newline:before { content: "\\eb25" }
.codicon-note:before { content: "\\eb26" }
.codicon-octoface:before { content: "\\eb27" }
.codicon-open-preview:before { content: "\\eb28" }
.codicon-package:before { content: "\\eb29" }
.codicon-paintcan:before { content: "\\eb2a" }
.codicon-pin:before { content: "\\eb2b" }
.codicon-play:before { content: "\\eb2c" }
.codicon-run:before { content: "\\eb2c" }
.codicon-plug:before { content: "\\eb2d" }
.codicon-preserve-case:before { content: "\\eb2e" }
.codicon-preview:before { content: "\\eb2f" }
.codicon-project:before { content: "\\eb30" }
.codicon-pulse:before { content: "\\eb31" }
.codicon-question:before { content: "\\eb32" }
.codicon-quote:before { content: "\\eb33" }
.codicon-radio-tower:before { content: "\\eb34" }
.codicon-reactions:before { content: "\\eb35" }
.codicon-references:before { content: "\\eb36" }
.codicon-refresh:before { content: "\\eb37" }
.codicon-regex:before { content: "\\eb38" }
.codicon-remote-explorer:before { content: "\\eb39" }
.codicon-remote:before { content: "\\eb3a" }
.codicon-remove:before { content: "\\eb3b" }
.codicon-replace-all:before { content: "\\eb3c" }
.codicon-replace:before { content: "\\eb3d" }
.codicon-repo-clone:before { content: "\\eb3e" }
.codicon-repo-force-push:before { content: "\\eb3f" }
.codicon-repo-pull:before { content: "\\eb40" }
.codicon-repo-push:before { content: "\\eb41" }
.codicon-report:before { content: "\\eb42" }
.codicon-request-changes:before { content: "\\eb43" }
.codicon-rocket:before { content: "\\eb44" }
.codicon-root-folder-opened:before { content: "\\eb45" }
.codicon-root-folder:before { content: "\\eb46" }
.codicon-rss:before { content: "\\eb47" }
.codicon-ruby:before { content: "\\eb48" }
.codicon-save-all:before { content: "\\eb49" }
.codicon-save-as:before { content: "\\eb4a" }
.codicon-save:before { content: "\\eb4b" }
.codicon-screen-full:before { content: "\\eb4c" }
.codicon-screen-normal:before { content: "\\eb4d" }
.codicon-search-stop:before { content: "\\eb4e" }
.codicon-server:before { content: "\\eb50" }
.codicon-settings-gear:before { content: "\\eb51" }
.codicon-settings:before { content: "\\eb52" }
.codicon-shield:before { content: "\\eb53" }
.codicon-smiley:before { content: "\\eb54" }
.codicon-sort-precedence:before { content: "\\eb55" }
.codicon-split-horizontal:before { content: "\\eb56" }
.codicon-split-vertical:before { content: "\\eb57" }
.codicon-squirrel:before { content: "\\eb58" }
.codicon-star-full:before { content: "\\eb59" }
.codicon-star-half:before { content: "\\eb5a" }
.codicon-symbol-class:before { content: "\\eb5b" }
.codicon-symbol-color:before { content: "\\eb5c" }
.codicon-symbol-constant:before { content: "\\eb5d" }
.codicon-symbol-enum-member:before { content: "\\eb5e" }
.codicon-symbol-field:before { content: "\\eb5f" }
.codicon-symbol-file:before { content: "\\eb60" }
.codicon-symbol-interface:before { content: "\\eb61" }
.codicon-symbol-keyword:before { content: "\\eb62" }
.codicon-symbol-misc:before { content: "\\eb63" }
.codicon-symbol-operator:before { content: "\\eb64" }
.codicon-symbol-property:before { content: "\\eb65" }
.codicon-wrench:before { content: "\\eb65" }
.codicon-wrench-subaction:before { content: "\\eb65" }
.codicon-symbol-snippet:before { content: "\\eb66" }
.codicon-tasklist:before { content: "\\eb67" }
.codicon-telescope:before { content: "\\eb68" }
.codicon-text-size:before { content: "\\eb69" }
.codicon-three-bars:before { content: "\\eb6a" }
.codicon-thumbsdown:before { content: "\\eb6b" }
.codicon-thumbsup:before { content: "\\eb6c" }
.codicon-tools:before { content: "\\eb6d" }
.codicon-triangle-down:before { content: "\\eb6e" }
.codicon-triangle-left:before { content: "\\eb6f" }
.codicon-triangle-right:before { content: "\\eb70" }
.codicon-triangle-up:before { content: "\\eb71" }
.codicon-twitter:before { content: "\\eb72" }
.codicon-unfold:before { content: "\\eb73" }
.codicon-unlock:before { content: "\\eb74" }
.codicon-unmute:before { content: "\\eb75" }
.codicon-unverified:before { content: "\\eb76" }
.codicon-verified:before { content: "\\eb77" }
.codicon-versions:before { content: "\\eb78" }
.codicon-vm-active:before { content: "\\eb79" }
.codicon-vm-outline:before { content: "\\eb7a" }
.codicon-vm-running:before { content: "\\eb7b" }
.codicon-watch:before { content: "\\eb7c" }
.codicon-whitespace:before { content: "\\eb7d" }
.codicon-whole-word:before { content: "\\eb7e" }
.codicon-window:before { content: "\\eb7f" }
.codicon-word-wrap:before { content: "\\eb80" }
.codicon-zoom-in:before { content: "\\eb81" }
.codicon-zoom-out:before { content: "\\eb82" }
.codicon-list-filter:before { content: "\\eb83" }
.codicon-list-flat:before { content: "\\eb84" }
.codicon-list-selection:before { content: "\\eb85" }
.codicon-selection:before { content: "\\eb85" }
.codicon-list-tree:before { content: "\\eb86" }
.codicon-debug-breakpoint-function-unverified:before { content: "\\eb87" }
.codicon-debug-breakpoint-function:before { content: "\\eb88" }
.codicon-debug-breakpoint-function-disabled:before { content: "\\eb88" }
.codicon-debug-stackframe-active:before { content: "\\eb89" }
.codicon-circle-small-filled:before { content: "\\eb8a" }
.codicon-debug-stackframe-dot:before { content: "\\eb8a" }
.codicon-terminal-decoration-mark:before { content: "\\eb8a" }
.codicon-debug-stackframe:before { content: "\\eb8b" }
.codicon-debug-stackframe-focused:before { content: "\\eb8b" }
.codicon-debug-breakpoint-unsupported:before { content: "\\eb8c" }
.codicon-symbol-string:before { content: "\\eb8d" }
.codicon-debug-reverse-continue:before { content: "\\eb8e" }
.codicon-debug-step-back:before { content: "\\eb8f" }
.codicon-debug-restart-frame:before { content: "\\eb90" }
.codicon-debug-alt:before { content: "\\eb91" }
.codicon-call-incoming:before { content: "\\eb92" }
.codicon-call-outgoing:before { content: "\\eb93" }
.codicon-menu:before { content: "\\eb94" }
.codicon-expand-all:before { content: "\\eb95" }
.codicon-feedback:before { content: "\\eb96" }
.codicon-git-pull-request-reviewer:before { content: "\\eb96" }
.codicon-group-by-ref-type:before { content: "\\eb97" }
.codicon-ungroup-by-ref-type:before { content: "\\eb98" }
.codicon-account:before { content: "\\eb99" }
.codicon-git-pull-request-assignee:before { content: "\\eb99" }
.codicon-bell-dot:before { content: "\\eb9a" }
.codicon-debug-console:before { content: "\\eb9b" }
.codicon-library:before { content: "\\eb9c" }
.codicon-output:before { content: "\\eb9d" }
.codicon-run-all:before { content: "\\eb9e" }
.codicon-sync-ignored:before { content: "\\eb9f" }
.codicon-pinned:before { content: "\\eba0" }
.codicon-github-inverted:before { content: "\\eba1" }
.codicon-server-process:before { content: "\\eba2" }
.codicon-server-environment:before { content: "\\eba3" }
.codicon-pass:before { content: "\\eba4" }
.codicon-issue-closed:before { content: "\\eba4" }
.codicon-stop-circle:before { content: "\\eba5" }
.codicon-play-circle:before { content: "\\eba6" }
.codicon-record:before { content: "\\eba7" }
.codicon-debug-alt-small:before { content: "\\eba8" }
.codicon-vm-connect:before { content: "\\eba9" }
.codicon-cloud:before { content: "\\ebaa" }
.codicon-merge:before { content: "\\ebab" }
.codicon-export:before { content: "\\ebac" }
.codicon-graph-left:before { content: "\\ebad" }
.codicon-magnet:before { content: "\\ebae" }
.codicon-notebook:before { content: "\\ebaf" }
.codicon-redo:before { content: "\\ebb0" }
.codicon-check-all:before { content: "\\ebb1" }
.codicon-pinned-dirty:before { content: "\\ebb2" }
.codicon-pass-filled:before { content: "\\ebb3" }
.codicon-circle-large-filled:before { content: "\\ebb4" }
.codicon-circle-large:before { content: "\\ebb5" }
.codicon-circle-large-outline:before { content: "\\ebb5" }
.codicon-combine:before { content: "\\ebb6" }
.codicon-gather:before { content: "\\ebb6" }
.codicon-table:before { content: "\\ebb7" }
.codicon-variable-group:before { content: "\\ebb8" }
.codicon-type-hierarchy:before { content: "\\ebb9" }
.codicon-type-hierarchy-sub:before { content: "\\ebba" }
.codicon-type-hierarchy-super:before { content: "\\ebbb" }
.codicon-git-pull-request-create:before { content: "\\ebbc" }
.codicon-run-above:before { content: "\\ebbd" }
.codicon-run-below:before { content: "\\ebbe" }
.codicon-notebook-template:before { content: "\\ebbf" }
.codicon-debug-rerun:before { content: "\\ebc0" }
.codicon-workspace-trusted:before { content: "\\ebc1" }
.codicon-workspace-untrusted:before { content: "\\ebc2" }
.codicon-workspace-unknown:before { content: "\\ebc3" }
.codicon-terminal-cmd:before { content: "\\ebc4" }
.codicon-terminal-debian:before { content: "\\ebc5" }
.codicon-terminal-linux:before { content: "\\ebc6" }
.codicon-terminal-powershell:before { content: "\\ebc7" }
.codicon-terminal-tmux:before { content: "\\ebc8" }
.codicon-terminal-ubuntu:before { content: "\\ebc9" }
.codicon-terminal-bash:before { content: "\\ebca" }
.codicon-arrow-swap:before { content: "\\ebcb" }
.codicon-copy:before { content: "\\ebcc" }
.codicon-person-add:before { content: "\\ebcd" }
.codicon-filter-filled:before { content: "\\ebce" }
.codicon-wand:before { content: "\\ebcf" }
.codicon-debug-line-by-line:before { content: "\\ebd0" }
.codicon-inspect:before { content: "\\ebd1" }
.codicon-layers:before { content: "\\ebd2" }
.codicon-layers-dot:before { content: "\\ebd3" }
.codicon-layers-active:before { content: "\\ebd4" }
.codicon-compass:before { content: "\\ebd5" }
.codicon-compass-dot:before { content: "\\ebd6" }
.codicon-compass-active:before { content: "\\ebd7" }
.codicon-azure:before { content: "\\ebd8" }
.codicon-issue-draft:before { content: "\\ebd9" }
.codicon-git-pull-request-closed:before { content: "\\ebda" }
.codicon-git-pull-request-draft:before { content: "\\ebdb" }
.codicon-debug-all:before { content: "\\ebdc" }
.codicon-debug-coverage:before { content: "\\ebdd" }
.codicon-run-errors:before { content: "\\ebde" }
.codicon-folder-library:before { content: "\\ebdf" }
.codicon-debug-continue-small:before { content: "\\ebe0" }
.codicon-beaker-stop:before { content: "\\ebe1" }
.codicon-graph-line:before { content: "\\ebe2" }
.codicon-graph-scatter:before { content: "\\ebe3" }
.codicon-pie-chart:before { content: "\\ebe4" }
.codicon-bracket-dot:before { content: "\\ebe5" }
.codicon-bracket-error:before { content: "\\ebe6" }
.codicon-lock-small:before { content: "\\ebe7" }
.codicon-azure-devops:before { content: "\\ebe8" }
.codicon-verified-filled:before { content: "\\ebe9" }
.codicon-newline:before { content: "\\ebea" }
.codicon-layout:before { content: "\\ebeb" }
.codicon-layout-activitybar-left:before { content: "\\ebec" }
.codicon-layout-activitybar-right:before { content: "\\ebed" }
.codicon-layout-panel-left:before { content: "\\ebee" }
.codicon-layout-panel-center:before { content: "\\ebef" }
.codicon-layout-panel-justify:before { content: "\\ebf0" }
.codicon-layout-panel-right:before { content: "\\ebf1" }
.codicon-layout-panel:before { content: "\\ebf2" }
.codicon-layout-sidebar-left:before { content: "\\ebf3" }
.codicon-layout-sidebar-right:before { content: "\\ebf4" }
.codicon-layout-statusbar:before { content: "\\ebf5" }
.codicon-layout-menubar:before { content: "\\ebf6" }
.codicon-layout-centered:before { content: "\\ebf7" }
.codicon-target:before { content: "\\ebf8" }
.codicon-indent:before { content: "\\ebf9" }
.codicon-record-small:before { content: "\\ebfa" }
.codicon-error-small:before { content: "\\ebfb" }
.codicon-terminal-decoration-error:before { content: "\\ebfb" }
.codicon-arrow-circle-down:before { content: "\\ebfc" }
.codicon-arrow-circle-left:before { content: "\\ebfd" }
.codicon-arrow-circle-right:before { content: "\\ebfe" }
.codicon-arrow-circle-up:before { content: "\\ebff" }
.codicon-layout-sidebar-right-off:before { content: "\\ec00" }
.codicon-layout-panel-off:before { content: "\\ec01" }
.codicon-layout-sidebar-left-off:before { content: "\\ec02" }
.codicon-blank:before { content: "\\ec03" }
.codicon-heart-filled:before { content: "\\ec04" }
.codicon-map:before { content: "\\ec05" }
.codicon-map-horizontal:before { content: "\\ec05" }
.codicon-fold-horizontal:before { content: "\\ec05" }
.codicon-map-filled:before { content: "\\ec06" }
.codicon-map-horizontal-filled:before { content: "\\ec06" }
.codicon-fold-horizontal-filled:before { content: "\\ec06" }
.codicon-circle-small:before { content: "\\ec07" }
.codicon-bell-slash:before { content: "\\ec08" }
.codicon-bell-slash-dot:before { content: "\\ec09" }
.codicon-comment-unresolved:before { content: "\\ec0a" }
.codicon-git-pull-request-go-to-changes:before { content: "\\ec0b" }
.codicon-git-pull-request-new-changes:before { content: "\\ec0c" }
.codicon-search-fuzzy:before { content: "\\ec0d" }
.codicon-comment-draft:before { content: "\\ec0e" }
.codicon-send:before { content: "\\ec0f" }
.codicon-sparkle:before { content: "\\ec10" }
.codicon-insert:before { content: "\\ec11" }
.codicon-mic:before { content: "\\ec12" }
.codicon-thumbsdown-filled:before { content: "\\ec13" }
.codicon-thumbsup-filled:before { content: "\\ec14" }
.codicon-coffee:before { content: "\\ec15" }
.codicon-snake:before { content: "\\ec16" }
.codicon-game:before { content: "\\ec17" }
.codicon-vr:before { content: "\\ec18" }
.codicon-chip:before { content: "\\ec19" }
.codicon-piano:before { content: "\\ec1a" }
.codicon-music:before { content: "\\ec1b" }
.codicon-mic-filled:before { content: "\\ec1c" }
.codicon-repo-fetch:before { content: "\\ec1d" }
.codicon-copilot:before { content: "\\ec1e" }
.codicon-lightbulb-sparkle:before { content: "\\ec1f" }
.codicon-robot:before { content: "\\ec20" }
.codicon-sparkle-filled:before { content: "\\ec21" }
.codicon-diff-single:before { content: "\\ec22" }
.codicon-diff-multiple:before { content: "\\ec23" }
.codicon-surround-with:before { content: "\\ec24" }
.codicon-share:before { content: "\\ec25" }
.codicon-git-stash:before { content: "\\ec26" }
.codicon-git-stash-apply:before { content: "\\ec27" }
.codicon-git-stash-pop:before { content: "\\ec28" }
.codicon-vscode:before { content: "\\ec29" }
.codicon-vscode-insiders:before { content: "\\ec2a" }
.codicon-code-oss:before { content: "\\ec2b" }
.codicon-run-coverage:before { content: "\\ec2c" }
.codicon-run-all-coverage:before { content: "\\ec2d" }
.codicon-coverage:before { content: "\\ec2e" }
.codicon-github-project:before { content: "\\ec2f" }
.codicon-map-vertical:before { content: "\\ec30" }
.codicon-fold-vertical:before { content: "\\ec30" }
.codicon-map-vertical-filled:before { content: "\\ec31" }
.codicon-fold-vertical-filled:before { content: "\\ec31" }
.codicon-go-to-search:before { content: "\\ec32" }
.codicon-percentage:before { content: "\\ec33" }
.codicon-sort-percentage:before { content: "\\ec33" }
.codicon-attach:before { content: "\\ec34" }
.codicon-go-to-editing-session:before { content: "\\ec35" }
.codicon-edit-session:before { content: "\\ec36" }
.codicon-code-review:before { content: "\\ec37" }
.codicon-copilot-warning:before { content: "\\ec38" }
.codicon-python:before { content: "\\ec39" }
.codicon-copilot-large:before { content: "\\ec3a" }
.codicon-copilot-warning-large:before { content: "\\ec3b" }
.codicon-keyboard-tab:before { content: "\\ec3c" }
.codicon-copilot-blocked:before { content: "\\ec3d" }
.codicon-copilot-not-connected:before { content: "\\ec3e" }
.codicon-flag:before { content: "\\ec3f" }
.codicon-lightbulb-empty:before { content: "\\ec40" }
.codicon-symbol-method-arrow:before { content: "\\ec41" }
.codicon-copilot-unavailable:before { content: "\\ec42" }
.codicon-repo-pinned:before { content: "\\ec43" }
.codicon-keyboard-tab-above:before { content: "\\ec44" }
.codicon-keyboard-tab-below:before { content: "\\ec45" }
.codicon-git-pull-request-done:before { content: "\\ec46" }
.codicon-mcp:before { content: "\\ec47" }
.codicon-extensions-large:before { content: "\\ec48" }
.codicon-layout-panel-dock:before { content: "\\ec49" }
.codicon-layout-sidebar-left-dock:before { content: "\\ec4a" }
.codicon-layout-sidebar-right-dock:before { content: "\\ec4b" }
.codicon-copilot-in-progress:before { content: "\\ec4c" }
.codicon-copilot-error:before { content: "\\ec4d" }
.codicon-copilot-success:before { content: "\\ec4e" }
.codicon-chat-sparkle:before { content: "\\ec4f" }
.codicon-search-sparkle:before { content: "\\ec50" }
.codicon-edit-sparkle:before { content: "\\ec51" }
.codicon-copilot-snooze:before { content: "\\ec52" }
.codicon-send-to-remote-agent:before { content: "\\ec53" }
.codicon-comment-discussion-sparkle:before { content: "\\ec54" }
.codicon-chat-sparkle-warning:before { content: "\\ec55" }
.codicon-chat-sparkle-error:before { content: "\\ec56" }
.codicon-collection:before { content: "\\ec57" }
.codicon-new-collection:before { content: "\\ec58" }
.codicon-thinking:before { content: "\\ec59" }
.codicon-build:before { content: "\\ec5a" }
.codicon-comment-discussion-quote:before { content: "\\ec5b" }
.codicon-cursor:before { content: "\\ec5c" }
.codicon-eraser:before { content: "\\ec5d" }
.codicon-file-text:before { content: "\\ec5e" }
.codicon-quotes:before { content: "\\ec60" }
.codicon-rename:before { content: "\\ec61" }
.codicon-run-with-deps:before { content: "\\ec62" }
.codicon-debug-connected:before { content: "\\ec63" }
.codicon-strikethrough:before { content: "\\ec64" }
.codicon-open-in-product:before { content: "\\ec65" }
.codicon-index-zero:before { content: "\\ec66" }
.codicon-agent:before { content: "\\ec67" }
.codicon-edit-code:before { content: "\\ec68" }
.codicon-repo-selected:before { content: "\\ec69" }
.codicon-skip:before { content: "\\ec6a" }
.codicon-merge-into:before { content: "\\ec6b" }
.codicon-git-branch-changes:before { content: "\\ec6c" }
.codicon-git-branch-staged-changes:before { content: "\\ec6d" }
.codicon-git-branch-conflicts:before { content: "\\ec6e" }
.codicon-git-branch:before { content: "\\ec6f" }
.codicon-git-branch-create:before { content: "\\ec6f" }
.codicon-git-branch-delete:before { content: "\\ec6f" }
.codicon-search-large:before { content: "\\ec70" }
.codicon-terminal-git-bash:before { content: "\\ec71" }
.codicon-window-active:before { content: "\\ec72" }
.codicon-forward:before { content: "\\ec73" }
.codicon-download:before { content: "\\ec74" }
.codicon-clockface:before { content: "\\ec75" }
.codicon-unarchive:before { content: "\\ec76" }
.codicon-session-in-progress:before { content: "\\ec77" }
.codicon-collection-small:before { content: "\\ec78" }
.codicon-vm-small:before { content: "\\ec79" }
.codicon-cloud-small:before { content: "\\ec7a" }
.codicon-add-small:before { content: "\\ec7b" }
.codicon-remove-small:before { content: "\\ec7c" }
.codicon-worktree-small:before { content: "\\ec7d" }
.codicon-worktree:before { content: "\\ec7e" }
.codicon-screen-cut:before { content: "\\ec7f" }
.codicon-ask:before { content: "\\ec80" }
.codicon-openai:before { content: "\\ec81" }
.codicon-claude:before { content: "\\ec82" }
.codicon-open-in-window:before { content: "\\ec83" }
.codicon-new-session:before { content: "\\ec84" }
.codicon-terminal-secure:before { content: "\\ec85" }
.codicon-chat-import:before { content: "\\ec86" }
.codicon-chat-export:before { content: "\\ec87" }
.codicon-share-window:before { content: "\\ec88" }
.codicon-circle-slash-compact:before { content: "\\ec89" }
.codicon-copilot-compact:before { content: "\\ec8a" }
.codicon-folder-opened-compact:before { content: "\\ec8b" }
.codicon-folder-compact:before { content: "\\ec8c" }
.codicon-gear-compact:before { content: "\\ec8d" }
.codicon-git-branch-compact:before { content: "\\ec8e" }
.codicon-library-compact:before { content: "\\ec8f" }
.codicon-record-keys-compact:before { content: "\\ec90" }
.codicon-remote-compact:before { content: "\\ec91" }
.codicon-repo-forked-compact:before { content: "\\ec92" }
.codicon-repo-compact:before { content: "\\ec93" }
.codicon-shield-compact:before { content: "\\ec94" }
.codicon-sparkle-compact:before { content: "\\ec95" }
.codicon-symbol-color-compact:before { content: "\\ec96" }
.codicon-window-compact:before { content: "\\ec97" }
.codicon-error-compact:before { content: "\\ec98" }
.codicon-warning-compact:before { content: "\\ec99" }
.codicon-pass-compact:before { content: "\\ec9a" }
.codicon-important:before { content: "\\ec9b" }
.codicon-important-compact:before { content: "\\ec9c" }
.codicon-rocket-compact:before { content: "\\ec9d" }
.codicon-unpin:before { content: "\\ec9e" }
.codicon-add-compact:before { content: "\\ec9f" }
.codicon-attach-compact:before { content: "\\eca0" }
.codicon-beaker-compact:before { content: "\\eca1" }
.codicon-check-compact:before { content: "\\eca2" }
.codicon-checklist-compact:before { content: "\\eca3" }
.codicon-chevron-down-compact:before { content: "\\eca4" }
.codicon-chevron-left-compact:before { content: "\\eca5" }
.codicon-chevron-right-compact:before { content: "\\eca6" }
.codicon-chevron-up-compact:before { content: "\\eca7" }
.codicon-circle-filled-compact:before { content: "\\eca8" }
.codicon-circle-small-filled-compact:before { content: "\\eca9" }
.codicon-close-compact:before { content: "\\ecaa" }
.codicon-collapse-all-compact:before { content: "\\ecab" }
.codicon-comment-compact:before { content: "\\ecac" }
.codicon-comment-unresolved-compact:before { content: "\\ecad" }
.codicon-debug-connected-compact:before { content: "\\ecae" }
.codicon-debug-disconnect-compact:before { content: "\\ecaf" }
.codicon-edit-compact:before { content: "\\ecb0" }
.codicon-file-media-compact:before { content: "\\ecb1" }
.codicon-git-fetch:before { content: "\\ecb2" }
.codicon-lightbulb-compact:before { content: "\\ecb3" }
.codicon-loading-compact:before { content: "\\ecb4" }
.codicon-pass-filled-compact:before { content: "\\ecb5" }
.codicon-project-compact:before { content: "\\ecb6" }
.codicon-refresh-compact:before { content: "\\ecb7" }
.codicon-search-compact:before { content: "\\ecb8" }
.codicon-session-in-progress-compact:before { content: "\\ecb9" }
.codicon-sync-compact:before { content: "\\ecba" }
.codicon-terminal-compact:before { content: "\\ecbb" }
.codicon-vm-pending:before { content: "\\ecbc" }
.codicon-worktree-compact:before { content: "\\ecbd" }
.codicon-developer-tools:before { content: "\\ecbe" }
.codicon-cloud-compact:before { content: "\\ecbf" }
.codicon-agent-compact:before { content: "\\ecc0" }
.codicon-ask-compact:before { content: "\\ecc1" }
.codicon-settings-compact:before { content: "\\ecc2" }
.codicon-vm-compact:before { content: "\\ecc3" }
.codicon-run-compact:before { content: "\\ecc4" }
.codicon-git-pull-request-comment:before { content: "\\ecc5" }
.codicon-git-pull-request-error:before { content: "\\ecc6" }
.codicon-right-panel-hide:before { content: "\\ecc7" }
.codicon-right-panel-show:before { content: "\\ecc8" }
.codicon-vscode-insiders-outline:before { content: "\\ecc9" }
.codicon-vscode-outline:before { content: "\\ecca" }
.codicon-voice-mode:before { content: "\\eccb" }
.codicon-voice-mode-compact:before { content: "\\eccc" }
.codicon-mic-download:before { content: "\\eccd" }
.codicon-mic-download-compact:before { content: "\\ecce" }
.codicon-voice-mode-download:before { content: "\\eccf" }
.codicon-voice-mode-download-compact:before { content: "\\ecd0" }
.codicon-google-gemini:before { content: "\\ecd1" }
.codicon-kimi:before { content: "\\ecd2" }
.codicon-microsoft:before { content: "\\ecd3" }
.codicon-fish1-happy:before { content: "\\ecd4" }
.codicon-fish1-neutral:before { content: "\\ecd5" }
.codicon-fish1-sad:before { content: "\\ecd6" }
.codicon-fish1-very-sad:before { content: "\\ecd7" }
.codicon-fish2-happy:before { content: "\\ecd8" }
.codicon-fish2-neutral:before { content: "\\ecd9" }
.codicon-fish2-sad:before { content: "\\ecda" }
.codicon-fish2-very-sad:before { content: "\\ecdb" }
.codicon-fish3-happy:before { content: "\\ecdc" }
.codicon-fish3-neutral:before { content: "\\ecdd" }
.codicon-fish3-sad:before { content: "\\ecde" }
.codicon-fish3-very-sad:before { content: "\\ecdf" }
.codicon-fish4-happy:before { content: "\\ece0" }
.codicon-fish4-neutral:before { content: "\\ece1" }
.codicon-fish4-sad:before { content: "\\ece2" }
.codicon-fish4-very-sad:before { content: "\\ece3" }
.codicon-person-voice:before { content: "\\ece4" }
.codicon-person-voice-compact:before { content: "\\ece5" }
.codicon-person-voice-filled:before { content: "\\ece6" }
.codicon-person-voice-filled-compact:before { content: "\\ece7" }
`;var bm=`/* The Inkspect design system: tokens and the shared components (buttons, fields, selects,
   switches, sliders, color picker, menus, toast, drawing toolbar and layer).
   Colors come from VS Code theme variables; hosts outside VS Code define them (theme.css).
   Every surface uses the tokens below, so sizes, radii and elevation stay consistent. */

:root,
:host {
  /* Shape */
  --ink-radius-sm: 4px;
  --ink-radius: 6px;
  --ink-radius-lg: 10px;
  --ink-radius-pill: 999px;
  /* Controls */
  --ink-control-sm: 24px;
  --ink-control: 28px;
  --ink-control-lg: 36px;
  /* Spacing */
  --ink-space-1: 4px;
  --ink-space-2: 8px;
  --ink-space-3: 12px;
  --ink-space-4: 16px;
  --ink-space-5: 24px;
  --ink-space-6: 32px;
  /* Type */
  --ink-font-xs: 11px;
  --ink-font-sm: 12px;
  --ink-font: var(--vscode-font-size, 13px);
  --ink-font-lg: 15px;
  --ink-font-xl: 22px;
  /* Surfaces and lines */
  --ink-surface: var(--vscode-editorWidget-background, var(--vscode-editor-background));
  /* Popups: lifted off the menu background, since many dark themes (Tokyo Night) give menus the
     sidebar's own color, a border the same near-black, and no shadow at all. */
  --ink-surface-raised: color-mix(
    in srgb,
    var(--vscode-foreground, #888) 7%,
    var(--vscode-menu-background, var(--ink-surface))
  );
  --ink-surface-sunken: color-mix(in srgb, var(--vscode-foreground, #888) 4%, transparent);
  --ink-border: var(--vscode-widget-border, rgba(128, 128, 128, 0.35));
  --ink-border-subtle: color-mix(in srgb, var(--vscode-foreground, #888) 10%, transparent);
  --ink-border-strong: color-mix(in srgb, var(--vscode-foreground, #888) 22%, transparent);
  --ink-hover: var(--vscode-toolbar-hoverBackground, rgba(128, 128, 128, 0.18));
  --ink-pressed: var(--vscode-toolbar-activeBackground, rgba(128, 128, 128, 0.26));
  /* Focus rings follow the theme's focus border; accents use the button color, which themes keep
     vivid (the focus border can be very dim). Text on tinted backgrounds uses the link color. */
  --ink-focus: var(--vscode-focusBorder, #0078d4);
  --ink-accent: var(--vscode-button-background, var(--ink-focus));
  --ink-accent-fg: var(--vscode-textLink-foreground, var(--ink-accent));
  --ink-accent-soft: color-mix(in srgb, var(--ink-accent) 20%, transparent);
  /* Secondary text, pulled toward the foreground so it stays readable in low-contrast themes. */
  --ink-muted: color-mix(
    in srgb,
    var(--vscode-descriptionForeground, #9d9d9d) 70%,
    var(--vscode-foreground, #ccc)
  );
  --ink-danger: var(--vscode-errorForeground, #f85149);
  --ink-success: var(--vscode-testing-iconPassed, #73c991);
  --ink-warning: var(--vscode-editorWarning-foreground, #cca700);
  /* The theme's own palette. Every theme defines its terminal ANSI colors, and they are its true
     hues (Tokyo Night's are #7aa2f7, #9ece6a, #e0af68, #f7768e, #bb9af7), unlike button and
     error colors, which some themes keep dim. Pulled slightly toward the foreground so they stay
     readable as text on both light and dark backgrounds. */
  --ink-blue: color-mix(
    in srgb,
    var(--vscode-terminal-ansiBlue, #3b8eea) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-green: color-mix(
    in srgb,
    var(--vscode-terminal-ansiGreen, #23d18b) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-yellow: color-mix(
    in srgb,
    var(--vscode-terminal-ansiYellow, #e5e510) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-red: color-mix(
    in srgb,
    var(--vscode-terminal-ansiRed, #f14c4c) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-magenta: color-mix(
    in srgb,
    var(--vscode-terminal-ansiMagenta, #d670d6) 88%,
    var(--vscode-foreground, #888)
  );
  /* Elevation */
  /* Half the theme's widget shadow, half plain black: some themes make theirs transparent. */
  --ink-shadow-color: color-mix(
    in srgb,
    var(--vscode-widget-shadow, rgba(0, 0, 0, 0.3)) 50%,
    rgba(0, 0, 0, 0.5)
  );
  --ink-shadow-sm: 0 1px 3px var(--ink-shadow-color);
  --ink-shadow: 0 6px 20px var(--ink-shadow-color), 0 1px 4px var(--ink-shadow-color);
  --ink-shadow-lg: 0 12px 32px var(--ink-shadow-color), 0 2px 8px var(--ink-shadow-color);
  /* Motion */
  --ink-ease: cubic-bezier(0.2, 0, 0, 1);
  --ink-fast: 90ms;
  --ink-normal: 160ms;
}

/* Focus ------------------------------------------------------------------------------------ */

.icon-button:focus-visible,
.button:focus-visible,
.link-button:focus-visible,
.menu-item:focus-visible,
.select:focus-visible,
.switch:focus-visible,
.checkbox:focus-visible,
.segment:focus-visible,
.slider-track:focus-visible,
.swatch:focus-visible,
.color-area:focus-visible,
.color-hue:focus-visible,
.chip:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: 1px;
}

/* Icon buttons ----------------------------------------------------------------------------- */

.icon-button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: var(--ink-control);
  height: var(--ink-control);
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--vscode-icon-foreground, var(--vscode-foreground));
  font: inherit;
  cursor: pointer;
  transition: background-color var(--ink-fast) var(--ink-ease);
}

/* DragHandle: the six-dot grip of a floating panel. */
.drag-handle {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: var(--ink-control);
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  cursor: grab;
  touch-action: none;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    color var(--ink-fast) var(--ink-ease);
}

.drag-handle:hover,
.drag-handle.dragging {
  background: var(--ink-hover);
  color: var(--vscode-foreground);
}

.drag-handle.dragging {
  cursor: grabbing;
}

.drag-handle:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.icon-button.small {
  width: var(--ink-control-sm);
  height: var(--ink-control-sm);
}

.icon-button:hover:not(:disabled) {
  background: var(--ink-hover);
}

.icon-button:active:not(:disabled) {
  background: var(--ink-pressed);
}

.icon-button.active {
  background: var(--ink-accent-soft);
  color: var(--vscode-inputOption-activeForeground, var(--vscode-foreground));
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--ink-accent) 60%, transparent);
}

.icon-button:disabled {
  opacity: 0.4;
  cursor: default;
}

/* Buttons ---------------------------------------------------------------------------------- */

.button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: var(--ink-control);
  padding: 0 12px;
  border: 1px solid var(--vscode-button-border, transparent);
  border-radius: var(--ink-radius-sm);
  font: inherit;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.button.small {
  gap: 4px;
  height: var(--ink-control-sm);
  padding: 0 8px;
}

.button .codicon {
  font-size: 14px;
}

.button.primary {
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.primary:hover:not(:disabled) {
  background: var(--vscode-button-hoverBackground);
}

.button.secondary {
  background: var(--vscode-button-secondaryBackground);
  color: var(--vscode-button-secondaryForeground);
}

.button.secondary:hover:not(:disabled) {
  background: var(--vscode-button-secondaryHoverBackground);
}

.button.ghost {
  border-color: transparent;
  background: transparent;
  color: inherit;
}

.button.ghost:hover:not(:disabled) {
  background: var(--ink-hover);
}

/* A solid call to action in the theme's own blue (its palette, see --ink-blue), for themes whose
   button color is dim. Dark text on dark themes, where the palette's blue is light. */
.button.accent {
  border-color: transparent;
  background: var(--ink-blue);
  color: var(--vscode-editor-background, #fff);
  font-weight: 600;
}

.button.accent:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-blue) 85%, var(--vscode-foreground, #fff));
}

body.vscode-light .button.accent {
  color: #fff;
}

body.vscode-high-contrast .button.accent {
  border-color: var(--vscode-contrastBorder, transparent);
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.danger {
  border-color: color-mix(in srgb, var(--ink-danger) 45%, transparent);
  background: transparent;
  color: var(--ink-danger);
}

.button.danger:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-danger) 12%, transparent);
}

.button:disabled {
  opacity: 0.5;
  cursor: default;
}

.link-button {
  padding: 0;
  border: none;
  background: none;
  color: var(--vscode-textLink-foreground);
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.link-button:hover:not(:disabled) {
  color: var(--vscode-textLink-activeForeground, var(--vscode-textLink-foreground));
  text-decoration: underline;
}

.link-button:disabled {
  color: inherit;
  cursor: default;
}

.link-button.danger {
  color: var(--ink-danger);
}

/* Text fields ------------------------------------------------------------------------------ */

.text-field {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: var(--ink-control);
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  transition: border-color var(--ink-fast) var(--ink-ease);
}

.text-field.size-sm {
  height: var(--ink-control-sm);
  padding: 0 6px;
}

.text-field.size-lg {
  height: var(--ink-control-lg);
  padding: 0 12px;
  border-radius: var(--ink-radius);
}

.text-field:hover:not(.disabled) {
  border-color: var(--ink-border-strong);
}

.text-field:focus-within {
  border-color: var(--ink-focus);
  box-shadow: 0 0 0 1px var(--ink-focus);
}

.text-field.invalid {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.text-field.disabled {
  opacity: 0.5;
}

.text-field input {
  flex: 1;
  width: 100%;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: none;
  outline: none;
  background: transparent;
  color: inherit;
  font: inherit;
}

.text-field input::placeholder {
  color: var(--vscode-input-placeholderForeground, var(--ink-muted));
}

/* Numbers: no spinner arrows (the fields accept typing and arrow keys). */
.text-field input::-webkit-outer-spin-button,
.text-field input::-webkit-inner-spin-button {
  margin: 0;
  appearance: none;
}

.text-field input[type='number'] {
  appearance: textfield;
  font-variant-numeric: tabular-nums;
}

.text-field input[type='search']::-webkit-search-cancel-button {
  appearance: none;
}

.text-field-icon {
  flex-shrink: 0;
  color: var(--ink-muted);
}

.text-field-clear {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.text-field-clear:hover {
  background: var(--ink-hover);
  color: inherit;
}

/* Form rows -------------------------------------------------------------------------------- */

.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: var(--ink-space-3);
}

.field.inline {
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ink-space-3);
}

.field-label {
  color: var(--vscode-foreground);
  font-weight: 600;
}

.field.inline .field-label {
  font-weight: normal;
}

.field-control {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  min-width: 0;
}

.field-control > .text-field,
.field-control > .select {
  flex: 1;
}

.field-hint {
  flex-basis: 100%;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.field-hint.error {
  color: var(--ink-danger);
}

/* Select ----------------------------------------------------------------------------------- */

.select {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  height: var(--ink-control);
  padding: 0 6px 0 8px;
  border: 1px solid var(--vscode-dropdown-border, var(--vscode-input-border, var(--ink-border)));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-dropdown-background, var(--vscode-input-background));
  color: var(--vscode-dropdown-foreground, var(--vscode-input-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.select.size-sm {
  height: var(--ink-control-sm);
  padding: 0 4px 0 6px;
}

.select:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
}

.select.open {
  border-color: var(--ink-focus);
}

.select.quiet {
  border-color: transparent;
  background: transparent;
}

.select.quiet:hover:not(:disabled),
.select.quiet.open {
  border-color: transparent;
  background: var(--ink-hover);
}

.select:disabled {
  opacity: 0.45;
  cursor: default;
}

.select-value {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.select-value.placeholder {
  color: var(--ink-muted);
}

.select-chevron {
  flex-shrink: 0;
  font-size: 14px !important;
  opacity: 0.8;
  transition: transform var(--ink-normal) var(--ink-ease);
}

.select.open .select-chevron {
  transform: rotate(180deg);
}

.select-list,
.color-picker,
.menu,
.popover {
  background: var(--ink-surface-raised);
  color: var(--vscode-menu-foreground, var(--vscode-foreground));
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow);
}

.select-list {
  position: fixed;
  z-index: 1000;
  max-height: min(340px, 60vh);
  padding: 4px;
  overflow-y: auto;
  outline: none;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.select-group {
  padding: 8px 8px 4px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.select-group:first-child {
  padding-top: 4px;
}

.select-option {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px 0 4px;
  border-radius: var(--ink-radius-sm);
  white-space: nowrap;
  cursor: pointer;
}

.select-option.active {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
}

.select-option.disabled {
  opacity: 0.45;
  cursor: default;
}

.select-check {
  flex-shrink: 0;
  font-size: 14px !important;
}

.select-option-label {
  flex: 1;
}

.select-option-detail {
  margin-left: 16px;
  opacity: 0.65;
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Switch and checkbox ---------------------------------------------------------------------- */

.switch,
.checkbox {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: var(--ink-space-2);
  padding: 2px 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.switch:disabled,
.checkbox:disabled {
  opacity: 0.45;
  cursor: default;
}

.switch-track {
  position: relative;
  flex-shrink: 0;
  width: 30px;
  height: 16px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-input-background, var(--ink-surface-sunken));
  transition:
    background-color var(--ink-normal) var(--ink-ease),
    border-color var(--ink-normal) var(--ink-ease);
}

.switch-thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--ink-muted);
  transition:
    transform var(--ink-normal) var(--ink-ease),
    background-color var(--ink-normal) var(--ink-ease);
}

.switch.on .switch-track {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
}

.switch.on .switch-thumb {
  background: var(--vscode-button-foreground, #fff);
  transform: translateX(14px);
}

.checkbox-box {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border: 1px solid var(--vscode-checkbox-border, var(--ink-border-strong));
  border-radius: 3px;
  background: var(--vscode-checkbox-background, var(--vscode-input-background));
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.checkbox.on .checkbox-box {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
  color: var(--vscode-button-foreground, #fff);
}

.checkbox-box .codicon {
  font-size: 14px !important;
}

/* Segmented control ------------------------------------------------------------------------ */

.segmented {
  display: inline-flex;
  flex-shrink: 0;
  gap: 2px;
  height: var(--ink-control);
  padding: 2px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
}

.segmented.size-sm {
  height: var(--ink-control-sm);
  padding: 1px;
  border-radius: var(--ink-radius-sm);
}

.segment {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  gap: 5px;
  min-width: 26px;
  padding: 0 10px;
  border: none;
  border-radius: calc(var(--ink-radius) - 2px);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    color var(--ink-fast) var(--ink-ease);
}

.segmented.size-sm .segment {
  padding: 0 8px;
  border-radius: 3px;
}

.segment:hover {
  color: var(--vscode-foreground);
}

.segment.checked {
  background: var(--vscode-button-secondaryBackground, var(--ink-hover));
  color: var(--vscode-button-secondaryForeground, var(--vscode-foreground));
  box-shadow: var(--ink-shadow-sm);
}

.segment-count {
  min-width: 16px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
  text-align: center;
}

.segment-count.error {
  background: var(--ink-danger);
  color: #fff;
}

/* Slider ----------------------------------------------------------------------------------- */

.slider {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  height: var(--ink-control);
}

.slider.disabled {
  opacity: 0.45;
}

.slider > .codicon {
  color: var(--ink-muted);
}

.slider-track {
  position: relative;
  width: 84px;
  height: 18px;
  cursor: pointer;
  touch-action: none;
  border-radius: var(--ink-radius-sm);
}

.slider-track::before,
.slider-fill {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  height: 4px;
  border-radius: var(--ink-radius-pill);
  transform: translateY(-50%);
}

.slider-track::before {
  right: 0;
  background: var(--ink-border-strong);
}

.slider-fill {
  background: var(--ink-accent);
}

.slider-thumb {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid var(--ink-accent);
  border-radius: 50%;
  background: var(--vscode-editor-background, #fff);
  box-shadow: var(--ink-shadow-sm);
  transform: translate(-50%, -50%);
  transition: transform var(--ink-fast) var(--ink-ease);
}

.slider-track:hover .slider-thumb,
.slider-track:active .slider-thumb {
  transform: translate(-50%, -50%) scale(1.15);
}

.slider-value {
  min-width: 34px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Swatches and color picker ---------------------------------------------------------------- */

.swatch {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  padding: 0;
  border: 1px solid color-mix(in srgb, var(--vscode-foreground, #888) 30%, transparent);
  border-radius: 50%;
  cursor: pointer;
  transition: transform var(--ink-fast) var(--ink-ease);
}

.swatch:hover {
  transform: scale(1.12);
}

.swatch.small {
  width: 16px;
  height: 16px;
}

.swatch.active {
  box-shadow:
    0 0 0 2px var(--ink-surface),
    0 0 0 3.5px var(--ink-accent);
}

.color-picker-trigger {
  background: conic-gradient(
    from 90deg,
    #f43f5e,
    #f59e0b,
    #84cc16,
    #06b6d4,
    #6366f1,
    #d946ef,
    #f43f5e
  );
}

.color-picker {
  position: fixed;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 224px;
  padding: 10px;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.color-area {
  position: relative;
  height: 140px;
  border-radius: var(--ink-radius-sm);
  background-image:
    linear-gradient(to top, #000, transparent), linear-gradient(to right, #fff, transparent) !important;
  cursor: crosshair;
  touch-action: none;
}

.color-hue {
  position: relative;
  height: 12px;
  border-radius: var(--ink-radius-pill);
  background: linear-gradient(
    to right,
    #f00 0%,
    #ff0 17%,
    #0f0 33%,
    #0ff 50%,
    #00f 67%,
    #f0f 83%,
    #f00 100%
  );
  cursor: pointer;
  touch-action: none;
}

.color-handle {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.35),
    0 1px 4px rgba(0, 0, 0, 0.4);
  transform: translate(-50%, -50%);
  pointer-events: none;
}

.color-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.color-preview {
  flex-shrink: 0;
  width: 26px;
  height: 26px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
}

.color-hex {
  flex: 1;
  min-width: 0;
  height: 26px;
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  outline: none;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-sm);
  text-transform: lowercase;
}

.color-hex:focus {
  border-color: var(--ink-focus);
}

.color-presets {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  padding-top: 8px;
  border-top: 1px solid var(--ink-border-subtle);
}

/* Chips and badges ------------------------------------------------------------------------- */

.badge {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 7px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  white-space: nowrap;
}

.badge.outline {
  border: 1px solid var(--ink-border-strong);
  background: transparent;
  color: var(--ink-muted);
}

.badge.success {
  background: color-mix(in srgb, var(--ink-success) 18%, transparent);
  color: var(--ink-success);
}

.badge.danger {
  background: color-mix(in srgb, var(--ink-danger) 18%, transparent);
  color: var(--ink-danger);
}

/* Key caps (shortcuts) --------------------------------------------------------------------- */

.keycaps {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 3px;
}

.keycap {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border: 1px solid var(--vscode-keybindingLabel-border, var(--ink-border-strong));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-keybindingLabel-background, var(--ink-surface-sunken));
  box-shadow: inset 0 -1px 0 var(--vscode-keybindingLabel-bottomBorder, var(--ink-border-strong));
  color: var(--vscode-keybindingLabel-foreground, var(--vscode-foreground));
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  line-height: 1;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.keycaps.size-sm .keycap {
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  font-size: 10.5px;
}

/* Cards ------------------------------------------------------------------------------------ */

.card {
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--ink-surface-sunken);
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--ink-space-3);
  padding: var(--ink-space-3) var(--ink-space-4);
  border-bottom: 1px solid var(--ink-border-subtle);
}

.card-title {
  margin: 0;
  font-size: var(--ink-font);
  font-weight: 600;
}

.card-body {
  padding: var(--ink-space-4);
}

.card-row {
  display: flex;
  align-items: center;
  gap: var(--ink-space-4);
  padding: var(--ink-space-3) var(--ink-space-4);
}

.card-row + .card-row {
  border-top: 1px solid var(--ink-border-subtle);
}

.card-row-text {
  flex: 1;
  min-width: 0;
}

.card-row-title {
  font-weight: 500;
}

.card-row-description {
  margin-top: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

/* Menus and popovers ----------------------------------------------------------------------- */

.menu,
.popover {
  position: fixed;
  /* Above the send dialog (900), like select lists and the color picker. */
  z-index: 1000;
  min-width: 200px;
  max-width: 420px;
  padding: 4px;
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

/* Long menus (a big bookmarks folder) stay short and scroll, like Chrome's. Items have a little
   room between them. */
.menu {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 5px;
  max-height: min(420px, calc(100vh - 8px));
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Submenus open without the pop animation, so they don't jump while the pointer moves. */
.menu .menu {
  animation: none;
}

.menu-item.expanded:not(:focus) {
  background: var(--ink-hover);
}

.menu-image {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  object-fit: contain;
}

.menu-arrow {
  margin-left: 12px;
  margin-right: -2px;
  opacity: 0.8;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  width: 100%;
  height: 28px;
  padding: 0 10px 0 8px;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.menu-item:hover:not(:disabled),
.menu-item:focus {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
  outline: none;
}

.menu-item:disabled {
  opacity: 0.45;
  cursor: default;
}

.menu-label {
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.menu-shortcut {
  margin-left: 16px;
  opacity: 0.7;
  font-size: 0.9em;
}

.menu-separator {
  flex-shrink: 0;
  height: 1px;
  margin: 3px 6px;
  background: var(--vscode-menu-separatorBackground, var(--ink-border));
}

/* Toast ------------------------------------------------------------------------------------ */

.toast {
  position: fixed;
  bottom: 16px;
  left: 50%;
  z-index: 200;
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: calc(100% - 32px);
  padding: 8px 14px;
  transform: translateX(-50%);
  background: var(--vscode-notifications-background, var(--ink-surface));
  color: var(--vscode-notifications-foreground, var(--vscode-foreground));
  border: 1px solid var(--vscode-notifications-border, var(--ink-border));
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow-lg);
  animation: toast-in var(--ink-normal) var(--ink-ease);
}

/* A failure: marked as one, longer on screen, and dismissible. */
.toast.error {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.toast.error > .codicon-error {
  flex-shrink: 0;
  color: var(--ink-danger);
}

.toast .toast-dismiss {
  flex-shrink: 0;
  margin: -4px -8px -4px 0;
}

.header-actions,
.button-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
}

/* Drawing ---------------------------------------------------------------------------------- */

.draw-toolbar {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  padding: 4px 8px;
  background: var(--ink-surface);
  border-top: 1px solid var(--ink-border);
  border-bottom: 1px solid var(--ink-border);
}

.draw-group {
  display: flex;
  align-items: center;
  gap: 2px;
  padding-right: 6px;
  border-right: 1px solid var(--ink-border-subtle);
}

.draw-group.colors {
  gap: 6px;
  padding: 0 8px 0 4px;
}

.draw-capture {
  margin-left: 2px;
}

.draw-close {
  margin-left: auto;
}

.drawing-layer {
  position: absolute;
  z-index: 3;
}

.drawing-layer canvas {
  position: relative;
  display: block;
  touch-action: none;
}

/* A live redaction (liveRedactions): blurs the page behind it, under the drawing canvas. Drawn
   over page content, so its colors are fixed. */
.drawing-redaction {
  position: absolute;
  pointer-events: none;
  background: rgba(128, 128, 128, 0.2);
  backdrop-filter: blur(12px) saturate(0.5);
}

.drawing-text-input {
  position: absolute;
  min-width: 160px;
  min-height: 1.6em;
  padding: 2px 4px;
  border: 1px dashed var(--ink-accent);
  background: rgba(255, 255, 255, 0.85);
  font-family: system-ui, sans-serif;
  font-weight: 600;
  resize: both;
  outline: none;
}

/* Motion ----------------------------------------------------------------------------------- */

@keyframes ink-fade-in {
  from {
    opacity: 0;
  }
}

@keyframes ink-pop-in {
  from {
    opacity: 0;
    transform: translateY(-3px) scale(0.985);
  }
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translate(-50%, 8px);
  }
}

@media (prefers-reduced-motion: reduce) {
  .select-list,
  .color-picker,
  .menu,
  .popover,
  .toast {
    animation: none;
  }
}

/* Shortcut list (ShortcutList) ------------------------------------------------------------- */

.shortcuts-warning {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 12px 8px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

/* Groups: a pinned header per mode. */
.group-header {
  position: sticky;
  top: var(--shortcut-sticky-top, 0);
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  height: 28px;
  padding: 0 12px 0 6px;
  border: none;
  border-top: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  color: var(--vscode-sideBarSectionHeader-foreground, var(--vscode-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.group-header:hover {
  background: var(--vscode-list-hoverBackground);
}

.group-header:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.group-icon {
  color: var(--ink-accent-fg);
}

.group-title {
  font-size: var(--ink-font-xs);
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.group-count {
  margin-left: auto;
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
}

/* Rows: label, then actions (on hover), then the keys in a right-aligned column. */
.shortcut-item {
  position: relative;
  padding: 0 12px 0 32px;
  border-radius: var(--ink-radius);
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.shortcut-item::before {
  content: '';
  position: absolute;
  top: 6px;
  bottom: 6px;
  left: 20px;
  width: 2px;
  border-radius: 1px;
  background: transparent;
}

.shortcut-item.changed::before {
  background: var(--ink-accent);
}

.shortcut-item.conflict::before {
  background: var(--ink-warning);
}

/* Outside VS Code (the browser extension) there is no list hover color: the kit's hover. */
.shortcut-item:hover,
.shortcut-item:focus-within {
  background: var(--vscode-list-hoverBackground, var(--ink-hover));
}

body.vscode-high-contrast .shortcut-item:hover,
body.vscode-high-contrast .shortcut-item:focus-within {
  outline: 1px dashed var(--vscode-contrastActiveBorder);
  outline-offset: -1px;
}

.shortcut-main {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 30px;
}

.shortcut-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Where a key works: VS (VS Code Browser) and BR (the browser toolbar), and the browser's own key. */
.shortcut-places {
  display: inline-flex;
  flex-shrink: 0;
  gap: 3px;
}

.shortcut-tag {
  --tag: var(--ink-muted);
  flex-shrink: 0;
  min-width: 22px;
  padding: 0 4px;
  border: 1px solid color-mix(in srgb, var(--tag) 40%, transparent);
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--tag) 10%, transparent);
  color: var(--tag);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 14px;
  text-align: center;
  letter-spacing: 0.02em;
}

.shortcut-tag.vs {
  --tag: var(--ink-blue);
}

.shortcut-tag.br {
  --tag: var(--ink-green);
}

body.vscode-high-contrast .shortcut-tag {
  border-color: var(--vscode-contrastBorder);
  background: transparent;
  color: var(--vscode-foreground);
}

.shortcut-item.changed .shortcut-label {
  font-weight: 500;
}

.shortcut-actions {
  display: inline-flex;
  flex-shrink: 0;
  justify-content: flex-end;
  gap: 1px;
  /* Room for both buttons (reset, add a key) in every row, so the columns line up. */
  min-width: calc(2 * var(--ink-control-sm) + 1px);
  opacity: 0;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.shortcut-item:hover .shortcut-actions,
.shortcut-item:focus-within .shortcut-actions {
  opacity: 1;
}

.shortcut-keys-column {
  display: inline-flex;
  flex-wrap: wrap;
  flex-shrink: 0;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  /* A steady width, so the VS/BR tags before it line up from row to row. */
  min-width: min(184px, 40%);
  max-width: 62%;
}

.key-button-wrap {
  position: relative;
  display: inline-flex;
}

.key-button {
  display: inline-flex;
  padding: 2px;
  border: 1px solid transparent;
  border-radius: var(--ink-radius);
  background: transparent;
  cursor: pointer;
}

.key-button:hover {
  border-color: var(--ink-border-strong);
  background: var(--ink-surface-sunken);
}

.key-button:focus-visible {
  outline: 1px solid var(--ink-focus);
}

/* The remove badge sits on the key's corner, so showing it doesn't move anything. */
.key-remove {
  position: absolute;
  top: -5px;
  right: -5px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 1px solid var(--ink-border-strong);
  border-radius: 50%;
  background: var(--ink-surface-raised);
  color: var(--ink-muted);
  opacity: 0;
  cursor: pointer;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.key-remove .codicon {
  font-size: 10px !important;
}

.key-button-wrap:hover .key-remove,
.key-remove:focus-visible {
  opacity: 1;
}

.key-remove:hover {
  border-color: var(--ink-danger);
  background: var(--ink-danger);
  color: #fff;
}

.key-empty {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 22px;
  padding: 0 8px;
  border: 1px dashed var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  font-size: var(--ink-font-xs);
  cursor: pointer;
}

.key-empty:hover {
  border-color: var(--ink-focus);
  color: var(--vscode-foreground);
}

.key-empty .codicon {
  font-size: 12px !important;
}

.key-recording {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  padding: 0 2px 0 8px;
  border: 1px solid var(--ink-focus);
  border-radius: var(--ink-radius-sm);
  background: var(--ink-accent-soft);
  box-shadow: 0 0 0 1px var(--ink-focus);
  font-size: var(--ink-font-xs);
}

.recording-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #ef4444;
  animation: ink-shortcut-pulse 1s ease-in-out infinite;
}

.key-recording-cancel {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.key-recording-cancel:hover {
  background: var(--ink-hover);
  color: inherit;
}

.shortcut-conflict {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 6px;
  padding: 0 0 6px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

@keyframes ink-shortcut-pulse {
  50% {
    opacity: 0.3;
  }
}

@media (prefers-reduced-motion: reduce) {
  .recording-dot {
    animation: none;
  }
}

body.vscode-high-contrast .key-button:hover {
  border-color: var(--vscode-contrastBorder);
}

/* Several keys for one action: "Ctrl T / Ctrl F4". */
.key-button-wrap + .key-button-wrap::before {
  content: '/';
  align-self: center;
  margin-right: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

/* Element picker hint (PickerHint) ------------------------------------------------------------
   Drawn over page content, so it has its own dark look (the theme's colors could vanish on the
   page), in both products. Each product places it. */
/* One row: what a click does, with each modifier, then the keys. */
.picker-hint {
  display: flex;
  align-items: center;
  gap: 14px;
  /* Its own width: centered with left: 50%, it would otherwise wrap at half the page. */
  width: max-content;
  padding: 6px 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.9);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  line-height: 1;
  pointer-events: none;
  backdrop-filter: blur(6px);
}

.picker-hint-item {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
}

.picker-hint-label {
  color: rgba(250, 250, 250, 0.82);
}

/* The main action, as a sentence; the others read "[Shift] + click  select several". */
.picker-hint-lead {
  color: #fff;
  font-weight: 600;
}

.picker-hint-click {
  color: #fff;
  font-weight: 500;
}

.picker-hint .keycap {
  border-color: rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  box-shadow: inset 0 -1px 0 rgba(255, 255, 255, 0.14);
  color: #fff;
}

/* Multi-selection bar (SelectionBar) ----------------------------------------------------------
   Over page content like the picker hint, so the same dark look; each product places it. */
.selection-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px;
  width: max-content;
  max-width: calc(100vw - 32px);
  padding: 5px 6px 5px 10px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.94);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  pointer-events: auto;
}

.selection-bar-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: 6px;
  font-weight: 600;
}

.selection-bar-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: #0a84ff;
  color: #fff;
  font-size: var(--ink-font-xs);
}

.selection-bar .button.ghost,
.selection-bar .icon-button {
  color: #fafafa;
}

.selection-bar .button.ghost:hover:not(:disabled),
.selection-bar .icon-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.12);
}

.selection-bar .button-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.selection-bar .keycap {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.16);
  box-shadow: none;
  color: #fff;
}

/* Thumbnails with a checkbox each (ThumbPicker): screenshots taken together ------------------- */
.thumb-picker {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(88px, 1fr));
  gap: var(--ink-space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.thumb-picker-item {
  position: relative;
  border-radius: var(--ink-radius);
}

.thumb-picker-image {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  aspect-ratio: 16 / 10;
  padding: 0;
  overflow: hidden;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  color: var(--ink-muted);
  cursor: pointer;
  transition:
    opacity var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.thumb-picker-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

.thumb-picker-image:hover {
  border-color: var(--ink-border-strong);
}

/* Left out: dimmed, so what is sent stands out. */
.thumb-picker-item:not(.on) .thumb-picker-image {
  opacity: 0.45;
}

.thumb-picker-item.on .thumb-picker-image {
  border-color: var(--ink-accent);
}

.thumb-picker-check {
  position: absolute;
  top: 4px;
  left: 4px;
  padding: 2px;
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--vscode-editor-background) 80%, transparent);
  box-shadow: var(--ink-shadow-sm);
}

body.vscode-high-contrast .thumb-picker-item.on .thumb-picker-image {
  outline: 1px solid var(--vscode-contrastActiveBorder);
}

/* The send dialog after a capture (SendModal) ------------------------------------------- */

.ink-modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 900;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--ink-space-4);
  background: color-mix(in srgb, #000 35%, transparent);
  animation: ink-fade-in var(--ink-normal) var(--ink-ease);
  pointer-events: auto;
}

.ink-modal {
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-3);
  width: min(480px, 100%);
  max-height: calc(100vh - 2 * var(--ink-space-4));
  overflow: auto;
  padding: var(--ink-space-4);
  background: var(--ink-surface);
  color: var(--vscode-editorWidget-foreground, var(--vscode-foreground));
  border: 1px solid var(--vscode-editorWidget-border, var(--ink-border));
  border-radius: var(--ink-radius-lg);
  box-shadow: var(--ink-shadow-lg);
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  text-align: left;
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.ink-modal:focus {
  outline: none;
}

.ink-modal-head {
  display: flex;
  align-items: flex-start;
  gap: var(--ink-space-3);
}

.ink-modal-detail {
  line-height: 1.35;
}

/* The captures: one row of equal tiles under the heading. */
.ink-modal-thumbs {
  display: grid;
  grid-auto-columns: minmax(0, 1fr);
  grid-auto-flow: column;
  gap: var(--ink-space-2);
}

.ink-modal-thumb {
  position: relative;
  display: block;
  height: 64px;
  overflow: hidden;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
}

.ink-modal-thumb img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

.ink-modal-more {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  background: color-mix(in srgb, #000 55%, transparent);
  color: #fff;
  font-size: var(--ink-font);
  font-weight: 600;
}

.ink-modal-heading {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: var(--ink-space-1);
  min-width: 0;
}

.ink-modal-project {
  flex-wrap: nowrap;
  white-space: nowrap;
}

.ink-modal-title {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  font-size: calc(var(--ink-font) + 1px);
  font-weight: 600;
}

.ink-modal-title .codicon {
  color: var(--ink-success);
}

.ink-modal-project,
.ink-modal-detail {
  display: flex;
  align-items: center;
  gap: var(--ink-space-1);
  font-size: var(--ink-font-sm);
}

.ink-modal-project-name {
  font-weight: 600;
}

.ink-modal-detail,
.ink-modal-project .ink-muted,
.ink-modal-empty,
.ink-modal-label,
.ink-modal-where,
.ink-modal-status {
  color: var(--ink-muted);
}

.ink-modal-label {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  margin-bottom: calc(-1 * var(--ink-space-1));
  font-size: var(--ink-font-xs);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

.ink-modal-count {
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--ink-surface-sunken);
  letter-spacing: 0;
}

.ink-modal-targets {
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-1);
  margin: 0;
  padding: 0;
  list-style: none;
}

.ink-modal-target {
  display: flex;
  align-items: center;
  gap: var(--ink-space-1);
}

.ink-modal-send {
  display: flex;
  flex: 1;
  align-items: center;
  gap: var(--ink-space-3);
  min-width: 0;
  min-height: 52px;
  padding: var(--ink-space-2) var(--ink-space-3) var(--ink-space-2) var(--ink-space-2);
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--ink-surface-sunken);
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.ink-modal-send:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
  background: var(--ink-hover);
}

.ink-modal-send:disabled {
  cursor: default;
  opacity: 0.6;
}

.ink-modal-send:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.ink-modal-target.default .ink-modal-send {
  border-color: var(--ink-accent);
  background: var(--ink-accent-soft);
}

.ink-modal-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: var(--ink-radius);
  background: color-mix(in srgb, var(--vscode-foreground) 8%, transparent);
}

.ink-modal-icon .codicon {
  font-size: 17px;
}

.ink-modal-target.default .ink-modal-icon {
  background: var(--ink-accent);
  color: var(--vscode-button-foreground, #fff);
}

.ink-modal-text {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
}

.ink-modal-agent {
  overflow: hidden;
  font-weight: 600;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ink-modal-where {
  overflow: hidden;
  font-size: var(--ink-font-sm);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ink-modal-keys {
  display: flex;
  flex: none;
  align-items: center;
  gap: var(--ink-space-1);
}

.ink-modal-number {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

.ink-modal-thread {
  align-self: flex-start;
}

.ink-modal-empty {
  padding: var(--ink-space-3);
  border: 1px dashed var(--ink-border-strong);
  border-radius: var(--ink-radius-lg);
  text-align: center;
}

.ink-modal-foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--ink-space-2);
  padding-top: var(--ink-space-3);
  border-top: 1px solid var(--ink-border-subtle);
}

.ink-modal-status {
  flex: 1;
  min-width: 160px;
  font-size: var(--ink-font-sm);
}

.ink-modal-status.tone-error {
  color: var(--ink-danger);
}

.ink-modal-status.tone-ok {
  color: var(--ink-success);
}

body.vscode-high-contrast .ink-modal-target.default .ink-modal-send {
  outline: 1px solid var(--vscode-contrastActiveBorder);
}

@media (forced-colors: active) {
  .ink-modal-target.default .ink-modal-send {
    outline: 2px solid Highlight;
  }
}

/* Saved list (SavedList) ----------------------------------------------------------------------
   A project's captures, in VS Code's Saved view and the browser's side panel. Cards are a lighter
   tint of the sidebar, with no outline: in themes like Tokyo Night the sidebar, editor and
   borders are all the same near-black. */
.saved {
  --card-bg: color-mix(
    in srgb,
    var(--vscode-foreground, #888) 5%,
    var(--vscode-sideBar-background, transparent)
  );
  display: flex;
  flex-direction: column;
  container: saved / inline-size;
}

/* The agent picker and filters, pinned at the top. */
.saved-header {
  position: sticky;
  top: 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-2);
  padding: var(--ink-space-2) var(--ink-space-3);
  border-bottom: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
}

/* Filters fill the width; below 480px only their icons and counts show (names are tooltips). */
.saved-filter {
  display: flex;
  width: 100%;
}

.saved-filter .segment {
  flex: 1 1 auto;
  min-width: 0;
  gap: 4px;
  padding: 0 4px;
}

@container saved (max-width: 260px) {
  .saved-filter .segment-count:not(.error) {
    display: none;
  }
}

@container saved (max-width: 480px) {
  .saved-filter .segment-label {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
}

/* Items. */
.saved-list {
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-2);
  margin: 0;
  padding: var(--ink-space-2) var(--ink-space-3) var(--ink-space-3);
  list-style: none;
}

.saved-card {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
  padding: 10px;
  border: 1px solid transparent;
  border-radius: var(--ink-radius-lg);
  background: var(--card-bg);
  outline: none;
  transition:
    border-color var(--ink-fast) var(--ink-ease),
    background var(--ink-fast) var(--ink-ease);
}

.saved-card:hover {
  background: color-mix(in srgb, var(--vscode-foreground, #888) 4%, var(--card-bg));
}

.saved-card:focus-visible {
  border-color: var(--ink-focus);
}

/* Screenshots, recordings and element captures: a preview across the card's width. The whole
   image shows (a short element strip isn't cropped to nothing); only tall captures, such as full
   pages, are cropped to their top. */
.saved-thumb {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  min-height: 44px;
  max-height: 150px;
  padding: 6px;
  overflow: hidden;
  border: none;
  border-radius: var(--ink-radius);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  cursor: zoom-in;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.saved-thumb:hover {
  opacity: 0.88;
}

.saved-thumb:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: 1px;
}

.saved-thumb img {
  display: block;
  max-width: 100%;
  max-height: 136px;
  border-radius: var(--ink-radius-sm);
  object-fit: contain;
}

.saved-thumb.tall {
  height: 150px;
  padding: 0;
}

.saved-thumb.tall img {
  width: 100%;
  height: 100%;
  max-height: none;
  border-radius: 0;
  object-fit: cover;
  object-position: top center;
}

.saved-card-head {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
}

.saved-card-icon {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  border-radius: var(--ink-radius);
  background: color-mix(in srgb, var(--kind-tone) 14%, transparent);
  color: var(--kind-tone);
}

.saved-card {
  --kind-tone: var(--ink-blue);
}

.saved-card.kind-errors,
.saved-card.kind-network {
  --kind-tone: var(--ink-red);
}

.saved-card.kind-report,
.saved-card.kind-measure {
  --kind-tone: var(--ink-green);
}

.saved-card.kind-css,
.saved-card.kind-color {
  --kind-tone: var(--ink-magenta);
}

.saved-card-heading {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.saved-card-title-row {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.saved-card-title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  /* The editor text color: some themes (Tokyo Night) keep the sidebar foreground quite dim. */
  color: var(--vscode-editor-foreground, var(--vscode-foreground));
  font-weight: 600;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* A soft chip in the link color, readable on light, dark and high-contrast backgrounds alike. */
.saved-card-badge {
  flex-shrink: 0;
  padding: 0 7px;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--ink-blue) 16%, transparent);
  color: var(--ink-blue);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 16px;
}

.saved-card-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0 6px;
  min-width: 0;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

.saved-card-meta span {
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-card-meta span + span::before {
  content: '\xB7';
  margin-right: 6px;
}

.saved-card-preview {
  margin: 0;
  padding: 6px 8px;
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-textCodeBlock-background, var(--ink-surface));
  color: var(--vscode-descriptionForeground, var(--ink-muted));
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-xs);
  line-height: 1.45;
}

/* Clamped inside the padding, so no half line shows below it. */
.saved-card-preview span {
  display: -webkit-box;
  overflow: hidden;
  word-break: break-word;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}

.saved-card-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
}

/* Send, and a chevron for another agent, joined into one control. */
.saved-send {
  display: inline-flex;
  flex-shrink: 0;
}

.saved-send .saved-send-more {
  min-width: 0;
  /* A hairline of the card shows between the two halves. */
  margin-left: 1px;
  padding: 0 5px;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

.saved-send .button:first-child:not(:last-child) {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}

.saved-card-tools {
  display: inline-flex;
  gap: 1px;
  margin-left: auto;
  opacity: 0.55;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.saved-card:hover .saved-card-tools,
.saved-card:focus-within .saved-card-tools {
  opacity: 1;
}

.saved-card-sent {
  display: flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  color: var(--ink-green);
  font-size: var(--ink-font-xs);
}

.saved-card-sent .codicon {
  flex-shrink: 0;
  font-size: 12px !important;
}

.saved-card-sent span:last-child {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Very narrow: the send button takes the whole row, the tools go below it. */
@container saved (max-width: 210px) {
  .saved-send,
  .saved-send .button:first-child {
    flex: 1;
  }

  .saved-card-tools {
    margin-left: 0;
  }
}

.saved-none {
  margin: var(--ink-space-4) var(--ink-space-3);
  color: var(--ink-muted);
  text-align: center;
}

.saved-footer {
  position: sticky;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ink-space-2);
  margin-top: auto;
  padding: 6px var(--ink-space-3);
  border-top: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
}

.saved-hint {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
}

@container saved (max-width: 320px) {
  .saved-hint {
    display: none;
  }

  .saved-footer {
    justify-content: flex-end;
  }
}

@media (prefers-reduced-motion: reduce) {
  .saved-card,
  .saved-card-tools {
    transition: none;
  }
}

body.vscode-high-contrast .saved-card {
  border-color: var(--vscode-contrastBorder);
}

body.vscode-high-contrast .saved-card.latest,
body.vscode-high-contrast .saved-card:focus-visible {
  border-color: var(--vscode-contrastActiveBorder, var(--ink-focus));
}

/* Selecting cards (to send, remove or group several): a checkbox in the head, shown on hover,
   on focus, and on every card while anything is selected. */
.saved-card-select {
  display: none;
  margin-top: 6px;
}

.saved-card:hover .saved-card-select,
.saved-card:focus-within .saved-card-select,
.saved.selecting .saved-card-select,
.saved-card.selected .saved-card-select {
  display: inline-flex;
}

.saved-card.selected {
  border-color: var(--ink-accent);
  background: color-mix(in srgb, var(--ink-accent) 8%, var(--card-bg));
}

body.vscode-high-contrast .saved-card.selected {
  border-color: var(--vscode-contrastActiveBorder);
}

/* A group: screenshots taken (or grouped) together, one thumbnail each. */
.saved-group .saved-card-icon {
  --kind-tone: var(--ink-blue);
}

.saved-card-count {
  flex-shrink: 0;
  min-width: 18px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--vscode-foreground, #888) 12%, transparent);
  color: var(--vscode-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 16px;
  text-align: center;
}

.saved-group-thumbs {
  grid-template-columns: repeat(auto-fill, minmax(72px, 1fr));
}

/* The footer while cards are selected: what to do with all of them. */
.saved-selection {
  justify-content: flex-start;
  gap: 4px;
}

.saved-selection-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: auto;
  font-weight: 600;
}

.saved-selection-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: var(--ink-accent);
  color: var(--vscode-button-foreground);
  font-size: var(--ink-font-xs);
}

/* A group of elements (or other text): a checklist, one row each. */
.saved-group-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
  margin: 0;
  padding: 4px;
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
  list-style: none;
}

.saved-group-row {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  padding: 3px 4px 3px 6px;
  border-radius: var(--ink-radius-sm);
}

.saved-group-row:hover {
  background: var(--vscode-list-hoverBackground, var(--ink-hover));
}

.saved-group-row:not(.on) .saved-group-row-text,
.saved-group-row:not(.on) .saved-group-row-icon {
  opacity: 0.5;
}

.saved-group-row-icon {
  flex-shrink: 0;
  color: var(--ink-blue);
}

.saved-group-row-text {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
}

.saved-group-row-title {
  overflow: hidden;
  color: var(--vscode-editor-foreground, var(--vscode-foreground));
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-group-row-detail {
  overflow: hidden;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-group-row-open {
  opacity: 0;
}

.saved-group-row:hover .saved-group-row-open,
.saved-group-row:focus-within .saved-group-row-open {
  opacity: 1;
}

/* After a removal: what went, and Undo (for a few seconds). */
.saved-undo-text {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  color: var(--vscode-foreground);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-undo-text .codicon {
  color: var(--ink-muted);
}

/* Send and its chevron, then Open in agentmux. */
.saved-send-group {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 2px;
}

/* A thumbnail that opens nothing (the side panel). */
.saved-thumb.still {
  cursor: default;
}

.saved-thumb.still:hover {
  opacity: 1;
}

@container saved (max-width: 210px) {
  .saved-send-group {
    flex: 1;
  }
}
`;var hx=_(B0());var bs=_(_e(),1);function hs(e,t,n,o={}){let{align:a="start",gap:i=4,matchWidth:r=!1}=o;(0,bs.useLayoutEffect)(()=>{if(!n)return;let l=()=>{e.current&&t.current&&E2(e.current,t.current,{align:a,gap:i,matchWidth:r})};l();let c=new ResizeObserver(l);return t.current&&c.observe(t.current),()=>c.disconnect()},[e,t,n,a,i,r])}function E2(e,t,{align:n,gap:o,matchWidth:a}){let i=e.getBoundingClientRect();a&&(t.style.minWidth=`${i.width}px`);let r=t.getBoundingClientRect(),l=4,c=i.bottom+o,s=c+r.height<=innerHeight-l,f=i.top-o-r.height,m=s||f<l?c:f,u=n==="end"?i.right-r.width:i.left;t.style.top=`${Math.max(l,Math.min(m,innerHeight-r.height-l))}px`,t.style.left=`${Math.max(l,Math.min(u,innerWidth-r.width-l))}px`,t.dataset.side=m===c?"bottom":"top"}function ap(e,t,n){let o=e().find(Boolean)?.getRootNode(),a=o instanceof ShadowRoot?o:void 0,i=c=>e().some(s=>s&&c.composedPath().includes(s)),r=c=>{a&&c.composedPath().includes(a.host)||i(c)||n(c)},l=c=>{i(c)||n(c)};return window.addEventListener(t,r,!0),a?.addEventListener(t,l,!0),()=>{window.removeEventListener(t,r,!0),a?.removeEventListener(t,l,!0)}}var rl,L0=e=>{let t=e.composedPath()[0];if(e.button!==0){rl=void 0;return}t instanceof Element&&(rl={element:t.closest('button, [role="button"], a')??t,at:performance.now()})};typeof window<"u"&&window.addEventListener("pointerdown",L0,!0);function U0(e){e.addEventListener("pointerdown",L0,!0)}function vs(){return rl&&performance.now()-rl.at<1e3?rl.element:void 0}function T2(e){let t=e.getRootNode(),n=[window];t instanceof ShadowRoot&&n.push(t);let o=r=>{r.composedPath().includes(e)&&(r.stopPropagation(),r.preventDefault(),a())},a=()=>{clearTimeout(i);for(let r of n)r.removeEventListener("click",o,!0)},i=setTimeout(a,1e3);for(let r of n)r.addEventListener("click",o,!0)}function ys(e,t,n,o){return ap(e,"pointerdown",a=>{o?.(a)||(t&&a.composedPath().includes(t)&&T2(t),n(a))})}function xs(e,t,n){(0,bs.useEffect)(()=>{if(!t)return;let o=()=>e.map(c=>c.current),a=ap(o,"pointerdown",()=>n("outside")),i=ap(o,"scroll",()=>n("window")),r=c=>{c.key==="Escape"&&(c.preventDefault(),c.stopPropagation(),n("escape"))},l=()=>n("window");return window.addEventListener("keydown",r,!0),window.addEventListener("blur",l),window.addEventListener("resize",l),()=>{a(),i(),window.removeEventListener("keydown",r,!0),window.removeEventListener("blur",l),window.removeEventListener("resize",l)}},[t,n])}function ae(...e){return e.filter(Boolean).join(" ")}function ws(e){let t=e?.getRootNode();return t instanceof ShadowRoot?t:document.body}function j0(e){return e.composedPath().some(t=>t instanceof HTMLElement&&t.dataset.inkPopup!==void 0)}var Aa=_(_e(),1);var ll={global:"Browser",inspect:"Element picker",draw:"Drawing",screenshot:"Screenshot",devtools:"Console and network",device:"Device",measure:"Measure",eyedropper:"Eyedropper",overlay:"Design overlay",tweak:"CSS tweak",record:"Record",a11y:"Accessibility check",send:"Send dialog"},ie=e=>`vscodeBrowser.${e}`,kn=[{id:"tab.new",label:"New tab",scope:"global",keys:["ctrl+t"],command:ie("newTab")},{id:"tab.close",label:"Close tab",scope:"global",keys:["ctrl+w","ctrl+f4"],command:ie("closeTab")},{id:"tab.reopen",label:"Reopen closed tab",scope:"global",keys:["ctrl+shift+t"],command:ie("reopenClosedTab")},{id:"tab.next",label:"Next tab",scope:"global",keys:["ctrl+tab","ctrl+pagedown"],mac:["ctrl+tab","cmd+alt+right"],command:ie("nextTab")},{id:"tab.previous",label:"Previous tab",scope:"global",keys:["ctrl+shift+tab","ctrl+pageup"],mac:["ctrl+shift+tab","cmd+alt+left"],command:ie("previousTab")},{id:"tab.duplicate",label:"Duplicate tab",scope:"global",keys:[],command:ie("duplicateTab")},{id:"tab.private",label:"New private tab",scope:"global",keys:["ctrl+shift+n"],command:ie("newPrivateTab")},{id:"window.new",label:"New window",scope:"global",keys:["ctrl+n"],command:ie("newWindow")},{id:"nav.address",label:"Focus the address bar",scope:"global",keys:["ctrl+l","alt+d"],mac:["cmd+l","alt+d"],command:ie("focusAddressBar")},{id:"nav.back",label:"Back",scope:"global",keys:["alt+left"],mac:["cmd+["],command:ie("goBack")},{id:"nav.forward",label:"Forward",scope:"global",keys:["alt+right"],mac:["cmd+]"],command:ie("goForward")},{id:"nav.reload",label:"Reload",scope:"global",keys:["ctrl+r","f5"],mac:["cmd+r"],command:ie("reload")},{id:"nav.hardReload",label:"Hard reload",scope:"global",keys:["ctrl+shift+r","ctrl+f5"],mac:["cmd+shift+r"],command:ie("hardReload")},{id:"nav.stop",label:"Stop loading",scope:"global",keys:[],command:ie("stop")},{id:"nav.home",label:"Home page",scope:"global",keys:["alt+home"],mac:["cmd+shift+h"],command:ie("goHome")},{id:"page.find",label:"Find in page",scope:"global",keys:["ctrl+f"],command:ie("find")},{id:"page.zoomIn",label:"Zoom in",scope:"global",keys:["ctrl+=","ctrl+shift+="],command:ie("zoomIn")},{id:"page.zoomOut",label:"Zoom out",scope:"global",keys:["ctrl+-"],command:ie("zoomOut")},{id:"page.zoomReset",label:"Reset zoom",scope:"global",keys:["ctrl+0"],command:ie("zoomReset")},{id:"page.bookmark",label:"Bookmark this page",scope:"global",keys:["ctrl+d"],command:ie("bookmarkPage")},{id:"page.source",label:"View page source",scope:"global",keys:["ctrl+u"],mac:["cmd+alt+u"],command:ie("viewSource")},{id:"page.pdf",label:"Save page as PDF",scope:"global",keys:[],command:ie("savePdf")},{id:"page.copyUrl",label:"Copy page address",scope:"global",keys:["ctrl+shift+l"],command:ie("copyUrl")},{id:"page.external",label:"Open in system browser",scope:"global",keys:[],command:ie("openInSystemBrowser")},{id:"page.devtools",label:"Open DevTools",scope:"global",keys:["f12"],command:ie("openDevTools")},{id:"page.contextToAgent",label:"Send page context to agent",scope:"global",keys:["ctrl+alt+enter"],command:ie("sendPageContextToChat")},{id:"agent.showContext",label:"Show agent context",scope:"global",keys:["ctrl+shift+alt+a"],command:ie("showAgentContext"),everywhere:!0},{id:"agent.sendLatest",label:"Send the latest capture to the agent",scope:"global",keys:["ctrl+shift+alt+v"],command:ie("sendLatestContext"),everywhere:!0},{id:"open.history",label:"History",scope:"global",keys:["ctrl+h"],mac:["cmd+y"],command:ie("showHistory")},{id:"open.downloads",label:"Downloads",scope:"global",keys:["shift+alt+l"],command:ie("showDownloads")},{id:"open.bookmarks",label:"Bookmark manager",scope:"global",keys:["ctrl+alt+b"],command:ie("showBookmarks")},{id:"open.bookmarksBar",label:"Show or hide the bookmarks bar",scope:"global",keys:["ctrl+shift+b"]},{id:"open.quickActions",label:"Quick actions",scope:"global",keys:["ctrl+shift+k"]},{id:"open.shortcuts",label:"Change keyboard shortcuts",scope:"global",keys:["ctrl+alt+k"],command:ie("editShortcuts")},{id:"open.cheatSheet",label:"Keyboard shortcuts of this mode",scope:"global",keys:["ctrl+shift+/"],mac:["cmd+alt+/"]},{id:"mode.inspect",label:"Element picker",scope:"global",keys:["shift+alt+e"]},{id:"mode.draw",label:"Draw on the page",scope:"global",keys:["shift+alt+w"]},{id:"mode.screenshot",label:"Screenshot",scope:"global",keys:["shift+alt+g"]},{id:"mode.devtools",label:"Console and network",scope:"global",keys:["shift+alt+j"]},{id:"mode.device",label:"Device toolbar",scope:"global",keys:["shift+alt+m"]},{id:"mode.measure",label:"Measure",scope:"global",keys:["shift+alt+u"]},{id:"mode.eyedropper",label:"Eyedropper",scope:"global",keys:["shift+alt+y"]},{id:"mode.overlay",label:"Design overlay",scope:"global",keys:["shift+alt+o"]},{id:"mode.tweak",label:"CSS tweak",scope:"global",keys:["shift+alt+v"]},{id:"mode.record",label:"Record the page",scope:"global",keys:["ctrl+alt+r"]},{id:"mode.a11y",label:"Accessibility check",scope:"global",keys:["shift+alt+h"]},{id:"inspect.parent",label:"Select the parent element",scope:"inspect",keys:["up"]},{id:"inspect.child",label:"Select the first child element",scope:"inspect",keys:["down"]},{id:"inspect.copy",label:"Copy the selected elements",scope:"inspect",keys:["enter","c"]},{id:"inspect.screenshot",label:"Screenshot the element",scope:"inspect",keys:["s"]},{id:"inspect.agent",label:"Send the element to the agent",scope:"inspect",keys:["a"]},{id:"inspect.help",label:"Show these shortcuts",scope:"inspect",keys:["shift+/"]},{id:"inspect.exit",label:"Exit",scope:"inspect",keys:["escape"]},{id:"draw.select",label:"Select and move",scope:"draw",keys:["v"]},{id:"draw.pen",label:"Pen",scope:"draw",keys:["p"]},{id:"draw.pencil",label:"Pencil",scope:"draw",keys:["i"]},{id:"draw.marker",label:"Marker",scope:"draw",keys:["m"]},{id:"draw.brush",label:"Brush",scope:"draw",keys:["u"]},{id:"draw.highlighter",label:"Highlighter",scope:"draw",keys:["h"]},{id:"draw.neon",label:"Neon",scope:"draw",keys:["g"]},{id:"draw.line",label:"Line",scope:"draw",keys:["l"]},{id:"draw.arrow",label:"Arrow",scope:"draw",keys:["a"]},{id:"draw.doubleArrow",label:"Double arrow",scope:"draw",keys:["d"]},{id:"draw.rect",label:"Rectangle",scope:"draw",keys:["r"]},{id:"draw.ellipse",label:"Ellipse",scope:"draw",keys:["o"]},{id:"draw.text",label:"Text",scope:"draw",keys:["t"]},{id:"draw.callout",label:"Numbered callout",scope:"draw",keys:["n"]},{id:"draw.blur",label:"Redact (pixelate)",scope:"draw",keys:["b"]},{id:"draw.eraser",label:"Eraser",scope:"draw",keys:["e"]},...[1,2,3,4,5,6,7,8,9].map(e=>({id:`draw.color${e}`,label:`Color ${e}`,scope:"draw",keys:[String(e)]})),{id:"draw.thinner",label:"Thinner stroke",scope:"draw",keys:["["]},{id:"draw.thicker",label:"Thicker stroke",scope:"draw",keys:["]"]},{id:"draw.fill",label:"Fill shapes on or off",scope:"draw",keys:["f"]},{id:"draw.undo",label:"Undo",scope:"draw",keys:["ctrl+z"]},{id:"draw.redo",label:"Redo",scope:"draw",keys:["ctrl+y","ctrl+shift+z"]},{id:"draw.clear",label:"Clear all drawings",scope:"draw",keys:["shift+backspace"]},{id:"draw.visible",label:"Hide or show drawings",scope:"draw",keys:["w"]},{id:"draw.capture",label:"Screenshot the drawing area",scope:"draw",keys:["enter"]},{id:"draw.captureAgent",label:"Screenshot the drawing area and send it to the agent",scope:"draw",keys:["shift+enter"]},{id:"draw.captureMenu",label:"Screenshot menu",scope:"draw",keys:["s"]},{id:"draw.captureGroups",label:"Screenshot each drawing separately",scope:"draw",keys:["alt+g"]},{id:"draw.captureClean",label:"Screenshot the drawing area without drawings",scope:"draw",keys:["alt+c"]},{id:"draw.captureViewport",label:"Screenshot the visible area with drawings",scope:"draw",keys:["alt+v"]},{id:"draw.captureFullPage",label:"Screenshot the full page with drawings",scope:"draw",keys:["alt+f"]},{id:"draw.help",label:"Show these shortcuts",scope:"draw",keys:["shift+/"]},{id:"draw.exit",label:"Stop drawing",scope:"draw",keys:["escape"]},{id:"shot.viewport",label:"Visible area",scope:"screenshot",keys:["v"]},{id:"shot.fullPage",label:"Full page",scope:"screenshot",keys:["f"]},{id:"shot.region",label:"Region",scope:"screenshot",keys:["r"]},{id:"shot.element",label:"Element",scope:"screenshot",keys:["e"]},{id:"shot.drawing",label:"Drawing area",scope:"screenshot",keys:["d"]},{id:"shot.lastToAgent",label:"Send the last screenshot to the agent",scope:"screenshot",keys:["a"],command:ie("screenshot.sendToTerminal")},{id:"send.default",label:"Send to the default agent",scope:"send",keys:["enter"]},{id:"send.newThread",label:"New agentmux thread",scope:"send",keys:["n"]},{id:"send.project",label:"Change project",scope:"send",keys:["p"]},{id:"send.copy",label:"Copy",scope:"send",keys:["c"]},{id:"send.download",label:"Download",scope:"send",keys:["d"]},{id:"send.close",label:"Close (keep it saved)",scope:"send",keys:["escape"]},{id:"dev.console",label:"Console",scope:"devtools",keys:["alt+1"]},{id:"dev.network",label:"Network",scope:"devtools",keys:["alt+2"]},{id:"dev.filter",label:"Filter",scope:"devtools",keys:["alt+f"]},{id:"dev.copyErrors",label:"Copy console errors",scope:"devtools",keys:["alt+e"]},{id:"dev.copyFailed",label:"Copy failed requests",scope:"devtools",keys:["alt+q"]},{id:"dev.copyContext",label:"Copy page context",scope:"devtools",keys:["alt+p"]},{id:"dev.contextAgent",label:"Send page context to the agent",scope:"devtools",keys:["alt+shift+p"]},{id:"dev.clear",label:"Clear",scope:"devtools",keys:["alt+k"]},{id:"dev.close",label:"Close",scope:"devtools",keys:["alt+w"]},{id:"device.previous",label:"Previous device",scope:"device",keys:["alt+["]},{id:"device.next",label:"Next device",scope:"device",keys:["alt+]"]},{id:"device.rotate",label:"Rotate",scope:"device",keys:["alt+r"]},{id:"device.touch",label:"Touch and mobile on or off",scope:"device",keys:["alt+t"]},{id:"device.fit",label:"Fit to window",scope:"device",keys:["alt+0"]},{id:"device.zoomIn",label:"Zoom in",scope:"device",keys:["alt+="]},{id:"device.zoomOut",label:"Zoom out",scope:"device",keys:["alt+-"]},{id:"device.network",label:"Next network speed",scope:"device",keys:["alt+n"]},{id:"device.theme",label:"Next color scheme",scope:"device",keys:["alt+l"]},{id:"device.close",label:"Close the device toolbar",scope:"device",keys:[]},{id:"measure.grid",label:"Rulers and grid on or off",scope:"measure",keys:["g"]},{id:"measure.copy",label:"Copy the measurements",scope:"measure",keys:["c"]},{id:"measure.clear",label:"Clear the pinned element",scope:"measure",keys:["backspace"]},{id:"measure.help",label:"Show these shortcuts",scope:"measure",keys:["shift+/"]},{id:"measure.exit",label:"Exit",scope:"measure",keys:["escape"]},{id:"eyedropper.hex",label:"Copy colors as hex",scope:"eyedropper",keys:["h"]},{id:"eyedropper.rgb",label:"Copy colors as rgb()",scope:"eyedropper",keys:["r"]},{id:"eyedropper.hsl",label:"Copy colors as hsl()",scope:"eyedropper",keys:["l"]},{id:"eyedropper.help",label:"Show these shortcuts",scope:"eyedropper",keys:["shift+/"]},{id:"eyedropper.exit",label:"Exit",scope:"eyedropper",keys:["escape"]},{id:"overlay.open",label:"Open an image",scope:"overlay",keys:["alt+o"]},{id:"overlay.fainter",label:"Less opaque",scope:"overlay",keys:["alt+,"]},{id:"overlay.stronger",label:"More opaque",scope:"overlay",keys:["alt+."]},{id:"overlay.left",label:"Nudge left",scope:"overlay",keys:["alt+left"]},{id:"overlay.right",label:"Nudge right",scope:"overlay",keys:["alt+right"]},{id:"overlay.up",label:"Nudge up",scope:"overlay",keys:["alt+up"]},{id:"overlay.down",label:"Nudge down",scope:"overlay",keys:["alt+down"]},{id:"overlay.difference",label:"Difference blend on or off",scope:"overlay",keys:["alt+x"]},{id:"overlay.hide",label:"Hide or show the overlay",scope:"overlay",keys:["alt+h"]},{id:"overlay.exit",label:"Close the overlay",scope:"overlay",keys:["alt+z"]},{id:"tweak.agent",label:"Send the CSS changes to the agent",scope:"tweak",keys:["ctrl+enter"]},{id:"tweak.copy",label:"Copy the CSS changes",scope:"tweak",keys:["ctrl+shift+c"]},{id:"tweak.undo",label:"Undo the last change",scope:"tweak",keys:["ctrl+z"]},{id:"tweak.exit",label:"Exit and revert",scope:"tweak",keys:["escape"]},{id:"record.stop",label:"Stop and save",scope:"record",keys:["alt+s"]},{id:"record.pause",label:"Pause or resume",scope:"record",keys:["alt+y"]},{id:"record.cancel",label:"Cancel",scope:"record",keys:["alt+backspace"]},{id:"a11y.next",label:"Next issue",scope:"a11y",keys:["n","down"]},{id:"a11y.previous",label:"Previous issue",scope:"a11y",keys:["p","up"]},{id:"a11y.tabOrder",label:"Tab order on or off",scope:"a11y",keys:["t"]},{id:"a11y.copy",label:"Copy the report",scope:"a11y",keys:["c"]},{id:"a11y.agent",label:"Send the report to the agent",scope:"a11y",keys:["a"]},{id:"a11y.help",label:"Show these shortcuts",scope:"a11y",keys:["shift+/"]},{id:"a11y.exit",label:"Exit",scope:"a11y",keys:["escape"]}];function cl(e,t){return t?[...e.mac??e.keys.map(n=>n.replace(/\bctrl\+/,"cmd+"))]:[...e.keys]}function ks(e){let t=rp(e.trim());return t.key?[t.ctrl&&"ctrl",t.shift&&"shift",t.alt&&"alt",t.meta&&"cmd",t.key].filter(Boolean).join("+"):""}function Ss(e,t){let n={};for(let o of kn){let a=e[o.id],i=(a===void 0?cl(o,t):typeof a=="string"?[a]:[...a]).map(ks);n[o.id]=[...new Set(i.filter(Boolean))]}return n}function Q0(e){if(!e||typeof e!="object"||Array.isArray(e))return{};let t=new Set(kn.map(o=>o.id)),n={};for(let[o,a]of Object.entries(e))t.has(o)&&(typeof a=="string"||Array.isArray(a)&&a.every(i=>typeof i=="string"))&&(n[o]=a);return n}var q0=new Set(["devtools","device","overlay","record"]);function Z0(e){let t=new Map(kn.map(a=>[a.id,a.scope])),n=new Map;for(let[a,i]of Object.entries(e))for(let r of i)n.set(r,[...n.get(r)??[],a]);let o=[];for(let[a,i]of n)for(let r=0;r<i.length;r++)for(let l=r+1;l<i.length;l++){let[c,s]=[t.get(i[r]),t.get(i[l])];(c===s||q0.has(c)&&q0.has(s))&&o.push({key:a,ids:[i[r],i[l]]})}return o}function sl(e,t,n){let o=Es(n);for(let a of t){let i=kn.find(r=>r.scope===a&&(e[r.id]??[]).includes(o));if(i)return i}}function Es(e){return[e.ctrl&&"ctrl",e.shift&&"shift",e.alt&&"alt",e.meta&&"cmd",e.key].filter(Boolean).join("+")}var ip=new Set(["mode.inspect","mode.draw","mode.screenshot","mode.device","mode.devtools","page.bookmark","open.shortcuts","inspect.parent","inspect.child","inspect.copy","inspect.exit",...["select","pen","pencil","marker","brush","highlighter","neon","line","arrow","doubleArrow","rect","ellipse","text","callout","blur","eraser"].map(e=>`draw.${e}`),...Array.from({length:9},(e,t)=>`draw.color${t+1}`),"draw.thinner","draw.thicker","draw.fill","draw.undo","draw.redo","draw.clear","draw.visible","draw.capture","draw.captureMenu","draw.captureGroups","draw.captureClean","draw.captureViewport","draw.captureFullPage","draw.exit","shot.viewport","shot.fullPage","shot.region","shot.element","shot.drawing","send.default","send.newThread","send.project","send.copy","send.download","send.close"]),C2=new Set([]),Y0={id:"vs",label:"VS",title:"Works in VS Code Browser"},V0={id:"br",label:"BR",title:"Works in the Inkspect toolbar in your browser (Chrome, Edge, Firefox...)"};function P0(e){return C2.has(e.scope)?[V0]:ip.has(e.id)?[Y0,V0]:[Y0]}var N2={control:"ctrl",ctl:"ctrl","\u2303":"ctrl",option:"alt",opt:"alt","\u2325":"alt",command:"cmd",meta:"cmd",win:"cmd",super:"cmd","\u2318":"cmd","\u21E7":"shift",esc:"escape",return:"enter","\u21A9":"enter",del:"delete","\u2191":"up","\u2193":"down","\u2190":"left","\u2192":"right",pgup:"pageup",pgdn:"pagedown","+":"="},K0=new Set(["ctrl","shift","alt","cmd"]);function $0(e,t){let n=t.toLowerCase().replace(/([⌃⌥⇧⌘↩↑↓←→])/g," $1 ").split(/\s+|[+-](?=.)/).filter(Boolean).map(c=>N2[c]??c);if(!n.length)return!1;let o=n.filter(c=>K0.has(c)),a=n.filter(c=>!K0.has(c));if(a.length>1)return!1;let i=rp(ks(e)),r={ctrl:i.ctrl,shift:i.shift,alt:i.alt,cmd:i.meta};if(!o.every(c=>r[c]))return!1;let[l]=a;return l===void 0||i.key.startsWith(l)}function J0(e){if(!e.key)return;let t=/^f([1-9]|1\d|2[0-4])$/.test(e.key);return e.ctrl||e.alt||e.meta||t?Es(e):void 0}function Yi(e,t){let n=It(e,t);return t?[...[...n.matchAll(/[⌃⌥⇧⌘]/g)].map(a=>a[0]),n.replace(/[⌃⌥⇧⌘]/g,"")]:n.split(/\+(?=.)/)}var I0={global:"browser",inspect:"inspect",draw:"edit",screenshot:"device-camera",devtools:"debug-console",device:"device-mobile",measure:"symbol-ruler",eyedropper:"symbol-color",overlay:"layers",tweak:"symbol-property",record:"record",a11y:"accessibility",send:"send"};function It(e,t){let n=rp(e),o={escape:"Esc",enter:t?"\u21A9":"Enter",backspace:t?"\u232B":"Backspace",delete:t?"\u2326":"Delete",up:"\u2191",down:"\u2193",left:"\u2190",right:"\u2192",pageup:"PgUp",pagedown:"PgDn",tab:t?"\u21E5":"Tab",space:"Space","/":n.shift?"?":"/"},a=!(n.key==="/"&&n.shift),i=o[n.key]??(n.key.length===1?n.key.toUpperCase():n.key[0].toUpperCase()+n.key.slice(1));return t?`${n.ctrl?"\u2303":""}${n.alt?"\u2325":""}${n.shift&&a?"\u21E7":""}${n.meta?"\u2318":""}${i}`:[n.ctrl&&"Ctrl",n.alt&&"Alt",n.shift&&a&&"Shift",i].filter(Boolean).join("+")}function rp(e){let t=e.toLowerCase().split("+"),n=t.pop()??"";return{ctrl:t.includes("ctrl"),shift:t.includes("shift"),alt:t.includes("alt"),meta:t.includes("cmd")||t.includes("meta")||t.includes("win"),key:n}}var M2={arrowleft:"left",arrowright:"right",arrowup:"up",arrowdown:"down",esc:"escape"," ":"space","+":"="},X0={Equal:"=",Minus:"-",BracketLeft:"[",BracketRight:"]",Slash:"/",Backslash:"\\",Comma:",",Period:".",Semicolon:";",Quote:"'",Backquote:"`",NumpadAdd:"=",NumpadSubtract:"-"},Ts=new Set(["Control","Shift","Alt","Meta","AltGraph","OS"]),G0={"?":"/","<":",",">":".",":":";",'"':"'","{":"[","}":"]","|":"\\","~":"`",_:"-","+":"=","!":"1","@":"2","#":"3",$:"4","%":"5","^":"6","&":"7","*":"8","(":"9",")":"0"};function uo(e){let t={ctrl:e.ctrlKey,shift:e.shiftKey,alt:e.altKey,meta:e.metaKey};if(e.getModifierState?.("AltGraph"))return{...t,key:""};let n=e.key,o;return/^[a-z0-9]$/i.test(n)?o=n.toLowerCase():e.shiftKey&&G0[n]!==void 0?o=G0[n]:/^[-=[\]\\/,.;'`+]$/.test(n)?o=n:/^Key[A-Z]$/.test(e.code)?o=e.code.slice(3).toLowerCase():/^Digit\d$/.test(e.code)?o=e.code.slice(5):X0[e.code]?o=X0[e.code]:o=n.toLowerCase(),{...t,key:M2[o]??o}}var Ma=_(U(),1);function Ns({icon:e,trailing:t,size:n="md",onClear:o,invalid:a,className:i,disabled:r,...l}){let c=l.value!==void 0&&String(l.value)!=="";return(0,Ma.jsxs)("div",{className:ae("text-field",`size-${n}`,a&&"invalid",r&&"disabled",i),children:[e&&(0,Ma.jsx)("span",{className:`codicon codicon-${e} text-field-icon`,"aria-hidden":"true"}),(0,Ma.jsx)("input",{spellCheck:!1,...l,disabled:r,"aria-invalid":a||void 0}),o&&c&&(0,Ma.jsx)("button",{type:"button",className:"text-field-clear","aria-label":"Clear",title:"Clear",tabIndex:-1,onClick:o,children:(0,Ma.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})}),t]})}var oy=_(U(),1),O2=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),fo=null;function ty(e){return fo?(fo(e),!0):!1}typeof window<"u"&&window.addEventListener("keydown",e=>{if(!fo||Ts.has(e.key))return;e.stopImmediatePropagation();let t=J0(uo(e));t&&(e.preventDefault(),fo(t))},!0);function ny({value:e,onChange:t,size:n}){let o=(0,Aa.useRef)(t);(0,Aa.useEffect)(()=>{o.current=t});let[a]=(0,Aa.useState)(()=>i=>o.current(It(i,O2)));return(0,Aa.useEffect)(()=>()=>{fo===a&&(fo=null)},[a]),(0,oy.jsx)(Ns,{size:n,icon:"search",placeholder:"Search actions or keys, or press a shortcut","aria-label":"Search shortcuts: type, or press a shortcut",value:e,onChange:i=>t(i.target.value),onClear:()=>t(""),onFocus:()=>{fo=a},onBlur:()=>{fo===a&&(fo=null)}})}var D=_(_e());var iy=["pen","pencil","marker","brush","highlighter","neon"],lp=["line","arrow","doubleArrow","rect","ellipse","blur"];function As(e,t){if(!t)return e;let n=[];for(let o of e){if(!o.anchor){n.push(o);continue}let a=t[o.anchor];a&&n.push(zs(o,-a.x,-a.y))}return n}function ry(e){try{let t=new URL(e);return/^#!?\//.test(t.hash)||(t.hash=""),t.href}catch{return e}}function ly(e,t){let n=Math.max(e.x,t.x),o=Math.max(e.y,t.y),a=Math.min(e.x+e.width,t.x+t.width),i=Math.min(e.y+e.height,t.y+t.height);return a>n&&i>o?{x:n,y:o,width:a-n,height:i-o}:void 0}var Vi=["#ff3b30","#ff9500","#ffcc00","#34c759","#00c7be","#007aff","#af52de","#ffffff","#000000"],za={color:"#ff3b30",width:4,opacity:1,dash:"solid",fill:!1};function cp(e){return 12+e.width*2}function sp(e){return 10+e.width}function ul(e){let t=e.style.width/2+(e.kind==="stroke"&&e.tool==="neon"?8:0),n;switch(e.kind){case"stroke":n=e.points.map(([o,a])=>[o,a]);break;case"text":{let o=cp(e.style),a=e.text.split(`
`),i=Math.max(...a.map(r=>r.length))*o*.6;n=[e.at,[e.at[0]+i,e.at[1]+a.length*o*1.25]];break}case"callout":{let o=sp(e.style);n=[[e.at[0]-o,e.at[1]-o],[e.at[0]+o,e.at[1]+o]];break}default:{let o=e.kind==="arrow"||e.kind==="doubleArrow"?up(e.style):0;return n=[e.start,e.end],Ms(ay(n),t+o)}}return Ms(ay(n),t)}function up(e){return 8+e.width*2.5}function ay(e){let t=e.map(i=>i[0]),n=e.map(i=>i[1]),o=Math.min(...t),a=Math.min(...n);return{x:o,y:a,width:Math.max(...t)-o,height:Math.max(...n)-a}}function Ms(e,t){return{x:e.x-t,y:e.y-t,width:e.width+t*2,height:e.height+t*2}}function cy(e){if(!e.length)return;let t=Math.min(...e.map(i=>i.x)),n=Math.min(...e.map(i=>i.y)),o=Math.max(...e.map(i=>i.x+i.width)),a=Math.max(...e.map(i=>i.y+i.height));return{x:t,y:n,width:o-t,height:a-n}}function R2(e,t){let n=Math.max(0,e.x),o=Math.max(0,e.y),a=t?Math.min(t.width,e.x+e.width):e.x+e.width,i=t?Math.min(t.height,e.y+e.height):e.y+e.height;return{x:n,y:o,width:Math.max(1,a-n),height:Math.max(1,i-o)}}function sy(e,t){let n=cy(e.map(ul));return n&&R2(Ms(n,t))}function D2(e,t,n){return e.x-n<=t.x+t.width&&t.x-n<=e.x+e.width&&e.y-n<=t.y+t.height&&t.y-n<=e.y+e.height}function uy(e,t){let n=[];for(let o of e){let a=ul(o),i=n.filter(l=>D2(l.bounds,a,t)),r={shapes:[...i.flatMap(l=>l.shapes),o],bounds:cy([a,...i.map(l=>l.bounds)])};for(let l of i)n.splice(n.indexOf(l),1);n.push(r)}return n.sort((o,a)=>o.bounds.y-a.bounds.y).map(o=>o.shapes)}function dy(e,t,n){let o=Ms(ul(e),n);if(!(t[0]>=o.x&&t[0]<=o.x+o.width&&t[1]>=o.y&&t[1]<=o.y+o.height))return!1;if(e.kind==="stroke"){let i=n+e.style.width/2;return e.points.some(([r,l])=>Math.hypot(r-t[0],l-t[1])<=i+4)}return e.kind==="line"||e.kind==="arrow"||e.kind==="doubleArrow"?_2(t,e.start,e.end)<=n+e.style.width/2:!0}function _2(e,t,n){let o=n[0]-t[0],a=n[1]-t[1],i=o*o+a*a,r=i?Math.max(0,Math.min(1,((e[0]-t[0])*o+(e[1]-t[1])*a)/i)):0;return Math.hypot(e[0]-(t[0]+r*o),e[1]-(t[1]+r*a))}function zs(e,t,n){let o=([a,i])=>[a+t,i+n];switch(e.kind){case"stroke":return{...e,points:e.points.map(([a,i,r])=>[a+t,i+n,r])};case"text":case"callout":return{...e,at:o(e.at)};default:return{...e,start:o(e.start),end:o(e.end)}}}function fy(e,t,n){let o=n[0]-t[0],a=n[1]-t[1];if(e==="rect"||e==="ellipse"||e==="blur"){let l=Math.max(Math.abs(o),Math.abs(a));return[t[0]+Math.sign(o||1)*l,t[1]+Math.sign(a||1)*l]}let i=Math.round(Math.atan2(a,o)/(Math.PI/4))*(Math.PI/4),r=Math.hypot(o,a);return[t[0]+Math.cos(i)*r,t[1]+Math.sin(i)*r]}function py(e){if(!Array.isArray(e))return[];let t=n=>Array.isArray(n)&&n.length>=2&&n.every(o=>typeof o=="number"&&Number.isFinite(o));return e.filter(n=>{if(typeof n!="object"||n===null)return!1;let o=n,a=o.style;if(typeof o.id!="string"||o.anchor!==void 0&&(typeof o.anchor!="string"||o.anchor.length>1e3)||typeof a?.color!="string"||typeof a.width!="number")return!1;switch(o.kind){case"stroke":return Array.isArray(o.points)&&o.points.length>0&&o.points.length<2e4&&o.points.every(t);case"text":return t(o.at)&&typeof o.text=="string"&&o.text.length<5e3;case"callout":return t(o.at)&&typeof o.number=="number";default:return lp.includes(o.kind)&&t(o.start)&&t(o.end)}}).slice(0,2e3)}function my(e,t,n){let o=["data-testid","data-test","data-cy","data-qa","aria-label","name"],a=m=>/^(css|sc|jsx|emotion|svelte)-|__[a-z0-9]{5,}$|[_-][a-f0-9]{6,}$|\d{3,}|[:[\]/()]/i.test(m),i=m=>{try{return t(m)===1}catch{return!1}},r=m=>{let u=m.tagName.toLowerCase(),d=[];m.id&&!a(m.id)&&d.push(`#${n(m.id)}`);for(let k of o){let E=m.getAttribute(k);E&&E.length<80&&d.push(`${u}[${k}="${E.replace(/"/g,'\\"')}"]`)}let x=Array.from(m.classList).filter(k=>!a(k)).slice(0,3).map(k=>`.${n(k)}`);return x.length&&d.push(u+x.join("")),d.push(u),d},l=m=>{let u=m.tagName.toLowerCase(),d=m.parentElement;if(!d)return u;let x=Array.from(d.children).filter(k=>k.tagName===m.tagName);return x.length>1?`${u}:nth-of-type(${x.indexOf(m)+1})`:u};for(let m of r(e))if(i(m))return m;let c=r(e).find(m=>m!==e.tagName.toLowerCase())??l(e);i(c)||(c=l(e));let s=e.parentElement;for(;s&&!i(c);){let m=r(s).find(u=>i(u));if(m)return c=`${m} > ${c}`,i(c)?c:`${m} > ${f(e,s,l)}`;c=`${l(s)} > ${c}`,s=s.parentElement}return c;function f(m,u,d){let x=[];for(let k=m;k&&k!==u;k=k.parentElement)x.unshift(d(k));return x.join(" > ")}}function gy(e){let t=[];for(let n=e;n;n=n.parentElement){let o=n.tagName.toLowerCase(),a=n.parentElement,i=a?Array.from(a.children).filter(r=>r.tagName===n.tagName):[];t.unshift(i.length>1?`${o}[${i.indexOf(n)+1}]`:o)}return`/${t.join("/")}`}var dp=["page","selector","xpath","role","component","box","text","styles","attributes","html"];function dl(e){return`${e.tag}${e.id?`#${e.id}`:""}${e.classes.slice(0,3).map(t=>`.${t}`).join("")}`}function H2(e){let t=e.file?` (${e.file}${e.line?`:${e.line}`:""})`:"";return`\`<${e.name}>\`${t} [${e.framework}]`}function fp(e,t,n=dp){switch(t){case"selector":return e.map(o=>o.selector).join(`
`);case"html":return e.map(o=>o.html).join(`

`);case"json":{let o=a=>{let i={element:dl(a)};return n.includes("page")&&(i.page={url:a.pageUrl,title:a.pageTitle,viewport:a.viewport,frameUrl:a.frameUrl}),n.includes("selector")&&(i.selector=a.selector),n.includes("xpath")&&(i.xpath=a.xpath),n.includes("role")&&(i.role=a.role?{role:a.role,name:a.name}:void 0),n.includes("component")&&(i.component=a.component),n.includes("box")&&(i.box=a.rect),n.includes("text")&&(i.text=a.text),n.includes("styles")&&(i.styles=a.styles),n.includes("attributes")&&(i.attributes=a.attributes),n.includes("html")&&(i.html=a.html),a.screenshot&&(i.screenshot=a.screenshot),i};return JSON.stringify(e.length===1?o(e[0]):e.map(o),null,2)}case"markdown":return e.map((o,a)=>{let i=[`### ${e.length>1?`${a+1}. `:""}Element: \`${dl(o)}\``];if(n.includes("page")&&(i.push(`- Page: ${o.pageUrl} (${o.viewport.width}\xD7${o.viewport.height})`),o.frameUrl&&i.push(`- Frame: ${o.frameUrl}`)),n.includes("selector")&&i.push(`- Selector: \`${o.selector}\``),n.includes("xpath")&&i.push(`- XPath: \`${o.xpath}\``),n.includes("role")&&o.role&&i.push(`- Role/name: ${o.role}${o.name?` "${o.name}"`:""}`),n.includes("component")&&o.component&&i.push(`- Component: ${H2(o.component)}`),n.includes("box")){let r=o.rect;i.push(`- Box: ${Math.round(r.width)}\xD7${Math.round(r.height)} at (${Math.round(r.x)}, ${Math.round(r.y)})`)}if(n.includes("text")&&o.text&&i.push(`- Text: "${o.text}"`),n.includes("styles")){let r=Object.entries(o.styles).map(([l,c])=>`${l}:${c}`).join("; ");r&&i.push(`- Styles: ${r}`)}if(n.includes("attributes")){let r=Object.entries(o.attributes).filter(([l])=>l!=="class"&&l!=="id"&&l!=="style").map(([l,c])=>`${l}="${c}"`).join(" ");r&&i.push(`- Attributes: ${r}`)}return o.screenshot&&i.push(`- Screenshot: ${o.screenshot}`),n.includes("html")&&i.push("```html",o.html,"```"),i.join(`
`)}).join(`

`)}}var B2=["display","position","width","height","margin","padding","color","background-color","font-family","font-size","font-weight","line-height","border","border-radius","z-index","flex-direction","justify-content","align-items","gap","grid-template-columns","opacity","overflow"];function by(e,t,n){let o=e.ownerDocument,a=o.defaultView||window,i=e.getRootNode(),r="querySelectorAll"in i?i:o,l=p=>a.CSS&&a.CSS.escape?a.CSS.escape(p):p,c=n.buildSelector(e,p=>r.querySelectorAll(p).length,l);if(r!==o&&"host"in r&&r.host){let p=r.host.getRootNode();c=n.buildSelector(r.host,h=>("querySelectorAll"in p?p:o).querySelectorAll(h).length,l)+" >>> "+c}let s=e.getBoundingClientRect(),f={};for(let p of Array.from(e.attributes||[]))f[p.name]=p.value.slice(0,300);let u=(e.innerText||e.textContent||"").replace(/\s+/g," ").trim().slice(0,200)||void 0,d=e.outerHTML||"";if(d.length>t){let p=e.cloneNode(!1);e.children.length?p.innerHTML="\u2026":p.textContent=(e.textContent||"").slice(0,80)+"\u2026",d=p.outerHTML.slice(0,t)}let x=a.getComputedStyle(e),k={};for(let p of n.styleProperties){let v=x.getPropertyValue(p);!v||/^(none|normal|auto|0px|static|visible|1|rgba\(0, 0, 0, 0\)|0px none .*)$/.test(v)||(k[p]=v.length>80?v.slice(0,80)+"\u2026":v)}let E=(()=>{try{let p=e,v=Object.keys(p).find(w=>w.startsWith("__reactFiber$")||w.startsWith("__reactInternalInstance$"));if(v)for(let w=p[v];w;w=w.return){let S=w.type;if(!S||typeof S=="string")continue;let M=S.displayName||S.name||S.render&&(S.render.displayName||S.render.name);if(!M)continue;let A=w._debugSource&&w._debugSource.fileName,H=w._debugSource&&w._debugSource.lineNumber,B=w._debugStack&&w._debugStack.stack;if(!A&&typeof B=="string"){let Y=B.split(`
`).slice(1).find(Ge=>!/node_modules|react-dom|react-stack|jsx-dev-runtime|chunk-/.test(Ge))||"",I=/\(?((?:https?|file|webpack[\w-]*):\/\/[^\s)]+?):(\d+):\d+\)?\s*$/.exec(Y);I&&(A=I[1],H=Number(I[2]))}return{framework:"react",name:M,file:A,line:H}}let h=p.__vueParentComponent;if(h){let w=h.type||{},S=w.__file;return{framework:"vue",name:w.name||w.__name||(S?String(S).split("/").pop().replace(/\.vue$/,""):"Anonymous"),file:S}}if(p.__vue__){let w=p.__vue__.$options||{};return{framework:"vue",name:w.name||w._componentTag||"Anonymous",file:w.__file}}for(let w=p;w;w=w.parentElement)if(w.__svelte_meta){let S=w.__svelte_meta.loc||{};return{framework:"svelte",name:S.file?String(S.file).split("/").pop().replace(/\.svelte$/,""):"Component",file:S.file,line:typeof S.line=="number"?S.line+1:void 0}}let T=a.ng;if(T&&T.getOwningComponent){let w=T.getComponent(e)||T.getOwningComponent(e);if(w)return{framework:"angular",name:w.constructor.name}}}catch{}})(),g=a.location.href,b=o.title;try{g=a.top.location.href,b=a.top.document.title}catch{}return{tag:e.tagName.toLowerCase(),id:e.id||void 0,classes:Array.from(e.classList||[]),selector:c,xpath:n.buildXPath(e),text:u,html:d,attributes:f,rect:{x:s.x,y:s.y,width:s.width,height:s.height},styles:k,component:E,pageUrl:g,pageTitle:b,viewport:{width:a.innerWidth,height:a.innerHeight},frameUrl:a!==a.top?a.location.href:void 0,scroll:{x:a.scrollX,y:a.scrollY}}}var hy={buildSelector:my,buildXPath:gy,styleProperties:B2};var L2={a:"link",article:"article",aside:"complementary",button:"button",dialog:"dialog",footer:"contentinfo",form:"form",h1:"heading",h2:"heading",h3:"heading",h4:"heading",h5:"heading",h6:"heading",header:"banner",hr:"separator",img:"img",li:"listitem",main:"main",nav:"navigation",ol:"list",option:"option",progress:"progressbar",section:"region",select:"combobox",table:"table",textarea:"textbox",ul:"list"},U2={button:"button",checkbox:"checkbox",email:"textbox",image:"button",number:"spinbutton",radio:"radio",range:"slider",reset:"button",search:"searchbox",submit:"button",tel:"textbox",text:"textbox",url:"textbox"},j2=new Set(["button","link","heading","listitem","option","tab","menuitem","cell"]);function Os(e){let t=e.tagName.toLowerCase(),n=e.getAttribute("role")?.split(/\s+/)[0]||void 0;n||(t==="input"?n=U2[(e.getAttribute("type")||"text").toLowerCase()]:t==="a"?n=e.hasAttribute("href")?"link":void 0:t==="section"?n=e.hasAttribute("aria-label")?"region":void 0:n=L2[t]);let o=r=>(r||"").replace(/\s+/g," ").trim().slice(0,200)||void 0,a=e.getAttribute("aria-labelledby"),i;if(a&&(i=o(a.split(/\s+/).map(r=>e.ownerDocument.getElementById(r)?.textContent||"").join(" "))),i??=o(e.getAttribute("aria-label")),!i&&(t==="img"||t==="area")&&(i=o(e.getAttribute("alt"))),!i&&"labels"in e){let r=e.labels;r?.length&&(i=o(Array.from(r,l=>l.textContent).join(" ")))}if(!i&&t==="input"){let r=e;["button","submit","reset"].includes(r.type)&&(i=o(r.value)),i??=o(r.placeholder)}return!i&&n&&j2.has(n)&&(i=o(e.innerText||e.textContent)),i??=o(e.getAttribute("title")),{role:n||"generic",name:i}}function vy(e){let t=e.parentElement||(e.getRootNode().host??null);return t&&t.tagName!=="HTML"?t:null}function yy(e){return e.firstElementChild||e.shadowRoot?.firstElementChild||null}var fl=(e,t,n,o,a,i)=>({id:e,name:t,group:"Phones",width:n,height:o,dpr:a,mobile:!0,touch:!0,userAgent:i}),pp=(e,t,n,o,a,i)=>({id:e,name:t,group:"Tablets",width:n,height:o,dpr:a,mobile:!0,touch:!0,userAgent:i}),Ki=(e,t,n)=>({id:`desktop-${e}x${t}`,name:`${n} ${e}\xD7${t}`,group:"Desktops",width:e,height:t,dpr:1,mobile:!1,touch:!1,userAgent:"desktop"}),Xi=[fl("iphone-se","iPhone SE",375,667,2,"iphone"),fl("iphone-16-pro","iPhone 16 Pro",402,874,3,"iphone"),fl("iphone-16-pro-max","iPhone 16 Pro Max",440,956,3,"iphone"),fl("pixel-8","Pixel 8",412,915,2.625,"android"),fl("galaxy-s24","Galaxy S24",360,780,3,"android"),pp("ipad-mini","iPad Mini",768,1024,2,"ipad"),pp("ipad-pro",'iPad Pro 12.9"',1024,1366,2,"ipad"),pp("surface-pro","Surface Pro 7",912,1368,2,"desktop"),Ki(1280,800,"Laptop"),Ki(1366,768,"Laptop"),Ki(1440,900,"Laptop"),Ki(1920,1080,"Full HD"),Ki(2560,1440,"QHD"),Ki(3840,2160,"4K")],xy={none:{label:"No throttling",offline:!1,latency:0,download:-1,upload:-1},offline:{label:"Offline",offline:!0,latency:0,download:0,upload:0},slow3g:{label:"Slow 3G",offline:!1,latency:2e3,download:5e4,upload:5e4},fast3g:{label:"Fast 3G",offline:!1,latency:562.5,download:18e4,upload:84375},fast4g:{label:"Fast 4G",offline:!1,latency:165,download:1012500,upload:168750}},wy=[1,4,6];var mp=50,gp=7680;function Rs(e){return{presetId:e.id,width:e.width,height:e.height,dpr:e.dpr,mobile:e.mobile,touch:e.touch,userAgent:e.userAgent}}function ky(e){return{...e,width:e.height,height:e.width}}function Sy(e,t,n){return e!=="fit"?e:!n.width||!n.height?1:Math.min(1,n.width/t.width,n.height/t.height)}function Ds(e){return!!e.error||e.status!==void 0&&e.status>=400}function Ey(e){if(!e.url)return"";let t=e.line!==void 0?`:${e.line+1}`:"",n=e.line!==void 0&&e.column!==void 0?`:${e.column+1}`:"";return`${e.url}${t}${n}`}function Ty(e,t,n=!1){let o=e.filter(i=>i.level==="error"||n&&i.level==="warning");if(!o.length)return`### Console errors: ${t}
No errors.`;let a=[`### Console errors: ${t} (${o.length})`];return o.forEach((i,r)=>{let[l,...c]=i.text.split(`
`);a.push(`${r+1}. ${i.level==="warning"?"[warning] ":""}${l}`);for(let f of c.slice(0,8))a.push(`   ${f.trim()}`);let s=Ey(i);s&&!i.text.includes(s)&&a.push(`   at ${s}`)}),a.join(`
`)}function Cy(e){let t=e.error?e.canceled?"canceled":e.error:`${e.status}${e.mimeType?` ${e.mimeType}`:""}`,n=e.duration!==void 0?`, ${Math.round(e.duration)} ms`:"";return`- ${e.method} ${e.url} \u2192 ${t} (${e.type}${n})`}function Ny(e,t){let n=e.filter(Ds);return n.length?[`### Failed network requests: ${t} (${n.length})`,...n.map(Cy)].join(`
`):`### Failed network requests: ${t}
No failed requests.`}function My(e){let t=["### Page context",`- URL: ${e.url}`,`- Title: ${e.title}`,`- Viewport: ${e.viewport.width}\xD7${e.viewport.height}${e.device?` (emulating ${e.device})`:""}`];e.selection&&t.push(`- Selected text: "${e.selection.slice(0,500)}"`);let n=e.console.filter(a=>a.level==="error").slice(-5);if(n.length){t.push("",`Recent console errors (${n.length}):`);for(let a of n){let i=Ey(a);t.push(`- ${a.text.split(`
`)[0]}${i?` (${i})`:""}`)}}let o=e.network.filter(Ds).slice(-5);return o.length&&t.push("",`Failed requests (${o.length}):`,...o.map(Cy)),t.join(`
`)}var{PI:q2}=Math,pl=q2+1e-4,Ay=.5,zy=[1,1];function Oy(e,t,n,o=a=>a){return e*o(.5-t*(.5-n))}var{min:bp}=Math;function qy(e,t,n){let o=bp(1,t/n);return bp(1,e+(bp(1,1-o)-e)*(o*.275))}function Y2(e){return[-e[0],-e[1]]}function qn(e,t){return[e[0]+t[0],e[1]+t[1]]}function Ry(e,t,n){return e[0]=t[0]+n[0],e[1]=t[1]+n[1],e}function Jo(e,t){return[e[0]-t[0],e[1]-t[1]]}function yp(e,t,n){return e[0]=t[0]-n[0],e[1]=t[1]-n[1],e}function $o(e,t){return[e[0]*t,e[1]*t]}function hp(e,t,n){return e[0]=t[0]*n,e[1]=t[1]*n,e}function V2(e,t){return[e[0]/t,e[1]/t]}function Yy(e){return[e[1],-e[0]]}function vp(e,t){let n=t[0];return e[0]=t[1],e[1]=-n,e}function Dy(e,t){return e[0]*t[0]+e[1]*t[1]}function K2(e,t){return e[0]===t[0]&&e[1]===t[1]}function X2(e){return Math.hypot(e[0],e[1])}function _y(e,t){let n=e[0]-t[0],o=e[1]-t[1];return n*n+o*o}function Vy(e){return V2(e,X2(e))}function G2(e,t){return Math.hypot(e[1]-t[1],e[0]-t[0])}function xp(e,t,n){let o=Math.sin(n),a=Math.cos(n),i=e[0]-t[0],r=e[1]-t[1],l=i*a-r*o,c=i*o+r*a;return[l+t[0],c+t[1]]}function Hy(e,t,n,o){let a=Math.sin(o),i=Math.cos(o),r=t[0]-n[0],l=t[1]-n[1],c=r*i-l*a,s=r*a+l*i;return e[0]=c+n[0],e[1]=s+n[1],e}function By(e,t,n){return qn(e,$o(Jo(t,e),n))}function Q2(e,t,n,o){let a=n[0]-t[0],i=n[1]-t[1];return e[0]=t[0]+a*o,e[1]=t[1]+i*o,e}function Ky(e,t,n){return qn(e,$o(t,n))}var dt=[0,0],Zo=[0,0],Po=[0,0];function Z2(e,t){let n=Ky(e,Vy(Yy(Jo(e,qn(e,[1,1])))),-t),o=[],a=1/13;for(let i=a;i<=1;i+=a)o.push(xp(n,e,pl*2*i));return o}function P2(e,t,n){let o=[],a=1/n;for(let i=a;i<=1;i+=a)o.push(xp(t,e,pl*i));return o}function $2(e,t,n){let o=Jo(t,n),a=$o(o,.5),i=$o(o,.51);return[Jo(e,a),Jo(e,i),qn(e,i),qn(e,a)]}function J2(e,t,n,o){let a=[],i=Ky(e,t,n),r=1/o;for(let l=r;l<1;l+=r)a.push(xp(i,e,pl*3*l));return a}function I2(e,t,n){return[qn(e,$o(t,n)),qn(e,$o(t,n*.99)),Jo(e,$o(t,n*.99)),Jo(e,$o(t,n))]}function Ly(e,t,n){return e===!1||e===void 0?0:e===!0?Math.max(t,n):e}function F2(e,t,n){return e.slice(0,10).reduce((o,a)=>{let i=a.pressure;return t&&(i=qy(o,a.distance,n)),(o+i)/2},e[0].pressure)}function W2(e,t={}){let{size:n=16,smoothing:o=.5,thinning:a=.5,simulatePressure:i=!0,easing:r=O=>O,start:l={},end:c={},last:s=!1}=t,{cap:f=!0,easing:m=O=>O*(2-O)}=l,{cap:u=!0,easing:d=O=>--O*O*O+1}=c;if(e.length===0||n<=0)return[];let x=e[e.length-1].runningLength,k=Ly(l.taper,n,x),E=Ly(c.taper,n,x),g=(n*o)**2,b=[],p=[],v=F2(e,i,n),h=Oy(n,a,e[e.length-1].pressure,r),T,w=e[0].vector,S=e[0].point,M=S,A=S,H=M,B=!1;for(let O=0;O<e.length;O++){let{pressure:ue}=e[O],{point:Te,vector:Ce,distance:xt,runningLength:Ie}=e[O],Lt=O===e.length-1;if(!Lt&&x-Ie<3)continue;a?(i&&(ue=qy(v,xt,n)),h=Oy(n,a,ue,r)):h=n/2,T===void 0&&(T=h);let R=Ie<k?m(Ie/k):1,j=x-Ie<E?d((x-Ie)/E):1;h=Math.max(.01,h*Math.min(R,j));let G=(Lt?e[O]:e[O+1]).vector,de=Lt?1:Dy(Ce,G),oe=Dy(Ce,w)<0&&!B,De=de!==null&&de<0;if(oe||De){vp(dt,w),hp(dt,dt,h);for(let wt=0;wt<=1;wt+=.07692307692307693)yp(Zo,Te,dt),Hy(Zo,Zo,Te,pl*wt),A=[Zo[0],Zo[1]],b.push(A),Ry(Po,Te,dt),Hy(Po,Po,Te,pl*-wt),H=[Po[0],Po[1]],p.push(H);S=A,M=H,De&&(B=!0);continue}if(B=!1,Lt){vp(dt,Ce),hp(dt,dt,h),b.push(Jo(Te,dt)),p.push(qn(Te,dt));continue}Q2(dt,G,Ce,de),vp(dt,dt),hp(dt,dt,h),yp(Zo,Te,dt),A=[Zo[0],Zo[1]],(O<=1||_y(S,A)>g)&&(b.push(A),S=A),Ry(Po,Te,dt),H=[Po[0],Po[1]],(O<=1||_y(M,H)>g)&&(p.push(H),M=H),v=ue,w=Ce}let Y=[e[0].point[0],e[0].point[1]],I=e.length>1?[e[e.length-1].point[0],e[e.length-1].point[1]]:qn(e[0].point,[1,1]),Ge=[],Re=[];if(e.length===1){if(!(k||E)||s)return Z2(Y,T||h)}else{k||E&&e.length===1||(f?Ge.push(...P2(Y,p[0],13)):Ge.push(...$2(Y,b[0],p[0])));let O=Yy(Y2(e[e.length-1].vector));E||k&&e.length===1?Re.push(I):u?Re.push(...J2(I,O,h,29)):Re.push(...I2(I,O,h))}return b.concat(Re,p.reverse(),Ge)}var Uy=[0,0];function jy(e){return e!=null&&e>=0}function eE(e,t={}){let{streamline:n=.5,size:o=16,last:a=!1}=t;if(e.length===0)return[];let i=.15+(1-n)*.85,r=Array.isArray(e[0])?e:e.map(({x:u,y:d,pressure:x=Ay})=>[u,d,x]);if(r.length===2){let u=r[1];r=r.slice(0,-1);for(let d=1;d<5;d++)r.push(By(r[0],u,d/4))}r.length===1&&(r=[...r,[...qn(r[0],zy),...r[0].slice(2)]]);let l=[{point:[r[0][0],r[0][1]],pressure:jy(r[0][2])?r[0][2]:.25,vector:[...zy],distance:0,runningLength:0}],c=!1,s=0,f=l[0],m=r.length-1;for(let u=1;u<r.length;u++){let d=a&&u===m?[r[u][0],r[u][1]]:By(f.point,r[u],i);if(K2(f.point,d))continue;let x=G2(d,f.point);if(s+=x,u<m&&!c){if(s<o)continue;c=!0}yp(Uy,f.point,d),f={point:d,pressure:jy(r[u][2])?r[u][2]:Ay,vector:Vy(Uy),distance:x,runningLength:s},l.push(f)}return l[0].vector=l[1]?.vector||[0,0],l}function Xy(e,t={}){return W2(eE(e,t),t)}var tE={pen:{size:1.4,thinning:.5},pencil:{size:.7,thinning:.25},marker:{size:2.5,thinning:0},brush:{size:2.2,thinning:.75,taper:!0},highlighter:{size:4,thinning:0,opacity:.35},neon:{size:1.4,thinning:.3}};function _s(e,t,n,o={}){let{anchors:a}=o;if(!a||!t.some(l=>l.anchor)){wp(e,t,n,o);return}let i=new Map,r=[];for(let l of t)l.anchor?i.set(l.anchor,[...i.get(l.anchor)??[],l]):r.push(l);wp(e,r,n,o);for(let[l,c]of i){let s=a[l];if(!s)continue;let{clip:f}=s;e.save(),e.beginPath(),e.rect((f.x-n.offsetX)*n.scale,(f.y-n.offsetY)*n.scale,f.width*n.scale,f.height*n.scale),e.clip(),wp(e,c,{scale:n.scale,offsetX:n.offsetX+s.x,offsetY:n.offsetY+s.y},o),e.restore()}}function wp(e,t,n,o){let a=([i,r])=>[(i-n.offsetX)*n.scale,(r-n.offsetY)*n.scale];for(let i of t)i.kind==="blur"&&!o.skipRedactions&&aE(e,i,a,o.pixelSource);for(let i of t)if(i.kind!=="blur"){switch(e.save(),nE(e,i.style,n.scale),i.kind){case"stroke":oE(e,i.tool,i.points,i.style,n.scale,a);break;case"line":case"arrow":case"doubleArrow":{let[r,l]=[a(i.start),a(i.end)];e.beginPath(),e.moveTo(r[0],r[1]),e.lineTo(l[0],l[1]),e.stroke(),e.setLineDash([]);let c=up(i.style)*n.scale;i.kind!=="line"&&Gy(e,r,l,c),i.kind==="doubleArrow"&&Gy(e,l,r,c);break}case"rect":{let[r,l]=[a(i.start),a(i.end)],[c,s,f,m]=[Math.min(r[0],l[0]),Math.min(r[1],l[1]),Math.abs(l[0]-r[0]),Math.abs(l[1]-r[1])];i.style.fill&&Qy(e,()=>e.fillRect(c,s,f,m)),e.strokeRect(c,s,f,m);break}case"ellipse":{let[r,l]=[a(i.start),a(i.end)];e.beginPath(),e.ellipse((r[0]+l[0])/2,(r[1]+l[1])/2,Math.abs(l[0]-r[0])/2,Math.abs(l[1]-r[1])/2,0,0,Math.PI*2),i.style.fill&&Qy(e,()=>e.fill()),e.stroke();break}case"text":{let r=cp(i.style)*n.scale,[l,c]=a(i.at);e.font=`600 ${r}px system-ui, sans-serif`,e.textBaseline="top",e.setLineDash([]),e.lineWidth=Math.max(2,r/6),e.strokeStyle=Zy(i.style.color)?"rgba(0,0,0,0.75)":"rgba(255,255,255,0.85)",i.text.split(`
`).forEach((s,f)=>{e.strokeText(s,l,c+f*r*1.25),e.fillText(s,l,c+f*r*1.25)});break}case"callout":{let r=sp(i.style)*n.scale,[l,c]=a(i.at);e.setLineDash([]),e.beginPath(),e.arc(l,c,r,0,Math.PI*2),e.fill(),e.lineWidth=Math.max(1.5,r/8),e.strokeStyle="rgba(255,255,255,0.9)",e.stroke(),e.fillStyle=Zy(i.style.color)?"#000":"#fff",e.font=`700 ${r*1.1}px system-ui, sans-serif`,e.textAlign="center",e.textBaseline="middle",e.fillText(String(i.number),l,c+r*.05);break}}e.restore(),i.id===o.selectedId&&iE(e,i,n)}}function nE(e,t,n){e.globalAlpha=t.opacity,e.strokeStyle=t.color,e.fillStyle=t.color,e.lineWidth=t.width*n,e.lineCap="round",e.lineJoin="round";let o=t.width*n;e.setLineDash(t.dash==="dashed"?[o*3,o*2]:t.dash==="dotted"?[.1,o*2]:[])}function oE(e,t,n,o,a,i){let r=tE[t];r.opacity!==void 0&&(e.globalAlpha=o.opacity*r.opacity,e.globalCompositeOperation="multiply"),t==="neon"&&(e.shadowColor=o.color,e.shadowBlur=12*a);let l=n.map(s=>[...i(s),s[2]]);if(o.dash!=="solid"||l.length<2){e.lineWidth=o.width*a*r.size,e.beginPath(),l.forEach(([s,f],m)=>m?e.lineTo(s,f):e.moveTo(s,f)),l.length===1&&e.lineTo(l[0][0]+.1,l[0][1]),e.stroke();return}let c=Xy(l,{size:o.width*a*r.size,thinning:r.thinning,smoothing:.5,streamline:.4,simulatePressure:l.every(([,,s])=>s===.5),start:{taper:r.taper?o.width*a*6:0,cap:!0},end:{taper:r.taper?o.width*a*6:0,cap:!0}});if(c.length){e.beginPath(),e.moveTo(c[0][0],c[0][1]);for(let s=1;s<c.length;s++){let[f,m]=c[s-1],[u,d]=c[s];e.quadraticCurveTo(f,m,(f+u)/2,(m+d)/2)}e.closePath(),e.fill(),t==="neon"&&(e.shadowBlur=0,e.globalAlpha=.8,e.lineWidth=Math.max(1,o.width*a*.3),e.strokeStyle="rgba(255,255,255,0.8)",e.beginPath(),l.forEach(([s,f],m)=>m?e.lineTo(s,f):e.moveTo(s,f)),e.stroke())}}function Gy(e,t,n,o){let a=Math.atan2(n[1]-t[1],n[0]-t[0]);e.beginPath(),e.moveTo(n[0],n[1]),e.lineTo(n[0]-o*Math.cos(a-Math.PI/7),n[1]-o*Math.sin(a-Math.PI/7)),e.lineTo(n[0]-o*Math.cos(a+Math.PI/7),n[1]-o*Math.sin(a+Math.PI/7)),e.closePath(),e.fill()}function Qy(e,t){let n=e.globalAlpha;e.globalAlpha=n*.25,t(),e.globalAlpha=n}function aE(e,t,n,o){let[a,i]=[n(t.start),n(t.end)],r=Math.round(Math.min(a[0],i[0])),l=Math.round(Math.min(a[1],i[1])),c=Math.round(Math.abs(i[0]-a[0])),s=Math.round(Math.abs(i[1]-a[1]));if(!(c<2||s<2)){if(e.save(),o){let f=Math.max(10,Math.round(Math.min(c,s)/5)),m=new OffscreenCanvas(Math.max(1,Math.ceil(c/f)),Math.max(1,Math.ceil(s/f)));m.getContext("2d").drawImage(o,r,l,c,s,0,0,m.width,m.height),e.imageSmoothingEnabled=!1,e.drawImage(m,0,0,m.width,m.height,r,l,c,s)}else e.fillStyle="rgba(128,128,128,0.9)",e.fillRect(r,l,c,s);e.restore()}}function iE(e,t,n){let o=ul(t);e.save(),e.setLineDash([4,4]),e.lineWidth=1,e.strokeStyle="#0a84ff",e.strokeRect((o.x-n.offsetX)*n.scale-3,(o.y-n.offsetY)*n.scale-3,o.width*n.scale+6,o.height*n.scale+6),e.restore()}function Zy(e){let t=e.replace("#","");if(t.length!==6)return!1;let[n,o,a]=[0,2,4].map(i=>parseInt(t.slice(i,i+2),16));return n*.299+o*.587+a*.114>170}async function kp(e,t,n,o,a){let i=await createImageBitmap(new Blob([e],{type:t})),r=new OffscreenCanvas(i.width,i.height),l=r.getContext("2d");l.drawImage(i,0,0),i.close(),o.length&&_s(l,o,{scale:r.width/n.width,offsetX:n.x,offsetY:n.y},{pixelSource:r,anchors:a});let c=await r.convertToBlob({type:"image/png"});return rE(new Uint8Array(await c.arrayBuffer()))}function rE(e){let t="";for(let n=0;n<e.length;n+=32768)t+=String.fromCharCode(...e.subarray(n,n+32768));return btoa(t)}var nt=_(_e(),1);var Gi=_(U(),1),lE=1,cE=()=>`s${Date.now().toString(36)}${(lE++).toString(36)}`;function Py({mapper:e,shapes:t,visible:n,interactive:o,tool:a,style:i,onChange:r,liveRedactions:l,pixelSource:c,anchors:s,anchorAt:f}){let m=l&&!c,u=(0,nt.useRef)(null),[d,x]=(0,nt.useState)(null),k=(0,nt.useRef)(null),E=R=>{k.current=R,x(R)},[g,b]=(0,nt.useState)(),[p,v]=(0,nt.useState)(null),h=(0,nt.useRef)(null),T=(0,nt.useRef)(!1),{bounds:w,scale:S,scroll:M}=e,[A,H]=(0,nt.useState)(null),B=(0,nt.useRef)(t);(0,nt.useEffect)(()=>{B.current=t},[t]);let Y=(0,nt.useMemo)(()=>s&&A&&!(A.id in s)?{...s,[A.id]:A.at}:s,[s,A]);(0,nt.useLayoutEffect)(()=>{let R=u.current;if(!R)return;let j=window.devicePixelRatio||1,G=Math.round(w.width*j),de=Math.round(w.height*j);(R.width!==G||R.height!==de)&&(R.width=G,R.height=de);let oe=R.getContext("2d");if(oe.clearRect(0,0,G,de),!n)return;let De=R.closest(".viewport")?.querySelector(".viewport-canvas");_s(oe,d?[...t,d]:t,{scale:S*j,offsetX:M.x,offsetY:M.y},{pixelSource:c??De??void 0,skipRedactions:m,selectedId:o?g:void 0,anchors:Y})},[Y,m,c,t,d,n,o,g,w.width,w.height,S,M.x,M.y]),(0,nt.useEffect)(()=>{if(!g)return;let R=j=>{(j.key==="Delete"||j.key==="Backspace")&&!sE(j)&&(j.preventDefault(),j.stopPropagation(),r(t.filter(G=>G.id!==g),!0),b(void 0))};return window.addEventListener("keydown",R,!0),()=>window.removeEventListener("keydown",R,!0)},[g,t,r]);let I=R=>{let j=R.currentTarget.getBoundingClientRect();return[(R.clientX-j.left)/S+M.x,(R.clientY-j.top)/S+M.y]},Ge=(R,j)=>{let G=j?Y?.[j]:void 0;return G?[R[0]+G.x,R[1]+G.y]:R},Re=(R,j)=>(!R.anchor||!Y||!!Y[R.anchor])&&dy(R,Ge(j,R.anchor),6/S),O=R=>{let j=t.filter(G=>!Re(G,R));j.length!==t.length&&r(j,!1)},ue=()=>{p?.value.trim()&&r([...t,{id:p.id,kind:"text",at:p.at,text:p.value,style:i,anchor:p.anchor}],!0),v(null)},Te=(R,j)=>{H(j);let G=oe=>oe.id===R&&!oe.anchor?{...zs(oe,j.at.x,j.at.y),anchor:j.id}:oe,de=k.current;de?.id===R&&E(G(de)),v(oe=>oe?.id===R&&!oe.anchor?{...oe,at:[oe.at[0]+j.at.x,oe.at[1]+j.at.y],anchor:j.id}:oe),B.current.some(oe=>oe.id===R&&!oe.anchor)&&r(B.current.map(G),!1)},Ce=R=>{if(R.button!==0||!n)return;R.preventDefault();let j=I(R),G=cE(),de=a==="eraser"||a==="select"?void 0:f?.(j),oe=de instanceof Promise?void 0:de;de instanceof Promise&&de.then(Ut=>Ut&&Te(G,Ut));let De=oe?.id;oe&&H(oe);let wt=oe?[j[0]+oe.at.x,j[1]+oe.at.y]:j;if(p&&ue(),a==="text"){let Ut=R.currentTarget.getBoundingClientRect();v({id:G,at:wt,anchor:De,local:[R.clientX-Ut.left,R.clientY-Ut.top],value:""});return}if(a==="callout"){let Ut=Math.max(0,...t.map(Gn=>Gn.kind==="callout"?Gn.number:0))+1;r([...t,{id:G,kind:"callout",at:wt,number:Ut,style:i,anchor:De}],!0);return}if(R.currentTarget.setPointerCapture(R.pointerId),a==="eraser"){T.current=!0,r(t,!0),O(j);return}if(a==="select"){let Ut=[...t].reverse().find(Gn=>Re(Gn,j));b(Ut?.id),Ut&&(h.current={start:j,original:Ut},r(t,!0));return}let Ps=R.pressure||.5;iy.includes(a)?E({id:G,kind:"stroke",tool:a,points:[[...wt,Ps]],style:i,anchor:De}):lp.includes(a)&&E({id:G,kind:a,start:wt,end:wt,style:i,anchor:De})},xt=R=>{let j=I(R);if(T.current){O(j);return}if(h.current){let{start:de,original:oe}=h.current,De=zs(oe,j[0]-de[0],j[1]-de[1]);r(t.map(wt=>wt.id===oe.id?De:wt),!1);return}let G=k.current;G&&(j=Ge(j,G.anchor),G.kind==="stroke"?E({...G,points:[...G.points,[...j,R.pressure||.5]]}):G.kind!=="text"&&G.kind!=="callout"&&E({...G,end:R.shiftKey?fy(G.kind,G.start,j):j}))},Ie=()=>{T.current=!1,h.current=null;let R=k.current;if(!R)return;R.kind!=="stroke"&&R.kind!=="text"&&R.kind!=="callout"&&Math.hypot(R.end[0]-R.start[0],R.end[1]-R.start[1])*S<3||r([...t,R],!0),E(null)},Lt=a==="select"?"default":a==="text"?"text":a==="eraser"?"cell":"crosshair";return(0,Gi.jsxs)("div",{className:"drawing-layer",style:{...w,pointerEvents:n&&o?"auto":"none"},children:[m&&n&&As(d?[...t,d]:t,Y).map(R=>{if(R.kind!=="blur")return null;let[j,G]=[R.start,R.end],de={x:Math.min(j[0],G[0]),y:Math.min(j[1],G[1]),width:Math.abs(G[0]-j[0]),height:Math.abs(G[1]-j[1])},oe=R.anchor&&Y?.[R.anchor]?.clip,De=oe?ly(de,oe):de;return De?(0,Gi.jsx)("div",{className:"drawing-redaction",style:{left:(De.x-M.x)*S,top:(De.y-M.y)*S,width:De.width*S,height:De.height*S}},R.id):null}),(0,Gi.jsx)("canvas",{ref:u,style:{width:w.width,height:w.height,cursor:Lt},onPointerDown:Ce,onPointerMove:xt,onPointerUp:Ie,onContextMenu:R=>R.preventDefault()}),p&&(0,Gi.jsx)("textarea",{className:"drawing-text-input",autoFocus:!0,value:p.value,placeholder:"Type, then Enter",style:{left:p.local[0],top:p.local[1],color:i.color,fontSize:(12+i.width*2)*S},onChange:R=>v({...p,value:R.target.value}),onBlur:ue,onKeyDown:R=>{R.stopPropagation(),R.key==="Enter"&&!R.shiftKey?(R.preventDefault(),ue()):R.key==="Escape"&&v(null)}})]})}function sE(e){let t=e.target;return!!t&&(t.tagName==="INPUT"||t.tagName==="TEXTAREA"||t.isContentEditable)}var Qi=_(U(),1);function Xe({variant:e="secondary",size:t="md",icon:n,iconEnd:o,loading:a,className:i,children:r,disabled:l,type:c="button",...s}){let f=a?"loading":n;return(0,Qi.jsxs)("button",{type:c,className:ae("button",e,t==="sm"&&"small",i),disabled:l||a,"aria-busy":a||void 0,...s,children:[f&&(0,Qi.jsx)("span",{className:ae("codicon",`codicon-${f}`,a&&"codicon-modifier-spin"),"aria-hidden":"true"}),r!==void 0&&(0,Qi.jsx)("span",{className:"button-label",children:r}),o&&(0,Qi.jsx)("span",{className:`codicon codicon-${o}`,"aria-hidden":"true"})]})}var Yn=_(_e(),1),e1=_(_l(),1);function Oa(e){let t=e.trim().toLowerCase(),n=/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/.exec(t);if(n){let a=n[4]===void 0?1:n[4].endsWith("%")?parseFloat(n[4])/100:Number(n[4]);return{r:Number(n[1]),g:Number(n[2]),b:Number(n[3]),a}}let o=/^#([\da-f]{3}|[\da-f]{6})$/.exec(t);if(o){let a=o[1].length===3?[...o[1]].map(i=>i+i).join(""):o[1];return{r:parseInt(a.slice(0,2),16),g:parseInt(a.slice(2,4),16),b:parseInt(a.slice(4,6),16),a:1}}if(t==="transparent")return{r:0,g:0,b:0,a:0}}function Zi({r:e,g:t,b:n,a:o}){let a=i=>Math.round(i).toString(16).padStart(2,"0").toUpperCase();return`#${a(e)}${a(t)}${a(n)}${o<1?a(o*255):""}`}function uE(e,t){let n=e.a+t.a*(1-e.a);if(n===0)return{r:0,g:0,b:0,a:0};let o=(a,i)=>(a*e.a+i*t.a*(1-e.a))/n;return{r:o(e.r,t.r),g:o(e.g,t.g),b:o(e.b,t.b),a:n}}function $y({r:e,g:t,b:n}){let o=a=>{let i=a/255;return i<=.03928?i/12.92:((i+.055)/1.055)**2.4};return .2126*o(e)+.7152*o(t)+.0722*o(n)}function Jy(e,t){let n=$y(uE(e,t)),o=$y(t),[a,i]=n>o?[n,o]:[o,n];return(a+.05)/(i+.05)}function Iy(e,t,n){let o=t>=24||t>=18.66&&n>=700;return e>=(o?3:4.5)}function Fy({r:e,g:t,b:n}){let[o,a,i]=[e/255,t/255,n/255],r=Math.max(o,a,i),l=r-Math.min(o,a,i),c=0;return l&&(r===o?c=(a-i)/l%6:r===a?c=(i-o)/l+2:c=(o-a)/l+4),{h:(c*60+360)%360,s:r?l/r:0,v:r}}function Wy({h:e,s:t,v:n}){let o=a=>{let i=(a+e/60)%6;return(n-n*t*Math.max(0,Math.min(i,4-i,1)))*255};return{r:o(5),g:o(3),b:o(1),a:1}}function Sp(e){let t=e.trim().replace(/^#?/,"#"),n=Oa(t);return n?Zi(n).toLowerCase():void 0}var vt=_(U(),1),dE=e=>Zi(Wy(e)).toLowerCase(),ml=e=>Fy(Oa(e)??{r:0,g:0,b:0,a:1});function t1({value:e,onChange:t,label:n,presets:o=[],className:a}){let[i,r]=(0,Yn.useState)(!1),[l,c]=(0,Yn.useState)(null),[s,f]=(0,Yn.useState)(()=>ml(e)),[m,u]=(0,Yn.useState)(null),d=(0,Yn.useRef)(null),x=(0,Yn.useRef)(null),k=(0,Yn.useCallback)(h=>{r(!1),h==="escape"&&d.current?.focus()},[]);xs([d,x],i,k),hs(d,x,i);let E=h=>{f(h),u(null),t(dE(h))},g=(h,T,w,S)=>{let M=h.getBoundingClientRect(),A=Math.min(1,Math.max(0,(T-M.left)/M.width)),H=Math.min(1,Math.max(0,(w-M.top)/M.height));E(S==="area"?{...s,s:A,v:1-H}:{...s,h:A*359.9})},b=h=>({onPointerDown:T=>{T.currentTarget.setPointerCapture(T.pointerId),T.currentTarget.focus(),g(T.currentTarget,T.clientX,T.clientY,h)},onPointerMove:T=>{T.currentTarget.hasPointerCapture(T.pointerId)&&g(T.currentTarget,T.clientX,T.clientY,h)}}),p=h=>T=>{let w=T.shiftKey?.1:.01,S={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,1],ArrowDown:[0,-1]}[T.key];if(!S)return;T.preventDefault();let M=A=>Math.min(1,Math.max(0,A));E(h==="area"?{...s,s:M(s.s+S[0]*w),v:M(s.v+S[1]*w)}:{...s,h:Math.min(359.9,Math.max(0,s.h+(S[0]||S[1])*w*360))})},v=`hsl(${s.h} 100% 50%)`;return(0,vt.jsxs)(vt.Fragment,{children:[(0,vt.jsx)("button",{ref:d,type:"button",className:ae("swatch","color-picker-trigger",i&&"active",a),"aria-label":n,title:n,"aria-haspopup":"dialog","aria-expanded":i,onClick:()=>{if(i)return k();f(ml(e)),u(null),c(ws(d.current)),r(!0)}}),i&&l&&(0,e1.createPortal)((0,vt.jsxs)("div",{ref:x,className:"color-picker","data-ink-popup":"",role:"dialog","aria-label":n,children:[(0,vt.jsx)("div",{className:"color-area",style:{background:v},role:"slider",tabIndex:0,"aria-label":"Saturation and brightness","aria-valuetext":`Saturation ${Math.round(s.s*100)}%, brightness ${Math.round(s.v*100)}%`,onKeyDown:p("area"),...b("area"),children:(0,vt.jsx)("span",{className:"color-handle",style:{left:`${s.s*100}%`,top:`${(1-s.v)*100}%`,background:e}})}),(0,vt.jsx)("div",{className:"color-hue",role:"slider",tabIndex:0,"aria-label":"Hue","aria-valuemin":0,"aria-valuemax":360,"aria-valuenow":Math.round(s.h),onKeyDown:p("hue"),...b("hue"),children:(0,vt.jsx)("span",{className:"color-handle",style:{left:`${s.h/360*100}%`,background:v}})}),(0,vt.jsxs)("div",{className:"color-row",children:[(0,vt.jsx)("span",{className:"color-preview",style:{background:e},"aria-hidden":"true"}),(0,vt.jsx)("input",{className:"color-hex","aria-label":"Hex color",spellCheck:!1,maxLength:7,value:m??e,onChange:h=>{u(h.target.value);let T=Sp(h.target.value);T&&h.target.value.replace("#","").length===6&&(f(ml(T)),t(T))},onBlur:()=>u(null),onKeyDown:h=>{if(h.key!=="Enter")return;let T=Sp(h.currentTarget.value);T&&(f(ml(T)),t(T),k("escape"))}})]}),o.length>0&&(0,vt.jsx)("div",{className:"color-presets",role:"group","aria-label":"Presets",children:o.map(h=>(0,vt.jsx)("button",{type:"button",className:ae("swatch","small",h===e&&"active"),style:{background:h},"aria-label":h,title:h,onClick:()=>{f(ml(h)),t(h)}},h))})]}),l)]})}var Ht=_(_e(),1),n1=_(_l(),1);var ft=_(U(),1);function Vn({value:e,options:t,onChange:n,label:o,title:a,placeholder:i="Select\u2026",icon:r,renderValue:l,size:c="md",appearance:s="field",disabled:f,className:m,align:u="start"}){let[d,x]=(0,Ht.useState)(!1),[k,E]=(0,Ht.useState)(-1),[g,b]=(0,Ht.useState)(null),p=(0,Ht.useRef)(null),v=(0,Ht.useRef)(null),h=(0,Ht.useRef)({text:"",at:0}),T=(0,Ht.useId)(),w=t.findIndex(O=>O.value===e),S=t[w],M=(0,Ht.useCallback)(O=>{x(!1),(O==="escape"||O==="chosen")&&p.current?.focus()},[]);xs([p,v],d,M),hs(p,v,d,{align:u,matchWidth:!0});let A=O=>O>=0&&!t[O]?.disabled,H=(O,ue)=>{for(let Te=1;Te<=t.length;Te++){let Ce=(O+ue*Te+t.length*2)%t.length;if(A(Ce))return Ce}return O},B=(O=w)=>{E(A(O)?O:H(-1,1)),b(ws(p.current)),x(!0)},Y=O=>{let ue=t[O];!ue||ue.disabled||(M("chosen"),ue.value!==e&&n(ue.value))};(0,Ht.useLayoutEffect)(()=>{d&&(v.current?.querySelector(`[data-index="${k}"]`)?.scrollIntoView({block:"nearest"}),v.current?.focus({preventScroll:!0}))},[d,k]);let I=O=>{let ue=Date.now(),Te=(ue-h.current.at<700?h.current.text:"")+O.toLowerCase();h.current={text:Te,at:ue};let Ce=d?k:w,Ie=[...t.keys()].map(Lt=>(Ce+(Te.length>1?0:1)+Lt)%t.length).find(Lt=>A(Lt)&&t[Lt].label.toLowerCase().startsWith(Te));Ie!==void 0&&(d?E(Ie):t[Ie].value!==e&&n(t[Ie].value))},Ge=O=>{["ArrowDown","ArrowUp","Enter"," "].includes(O.key)?(O.preventDefault(),B()):O.key.length===1&&!O.ctrlKey&&!O.metaKey&&!O.altKey&&I(O.key)},Re=O=>{let Te={ArrowDown:()=>E(Ce=>H(Ce,1)),ArrowUp:()=>E(Ce=>H(Ce,-1)),Home:()=>E(H(-1,1)),End:()=>E(H(t.length,-1)),PageDown:()=>E(Ce=>Math.min(H(Ce,1)+7,H(t.length,-1))),PageUp:()=>E(Ce=>Math.max(H(Ce,-1)-7,H(-1,1))),Enter:()=>Y(k)," ":()=>h.current.text&&Date.now()-h.current.at<700?I(" "):Y(k),Tab:()=>M()}[O.key];Te?(O.key!=="Tab"&&O.preventDefault(),Te()):O.key.length===1&&!O.ctrlKey&&!O.metaKey&&!O.altKey&&I(O.key)};return(0,ft.jsxs)(ft.Fragment,{children:[(0,ft.jsxs)("button",{ref:p,type:"button",className:ae("select",`size-${c}`,s==="quiet"&&"quiet",d&&"open",m),role:"combobox","aria-haspopup":"listbox","aria-expanded":d,"aria-controls":d?`${T}-list`:void 0,"aria-label":o,title:a??o,disabled:f,onClick:()=>d?M():B(),onKeyDown:Ge,children:[r&&(0,ft.jsx)("span",{className:`codicon codicon-${r}`,"aria-hidden":"true"}),!r&&S?.icon&&(0,ft.jsx)("span",{className:`codicon codicon-${S.icon}`,"aria-hidden":"true"}),(0,ft.jsx)("span",{className:ae("select-value",!S&&"placeholder"),children:S?l?l(S):S.label:i}),(0,ft.jsx)("span",{className:"codicon codicon-chevron-down select-chevron","aria-hidden":"true"})]}),d&&g&&(0,n1.createPortal)((0,ft.jsx)("div",{ref:v,id:`${T}-list`,className:"select-list","data-ink-popup":"",role:"listbox","aria-label":o,tabIndex:-1,"aria-activedescendant":k>=0?`${T}-${k}`:void 0,onKeyDown:Re,children:t.map((O,ue)=>[O.group&&O.group!==t[ue-1]?.group?(0,ft.jsx)("div",{className:"select-group",role:"presentation",children:O.group},`g-${O.group}`):null,(0,ft.jsxs)("div",{id:`${T}-${ue}`,"data-index":ue,role:"option","aria-selected":ue===w,"aria-disabled":O.disabled||void 0,className:ae("select-option",ue===k&&"active",ue===w&&"selected",O.disabled&&"disabled"),style:O.indent?{paddingLeft:4+O.indent*14}:void 0,onPointerMove:()=>!O.disabled&&E(ue),onClick:()=>Y(ue),children:[(0,ft.jsx)("span",{className:`codicon codicon-${ue===w?"check":"blank"} select-check`,"aria-hidden":"true"}),O.icon&&(0,ft.jsx)("span",{className:`codicon codicon-${O.icon}`,"aria-hidden":"true"}),(0,ft.jsx)("span",{className:"select-option-label",children:O.label}),O.detail&&(0,ft.jsx)("span",{className:"select-option-detail",children:O.detail})]},O.value)])}),g)]})}var o1=_(_e(),1);var Io=_(U(),1);function Ep({value:e,min:t,max:n,step:o=1,onChange:a,label:i,format:r=String,icon:l,showValue:c,className:s,disabled:f}){let m=(0,o1.useRef)(null),u=g=>Math.min(n,Math.max(t,Math.round(g/o)*o)),d=g=>{let b=u(g);b!==e&&a(b)},x=g=>{let b=m.current?.getBoundingClientRect();b?.width&&d(t+(g-b.left)/b.width*(n-t))},k=n>t?(e-t)/(n-t):0,E=g=>{let b=Math.max(o,(n-t)/10),p={ArrowRight:e+o,ArrowUp:e+o,ArrowLeft:e-o,ArrowDown:e-o,PageUp:e+b,PageDown:e-b,Home:t,End:n};g.key in p&&(g.preventDefault(),d(p[g.key]))};return(0,Io.jsxs)("div",{className:ae("slider",f&&"disabled",s),title:`${i}: ${r(e)}`,children:[l&&(0,Io.jsx)("span",{className:`codicon codicon-${l}`,"aria-hidden":"true"}),(0,Io.jsxs)("div",{ref:m,className:"slider-track",role:"slider",tabIndex:f?-1:0,"aria-label":i,"aria-valuemin":t,"aria-valuemax":n,"aria-valuenow":e,"aria-valuetext":r(e),"aria-disabled":f||void 0,onKeyDown:f?void 0:E,onPointerDown:g=>{f||g.button!==0||(g.currentTarget.setPointerCapture(g.pointerId),g.currentTarget.focus(),x(g.clientX))},onPointerMove:g=>{g.currentTarget.hasPointerCapture(g.pointerId)&&x(g.clientX)},children:[(0,Io.jsx)("span",{className:"slider-fill",style:{width:`${k*100}%`}}),(0,Io.jsx)("span",{className:"slider-thumb",style:{left:`${k*100}%`}})]}),c&&(0,Io.jsx)("span",{className:"slider-value",children:r(e)})]})}var Tp=_(U(),1),fE={select:"M3 2l9 5-4 1-2 4z",pen:"M11 2l3 3-8 8H3v-3zM9.5 3.5l3 3",pencil:"M11.5 2.5l2 2L6 12l-3 1 1-3zM10 4l2 2",marker:"M10 2l4 4-6 6H4v-4zM4 12l-2 2h4",brush:"M13.5 2.5c-2 1-5 4-6.5 6l1 1c2-1.5 5-4.5 6-6.5zM6.5 9.5c-2 0-3 1.5-3 3 0 .8-.5 1.2-1.5 1.5 3 .5 5.5-1 5.5-3.5",highlighter:"M9 2l5 5-5 5-5-5zM4 7l-2 5 3-1M2 14h12",neon:"M2 12c2-6 4 2 6-4s4 2 6-4M8 1v2M3 3l1.5 1.5M13 3l-1.5 1.5",line:"M3 13L13 3",arrow:"M3 13L13 3M7 3h6v6",doubleArrow:"M3 13L13 3M7 3h6v6M9 13H3V7",rect:"M2.5 3.5h11v9h-11z",ellipse:"M8 3c3.3 0 6 2.2 6 5s-2.7 5-6 5-6-2.2-6-5 2.7-5 6-5z",blur:"M2 2h4v4H2zM6 6h4v4H6zM10 2h4v4h-4zM2 10h4v4H2zM10 10h4v4h-4z",text:"M3 3h10M8 3v10M6 13h4",callout:"M8 2a5 5 0 110 10 5 5 0 010-10zM7 5.5l1.5-1v5M7 9.5h3",eraser:"M9 2l5 5-6 6H4l-2-2zM6 5l5 5M4 13h10"};function a1({tool:e}){return(0,Tp.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.3",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:(0,Tp.jsx)("path",{d:fE[e]})})}var ye=_(U(),1),i1=[[{tool:"select",label:"Select and move"}],[{tool:"pen",label:"Pen"},{tool:"pencil",label:"Pencil"},{tool:"marker",label:"Marker"},{tool:"brush",label:"Brush"},{tool:"highlighter",label:"Highlighter"},{tool:"neon",label:"Neon"}],[{tool:"line",label:"Line"},{tool:"arrow",label:"Arrow"},{tool:"doubleArrow",label:"Double arrow"},{tool:"rect",label:"Rectangle"},{tool:"ellipse",label:"Ellipse"}],[{tool:"text",label:"Text"},{tool:"callout",label:"Numbered callout"},{tool:"blur",label:"Redact (pixelate)"},{tool:"eraser",label:"Eraser"}]],pE=[{value:"solid",label:"Solid"},{value:"dashed",label:"Dashed"},{value:"dotted",label:"Dotted"}],r1=i1.flat().map(e=>e.tool);function l1(e){let{tool:t,style:n}=e,o=(i,r,l)=>{let c=kn.find(f=>f.id===r),s=e.keyOf?e.keyOf(r):c?.keys[0]?It(c.keys[0],!1):l;return s?`${i} (${s})`:i},a=[...Vi,...e.recentColors.filter(i=>!Vi.includes(i))];return(0,ye.jsxs)("div",{className:"draw-toolbar",role:"toolbar","aria-label":"Drawing tools",children:[i1.map((i,r)=>(0,ye.jsx)("div",{className:"draw-group",children:i.map(({tool:l,label:c})=>(0,ye.jsx)("button",{type:"button",className:`icon-button${t===l?" active":""}`,title:o(c,`draw.${l}`),"aria-label":c,"aria-pressed":t===l,onClick:()=>e.onTool(l),children:(0,ye.jsx)(a1,{tool:l})},l))},r)),(0,ye.jsxs)("div",{className:"draw-group colors",role:"radiogroup","aria-label":"Colour",children:[a.slice(0,13).map(i=>(0,ye.jsx)("button",{type:"button",role:"radio","aria-checked":n.color===i,"aria-label":i,title:i,className:`swatch${n.color===i?" active":""}`,style:{background:i},onClick:()=>e.onStyle({color:i})},i)),(0,ye.jsx)(t1,{value:n.color,label:"Custom colour",presets:Vi,onChange:i=>e.onStyle({color:i})})]}),(0,ye.jsxs)("div",{className:"draw-group",children:[(0,ye.jsx)(Ep,{icon:"circle-small-filled",label:"Width",min:1,max:24,value:n.width,format:i=>`${i}px`,onChange:i=>e.onStyle({width:i})}),(0,ye.jsx)(Ep,{icon:"color-mode",label:"Opacity",min:10,max:100,step:5,value:Math.round(n.opacity*100),format:i=>`${i}%`,onChange:i=>e.onStyle({opacity:i/100})}),(0,ye.jsx)(Vn,{size:"sm",appearance:"quiet",label:"Line style",value:n.dash,options:pE,onChange:i=>e.onStyle({dash:i})}),(0,ye.jsx)("button",{type:"button",className:`icon-button${n.fill?" active":""}`,title:o("Fill shapes","draw.fill"),"aria-label":"Fill shapes","aria-pressed":n.fill,onClick:()=>e.onStyle({fill:!n.fill}),children:(0,ye.jsx)("span",{className:"codicon codicon-circle-filled","aria-hidden":"true"})})]}),(0,ye.jsxs)("div",{className:"draw-group",children:[(0,ye.jsx)("button",{type:"button",className:"icon-button",title:o("Undo","draw.undo","Ctrl+Z"),"aria-label":"Undo",disabled:!e.canUndo,onClick:e.onUndo,children:(0,ye.jsx)("span",{className:"codicon codicon-discard","aria-hidden":"true"})}),(0,ye.jsx)("button",{type:"button",className:"icon-button",title:o("Redo","draw.redo","Ctrl+Y"),"aria-label":"Redo",disabled:!e.canRedo,onClick:e.onRedo,children:(0,ye.jsx)("span",{className:"codicon codicon-redo","aria-hidden":"true"})}),(0,ye.jsx)("button",{type:"button",className:"icon-button",title:o("Clear all drawings","draw.clear"),"aria-label":"Clear all drawings",disabled:!e.hasShapes,onClick:e.onClear,children:(0,ye.jsx)("span",{className:"codicon codicon-clear-all","aria-hidden":"true"})}),(0,ye.jsx)("button",{type:"button",className:`icon-button${e.visible?"":" active"}`,title:o(e.visible?"Hide drawings":"Show drawings","draw.visible"),"aria-label":e.visible?"Hide drawings":"Show drawings",onClick:e.onToggleVisible,children:(0,ye.jsx)("span",{className:`codicon codicon-${e.visible?"eye":"eye-closed"}`,"aria-hidden":"true"})})]}),(0,ye.jsx)(Xe,{variant:"primary",size:"sm",icon:"device-camera",iconEnd:"chevron-down",className:"draw-capture",disabled:!e.hasShapes,title:o("Screenshot menu","draw.captureMenu"),onClick:i=>{let r=i.currentTarget.getBoundingClientRect();e.onCapture(r.left,r.bottom+2)},children:"Screenshot"}),(0,ye.jsx)("button",{type:"button",className:"icon-button draw-close",title:o("Stop drawing","draw.exit","Esc"),"aria-label":"Stop drawing",onClick:e.onClose,children:(0,ye.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]})}var mE={area:"draw.capture",groups:"draw.captureGroups",clean:"draw.captureClean",viewport:"draw.captureViewport",fullPage:"draw.captureFullPage"};function c1(e,t){let n=(o,a,i)=>({label:a,icon:i,shortcut:t?.(mE[o]),onSelect:()=>e(o)});return[n("area","Drawing area","device-camera"),n("groups","Each drawing separately","layers"),n("clean","Drawing area without drawings","eye-closed"),{separator:!0},n("viewport","Visible area with drawings","screen-normal"),n("fullPage","Full page with drawings","file-media")]}var Cp=_(U(),1);function s1({label:e,dragging:t,className:n,...o}){return(0,Cp.jsx)("button",{type:"button",className:["drag-handle",t&&"dragging",n].filter(Boolean).join(" "),title:e,"aria-label":e,...o,children:(0,Cp.jsx)("span",{className:"codicon codicon-gripper","aria-hidden":"true"})})}var Np=_(U(),1);function Ee({icon:e,label:t,onClick:n,onContextMenu:o,disabled:a,active:i,spin:r,className:l}){return(0,Np.jsx)("button",{type:"button",className:["icon-button",i&&"active",l].filter(Boolean).join(" "),title:t,"aria-label":t,"aria-pressed":i,disabled:a,onClick:n,onContextMenu:o,children:(0,Np.jsx)("span",{className:`codicon codicon-${e}${r?" codicon-modifier-spin":""}`,"aria-hidden":"true"})})}var dn=_(_e(),1);var Ft=_(U(),1);function Hs({menu:e,onClose:t}){let n=(0,dn.useRef)(null),[o]=(0,dn.useState)(vs);return(0,dn.useEffect)(()=>{let a=ys(()=>[n.current],o,()=>t()),i=r=>{r.key==="Escape"&&(r.preventDefault(),r.stopPropagation(),t())};return window.addEventListener("keydown",i,!0),window.addEventListener("blur",t),window.addEventListener("resize",t),()=>{a(),window.removeEventListener("keydown",i,!0),window.removeEventListener("blur",t),window.removeEventListener("resize",t)}},[t,o]),(0,Ft.jsx)("div",{ref:n,className:"menu-root",onContextMenu:a=>a.preventDefault(),children:(0,Ft.jsx)(u1,{items:e.items,x:e.x,y:e.y,onClose:t,focusFirst:!0})})}function u1({items:e,x:t,y:n,onClose:o,focusFirst:a,parent:i,onBack:r}){let l=(0,dn.useRef)(null),[c,s]=(0,dn.useState)(null),f=(0,dn.useRef)(void 0);(0,dn.useLayoutEffect)(()=>{let E=l.current;if(!E)return;let g=E.getBoundingClientRect(),b=t;i&&t+g.width>innerWidth-4&&(b=i.left-g.width+2),E.style.left=`${Math.max(4,Math.min(b,innerWidth-g.width-4))}px`,E.style.top=`${Math.max(4,Math.min(n,innerHeight-g.height-4))}px`,a&&E.querySelector(":scope > button:not(:disabled)")?.focus({preventScroll:!0})},[t,n,i,a]),(0,dn.useEffect)(()=>()=>clearTimeout(f.current),[]);let m=()=>[...l.current?.querySelectorAll(":scope > button:not(:disabled)")??[]],u=(E,g,b)=>{clearTimeout(f.current),s({index:E,rect:g.getBoundingClientRect()}),b&&setTimeout(()=>l.current?.querySelector(":scope > .menu button:not(:disabled)")?.focus({preventScroll:!0}))},d=E=>{if(E.target instanceof HTMLElement&&E.target.closest(".menu")!==l.current)return;let g=m(),b=g.indexOf(document.activeElement);if(E.key==="ArrowDown"||E.key==="ArrowUp")E.preventDefault(),g[(b+(E.key==="ArrowDown"?1:-1)+g.length)%g.length]?.focus();else if(E.key==="ArrowLeft"&&r)E.preventDefault(),E.stopPropagation(),r();else if(E.key==="ArrowRight"){let p=g[b],v=p&&e[Number(p.dataset.index)];v&&"submenu"in v&&v.submenu&&(E.preventDefault(),u(Number(p.dataset.index),p,!0))}},x=c?e[c.index]:void 0,k=x&&"submenu"in x?x.submenu?.():void 0;return(0,Ft.jsxs)("div",{ref:l,className:"menu",role:"menu",style:{left:t,top:n},onKeyDown:d,children:[e.map((E,g)=>"separator"in E?(0,Ft.jsx)("div",{className:"menu-separator",role:"separator"},g):(0,Ft.jsxs)("button",{type:"button",role:"menuitem","data-index":g,"aria-haspopup":E.submenu?"menu":void 0,"aria-expanded":E.submenu?c?.index===g:void 0,className:`menu-item${c?.index===g?" expanded":""}`,disabled:E.disabled,onPointerEnter:b=>{clearTimeout(f.current);let p=b.currentTarget;E.disabled||p.focus({preventScroll:!0}),f.current=setTimeout(()=>E.submenu?u(g,p,!1):s(null),E.submenu?120:250)},onClick:b=>{if(E.submenu){u(g,b.currentTarget,b.detail===0);return}o(),E.onSelect()},children:[E.image?(0,Ft.jsx)("img",{className:"menu-image",src:E.image,alt:"",referrerPolicy:"no-referrer"}):(0,Ft.jsx)("span",{className:`codicon codicon-${E.icon??"blank"}`,"aria-hidden":"true"}),(0,Ft.jsx)("span",{className:"menu-label",children:E.label}),E.shortcut&&(0,Ft.jsx)("span",{className:"menu-shortcut",children:E.shortcut}),E.submenu&&(0,Ft.jsx)("span",{className:"codicon codicon-chevron-right menu-arrow","aria-hidden":"true"})]},g)),c&&k&&(0,Ft.jsx)(u1,{items:k.length?k:[{label:"(empty)",disabled:!0,onSelect:()=>{}}],x:c.rect.right-2,y:c.rect.top-5,parent:c.rect,onClose:o,onBack:()=>{s(null),l.current?.querySelector(`:scope > button[data-index="${c.index}"]`)?.focus()}},c.index)]})}var po=_(U(),1),gE=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),bE=[{action:"copy",label:"Capture",icon:"inspect"},{action:"screenshot",label:"Screenshot",icon:"device-camera"}];function d1({count:e,map:t,onAction:n,className:o,style:a}){let i=t["inspect.copy"]?.[0];return(0,po.jsxs)("div",{className:ae("selection-bar",o),style:a,role:"toolbar","aria-label":"Selected elements",onPointerDown:r=>r.stopPropagation(),children:[(0,po.jsxs)("span",{className:"selection-bar-count",children:[(0,po.jsx)("span",{className:"selection-bar-badge",children:e}),"selected"]}),bE.map(({action:r,label:l,icon:c})=>(0,po.jsxs)(Xe,{size:"sm",variant:r==="copy"?"primary":"ghost",icon:c,onClick:()=>n(r),children:[l,r==="copy"&&i&&(0,po.jsx)("span",{className:"keycaps size-sm",children:Yi(i,gE).map(s=>(0,po.jsx)("kbd",{className:"keycap",children:s},s))})]},r)),(0,po.jsx)(Ee,{icon:"close",label:"Clear the selection",className:"small selection-bar-clear",onClick:()=>n("clear")})]})}var f1=["claude","codex","opencode","agy"];var p1=e=>`agentmux:new:${e}`,m1={claude:"Claude Code",codex:"Codex",opencode:"opencode",agy:"Antigravity"};var gl=e=>typeof e=="number"&&Number.isFinite(e),yt=e=>typeof e=="boolean",$=e=>t=>typeof t=="string"&&t.length<=e,Kn=e=>t=>typeof t=="string"&&e.test(t),Q=e=>t=>t===void 0||e(t),Ra=(...e)=>t=>typeof t=="string"&&e.includes(t),hE=e=>typeof e=="object"&&e!==null&&!Array.isArray(e),Da=e=>t=>hE(t)&&Object.entries(e).every(([n,o])=>o(t[n])),fn=(e,t=1e5)=>n=>Array.isArray(n)&&n.length<=t&&n.every(e);var v3=1024*1024,vE=64*1024*1024,yE=["element","screenshot","recording","errors","network","page","report","css","measure","color","text"],zp=/^\d{8}-\d{6}-[0-9a-f]{6}$/,Mp=/^[\w-]{1,40}\.[a-z0-9]{1,5}$/;function g1(e){return e.vscode||e.agentmux}var _a=Kn(/^[\w.-]{1,64}$/),Bs=$(vE),xE=$(4096),y3={auth:{token:$(128),role:Ra("browser","vscode"),origin:Q($(256))}},pt=Kn(/^[\w-]{1,64}$/),pn=$(4096),b1=Ra(...yE),Ap=Kn(/^[A-Za-z0-9+/]*={0,2}$/),wE=Da({kind:b1,title:$(300),detail:Q($(1e3)),text:Q($(5e6)),group:Q(_a),groupIndex:Q(gl),image:Q(Ap),thumb:Q(e=>typeof e=="string"&&e.length<=4e5&&Ap(e))}),h1=Da({id:$(200),kind:Ra("tmux","terminal","chat"),label:$(100),detail:$(300)}),Pi=fn(Kn(zp),60),x3={link:{data:Bs},ping:{},"projects.get":{req:pt,url:Q($(4096))},"capture.save":{req:pt,project:pn,url:Q($(4096)),browser:Q($(100)),captures:fn(wE,60),send:Q($(200))},"item.send":{req:pt,project:pn,ids:Pi,target:Q($(200)),open:Q(yt)},"items.move":{req:pt,project:pn,ids:Pi,to:pn},"items.get":{req:pt,project:pn},"item.thumb":{req:pt,project:pn,id:Kn(zp)},"item.remove":{req:pt,project:pn,ids:Pi},"item.restore":{req:pt,project:pn,ids:Pi},"project.pin":{req:pt,project:pn,pinned:yt}},kE=Da({path:pn,name:$(300),vscode:yt,agentmux:yt,saved:yt,pinned:yt,targets:Q(fn(h1,50)),defaultTarget:Q($(200)),harnesses:Q(fn(Ra(...f1),10)),inbox:Q(yt)}),SE=Da({v:e=>e===1,id:Kn(zp),kind:b1,title:$(300),detail:Q($(1e3)),url:Q($(4096)),time:gl,group:Q(_a),groupIndex:Q(gl),key:Q($(200)),source:Ra("browser","vscode"),browser:Q($(100)),preview:Q($(1e3)),files:Da({file:Q(Kn(Mp)),text:Q(Kn(Mp)),thumb:Q(Kn(Mp))}),sentTo:fn($(200),50)}),w3={link:{data:Bs},status:{vscode:yt,peer:Q($(200)),features:Q(fn($(40),50))},relink:{},pong:{},projects:{req:pt,projects:fn(kE,500),suggested:Q(pn)},"capture.saved":{req:pt,ok:yt,ids:Q(Pi),error:Q($(1e3)),sentTo:Q($(200))},"item.sent":{req:pt,ok:yt,sentTo:Q($(200)),error:Q($(1e3))},items:{req:pt,ok:yt,items:fn(SE,500),error:Q($(1e3))},thumb:{req:pt,data:Q(Ap),mimeType:Q(Ra("image/jpeg","image/png"))},done:{req:pt,ok:yt,error:Q($(1e3))}},k3={window:{id:_a,name:$(200),folders:fn(xE,50),focusedAt:gl,targets:Q(fn(h1,50))},link:{browser:_a,data:Bs},shutdown:{},ping:{},"run.sent":{req:pt,ok:yt,sentTo:Q($(200)),error:Q($(1e3))}},EE=Da({id:_a,name:$(100),origin:$(256)}),S3={welcome:{build:$(100),leader:yt},leader:{leader:yt},browsers:{browsers:fn(EE,50)},link:{browser:_a,data:Bs},gone:{browser:_a},pong:{},"run.send":{req:pt,project:pn,ids:Pi,target:$(200)}};function v1(e){return e.inbox?"captures without a project":[e.vscode&&"VS Code",e.agentmux&&"agentmux",!g1(e)&&e.saved&&"saved",e.pinned&&"pinned"].filter(Boolean).join(" \xB7 ")}var Xn=_(_e(),1);function y1(e,t){let n=e.find(o=>o.id===t);return n?[n,...e.filter(o=>o!==n)]:[...e]}function x1(e,t){if(/^[1-9]$/.test(e))return t[Number(e)-1]}function w1(e){return e.kind==="chat"?"comment-discussion":e.kind==="tmux"?"terminal-tmux":"terminal"}var Op=_(U(),1),TE=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function Ha({binding:e,size:t="md"}){let n=Yi(e,TE);return(0,Op.jsx)("span",{className:`keycaps size-${t}`,"aria-label":n.join("+"),children:n.map((o,a)=>(0,Op.jsx)("kbd",{className:"keycap",children:o},a))})}var P=_(U(),1),k1='button:not([disabled]), [href], input, [tabindex]:not([tabindex="-1"])';function S1(e){let{targets:t,defaultTarget:n,harnesses:o=[],onSend:a,onClose:i,map:r}=e,l=(0,Xn.useRef)(null),c=(0,Xn.useRef)(null),s=(0,Xn.useRef)(null),[f,m]=(0,Xn.useState)(null),u=y1(t,n),[d,x]=(0,Xn.useState)(),k=u.some(h=>h.id===d)?d:u[0]?.id,E=e.status?.tone==="busy",g=h=>r[h]?.[0];(0,Xn.useEffect)(()=>{let h=l.current?.getRootNode()?.activeElement;return l.current?.focus(),()=>h?.focus?.()},[]),(0,Xn.useEffect)(()=>{let h=l.current,T=h?.parentElement;if(!h||!T)return;let w=h.getRootNode(),S=w instanceof ShadowRoot?w.host:void 0,M=h.ownerDocument,A=M.documentElement,H={htmlOverflow:A.style.overflow,bodyOverflow:M.body.style.overflow,paddingRight:A.style.paddingRight},B=M.defaultView?M.defaultView.innerWidth-A.clientWidth:0;A.style.overflow="hidden",M.body.style.overflow="hidden",B>0&&(A.style.paddingRight=`${B}px`);let Y=Ge=>{(!h.contains(Ge.target)||h.scrollHeight<=h.clientHeight)&&Ge.preventDefault()};T.addEventListener("wheel",Y,{passive:!1}),T.addEventListener("touchmove",Y,{passive:!1});let I=Ge=>{let Re=Ge.target;!Re||Re===S||h.contains(Re)||Re.closest?.("[data-ink-popup]")||(h.querySelector(k1)??h).focus()};return M.addEventListener("focusin",I,!0),()=>{A.style.overflow=H.htmlOverflow,M.body.style.overflow=H.bodyOverflow,A.style.paddingRight=H.paddingRight,T.removeEventListener("wheel",Y),T.removeEventListener("touchmove",Y),M.removeEventListener("focusin",I,!0)}},[]);let b=h=>{if(!u.length)return;let T=u.findIndex(S=>S.id===k),w=u[(T+h+u.length)%u.length];x(w.id),l.current?.querySelector(`[data-target="${CSS.escape(w.id)}"]`)?.focus()},p=()=>{let h=c.current?.getBoundingClientRect();h&&m({x:h.left,y:h.bottom+4,items:o.map(T=>({label:m1[T],icon:"terminal-tmux",onSelect:()=>a(p1(T),{open:!1})}))})},v=h=>{if(h.defaultPrevented)return;if(h.key==="Tab"){let I=[...l.current?.querySelectorAll(k1)??[]];if(!I.length)return;let Ge=l.current.getRootNode(),Re=I.indexOf(Ge.activeElement),O=h.shiftKey?Re<=0?I.length-1:Re-1:(Re+1)%I.length;I[O].focus(),h.preventDefault();return}if(E){if(h.key!=="Escape")return;h.preventDefault(),h.stopPropagation(),i();return}let T=h.nativeEvent,w=h.target.closest('[role="menu"], [role="listbox"], input');if((h.key==="ArrowDown"||h.key==="ArrowUp")&&!w&&u.length){h.preventDefault(),h.stopPropagation(),b(h.key==="ArrowDown"?1:-1);return}let S=/^Digit([1-9])$/.exec(T.code)?.[1],M=S&&!h.ctrlKey&&!h.altKey&&!h.metaKey?x1(S,u):void 0;if(M){h.preventDefault(),h.stopPropagation(),a(M.id,{open:h.shiftKey&&M.kind==="tmux"});return}if(h.target.closest("button")&&h.key==="Enter")return;let H=sl(r,["send"],uo(T))?.id,B={"send.default":k?()=>a(k,{open:!1}):void 0,"send.newThread":o.length?p:void 0,"send.project":e.onProject?()=>s.current?.querySelector("button")?.click():void 0,"send.copy":e.onCopy,"send.download":e.onDownload,"send.close":i},Y=H?B[H]:h.key==="Escape"?i:void 0;Y&&(h.preventDefault(),h.stopPropagation(),Y())};return(0,P.jsx)("div",{className:"ink-modal-backdrop",onMouseDown:h=>{h.target===h.currentTarget&&!E&&i()},children:(0,P.jsxs)("div",{ref:l,className:"ink-modal",role:"dialog","aria-modal":"true","aria-label":e.title,tabIndex:-1,onKeyDown:v,children:[(0,P.jsxs)("div",{className:"ink-modal-head",children:[(0,P.jsxs)("div",{className:"ink-modal-heading",children:[(0,P.jsxs)("div",{className:"ink-modal-title",children:[(0,P.jsx)("span",{className:"codicon codicon-pass-filled","aria-hidden":"true"}),e.title]}),e.project&&(0,P.jsxs)("div",{className:"ink-modal-project",ref:s,children:[(0,P.jsx)("span",{className:"ink-muted",children:"Saved in"}),e.projects&&e.projects.length>1&&e.onProject?(0,P.jsx)(Vn,{size:"sm",appearance:"quiet",label:"Project",icon:"folder",value:e.project.path,onChange:e.onProject,options:e.projects.map(h=>({value:h.path,label:h.name,detail:h.detail,icon:"folder"}))}):(0,P.jsx)("span",{className:"ink-modal-project-name",children:e.project.name})]}),e.detail&&(0,P.jsx)("div",{className:"ink-modal-detail",children:e.detail})]}),(0,P.jsx)(Ee,{icon:"close",label:"Close (it stays saved)",onClick:i})]}),!!e.images?.length&&(0,P.jsx)("div",{className:"ink-modal-thumbs","aria-hidden":"true",children:e.images.slice(0,4).map((h,T,w)=>(0,P.jsxs)("span",{className:"ink-modal-thumb",children:[(0,P.jsx)("img",{src:h,alt:""}),T===w.length-1&&e.images.length>w.length&&(0,P.jsxs)("span",{className:"ink-modal-more",children:["+",e.images.length-w.length]})]},T))}),(0,P.jsxs)("div",{className:"ink-modal-label",children:["Send to",u.length>0&&(0,P.jsx)("span",{className:"ink-modal-count",children:u.length})]}),u.length?(0,P.jsx)("ul",{className:"ink-modal-targets",role:"list",children:u.map((h,T)=>(0,P.jsxs)("li",{className:ae("ink-modal-target",h.id===k&&"default"),children:[(0,P.jsxs)("button",{type:"button",className:"ink-modal-send","data-target":h.id,"aria-current":h.id===k?"true":void 0,disabled:E,onClick:()=>a(h.id,{open:!1}),"aria-keyshortcuts":T<9?String(T+1):void 0,children:[(0,P.jsx)("span",{className:"ink-modal-icon","aria-hidden":"true",children:(0,P.jsx)("span",{className:`codicon codicon-${w1(h)}`})}),(0,P.jsxs)("span",{className:"ink-modal-text",children:[(0,P.jsx)("span",{className:"ink-modal-agent",children:h.label}),(0,P.jsx)("span",{className:"ink-modal-where",children:h.detail})]}),(0,P.jsxs)("span",{className:"ink-modal-keys",children:[T<9&&(0,P.jsx)("span",{className:"ink-modal-number",children:T+1}),h.id===k&&g("send.default")&&(0,P.jsx)(Ha,{binding:g("send.default"),size:"sm"})]})]}),h.kind==="tmux"&&(0,P.jsx)(Ee,{icon:"link-external",label:`Send and open ${h.detail} in agentmux`,disabled:E,onClick:()=>a(h.id,{open:!0})})]},h.id))}):(0,P.jsx)("div",{className:"ink-modal-empty",children:e.emptyText??"No agent is running for this project."}),o.length>0&&(0,P.jsxs)(Xe,{ref:c,size:"sm",variant:"ghost",icon:"add",iconEnd:"chevron-down",className:"ink-modal-thread",disabled:E,onClick:p,children:["New agentmux thread",g("send.newThread")&&(0,P.jsx)(Ha,{binding:g("send.newThread"),size:"sm"})]}),(0,P.jsxs)("div",{className:"ink-modal-foot",children:[(0,P.jsx)("span",{className:ae("ink-modal-status",e.status&&`tone-${e.status.tone}`),role:"status",children:e.status?.text??"Esc keeps it saved without sending."}),e.onCopy&&(0,P.jsxs)(Xe,{size:"sm",variant:"ghost",icon:"copy",disabled:E,onClick:e.onCopy,children:["Copy",g("send.copy")&&(0,P.jsx)(Ha,{binding:g("send.copy"),size:"sm"})]}),e.onDownload&&(0,P.jsxs)(Xe,{size:"sm",variant:"ghost",icon:"desktop-download",disabled:E,onClick:e.onDownload,children:[e.downloadLabel??"Download",g("send.download")&&(0,P.jsx)(Ha,{binding:g("send.download"),size:"sm"})]})]}),f&&(0,P.jsx)(Hs,{menu:f,onClose:()=>m(null)})]})})}var E1="inkspect:request",Ls="inkspect:response",Rp="data-inkspect-target";async function Le(e){try{return await chrome.runtime.sendMessage(e)??{ok:!1,error:"No reply from the extension"}}catch(t){return{ok:!1,error:t instanceof Error?t.message:String(t)}}}var Us="inkspectShortcuts",bl=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),C1=kn.filter(e=>ip.has(e.id)),CE={"mode.device":"Responsive view","mode.screenshot":"Screenshot menu","open.shortcuts":"Keyboard shortcuts"},N1=e=>CE[e.id]??e.label,M1=e=>e==="global"?"General":ll[e],T1=["global","inspect","draw","screenshot"],A1=[...T1,...Object.keys(ll).filter(e=>!T1.includes(e))];async function z1(){let e=(await chrome.storage.sync.get(Us))[Us];return{overrides:Q0(e?.shortcuts??{}),updated:typeof e?.updated=="number"?e.updated:0}}async function O1(e){let{updated:t}=await z1();await chrome.storage.sync.set({[Us]:{shortcuts:e,updated:Math.max(Date.now(),t+1)}})}function R1(e){let t=()=>{z1().then(o=>e(Ss(o.overrides,bl),o))},n=(o,a)=>{a==="sync"&&o[Us]&&t()};return chrome.storage.onChanged.addListener(n),t(),()=>chrome.storage.onChanged.removeListener(n)}async function Dp(e,t,n){let o={...e},a=kn.find(l=>l.id===t),i=a?cl(a,bl).map(ks):[],r=n!==void 0&&n.length===i.length&&n.every(l=>i.includes(l));n===void 0||r?delete o[t]:o[t]=n,await O1(o)}async function D1(){await O1({})}var _1=(e=2)=>new Promise(t=>{let n=o=>o?requestAnimationFrame(()=>n(o-1)):setTimeout(t,30);n(e)});async function NE(e){let t=new Image;return t.src=e,await t.decode(),t}async function hl(e){let t=e();await _1();try{let n=await Le({type:"capture"});if(!n.ok||!n.dataUrl)throw new Error(n.ok?"No image":n.error);return await NE(n.dataUrl)}finally{t()}}function ME(){let e=[];for(let t of document.querySelectorAll("body *")){let n=getComputedStyle(t).position;(n==="fixed"||n==="sticky")&&(e.push([t,t.style.getPropertyValue("visibility")]),t.style.setProperty("visibility","hidden","important"))}return()=>{for(let[t,n]of e)n?t.style.setProperty("visibility",n):t.style.removeProperty("visibility")}}function AE(e,t){return Math.min(1,32e3/t,32e3/e,Math.sqrt(25e7/(e*t)))}async function _p(e,t){let n=document.documentElement,o=Math.max(n.scrollWidth,innerWidth),a=Math.max(n.scrollHeight,innerHeight),i=Math.max(0,Math.floor(e.x)),r=Math.max(0,Math.floor(e.y)),l={x:i,y:r,width:Math.max(1,Math.min(Math.ceil(e.width+e.x-i),o-i)),height:Math.max(1,Math.min(Math.ceil(e.height+e.y-r),a-r))},c={x:scrollX,y:scrollY},s=l.x>=scrollX&&l.y>=scrollY&&l.x+l.width<=scrollX+n.clientWidth&&l.y+l.height<=scrollY+n.clientHeight,f=devicePixelRatio,m=AE(l.width*f,l.height*f),u=document.createElement("canvas");u.width=Math.round(l.width*f*m),u.height=Math.round(l.height*f*m);let d=u.getContext("2d"),x=(E,g,b)=>{let p=E.width/innerWidth,v=(l.x-g)*p,h=Math.max(0,l.y-b)*p,T=Math.max(0,b-l.y),w=Math.min(l.height-T,n.clientHeight-Math.max(0,l.y-b));w<=0||d.drawImage(E,v,h,l.width*p,w*p,0,T*f*m,u.width,w*f*m)};if(s)return x(await hl(t),scrollX,scrollY),{dataUrl:u.toDataURL("image/png"),area:l};let k;try{let E=Math.min(l.x,Math.max(0,o-n.clientWidth));for(let g=l.y;g<l.y+l.height;){scrollTo(E,g),await _1(),x(await hl(t),scrollX,scrollY);let b=scrollY+n.clientHeight;if(b>=l.y+l.height||b>=a)break;g=b,k??=ME()}}finally{k?.(),scrollTo(c.x,c.y)}return{dataUrl:u.toDataURL("image/png"),area:l}}function Hp(){let e=document.documentElement;return{x:scrollX,y:scrollY,width:e.clientWidth,height:e.clientHeight}}function Bp(){let e=document.documentElement;return{x:0,y:0,width:e.clientWidth,height:Math.max(e.scrollHeight,innerHeight)}}async function H1(e){let t=e.getBoundingClientRect(),n=await hl(()=>()=>{}),o=n.width/innerWidth,a=document.createElement("canvas");return a.width=Math.round(t.width*o),a.height=Math.round(t.height*o),a.getContext("2d").drawImage(n,t.x*o,t.y*o,t.width*o,t.height*o,0,0,a.width,a.height),a.toDataURL("image/png")}async function B1(e,t=480){try{let n=e.replace(/^data:image\/\w+;base64,/,""),o=Uint8Array.from(atob(n),f=>f.charCodeAt(0)),a=await createImageBitmap(new Blob([o],{type:"image/png"})),i=Math.min(1,t/Math.max(a.width,a.height)),r=new OffscreenCanvas(Math.max(1,Math.round(a.width*i)),Math.max(1,Math.round(a.height*i)));r.getContext("2d").drawImage(a,0,0,r.width,r.height),a.close();let l=await r.convertToBlob({type:"image/jpeg",quality:.75}),c=new Uint8Array(await l.arrayBuffer()),s="";for(let f=0;f<c.length;f+=32768)s+=String.fromCharCode(...c.subarray(f,f+32768));return btoa(s)}catch{return}}function L1(e,t,n){let o=l=>{if(l===document.scrollingElement||l===document.body||l===document.documentElement)return!1;let c=getComputedStyle(l),s=f=>/auto|scroll|overlay/.test(f);return s(c.overflowY)&&l.scrollHeight>l.clientHeight+1||s(c.overflowX)&&l.scrollWidth>l.clientWidth+1},i=document.elementsFromPoint(e,t).find(l=>!n||l!==n&&!n.contains(l))??null;for(;i&&!o(i);)i=i.parentElement;if(!i)return null;let r=[];for(let l=i;l&&l!==document.documentElement;l=l.parentElement){if(l.id&&document.querySelectorAll(`#${CSS.escape(l.id)}`).length===1){r.unshift(`#${CSS.escape(l.id)}`);break}let c=l.localName,s=l.parentElement?[...l.parentElement.children].filter(f=>f.localName===c).indexOf(l)+1:1;r.unshift(`${CSS.escape(c)}:nth-of-type(${s})`)}return r.join(" > ")}function Lp(e){let t=o=>{if(o===document.scrollingElement||o===document.body||o===document.documentElement)return!1;let a=getComputedStyle(o),i=r=>/auto|scroll|overlay/.test(r);return i(a.overflowY)&&o.scrollHeight>o.clientHeight+1||i(a.overflowX)&&o.scrollWidth>o.clientWidth+1},n={};for(let o of e){let a=null;try{a=document.querySelector(o)}catch{}if(!a)continue;let i=0,r=0,l=-1/0,c=-1/0,s=1/0,f=1/0;for(let m=a;m;m=m.parentElement){if(m!==a&&!t(m))continue;if(m===document.body||m===document.documentElement)break;i+=m.scrollLeft,r+=m.scrollTop;let u=m.getBoundingClientRect();l=Math.max(l,u.left+m.clientLeft+scrollX),c=Math.max(c,u.top+m.clientTop+scrollY),s=Math.min(s,u.left+m.clientLeft+m.clientWidth+scrollX),f=Math.min(f,u.top+m.clientTop+m.clientHeight+scrollY)}n[o]={x:i,y:r,clip:{x:l,y:c,width:Math.max(0,s-l),height:Math.max(0,f-c)}}}return n}function U1(e,t,n){let o=L1(e,t,n),a=o?Lp([o])[o]:void 0;return o&&a?{id:o,at:a}:void 0}function js(e){let t=[...new Set(e.flatMap(n=>n.anchor?[n.anchor]:[]))];return t.length?Lp(t):{}}function zE(e){if(e===document.scrollingElement||e===document.body||e===document.documentElement)return!1;let t=getComputedStyle(e),n=o=>/auto|scroll|overlay/.test(o);return n(t.overflowY)&&e.scrollHeight>e.clientHeight+1||n(t.overflowX)&&e.scrollWidth>e.clientWidth+1}function j1(e,t){let n=e.deltaMode===WheelEvent.DOM_DELTA_LINE?16:e.deltaMode===WheelEvent.DOM_DELTA_PAGE?innerHeight:1,o=e.deltaX*n,a=e.deltaY*n;e.shiftKey&&!o&&([o,a]=[a,0]);let i=document.elementsFromPoint(e.clientX,e.clientY).find(r=>r!==t&&!t.contains(r))??null;for(;i;i=i.parentElement){if(!zE(i))continue;if(a>0&&i.scrollTop+i.clientHeight<i.scrollHeight-1||a<0&&i.scrollTop>0||o>0&&i.scrollLeft+i.clientWidth<i.scrollWidth-1||o<0&&i.scrollLeft>0){i.scrollBy({left:o,top:a,behavior:"instant"});return}}window.scrollBy({left:o,top:a,behavior:"instant"})}var mo=_(_e());var ot=_(U(),1),Up=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function q1({purpose:e,map:t,helpKey:n,className:o,style:a}){let i=r=>{let l=t[r]?.[0];return l?Yi(l,Up):[]};return e==="screenshot"?(0,ot.jsxs)("div",{className:ae("picker-hint",o),style:a,role:"status",children:[(0,ot.jsx)("span",{className:"picker-hint-lead",children:"Click an element to screenshot it"}),(0,ot.jsx)(vl,{caps:i("inspect.exit"),label:"cancel"})]}):(0,ot.jsxs)("div",{className:ae("picker-hint",o),style:a,role:"status",children:[(0,ot.jsxs)("span",{className:"picker-hint-item",children:[(0,ot.jsx)("span",{className:"picker-hint-lead",children:"Click"}),(0,ot.jsx)("span",{className:"picker-hint-label",children:"to capture"})]}),(0,ot.jsx)(vl,{caps:[Up?"\u2325":"Alt"],click:!0,label:"screenshot"}),(0,ot.jsx)(vl,{caps:[Up?"\u21E7":"Shift"],click:!0,label:"to add"}),(0,ot.jsx)(vl,{caps:i("inspect.exit"),label:"stop"}),n&&(0,ot.jsx)(vl,{caps:i("inspect.help"),label:"keys"})]})}function vl({caps:e,click:t,label:n}){return e.length?(0,ot.jsxs)("span",{className:"picker-hint-item",children:[(0,ot.jsx)("span",{className:"keycaps size-sm",children:e.map((o,a)=>(0,ot.jsx)("kbd",{className:"keycap",children:o},a))}),t&&(0,ot.jsx)("span",{className:"picker-hint-click",children:"+ click"}),(0,ot.jsx)("span",{className:"picker-hint-label",children:n})]}):null}var J=_(U()),OE={Escape:"inspect.exit",ArrowUp:"inspect.parent",ArrowDown:"inspect.child",Enter:"inspect.copy"},Je=e=>parseFloat(e)||0;function RE(e){let t=e.getBoundingClientRect(),n=getComputedStyle(e),o={x:t.x,y:t.y,width:t.width,height:t.height},a={x:o.x-Je(n.marginLeft),y:o.y-Je(n.marginTop),width:o.width+Je(n.marginLeft)+Je(n.marginRight),height:o.height+Je(n.marginTop)+Je(n.marginBottom)},i={x:o.x+Je(n.borderLeftWidth),y:o.y+Je(n.borderTopWidth),width:o.width-Je(n.borderLeftWidth)-Je(n.borderRightWidth),height:o.height-Je(n.borderTopWidth)-Je(n.borderBottomWidth)},r={x:i.x+Je(n.paddingLeft),y:i.y+Je(n.paddingTop),width:i.width-Je(n.paddingLeft)-Je(n.paddingRight),height:i.height-Je(n.paddingTop)-Je(n.paddingBottom)};return{margin:a,border:o,padding:i,content:r}}function DE(e){let t={r:255,g:255,b:255,a:1},n=[];for(let o=e;o;o=o.parentElement){let a=Oa(getComputedStyle(o).backgroundColor);if(a&&a.a>0&&(n.push(a),a.a>=1))break}for(let o of n.reverse())t={r:o.r*o.a+t.r*(1-o.a),g:o.g*o.a+t.g*(1-o.a),b:o.b*o.a+t.b*(1-o.a),a:1};return t}function _E(e){let t=e;return t.disabled?!1:t.tabIndex>=0}var Y1=(e,t)=>{let n=["Top","Right","Bottom","Left"].map(o=>e.getPropertyValue(`${t}-${o.toLowerCase()}`));return n.every(o=>o===n[0])?n[0]:n[0]===n[2]&&n[1]===n[3]?`${n[0]} ${n[1]}`:n.join(" ")};function HE(e){let t=getComputedStyle(e),n=e.getBoundingClientRect(),o=Oa(t.color),a=Oa(t.backgroundColor),i=DE(e),r=!!e.innerText?.trim(),l=o&&r?Jy(o,i):void 0,{role:c,name:s}=Os(e),f=Y1(t,"margin"),m=Y1(t,"padding");return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList).slice(0,4),size:`${Math.round(n.width*100)/100} \xD7 ${Math.round(n.height*100)/100}`,color:r&&o?Zi(o):void 0,font:r?`${t.fontSize} ${t.fontFamily.split(",")[0].replace(/["']/g,"")}`:void 0,background:a&&a.a>0?Zi(a):void 0,margin:f!=="0px"?f:void 0,padding:m!=="0px"?m:void 0,ratio:l,ratioPasses:l!==void 0?Iy(l,Je(t.fontSize),Number(t.fontWeight)||400):void 0,role:c,name:s,focusable:_E(e),rect:n}}function V1({host:e,purpose:t,selection:n,onPick:o,onCommit:a,onExit:i,actionOf:r,map:l}){let[c,s]=(0,mo.useState)(null),[,f]=(0,mo.useState)(0),m=(0,mo.useRef)(null),u=(0,mo.useRef)({onPick:o,onCommit:a,onExit:i,actionOf:r});(0,mo.useEffect)(()=>{u.current={onPick:o,onCommit:a,onExit:i,actionOf:r}}),(0,mo.useEffect)(()=>{let p=B=>B.composedPath().includes(e),v=(B,Y)=>document.elementsFromPoint(B,Y).find(I=>I!==e&&!e.contains(I))??null,h=B=>{m.current=B,s(B)},T=B=>{if(p(B))return;let Y=v(B.clientX,B.clientY);Y!==m.current&&h(Y)},w=B=>{p(B)||(B.preventDefault(),B.stopImmediatePropagation())},S=B=>{if(p(B))return;w(B);let Y=v(B.clientX,B.clientY)??m.current;Y&&u.current.onPick(Y,{add:B.shiftKey,screenshot:B.altKey})},M=B=>{let Y=u.current.actionOf?u.current.actionOf(B):OE[B.key];if(p(B)&&Y!=="inspect.exit")return;let I=m.current;if(Y==="inspect.exit")u.current.onExit();else if(Y==="inspect.parent"&&I)h(vy(I)??I);else if(Y==="inspect.child"&&I)h(yy(I)??I);else if(Y==="inspect.copy")u.current.onCommit(I);else return;B.preventDefault(),B.stopImmediatePropagation()},A=()=>f(B=>B+1),H=["mousedown","mouseup","pointerdown","pointerup","dblclick","auxclick","contextmenu"];window.addEventListener("mousemove",T,!0),window.addEventListener("click",S,!0),window.addEventListener("keydown",M,!0),window.addEventListener("scroll",A,!0),window.addEventListener("resize",A);for(let B of H)window.addEventListener(B,w,!0);return()=>{window.removeEventListener("mousemove",T,!0),window.removeEventListener("click",S,!0),window.removeEventListener("keydown",M,!0),window.removeEventListener("scroll",A,!0),window.removeEventListener("resize",A);for(let B of H)window.removeEventListener(B,w,!0)}},[e]);let d=c?.isConnected?HE(c):void 0,x=c?.isConnected?RE(c):void 0,k=p=>({left:p.x,top:p.y,width:Math.max(0,p.width),height:Math.max(0,p.height)}),E=250,g=d?d.rect.bottom+8+220<innerHeight?d.rect.bottom+8:Math.max(4,d.rect.top-8-220):0,b=d?Math.max(4,Math.min(d.rect.left,innerWidth-E-8)):0;return(0,J.jsxs)("div",{className:"inspector",children:[(0,J.jsx)(q1,{className:"inspect-hint",purpose:t,map:l}),x&&(0,J.jsxs)(J.Fragment,{children:[(0,J.jsx)("div",{className:"hl hl-margin",style:k(x.margin)}),(0,J.jsx)("div",{className:"hl hl-border",style:k(x.border)}),(0,J.jsx)("div",{className:"hl hl-padding",style:k(x.padding)}),(0,J.jsx)("div",{className:"hl hl-content",style:k(x.content)}),(0,J.jsx)("div",{className:"hl hl-outline",style:k(x.border)})]}),n.map((p,v)=>{let h=p.getBoundingClientRect();return(0,J.jsx)("div",{className:"selection-box",style:k(h),children:(0,J.jsx)("span",{className:"selection-badge",children:v+1})},v)}),d&&(0,J.jsxs)("div",{className:"tip",style:{left:b,top:g,width:E},children:[(0,J.jsxs)("div",{className:"tip-head",children:[(0,J.jsxs)("span",{children:[(0,J.jsx)("span",{className:"tip-tag",children:d.tag}),d.id&&(0,J.jsxs)("span",{className:"tip-id",children:["#",d.id]}),d.classes.map(p=>(0,J.jsxs)("span",{className:"tip-class",children:[".",p]},p))]}),(0,J.jsx)("span",{className:"tip-size",children:d.size})]}),d.color&&(0,J.jsx)(Ba,{label:"Color",value:d.color,swatch:d.color}),d.font&&(0,J.jsx)(Ba,{label:"Font",value:d.font}),d.background&&(0,J.jsx)(Ba,{label:"Background",value:d.background,swatch:d.background}),d.margin&&(0,J.jsx)(Ba,{label:"Margin",value:d.margin}),d.padding&&(0,J.jsx)(Ba,{label:"Padding",value:d.padding}),(0,J.jsx)("div",{className:"tip-section",children:"Accessibility"}),d.ratio!==void 0&&(0,J.jsxs)("div",{className:"tip-row",children:[(0,J.jsx)("span",{children:"Contrast"}),(0,J.jsxs)("span",{children:[(0,J.jsx)("span",{className:"tip-aa",style:{color:d.color,background:d.background},children:"Aa"})," ",d.ratio.toFixed(2)," ",(0,J.jsx)("span",{className:d.ratioPasses?"ok":"bad",children:d.ratioPasses?"\u2713":"!"})]})]}),(0,J.jsx)(Ba,{label:"Name",value:d.name??""}),(0,J.jsx)(Ba,{label:"Role",value:d.role??"generic"}),(0,J.jsxs)("div",{className:"tip-row",children:[(0,J.jsx)("span",{children:"Keyboard-focusable"}),(0,J.jsx)("span",{className:d.focusable?"ok":"muted",children:d.focusable?"\u2713":"\u2298"})]})]})]})}function Ba({label:e,value:t,swatch:n}){return(0,J.jsxs)("div",{className:"tip-row",children:[(0,J.jsx)("span",{children:e}),(0,J.jsxs)("span",{className:"tip-value",children:[n&&(0,J.jsx)("span",{className:"tip-swatch",style:{background:n}}),t]})]})}var Wi=_(_e());var qs=_(_e(),1);var X1=_(U(),1);function K1({children:e,confirmLabel:t,onConfirm:n,icon:o,variant:a="ghost",size:i="sm",disabled:r,title:l,className:c}){let[s,f]=(0,qs.useState)(!1);return(0,qs.useEffect)(()=>{if(!s)return;let m=setTimeout(()=>f(!1),4e3);return()=>clearTimeout(m)},[s]),(0,X1.jsx)(Xe,{size:i,variant:s?"danger":a,icon:s?"warning":o,disabled:r,title:l,className:c,"aria-live":"polite",onClick:()=>{if(!s){f(!0);return}f(!1),n()},onBlur:()=>f(!1),children:s?t:e})}var $i=_(U(),1);function Ys({label:e,hint:t,error:n,inline:o,className:a,children:i}){return(0,$i.jsxs)("label",{className:ae("field",o&&"inline",a),children:[(0,$i.jsx)("span",{className:"field-label",children:e}),(0,$i.jsx)("span",{className:"field-control",children:i}),(n||t)&&(0,$i.jsx)("span",{className:ae("field-hint",n&&"error"),role:n?"alert":void 0,children:n??t})]})}var Fo=_(_e(),1);var W=_(U(),1),Ji=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function Q1({actions:e,scopes:t,map:n,overrides:o,query:a="",labelOf:i=s=>s.label,scopeLabel:r=s=>ll[s],onSetKeys:l,onReset:c}){let[s,f]=(0,Fo.useState)(new Set),[m,u]=(0,Fo.useState)(null),d=(0,Fo.useMemo)(()=>new Set(e.map(p=>p.id)),[e]),x=(0,Fo.useMemo)(()=>Z0(n).filter(p=>p.ids.every(v=>d.has(v))),[n,d]),k=p=>x.filter(v=>v.ids.includes(p)).map(v=>({key:v.key,other:v.ids.find(h=>h!==p)}));(0,Fo.useEffect)(()=>{if(!m)return;let p=h=>{if(h.preventDefault(),h.stopImmediatePropagation(),Ts.has(h.key))return;let T=uo(h);if(!T.key)return;let w=!T.ctrl&&!T.alt&&!T.meta&&!T.shift,S=[...n[m.id]??[]];if(w&&T.key==="escape"){u(null);return}if(w&&T.key==="backspace"&&m.index!==void 0)S.splice(m.index,1);else{let M=Es(T);m.index===void 0?S.push(M):S[m.index]=M}l(m.id,[...new Set(S)]),u(null)},v=h=>{h.composedPath().some(w=>w instanceof HTMLElement&&w.classList.contains("key-recording"))||u(null)};return window.addEventListener("keydown",p,!0),window.addEventListener("pointerdown",v,!0),()=>{window.removeEventListener("keydown",p,!0),window.removeEventListener("pointerdown",v,!0)}},[m,n,l]);let E=a.trim().toLowerCase(),g=p=>!E||i(p).toLowerCase().includes(E)||p.id.toLowerCase().includes(E)||r(p.scope).toLowerCase().includes(E)||(n[p.id]??[]).some(v=>It(v,Ji).toLowerCase().includes(E)||$0(v,E)),b=p=>{let v=e.find(h=>h.id===p);return v?i(v):p};return(0,W.jsxs)("div",{className:"shortcut-list",children:[x.length>0&&(0,W.jsxs)("p",{className:"shortcuts-warning",role:"alert",children:[(0,W.jsx)("span",{className:"codicon codicon-warning","aria-hidden":"true"}),x.length===1?"1 key is":`${x.length} keys are`," used twice."]}),t.map(p=>{let v=e.filter(T=>T.scope===p&&g(T));if(!v.length)return null;let h=E!==""||!s.has(p);return(0,W.jsxs)("section",{className:"shortcut-group",children:[(0,W.jsxs)("button",{type:"button",className:"group-header","aria-expanded":h,onClick:()=>f(T=>{let w=new Set(T);return w.has(p)?w.delete(p):w.add(p),w}),children:[(0,W.jsx)("span",{className:`codicon codicon-chevron-${h?"down":"right"}`,"aria-hidden":"true"}),(0,W.jsx)("span",{className:`codicon codicon-${I0[p]} group-icon`,"aria-hidden":"true"}),(0,W.jsx)("span",{className:"group-title",children:r(p)}),(0,W.jsx)("span",{className:"group-count",children:v.length})]}),h&&v.map(T=>(0,W.jsx)(BE,{action:T,label:i(T),keys:n[T.id]??[],changed:T.id in o,conflicts:k(T.id).map(w=>({...w,otherLabel:b(w.other)})),recording:m?.id===T.id?m:null,onRecord:w=>u({id:T.id,index:w}),onCancel:()=>u(null),onRemove:w=>l(T.id,(n[T.id]??[]).filter((S,M)=>M!==w)),onReset:()=>c(T.id),onResolve:(w,S)=>l(w,(n[w]??[]).filter(M=>M!==S))},T.id))]},p)})]})}function BE({action:e,label:t,keys:n,changed:o,conflicts:a,recording:i,onRecord:r,onCancel:l,onRemove:c,onReset:s,onResolve:f}){let m=cl(e,Ji).map(d=>It(d,Ji)).join(", ")||"none",u=i!==null&&i.index===void 0;return(0,W.jsxs)("div",{className:`shortcut-item${o?" changed":""}${a.length?" conflict":""}`,children:[(0,W.jsxs)("div",{className:"shortcut-main",children:[(0,W.jsx)("span",{className:"shortcut-label",title:e.id,children:t}),(0,W.jsx)("span",{className:"shortcut-places",children:P0(e).map(d=>(0,W.jsx)("span",{className:`shortcut-tag ${d.id}`,title:d.title,children:d.label},d.id))}),(0,W.jsxs)("span",{className:"shortcut-actions",children:[o&&(0,W.jsx)(Ee,{icon:"discard",label:`Reset to default (${m})`,className:"small",onClick:s}),n.length>0&&!u&&(0,W.jsx)(Ee,{icon:"add",label:"Add another key",className:"small add-key",onClick:()=>r()})]}),(0,W.jsxs)("span",{className:"shortcut-keys-column",children:[n.map((d,x)=>i?.index===x?(0,W.jsx)(G1,{onCancel:l},d):(0,W.jsxs)("span",{className:"key-button-wrap",children:[(0,W.jsx)("button",{type:"button",className:"key-button",title:"Change: click, then press the new keys","aria-label":`${It(d,Ji)}: change`,onClick:()=>r(x),children:(0,W.jsx)(Ha,{binding:d,size:"sm"})}),(0,W.jsx)("button",{type:"button",className:"key-remove","aria-label":`Remove ${It(d,Ji)}`,title:"Remove this key",onClick:()=>c(x),children:(0,W.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]},d)),u&&(0,W.jsx)(G1,{onCancel:l}),!n.length&&!u&&(0,W.jsxs)("button",{type:"button",className:"key-empty",title:"Add a key: click, then press the keys",onClick:()=>r(),children:[(0,W.jsx)("span",{className:"codicon codicon-add","aria-hidden":"true"}),"Add key"]})]})]}),a.map(({key:d,other:x,otherLabel:k})=>(0,W.jsxs)("div",{className:"shortcut-conflict",children:[(0,W.jsx)("span",{className:"codicon codicon-warning","aria-hidden":"true"}),(0,W.jsxs)("span",{children:[It(d,Ji)," is also \u201C",k,"\u201D"]}),(0,W.jsx)("button",{type:"button",className:"link-button",onClick:()=>f(x,d),children:"Remove it there"})]},`${d}-${x}`))]})}function G1({onCancel:e}){return(0,W.jsxs)("span",{className:"key-recording",role:"status",children:[(0,W.jsx)("span",{className:"recording-dot","aria-hidden":"true"}),"Press keys\u2026",(0,W.jsx)("button",{type:"button",className:"key-recording-cancel","aria-label":"Cancel",onClick:e,children:(0,W.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]})}var Z1=_(_e(),1);var La=_(U(),1);function jp({value:e,options:t,onChange:n,label:o,iconOnly:a,size:i="md",className:r}){let l=(0,Z1.useRef)(null),c=s=>{let f={ArrowRight:1,ArrowDown:1,ArrowLeft:-1,ArrowUp:-1}[s.key];if(!f)return;s.preventDefault();let m=t.findIndex(d=>d.value===e),u=t[(m+f+t.length)%t.length];n(u.value),l.current?.querySelector(`[data-value="${CSS.escape(u.value)}"]`)?.focus()};return(0,La.jsx)("div",{ref:l,className:ae("segmented",`size-${i}`,r),role:"radiogroup","aria-label":o,onKeyDown:c,children:t.map(s=>{let f=s.value===e;return(0,La.jsxs)("button",{type:"button",role:"radio","aria-checked":f,"aria-label":a?s.label:void 0,title:a||s.icon?s.label:void 0,"data-value":s.value,tabIndex:f?0:-1,className:ae("segment",f&&"checked"),onClick:()=>n(s.value),children:[s.icon&&(0,La.jsx)("span",{className:`codicon codicon-${s.icon}`,"aria-hidden":"true"}),!a&&(0,La.jsx)("span",{className:"segment-label",children:s.label}),s.count!==void 0&&(0,La.jsx)("span",{className:ae("segment-count",s.tone),children:s.count})]},s.value)})})}var Ii=_(U(),1);function qp({checked:e,onChange:t,children:n,label:o,disabled:a,className:i,title:r}){return(0,Ii.jsxs)("button",{type:"button",role:"switch","aria-checked":e,"aria-label":n?void 0:o,title:r,disabled:a,className:ae("switch",e&&"on",i),onClick:()=>t(!e),children:[(0,Ii.jsx)("span",{className:"switch-track","aria-hidden":"true",children:(0,Ii.jsx)("span",{className:"switch-thumb"})}),n&&(0,Ii.jsx)("span",{className:"toggle-label",children:n})]})}var yl=_(_e());var Vs=_(_e()),Fi=_(U());function P1({value:e,onChange:t,onComplete:n,length:o=6,disabled:a}){let i=(0,Vs.useRef)([]),r=Array.from({length:o},(s,f)=>e[f]??""),l=s=>i.current[Math.max(0,Math.min(o-1,s))]?.focus(),c=(s,f)=>{let m=f.replace(/\D/g,"");if(!m)return;let u=(e.slice(0,s)+m).slice(0,o);t(u),l(u.length),u.length===o&&n?.(u)};return(0,Fi.jsx)("div",{className:"code-input",role:"group","aria-label":"Pairing code",children:r.map((s,f)=>(0,Fi.jsxs)(Vs.Fragment,{children:[f===o/2&&(0,Fi.jsx)("span",{className:"code-sep","aria-hidden":"true"}),(0,Fi.jsx)("input",{ref:m=>{i.current[f]=m},className:"code-box",inputMode:"numeric",autoComplete:"one-time-code","aria-label":`Digit ${f+1}`,maxLength:o,disabled:a,value:s,onFocus:m=>m.currentTarget.select(),onChange:m=>c(Math.min(f,e.length),m.target.value),onPaste:m=>{m.preventDefault(),c(0,m.clipboardData.getData("text"))},onKeyDown:m=>{if(m.key==="Backspace"){m.preventDefault();let u=s?f:f-1;u>=0&&t(e.slice(0,u)),l(u)}else m.key==="ArrowLeft"?(m.preventDefault(),l(f-1)):m.key==="ArrowRight"&&(m.preventDefault(),l(f+1))}})]},f))})}var le=_(U());function $1({status:e,pair:t,compact:n,startWithCode:o}){let[a,i]=(0,yl.useState)(""),[r,l]=(0,yl.useState)(""),[c,s]=(0,yl.useState)(!1),[f,m]=(0,yl.useState)(!!o);if(e.state==="connected")return null;let u=async(x=a)=>{if(x.length!==6||c)return;s(!0),l("");let k=await t(x).catch(()=>{});if(s(!1),!k){l("The extension did not answer. Reload it and try again.");return}l(k.error??""),k.state==="connected"&&i("")},d=(0,le.jsxs)("p",{className:"card-foot",children:[(0,le.jsx)("span",{className:"codicon codicon-lock","aria-hidden":"true"}),"The link only talks to VS Code on this computer, and only after pairing (or through the browser helper VS Code installs)."]});return e.via==="hub"?(0,le.jsx)("div",{className:ae("card","pair-card",n&&"compact"),children:(0,le.jsxs)("p",{className:"pair-lead",children:[(0,le.jsx)("span",{className:"codicon codicon-plug","aria-hidden":"true"}),(0,le.jsx)("span",{children:"Linked through the browser helper: no pairing needed. VS Code isn't running, so sends to its terminals and chat wait for it; captures still save into your projects, and agentmux agents still get them."})]})}):e.state!=="unpaired"?(0,le.jsxs)("div",{className:ae("card","pair-card",n&&"compact"),children:[(0,le.jsxs)("p",{className:"pair-lead",children:[(0,le.jsx)("span",{className:"codicon codicon-loading codicon-modifier-spin","aria-hidden":"true"}),(0,le.jsxs)("span",{children:["Open VS Code with the VS Code Browser extension. Then click"," ",(0,le.jsx)("b",{children:"Pair Browser Extension"})," in its ",(0,le.jsx)("b",{children:"Browser"})," side panel."]})]}),!n&&d]}):(0,le.jsxs)("form",{className:ae("card","pair-card",n&&"compact"),onSubmit:x=>{x.preventDefault(),u()},children:[(0,le.jsxs)("p",{className:"pair-lead",children:[(0,le.jsx)("span",{className:"codicon codicon-plug","aria-hidden":"true"}),(0,le.jsxs)("span",{children:["In VS Code, click ",(0,le.jsx)("b",{children:"Pair Browser Extension"})," in the ",(0,le.jsx)("b",{children:"Browser"})," side panel (or"," ",(0,le.jsx)("b",{children:"Pair"})," on its notification). No code needed: this updates by itself."]})]}),f?(0,le.jsxs)(le.Fragment,{children:[(0,le.jsxs)("p",{className:"muted",children:["Run ",(0,le.jsx)("kbd",{children:"Browser: Pair Browser Extension with a Code"})," in VS Code, then type the code it shows."]}),(0,le.jsxs)("div",{className:"pair-row",children:[(0,le.jsx)(P1,{value:a,onChange:i,disabled:c,onComplete:x=>{u(x)}}),(0,le.jsx)(Xe,{type:"submit",variant:"primary",icon:"link",className:"pair-button",loading:c,disabled:a.length!==6,children:"Pair"})]})]}):(0,le.jsx)(Xe,{size:"sm",variant:"ghost",icon:"key",className:"use-code",onClick:()=>m(!0),children:"Use a code instead"}),r&&(0,le.jsxs)("p",{className:"pair-message",role:"alert",children:[(0,le.jsx)("span",{className:"codicon codicon-error","aria-hidden":"true"}),r]}),!n&&d]})}function Ua(e,t=2e3){let n=crypto.randomUUID();return new Promise(o=>{let a=r=>{let l;try{l=JSON.parse(r.detail)}catch{return}l.id===n&&(window.removeEventListener(Ls,a),clearTimeout(i),o(l.result))},i=setTimeout(()=>{window.removeEventListener(Ls,a),o(void 0)},t);window.addEventListener(Ls,a),window.dispatchEvent(new CustomEvent(E1,{detail:JSON.stringify({id:n,request:e})}))})}async function xl(e){try{return await navigator.clipboard.writeText(e),!0}catch{let t=document.createElement("textarea");t.value=e,t.style.cssText="position:fixed;left:-9999px;top:0;opacity:0",document.documentElement.appendChild(t),t.select();let n=document.execCommand("copy");return t.remove(),n}}async function Ks(e){try{let t=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({"image/png":t})]),!0}catch{return!1}}var LE={copyFormat:"markdown",fields:[...dp],maxHtml:2e3,annotationPadding:40};async function Yp(){let e=await chrome.storage.sync.get("settings").catch(()=>({}));return{...LE,...e.settings}}function Vp(e=new Date){let t=a=>String(a).padStart(2,"0"),n=`${e.getFullYear()}-${t(e.getMonth()+1)}-${t(e.getDate())}_${t(e.getHours())}-${t(e.getMinutes())}-${t(e.getSeconds())}`,o=(location.hostname||"page").replace(/[^a-z0-9.-]+/gi,"-").slice(0,40);return`screenshot-${n}-${o}.png`}var q=_(U());function Xs({title:e,onClose:t,children:n}){return(0,q.jsxs)("div",{className:"panel",role:"dialog","aria-label":e,children:[(0,q.jsxs)("div",{className:"panel-head",children:[(0,q.jsx)("span",{children:e}),(0,q.jsx)("button",{type:"button",className:"icon-button","aria-label":"Close",title:"Close",onClick:t,children:(0,q.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]}),(0,q.jsx)("div",{className:"panel-body",children:n})]})}var J1={network:"none",cpu:1,colorScheme:"default",print:!1,agent:!0};function I1({onClose:e,value:t,onChange:n}){let a=i=>n({...t,...i});return(0,q.jsxs)(Xs,{title:"Emulation",onClose:e,children:[!1,(0,q.jsx)(qp,{checked:t.agent,disabled:!1,onChange:i=>a({agent:i}),children:"Device user agent and touch"}),(0,q.jsxs)("div",{className:"row",children:[(0,q.jsx)(Ys,{label:"Network",children:(0,q.jsx)(Vn,{size:"sm",label:"Network",disabled:!1,value:t.network,onChange:i=>a({network:i}),options:Object.entries(xy).map(([i,r])=>({value:i,label:r.label}))})}),(0,q.jsx)(Ys,{label:"CPU",children:(0,q.jsx)(Vn,{size:"sm",label:"CPU",disabled:!1,value:String(t.cpu),onChange:i=>a({cpu:Number(i)}),options:wy.map(i=>({value:String(i),label:i===1?"Normal":`${i}\xD7 slower`}))})})]}),(0,q.jsx)(Ys,{label:"Color scheme",children:(0,q.jsx)(jp,{size:"sm",label:"Color scheme",value:t.colorScheme,onChange:i=>a({colorScheme:i}),options:[{value:"default",label:"Page default"},{value:"light",label:"Light",icon:"color-mode"},{value:"dark",label:"Dark",icon:"color-mode"}]})}),(0,q.jsx)(qp,{checked:t.print,disabled:!1,onChange:i=>a({print:i}),children:"Print media"}),(0,q.jsx)("p",{className:"note",children:"Chrome shows a \u201Cstarted debugging this browser\u201D bar while any of these are on."})]})}var UE={error:"error",warning:"warning",info:"info",debug:"debug",log:"circle-small"};function F1({onClose:e,copy:t,pageContext:n}){let[o,a]=(0,Wi.useState)({console:[],network:[]}),[i,r]=(0,Wi.useState)("console");(0,Wi.useEffect)(()=>{let u=!0,d=async()=>{let k=await Ua({kind:"logs"});u&&k&&a(k)};d();let x=setInterval(()=>{d()},1e3);return()=>{u=!1,clearInterval(x)}},[]);let l=async()=>await Ua({kind:"logs"})??o,c=o.console.filter(u=>u.level==="error"),s=o.network.filter(Ds),f=i==="console"?o.console.slice(-200).reverse():[],m=i==="console"?!f.length:!s.length;return(0,q.jsxs)(Xs,{title:"Console and network",onClose:e,children:[(0,q.jsxs)("div",{className:"console-tabs",children:[(0,q.jsx)(jp,{size:"sm",label:"Show",className:"console-view",value:i,onChange:r,options:[{value:"console",label:"Console",icon:"terminal",count:c.length||void 0,tone:c.length?"error":void 0},{value:"network",label:"Failed requests",icon:"globe",count:s.length||void 0,tone:s.length?"error":void 0}]}),(0,q.jsx)(Ee,{icon:"clear-all",label:"Clear",onClick:()=>{Ua({kind:"clearLogs"}).then(()=>a({console:[],network:[]}))}})]}),(0,q.jsxs)("div",{className:"log",children:[i==="console"?f.map(u=>(0,q.jsxs)("div",{className:`log-row level-${u.level}`,children:[(0,q.jsx)("span",{className:`log-icon codicon codicon-${UE[u.level]??"circle-small"}`,"aria-hidden":"true"}),(0,q.jsx)("span",{className:"log-text",children:u.text}),u.url&&(0,q.jsxs)("span",{className:"log-source",title:u.url,children:[jE(u.url),u.line!==void 0?`:${u.line+1}`:""]})]},u.id)):s.map(u=>(0,q.jsxs)("div",{className:"log-row level-error",title:u.url,children:[(0,q.jsx)("span",{className:"log-icon codicon codicon-error","aria-hidden":"true"}),(0,q.jsxs)("span",{className:"log-text",children:[u.method," ",u.url]}),(0,q.jsx)("span",{className:"log-source",children:u.error??u.status})]},u.id)),m&&(0,q.jsxs)("div",{className:"log-empty",children:[(0,q.jsx)("span",{className:"codicon codicon-check-all","aria-hidden":"true"}),(0,q.jsx)("strong",{children:i==="console"?"No console messages yet":"No failed requests"}),(0,q.jsx)("span",{children:"They are recorded while the toolbar is open on this page."})]})]}),(0,q.jsxs)("div",{className:"panel-group",children:[(0,q.jsx)("span",{className:"panel-group-title",children:"Copy for AI"}),(0,q.jsxs)("div",{className:"button-row wrap",children:[(0,q.jsx)(Xe,{size:"sm",icon:"copy",title:"Copy console errors for AI","aria-label":"Copy console errors for AI",onClick:()=>{l().then(u=>t(Ty(u.console,location.href),"Console errors","errors"))},children:"Console errors"}),(0,q.jsx)(Xe,{size:"sm",icon:"copy",title:"Copy failed requests for AI","aria-label":"Copy failed requests for AI",onClick:()=>{l().then(u=>t(Ny(u.network,location.href),"Failed requests","network"))},children:"Failed requests"}),(0,q.jsx)(Xe,{size:"sm",icon:"copy",title:"Copy page context for AI","aria-label":"Copy page context for AI",onClick:()=>{n().then(u=>t(u,"Page context","page"))},children:"Page context"})]})]})]})}function W1({onClose:e,status:t}){return(0,q.jsxs)(Xs,{title:"VS Code link",onClose:e,children:[t.state==="connected"?(0,q.jsxs)("p",{className:"status status-connected",children:["Linked with ",t.peer??"VS Code",t.via==="hub"?" through the browser helper":"",". Captures are saved into your projects and offered to send; bookmarks sync both ways."]}):(0,q.jsx)($1,{compact:!0,status:t,pair:n=>Le({type:"pair",code:n}).then(o=>o.ok?o.status:{...t,error:o.error})}),(0,q.jsx)("div",{className:"button-row",children:(0,q.jsx)(Xe,{size:"sm",variant:"secondary",onClick:()=>{Le({type:"openOptions"})},children:"Settings"})})]})}function ex({onClose:e,map:t,overrides:n,linked:o}){let[a,i]=(0,Wi.useState)(""),r=Object.keys(n).length;return(0,q.jsxs)(Xs,{title:"Keyboard shortcuts",onClose:e,children:[(0,q.jsxs)("div",{className:"shortcuts-bar",children:[(0,q.jsx)(ny,{size:"sm",value:a,onChange:i}),(0,q.jsx)(K1,{icon:"discard",confirmLabel:"Click again to reset",title:"Reset all shortcuts (here and in VS Code)",disabled:!r,onConfirm:()=>{D1()},children:"Reset all"})]}),(0,q.jsxs)("p",{className:"note shortcuts-sync",children:[(0,q.jsx)("span",{className:`codicon codicon-${o?"sync":"cloud"}`,"aria-hidden":"true"}),o?"Shared with VS Code: changes here apply there too, and the other way round.":"Saved to your browser account. They sync with VS Code once it is linked."]}),(0,q.jsx)(Q1,{actions:kn,scopes:A1,map:t,overrides:n,query:a,labelOf:N1,scopeLabel:M1,onSetKeys:(l,c)=>{Dp(n,l,c)},onReset:l=>{Dp(n,l,void 0)}})]})}function jE(e){let t=e.split(/[?#]/)[0].split("/").pop()||e;try{return decodeURIComponent(t)}catch{return t}}var Sn=_(_e());var je=_(U()),qE=[{value:"fit",label:"Fit"},...[.5,.75,1,1.25].map(e=>({value:String(e),label:`${e*100}%`}))],YE=[{value:"custom",label:"Custom size",icon:"screen-full"},...Xi.map(e=>({value:e.id,label:e.name,detail:`${e.width}\xD7${e.height}`,group:e.group,icon:e.group==="Desktops"?"vm":"device-mobile"}))],tx=32,VE=36;function ox({top:e,device:t,onDevice:n,zoom:o,onZoom:a,src:i,frameRef:r,emulationActive:l,onEmulation:c,onClose:s}){let f=(0,Sn.useRef)(null),m=(0,Sn.useRef)(null),[u,d]=(0,Sn.useState)({width:0,height:0});(0,Sn.useLayoutEffect)(()=>{let h=f.current,T=()=>d({width:h.clientWidth,height:h.clientHeight}),w=new ResizeObserver(T);return w.observe(h),T(),()=>w.disconnect()},[]);let[x,k]=(0,Sn.useState)(null),E=x??Sy(o,t,{width:u.width-tx*2,height:u.height-tx*2-VE}),g=(0,Sn.useRef)(null),b=(h,T)=>(0,je.jsx)("div",{className:`rv-handle rv-handle-${h}`,role:"separator","aria-label":T,title:T,onPointerDown:w=>{w.preventDefault(),w.currentTarget.setPointerCapture(w.pointerId),g.current={x:w.clientX,y:w.clientY,width:t.width,height:t.height},k(E)},onPointerMove:w=>{let S=g.current;if(!S)return;let M=(A,H)=>Math.round(Math.min(gp,Math.max(mp,A+2*H/E)));n({...t,presetId:void 0,width:h==="y"?t.width:M(S.width,w.clientX-S.x),height:h==="x"?t.height:M(S.height,w.clientY-S.y)})},onPointerUp:()=>{g.current=null,k(null)},onPointerCancel:()=>{g.current=null,k(null)}}),p=(h,T)=>{let w=Math.round(Number(T));!Number.isFinite(w)||w<mp||n({...t,presetId:void 0,[h]:Math.min(gp,w)})},v=Xi.find(h=>h.id===t.presetId);return(0,je.jsxs)("div",{className:`rv${x!==null?" dragging":""}`,style:{top:e},children:[(0,je.jsxs)("div",{className:"rv-controls",role:"toolbar","aria-label":"Responsive view",children:[(0,je.jsx)(Vn,{size:"sm",label:"Device",className:"rv-device",value:v?v.id:"custom",options:YE,onChange:h=>{let T=Xi.find(w=>w.id===h);T?n(Rs(T)):(n({...t,presetId:void 0}),requestAnimationFrame(()=>m.current?.focus()))}}),(0,je.jsx)(nx,{label:"Width",value:t.width,onCommit:h=>p("width",h),inputRef:m}),(0,je.jsx)("span",{className:"rv-times","aria-hidden":"true",children:"\xD7"}),(0,je.jsx)(nx,{label:"Height",value:t.height,onCommit:h=>p("height",h)}),(0,je.jsx)(Ee,{icon:"sync",label:"Rotate",onClick:()=>n(ky(t))}),(0,je.jsx)("span",{className:"rv-divider","aria-hidden":"true"}),(0,je.jsx)(Vn,{size:"sm",label:"Zoom",className:"rv-zoom",value:String(o),options:qE,onChange:h=>a(h==="fit"?"fit":Number(h))}),(0,je.jsx)(Ee,{icon:"settings",label:"Network, CPU, color scheme and user agent",active:l,onClick:c}),(0,je.jsx)(Ee,{icon:"close",label:"Close the responsive view",onClick:s})]}),(0,je.jsx)("div",{className:"rv-area",ref:f,children:(0,je.jsxs)("div",{className:"rv-stage",children:[(0,je.jsxs)("div",{className:"rv-frame",children:[(0,je.jsx)("div",{className:"rv-screen",style:{width:t.width*E,height:t.height*E},children:i&&(0,je.jsx)("iframe",{ref:r,title:`${v?.name??"Custom size"} preview`,src:i,sandbox:"allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-top-navigation-by-user-activation",style:{width:t.width,height:t.height,transform:`scale(${E})`}})}),b("x","Drag to change the width"),b("y","Drag to change the height"),b("xy","Drag to change the size")]}),(0,je.jsxs)("div",{className:"rv-caption",children:[v?.name??"Custom size"," \xB7 ",t.width," \xD7 ",t.height,E!==1&&` \xB7 ${Math.round(E*100)}%`]})]})})]})}function nx({label:e,value:t,onCommit:n,inputRef:o}){let[a,i]=(0,Sn.useState)(null),r=(0,Sn.useRef)(!1),l=()=>{a!==null&&n(a),i(null)};return(0,je.jsx)(Ns,{size:"sm",className:"rv-size",ref:o,"aria-label":e,inputMode:"numeric",value:a??String(t),onChange:c=>i(c.target.value.replace(/\D/g,"")),onFocus:c=>{c.currentTarget.select(),r.current=!0},onMouseUp:c=>{r.current&&c.preventDefault(),r.current=!1},onBlur:l,onKeyDown:c=>{c.key==="Enter"?l():c.key==="Escape"&&i(null)}})}var Kp="inkspectDrawings",KE=30,Gp=ry;async function ax(){let t=(await chrome.storage.local.get(Kp).catch(()=>({})))[Kp];return t&&typeof t=="object"?t:{}}var Xp=Promise.resolve(),mn;async function ix(e){return mn?.page===e?mn.shapes:(await Xp,py((await ax())[e]?.shapes))}function XE(e,t){Xp=Xp.then(async()=>{let n=await ax();t.length?n[e]={shapes:t,at:Date.now()}:delete n[e];let o=Object.entries(n).sort(([,a],[,i])=>i.at-a.at).slice(0,KE);await chrome.storage.local.set({[Kp]:Object.fromEntries(o)})}).catch(()=>{})}function wl(){mn&&(clearTimeout(mn.timer),XE(mn.page,mn.shapes),mn=void 0)}function rx(e,t){mn&&mn.page!==e&&wl(),mn&&clearTimeout(mn.timer),mn={page:e,shapes:t,timer:setTimeout(wl,400)}}var qe=_(_e()),Gs="toolbarPosition",er=8,lx=12,GE={k:700,c:40},QE={k:320,c:20},cx=24,ZE=()=>matchMedia("(prefers-reduced-motion: reduce)").matches,Qs=e=>({width:e?.offsetWidth??0,height:e?.offsetHeight??0}),sx=e=>Math.round(e*devicePixelRatio)/devicePixelRatio,kl=(e,t)=>{e&&(e.style.transform=`translate(${sx(t.x)}px, ${sx(t.y)}px)`)};function ux(e,t,n=!1){let o=(0,qe.useRef)(null),[a,i]=(0,qe.useState)(null),[r,l]=(0,qe.useState)(!1),c=(0,qe.useRef)({x:0,y:0}),s=(0,qe.useRef)({x:0,y:0}),f=(0,qe.useRef)({x:0,y:0}),m=(0,qe.useRef)(null),u=(0,qe.useRef)(!1),d=(0,qe.useRef)(0),x=(0,qe.useRef)(0),k=(0,qe.useCallback)(S=>{let{width:M,height:A}=Qs(t.current),H=Math.max(er,innerWidth-M-er),B=Math.max(er,innerHeight-A-er);return{x:Math.min(H,Math.max(er,S.x)),y:Math.min(B,Math.max(er,S.y))}},[t]),E=(0,qe.useCallback)(()=>{let{width:S,height:M}=Qs(t.current);i({...c.current,width:S,height:M})},[t]),g=(0,qe.useCallback)(S=>{let M=Math.min(.032,(S-x.current)/1e3||.016);x.current=S;let{k:A,c:H}=m.current?GE:QE,B=!1;for(let Y of["x","y"]){let I=f.current[Y]-c.current[Y];s.current[Y]+=(A*I-H*s.current[Y])*M,c.current[Y]+=s.current[Y]*M,(Math.abs(I)>.3||Math.abs(s.current[Y])>4)&&(B=!0)}if(!B&&!m.current){c.current={...f.current},s.current={x:0,y:0},kl(o.current,c.current),d.current=0,E();return}kl(o.current,c.current),d.current=requestAnimationFrame(g)},[E]),b=(0,qe.useCallback)(S=>{if(f.current=S,ZE()){c.current={...S},s.current={x:0,y:0},kl(o.current,c.current),m.current||E();return}d.current||(x.current=performance.now(),d.current=requestAnimationFrame(g))},[E,g]),p=S=>{chrome.storage.local.set({[Gs]:S}).catch(()=>{})};(0,qe.useLayoutEffect)(()=>{if(!e)return;if(n){c.current={x:0,y:0},f.current={x:0,y:0},kl(o.current,c.current),E();return}let S=!0,M=A=>{if(!S)return;let H=A;u.current=typeof H?.x=="number"&&typeof H.y=="number";let B=H&&u.current?{x:H.x,y:H.y}:{x:(innerWidth-Qs(t.current).width)/2,y:lx};c.current=k(B),f.current={...c.current},s.current={x:0,y:0},kl(o.current,c.current),E()};return M(void 0),chrome.storage.local.get(Gs).then(A=>A[Gs]&&M(A[Gs])).catch(()=>{}),()=>{S=!1,cancelAnimationFrame(d.current),d.current=0,m.current=null}},[e,n,k,E,t]),(0,qe.useEffect)(()=>{if(!e)return;let S=()=>{if(n)return E();if(m.current)return;let A={x:(innerWidth-Qs(t.current).width)/2,y:lx};b(k(u.current?f.current:A))},M=new ResizeObserver(S);return t.current&&M.observe(t.current),addEventListener("resize",S),()=>{M.disconnect(),removeEventListener("resize",S)}},[e,n,k,b,E,t]);let v=S=>{S.button!==0||n||(S.preventDefault(),S.currentTarget.setPointerCapture(S.pointerId),u.current=!0,m.current={id:S.pointerId,x:S.clientX-c.current.x,y:S.clientY-c.current.y},l(!0))},h=S=>{let M=m.current;if(!M||M.id!==S.pointerId)return;let A={x:S.clientX-M.x,y:S.clientY-M.y},H=k(A);b({x:H.x+(A.x-H.x)*.25,y:H.y+(A.y-H.y)*.25})},T=S=>{let M=m.current;if(!M||M.id!==S.pointerId)return;m.current=null,l(!1);let A=k(f.current);b(A),p(A)};return{ref:o,rest:a,dragging:r,handle:{onPointerDown:v,onPointerMove:h,onPointerUp:T,onPointerCancel:T,onKeyDown:S=>{if(n)return;let M=S.shiftKey?cx*4:cx,H={ArrowLeft:{x:-M,y:0},ArrowRight:{x:M,y:0},ArrowUp:{x:0,y:-M},ArrowDown:{x:0,y:M}}[S.key];if(!H)return;S.preventDefault(),S.stopPropagation(),u.current=!0;let B=k({x:f.current.x+H.x,y:f.current.y+H.y});b(B),p(B)}}}}var Bt=_(_e());var PE=e=>e.replace(/^data:image\/\w+;base64,/,"");function dx(e,t){return{path:t,name:e?.name??t.split("/").pop()??t}}function fx(e){let[t,n]=(0,Bt.useState)(null),o=(0,Bt.useRef)(null),a=(0,Bt.useRef)(0),i=(0,Bt.useCallback)(d=>{o.current=d,n(d)},[]),r=(0,Bt.useCallback)(d=>{o.current&&i({...o.current,...d})},[i]),l=(0,Bt.useCallback)(async(d,x,k)=>{if(!d.length)return;let E=d.flatMap(v=>v.image?[v.image]:[]),g={title:x,detail:k,taken:d,images:E,projects:[],targets:[],harnesses:[]},b=++a.current,p=()=>a.current!==b||!o.current;if(e.projects){i({...g,status:{tone:"busy",text:"Saving\u2026"}});let v=await Le({type:"projects",url:location.href}),h=v.ok?v.projects??[]:[],T=v.ok?v.suggested??h[0]?.path:void 0;if(!T){if(p())return;i({...g,projects:h,status:{tone:"error",text:v.ok?"Not saved: no project. Open one in VS Code, or start an agent in agentmux.":v.error}});return}let w=await Promise.all(d.map(A=>A.image?B1(A.image):void 0)),S=await Le({type:"saveCapture",project:T,url:location.href,captures:d.map((A,H)=>({kind:A.kind,title:A.title,text:A.text,group:A.group,groupIndex:A.groupIndex,image:A.image?PE(A.image):void 0,thumb:w[H]}))});if(p())return;let M=h.find(A=>A.path===T);i({...g,project:dx(M,T),ids:S.ok?S.ids:void 0,projects:h,targets:M?.targets??[],defaultTarget:M?.defaultTarget,harnesses:M?.harnesses??[],status:S.ok?void 0:{tone:"error",text:S.error}});return}i({...g,empty:"Not linked: install the browser helper or link VS Code to send it to an agent."})},[e.projects,i]),c=(0,Bt.useCallback)(async(d,x)=>{let k=o.current;if(!k)return;let E=a.current;r({status:{tone:"busy",text:"Sending\u2026"}});let g=k.ids&&k.project?await Le({type:"sendSaved",project:k.project.path,ids:k.ids,target:d,open:x}):{ok:!1,error:"Not saved, so nothing can be sent."};if(!(a.current!==E||!o.current)){if(!g.ok){r({status:{tone:"error",text:g.error}});return}r({status:{tone:"ok",text:`Sent to ${g.sentTo??"the agent"}`}}),setTimeout(()=>{a.current===E&&o.current?.status?.tone==="ok"&&i(null)},900)}},[i,r]),s=(0,Bt.useCallback)(async d=>{let x=o.current;if(!x?.ids||!x.project||d===x.project.path)return;let k=a.current,E=await Le({type:"moveSaved",project:x.project.path,to:d,ids:x.ids});if(a.current!==k)return;if(!E.ok){r({status:{tone:"error",text:E.error}});return}let g=await Le({type:"projects",url:location.href});if(a.current!==k)return;let b=g.ok?g.projects??x.projects:x.projects,p=b.find(v=>v.path===d);r({project:dx(p,d),projects:b,targets:p?.targets??[],defaultTarget:p?.defaultTarget,harnesses:p?.harnesses??[],status:void 0})},[r]),f=(0,Bt.useCallback)(async()=>{let d=o.current;if(!d)return;let x=d.images[0]?await Ks(d.images[0]):await xl(d.taken.map(k=>k.text??"").join(`

`));r({status:x?{tone:"ok",text:"Copied"}:{tone:"error",text:"Could not copy"}})},[r]),m=(0,Bt.useCallback)(()=>{let d=o.current;if(d){if(d.images.length)for(let x of d.images)Le({type:"download",dataUrl:x,filename:`Inkspect/${Vp()}`});else{let x=d.taken.map(E=>E.text??"").join(`

`),k=`data:text/markdown;base64,${btoa(unescape(encodeURIComponent(x)))}`;Le({type:"download",dataUrl:k,filename:`Inkspect/${Vp().replace(/\.png$/,".md")}`})}r({status:{tone:"ok",text:"Downloading"}})}},[r]),u=(0,Bt.useCallback)(()=>{a.current++,i(null)},[i]);return{offer:t,capture:l,sendTo:c,moveTo:s,copyAgain:f,download:m,close:u}}var K=_(U()),$E=new Set(C1.map(e=>e.id)),Zs=" (not available in the responsive view yet)",JE=/\b(failed|could not|can't|cannot|did not|didn't|nothing was|not linked|not running)\b/i,IE={highlighter:{...za,color:"#ffd60a",width:16,opacity:.4},marker:{...za,width:8},pencil:{...za,width:2}},FE={area:"Drawing screenshot",groups:"Drawing screenshot",clean:"Drawing area",viewport:"Annotated viewport",fullPage:"Annotated full page"};function px({host:e,hideHost:t,toggleSignal:n}){let[o,a]=(0,D.useState)(!1),[i,r]=(0,D.useState)(null),[l,c]=(0,D.useState)(null),[s,f]=(0,D.useState)(null),[m,u]=(0,D.useState)(null),[d,x]=(0,D.useState)([]),[k,E]=(0,D.useState)({state:"offline"}),[g,b]=(0,D.useState)(!1),[p,v]=(0,D.useState)(()=>({map:Ss({},bl),overrides:{}})),[h,T]=(0,D.useState)(null),[w,S]=(0,D.useState)(!1),M=(0,D.useRef)(null),A=(0,D.useRef)(null),[H,B]=(0,D.useState)(null),[Y,I]=(0,D.useState)("fit"),[Ge,Re]=(0,D.useState)(null),[O,ue]=(0,D.useState)(J1),Te=(0,D.useRef)(null),Ce=(0,D.useRef)(null),[xt,Ie]=(0,D.useState)([]),[Lt,R]=(0,D.useState)([]),[j,G]=(0,D.useState)([]),[de,oe]=(0,D.useState)("pen"),[De,wt]=(0,D.useState)(IE),[Ps,Ut]=(0,D.useState)([]),[Gn,Qp]=(0,D.useState)(!0),[tr,yx]=(0,D.useState)({x:scrollX,y:scrollY}),[Wo,xx]=(0,D.useState)({width:innerWidth,height:innerHeight}),Qn=(0,D.useRef)(xt),[ja,wx]=(0,D.useState)(null),[kx,Zp]=(0,D.useState)(!1),[qa,Sx]=(0,D.useState)(()=>Gp(location.href)),[Sl,Ex]=(0,D.useState)(qa),[Pp,Tx]=(0,D.useState)(null);Sl!==qa&&(Ex(qa),Ie([]),R([]),G([]));let[,Cx]=(0,D.useState)(0),$p=(0,D.useRef)(null);(0,D.useEffect)(()=>{Qn.current=xt},[xt]),(0,D.useEffect)(()=>{let y=!1;return ix(qa).then(C=>{y||(Ie(z=>[...C,...z]),Tx(qa))}),()=>{y=!0}},[qa]),(0,D.useEffect)(()=>{Pp===Sl&&rx(Sl,xt)},[xt,Sl,Pp]),(0,D.useEffect)(()=>{let y=()=>Sx(Gp(location.href)),C=setInterval(y,500);window.addEventListener("popstate",y),window.addEventListener("hashchange",y),window.addEventListener("pagehide",wl);let z=0,L=Me=>{Me.target===document||!Qn.current.some(Nt=>Nt.anchor)||(cancelAnimationFrame(z),z=requestAnimationFrame(()=>Cx(Nt=>Nt+1)))};return document.addEventListener("scroll",L,{capture:!0,passive:!0}),()=>{clearInterval(C),cancelAnimationFrame(z),window.removeEventListener("popstate",y),window.removeEventListener("hashchange",y),window.removeEventListener("pagehide",wl),document.removeEventListener("scroll",L,{capture:!0})}},[]);let Jp=(0,D.useRef)(0);(0,D.useEffect)(()=>{n!==Jp.current&&(Jp.current=n,a(y=>(y&&(r(null),c(null),f(null),B(null),Re(null)),!y)))},[n]),(0,D.useEffect)(()=>{Le({type:"toolbarOpen",open:o})},[o]);let{ref:Nx,rest:gn,dragging:Ip,handle:Mx}=ux(o,M,H!==null),Ne=H!==null;(0,D.useEffect)(()=>{if(!Ne)return;let y=document.documentElement,C=y.style.getPropertyValue("overflow"),z=y.style.getPropertyPriority("overflow");return y.style.setProperty("overflow","hidden","important"),()=>{C?y.style.setProperty("overflow",C,z):y.style.removeProperty("overflow")}},[Ne]),(0,D.useEffect)(()=>R1((y,C)=>v({map:y,overrides:C.overrides})),[]),(0,D.useEffect)(()=>{if(!o)return;let y="",C=(Me=!1)=>{!Me&&location.href===y||(y=location.href,Le({type:"isBookmarked",url:y}).then(Nt=>Nt.ok&&S(!!Nt.bookmarked)))};C(!0);let z=setInterval(()=>C(),1e3),L=()=>C(!0);return addEventListener("focus",L),()=>{clearInterval(z),removeEventListener("focus",L)}},[o]);let ea=(0,D.useCallback)(y=>{let C=p.map[y]?.[0];return C?It(C,bl):void 0},[p.map]),ta=(y,C)=>{let z=ea(C);return z?`${y} (${z})`:y};(0,D.useEffect)(()=>{Yp().then(L=>Ce.current=L),Le({type:"bridgeStatus"}).then(L=>L.ok&&L.status&&E(L.status));let y=L=>{L.type==="bridgeStatus"&&L.status&&E(L.status)};chrome.runtime.onMessage.addListener(y);let C=()=>yx({x:scrollX,y:scrollY}),z=()=>xx({width:innerWidth,height:innerHeight});return window.addEventListener("scroll",C,{passive:!0}),window.addEventListener("resize",z),()=>{chrome.runtime.onMessage.removeListener(y),window.removeEventListener("scroll",C),window.removeEventListener("resize",z)}},[]);let Qe=(0,D.useCallback)((y,C={})=>{let z=C.tone??(JE.test(y)?"error":"info");u({id:Date.now(),message:y,...C,tone:z})},[]),$s=H?.userAgent,Fp=H?.touch??!1;(0,D.useEffect)(()=>{let y=Ne&&O.agent&&$s?{userAgent:$s,touch:Fp}:void 0,C=Ne?{agent:y,network:O.network,cpu:O.cpu,colorScheme:O.colorScheme,print:O.print}:{network:"none",cpu:1,colorScheme:"default",print:!1};Le({type:"emulate",request:C}).then(z=>{z.ok||Qe(z.error)})},[Ne,$s,Fp,O,Qe]);let Wp=(0,D.useCallback)(async()=>{r(null),c(z=>z==="console"?null:z),B(z=>z??Rs(Xi[0]));let y=location.href,C=await Le({type:"allowFraming",url:y});C.ok||Qe(`The page may not load in the frame: ${C.error}`),Re(y)},[Qe]),El=(0,D.useCallback)(()=>{B(null),Re(null),c(y=>y==="emulation"?null:y),Le({type:"endFraming"})},[]);(0,D.useEffect)(()=>{if(!m||m.held)return;let y=setTimeout(()=>u(C=>C?.id===m.id?null:C),m.tone==="error"?8e3:3500);return()=>clearTimeout(y)},[m]);let Tl=(0,D.useCallback)(()=>{let y=t();return b(!0),()=>{y(),b(!1)}},[t]),nr=(0,D.useCallback)(async y=>{let C=await _p(y,Tl),z=Gn?Qn.current:[];if(!z.length)return C.dataUrl;let L=new Uint8Array(await(await fetch(C.dataUrl)).arrayBuffer());return`data:image/png;base64,${await kp(L,"image/png",C.area,z,js(z))}`},[Gn,Tl]),Cl=k.state==="connected",{offer:mt,capture:Ya,sendTo:Ax,moveTo:zx,copyAgain:Ox,download:Rx,close:Dx}=fx(k),em=(0,D.useCallback)(async(y,C,z="text")=>{let L=await xl(y);await Ya([{kind:z,title:C,text:y}],C,L?"Copied to the clipboard.":void 0)},[Ya]),Zn=(0,D.useCallback)(async(y,C)=>{let z=typeof y=="string"?[y]:y;if(!z.length)return;let L=z.length>1,Me=await Ks(z[0]),Nt=L?crypto.randomUUID():void 0;await Ya(z.map((Wt,jt)=>({kind:"screenshot",title:L?`${C} ${jt+1} of ${z.length}`:C,image:Wt,group:Nt,groupIndex:L?jt:void 0})),L?`${z.length} ${C.toLowerCase()}`:C,Me?L?"The first is copied to the clipboard.":"Copied to the clipboard.":void 0)},[Ya]),go=(0,D.useCallback)(async y=>{if(y==="region")return r({kind:"region"});if(y==="element")return r({kind:"inspect",purpose:"screenshot"});try{let C=y==="viewport"?Hp():Bp();await Zn(await nr(C),y==="viewport"?"Screenshot":"Full-page screenshot")}catch(C){Qe(`Screenshot failed: ${C instanceof Error?C.message:String(C)}`)}},[Zn,nr,Qe]),tm=(0,D.useCallback)(async y=>{let C=Ce.current?.maxHtml??2e3;y.setAttribute(Rp,"");try{let z=await Ua({kind:"collect",maxHtml:C},1500);if(z&&!z.error&&z.tag)return z}finally{y.removeAttribute(Rp)}return{...by(y,C,hy),...Os(y)}},[]),Js=(0,D.useCallback)(async y=>{let C=y.getBoundingClientRect();return nr({x:C.x+scrollX,y:C.y+scrollY,width:C.width,height:C.height})},[nr]),_x=async y=>{let C=d;if(x([]),y!=="clear"){if(y==="copy")return Nl(C);try{let z=[];for(let L of C)z.push(await Js(L));await Zn(z,C.length===1?"Element screenshot":"Element screenshots")}catch(z){Qe(`Screenshot failed: ${z instanceof Error?z.message:String(z)}`)}}},Nl=(0,D.useCallback)(async y=>{let C=Ce.current??await Yp(),z=await Promise.all(y.map(tm)),L=z.length===1,Me=await xl(fp(z,C.copyFormat,C.fields)),Nt=L?void 0:crypto.randomUUID();await Ya(z.map((Wt,jt)=>({kind:"element",title:`Element ${dl(Wt)}`,text:fp([Wt],"markdown",C.fields),group:Nt,groupIndex:L?void 0:jt})),L?`Element ${dl(z[0])}`:`${z.length} elements`,Me?"Its details are copied to the clipboard.":void 0)},[tm,Ya]),Hx=(0,D.useCallback)(async(y,C)=>{let z=i?.kind==="inspect"&&i.purpose==="screenshot";if(z&&r(null),C.add&&!z){x(L=>L.includes(y)?L.filter(Me=>Me!==y):[...L,y]);return}if(z||C.screenshot){try{await Zn(await Js(y),"Element screenshot")}catch(L){Qe(`Screenshot failed: ${L instanceof Error?L.message:String(L)}`)}return}await Nl([y])},[Js,Nl,Zn,Qe,i]),nm=(0,D.useCallback)(async()=>{let y=await Ua({kind:"logs"});return My({url:location.href,title:document.title,viewport:{width:innerWidth,height:innerHeight},selection:getSelection()?.toString()||void 0,console:y?.console??[],network:y?.network??[]})},[]),Is=(0,D.useCallback)((y,C)=>{C&&(R(z=>[...z.slice(-99),Qn.current]),G([])),Ie(y)},[]),om=(0,D.useCallback)(()=>{R(y=>{let C=y.at(-1);return C?(G(z=>[...z,Qn.current]),Ie(C),y.slice(0,-1)):y})},[]),am=(0,D.useCallback)(()=>{G(y=>{let C=y.at(-1);return C?(R(z=>[...z,Qn.current]),Ie(C),y.slice(0,-1)):y})},[]),na=(0,D.useCallback)(async y=>{let C=js(Qn.current),z=As(Qn.current,C);if(!z.length&&(y==="area"||y==="groups"||y==="clean")){Qe("Draw something first.");return}let L=Ce.current?.annotationPadding??40,Me=new Map(Qn.current.map(jt=>[jt.id,jt])),Nt=y==="groups"?uy(z,80):[z],Wt=[];for(let jt of Nt){let pm=y==="viewport"?Hp():y==="fullPage"?Bp():sy(jt,L);if(pm)try{let Va=await _p(pm,Tl),Kx=new Uint8Array(await(await fetch(Va.dataUrl)).arrayBuffer()),Xx=await kp(Kx,"image/png",Va.area,y==="clean"?[]:jt.map(Gx=>Me.get(Gx.id)),C);Wt.push(`data:image/png;base64,${Xx}`)}catch(Va){Qe(`Screenshot failed: ${Va instanceof Error?Va.message:String(Va)}`);return}}await Zn(Wt,Wt.length>1?"Drawings":FE[y])},[Zn,Tl,Qe]),im=xt.some(y=>y.kind==="blur")||i?.kind==="draw"&&de==="blur",Fs=ja&&ja.x===tr.x&&ja.y===tr.y&&ja.width===Wo.width&&ja.height===Wo.height?ja.canvas:void 0;(0,D.useEffect)(()=>{if(!o||!im||Fs)return;let y=!1,C=setTimeout(()=>{let z={x:scrollX,y:scrollY,width:innerWidth,height:innerHeight};hl(()=>(Zp(!0),()=>Zp(!1))).then(L=>{if(y)return;let Me=document.createElement("canvas");Me.width=Math.round(z.width*devicePixelRatio),Me.height=Math.round(z.height*devicePixelRatio),Me.getContext("2d").drawImage(L,0,0,Me.width,Me.height),wx({canvas:Me,...z})}).catch(()=>{})},250);return()=>{y=!0,clearTimeout(C)}},[o,im,Fs,tr.x,tr.y,Wo.width,Wo.height]);let rm=i?.kind==="draw";(0,D.useEffect)(()=>{let y=$p.current;if(!rm||!y)return;let C=z=>{z.ctrlKey||(z.preventDefault(),j1(z,e))};return y.addEventListener("wheel",C,{passive:!1}),()=>y.removeEventListener("wheel",C)},[rm,e]);let Ml=y=>r(C=>C?.kind===y.kind?null:y),Bx=(y,C,z)=>{let L=y.currentTarget.getBoundingClientRect();f({x:L.left,y:L.bottom+4,items:C}),T(z??null)},lm=(y,C,z)=>{let L=M.current?.querySelector(y);if(!L)return;let Me=L.getBoundingClientRect();f({x:Me.left,y:Me.bottom+4,items:C}),T(z)},Ws=()=>{f(null),T(null)},or=y=>{let C=De[de]??za;wt(z=>({...z,[de]:{...C,...y}})),y.color&&Ut(z=>[y.color,...z.filter(L=>L!==y.color)].slice(0,6))},Lx=()=>{Le({type:"openSaved"}).then(y=>{y.ok||Qe(y.error,{tone:"error"})})},cm=()=>{Le(w?{type:"unbookmarkPage",url:location.href}:{type:"bookmarkPage",url:location.href,title:document.title}).then(y=>{if(!y.ok)return Qe(y.error,{tone:"error"});S(!!y.bookmarked),Qe(y.bookmarked?"Bookmarked":"Bookmark removed",y.bookmarked?{tone:"success",detail:Cl?"It syncs to VS Code.":void 0}:{})})},sm=()=>[{label:"Visible area",icon:"device-camera",shortcut:ea("shot.viewport"),onSelect:()=>{go("viewport")}},{label:"Full page",icon:"file-media",shortcut:ea("shot.fullPage"),onSelect:()=>{go("fullPage")}},{label:"Select region...",icon:"screen-full",shortcut:ea("shot.region"),onSelect:()=>{go("region")}},{label:"Select element...",icon:"inspect",shortcut:ea("shot.element"),onSelect:()=>{go("element")}}],um=()=>c1(y=>{na(y)},ea),dm=(0,D.useRef)({});if((0,D.useEffect)(()=>{let y=Object.fromEntries(r1.map(L=>[`draw.${L}`,()=>oe(L)])),C=Object.fromEntries(Vi.slice(0,9).map((L,Me)=>[`draw.color${Me+1}`,()=>or({color:L})])),z=De[de]?.width??za.width;dm.current={"mode.inspect":()=>!Ne&&Ml({kind:"inspect",purpose:"copy"}),"mode.draw":()=>!Ne&&Ml({kind:"draw"}),"mode.screenshot":()=>Ne?void 0:lm(".shot-button",sm(),"screenshot"),"mode.device":()=>Ne?El():void Wp(),"mode.devtools":()=>!Ne&&c(L=>L==="console"?null:"console"),"page.bookmark":cm,"open.shortcuts":()=>c(L=>L==="shortcuts"?null:"shortcuts"),...y,...C,"draw.thinner":()=>or({width:Math.max(1,z-(z>6?2:1))}),"draw.thicker":()=>or({width:Math.min(24,z+(z>=6?2:1))}),"draw.fill":()=>or({fill:!(De[de]?.fill??!1)}),"draw.undo":om,"draw.redo":am,"draw.clear":()=>Is([],!0),"draw.visible":()=>Qp(L=>!L),"draw.capture":()=>{na("area")},"draw.captureGroups":()=>{na("groups")},"draw.captureClean":()=>{na("clean")},"draw.captureViewport":()=>{na("viewport")},"draw.captureFullPage":()=>{na("fullPage")},"draw.captureMenu":()=>lm(".draw-capture",um(),"draw"),"draw.exit":()=>r(null),"shot.viewport":()=>{go("viewport")},"shot.fullPage":()=>{go("fullPage")},"shot.region":()=>{go("region")},"shot.element":()=>{go("element")},"shot.drawing":()=>{na("area")}}}),(0,D.useEffect)(()=>{if(l)return ys(()=>[A.current],vs(),()=>c(null),y=>!M.current||!y.composedPath().includes(M.current)||j0(y))},[l]),(0,D.useEffect)(()=>{if(!o)return;let y=C=>{if(l==="shortcuts"||mt)return;let z=M.current?.getRootNode(),L=C.composedPath().includes(e)&&z instanceof ShadowRoot?z.activeElement:C.composedPath()[0];if(L instanceof HTMLElement&&(L.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(L.tagName))||i?.kind==="inspect"||i?.kind==="region")return;if(C.key==="Escape"&&(s||l&&i?.kind!=="draw")){s?Ws():c(null),C.preventDefault(),C.stopImmediatePropagation();return}let Nt=s?h?[h]:[]:i?.kind==="draw"?["draw","global"]:["global"],Wt=sl(p.map,Nt,uo(C)),jt=Wt&&$E.has(Wt.id)&&dm.current[Wt.id];jt&&(C.preventDefault(),C.stopImmediatePropagation(),s&&Ws(),jt())};return window.addEventListener("keydown",y,!0),()=>window.removeEventListener("keydown",y,!0)},[o,i,l,s,h,p.map,e,mt]),!o)return null;let Ux=!!gn&&gn.x+gn.width/2>Wo.width/2,jx=!!gn&&gn.y+gn.height/2>Wo.height/2,qx=gn?Ne?gn.height:gn.y<64?gn.y+gn.height+8:0:0,Yx={scale:1,scroll:tr,bounds:{left:0,top:0,...Wo}},Vx=js(xt),fm=De[de]??za;return(0,K.jsxs)("div",{className:`inkspect${g?" capturing":""}${kx?" sampling":""}`,children:[(xt.length>0||i?.kind==="draw")&&(0,K.jsx)("div",{className:"draw-host",ref:$p,children:(0,K.jsx)(Py,{mapper:Yx,shapes:xt,visible:Gn,interactive:i?.kind==="draw",tool:de,style:fm,onChange:Is,liveRedactions:!0,pixelSource:Fs,anchors:Vx,anchorAt:y=>U1(y[0]-scrollX,y[1]-scrollY,e)})}),i?.kind==="inspect"&&!mt&&(0,K.jsx)(V1,{host:e,map:p.map,purpose:i.purpose,selection:d,onPick:(y,C)=>{Hx(y,C)},onCommit:y=>{let C=d.length?d:y?[y]:[];C.length&&Nl(C),x([])},onExit:()=>{r(null),x([])},actionOf:y=>sl(p.map,["inspect"],uo(y))?.id}),i?.kind==="inspect"&&!mt&&d.length>0&&(0,K.jsx)(d1,{className:"toolbar-selection-bar",count:d.length,map:p.map,onAction:y=>{_x(y)}}),i?.kind==="region"&&(0,K.jsx)(WE,{onCancel:()=>r(null),onDone:y=>{r(null),nr({...y,x:y.x+scrollX,y:y.y+scrollY}).then(C=>Zn(C,"Region screenshot")).catch(C=>Qe(`Screenshot failed: ${String(C)}`))}}),H&&(0,K.jsx)(ox,{top:qx,device:H,onDevice:B,zoom:Y,onZoom:I,src:Ge,frameRef:Te,emulationActive:l==="emulation",onEmulation:()=>c(y=>y==="emulation"?null:"emulation"),onClose:El}),(0,K.jsxs)("div",{ref:Nx,className:["float",Ne&&"docked",Ux&&"align-right",jx&&"above",Ip&&"dragging"].filter(Boolean).join(" "),children:[(0,K.jsxs)("div",{className:"bar",ref:M,role:"toolbar","aria-label":"Inkspect",children:[(0,K.jsxs)("div",{className:"bar-row",children:[(0,K.jsxs)("span",{className:"bar-brand",children:[(0,K.jsx)("img",{src:chrome.runtime.getURL("icons/32.png"),alt:""}),"Inkspect"]}),(0,K.jsx)("span",{className:"separator"}),(0,K.jsx)(Ee,{icon:"inspect",label:`${ta("Select an element to copy its details for AI","mode.inspect")}${Ne?Zs:""}`,disabled:Ne,active:i?.kind==="inspect",onClick:()=>Ml({kind:"inspect",purpose:"copy"})}),(0,K.jsx)(Ee,{icon:"edit",label:`${ta("Draw on the page","mode.draw")}${Ne?Zs:""}`,disabled:Ne,active:i?.kind==="draw",onClick:()=>Ml({kind:"draw"})}),(0,K.jsx)(Ee,{icon:"device-camera",label:ta("Screenshot","mode.screenshot"),className:"shot-button",onClick:y=>Bx(y,Ne?[{label:"Device screen",icon:"device-mobile",onSelect:()=>{let C=Te.current?.parentElement;C&&H1(C).then(z=>Zn(z,"Device screenshot")).catch(z=>Qe(`Screenshot failed: ${String(z)}`))}}]:sm(),Ne?void 0:"screenshot")}),(0,K.jsx)(Ee,{icon:"device-mobile",label:ta("Responsive view","mode.device"),active:Ne,onClick:()=>Ne?El():void Wp()}),(0,K.jsx)(Ee,{icon:"debug-console",label:`${ta("Console and network (copy errors for AI)","mode.devtools")}${Ne?Zs:""}`,disabled:Ne,active:l==="console",onClick:()=>c(y=>y==="console"?null:"console")}),(0,K.jsx)(Ee,{icon:"copy",label:`Copy page context for AI${Ne?Zs:""}`,disabled:Ne,onClick:()=>{nm().then(y=>em(y,"Page context","page"))}}),(0,K.jsx)(Ee,{icon:w?"star-full":"star-empty",label:ta(w?"Remove bookmark":"Bookmark this page","page.bookmark"),className:w?"bookmarked":void 0,onClick:cm}),(0,K.jsx)("span",{className:"separator"}),(0,K.jsx)(Xe,{size:"sm",variant:"ghost",icon:"layout-sidebar-right",className:"saved-button",title:"Saved captures of this page's project, in the side panel",onClick:Lx,children:"Saved"}),(0,K.jsx)("span",{className:"separator"}),(0,K.jsx)(Ee,{icon:"keyboard",label:ta("Keyboard shortcuts (shared with VS Code)","open.shortcuts"),active:l==="shortcuts",onClick:()=>c(y=>y==="shortcuts"?null:"shortcuts")}),(0,K.jsx)(Ee,{icon:Cl?"plug":"debug-disconnect",label:Cl?`Linked with ${k.peer??"VS Code"}`:"Link with VS Code",active:l==="link",className:`link-${k.state}`,onClick:()=>c(y=>y==="link"?null:"link")}),(0,K.jsx)(Ee,{icon:"close",label:"Close toolbar",onClick:()=>{El(),r(null),c(null),a(!1)}}),!Ne&&(0,K.jsx)(s1,{label:"Move the toolbar (drag, or use the arrow keys)",dragging:Ip,...Mx})]}),i?.kind==="draw"&&(0,K.jsx)(l1,{tool:de,style:fm,recentColors:Ps,canUndo:Lt.length>0,canRedo:j.length>0,hasShapes:xt.length>0,visible:Gn,onTool:oe,onStyle:or,keyOf:ea,onUndo:om,onRedo:am,onClear:()=>Is([],!0),onToggleVisible:()=>Qp(y=>!y),onCapture:(y,C)=>{f({x:y,y:C,items:um()}),T("draw")},onClose:()=>r(null)})]}),l&&(0,K.jsxs)("div",{className:"panel-dock",ref:A,children:[l==="emulation"&&(0,K.jsx)(I1,{onClose:()=>c(null),value:O,onChange:ue}),l==="console"&&(0,K.jsx)(F1,{onClose:()=>c(null),toast:Qe,copy:(y,C,z)=>{em(y,C,z)},pageContext:nm}),l==="shortcuts"&&(0,K.jsx)(ex,{onClose:()=>c(null),map:p.map,overrides:p.overrides,linked:Cl}),l==="link"&&(0,K.jsx)(W1,{onClose:()=>c(null),toast:Qe,status:k})]})]}),s&&(0,K.jsx)(Hs,{menu:s,onClose:Ws}),m&&(0,K.jsx)("div",{className:`toast tone-${m.tone??"info"}`,role:m.tone==="error"?"alert":"status",onPointerEnter:()=>u(y=>y?.id===m.id?{...y,held:!0}:y),onPointerLeave:()=>u(y=>y?.id===m.id?{...y,held:!1}:y),children:(0,K.jsxs)("div",{className:"toast-top",children:[m.tone!=="info"&&(0,K.jsx)("span",{className:`toast-icon codicon codicon-${m.tone==="error"?"error":"pass-filled"}`,"aria-hidden":"true"}),(0,K.jsxs)("div",{className:"toast-body",children:[(0,K.jsx)("div",{className:"toast-title",children:m.message}),m.detail&&(0,K.jsx)("div",{className:"toast-detail",children:m.detail})]}),(0,K.jsx)(Ee,{icon:"close",label:"Dismiss",className:"toast-close",onClick:()=>u(null)})]})},m.id),mt&&(0,K.jsx)(S1,{title:mt.title,detail:mt.detail,images:mt.images,project:mt.project,projects:mt.projects.map(y=>({path:y.path,name:y.name,detail:v1(y)})),onProject:mt.ids&&k.features?.includes("items.move")?y=>{zx(y)}:void 0,targets:mt.targets,defaultTarget:mt.defaultTarget,harnesses:mt.harnesses,emptyText:mt.empty,onSend:(y,{open:C})=>{Ax(y,C)},onCopy:()=>{Ox()},onDownload:Rx,onClose:Dx,status:mt.status,map:p.map})]})}function WE({onDone:e,onCancel:t}){let[n,o]=(0,D.useState)(null),a=(0,D.useRef)(null);return(0,D.useEffect)(()=>{let i=r=>{r.key==="Escape"&&t()};return window.addEventListener("keydown",i,!0),()=>window.removeEventListener("keydown",i,!0)},[t]),(0,K.jsxs)("div",{className:"region",onPointerDown:i=>{i.currentTarget.setPointerCapture(i.pointerId),a.current={x:i.clientX,y:i.clientY},o({x:i.clientX,y:i.clientY,width:0,height:0})},onPointerMove:i=>{let r=a.current;r&&o({x:Math.min(r.x,i.clientX),y:Math.min(r.y,i.clientY),width:Math.abs(i.clientX-r.x),height:Math.abs(i.clientY-r.y)})},onPointerUp:()=>{a.current=null,n&&n.width>4&&n.height>4&&e(n)},children:[(0,K.jsx)("div",{className:"inspect-hint",children:"Drag to select a region \xB7 Esc to cancel"}),n&&(0,K.jsx)("div",{className:"region-box",style:{left:n.x,top:n.y,width:n.width,height:n.height},children:(0,K.jsxs)("span",{className:"region-size",children:[Math.round(n.width)," \xD7 ",Math.round(n.height)]})})]})}var mx=`/* PairCard: linking this browser (one click in VS Code; the code is the fallback), on the full
   page, in the popup and in the toolbar. */

.pair-card {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 16px;
  padding: 24px;
}

.pair-lead {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin: 0;
  font-size: var(--ink-font-lg);
}

.pair-lead .codicon {
  margin-top: 3px;
  color: var(--ink-blue);
}

.pair-card kbd {
  padding: 1px 6px;
  border: 1px solid var(--vscode-keybindingLabel-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-keybindingLabel-background, var(--ink-surface-sunken));
  font-family: inherit;
  font-size: 0.92em;
  font-weight: 600;
  white-space: nowrap;
}

.pair-card > .muted {
  margin: 0;
}

.pair-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
}

.code-input {
  display: flex;
  align-items: center;
  gap: 8px;
}

.code-sep {
  width: 10px;
  height: 2px;
  margin: 0 2px;
  border-radius: 1px;
  background: var(--ink-border-strong);
}

.code-box {
  width: 46px;
  height: 56px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: 12px;
  outline: none;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font-family: var(--vscode-editor-font-family);
  font-size: 24px;
  font-weight: 600;
  text-align: center;
  caret-color: var(--ink-blue);
  transition:
    border-color var(--ink-fast) var(--ink-ease),
    box-shadow var(--ink-fast) var(--ink-ease);
}

.code-box:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
}

.code-box:focus {
  border-color: var(--ink-focus);
  box-shadow: 0 0 0 1px var(--ink-focus);
}

.code-box:disabled {
  opacity: 0.6;
}

.pair-button {
  height: 56px;
  padding: 0 26px;
  border-radius: 12px;
  font-weight: 600;
}

.pair-message {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin: 0;
  color: var(--ink-danger);
}

.pair-message .codicon {
  margin-top: 2px;
}

.card-foot {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  margin: 0;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.card-foot .codicon {
  margin-top: 2px;
}

/* The popup's and the toolbar's smaller card. */
.pair-card.compact {
  gap: 10px;
  padding: 12px;
}

.pair-card.compact .pair-lead {
  font-size: var(--ink-font-sm);
}

.pair-card.compact .code-box {
  width: 30px;
  height: 38px;
  border-radius: 8px;
  font-size: 18px;
}

.pair-card.compact .pair-button {
  height: 38px;
  padding: 0 14px;
  border-radius: 8px;
}

/* Where no page style gives it a surface (the popup, the toolbar). */
.pair-card.compact {
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--vscode-editorWidget-background);
}

.pair-card .muted {
  margin: 0;
  color: var(--ink-muted);
}
`;var gx=`/* The Inkspect toolbar. The shared components use VS Code theme variables, defined here in a
   dark and a light variant that follow the system theme. */

:host,
.inkspect {
  --vscode-font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  --vscode-font-size: 13px;
  --vscode-editor-font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
  --vscode-foreground: #cccccc;
  --vscode-descriptionForeground: #9d9d9d;
  --vscode-editor-background: #1f1f1f;
  --vscode-editorWidget-background: #202020;
  --vscode-widget-border: #3c3c3c;
  --vscode-widget-shadow: rgba(0, 0, 0, 0.45);
  --vscode-focusBorder: #0078d4;
  --vscode-button-background: #0078d4;
  --vscode-button-foreground: #ffffff;
  --vscode-button-hoverBackground: #026ec1;
  --vscode-button-secondaryBackground: #313131;
  --vscode-button-secondaryForeground: #cccccc;
  --vscode-button-secondaryHoverBackground: #3c3c3c;
  --vscode-toolbar-hoverBackground: rgba(90, 93, 94, 0.31);
  --vscode-toolbar-activeBackground: rgba(99, 102, 103, 0.31);
  --vscode-inputOption-activeBackground: rgba(36, 137, 219, 0.51);
  --vscode-inputOption-activeBorder: #2488db;
  --vscode-input-background: #313131;
  --vscode-input-foreground: #cccccc;
  --vscode-input-border: #3c3c3c;
  --vscode-menu-background: #1f1f1f;
  --vscode-menu-foreground: #cccccc;
  --vscode-menu-selectionBackground: #0078d4;
  --vscode-menu-selectionForeground: #ffffff;
  --vscode-menu-separatorBackground: #454545;
  --vscode-menu-border: #454545;
  --vscode-notifications-background: #1f1f1f;
  --vscode-notifications-foreground: #cccccc;
  --vscode-errorForeground: #f85149;
  --vscode-testing-iconPassed: #73c991;
  --vscode-badge-background: #616161;
  --vscode-badge-foreground: #f8f8f8;
  color-scheme: dark;
}

@media (prefers-color-scheme: light) {
  :host,
  .inkspect {
    --vscode-foreground: #3b3b3b;
    --vscode-descriptionForeground: #6f6f6f;
    --vscode-editor-background: #ffffff;
    --vscode-editorWidget-background: #f8f8f8;
    --vscode-widget-border: #d4d4d4;
    --vscode-widget-shadow: rgba(0, 0, 0, 0.16);
    --vscode-focusBorder: #005fb8;
    --vscode-button-background: #005fb8;
    --vscode-button-hoverBackground: #0258a8;
    --vscode-button-secondaryBackground: #e5e5e5;
    --vscode-button-secondaryForeground: #3b3b3b;
    --vscode-button-secondaryHoverBackground: #cccccc;
    --vscode-toolbar-hoverBackground: rgba(184, 184, 184, 0.31);
    --vscode-toolbar-activeBackground: rgba(166, 166, 166, 0.31);
    --vscode-inputOption-activeBackground: rgba(190, 195, 201, 0.51);
    --vscode-input-background: #ffffff;
    --vscode-input-foreground: #3b3b3b;
    --vscode-input-border: #cecece;
    --vscode-menu-background: #ffffff;
    --vscode-menu-foreground: #3b3b3b;
    --vscode-menu-selectionBackground: #005fb8;
    --vscode-menu-separatorBackground: #d4d4d4;
    --vscode-menu-border: #cecece;
    --vscode-notifications-background: #ffffff;
    --vscode-notifications-foreground: #3b3b3b;
    --vscode-errorForeground: #b3261e;
    --vscode-testing-iconPassed: #2e7d32;
    color-scheme: light;
  }
}

.inkspect {
  position: fixed;
  inset: 0;
  font-family: var(--vscode-font-family);
  font-size: var(--vscode-font-size);
  color: var(--vscode-foreground);
  pointer-events: none;
}

.inkspect *,
.inkspect *::before,
.inkspect *::after {
  box-sizing: border-box;
}

/* Everything interactive takes the pointer; the rest of the layer lets the page through. */
.bar,
.rv,
.panel-dock,
.toast,
.menu,
.ink-modal-backdrop,
/* Popups (select lists, color pickers) are portaled to the shadow root, outside .inkspect. */
[data-ink-popup],
.select-list,
.region,
.draw-host .drawing-layer {
  pointer-events: auto;
}

.inkspect.capturing * {
  visibility: hidden !important;
}

/* Capturing the page for redactions to pixelate: everything over the page steps aside for a
   moment, except the bar (there is only more of the bar under it). Transparent rather than
   hidden, so a drag that starts meanwhile still reaches the drawing layer. */
.inkspect.sampling .draw-host,
.inkspect.sampling .panel-dock,
.inkspect.sampling .toast,
.inkspect.sampling .ink-modal-backdrop,
.inkspect.sampling .menu {
  opacity: 0 !important;
}

/* The toolbar floats over the page (the page isn't moved), as wide as its buttons. Its handle
   drags it (useFloating.ts writes the position into the transform); panels hang off its side with
   more room. While drawing, the drawing tools add a second row. */
.float {
  position: fixed;
  top: 0;
  left: 0;
}

.bar {
  width: max-content;
  max-width: calc(100vw - 16px);
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-lg);
  background: var(--vscode-editorWidget-background);
  box-shadow: var(--ink-shadow-lg);
  user-select: none;
  animation: bar-in var(--ink-normal) var(--ink-ease);
  transition:
    box-shadow var(--ink-fast) var(--ink-ease),
    scale var(--ink-fast) var(--ink-ease);
}

/* Lifted while dragged. */
/* Docked across the top while the responsive view is open (it can't be moved then). */
.float.docked {
  right: 0;
}

.float.docked .bar {
  width: auto;
  max-width: none;
  border-width: 0 0 1px;
  border-radius: 0;
  box-shadow: none;
  animation: none;
}

.float.docked .bar-row {
  justify-content: center;
}

.float.dragging .bar {
  scale: 1.02;
  box-shadow:
    var(--ink-shadow-lg),
    0 16px 40px color-mix(in srgb, #000 30%, transparent);
}

.bar-row {
  display: flex;
  align-items: center;
  gap: 2px;
  height: 40px;
  padding: 0 4px 0 8px;
}

.bar-brand {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 8px;
  padding: 0 4px;
  font-weight: 600;
}

.bar-brand img {
  width: 18px;
  height: 18px;
  border-radius: 4px;
}

.saved-button {
  flex-shrink: 0;
}

/* The drawing tools: the bar's second row. */
.bar .draw-toolbar {
  justify-content: center;
  border-top: 1px solid var(--ink-border-subtle);
  border-bottom: none;
  border-radius: 0 0 var(--ink-radius-lg) var(--ink-radius-lg);
  background: transparent;
}

@keyframes bar-in {
  from {
    opacity: 0;
    scale: 0.96;
  }
}

@media (prefers-reduced-motion: reduce) {
  .bar {
    animation: none;
    transition: none;
  }
}

.separator {
  width: 1px;
  height: 18px;
  margin: 0 4px;
  background: var(--vscode-widget-border);
}

.bookmarked .codicon {
  color: var(--ink-blue);
}

.link-connected .codicon {
  color: var(--vscode-testing-iconPassed);
}

.link-offline .codicon,
.link-unpaired .codicon {
  color: var(--vscode-descriptionForeground);
}

.draw-host {
  position: fixed;
  inset: 0;
}

.menu {
  position: fixed;
}

/* Toast ------------------------------------------------------------------------------------ */

.inkspect .toast {
  position: fixed;
  top: auto;
  right: 16px;
  bottom: 16px;
  left: auto;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 0;
  width: min(460px, calc(100vw - 32px));
  max-width: none;
  padding: 0;
  overflow: hidden;
  transform: none;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-lg);
  background: var(--vscode-editorWidget-background);
  color: var(--vscode-foreground);
  box-shadow: var(--ink-shadow-lg);
  animation: toast-in var(--ink-normal) var(--ink-ease);
}

.inkspect .toast.tone-error {
  border-color: color-mix(in srgb, var(--ink-danger) 45%, var(--ink-border-strong));
}

.toast-top {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  padding: 14px 10px 14px 14px;
}

.toast-icon {
  flex-shrink: 0;
  margin-top: 1px;
  font-size: 18px !important;
}

.tone-success .toast-icon {
  color: var(--vscode-testing-iconPassed);
}

.tone-error .toast-icon {
  color: var(--ink-danger);
}

.toast-body {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  padding-top: 2px;
}

.toast-title {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: var(--ink-font-lg);
  font-weight: 600;
  line-height: 1.3;
  overflow-wrap: anywhere;
}

.toast-detail {
  color: var(--ink-muted);
  overflow-wrap: anywhere;
}

.toast-close {
  flex-shrink: 0;
  margin-top: -2px;
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
}

/* Panels ------------------------------------------------------------------------------------ */

.panel-dock {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  width: 370px;
  max-width: calc(100vw - 16px);
}

.float.align-right .panel-dock {
  right: 0;
  left: auto;
}

.float.above .panel-dock {
  top: auto;
  bottom: calc(100% + 8px);
}

.panel {
  border: 1px solid var(--vscode-widget-border);
  border-radius: 8px;
  background: var(--vscode-editorWidget-background);
  box-shadow: 0 8px 24px var(--vscode-widget-shadow);
}

.panel-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 6px 6px 12px;
  border-bottom: 1px solid var(--vscode-widget-border);
  font-weight: 600;
}

.panel-body {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: min(70vh, 560px);
  padding: 12px;
  overflow: auto;
}

.row {
  display: flex;
  align-items: flex-end;
  gap: 8px;
}

.field {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 4px;
  color: var(--vscode-descriptionForeground);
  font-size: 12px;
}

.field select,
.field input {
  height: 26px;
  padding: 0 6px;
  border: 1px solid var(--vscode-input-border);
  border-radius: 4px;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font: inherit;
  font-size: 13px;
}

.check {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
}

.note {
  margin: 0;
  color: var(--vscode-descriptionForeground);
  font-size: 12px;
}

.note.error,
.status-offline {
  color: var(--vscode-errorForeground);
}

.status {
  margin: 0;
}

.status-connected {
  color: var(--vscode-testing-iconPassed);
}

.button-row.wrap {
  flex-wrap: wrap;
}

/* A labelled group of actions in a panel ("Copy for AI", "Send ... to VS Code"). */
.panel-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding-top: 12px;
  border-top: 1px solid var(--ink-border-subtle);
}

.panel-group-title {
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
  font-weight: 600;
}

/* Console and network. */
.console-tabs {
  display: flex;
  align-items: center;
  gap: 6px;
}

.console-view {
  flex: 1;
}

.console-view .segment {
  flex: 1;
}

.log {
  min-height: 120px;
  max-height: 280px;
  overflow-x: hidden;
  overflow-y: auto;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  font-family: var(--vscode-editor-font-family);
  font-size: var(--ink-font-sm);
}

.log-row {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 5px 8px;
  border-bottom: 1px solid var(--ink-border-subtle);
}

.log-row:last-child {
  border-bottom: none;
}

.log-icon {
  flex-shrink: 0;
  margin-top: 2px;
  color: var(--ink-muted);
  font-size: 12px !important;
}

.log-row.level-error {
  background: color-mix(in srgb, var(--ink-danger) 8%, transparent);
  color: var(--ink-danger);
}

.log-row.level-error .log-icon {
  color: var(--ink-danger);
}

.log-row.level-warning {
  background: color-mix(in srgb, var(--ink-yellow) 8%, transparent);
  color: var(--ink-yellow);
}

.log-row.level-warning .log-icon {
  color: var(--ink-yellow);
}

.log-text {
  flex: 1;
  min-width: 0;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.log-source {
  /* Long file names are cut, never the message. */
  max-width: 35%;
  overflow: hidden;
  color: var(--ink-muted);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.log-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  min-height: 118px;
  padding: 16px;
  color: var(--ink-muted);
  font-family: var(--vscode-font-family);
  text-align: center;
}

.log-empty .codicon {
  margin-bottom: 4px;
  color: var(--ink-green);
  font-size: 20px !important;
}

.log-empty strong {
  color: var(--vscode-foreground);
  font-weight: 600;
}

/* Element inspector (DevTools colors) ------------------------------------------------------- */

/* The picker's hint (PickerHint, styled in @inkspect/shared/ui): centered at the bottom. */
.inspect-hint {
  position: fixed;
  left: 50%;
  bottom: 16px;
  max-width: calc(100vw - 32px);
  transform: translateX(-50%);
}

.hl {
  position: fixed;
  pointer-events: none;
}

/* DevTools' box-model colors, lighter so the element's text stays readable, plus an outline. */
.hl-margin {
  background: rgba(246, 178, 107, 0.4);
}

.hl-border {
  background: rgba(255, 229, 153, 0.5);
}

.hl-padding {
  background: rgba(147, 196, 125, 0.4);
}

.hl-content {
  background: rgba(111, 168, 220, 0.4);
}

.hl-outline {
  box-shadow:
    0 0 0 2px #0a84ff,
    0 0 0 3px rgba(255, 255, 255, 0.85);
}

.selection-box {
  position: fixed;
  border: 2px solid #0078d4;
  pointer-events: none;
}

.selection-badge {
  position: absolute;
  top: -10px;
  left: -10px;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 10px;
  background: #0078d4;
  color: #fff;
  font-size: 12px;
  line-height: 20px;
  text-align: center;
}

/* Chrome's inspect tooltip: always light, like in DevTools. */
.tip {
  position: fixed;
  padding: 8px 10px;
  border-radius: 4px;
  background: #fff;
  color: #303942;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
  font:
    12px system-ui,
    sans-serif;
  pointer-events: none;
}

.tip-head {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 6px;
  font-weight: 600;
}

.tip-tag {
  color: #881280;
}

.tip-id,
.tip-class {
  color: #1a1aa6;
}

.tip-size {
  flex-shrink: 0;
  color: #5f6368;
  font-weight: 400;
}

.tip-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 1px 0;
  color: #5f6368;
}

.tip-row > span:last-child {
  color: #303942;
  text-align: right;
  overflow-wrap: anywhere;
}

.tip-value {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.tip-swatch {
  display: inline-block;
  width: 10px;
  height: 10px;
  border: 1px solid #ccc;
}

.tip-section {
  margin: 6px 0 2px;
  padding-top: 6px;
  border-top: 1px solid #e0e0e0;
  color: #5f6368;
  font-size: 10px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
}

.tip-aa {
  padding: 0 3px;
  border: 1px solid #ccc;
}

.ok {
  color: #188038 !important;
}

.bad {
  color: #d93025 !important;
}

/* Region selection --------------------------------------------------------------------------- */

.region {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.25);
  cursor: crosshair;
}

.region-box {
  position: fixed;
  border: 1px dashed #fff;
  outline: 1px dashed rgba(0, 0, 0, 0.6);
  box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.35);
}

.region-size {
  position: absolute;
  top: -22px;
  left: 0;
  padding: 1px 6px;
  border-radius: 3px;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  font-size: 11px;
}

/* Responsive view --------------------------------------------------------------------------- */

/* Covers the page below the bar; the page shows in a device-sized frame, centered. */
.rv {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  display: flex;
  flex-direction: column;
  background: color-mix(in srgb, var(--vscode-foreground) 6%, var(--vscode-editor-background));
}

.rv-controls {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 6px 12px;
  border-bottom: 1px solid var(--ink-border-subtle);
  background: var(--vscode-editorWidget-background);
}

.rv-device {
  width: 200px;
}

.rv-size {
  width: 64px;
}

.rv-size input {
  text-align: center;
  font-variant-numeric: tabular-nums;
}

.rv-zoom {
  width: 84px;
}

.rv-times {
  color: var(--ink-muted);
}

.rv-divider {
  width: 1px;
  height: 18px;
  margin: 0 4px;
  background: var(--ink-border-subtle);
}

.rv-area {
  flex: 1;
  min-height: 0;
  overflow: auto;
}

/* Centered while it fits; scrolls from its top-left corner when zoomed in beyond the area. */
.rv-stage {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 22px;
  min-width: 100%;
  min-height: 100%;
  width: max-content;
  padding: 24px 32px;
}

.rv-screen {
  position: relative;
  flex-shrink: 0;
  overflow: hidden;
  border-radius: 6px;
  background: #fff;
  box-shadow:
    0 0 0 1px var(--ink-border-strong),
    var(--ink-shadow-lg);
}

.rv-screen iframe {
  display: block;
  border: 0;
  transform-origin: 0 0;
  background: #fff;
}

/* The screen and its resize handles (right edge, bottom edge, corner), like DevTools'. */
.rv-frame {
  position: relative;
  flex-shrink: 0;
}

.rv-handle {
  position: absolute;
  z-index: 1;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--vscode-foreground) 28%, transparent);
  touch-action: none;
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.rv-handle:hover,
.rv.dragging .rv-handle {
  background: var(--ink-blue);
}

.rv-handle-x {
  top: 50%;
  right: -14px;
  width: 6px;
  height: 44px;
  transform: translateY(-50%);
  cursor: ew-resize;
}

.rv-handle-y {
  bottom: -14px;
  left: 50%;
  width: 44px;
  height: 6px;
  transform: translateX(-50%);
  cursor: ns-resize;
}

.rv-handle-xy {
  right: -14px;
  bottom: -14px;
  width: 12px;
  height: 12px;
  border-radius: 3px;
  cursor: nwse-resize;
}

/* The frame would take the pointer from the handle mid-drag. */
.rv.dragging iframe {
  pointer-events: none;
}

.rv.dragging {
  user-select: none;
}

.rv-caption {
  height: 14px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  font-variant-numeric: tabular-nums;
}

@media (prefers-reduced-motion: reduce) {
  .bar,
  .inkspect .toast {
    animation: none;
  }
}

/* The shortcuts panel. */
.shortcuts-bar {
  display: flex;
  align-items: center;
  gap: 6px;
}

.shortcuts-bar .text-field {
  flex: 1;
}

/* Group headers pin to the panel's top edge (sticky stops at the padding otherwise, leaving a
   strip where rows show through). */
.panel-body .shortcut-list {
  --shortcut-sticky-top: -12px;
}

.panel-body .group-header {
  background: var(--vscode-editorWidget-background);
}

.shortcuts-sync {
  display: flex;
  gap: 6px;
}

.shortcuts-sync .codicon {
  flex-shrink: 0;
  margin-top: 1px;
}

/* The bar over a Shift+click selection (SelectionBar), just above the picker's hint. */
.toolbar-selection-bar {
  position: fixed;
  left: 50%;
  bottom: 92px;
  transform: translateX(-50%);
}
`;var vx=_(U());async function nT(){try{let e=await(await fetch(chrome.runtime.getURL("codicon.ttf"))).arrayBuffer(),t=new FontFace("codicon",e);await t.load(),document.fonts.add(t)}catch{}}function oT(){let e=document.createElement("inkspect-toolbar");e.style.cssText="all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none; display: block;";let t=e.attachShadow({mode:"closed"});U0(t);let n=document.createElement("style");n.textContent=[gm.replace(/@font-face\s*{[^}]*}/g,""),bm,mx,gx].join(`
`);let o=document.createElement("div");t.append(n,o),document.documentElement.appendChild(e),nT();let a=(0,hx.createRoot)(o),i=()=>(e.style.visibility="hidden",()=>{e.style.visibility=""});return r=>{e.isConnected||document.documentElement.appendChild(e),a.render((0,vx.jsx)(px,{host:e,hideHost:i,toggleSignal:r}))}}var bx=window;if(!bx.__inkspect){bx.__inkspect=!0;let e,t=0;chrome.runtime.onMessage.addListener(n=>{n.type==="toggle"&&(n.key&&ty(n.key)||(e??=oT(),e(++t)))})}})();
