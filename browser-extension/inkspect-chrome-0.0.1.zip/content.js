"use strict";(()=>{var gx=Object.create;var Pp=Object.defineProperty;var bx=Object.getOwnPropertyDescriptor;var hx=Object.getOwnPropertyNames;var vx=Object.getPrototypeOf,yx=Object.prototype.hasOwnProperty;var bn=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports}catch(n){throw t=0,n}};var xx=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of hx(t))!yx.call(e,a)&&a!==n&&Pp(e,a,{get:()=>t[a],enumerable:!(o=bx(t,a))||o.enumerable});return e};var R=(e,t,n)=>(n=e!=null?gx(vx(e)):{},xx(t||!e||!e.__esModule?Pp(n,"default",{value:e,enumerable:!0}):n,e));var rm=bn(Te=>{"use strict";function Zs(e,t){var n=e.length;e.push(t);e:for(;0<n;){var o=n-1>>>1,a=e[o];if(0<xl(a,t))e[o]=t,e[n]=a,n=o;else break e}}function hn(e){return e.length===0?null:e[0]}function wl(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;e:for(var o=0,a=e.length,i=a>>>1;o<i;){var r=2*(o+1)-1,l=e[r],c=r+1,s=e[c];if(0>xl(l,n))c<a&&0>xl(s,l)?(e[o]=s,e[c]=n,o=c):(e[o]=l,e[r]=n,o=r);else if(c<a&&0>xl(s,n))e[o]=s,e[c]=n,o=c;else break e}}return t}function xl(e,t){var n=e.sortIndex-t.sortIndex;return n!==0?n:e.id-t.id}Te.unstable_now=void 0;typeof performance=="object"&&typeof performance.now=="function"?(Ip=performance,Te.unstable_now=function(){return Ip.now()}):(Xs=Date,Fp=Xs.now(),Te.unstable_now=function(){return Xs.now()-Fp});var Ip,Xs,Fp,Un=[],io=[],Sx=1,Xt=null,lt=3,Ps=!1,Ii=!1,Fi=!1,$s=!1,tm=typeof setTimeout=="function"?setTimeout:null,nm=typeof clearTimeout=="function"?clearTimeout:null,Wp=typeof setImmediate<"u"?setImmediate:null;function kl(e){for(var t=hn(io);t!==null;){if(t.callback===null)wl(io);else if(t.startTime<=e)wl(io),t.sortIndex=t.expirationTime,Zs(Un,t);else break;t=hn(io)}}function Js(e){if(Fi=!1,kl(e),!Ii)if(hn(Un)!==null)Ii=!0,Ba||(Ba=!0,Ha());else{var t=hn(io);t!==null&&Is(Js,t.startTime-e)}}var Ba=!1,Wi=-1,om=5,am=-1;function im(){return $s?!0:!(Te.unstable_now()-am<om)}function Gs(){if($s=!1,Ba){var e=Te.unstable_now();am=e;var t=!0;try{e:{Ii=!1,Fi&&(Fi=!1,nm(Wi),Wi=-1),Ps=!0;var n=lt;try{t:{for(kl(e),Xt=hn(Un);Xt!==null&&!(Xt.expirationTime>e&&im());){var o=Xt.callback;if(typeof o=="function"){Xt.callback=null,lt=Xt.priorityLevel;var a=o(Xt.expirationTime<=e);if(e=Te.unstable_now(),typeof a=="function"){Xt.callback=a,kl(e),t=!0;break t}Xt===hn(Un)&&wl(Un),kl(e)}else wl(Un);Xt=hn(Un)}if(Xt!==null)t=!0;else{var i=hn(io);i!==null&&Is(Js,i.startTime-e),t=!1}}break e}finally{Xt=null,lt=n,Ps=!1}t=void 0}}finally{t?Ha():Ba=!1}}}var Ha;typeof Wp=="function"?Ha=function(){Wp(Gs)}:typeof MessageChannel<"u"?(Qs=new MessageChannel,em=Qs.port2,Qs.port1.onmessage=Gs,Ha=function(){em.postMessage(null)}):Ha=function(){tm(Gs,0)};var Qs,em;function Is(e,t){Wi=tm(function(){e(Te.unstable_now())},t)}Te.unstable_IdlePriority=5;Te.unstable_ImmediatePriority=1;Te.unstable_LowPriority=4;Te.unstable_NormalPriority=3;Te.unstable_Profiling=null;Te.unstable_UserBlockingPriority=2;Te.unstable_cancelCallback=function(e){e.callback=null};Te.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):om=0<e?Math.floor(1e3/e):5};Te.unstable_getCurrentPriorityLevel=function(){return lt};Te.unstable_next=function(e){switch(lt){case 1:case 2:case 3:var t=3;break;default:t=lt}var n=lt;lt=t;try{return e()}finally{lt=n}};Te.unstable_requestPaint=function(){$s=!0};Te.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=lt;lt=e;try{return t()}finally{lt=n}};Te.unstable_scheduleCallback=function(e,t,n){var o=Te.unstable_now();switch(typeof n=="object"&&n!==null?(n=n.delay,n=typeof n=="number"&&0<n?o+n:o):n=o,e){case 1:var a=-1;break;case 2:a=250;break;case 5:a=1073741823;break;case 4:a=1e4;break;default:a=5e3}return a=n+a,e={id:Sx++,callback:t,priorityLevel:e,startTime:n,expirationTime:a,sortIndex:-1},n>o?(e.sortIndex=n,Zs(io,e),hn(Un)===null&&e===hn(io)&&(Fi?(nm(Wi),Wi=-1):Fi=!0,Is(Js,n-o))):(e.sortIndex=a,Zs(Un,e),Ii||Ps||(Ii=!0,Ba||(Ba=!0,Ha()))),e};Te.unstable_shouldYield=im;Te.unstable_wrapCallback=function(e){var t=lt;return function(){var n=lt;lt=t;try{return e.apply(this,arguments)}finally{lt=n}}}});var cm=bn((CE,lm)=>{"use strict";lm.exports=rm()});var km=bn(K=>{"use strict";var eu=Symbol.for("react.transitional.element"),Ex=Symbol.for("react.portal"),Tx=Symbol.for("react.fragment"),Cx=Symbol.for("react.strict_mode"),Nx=Symbol.for("react.profiler"),Mx=Symbol.for("react.consumer"),Ax=Symbol.for("react.context"),zx=Symbol.for("react.forward_ref"),Ox=Symbol.for("react.suspense"),Rx=Symbol.for("react.memo"),pm=Symbol.for("react.lazy"),Dx=Symbol.for("react.activity"),_x=Symbol.for("react.view_transition"),sm=Symbol.iterator;function Hx(e){return e===null||typeof e!="object"?null:(e=sm&&e[sm]||e["@@iterator"],typeof e=="function"?e:null)}var mm={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},gm=Object.assign,bm={};function Ua(e,t,n){this.props=e,this.context=t,this.refs=bm,this.updater=n||mm}Ua.prototype.isReactComponent={};Ua.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};Ua.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function hm(){}hm.prototype=Ua.prototype;function tu(e,t,n){this.props=e,this.context=t,this.refs=bm,this.updater=n||mm}var nu=tu.prototype=new hm;nu.constructor=tu;gm(nu,Ua.prototype);nu.isPureReactComponent=!0;var um=Array.isArray;function Ws(){}var ye={H:null,A:null,T:null,S:null},vm=Object.prototype.hasOwnProperty;function ou(e,t,n){var o=n.ref;return{$$typeof:eu,type:e,key:t,ref:o!==void 0?o:null,props:n}}function Bx(e,t){return ou(e.type,t,e.props)}function au(e){return typeof e=="object"&&e!==null&&e.$$typeof===eu}function Lx(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var dm=/\/+/g;function Fs(e,t){return typeof e=="object"&&e!==null&&e.key!=null?Lx(""+e.key):t.toString(36)}function Ux(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(Ws,Ws):(e.status="pending",e.then(function(t){e.status==="pending"&&(e.status="fulfilled",e.value=t)},function(t){e.status==="pending"&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function La(e,t,n,o,a){var i=typeof e;(i==="undefined"||i==="boolean")&&(e=null);var r=!1;if(e===null)r=!0;else switch(i){case"bigint":case"string":case"number":r=!0;break;case"object":switch(e.$$typeof){case eu:case Ex:r=!0;break;case pm:return r=e._init,La(r(e._payload),t,n,o,a)}}if(r)return a=a(e),r=o===""?"."+Fs(e,0):o,um(a)?(n="",r!=null&&(n=r.replace(dm,"$&/")+"/"),La(a,t,n,"",function(s){return s})):a!=null&&(au(a)&&(a=Bx(a,n+(a.key==null||e&&e.key===a.key?"":(""+a.key).replace(dm,"$&/")+"/")+r)),t.push(a)),1;r=0;var l=o===""?".":o+":";if(um(e))for(var c=0;c<e.length;c++)o=e[c],i=l+Fs(o,c),r+=La(o,t,n,i,a);else if(c=Hx(e),typeof c=="function")for(e=c.call(e),c=0;!(o=e.next()).done;)o=o.value,i=l+Fs(o,c++),r+=La(o,t,n,i,a);else if(i==="object"){if(typeof e.then=="function")return La(Ux(e),t,n,o,a);throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return r}function Sl(e,t,n){if(e==null)return e;var o=[],a=0;return La(e,o,"","",function(i){return t.call(n,i,a++)}),o}function jx(e){if(e._status===-1){var t=e._result,n=t();n.then(function(o){(e._status===0||e._status===-1)&&(e._status=1,e._result=o,n.status===void 0&&(n.status="fulfilled",n.value=o))},function(o){(e._status===0||e._status===-1)&&(e._status=2,e._result=o,n.status===void 0&&(n.status="rejected",n.reason=o))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var fm=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)};function ym(e){var t=ye.T,n={};n.types=t!==null?t.types:null,ye.T=n;try{var o=e(),a=ye.S;a!==null&&a(n,o),typeof o=="object"&&o!==null&&typeof o.then=="function"&&o.then(Ws,fm)}catch(i){fm(i)}finally{t!==null&&n.types!==null&&(t.types=n.types),ye.T=t}}function xm(e){var t=ye.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else ym(xm.bind(null,e))}var qx={map:Sl,forEach:function(e,t,n){Sl(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return Sl(e,function(){t++}),t},toArray:function(e){return Sl(e,function(t){return t})||[]},only:function(e){if(!au(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};K.Activity=Dx;K.Children=qx;K.Component=Ua;K.Fragment=Tx;K.Profiler=Nx;K.PureComponent=tu;K.StrictMode=Cx;K.Suspense=Ox;K.ViewTransition=_x;K.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=ye;K.__COMPILER_RUNTIME={__proto__:null,c:function(e){return ye.H.useMemoCache(e)}};K.addTransitionType=xm;K.cache=function(e){return function(){return e.apply(null,arguments)}};K.cacheSignal=function(){return null};K.cloneElement=function(e,t,n){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var o=gm({},e.props),a=e.key;if(t!=null)for(i in t.key!==void 0&&(a=""+t.key),t)!vm.call(t,i)||i==="key"||i==="__self"||i==="__source"||i==="ref"&&t.ref===void 0||(o[i]=t[i]);var i=arguments.length-2;if(i===1)o.children=n;else if(1<i){for(var r=Array(i),l=0;l<i;l++)r[l]=arguments[l+2];o.children=r}return ou(e.type,a,o)};K.createContext=function(e){return e={$$typeof:Ax,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:Mx,_context:e},e};K.createElement=function(e,t,n){var o,a={},i=null;if(t!=null)for(o in t.key!==void 0&&(i=""+t.key),t)vm.call(t,o)&&o!=="key"&&o!=="__self"&&o!=="__source"&&(a[o]=t[o]);var r=arguments.length-2;if(r===1)a.children=n;else if(1<r){for(var l=Array(r),c=0;c<r;c++)l[c]=arguments[c+2];a.children=l}if(e&&e.defaultProps)for(o in r=e.defaultProps,r)a[o]===void 0&&(a[o]=r[o]);return ou(e,i,a)};K.createRef=function(){return{current:null}};K.forwardRef=function(e){return{$$typeof:zx,render:e}};K.isValidElement=au;K.lazy=function(e){return{$$typeof:pm,_payload:{_status:-1,_result:e},_init:jx}};K.memo=function(e,t){return{$$typeof:Rx,type:e,compare:t===void 0?null:t}};K.startTransition=ym;K.unstable_useCacheRefresh=function(){return ye.H.useCacheRefresh()};K.use=function(e){return ye.H.use(e)};K.useActionState=function(e,t,n){return ye.H.useActionState(e,t,n)};K.useCallback=function(e,t){return ye.H.useCallback(e,t)};K.useContext=function(e){return ye.H.useContext(e)};K.useDebugValue=function(){};K.useDeferredValue=function(e,t){return ye.H.useDeferredValue(e,t)};K.useEffect=function(e,t){return ye.H.useEffect(e,t)};K.useEffectEvent=function(e){return ye.H.useEffectEvent(e)};K.useId=function(){return ye.H.useId()};K.useImperativeHandle=function(e,t,n){return ye.H.useImperativeHandle(e,t,n)};K.useInsertionEffect=function(e,t){return ye.H.useInsertionEffect(e,t)};K.useLayoutEffect=function(e,t){return ye.H.useLayoutEffect(e,t)};K.useMemo=function(e,t){return ye.H.useMemo(e,t)};K.useOptimistic=function(e,t){return ye.H.useOptimistic(e,t)};K.useReducer=function(e,t,n){return ye.H.useReducer(e,t,n)};K.useRef=function(e){return ye.H.useRef(e)};K.useState=function(e){return ye.H.useState(e)};K.useSyncExternalStore=function(e,t,n){return ye.H.useSyncExternalStore(e,t,n)};K.useTransition=function(){return ye.H.useTransition()};K.version="19.3.0"});var Ae=bn((ME,wm)=>{"use strict";wm.exports=km()});var Tm=bn(ct=>{"use strict";var Yx=Ae();function Em(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function ro(){}var ft={d:{f:ro,r:function(){throw Error(Em(522))},D:ro,C:ro,L:ro,m:ro,X:ro,S:ro,M:ro},p:0,findDOMNode:null},Vx=Symbol.for("react.portal"),Kx=Symbol.for("react.recoverable"),Sm=Symbol.for("react.optimistic_key");function Xx(e,t,n){var o=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Vx,key:o==null?null:o===Sm?Sm:""+o,children:e,containerInfo:t,implementation:n}}var er=Yx.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function El(e,t){if(e==="font")return"";if(typeof t=="string")return t==="use-credentials"?t:""}ct.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=ft;ct.browser=function(e){return{$$typeof:Kx,_reason:e}};ct.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(Em(299));return Xx(e,t,null,n)};ct.flushSync=function(e){var t=er.T,n=ft.p;try{if(er.T=null,ft.p=2,e)return e()}finally{er.T=t,ft.p=n,ft.d.f()}};ct.preconnect=function(e,t){typeof e=="string"&&(t?(t=t.crossOrigin,t=typeof t=="string"?t==="use-credentials"?t:"":void 0):t=null,ft.d.C(e,t))};ct.prefetchDNS=function(e){typeof e=="string"&&ft.d.D(e)};ct.preinit=function(e,t){if(typeof e=="string"&&t&&typeof t.as=="string"){var n=t.as,o=El(n,t.crossOrigin),a=typeof t.integrity=="string"?t.integrity:void 0,i=typeof t.fetchPriority=="string"?t.fetchPriority:void 0;n==="style"?ft.d.S(e,typeof t.precedence=="string"?t.precedence:void 0,{crossOrigin:o,integrity:a,fetchPriority:i}):n==="script"&&ft.d.X(e,{crossOrigin:o,integrity:a,fetchPriority:i,nonce:typeof t.nonce=="string"?t.nonce:void 0})}};ct.preinitModule=function(e,t){if(typeof e=="string")if(typeof t=="object"&&t!==null){if(t.as==null||t.as==="script"){var n=El(t.as,t.crossOrigin);ft.d.M(e,{crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}}else t==null&&ft.d.M(e)};ct.preload=function(e,t){if(typeof e=="string"&&typeof t=="object"&&t!==null&&typeof t.as=="string"){var n=t.as,o=El(n,t.crossOrigin);ft.d.L(e,n,{crossOrigin:o,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,type:typeof t.type=="string"?t.type:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy=="string"?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet=="string"?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes=="string"?t.imageSizes:void 0,media:typeof t.media=="string"?t.media:void 0})}};ct.preloadModule=function(e,t){if(typeof e=="string")if(t){var n=El(t.as,t.crossOrigin);ft.d.m(e,{as:typeof t.as=="string"&&t.as!=="script"?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}else ft.d.m(e)};ct.requestFormReset=function(e){ft.d.r(e)};ct.unstable_batchedUpdates=function(e,t){return e(t)};ct.useFormState=function(e,t,n){return er.H.useFormState(e,t,n)};ct.useFormStatus=function(){return er.H.useHostTransitionStatus()};ct.version="19.3.0"});var Tl=bn((zE,Nm)=>{"use strict";function Cm(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Cm)}catch(e){console.error(e)}}Cm(),Nm.exports=Tm()});var p0=bn(rs=>{"use strict";var Ke=cm(),fb=Ae(),Gx=Tl();function C(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function pb(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Yr(e){for(var t=e,n=t;n&&!n.alternate;)t=n,(t.flags&4098)!==0&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function mb(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function gb(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Mm(e){if(Yr(e)!==e)throw Error(C(188))}function Qx(e){var t=e.alternate;if(!t){if(t=Yr(e),t===null)throw Error(C(188));return t!==e?null:e}for(var n=e,o=t;;){var a=n.return;if(a===null)break;var i=a.alternate;if(i===null){if(o=a.return,o!==null){n=o;continue}break}if(a.child===i.child){for(i=a.child;i;){if(i===n)return Mm(a),e;if(i===o)return Mm(a),t;i=i.sibling}throw Error(C(188))}if(n.return!==o.return)n=a,o=i;else{for(var r=!1,l=a.child;l;){if(l===n){r=!0,n=a,o=i;break}if(l===o){r=!0,o=a,n=i;break}l=l.sibling}if(!r){for(l=i.child;l;){if(l===n){r=!0,n=i,o=a;break}if(l===o){r=!0,o=i,n=a;break}l=l.sibling}if(!r)throw Error(C(189))}}if(n.alternate!==o)throw Error(C(190))}if(n.tag!==3)throw Error(C(188));return n.stateNode.current===n?e:t}function bb(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=bb(e),t!==null)return t;e=e.sibling}return null}function Et(e,t,n,o,a,i){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,o,a,i)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&Et(e.child,t,n,o,a,i))return!0;e=e.sibling}return!1}function ga(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function Am(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),!(e.tag===3||e.tag===5||e.tag===27));)e=e.return;return t}function hb(e){var t=[null,null],n=ga(e);return n===null||vb(t,e,n.child,{foundSelf:!1}),t}function vb(e,t,n,o){for(;n!==null;){if(n===t)o.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(o.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&vb(e,t,n.child,o))return!0;n=n.sibling}return!1}function Ve(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(C(559))}}var Ga=null,Bu=null;function Zx(e,t,n){return e===n?!0:e===t?(Ga=e,!0):!1}function Px(e,t,n){return e===n?(Bu=e,!1):e===t?(Bu!==null&&(Ga=e),!0):!1}function zm(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function Lu(e,t,n){for(var o=0,a=e;a;a=n(a))o++;a=0;for(var i=t;i;i=n(i))a++;for(;0<o-a;)e=n(e),o--;for(;0<a-o;)t=n(t),a--;for(;o--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var he=Object.assign,$x=Symbol.for("react.element"),Cl=Symbol.for("react.transitional.element"),lr=Symbol.for("react.portal"),Qa=Symbol.for("react.fragment"),yb=Symbol.for("react.strict_mode"),Uu=Symbol.for("react.profiler"),xb=Symbol.for("react.consumer"),Sn=Symbol.for("react.context"),Zd=Symbol.for("react.forward_ref"),ju=Symbol.for("react.suspense"),qu=Symbol.for("react.suspense_list"),Pd=Symbol.for("react.memo"),uo=Symbol.for("react.lazy"),Yu=Symbol.for("react.activity"),Jx=Symbol.for("react.legacy_hidden"),Ix=Symbol.for("react.memo_cache_sentinel"),Vu=Symbol.for("react.view_transition"),Fx=Symbol.for("react.recoverable"),Om=Symbol.iterator;function tr(e){return e===null||typeof e!="object"?null:(e=Om&&e[Om]||e["@@iterator"],typeof e=="function"?e:null)}var Wx=Symbol.for("react.client.reference");function Ku(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===Wx?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Qa:return"Fragment";case Uu:return"Profiler";case yb:return"StrictMode";case ju:return"Suspense";case qu:return"SuspenseList";case Yu:return"Activity";case Vu:return"ViewTransition"}if(typeof e=="object")switch(e.$$typeof){case lr:return"Portal";case Sn:return e.displayName||"Context";case xb:return(e._context.displayName||"Context")+".Consumer";case Zd:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Pd:return t=e.displayName||null,t!==null?t:Ku(e.type)||"Memo";case uo:t=e._payload,e=e._init;try{return Ku(e(t))}catch{}}return null}var cr=Array.isArray,Y=fb.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,se=Gx.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,na={pending:!1,data:null,method:null,action:null},Xu=[],Za=-1;function zn(e){return{current:e}}function We(e){0>Za||(e.current=Xu[Za],Xu[Za]=null,Za--)}function we(e,t){Za++,Xu[Za]=e.current,e.current=t}var Nn=zn(null),Tr=zn(null),xo=zn(null),fc=zn(null);function pc(e,t){switch(we(xo,t),we(Tr,e),we(Nn,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?Gg(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=Gg(t),e=Vv(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}We(Nn),we(Nn,e)}function pi(){We(Nn),We(Tr),We(xo)}function Gu(e){var t=e.memoizedState;t!==null&&(Si._currentValue=t.memoizedState,we(fc,e)),t=Nn.current;var n=Vv(t,e.type);t!==n&&(we(Tr,e),we(Nn,n))}function mc(e){Tr.current===e&&(We(Nn),We(Tr)),fc.current===e&&(We(fc),Si._currentValue=na)}var iu,Rm;function co(e){if(iu===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);iu=t&&t[1]||"",Rm=-1<n.stack.indexOf(`
    at`)?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return`
`+iu+e+Rm}var ru=!1;function lu(e,t){if(!e||ru)return"";ru=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(t){var b=function(){throw Error()};if(Object.defineProperty(b.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(b,[])}catch(x){var u=x}Reflect.construct(e,[],b)}else{try{b.call()}catch(x){u=x}b=!1;try{var d=Object.getOwnPropertyDescriptor(e.prototype,"props");Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),b=!0,new e}finally{b&&(d!==void 0?Object.defineProperty(e.prototype,"props",d):delete e.prototype.props)}}}else{try{throw Error()}catch(x){u=x}(b=e())&&typeof b.catch=="function"&&b.catch(function(){})}}catch(x){if(x&&u&&typeof x.stack=="string")return[x.stack,u.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var a=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");a&&a.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var i=o.DetermineComponentFrameRoot(),r=i[0],l=i[1];if(r&&l){var c=r.split(`
`),s=l.split(`
`);for(a=o=0;o<c.length&&!c[o].includes("DetermineComponentFrameRoot");)o++;for(;a<s.length&&!s[a].includes("DetermineComponentFrameRoot");)a++;if(o===c.length||a===s.length)for(o=c.length-1,a=s.length-1;1<=o&&0<=a&&c[o]!==s[a];)a--;for(;1<=o&&0<=a;o--,a--)if(c[o]!==s[a]){if(o!==1||a!==1)do if(o--,a--,0>a||c[o]!==s[a]){var p=`
`+c[o].replace(" at new "," at ");return e.displayName&&p.includes("<anonymous>")&&(p=p.replace("<anonymous>",e.displayName)),p}while(1<=o&&0<=a);break}}}finally{ru=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?co(n):""}function ek(e,t){switch(e.tag){case 26:case 27:case 5:return co(e.type);case 16:return co("Lazy");case 13:return e.child!==t&&t!==null?co("Suspense Fallback"):co("Suspense");case 19:return co("SuspenseList");case 0:case 15:return lu(e.type,!1);case 11:return lu(e.type.render,!1);case 1:return lu(e.type,!0);case 31:return co("Activity");case 30:return co("ViewTransition");default:return""}}function Dm(e){try{var t="",n=null;do t+=ek(e,n),n=e,e=e.return;while(e);return t}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var Qu=Object.prototype.hasOwnProperty,$d=Ke.unstable_scheduleCallback,cu=Ke.unstable_cancelCallback,tk=Ke.unstable_shouldYield,nk=Ke.unstable_requestPaint,_t=Ke.unstable_now,ok=Ke.unstable_getCurrentPriorityLevel,kb=Ke.unstable_ImmediatePriority,wb=Ke.unstable_UserBlockingPriority,gc=Ke.unstable_NormalPriority,ak=Ke.unstable_LowPriority,Sb=Ke.unstable_IdlePriority,ik=Ke.log,rk=Ke.unstable_setDisableYieldValue,Vr=null,Ht=null;function mo(e){if(typeof ik=="function"&&rk(e),Ht&&typeof Ht.setStrictMode=="function")try{Ht.setStrictMode(Vr,e)}catch{}}var Bt=Math.clz32?Math.clz32:sk,lk=Math.log,ck=Math.LN2;function sk(e){return e>>>=0,e===0?32:31-(lk(e)/ck|0)|0}var Nl=256,Ml=262144,Al=4194304;function Io(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Yc(e,t,n){var o=e.pendingLanes;if(o===0)return 0;var a=0,i=e.suspendedLanes,r=e.pingedLanes;e=e.warmLanes;var l=o&134217727;return l!==0?(o=l&~i,o!==0?a=Io(o):(r&=l,r!==0?a=Io(r):n||(n=l&~e,n!==0&&(a=Io(n))))):(l=o&~i,l!==0?a=Io(l):r!==0?a=Io(r):n||(n=o&~e,n!==0&&(a=Io(n)))),a===0?0:t!==0&&t!==a&&(t&i)===0&&(i=a&-a,n=t&-t,i>=n||i===32&&(n&4194048)!==0)?t:a}function Kr(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Eb(e,t){(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var o=31-Bt(n),a=1<<o;t|=e[o],n&=~a}return t}function uk(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Tb(){var e=Al;return Al<<=1,(Al&62914560)===0&&(Al=4194304),e}function su(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Xr(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function dk(e,t,n,o,a,i){var r=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var l=e.entanglements,c=e.expirationTimes,s=e.hiddenUpdates;for(n=r&~n;0<n;){var p=31-Bt(n),b=1<<p;l[p]=0,c[p]=-1;var u=s[p];if(u!==null)for(s[p]=null,p=0;p<u.length;p++){var d=u[p];d!==null&&(d.lane&=-536870913)}n&=~b}o!==0&&Cb(e,o,0),i!==0&&a===0&&e.tag!==0&&(e.suspendedLanes|=i&~(r&~t))}function Cb(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var o=31-Bt(t);e.entangledLanes|=t,e.entanglements[o]=e.entanglements[o]|1073741824|n&261930}function Nb(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var o=31-Bt(n),a=1<<o;a&t|e[o]&t&&(e[o]|=t),n&=~a}}function Mb(e,t){var n=t&-t;return n=(n&42)!==0?1:Jd(n),(n&(e.suspendedLanes|t))!==0?0:n}function Jd(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Id(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Ab(){var e=se.p;return e!==0?e:(e=window.event,e===void 0?32:u0(e.type))}function _m(e,t){var n=se.p;try{return se.p=e,t()}finally{se.p=n}}var In=Math.random().toString(36).slice(2),Ie="__reactFiber$"+In,Tt="__reactProps$"+In,Ci="__reactContainer$"+In,Hm="__reactEvents$"+In,fk="__reactListeners$"+In,pk="__reactHandles$"+In,Bm="__reactResources$"+In,Gr="__reactMarker$"+In,bc="__reactLoad$"+In;function Vc(e){delete e[Ie],delete e[Tt],delete e[fk],delete e[pk]}function ea(e){var t;if(t=e[Ie])return t;for(var n=e.parentNode;n;){if(t=n[Ci]||n[Ie]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=Wg(e);e!==null;){if(n=e[Ie])return n;e=Wg(e)}return t}e=n,n=e.parentNode}return null}function Ni(e){if(e=e[Ie]||e[Ci]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function sr(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(C(33))}function oi(e){var t=e[Bm];return t||(t=e[Bm]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function Ze(e){e[Gr]=!0}function zb(e){e[bc]=void 0}var Ob=new Set,Rb={};function ba(e,t){mi(e,t),mi(e+"Capture",t)}function mi(e,t){for(Rb[e]=t,e=0;e<t.length;e++)Ob.add(t[e])}var mk=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Lm={},Um={};function gk(e){return Qu.call(Um,e)?!0:Qu.call(Lm,e)?!1:mk.test(e)?Um[e]=!0:(Lm[e]=!0,!1)}var re=!1;function jm(){var e=re;return re=!1,e}function Zl(e,t,n){if(gk(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var o=t.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,n)}}function zl(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,n)}}function jn(e,t,n,o){if(o===null)e.removeAttribute(n);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,o)}}function zt(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Db(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function bk(e,t,n){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var a=o.get,i=o.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return a.call(this)},set:function(r){n=""+r,i.call(this,r)}}),Object.defineProperty(e,t,{enumerable:o.enumerable}),{getValue:function(){return n},setValue:function(r){n=""+r},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Zu(e){if(!e._valueTracker){var t=Db(e)?"checked":"value";e._valueTracker=bk(e,t,""+e[t])}}function _b(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),o="";return e&&(o=Db(e)?e.checked?"true":"false":e.value),e=o,e!==n?(t.setValue(e),!0):!1}var hk=/[\n"\\]/g;function $t(e){return e.replace(hk,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function Pu(e,t,n,o,a,i,r,l){e.name="",r!=null&&typeof r!="function"&&typeof r!="symbol"&&typeof r!="boolean"?e.type=r:e.removeAttribute("type"),t!=null?r==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+zt(t)):e.value!==""+zt(t)&&(e.value=""+zt(t)):r!=="submit"&&r!=="reset"||e.removeAttribute("value"),t!=null?r==="number"&&e.value==t?uu(e,zt(e.value)):uu(e,zt(t)):n!=null?uu(e,zt(n)):o!=null&&e.removeAttribute("value"),a==null&&i!=null&&(e.defaultChecked=!!i),a!=null&&(e.checked=a&&typeof a!="function"&&typeof a!="symbol"),l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"?e.name=""+zt(l):e.removeAttribute("name")}function Hb(e,t,n,o,a,i,r,l){if(i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"&&(e.type=i),t!=null||n!=null){if(!(i!=="submit"&&i!=="reset"||t!=null)){Zu(e);return}n=n!=null?""+zt(n):"",t=t!=null?""+zt(t):n,l||t===e.value||(e.value=t),e.defaultValue=t}o=o??a,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=l?e.checked:!!o,e.defaultChecked=!!o,r!=null&&typeof r!="function"&&typeof r!="symbol"&&typeof r!="boolean"&&(e.name=r),Zu(e)}function uu(e,t){e.defaultValue!==""+t&&(e.defaultValue=""+t)}function ai(e,t,n,o){if(e=e.options,t){t={};for(var a=0;a<n.length;a++)t["$"+n[a]]=!0;for(n=0;n<e.length;n++)a=t.hasOwnProperty("$"+e[n].value),e[n].selected!==a&&(e[n].selected=a),a&&o&&(e[n].defaultSelected=!0)}else{for(n=""+zt(n),t=null,a=0;a<e.length;a++){if(e[a].value===n){e[a].selected=!0,o&&(e[a].defaultSelected=!0);return}t!==null||e[a].disabled||(t=e[a])}t!==null&&(t.selected=!0)}}function Bb(e,t,n){if(t!=null&&(t=""+zt(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n!=null?""+zt(n):""}function Lb(e,t,n,o){if(t==null){if(o!=null){if(n!=null)throw Error(C(92));if(cr(o)){if(1<o.length)throw Error(C(93));o=o[0]}n=o}n==null&&(n=""),t=n}n=zt(t),e.defaultValue=n,o=e.textContent,o===n&&o!==""&&o!==null&&(e.value=o),Zu(e)}function gi(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var vk=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function qm(e,t,n){var o=t.indexOf("--")===0;n==null||typeof n=="boolean"||n===""?o?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":o?e.setProperty(t,n):typeof n!="number"||n===0||vk.has(t)?t==="float"?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function Ub(e,t,n){if(t!=null&&typeof t!="object")throw Error(C(62));if(e=e.style,n!=null){for(var o in n)!n.hasOwnProperty(o)||t!=null&&t.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="",re=!0);for(var a in t)o=t[a],t.hasOwnProperty(a)&&n[a]!==o&&(qm(e,a,o),re=!0)}else for(var i in t)t.hasOwnProperty(i)&&qm(e,i,t[i])}function Fd(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var yk=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),xk=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Pl(e){return xk.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function En(){}var $u=null;function Wd(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Pa=null,ii=null;function Ym(e){var t=Ni(e);if(t&&(e=t.stateNode)){var n=e[Tt]||null;e:switch(e=t.stateNode,t.type){case"input":if(Pu(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+$t(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var o=n[t];if(o!==e&&o.form===e.form){var a=o[Tt]||null;if(!a)throw Error(C(90));Pu(o,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)o=n[t],o.form===e.form&&_b(o)}break e;case"textarea":Bb(e,n.value,n.defaultValue);break e;case"select":t=n.value,t!=null&&ai(e,!!n.multiple,t,!1)}}}var du=!1;function jb(e,t,n){if(du)return e(t,n);du=!0;try{var o=e(t);return o}finally{if(du=!1,(Pa!==null||ii!==null)&&(ns(),Pa&&(t=Pa,e=ii,ii=Pa=null,Ym(t),e)))for(t=0;t<e.length;t++)Ym(e[t])}}function Cr(e,t){var n=e.stateNode;if(n===null)return null;var o=n[Tt]||null;if(o===null)return null;n=o[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(C(231,t,typeof n));return n}var Gn=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Ju=!1;if(Gn)try{ja={},Object.defineProperty(ja,"passive",{get:function(){Ju=!0}}),window.addEventListener("test",ja,ja),window.removeEventListener("test",ja,ja)}catch{Ju=!1}var ja,go=null,ef=null,$l=null;function qb(){if($l)return $l;var e,t=ef,n=t.length,o,a="value"in go?go.value:go.textContent,i=a.length;for(e=0;e<n&&t[e]===a[e];e++);var r=n-e;for(o=1;o<=r&&t[n-o]===a[i-o];o++);return $l=a.slice(e,1<o?1-o:void 0)}function Jl(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Ol(){return!0}function Vm(){return!1}function bt(e){function t(n,o,a,i,r){this._reactName=n,this._targetInst=a,this.type=o,this.nativeEvent=i,this.target=r,this.currentTarget=null;for(var l in e)e.hasOwnProperty(l)&&(n=e[l],this[l]=n?n(i):i[l]);return this.isDefaultPrevented=(i.defaultPrevented!=null?i.defaultPrevented:i.returnValue===!1)?Ol:Vm,this.isPropagationStopped=Vm,this}return he(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=Ol)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=Ol)},persist:function(){},isPersistent:Ol}),t}var Ho={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Kc=bt(Ho),Qr=he({},Ho,{view:0,detail:0}),kk=bt(Qr),fu,pu,nr,Xc=he({},Qr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:tf,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==nr&&(nr&&e.type==="mousemove"?(fu=e.screenX-nr.screenX,pu=e.screenY-nr.screenY):pu=fu=0,nr=e),fu)},movementY:function(e){return"movementY"in e?e.movementY:pu}}),Km=bt(Xc),wk=he({},Xc,{dataTransfer:0}),Sk=bt(wk),Ek=he({},Qr,{relatedTarget:0}),mu=bt(Ek),Tk=he({},Ho,{animationName:0,elapsedTime:0,pseudoElement:0}),Ck=bt(Tk),Nk=he({},Ho,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Mk=bt(Nk),Ak=he({},Ho,{data:0}),Xm=bt(Ak),zk={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Ok={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Rk={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Dk(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Rk[e])?!!t[e]:!1}function tf(){return Dk}var _k=he({},Qr,{key:function(e){if(e.key){var t=zk[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=Jl(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?Ok[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:tf,charCode:function(e){return e.type==="keypress"?Jl(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Jl(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),Hk=bt(_k),Bk=he({},Xc,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Gm=bt(Bk),Lk=he({},Ho,{submitter:0}),Uk=bt(Lk),jk=he({},Qr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:tf}),qk=bt(jk),Yk=he({},Ho,{propertyName:0,elapsedTime:0,pseudoElement:0}),Vk=bt(Yk),Kk=he({},Xc,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Xk=bt(Kk),Gk=he({},Ho,{newState:0,oldState:0,source:0}),Qk=bt(Gk),Zk=[9,13,27,32],nf=Gn&&"CompositionEvent"in window,fr=null;Gn&&"documentMode"in document&&(fr=document.documentMode);var Pk=Gn&&"TextEvent"in window&&!fr,Yb=Gn&&(!nf||fr&&8<fr&&11>=fr),Qm=" ",Zm=!1;function Vb(e,t){switch(e){case"keyup":return Zk.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Kb(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var $a=!1;function $k(e,t){switch(e){case"compositionend":return Kb(t);case"keypress":return t.which!==32?null:(Zm=!0,Qm);case"textInput":return e=t.data,e===Qm&&Zm?null:e;default:return null}}function Jk(e,t){if($a)return e==="compositionend"||!nf&&Vb(e,t)?(e=qb(),$l=ef=go=null,$a=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Yb&&t.locale!=="ko"?null:t.data;default:return null}}var Ik={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Pm(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Ik[e.type]:t==="textarea"}function Xb(e,t,n,o){Pa?ii?ii.push(o):ii=[o]:Pa=o,t=Uc(t,"onChange"),0<t.length&&(n=new Kc("onChange","change",null,n,o),e.push({event:n,listeners:t}))}var pr=null,Nr=null;function Fk(e){jv(e,0)}function Gc(e){var t=sr(e);if(_b(t))return e}function $m(e,t){if(e==="change")return t}var Gb=!1;Gn&&(Gn?(Dl="oninput"in document,Dl||(gu=document.createElement("div"),gu.setAttribute("oninput","return;"),Dl=typeof gu.oninput=="function"),Rl=Dl):Rl=!1,Gb=Rl&&(!document.documentMode||9<document.documentMode));var Rl,Dl,gu;function Jm(){pr&&(pr.detachEvent("onpropertychange",Qb),Nr=pr=null)}function Qb(e){if(e.propertyName==="value"&&Gc(Nr)){var t=[];Xb(t,Nr,e,Wd(e)),jb(Fk,t)}}function Wk(e,t,n){e==="focusin"?(Jm(),pr=t,Nr=n,pr.attachEvent("onpropertychange",Qb)):e==="focusout"&&Jm()}function ew(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Gc(Nr)}function tw(e,t){if(e==="click")return Gc(t)}function nw(e,t){if(e==="input"||e==="change")return Gc(t)}function ow(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Ut=typeof Object.is=="function"?Object.is:ow;function Mr(e,t){if(Ut(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),o=Object.keys(t);if(n.length!==o.length)return!1;for(o=0;o<n.length;o++){var a=n[o];if(!Qu.call(t,a)||!Ut(e[a],t[a]))return!1}return!0}function Iu(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function Im(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Fm(e,t){var n=Im(e);e=0;for(var o;n;){if(n.nodeType===3){if(o=e+n.textContent.length,e<=t&&o>=t)return{node:n,offset:t-e};e=o}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=Im(n)}}function Zb(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Zb(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Pb(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=Iu(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=Iu(e.document)}return t}function of(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var aw=Gn&&"documentMode"in document&&11>=document.documentMode,Ja=null,Fu=null,mr=null,Wu=!1;function Wm(e,t,n){var o=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Wu||Ja==null||Ja!==Iu(o)||(o=Ja,"selectionStart"in o&&of(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),mr&&Mr(mr,o)||(mr=o,o=Uc(Fu,"onSelect"),0<o.length&&(t=new Kc("onSelect","select",null,t,n),e.push({event:t,listeners:o}),t.target=Ja)))}function $o(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var Ia={animationend:$o("Animation","AnimationEnd"),animationiteration:$o("Animation","AnimationIteration"),animationstart:$o("Animation","AnimationStart"),transitionrun:$o("Transition","TransitionRun"),transitionstart:$o("Transition","TransitionStart"),transitioncancel:$o("Transition","TransitionCancel"),transitionend:$o("Transition","TransitionEnd")},bu={},$b={};Gn&&($b=document.createElement("div").style,"AnimationEvent"in window||(delete Ia.animationend.animation,delete Ia.animationiteration.animation,delete Ia.animationstart.animation),"TransitionEvent"in window||delete Ia.transitionend.transition);function ha(e){if(bu[e])return bu[e];if(!Ia[e])return e;var t=Ia[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in $b)return bu[e]=t[n];return e}var Jb=ha("animationend"),Ib=ha("animationiteration"),Fb=ha("animationstart"),iw=ha("transitionrun"),rw=ha("transitionstart"),lw=ha("transitioncancel"),Wb=ha("transitionend"),eh=new Map,ed="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");ed.push("scrollEnd");function fn(e,t){eh.set(e,t),ba(t,[e])}var cw=0;function Qn(e,t){if(e.name!=null&&e.name!=="auto")return e.name;if(t.autoName!==null)return t.autoName;e=dn.identifierPrefix;var n=cw++;return e="_"+e+"t_"+n.toString(32)+"_",t.autoName=e}function eg(e){if(e==null||typeof e=="string")return e;var t=null,n=fi;if(n!==null)for(var o=0;o<n.length;o++){var a=e[n[o]];if(a!=null){if(a==="none")return"none";t=t==null?a:t+(" "+a)}}return t??e.default}function Fn(e,t){return e=eg(e),t=eg(t),t==null?e==="auto"?null:e:t==="auto"?null:t}var hc=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Qt=[],Fa=0,af=0;function Qc(){for(var e=Fa,t=af=Fa=0;t<e;){var n=Qt[t];Qt[t++]=null;var o=Qt[t];Qt[t++]=null;var a=Qt[t];Qt[t++]=null;var i=Qt[t];if(Qt[t++]=null,o!==null&&a!==null){var r=o.pending;r===null?a.next=a:(a.next=r.next,r.next=a),o.pending=a}i!==0&&th(n,a,i)}}function Zc(e,t,n,o){Qt[Fa++]=e,Qt[Fa++]=t,Qt[Fa++]=n,Qt[Fa++]=o,af|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function rf(e,t,n,o){return Zc(e,t,n,o),vc(e)}function va(e,t){return Zc(e,null,null,t),vc(e)}function th(e,t,n){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n);for(var a=!1,i=e.return;i!==null;)i.childLanes|=n,o=i.alternate,o!==null&&(o.childLanes|=n),i.tag===22&&(e=i.stateNode,e===null||e._visibility&1||(a=!0)),e=i,i=i.return;return e.tag===3?(i=e.stateNode,a&&t!==null&&(a=31-Bt(n),e=i.hiddenUpdates,o=e[a],o===null?e[a]=[t]:o.push(t),t.lane=n|536870912),i):null}function vc(e){if(50<Er)throw Er=0,rc=null,Error(C(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Wa={};function sw(e,t,n,o){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function wt(e,t,n,o){return new sw(e,t,n,o)}function lf(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Kn(e,t){var n=e.alternate;return n===null?(n=wt(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function nh(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Il(e,t,n,o,a,i){var r=0;if(o=e,typeof o=="function")lf(o)&&(r=1);else if(typeof o=="string")r=HS(e,n,Nn.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(o){case Yu:return e=wt(31,n,t,a),e.elementType=Yu,e.lanes=i,e;case Qa:return oa(n.children,a,i,t);case yb:r=8,a|=24;break;case Uu:return e=wt(12,n,t,a|2),e.elementType=Uu,e.lanes=i,e;case ju:return e=wt(13,n,t,a),e.elementType=ju,e.lanes=i,e;case qu:return e=wt(19,n,t,a),e.elementType=qu,e.lanes=i,e;case Jx:case Vu:return e=a|32,e=wt(30,n,t,e),e.elementType=Vu,e.lanes=i,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof o=="object"&&o!==null)switch(o.$$typeof){case Sn:r=10;break e;case xb:r=9;break e;case Zd:r=11;break e;case Pd:r=14;break e;case uo:r=16,o=null;break e}r=29,n=Error(C(130,e===null?"null":typeof e,"")),o=null}return t=wt(r,n,t,a),t.elementType=e,t.type=o,t.lanes=i,t}function oa(e,t,n,o){return e=wt(7,e,o,t),e.lanes=n,e}function hu(e,t,n){return e=wt(6,e,null,t),e.lanes=n,e}function oh(e){var t=wt(18,null,null,0);return t.stateNode=e,t}function vu(e,t,n){return t=wt(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var tg=new WeakMap;function Jt(e,t){if(typeof e=="object"&&e!==null){var n=tg.get(e);return n!==void 0?n:(t={value:e,source:t,stack:Dm(t)},tg.set(e,t),t)}return{value:e,source:t,stack:Dm(t)}}var ei=[],ti=0,yc=null,Ar=0,Zt=[],Pt=0,zo=null,Tn=1,Cn="";function Yn(e,t){ei[ti++]=Ar,ei[ti++]=yc,yc=e,Ar=t}function ah(e,t,n){Zt[Pt++]=Tn,Zt[Pt++]=Cn,Zt[Pt++]=zo,zo=e;var o=Tn;e=Cn;var a=32-Bt(o)-1;o&=~(1<<a),n+=1;var i=32-Bt(t)+a;if(30<i){var r=a-a%5;i=(o&(1<<r)-1).toString(32),o>>=r,a-=r,Tn=1<<32-Bt(t)+a|n<<a|o,Cn=i+e}else Tn=1<<i|n<<a|o,Cn=e}function Pc(e){e.return!==null&&(Yn(e,1),ah(e,1,0))}function cf(e){for(;e===yc;)yc=ei[--ti],ei[ti]=null,Ar=ei[--ti],ei[ti]=null;for(;e===zo;)zo=Zt[--Pt],Zt[Pt]=null,Cn=Zt[--Pt],Zt[Pt]=null,Tn=Zt[--Pt],Zt[Pt]=null}function ih(e,t){Zt[Pt++]=Tn,Zt[Pt++]=Cn,Zt[Pt++]=zo,Tn=t.id,Cn=t.overflow,zo=e}var Pe=null,ke=null,J=!1,ko=null,It=!1,td=Error(C(519));function Oo(e){var t=Error(C(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw zr(Jt(t,e)),td}function ng(e){var t=e.stateNode,n=e.type,o=e.memoizedProps;switch(t[Ie]=e,t[Tt]=o,n){case"dialog":W("cancel",t),W("close",t);break;case"iframe":case"object":case"embed":W("load",t);break;case"video":case"audio":for(n=0;n<_r.length;n++)W(_r[n],t);break;case"source":W("error",t);break;case"img":case"image":case"link":W("error",t),W("load",t);break;case"details":W("toggle",t);break;case"input":W("invalid",t),Hb(t,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":W("invalid",t);break;case"textarea":W("invalid",t),Lb(t,o.value,o.defaultValue,o.children)}n=o.children,typeof n!="string"&&typeof n!="number"&&typeof n!="bigint"||t.textContent===""+n||o.suppressHydrationWarning===!0||Yv(t.textContent,n)?(o.popover!=null&&(W("beforetoggle",t),W("toggle",t)),o.onScroll!=null&&W("scroll",t),o.onScrollEnd!=null&&W("scrollend",t),o.onClick!=null&&(t.onclick=En),t=!0):t=!1,t||Oo(e,!0)}function xc(e){for(Pe=e.return;Pe;)switch(Pe.tag){case 5:case 31:case 13:It=!1;return;case 27:case 3:It=!0;return;default:Pe=Pe.return}}function qa(e){if(e!==Pe)return!1;if(!J)return xc(e),J=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!=="form"&&n!=="button")||jd(e.type,e.memoizedProps)),n=!n),n&&ke&&Oo(e),xc(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(C(317));ke=Fg(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(C(317));ke=Fg(e)}else t===27?(t=ke,Bo(e.type)?(e=Kd,Kd=null,ke=e):ke=t):ke=Pe?Ft(e.stateNode.nextSibling):null;return!0}function la(){ke=Pe=null,J=!1}function yu(){var e=ko;return e!==null&&(xt===null?xt=e:xt.push.apply(xt,e),ko=null),e}function zr(e){ko===null?ko=[e]:ko.push(e)}var nd=zn(null),ya=null,Vn=null;function bo(e,t,n){we(nd,t._currentValue),t._currentValue=n}function Xn(e){e._currentValue=nd.current,We(nd)}function Fl(e,t,n){for(;e!==null;){var o=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,o!==null&&(o.childLanes|=t)):o!==null&&(o.childLanes&t)!==t&&(o.childLanes|=t),e===n)break;e=e.return}}function od(e,t,n,o){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var i=a.dependencies;if(i!==null){var r=a.child;i=i.firstContext;e:for(;i!==null;){var l=i;i=a;for(var c=0;c<t.length;c++)if(l.context===t[c]){i.lanes|=n,l=i.alternate,l!==null&&(l.lanes|=n),Fl(i.return,n,e),o||(r=null);break e}i=l.next}}else if(a.tag===18){if(r=a.return,r===null)throw Error(C(341));r.lanes|=n,i=r.alternate,i!==null&&(i.lanes|=n),Fl(r,n,e),r=null}else a.tag===13&&a.memoizedState!==null&&a.memoizedState.dehydrated===null?(a.lanes|=n,r=a.alternate,r!==null&&(r.lanes|=n),Fl(a.return,n,e),r=a.child,r=r!==null?r.sibling:null):r=a.child;if(r!==null)r.return=a;else for(r=a;r!==null;){if(r===e){r=null;break}if(a=r.sibling,a!==null){a.return=r.return,r=a;break}r=r.return}a=r}}function ca(e,t,n,o){e=null;for(var a=t,i=!1;a!==null;){if(!i){if((a.flags&524288)!==0)i=!0;else if((a.flags&262144)!==0)break}if(a.tag===10){var r=a.alternate;if(r===null)throw Error(C(387));if(r=r.memoizedProps,r!==null){var l=a.type;Ut(a.pendingProps.value,r.value)||(e!==null?e.push(l):e=[l])}}else if(a===fc.current){if(r=a.alternate,r===null)throw Error(C(387));r.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e!==null?e.push(Si):e=[Si])}a=a.return}return e!==null&&od(t,e,n,o),t.flags|=262144,e!==null}function kc(e){for(e=e.firstContext;e!==null;){if(!Ut(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function sa(e){ya=e,Vn=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function Fe(e){return rh(ya,e)}function _l(e,t){return ya===null&&sa(e),rh(e,t)}function rh(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},Vn===null){if(e===null)throw Error(C(308));Vn=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else Vn=Vn.next=t;return n}var uw=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(n,o){e.push(o)}};this.abort=function(){t.aborted=!0,e.forEach(function(n){return n()})}},dw=Ke.unstable_scheduleCallback,fw=Ke.unstable_NormalPriority,Le={$$typeof:Sn,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function sf(){return{controller:new uw,data:new Map,refCount:0}}function Zr(e){e.refCount--,e.refCount===0&&dw(fw,function(){e.controller.abort()})}function og(e,t){if((e.pendingLanes&4194048)!==0){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var o=t[e];n.indexOf(o)===-1&&n.push(o)}}}var ur=null;function pw(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var gr=null,ad=0,ua=0,ri=null;function mw(e,t){if(gr===null){var n=gr=[];ad=0,ua=Lf(),ri={status:"pending",value:void 0,then:function(o){n.push(o)}}}return ad++,t.then(ag,ag),t}function ag(){if(--ad===0&&(ur=null,gr!==null)){ri!==null&&(ri.status="fulfilled");var e=gr;gr=null,ua=0,ri=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function gw(e,t){var n=[],o={status:"pending",value:null,reason:null,then:function(a){n.push(a)}};return e.then(function(){o.status="fulfilled",o.value=t;for(var a=0;a<n.length;a++)(0,n[a])(t)},function(a){for(o.status="rejected",o.reason=a,a=0;a<n.length;a++)(0,n[a])(void 0)}),o}var ig=Y.S;Y.S=function(e,t){if(Ev=_t(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&mw(e,t),ur!==null)for(var n=xi;n!==null;)og(n,ur),n=n.next;if(n=e.types,n!==null){for(var o=xi;o!==null;)og(o,n),o=o.next;if(ua!==0){o=ur,o===null&&(o=ur=[]);for(var a=0;a<n.length;a++){var i=n[a];o.indexOf(i)===-1&&o.push(i)}}}ig!==null&&ig(e,t)};var aa=zn(null);function uf(){var e=aa.current;return e!==null?e:be.pooledCache}function Wl(e,t){t===null?we(aa,aa.current):we(aa,t.pool)}function lh(){var e=uf();return e===null?null:{parent:Le._currentValue,pool:e}}var Mi=Error(C(460)),df=Error(C(474)),$c=Error(C(542)),wc={then:function(){}};function rg(e){return e=e.status,e==="fulfilled"||e==="rejected"}function ch(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(En,En),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,cg(e),e===void 0&&!("reason"in t)?Error(C(600)):e;default:if(typeof t.status=="string")t.then(En,En);else{if(e=be,e!==null&&100<e.shellSuspendCounter)throw Error(C(482));e=t,e.status="pending",e.then(function(o){if(t.status==="pending"){var a=t;a.status="fulfilled",a.value=o}},function(o){if(t.status==="pending"){var a=t;a.status="rejected",a.reason=o}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,cg(e),e}throw ia=t,Mi}}function Fo(e){try{var t=e._init;return t(e._payload)}catch(n){throw n!==null&&typeof n=="object"&&typeof n.then=="function"?(ia=n,Mi):n}}var ia=null;function lg(){if(ia===null)throw Error(C(459));var e=ia;return ia=null,e}function cg(e){if(e===Mi||e===$c)throw Error(C(483))}var li=null,Or=0;function Hl(e){var t=Or;return Or+=1,li===null&&(li=[]),ch(li,e,t)}function lo(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function Bl(e,t){throw t.$$typeof===$x?Error(C(525)):(e=Object.prototype.toString.call(t),Error(C(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function sh(e){function t(m,g){if(e){var f=m.deletions;f===null?(m.deletions=[g],m.flags|=16):f.push(g)}}function n(m,g){if(!e)return null;for(;g!==null;)t(m,g),g=g.sibling;return null}function o(m){for(var g=new Map;m!==null;)m.key===null?g.set(m.index,m):g.set(m.key,m),m=m.sibling;return g}function a(m,g){return m=Kn(m,g),m.index=0,m.sibling=null,m}function i(m,g,f){return m.index=f,e?(f=m.alternate,f!==null?(f=f.index,f<g?(m.flags|=2,g):f):(m.flags|=134217730,g)):(m.flags|=1048576,g)}function r(m){return e&&m.alternate===null&&(m.flags|=134217730),m}function l(m,g,f,y){return g===null||g.tag!==6?(g=hu(f,m.mode,y),g.return=m,g):(g=a(g,f),g.return=m,g)}function c(m,g,f,y){var h=f.type;return h===Qa?(m=p(m,g,f.props.children,y,f.key),lo(m,f),m):g!==null&&(g.elementType===h||typeof h=="object"&&h!==null&&h.$$typeof===uo&&Fo(h)===g.type)?(g=a(g,f.props),lo(g,f),g.return=m,g):(g=Il(f.type,f.key,f.props,null,m.mode,y),lo(g,f),g.return=m,g)}function s(m,g,f,y){return g===null||g.tag!==4||g.stateNode.containerInfo!==f.containerInfo||g.stateNode.implementation!==f.implementation?(g=vu(f,m.mode,y),g.return=m,g):(g=a(g,f.children||[]),g.return=m,g)}function p(m,g,f,y,h){return g===null||g.tag!==7?(g=oa(f,m.mode,y,h),g.return=m,g):(g=a(g,f),g.return=m,g)}function b(m,g,f){if(typeof g=="string"&&g!==""||typeof g=="number"||typeof g=="bigint")return g=hu(""+g,m.mode,f),g.return=m,g;if(typeof g=="object"&&g!==null){switch(g.$$typeof){case Cl:return f=Il(g.type,g.key,g.props,null,m.mode,f),lo(f,g),f.return=m,f;case lr:return g=vu(g,m.mode,f),g.return=m,g;case uo:return g=Fo(g),b(m,g,f)}if(cr(g)||tr(g))return g=oa(g,m.mode,f,null),g.return=m,g;if(typeof g.then=="function")return b(m,Hl(g),f);if(g.$$typeof===Sn)return b(m,_l(m,g),f);Bl(m,g)}return null}function u(m,g,f,y){var h=g!==null?g.key:null;if(typeof f=="string"&&f!==""||typeof f=="number"||typeof f=="bigint")return h!==null?null:l(m,g,""+f,y);if(typeof f=="object"&&f!==null){switch(f.$$typeof){case Cl:return f.key===h?c(m,g,f,y):null;case lr:return f.key===h?s(m,g,f,y):null;case uo:return f=Fo(f),u(m,g,f,y)}if(cr(f)||tr(f))return h!==null?null:p(m,g,f,y,null);if(typeof f.then=="function")return u(m,g,Hl(f),y);if(f.$$typeof===Sn)return u(m,g,_l(m,f),y);Bl(m,f)}return null}function d(m,g,f,y,h){if(typeof y=="string"&&y!==""||typeof y=="number"||typeof y=="bigint")return m=m.get(f)||null,l(g,m,""+y,h);if(typeof y=="object"&&y!==null){switch(y.$$typeof){case Cl:return m=m.get(y.key===null?f:y.key)||null,c(g,m,y,h);case lr:return m=m.get(y.key===null?f:y.key)||null,s(g,m,y,h);case uo:return y=Fo(y),d(m,g,f,y,h)}if(cr(y)||tr(y))return m=m.get(f)||null,p(g,m,y,h,null);if(typeof y.then=="function")return d(m,g,f,Hl(y),h);if(y.$$typeof===Sn)return d(m,g,f,_l(g,y),h);Bl(g,y)}return null}function x(m,g,f,y){for(var h=null,S=null,v=g,T=g=0,z=null;v!==null&&T<f.length;T++){v.index>T?(z=v,v=null):z=v.sibling;var M=u(m,v,f[T],y);if(M===null){v===null&&(v=z);break}e&&v&&M.alternate===null&&t(m,v),g=i(M,g,T),S===null?h=M:S.sibling=M,S=M,v=z}if(T===f.length)return n(m,v),J&&Yn(m,T),h;if(v===null){for(;T<f.length;T++)v=b(m,f[T],y),v!==null&&(g=i(v,g,T),S===null?h=v:S.sibling=v,S=v);return J&&Yn(m,T),h}for(v=o(v);T<f.length;T++)z=d(v,m,T,f[T],y),z!==null&&(e&&(M=z.alternate,M!==null&&v.delete(M.key===null?T:M.key)),g=i(z,g,T),S===null?h=z:S.sibling=z,S=z);return e&&v.forEach(function(B){return t(m,B)}),J&&Yn(m,T),h}function k(m,g,f,y){if(f==null)throw Error(C(151));for(var h=null,S=null,v=g,T=g=0,z=null,M=f.next();v!==null&&!M.done;T++,M=f.next()){v.index>T?(z=v,v=null):z=v.sibling;var B=u(m,v,M.value,y);if(B===null){v===null&&(v=z);break}e&&v&&B.alternate===null&&t(m,v),g=i(B,g,T),S===null?h=B:S.sibling=B,S=B,v=z}if(M.done)return n(m,v),J&&Yn(m,T),h;if(v===null){for(;!M.done;T++,M=f.next())M=b(m,M.value,y),M!==null&&(g=i(M,g,T),S===null?h=M:S.sibling=M,S=M);return J&&Yn(m,T),h}for(v=o(v);!M.done;T++,M=f.next())M=d(v,m,T,M.value,y),M!==null&&(e&&(z=M.alternate,z!==null&&v.delete(z.key===null?T:z.key)),g=i(M,g,T),S===null?h=M:S.sibling=M,S=M);return e&&v.forEach(function(H){return t(m,H)}),J&&Yn(m,T),h}function E(m,g,f,y){if(typeof f=="object"&&f!==null&&f.type===Qa&&f.key===null&&f.props.ref===void 0&&(f=f.props.children),typeof f=="object"&&f!==null){switch(f.$$typeof){case Cl:e:{for(var h=f.key;g!==null;){if(g.key===h){if(h=f.type,h===Qa){if(g.tag===7){n(m,g.sibling),y=a(g,f.props.children),lo(y,f),y.return=m,m=y;break e}}else if(g.elementType===h||typeof h=="object"&&h!==null&&h.$$typeof===uo&&Fo(h)===g.type){n(m,g.sibling),y=a(g,f.props),lo(y,f),y.return=m,m=y;break e}n(m,g);break}else t(m,g);g=g.sibling}f.type===Qa?(y=oa(f.props.children,m.mode,y,f.key),lo(y,f),y.return=m,m=y):(y=Il(f.type,f.key,f.props,null,m.mode,y),lo(y,f),y.return=m,m=y)}return r(m);case lr:e:{for(h=f.key;g!==null;){if(g.key===h)if(g.tag===4&&g.stateNode.containerInfo===f.containerInfo&&g.stateNode.implementation===f.implementation){n(m,g.sibling),y=a(g,f.children||[]),y.return=m,m=y;break e}else{n(m,g);break}else t(m,g);g=g.sibling}y=vu(f,m.mode,y),y.return=m,m=y}return r(m);case uo:return f=Fo(f),E(m,g,f,y)}if(cr(f))return x(m,g,f,y);if(tr(f)){if(h=tr(f),typeof h!="function")throw Error(C(150));return f=h.call(f),k(m,g,f,y)}if(typeof f.then=="function")return E(m,g,Hl(f),y);if(f.$$typeof===Sn)return E(m,g,_l(m,f),y);Bl(m,f)}return typeof f=="string"&&f!==""||typeof f=="number"||typeof f=="bigint"?(f=""+f,g!==null&&g.tag===6?(n(m,g.sibling),y=a(g,f),y.return=m,m=y):(n(m,g),y=hu(f,m.mode,y),y.return=m,m=y),r(m)):n(m,g)}return function(m,g,f,y){try{Or=0;var h=E(m,g,f,y);return li=null,h}catch(v){if(v===Mi||v===$c)throw v;var S=wt(29,v,null,m.mode);return S.lanes=y,S.return=m,S}}}var da=sh(!0),uh=sh(!1),fo=!1;function ff(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function id(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function wo(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function So(e,t,n){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(ce&2)!==0){var a=o.pending;return a===null?t.next=t:(t.next=a.next,a.next=t),o.pending=t,t=vc(e),th(e,null,n),t}return Zc(e,o,t,n),vc(e)}function br(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194048)!==0)){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Nb(e,n)}}function xu(e,t){var n=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,n===o)){var a=null,i=null;if(n=n.firstBaseUpdate,n!==null){do{var r={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};i===null?a=i=r:i=i.next=r,n=n.next}while(n!==null);i===null?a=i=t:i=i.next=t}else a=i=t;n={baseState:o.baseState,firstBaseUpdate:a,lastBaseUpdate:i,shared:o.shared,callbacks:o.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var rd=!1;function hr(){if(rd){var e=ri;if(e!==null)throw e}}function vr(e,t,n,o){rd=!1;var a=e.updateQueue;fo=!1;var i=a.firstBaseUpdate,r=a.lastBaseUpdate,l=a.shared.pending;if(l!==null){a.shared.pending=null;var c=l,s=c.next;c.next=null,r===null?i=s:r.next=s,r=c;var p=e.alternate;p!==null&&(p=p.updateQueue,l=p.lastBaseUpdate,l!==r&&(l===null?p.firstBaseUpdate=s:l.next=s,p.lastBaseUpdate=c))}if(i!==null){var b=a.baseState;r=0,p=s=c=null,l=i;do{var u=l.lane&-536870913,d=u!==l.lane;if(d?(te&u)===u:(o&u)===u){u!==0&&u===ua&&(rd=!0),p!==null&&(p=p.next={lane:0,tag:l.tag,payload:l.payload,callback:null,next:null});e:{var x=e,k=l;u=t;var E=n;switch(k.tag){case 1:if(x=k.payload,typeof x=="function"){b=x.call(E,b,u);break e}b=x;break e;case 3:x.flags=x.flags&-65537|128;case 0:if(x=k.payload,u=typeof x=="function"?x.call(E,b,u):x,u==null)break e;b=he({},b,u);break e;case 2:fo=!0}}u=l.callback,u!==null&&(e.flags|=64,d&&(e.flags|=8192),d=a.callbacks,d===null?a.callbacks=[u]:d.push(u))}else d={lane:u,tag:l.tag,payload:l.payload,callback:l.callback,next:null},p===null?(s=p=d,c=b):p=p.next=d,r|=u;if(l=l.next,l===null){if(l=a.shared.pending,l===null)break;d=l,l=d.next,d.next=null,a.lastBaseUpdate=d,a.shared.pending=null}}while(!0);p===null&&(c=b),a.baseState=c,a.firstBaseUpdate=s,a.lastBaseUpdate=p,i===null&&(a.shared.lanes=0),_o|=r,e.lanes=r,e.memoizedState=b}}function dh(e,t){if(typeof e!="function")throw Error(C(191,e));e.call(t)}function fh(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)dh(n[e],t)}var Ro=zn(null),Sc=zn(0);function sg(e,t){e=Jn,we(Sc,e),we(Ro,t),Jn=e|t.baseLanes}function ld(){we(Sc,Jn),we(Ro,Ro.current)}function pf(){Jn=Sc.current,We(Ro),We(Sc)}var nt=zn(null),st=null;function Eo(e){var t=e.alternate;we(et,et.current&1),we(nt,e),st===null&&(t===null||Ro.current!==null||t.memoizedState!==null)&&(st=e)}function cd(e){we(et,et.current),we(nt,e),st===null&&(st=e)}function ph(e){e.tag===22?(we(et,et.current),we(nt,e),st===null&&(st=e)):To()}function To(){we(et,et.current),we(nt,nt.current)}function Ot(e){We(nt),st===e&&(st=null),We(et)}var et=zn(0);function Rr(e,t){we(nt,nt.current),we(et,t)}function mf(e){We(et),We(nt),st===e&&(st=null)}function Ec(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||Vd(n)||Yf(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!=="independent"){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Zn=0,Q=null,me=null,Be=null,Tc=!1,ci=!1,fa=!1,Cc=0,Dr=0,si=null,bw=0;function ze(){throw Error(C(321))}function gf(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Ut(e[n],t[n]))return!1;return!0}function bf(e,t,n,o,a,i){return Zn=i,Q=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,Y.H=e===null||e.memoizedState===null?Xh:Gh,fa=!1,i=n(o,a),fa=!1,ci&&(i=gh(t,n,o,a)),mh(e),i}function mh(e){Y.H=Nc;var t=me!==null&&me.next!==null;if(Zn=0,Be=me=Q=null,Tc=!1,Dr=0,si=null,t)throw Error(C(300));e===null||Ue||(e=e.dependencies,e!==null&&kc(e)&&(Ue=!0))}function gh(e,t,n,o){Q=e;var a=0;do{if(ci&&(si=null),Dr=0,ci=!1,25<=a)throw Error(C(301));if(a+=1,Be=me=null,e.updateQueue!=null){var i=e.updateQueue;i.lastEffect=null,i.events=null,i.stores=null,i.memoCache!=null&&(i.memoCache.index=0)}Y.H=Ew,i=t(n,o)}while(ci);return i}function hw(){var e=Y.H,t=e.useState()[0];return t=typeof t.then=="function"?Pr(t):t,e=e.useState()[0],(me!==null?me.memoizedState:null)!==e&&(Q.flags|=1024),t}function hf(){var e=Cc!==0;return Cc=0,e}function vf(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function yf(e){if(Tc){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Tc=!1}Zn=0,Be=me=Q=null,ci=!1,Dr=Cc=0,si=null}function gt(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Be===null?Q.memoizedState=Be=e:Be=Be.next=e,Be}function Re(){if(me===null){var e=Q.alternate;e=e!==null?e.memoizedState:null}else e=me.next;var t=Be===null?Q.memoizedState:Be.next;if(t!==null)Be=t,me=e;else{if(e===null)throw Q.alternate===null?Error(C(467)):Error(C(310));me=e,e={memoizedState:me.memoizedState,baseState:me.baseState,baseQueue:me.baseQueue,queue:me.queue,next:null},Be===null?Q.memoizedState=Be=e:Be=Be.next=e}return Be}function Jc(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Pr(e){var t=Dr;return Dr+=1,si===null&&(si=[]),e=ch(si,e,t),t=Q,(Be===null?t.memoizedState:Be.next)===null&&(t=t.alternate,Y.H=t===null||t.memoizedState===null?Xh:Gh),e}function Ic(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Pr(e);if(e.$$typeof===Fx)return;if(e.$$typeof===Sn)return Fe(e)}throw Error(C(438,String(e)))}function xf(e){var t=null,n=Q.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var o=Q.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(t={data:o.data.map(function(a){return a.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),n===null&&(n=Jc(),Q.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),o=0;o<e;o++)n[o]=Ix;return t.index++,n}function Pn(e,t){return typeof t=="function"?t(e):t}function ec(e){var t=Re();return kf(t,me,e)}function kf(e,t,n){var o=e.queue;if(o===null)throw Error(C(311));o.lastRenderedReducer=n;var a=e.baseQueue,i=o.pending;if(i!==null){if(a!==null){var r=a.next;a.next=i.next,i.next=r}t.baseQueue=a=i,o.pending=null}if(i=e.baseState,a===null)e.memoizedState=i;else{t=a.next;var l=r=null,c=null,s=t,p=!1;do{var b=s.lane&-536870913;if(b!==s.lane?(te&b)===b:(Zn&b)===b){var u=s.revertLane;if(u===0)c!==null&&(c=c.next={lane:0,revertLane:0,gesture:null,action:s.action,hasEagerState:s.hasEagerState,eagerState:s.eagerState,next:null}),b===ua&&(p=!0);else if((Zn&u)===u){s=s.next,u===ua&&(p=!0);continue}else b={lane:0,revertLane:s.revertLane,gesture:null,action:s.action,hasEagerState:s.hasEagerState,eagerState:s.eagerState,next:null},c===null?(l=c=b,r=i):c=c.next=b,Q.lanes|=u,_o|=u;b=s.action,fa&&n(i,b),i=s.hasEagerState?s.eagerState:n(i,b)}else u={lane:b,revertLane:s.revertLane,gesture:s.gesture,action:s.action,hasEagerState:s.hasEagerState,eagerState:s.eagerState,next:null},c===null?(l=c=u,r=i):c=c.next=u,Q.lanes|=b,_o|=b;s=s.next}while(s!==null&&s!==t);if(c===null?r=i:c.next=l,!Ut(i,e.memoizedState)&&(Ue=!0,p&&(n=ri,n!==null)))throw n;e.memoizedState=i,e.baseState=r,e.baseQueue=c,o.lastRenderedState=i}return a===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function ku(e){var t=Re(),n=t.queue;if(n===null)throw Error(C(311));n.lastRenderedReducer=e;var o=n.dispatch,a=n.pending,i=t.memoizedState;if(a!==null){n.pending=null;var r=a=a.next;do i=e(i,r.action),r=r.next;while(r!==a);Ut(i,t.memoizedState)||(Ue=!0),t.memoizedState=i,t.baseQueue===null&&(t.baseState=i),n.lastRenderedState=i}return[i,o]}function bh(e,t,n){var o=Q,a=Re(),i=J;if(i){if(n===void 0)throw Error(C(407));n=n()}else n=t();var r=!Ut((me||a).memoizedState,n);if(r&&(a.memoizedState=n,Ue=!0),a=a.queue,wf(yh.bind(null,o,a,e),[e]),e=a.getSnapshot!==t||r||Be!==null&&(Be.memoizedState.tag&1)!==0,bi(e?9:8,{destroy:void 0},vh.bind(null,o,a,n,t),null),e){if(o.flags|=2048,be===null)throw Error(C(349));i||(Zn&127)!==0||hh(o,t,n)}return n}function hh(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=Q.updateQueue,t===null?(t=Jc(),Q.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function vh(e,t,n,o){t.value=n,t.getSnapshot=o,xh(t)&&kh(e)}function yh(e,t,n){return n(function(){xh(t)&&kh(e)})}function xh(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Ut(e,n)}catch{return!0}}function kh(e){var t=va(e,2);t!==null&&St(t,e,2)}function sd(e){var t=gt();if(typeof e=="function"){var n=e;if(e=n(),fa){mo(!0);try{n()}finally{mo(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Pn,lastRenderedState:e},t}function wh(e,t,n,o){return e.baseState=n,kf(e,me,typeof o=="function"?o:Pn)}function vw(e,t,n,o,a){if(Wc(e))throw Error(C(485));if(e=t.action,e!==null){var i={payload:a,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(r){i.listeners.push(r)}};Y.T!==null?n(!0):i.isTransition=!1,o(i),n=t.pending,n===null?(i.next=t.pending=i,Sh(t,i)):(i.next=n.next,t.pending=n.next=i)}}function Sh(e,t){var n=t.action,o=t.payload,a=e.state;if(t.isTransition){var i=Y.T,r={};r.types=i!==null?i.types:null,Y.T=r;try{var l=n(a,o),c=Y.S;c!==null&&c(r,l),ug(e,t,l)}catch(s){ud(e,t,s)}finally{i!==null&&r.types!==null&&(i.types=r.types),Y.T=i}}else try{i=n(a,o),ug(e,t,i)}catch(s){ud(e,t,s)}}function ug(e,t,n){n!==null&&typeof n=="object"&&typeof n.then=="function"?n.then(function(o){dg(e,t,o)},function(o){return ud(e,t,o)}):dg(e,t,n)}function dg(e,t,n){t.status="fulfilled",t.value=n,Eh(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Sh(e,n)))}function ud(e,t,n){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do t.status="rejected",t.reason=n,Eh(t),t=t.next;while(t!==o)}e.action=null}function Eh(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Th(e,t){return t}function fg(e,t){if(J){var n=be.formState;if(n!==null){e:{var o=Q;if(J){if(ke){t:{for(var a=ke,i=It;a.nodeType!==8;){if(!i){a=null;break t}if(a=Ft(a.nextSibling),a===null){a=null;break t}}i=a.data,a=i==="F!"||i==="F"?a:null}if(a){ke=Ft(a.nextSibling),o=a.data==="F!";break e}}Oo(o)}o=!1}o&&(t=n[0])}}return n=gt(),n.memoizedState=n.baseState=t,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Th,lastRenderedState:t},n.queue=o,n=Yh.bind(null,Q,o),o.dispatch=n,o=sd(!1),i=Cf.bind(null,Q,!1,o.queue),o=gt(),a={state:t,dispatch:null,action:e,pending:null},o.queue=a,n=vw.bind(null,Q,a,i,n),a.dispatch=n,o.memoizedState=e,[t,n,!1]}function pg(e){var t=Re();return Ch(t,me,e)}function Ch(e,t,n){if(t=kf(e,t,Th)[0],e=ec(Pn)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var o=Pr(t)}catch(r){throw r===Mi?$c:r}else o=t;t=Re();var a=t.queue,i=a.dispatch;return n!==t.memoizedState&&(Q.flags|=2048,bi(9,{destroy:void 0},yw.bind(null,a,n),null)),[o,i,e]}function yw(e,t){e.action=t}function mg(e){var t=Re(),n=me;if(n!==null)return Ch(t,n,e);Re(),t=t.memoizedState,n=Re();var o=n.queue.dispatch;return n.memoizedState=e,[t,o,!1]}function bi(e,t,n,o){return e={tag:e,create:n,deps:o,inst:t,next:null},t=Q.updateQueue,t===null&&(t=Jc(),Q.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(o=n.next,n.next=e,e.next=o,t.lastEffect=e),e}function Nh(){return Re().memoizedState}function tc(e,t,n,o){var a=gt();Q.flags|=e,a.memoizedState=bi(1|t,{destroy:void 0},n,o===void 0?null:o)}function Fc(e,t,n,o){var a=Re();o=o===void 0?null:o;var i=a.memoizedState.inst;me!==null&&o!==null&&gf(o,me.memoizedState.deps)?a.memoizedState=bi(t,i,n,o):(Q.flags|=e,a.memoizedState=bi(1|t,i,n,o))}function gg(e,t){tc(8390656,8,e,t)}function wf(e,t){Fc(2048,8,e,t)}function xw(e){Q.flags|=4;var t=Q.updateQueue;if(t===null)t=Jc(),Q.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Mh(e){var t=Re().memoizedState;return xw({ref:t,nextImpl:e}),function(){if((ce&2)!==0)throw Error(C(440));return t.impl.apply(void 0,arguments)}}function Ah(e,t){return Fc(4,2,e,t)}function zh(e,t){return Fc(4,4,e,t)}function Oh(e,t){if(typeof t=="function"){e=e();var n=t(e);return function(){typeof n=="function"?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Rh(e,t,n){n=n!=null?n.concat([e]):null,Fc(4,4,Oh.bind(null,t,e),n)}function Sf(){}function Dh(e,t){var n=Re();t=t===void 0?null:t;var o=n.memoizedState;return t!==null&&gf(t,o[1])?o[0]:(n.memoizedState=[e,t],e)}function _h(e,t){var n=Re();t=t===void 0?null:t;var o=n.memoizedState;if(t!==null&&gf(t,o[1]))return o[0];if(o=e(),fa){mo(!0);try{e()}finally{mo(!1)}}return n.memoizedState=[o,t],o}function Ef(e,t,n){return n===void 0||(Zn&1073741824)!==0&&(te&261930)===0?e.memoizedState=t:(e.memoizedState=n,e=Cv(),Q.lanes|=e,_o|=e,n)}function Hh(e,t,n,o){return Ut(n,t)?n:Ro.current!==null?(e=Ef(e,n,o),Ut(e,t)||(Ue=!0),e):(Zn&106)===0||(Zn&1073741824)!==0&&(te&261930)===0?(Ue=!0,e.memoizedState=n):(e=Cv(),Q.lanes|=e,_o|=e,t)}function Bh(e,t,n,o,a){var i=se.p;se.p=i!==0&&8>i?i:8;var r=Y.T,l={};l.types=r!==null?r.types:null,Y.T=l,Cf(e,!1,t,n);try{var c=a(),s=Y.S;if(s!==null&&s(l,c),c!==null&&typeof c=="object"&&typeof c.then=="function"){var p=gw(c,o);yr(e,t,p,Lt(e))}else yr(e,t,o,Lt(e))}catch(b){yr(e,t,{then:function(){},status:"rejected",reason:b},Lt())}finally{se.p=i,r!==null&&l.types!==null&&(r.types=l.types),Y.T=r}}function kw(){}function dd(e,t,n,o){if(e.tag!==5)throw Error(C(476));var a=Lh(e).queue;Bh(e,a,t,na,n===null?kw:function(){return Uh(e),n(o)})}function Lh(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:na,baseState:na,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Pn,lastRenderedState:na},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Pn,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function Uh(e){var t=Lh(e);t.next===null&&(t=e.alternate.memoizedState),yr(e,t.next.queue,{},Lt())}function Tf(){return Fe(Si)}function jh(){return Re().memoizedState}function qh(){return Re().memoizedState}function ww(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=Lt();e=wo(n);var o=So(t,e,n);o!==null&&(St(o,t,n),br(o,t,n)),t={cache:sf()},e.payload=t;return}t=t.return}}function Sw(e,t,n){var o=Lt();n={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},Wc(e)?Vh(t,n):(n=rf(e,t,n,o),n!==null&&(St(n,e,o),Kh(n,t,o)))}function Yh(e,t,n){var o=Lt();yr(e,t,n,o)}function yr(e,t,n,o){var a={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(Wc(e))Vh(t,a);else{var i=e.alternate;if(e.lanes===0&&(i===null||i.lanes===0)&&(i=t.lastRenderedReducer,i!==null))try{var r=t.lastRenderedState,l=i(r,n);if(a.hasEagerState=!0,a.eagerState=l,Ut(l,r))return Zc(e,t,a,0),be===null&&Qc(),!1}catch{}if(n=rf(e,t,a,o),n!==null)return St(n,e,o),Kh(n,t,o),!0}return!1}function Cf(e,t,n,o){if(o={lane:2,revertLane:Lf(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Wc(e)){if(t)throw Error(C(479))}else t=rf(e,n,o,2),t!==null&&St(t,e,2)}function Wc(e){var t=e.alternate;return e===Q||t!==null&&t===Q}function Vh(e,t){ci=Tc=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function Kh(e,t,n){if((n&4194048)!==0){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Nb(e,n)}}var Nc={readContext:Fe,use:Ic,useCallback:ze,useContext:ze,useEffect:ze,useImperativeHandle:ze,useLayoutEffect:ze,useInsertionEffect:ze,useMemo:ze,useReducer:ze,useRef:ze,useState:ze,useDebugValue:ze,useDeferredValue:ze,useTransition:ze,useSyncExternalStore:ze,useId:ze,useHostTransitionStatus:ze,useFormState:ze,useActionState:ze,useOptimistic:ze,useMemoCache:ze,useCacheRefresh:ze,useEffectEvent:ze},Xh={readContext:Fe,use:Ic,useCallback:function(e,t){return gt().memoizedState=[e,t===void 0?null:t],e},useContext:Fe,useEffect:gg,useImperativeHandle:function(e,t,n){n=n!=null?n.concat([e]):null,tc(4194308,4,Oh.bind(null,t,e),n)},useLayoutEffect:function(e,t){return tc(4194308,4,e,t)},useInsertionEffect:function(e,t){tc(4,2,e,t)},useMemo:function(e,t){var n=gt();t=t===void 0?null:t;var o=e();if(fa){mo(!0);try{e()}finally{mo(!1)}}return n.memoizedState=[o,t],o},useReducer:function(e,t,n){var o=gt();if(n!==void 0){var a=n(t);if(fa){mo(!0);try{n(t)}finally{mo(!1)}}}else a=t;return o.memoizedState=o.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:a},o.queue=e,e=e.dispatch=Sw.bind(null,Q,e),[o.memoizedState,e]},useRef:function(e){var t=gt();return e={current:e},t.memoizedState=e},useState:function(e){e=sd(e);var t=e.queue,n=Yh.bind(null,Q,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:Sf,useDeferredValue:function(e,t){var n=gt();return Ef(n,e,t)},useTransition:function(){var e=sd(!1);return e=Bh.bind(null,Q,e.queue,!0,!1),gt().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var o=Q,a=gt();if(J){if(n===void 0)throw Error(C(407));n=n()}else{if(n=t(),be===null)throw Error(C(349));(te&127)!==0||hh(o,t,n)}a.memoizedState=n;var i={value:n,getSnapshot:t};return a.queue=i,gg(yh.bind(null,o,i,e),[e]),o.flags|=2048,bi(9,{destroy:void 0},vh.bind(null,o,i,n,t),null),n},useId:function(){var e=gt(),t=be.identifierPrefix;if(J){var n=Cn,o=Tn;n=(o&~(1<<32-Bt(o)-1)).toString(32)+n,t="_"+t+"R_"+n,n=Cc++,0<n&&(t+="H"+n.toString(32)),t+="_"}else n=bw++,t="_"+t+"r_"+n.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:Tf,useFormState:fg,useActionState:fg,useOptimistic:function(e){var t=gt();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=Cf.bind(null,Q,!0,n),n.dispatch=t,[e,t]},useMemoCache:xf,useCacheRefresh:function(){return gt().memoizedState=ww.bind(null,Q)},useEffectEvent:function(e){var t=gt(),n={impl:e};return t.memoizedState=n,function(){if((ce&2)!==0)throw Error(C(440));return n.impl.apply(void 0,arguments)}}},Gh={readContext:Fe,use:Ic,useCallback:Dh,useContext:Fe,useEffect:wf,useImperativeHandle:Rh,useInsertionEffect:Ah,useLayoutEffect:zh,useMemo:_h,useReducer:ec,useRef:Nh,useState:function(){return ec(Pn)},useDebugValue:Sf,useDeferredValue:function(e,t){var n=Re();return Hh(n,me.memoizedState,e,t)},useTransition:function(){var e=ec(Pn)[0],t=Re().memoizedState;return[typeof e=="boolean"?e:Pr(e),t]},useSyncExternalStore:bh,useId:jh,useHostTransitionStatus:Tf,useFormState:pg,useActionState:pg,useOptimistic:function(e,t){var n=Re();return wh(n,me,e,t)},useMemoCache:xf,useCacheRefresh:qh,useEffectEvent:Mh},Ew={readContext:Fe,use:Ic,useCallback:Dh,useContext:Fe,useEffect:wf,useImperativeHandle:Rh,useInsertionEffect:Ah,useLayoutEffect:zh,useMemo:_h,useReducer:ku,useRef:Nh,useState:function(){return ku(Pn)},useDebugValue:Sf,useDeferredValue:function(e,t){var n=Re();return me===null?Ef(n,e,t):Hh(n,me.memoizedState,e,t)},useTransition:function(){var e=ku(Pn)[0],t=Re().memoizedState;return[typeof e=="boolean"?e:Pr(e),t]},useSyncExternalStore:bh,useId:jh,useHostTransitionStatus:Tf,useFormState:mg,useActionState:mg,useOptimistic:function(e,t){var n=Re();return me!==null?wh(n,me,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:xf,useCacheRefresh:qh,useEffectEvent:Mh};function wu(e,t,n,o){t=e.memoizedState,n=n(o,t),n=n==null?t:he({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var fd={enqueueSetState:function(e,t,n){e=e._reactInternals;var o=Lt(),a=wo(o);a.payload=t,n!=null&&(a.callback=n),t=So(e,a,o),t!==null&&(St(t,e,o),br(t,e,o))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var o=Lt(),a=wo(o);a.tag=1,a.payload=t,n!=null&&(a.callback=n),t=So(e,a,o),t!==null&&(St(t,e,o),br(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Lt(),o=wo(n);o.tag=2,t!=null&&(o.callback=t),t=So(e,o,n),t!==null&&(St(t,e,n),br(t,e,n))}};function bg(e,t,n,o,a,i,r){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,i,r):t.prototype&&t.prototype.isPureReactComponent?!Mr(n,o)||!Mr(a,i):!0}function hg(e,t,n,o){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,o),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,o),t.state!==e&&fd.enqueueReplaceState(t,t.state,null)}function pa(e,t){var n=t;if("ref"in t){n={};for(var o in t)o!=="ref"&&(n[o]=t[o])}if(e=e.defaultProps){n===t&&(n=he({},n));for(var a in e)n[a]===void 0&&(n[a]=e[a])}return n}function Qh(e){hc(e)}function Zh(e){console.error(e)}function Ph(e){hc(e)}function Mc(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(o){setTimeout(function(){throw o})}}function vg(e,t,n){try{var o=e.onCaughtError;o(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(a){setTimeout(function(){throw a})}}function pd(e,t,n){return n=wo(n),n.tag=3,n.payload={element:null},n.callback=function(){Mc(e,t)},n}function $h(e){return e=wo(e),e.tag=3,e}function Jh(e,t,n,o){var a=n.type.getDerivedStateFromError;if(typeof a=="function"){var i=o.value;e.payload=function(){return a(i)},e.callback=function(){vg(t,n,o)}}var r=n.stateNode;r!==null&&typeof r.componentDidCatch=="function"&&(e.callback=function(){vg(t,n,o),typeof a!="function"&&(Co===null?Co=new Set([this]):Co.add(this));var l=o.stack;this.componentDidCatch(o.value,{componentStack:l!==null?l:""})})}function Tw(e,t,n,o,a){if(n.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(t=n.alternate,t!==null&&ca(t,n,a,!0),n=nt.current,n!==null){switch(n.tag){case 31:case 13:case 19:return st===null?Bc():n.alternate===null&&Oe===0&&(Oe=3),n.flags&=-257,n.flags|=65536,n.lanes=a,o===wc?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([o]):t.add(o),Au(e,o,a)),!1;case 22:return n.flags|=65536,o===wc?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([o])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([o]):n.add(o)),Au(e,o,a)),!1}throw Error(C(435,n.tag))}return Au(e,o,a),Bc(),!1}if(J)return t=nt.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=a,o!==td&&(e=Error(C(422),{cause:o}),zr(Jt(e,n)))):(o!==td&&(t=Error(C(423),{cause:o}),zr(Jt(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,o=Jt(o,n),a=pd(e.stateNode,o,a),xu(e,a),Oe!==4&&(Oe=2)),!1;var i=Error(C(520),{cause:o});if(i=Jt(i,n),Sr===null?Sr=[i]:Sr.push(i),Oe!==4&&(Oe=2),t===null)return!0;o=Jt(o,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=pd(n.stateNode,o,e),xu(n,e),!1;case 1:if(t=n.type,i=n.stateNode,(n.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||i!==null&&typeof i.componentDidCatch=="function"&&(Co===null||!Co.has(i))))return n.flags|=65536,a&=-a,n.lanes|=a,a=$h(a),Jh(a,e,n,o),xu(n,a),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var Nf=Error(C(461)),Ue=!1;function Ye(e,t,n,o){t.child=e===null?uh(t,null,n,o):da(t,e.child,n,o)}function yg(e,t,n,o,a){n=n.render;var i=t.ref;if("ref"in o){var r={};for(var l in o)l!=="ref"&&(r[l]=o[l])}else r=o;return sa(t),o=bf(e,t,n,r,i,a),l=hf(),e!==null&&!Ue?(vf(e,t,a),$n(e,t,a)):(J&&l&&Pc(t),t.flags|=1,Ye(e,t,o,a),t.child)}function xg(e,t,n,o,a){if(e===null){var i=n.type;return typeof i=="function"&&!lf(i)&&i.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=i,Ih(e,t,i,o,a)):(e=Il(n.type,null,o,t,t.mode,a),e.ref=t.ref,e.return=t,t.child=e)}if(i=e.child,!Af(e,a)){var r=i.memoizedProps;if(n=n.compare,n=n!==null?n:Mr,n(r,o)&&e.ref===t.ref)return $n(e,t,a)}return t.flags|=1,e=Kn(i,o),e.ref=t.ref,e.return=t,t.child=e}function Ih(e,t,n,o,a){if(e!==null){var i=e.memoizedProps;if(Mr(i,o)&&e.ref===t.ref)if(Ue=!1,t.pendingProps=o=i,Af(e,a))(e.flags&131072)!==0&&(Ue=!0);else return t.lanes=e.lanes,$n(e,t,a)}return md(e,t,n,o,a)}function Fh(e,t,n,o){var a=o.children,i=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((t.flags&128)!==0){if(i=i!==null?i.baseLanes|n:n,e!==null){for(o=t.child=e.child,a=0;o!==null;)a=a|o.lanes|o.childLanes,o=o.sibling;o=a&~i}else o=0,t.child=null;return kg(e,t,i,n,o)}if((n&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Wl(t,i!==null?i.cachePool:null),i!==null?sg(t,i):ld(),ph(t);else return o=t.lanes=536870912,kg(e,t,i!==null?i.baseLanes|n:n,n,o)}else i!==null?(Wl(t,i.cachePool),sg(t,i),To(),t.memoizedState=null):(e!==null&&Wl(t,null),ld(),To());return Ye(e,t,a,n),t.child}function xr(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function kg(e,t,n,o,a){var i=uf();return i=i===null?null:{parent:Le._currentValue,pool:i},t.memoizedState={baseLanes:n,cachePool:i},e!==null&&Wl(t,null),ld(),ph(t),e!==null&&ca(e,t,o,!0),t.childLanes=a,null}function nc(e,t){return t=es({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function wg(e,t,n){return da(t,e.child,null,n),e=nc(t,t.pendingProps),e.flags|=2,Ot(t),t.memoizedState=null,e}function Cw(e,t,n){var o=t.pendingProps,a=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(J){if(o.mode==="hidden")return e=nc(t,o),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},xr(null,e);if(cd(t),(e=ke)?(e=Fv(e,It),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:zo!==null?{id:Tn,overflow:Cn}:null,retryLane:536870912,hydrationErrors:null},n=oh(e),n.return=t,t.child=n,Pe=t,ke=null)):e=null,e===null)throw Oo(t);return t.lanes=536870912,null}return nc(t,o)}var i=e.memoizedState;if(i!==null){var r=i.dehydrated;if(cd(t),a)if(t.flags&256)t.flags&=-257,t=wg(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(C(558));else if(Ue||ca(e,t,n,!1),a=(n&e.childLanes)!==0,Ue||a){if(Ro.current===null){if(o=be,o!==null&&(r=Mb(o,n),r!==0&&r!==i.retryLane))throw i.retryLane=r,va(e,r),St(o,e,r),Nf;Bc()}t=wg(e,t,n)}else e=i.treeContext,ke=Ft(r.nextSibling),Pe=t,J=!0,ko=null,It=!1,e!==null&&ih(t,e),t=nc(t,o),t.flags|=134221824;return t}return e=Kn(e.child,{mode:o.mode,children:o.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Va(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!="function"&&typeof n!="object")throw Error(C(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function md(e,t,n,o,a){return sa(t),n=bf(e,t,n,o,void 0,a),o=hf(),e!==null&&!Ue?(vf(e,t,a),$n(e,t,a)):(J&&o&&Pc(t),t.flags|=1,Ye(e,t,n,a),t.child)}function Sg(e,t,n,o,a,i){return sa(t),t.updateQueue=null,n=gh(t,o,n,a),mh(e),o=hf(),e!==null&&!Ue?(vf(e,t,i),$n(e,t,i)):(J&&o&&Pc(t),t.flags|=1,Ye(e,t,n,i),t.child)}function Eg(e,t,n,o,a){if(sa(t),t.stateNode===null){var i=Wa,r=n.contextType;typeof r=="object"&&r!==null&&(i=Fe(r)),i=new n(o,i),t.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=fd,t.stateNode=i,i._reactInternals=t,i=t.stateNode,i.props=o,i.state=t.memoizedState,i.refs={},ff(t),r=n.contextType,i.context=typeof r=="object"&&r!==null?Fe(r):Wa,i.state=t.memoizedState,r=n.getDerivedStateFromProps,typeof r=="function"&&(wu(t,n,r,o),i.state=t.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof i.getSnapshotBeforeUpdate=="function"||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(r=i.state,typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount(),r!==i.state&&fd.enqueueReplaceState(i,i.state,null),vr(t,o,i,a),hr(),i.state=t.memoizedState),typeof i.componentDidMount=="function"&&(t.flags|=4194308),o=!0}else if(e===null){i=t.stateNode;var l=t.memoizedProps,c=pa(n,l);i.props=c;var s=i.context,p=n.contextType;r=Wa,typeof p=="object"&&p!==null&&(r=Fe(p));var b=n.getDerivedStateFromProps;p=typeof b=="function"||typeof i.getSnapshotBeforeUpdate=="function",l=t.pendingProps!==l,p||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(l||s!==r)&&hg(t,i,o,r),fo=!1;var u=t.memoizedState;i.state=u,vr(t,o,i,a),hr(),s=t.memoizedState,l||u!==s||fo?(typeof b=="function"&&(wu(t,n,b,o),s=t.memoizedState),(c=fo||bg(t,n,c,o,u,s,r))?(p||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount()),typeof i.componentDidMount=="function"&&(t.flags|=4194308)):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=o,t.memoizedState=s),i.props=o,i.state=s,i.context=r,o=c):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),o=!1)}else{i=t.stateNode,id(e,t),r=t.memoizedProps,p=pa(n,r),i.props=p,b=t.pendingProps,u=i.context,s=n.contextType,c=Wa,typeof s=="object"&&s!==null&&(c=Fe(s)),l=n.getDerivedStateFromProps,(s=typeof l=="function"||typeof i.getSnapshotBeforeUpdate=="function")||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(r!==b||u!==c)&&hg(t,i,o,c),fo=!1,u=t.memoizedState,i.state=u,vr(t,o,i,a),hr();var d=t.memoizedState;r!==b||u!==d||fo||e!==null&&e.dependencies!==null&&kc(e.dependencies)?(typeof l=="function"&&(wu(t,n,l,o),d=t.memoizedState),(p=fo||bg(t,n,p,o,u,d,c)||e!==null&&e.dependencies!==null&&kc(e.dependencies))?(s||typeof i.UNSAFE_componentWillUpdate!="function"&&typeof i.componentWillUpdate!="function"||(typeof i.componentWillUpdate=="function"&&i.componentWillUpdate(o,d,c),typeof i.UNSAFE_componentWillUpdate=="function"&&i.UNSAFE_componentWillUpdate(o,d,c)),typeof i.componentDidUpdate=="function"&&(t.flags|=4),typeof i.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof i.componentDidUpdate!="function"||r===e.memoizedProps&&u===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||r===e.memoizedProps&&u===e.memoizedState||(t.flags|=1024),t.memoizedProps=o,t.memoizedState=d),i.props=o,i.state=d,i.context=c,o=p):(typeof i.componentDidUpdate!="function"||r===e.memoizedProps&&u===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||r===e.memoizedProps&&u===e.memoizedState||(t.flags|=1024),o=!1)}return i=o,Va(e,t),o=(t.flags&128)!==0,i||o?(i=t.stateNode,n=o&&typeof n.getDerivedStateFromError!="function"?null:i.render(),t.flags|=1,e!==null&&o?(t.child=da(t,e.child,null,a),t.child=da(t,null,n,a)):Ye(e,t,n,a),t.memoizedState=i.state,e=t.child):e=$n(e,t,a),e}function Tg(e,t,n,o){return la(),t.flags|=256,Ye(e,t,n,o),t.child}var gd={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function bd(e){return{baseLanes:e,cachePool:lh()}}function hd(e,t,n){return e=e!==null?e.childLanes&~n:0,t&&(e|=Dt),e}function Wh(e,t,n){var o=t.pendingProps,a=!1,i=(t.flags&128)!==0,r;if((r=i)||(r=e!==null&&e.memoizedState===null?!1:(et.current&2)!==0),r&&(a=!0,t.flags&=-129),r=(t.flags&32)!==0,t.flags&=-33,e===null){if(J){if(a?Eo(t):To(),(e=ke)?(e=Fv(e,It),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:zo!==null?{id:Tn,overflow:Cn}:null,retryLane:536870912,hydrationErrors:null},n=oh(e),n.return=t,t.child=n,Pe=t,ke=null)):e=null,e===null)throw Oo(t);return Yf(e)?t.lanes=32:t.lanes=536870912,null}return i=o.children,o=o.fallback,a?(To(),a=t.mode,i=es({mode:"hidden",children:i},a),o=oa(o,a,n,null),i.return=t,o.return=t,i.sibling=o,t.child=i,o=t.child,o.memoizedState=bd(n),o.childLanes=hd(e,r,n),t.memoizedState=gd,xr(null,o)):(Eo(t),Mf(t,i))}var l=e.memoizedState;if(l!==null){var c=l.dehydrated;if(c!==null)return Nw(e,t,i,r,o,c,l,n)}return a?(To(),a=o.fallback,i=t.mode,l=e.child,c=l.sibling,o=Kn(l,{mode:"hidden",children:o.children}),o.subtreeFlags=l.subtreeFlags&1206910976,c!==null?a=Kn(c,a):(a=oa(a,i,n,null),a.flags|=2),a.return=t,o.return=t,o.sibling=a,t.child=o,xr(null,o),o=t.child,a=e.child.memoizedState,a===null?a=bd(n):(i=a.cachePool,i!==null?(l=Le._currentValue,i=i.parent!==l?{parent:l,pool:l}:i):i=lh(),a={baseLanes:a.baseLanes|n,cachePool:i}),o.memoizedState=a,o.childLanes=hd(e,r,n),t.memoizedState=gd,xr(e.child,o)):(Eo(t),n=e.child,e=n.sibling,n=Kn(n,{mode:"visible",children:o.children}),n.return=t,n.sibling=null,e!==null&&(r=t.deletions,r===null?(t.deletions=[e],t.flags|=16):r.push(e)),t.child=n,t.memoizedState=null,n)}function Mf(e,t){return t=es({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function es(e,t){return e=wt(22,e,null,t),e.lanes=0,e}function Ll(e,t,n){return da(t,e.child,null,n),e=Mf(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function Nw(e,t,n,o,a,i,r,l){if(n)return t.flags&256?(Eo(t),t.flags&=-257,Ll(e,t,l)):t.memoizedState!==null?(To(),t.child=e.child,t.flags|=128,null):(To(),i=a.fallback,r=t.mode,a=es({mode:"visible",children:a.children},r),i=oa(i,r,l,null),i.flags|=2,a.return=t,i.return=t,a.sibling=i,t.child=a,da(t,e.child,null,l),a=t.child,a.memoizedState=bd(l),a.childLanes=hd(e,o,l),t.memoizedState=gd,xr(null,a));if(Eo(t),Yf(i)){if(o=i.nextSibling&&i.nextSibling.dataset,o)var c=o.dgst;return o=c,o!==""&&(a=Error(C(419)),a.stack="",a.digest=o,zr({value:a,source:null,stack:null})),Ll(e,t,l)}if(Ue||ca(e,t,l,!1),o=(l&e.childLanes)!==0,Ue||o){if(Ro.current!==null)return Ll(e,t,l);if(o=be,o!==null&&(a=Mb(o,l),a!==0&&a!==r.retryLane))throw r.retryLane=a,va(e,a),St(o,e,a),Nf;return Vd(i)||Bc(),Ll(e,t,l)}return Vd(i)?(t.flags|=192,t.child=e.child,null):(e=r.treeContext,ke=Ft(i.nextSibling),Pe=t,J=!0,ko=null,It=!1,e!==null&&ih(t,e),t=Mf(t,a.children),t.flags|=134221824,t)}function Cg(e,t,n){e.lanes|=t;var o=e.alternate;o!==null&&(o.lanes|=t),Fl(e.return,t,n)}function Ng(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&Ec(n)===null&&(t=e),e=e.sibling}return t}function Ul(e,t,n,o,a,i){var r=e.memoizedState;r===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:o,tail:n,tailMode:a,treeForkCount:i}:(r.isBackwards=t,r.rendering=null,r.renderingStartTime=0,r.last=o,r.tail=n,r.tailMode=a,r.treeForkCount=i)}function Su(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function vd(e,t,n){var o=t.pendingProps,a=o.revealOrder,i=o.tail;o=o.children;var r=et.current;if(t.flags&128)return Rr(t,r),null;var l=(r&2)!==0;if(l?(r=r&1|2,t.flags|=128):r&=1,Rr(t,r),a==="backwards"&&e!==null?(Su(e),Ye(e,t,o,n),Su(e)):Ye(e,t,o,n),o=J?Ar:0,!l&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Cg(e,n,t);else if(e.tag===19)Cg(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(a){case"backwards":n=Ng(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null,Su(t)),Ul(t,!0,a,null,i,o);break;case"unstable_legacy-backwards":for(n=null,a=t.child,t.child=null;a!==null;){if(e=a.alternate,e!==null&&Ec(e)===null){t.child=a;break}e=a.sibling,a.sibling=n,n=a,a=e}Ul(t,!0,n,null,i,o);break;case"together":Ul(t,!1,null,null,void 0,o);break;case"independent":t.memoizedState=null;break;default:n=Ng(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null),Ul(t,!1,a,n,i,o)}return t.child}function Mg(e,t,n){var o=t.pendingProps;return bo(t,t.type,o.value),Ye(e,t,o.children,n),t.child}function $n(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),_o|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(ca(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(C(153));if(t.child!==null){for(e=t.child,n=Kn(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Kn(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function Af(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&kc(e)))}function Mw(e,t,n){switch(t.tag){case 3:pc(t,t.stateNode.containerInfo),bo(t,Le,e.memoizedState.cache),la();break;case 27:case 5:Gu(t);break;case 4:pc(t,t.stateNode.containerInfo);break;case 10:bo(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,cd(t),null;break;case 13:var o=t.memoizedState;if(o!==null){if(o.dehydrated!==null)return Eo(t),t.flags|=128,null;o=ca(e,t,n,!1);var a=t.child.childLanes;return o||(n&a)!==0?Wh(e,t,n):(Eo(t),e=$n(e,t,n),e!==null?e.sibling:null)}Eo(t);break;case 19:if(t.flags&128)return vd(e,t,n);if(a=(e.flags&128)!==0,o=(n&t.childLanes)!==0,o||(ca(e,t,n,!1),o=(n&t.childLanes)!==0),a){if(o)return vd(e,t,n);t.flags|=128}if(a=t.memoizedState,a!==null&&(a.rendering=null,a.tail=null,a.lastEffect=null),Rr(t,et.current),o)break;return null;case 22:return t.lanes=0,Fh(e,t,n,t.pendingProps);case 24:bo(t,Le,e.memoizedState.cache)}return $n(e,t,n)}function ev(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)Ue=!0;else{if(!Af(e,n)&&(t.flags&128)===0)return Ue=!1,Mw(e,t,n);Ue=(e.flags&131072)!==0}else Ue=!1,J&&(t.flags&1048576)!==0&&ah(t,Ar,t.index);switch(t.lanes=0,t.tag){case 16:e:{var o=t.pendingProps;if(e=Fo(t.elementType),t.type=e,typeof e=="function")lf(e)?(o=pa(e,o),t.tag=1,t=Eg(null,t,e,o,n)):(t.tag=0,t=md(null,t,e,o,n));else{if(e!=null){var a=e.$$typeof;if(a===Zd){t.tag=11,t=yg(null,t,e,o,n);break e}else if(a===Pd){t.tag=14,t=xg(null,t,e,o,n);break e}else if(a===Sn){t.tag=10,t.type=e,t=Mg(null,t,n);break e}}throw t=Ku(e)||e,Error(C(306,t,""))}}return t;case 0:return md(e,t,t.type,t.pendingProps,n);case 1:return o=t.type,a=pa(o,t.pendingProps),Eg(e,t,o,a,n);case 3:e:{if(pc(t,t.stateNode.containerInfo),e===null)throw Error(C(387));o=t.pendingProps;var i=t.memoizedState;a=i.element,id(e,t),vr(t,o,null,n);var r=t.memoizedState;if(o=r.cache,bo(t,Le,o),o!==i.cache&&od(t,[Le],n,!0),hr(),o=r.element,i.isDehydrated)if(i={element:o,isDehydrated:!1,cache:r.cache},t.updateQueue.baseState=i,t.memoizedState=i,t.flags&256){t=Tg(e,t,o,n);break e}else if(o!==a){a=Jt(Error(C(424)),t),zr(a),t=Tg(e,t,o,n);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,ke=Ft(e.firstChild),Pe=t,J=!0,ko=null,It=!0,n=uh(t,null,o,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling;else{if(la(),o===a){t=$n(e,t,n);break e}Ye(e,t,o,n)}t=t.child}return t;case 26:return Va(e,t),e===null?(n=tb(t.type,null,t.pendingProps,null))?t.memoizedState=n:J||(t.stateNode=Kv(t.type,t.pendingProps,xo.current,t)):t.memoizedState=tb(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return Gu(t),e===null&&J&&(o=t.stateNode=Wv(t.type,t.pendingProps,xo.current),Pe=t,It=!0,a=ke,Bo(t.type)?(Kd=a,ke=Ft(o.firstChild)):ke=a),Ye(e,t,t.pendingProps.children,n),Va(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&J&&((a=o=ke)&&(o=xS(o,t.type,t.pendingProps,It),o!==null?(t.stateNode=o,Pe=t,ke=Ft(o.firstChild),It=!1,a=!0):a=!1),a||Oo(t)),Gu(t),a=t.type,i=t.pendingProps,r=e!==null?e.memoizedProps:null,o=i.children,jd(a,i)?o=null:r!==null&&jd(a,r)&&(t.flags|=32),t.memoizedState!==null&&(a=bf(e,t,hw,null,null,n),Si._currentValue=a),Va(e,t),Ye(e,t,o,n),t.child;case 6:return e===null&&J&&((e=n=ke)&&(n=kS(n,t.pendingProps,It),n!==null?(t.stateNode=n,Pe=t,ke=null,e=!0):e=!1),e||Oo(t)),null;case 13:return Wh(e,t,n);case 4:return pc(t,t.stateNode.containerInfo),o=t.pendingProps,e===null?t.child=da(t,null,o,n):Ye(e,t,o,n),t.child;case 11:return yg(e,t,t.type,t.pendingProps,n);case 7:return o=t.pendingProps,Va(e,t),Ye(e,t,o,n),t.child;case 8:return Ye(e,t,t.pendingProps.children,n),t.child;case 12:return Ye(e,t,t.pendingProps.children,n),t.child;case 10:return Mg(e,t,n);case 9:return a=t.type._context,o=t.pendingProps.children,sa(t),a=Fe(a),o=o(a),t.flags|=1,Ye(e,t,o,n),t.child;case 14:return xg(e,t,t.type,t.pendingProps,n);case 15:return Ih(e,t,t.type,t.pendingProps,n);case 19:return vd(e,t,n);case 31:return Cw(e,t,n);case 22:return Fh(e,t,n,t.pendingProps);case 24:return sa(t),o=Fe(Le),e===null?(a=uf(),a===null&&(a=be,i=sf(),a.pooledCache=i,i.refCount++,i!==null&&(a.pooledCacheLanes|=n),a=i),t.memoizedState={parent:o,cache:a},ff(t),bo(t,Le,a)):((e.lanes&n)!==0&&(id(e,t),vr(t,null,null,n),hr()),a=e.memoizedState,i=t.memoizedState,a.parent!==o?(a={parent:o,cache:o},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),bo(t,Le,o)):(o=i.cache,bo(t,Le,o),o!==a.cache&&od(t,[Le],n,!0))),Ye(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),o=t.pendingProps,o.name!=null&&o.name!=="auto"?t.flags|=e===null?18882560:18874368:J&&Pc(t),e!==null&&e.memoizedProps.name!==o.name?t.flags|=4194816:Va(e,t),Ye(e,t,o.children,n),t.child;case 29:throw t.pendingProps}throw Error(C(156,t.tag))}function qn(e){e.flags|=4}function Eu(e,t,n,o,a){var i;if((i=(e.mode&32)!==0)&&(i=n===null?ab(t,o):ab(t,o)&&(o.src!==n.src||o.srcSet!==n.srcSet)),i){if(e.flags|=16777216,(a&335544128)===a)if(e.stateNode.complete)e.flags|=8192;else if(Av())e.flags|=8192;else throw ia=wc,df}else e.flags&=-16777217}function Ag(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!o0(t))if(Av())e.flags|=8192;else throw ia=wc,df}function jl(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?Tb():536870912,e.lanes|=t,hi|=t)}function or(e,t){if(!J)switch(e.tailMode){case"visible":break;case"collapsed":for(var n=e.tail,o=null;n!==null;)n.alternate!==null&&(o=n),n=n.sibling;o===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function xe(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,o=0;if(t)for(var a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags&1206910976,o|=a.flags&1206910976,a.return=e,a=a.sibling;else for(a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags,o|=a.flags,a.return=e,a=a.sibling;return e.subtreeFlags|=o,e.childLanes=n,t}function Aw(e,t,n){var o=t.pendingProps;switch(cf(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return xe(t),null;case 1:return xe(t),null;case 3:return n=t.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),t.memoizedState.cache!==o&&(t.flags|=2048),Xn(Le),pi(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(qa(t)?qn(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,yu())),xe(t),null;case 26:var a=t.type,i=t.memoizedState;return e===null?(qn(t),i!==null?(xe(t),Ag(t,i)):(xe(t),Eu(t,a,null,o,n))):i?i!==e.memoizedState?(qn(t),xe(t),Ag(t,i)):(xe(t),t.flags&=-16777217):(e=e.memoizedProps,e!==o&&qn(t),xe(t),Eu(t,a,e,o,n)),null;case 27:if(mc(t),n=xo.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&qn(t);else{if(!o){if(t.stateNode===null)throw Error(C(166));return xe(t),t.subtreeFlags&=-33554433,null}e=Nn.current,qa(t)?ng(t,e):(e=Wv(a,o,n),t.stateNode=e,qn(t))}return xe(t),t.subtreeFlags&=-33554433,null;case 5:if(mc(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&qn(t);else{if(!o){if(t.stateNode===null)throw Error(C(166));return xe(t),t.subtreeFlags&=-33554433,null}if(i=Nn.current,qa(t))ng(t,i);else{var r=Br(xo.current);switch(i){case 1:i=r.createElementNS("http://www.w3.org/2000/svg",a);break;case 2:i=r.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;default:switch(a){case"svg":i=r.createElementNS("http://www.w3.org/2000/svg",a);break;case"math":i=r.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;case"script":i=r.createElement("div"),i.innerHTML="<script><\/script>",i=i.removeChild(i.firstChild);break;case"select":i=typeof o.is=="string"?r.createElement("select",{is:o.is}):r.createElement("select"),o.multiple?i.multiple=!0:o.size&&(i.size=o.size);break;default:i=typeof o.is=="string"?r.createElement(a,{is:o.is}):r.createElement(a)}}i[Ie]=t,i[Tt]=o;e:for(r=t.child;r!==null;){if(r.tag===5||r.tag===6)i.appendChild(r.stateNode);else if(r.tag!==4&&r.tag!==27&&r.child!==null){r.child.return=r,r=r.child;continue}if(r===t)break e;for(;r.sibling===null;){if(r.return===null||r.return===t)break e;r=r.return}r.sibling.return=r.return,r=r.sibling}t.stateNode=i;e:switch(tt(i,a,o),a){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&qn(t)}}return xe(t),t.subtreeFlags&=-33554433,Eu(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==o&&qn(t);else{if(typeof o!="string"&&t.stateNode===null)throw Error(C(166));if(e=xo.current,qa(t)){if(e=t.stateNode,n=t.memoizedProps,o=null,a=Pe,a!==null)switch(a.tag){case 27:case 5:o=a.memoizedProps}e[Ie]=t,e=!!(e.nodeValue===n||o!==null&&o.suppressHydrationWarning===!0||Yv(e.nodeValue,n)),e||Oo(t,!0)}else e=Br(e).createTextNode(o),e[Ie]=t,t.stateNode=e}return xe(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(o=qa(t),n!==null){if(e===null){if(!o)throw Error(C(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(C(557));e[Ie]=t}else la(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;xe(t),e=!1}else n=yu(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(Ot(t),t):(Ot(t),null);if((t.flags&128)!==0)throw Error(C(558))}return xe(t),null;case 13:if(o=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=qa(t),o!==null&&o.dehydrated!==null){if(e===null){if(!a)throw Error(C(318));if(a=t.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(C(317));a[Ie]=t}else la(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;xe(t),a=!1}else a=yu(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(Ot(t),t):(Ot(t),null)}return Ot(t),(t.flags&128)!==0?(t.lanes=n,t):(n=o!==null,e=e!==null&&e.memoizedState!==null,n&&(o=t.child,a=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(a=o.alternate.memoizedState.cachePool.pool),i=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(i=o.memoizedState.cachePool.pool),i!==a&&(o.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),jl(t,t.updateQueue),xe(t),null);case 4:return pi(),e===null&&Uf(t.stateNode.containerInfo),t.flags|=67108864,xe(t),null;case 10:return Xn(t.type),xe(t),null;case 19:if(mf(t),o=t.memoizedState,o===null)return xe(t),null;if(a=(t.flags&128)!==0,i=o.rendering,i===null)if(a)or(o,!1);else{if(Oe!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(i=Ec(e),i!==null){for(t.flags|=128,or(o,!1),e=i.updateQueue,t.updateQueue=e,jl(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)nh(n,e),n=n.sibling;return Rr(t,et.current&1|2),J&&Yn(t,o.treeForkCount),t.child}e=e.sibling}o.tail!==null&&_t()>_c&&(t.flags|=128,a=!0,or(o,!1),t.lanes=4194304)}else{if(!a)if(e=Ec(i),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,jl(t,e),or(o,!0),o.tail===null&&o.tailMode!=="collapsed"&&o.tailMode!=="visible"&&!i.alternate&&!J)return xe(t),null}else 2*_t()-o.renderingStartTime>_c&&n!==536870912&&(t.flags|=128,a=!0,or(o,!1),t.lanes=4194304);o.isBackwards?(i.sibling=t.child,t.child=i):(e=o.last,e!==null?e.sibling=i:t.child=i,o.last=i)}if(o.tail!==null){e=o.tail;e:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break e}n=n.sibling}n=!0}return o.rendering=e,o.tail=e.sibling,o.renderingStartTime=_t(),e.sibling=null,i=et.current,i=a?i&1|2:i&1,o.tailMode==="visible"||o.tailMode==="collapsed"||!n||J?Rr(t,i):(n=i,we(nt,t),we(et,n),st===null&&(st=t)),J&&Yn(t,o.treeForkCount),e}return xe(t),null;case 22:case 23:return Ot(t),pf(),o=t.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(t.flags|=8192):o&&(t.flags|=8192),o?(n&536870912)!==0&&(t.flags&128)===0&&(xe(t),t.subtreeFlags&6&&(t.flags|=8192)):xe(t),n=t.updateQueue,n!==null&&jl(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),o=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),o!==n&&(t.flags|=2048),e!==null&&We(aa),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),Xn(Le),xe(t),null;case 25:return null;case 30:return t.flags|=33554432,xe(t),null}throw Error(C(156,t.tag))}function zw(e,t){switch(cf(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return Xn(Le),pi(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return mc(t),null;case 31:if(t.memoizedState!==null){if(Ot(t),t.alternate===null)throw Error(C(340));la()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(Ot(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(C(340));la()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return mf(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return pi(),null;case 10:return Xn(t.type),null;case 22:case 23:return Ot(t),pf(),e!==null&&We(aa),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return Xn(Le),null;case 25:return null;default:return null}}function tv(e,t){switch(cf(t),t.tag){case 3:Xn(Le),pi();break;case 26:case 27:case 5:mc(t);break;case 4:pi();break;case 31:t.memoizedState!==null&&Ot(t);break;case 13:Ot(t);break;case 19:mf(t);break;case 10:Xn(t.type);break;case 22:case 23:Ot(t),pf(),e!==null&&We(aa);break;case 24:Xn(Le)}}function $r(e,t){try{var n=t.updateQueue,o=n!==null?n.lastEffect:null;if(o!==null){var a=o.next;n=a;do{if((n.tag&e)===e){o=void 0;var i=n.create,r=n.inst;o=i(),r.destroy=o}n=n.next}while(n!==a)}}catch(l){pe(t,t.return,l)}}function Do(e,t,n){try{var o=t.updateQueue,a=o!==null?o.lastEffect:null;if(a!==null){var i=a.next;o=i;do{if((o.tag&e)===e){var r=o.inst,l=r.destroy;if(l!==void 0){r.destroy=void 0,a=t;var c=n,s=l;try{s()}catch(p){pe(a,c,p)}}}o=o.next}while(o!==i)}}catch(p){pe(t,t.return,p)}}function nv(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{fh(t,n)}catch(o){pe(e,e.return,o)}}}function ov(e,t,n){n.props=pa(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(o){pe(e,t,o)}}function kn(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:var a=e.stateNode,i=Qn(e.memoizedProps,a);(a.ref===null||a.ref.name!==i)&&(a.ref=Zv(i)),o=a.ref;break;case 7:if(e.stateNode===null){var r=new jt(e);Et(e.child,!1,vS,r,void 0,void 0),e.stateNode=r}o=e.stateNode;break;default:o=e.stateNode}typeof n=="function"?e.refCleanup=n(o):n.current=o}}catch(l){pe(e,t,l)}}function Je(e,t){var n=e.ref,o=e.refCleanup;if(n!==null)if(typeof o=="function")try{o()}catch(a){pe(e,t,a)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n=="function")try{n(null)}catch(a){pe(e,t,a)}else n.current=null}function Ac(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)Iv(e.stateNode,t[n])}function zg(e){for(var t=e.return;t!==null&&(Of(t)&&Iv(e.stateNode,t.stateNode),!zf(t));)t=t.return}function kr(e){for(var t=e.return;t!==null&&(Of(t)&&yS(e.stateNode,t.stateNode),!zf(t));)t=t.return}function zf(e){return e.tag===5||e.tag===3||e.tag===27}function Of(e){return e&&e.tag===7&&e.stateNode!==null}function yd(e){var t=e.type,n=e.memoizedProps,o=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&o.focus();break e;case"img":n.src?o.src=n.src:n.srcSet&&(o.srcset=n.srcSet)}}catch(a){pe(e,e.return,a)}}function Tu(e,t,n){try{var o=e.stateNode;eS(o,e.type,n,t),o[Tt]=t}catch(a){pe(e,e.return,a)}}function av(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Bo(e.type)||e.tag===4}function Cu(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||av(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Bo(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function xd(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n).insertBefore(a,t):(t=n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.appendChild(a),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=En)),Ac(e,o),re=!0;else if(a!==4&&(a===27&&(Ac(e,o),o=null,Bo(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(xd(e,t,n,o),e=e.sibling;e!==null;)xd(e,t,n,o),e=e.sibling}function zc(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?n.insertBefore(a,t):n.appendChild(a),Ac(e,o),re=!0;else if(a!==4&&(a===27&&(Ac(e,o),o=null,Bo(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(zc(e,t,n,o),e=e.sibling;e!==null;)zc(e,t,n,o),e=e.sibling}function iv(e){var t=e.stateNode,n=e.memoizedProps;try{for(var o=e.type,a=t.attributes;a.length;)t.removeAttributeNode(a[0]);tt(t,o,n),t[Ie]=e,t[Tt]=n}catch(i){pe(e,e.return,i)}}var Oc=!1,Rt=null;function Og(e){(e.tag===30||(e.subtreeFlags&33554432)!==0)&&(Oc=!0)}var wn=null;function Rg(){var e=wn;return wn=null,e}var kt=0;function Ai(e,t,n,o,a){return kt=0,rv(e.child,t,n,o,a)}function rv(e,t,n,o,a){for(var i=!1;e!==null;){if(e.tag===5){var r=e.stateNode;if(o!==null){var l=qd(r);o.push(l),l.view&&(i=!0)}else i||qd(r).view&&(i=!0);Oc=!0,Xv(r,kt===0?t:t+"_"+kt,n),kt++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&a||rv(e.child,t,n,o,a)&&(i=!0));e=e.sibling}return i}function An(e,t){for(;e!==null;)e.tag===5?Gv(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||An(e.child,t)),e=e.sibling}function oc(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(oc(e),e.tag===30&&(e.flags&18874368)!==0&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name==="auto")throw Error(C(544));var n=t.name;t=Fn(t.default,t.share),t!=="none"&&(Ai(e,n,t,null,!1)||An(e.child,!1))}e=e.sibling}}function kd(e,t){if(e.tag===30){var n=e.stateNode,o=e.memoizedProps,a=Qn(o,n),i=Fn(o.default,n.paired?o.share:o.enter);i!=="none"?Ai(e,a,i,null,!1)?(oc(e),n.paired||t||vi(e,o.onEnter)):An(e.child,!1):oc(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)kd(e,t),e=e.sibling;else oc(e)}function wd(e){if(Rt!==null&&Rt.size!==0){var t=Rt;if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var n=e.memoizedProps,o=n.name;if(o!=null&&o!=="auto"){var a=t.get(o);if(a!==void 0){var i=Fn(n.default,n.share);if(i!=="none"&&(Ai(e,o,i,null,!1)?(i=e.stateNode,a.paired=i,i.paired=a,vi(e,n.onShare)):An(e.child,!1)),t.delete(o),t.size===0)break}}}wd(e)}e=e.sibling}}}function Sd(e){if(e.tag===30){var t=e.memoizedProps,n=Qn(t,e.stateNode),o=Rt!==null?Rt.get(n):void 0,a=Fn(t.default,o!==void 0?t.share:t.exit);a!=="none"&&(Ai(e,n,a,null,!1)?o!==void 0?(a=e.stateNode,o.paired=a,a.paired=o,Rt.delete(n),vi(e,t.onShare)):vi(e,t.onExit):An(e.child,!1)),Rt!==null&&wd(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Sd(e),e=e.sibling;else Rt!==null&&wd(e)}function lv(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=Qn(t,e.stateNode);t=Fn(t.default,t.update),e.flags&=-5,t!=="none"&&Ai(e,n,t,e.memoizedState=[],!1)}else(e.subtreeFlags&33554432)!==0&&lv(e);e=e.sibling}}function Ed(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var t=e.stateNode;t.paired!==null&&(t.paired=null,An(e.child,!1))}Ed(e)}e=e.sibling}}function ac(e){if(e.tag===30)e.stateNode.paired=null,An(e.child,!1),Ed(e);else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)ac(e),e=e.sibling;else Ed(e)}function cv(e){for(e=e.child;e!==null;)e.tag===30?An(e.child,!1):(e.subtreeFlags&33554432)!==0&&cv(e),e=e.sibling}function Rf(e,t,n,o,a,i,r){for(var l=!1;t!==null;){if(t.tag===5){var c=t.stateNode;if(i!==null&&kt<i.length){var s=i[kt],p=qd(c);(s.view||p.view)&&(l=!0);var b;if(b=(e.flags&4)===0)if(p.clip)b=!0;else{b=s.rect;var u=p.rect;b=b.y!==u.y||b.x!==u.x||b.height!==u.height||b.width!==u.width}b&&(e.flags|=4),p.abs?p=!s.abs:(s=s.rect,p=p.rect,p=s.height!==p.height||s.width!==p.width),p&&(e.flags|=32)}else e.flags|=32;(e.flags&4)!==0&&Xv(c,kt===0?n:n+"_"+kt,a),l&&(e.flags&4)!==0||(wn===null&&(wn=[]),wn.push(c,kt===0?o:o+"_"+kt,t.memoizedProps)),kt++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&r?e.flags|=t.flags&32:Rf(e,t.child,n,o,a,i,r)&&(l=!0));t=t.sibling}return l}function sv(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,o=e.stateNode,a=Qn(n,o),i=Fn(n.default,n.update);if(t){o=o.clones;var r=o===null?null:o.map(rS)}else r=e.memoizedState,e.memoizedState=null;o=e;var l=e.child;kt=0,a=Rf(o,l,a,a,i,r,!1),(e.flags&4)!==0&&a&&(t||vi(e,n.onUpdate))}else(e.subtreeFlags&33554432)!==0&&sv(e,t);e=e.sibling}}var Ge=!1,ue=!1,vn=!1,Nu=!1,Dg=typeof WeakSet=="function"?WeakSet:Set,Qe=null,yn=!1,dr=!1,Rc=!1,Td=!1;function Ow(e,t,n){if(e=e.containerInfo,Ld=Ei,e=Pb(e),of(e)){if("selectionStart"in e)var o={start:e.selectionStart,end:e.selectionEnd};else e:{o=(o=e.ownerDocument)&&o.defaultView||window;var a=o.getSelection&&o.getSelection();if(a&&a.rangeCount!==0){o=a.anchorNode;var i=a.anchorOffset,r=a.focusNode;a=a.focusOffset;try{o.nodeType,r.nodeType}catch{o=null;break e}var l=0,c=-1,s=-1,p=0,b=0,u=e,d=null;t:for(;;){for(var x;u!==o||i!==0&&u.nodeType!==3||(c=l+i),u!==r||a!==0&&u.nodeType!==3||(s=l+a),u.nodeType===3&&(l+=u.nodeValue.length),(x=u.firstChild)!==null;)d=u,u=x;for(;;){if(u===e)break t;if(d===o&&++p===i&&(c=l),d===r&&++b===a&&(s=l),(x=u.nextSibling)!==null)break;u=d,d=u.parentNode}u=x}o=c===-1||s===-1?null:{start:c,end:s}}else o=null}o=o||{start:0,end:0}}else o=null;for(Ud={focusedElem:e,selectionRange:o},Ei=!1,n=(n&335544064)===n,Qe=t,t=n?9270:1024;Qe!==null;){if(e=Qe,n&&(o=e.deletions,o!==null))for(i=0;i<o.length;i++)n&&Sd(o[i]);if(e.alternate===null&&(e.flags&2)!==0)n&&Og(e),ql(n);else{if(e.tag===22){if(o=e.alternate,e.memoizedState!==null){o!==null&&o.memoizedState===null&&n&&Sd(o),ql(n);continue}else if(o!==null&&o.memoizedState!==null){n&&Og(e),ql(n);continue}}o=e.child,(e.subtreeFlags&t)!==0&&o!==null?(o.return=e,Qe=o):(n&&lv(e),ql(n))}}Rt=null}function ql(e){for(;Qe!==null;){var t=Qe,n=e,o=t.alternate,a=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if((a&1024)!==0&&o!==null){n=void 0,a=o.memoizedProps,o=o.memoizedState;var i=t.stateNode;try{var r=pa(t.type,a);n=i.getSnapshotBeforeUpdate(r,o),i.__reactInternalSnapshotBeforeUpdate=n}catch(l){pe(t,t.return,l)}}break;case 3:if((a&1024)!==0){if(o=t.stateNode.containerInfo,n=o.nodeType,n===9)Yd(o);else if(n===1)switch(o.nodeName){case"HEAD":case"HTML":case"BODY":Yd(o);break;default:o.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&o!==null&&(n=Qn(o.memoizedProps,o.stateNode),a=t.memoizedProps,a=Fn(a.default,a.update),a!=="none"&&Ai(o,n,a,o.memoizedState=[],!0));break;default:if((a&1024)!==0)throw Error(C(163))}if(o=t.sibling,o!==null){o.return=t.return,Qe=o;break}Qe=t.return}}function uv(e,t,n){var o=n.flags;switch(n.tag){case 0:case 11:case 15:xn(e,n),o&4&&$r(5,n);break;case 1:if(xn(e,n),o&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(r){pe(n,n.return,r)}else{var a=pa(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(a,t,e.__reactInternalSnapshotBeforeUpdate)}catch(r){pe(n,n.return,r)}}o&64&&nv(n),o&512&&kn(n,n.return);break;case 3:if(xn(e,n),o&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{fh(e,t)}catch(r){pe(n,n.return,r)}}break;case 27:t===null&&o&4&&iv(n);case 26:case 5:xn(e,n),t===null&&o&4&&yd(n),o&512&&kn(n,n.return);break;case 12:xn(e,n);break;case 31:xn(e,n),o&4&&mv(e,n);break;case 13:xn(e,n),o&4&&gv(e,n),o&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=Kw.bind(null,n),wS(e,n))));break;case 22:if(o=n.memoizedState!==null||Ge,!o){var i=t!==null&&t.memoizedState!==null||ue;t=Ge,a=ue,Ge=o,(ue=i)&&!a?(o=2,(n.subtreeFlags&8772)!==0&&(o|=1),cn(e,n,o)):xn(e,n),Ge=t,ue=a}break;case 30:xn(e,n),o&512&&kn(n,n.return);break;case 7:o&512&&kn(n,n.return);default:xn(e,n)}}function Cd(e,t){for(e=e.child;e!==null;)dv(e,t),e=e.sibling}function dv(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var o=n.style;typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"}else{var a=e.stateNode,i=e.memoizedProps.style,r=i!=null&&i.hasOwnProperty("display")?i.display:null;a.style.display=r==null||typeof r=="boolean"?"":(""+r).trim()}}catch(c){pe(e,e.return,c)}Nd(e,t);break;case 6:try{e.stateNode.nodeValue=t?"":e.memoizedProps,re=!0}catch(c){pe(e,e.return,c)}break;case 18:try{var l=e.stateNode;t?$g(l,!0):$g(e.stateNode,!1)}catch(c){pe(e,e.return,c)}break;case 22:case 23:e.memoizedState===null&&Cd(e,t);break;default:Cd(e,t)}}function Nd(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){e:{var n=e,o=t;switch(n.tag){case 4:dv(n,o);break e;case 22:n.memoizedState===null&&Nd(n,o);break e;default:Nd(n,o)}}e=e.sibling}}function fv(e){var t=e.alternate;t!==null&&(e.alternate=null,fv(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&Vc(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var Ce=null,yt=!1;function ln(e,t,n){for(n=n.child;n!==null;)pv(e,t,n),n=n.sibling}function pv(e,t,n){if(Ht&&typeof Ht.onCommitFiberUnmount=="function")try{Ht.onCommitFiberUnmount(Vr,n)}catch{}switch(n.tag){case 26:ue||Je(n,t),ln(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!ue&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:ue||Je(n,t),kr(n);var o=Ce,a=yt;Bo(n.type)&&(Ce=n.stateNode,yt=!1),ln(e,t,n),e0(n.stateNode,n.type,n.memoizedProps),Ce=o,yt=a;break;case 5:ue||Je(n,t),kr(n);case 6:if(n.tag===6&&kr(n),o=Ce,a=yt,Ce=null,ln(e,t,n),Ce=o,yt=a,Ce!==null)if(yt)try{(Ce.nodeType===9?Ce.body:Ce.nodeName==="HTML"?Ce.ownerDocument.body:Ce).removeChild(n.stateNode),re=!0}catch(i){pe(n,t,i)}else try{Ce.removeChild(n.stateNode),re=!0}catch(i){pe(n,t,i)}break;case 18:Ce!==null&&(yt?(e=Ce,Pg(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,n.stateNode),Ti(e)):Pg(Ce,n.stateNode));break;case 4:o=Ce,a=yt,Ce=n.stateNode.containerInfo,yt=!0,ln(e,t,n),Ce=o,yt=a;break;case 0:case 11:case 14:case 15:Do(2,n,t),ue||Do(4,n,t),ln(e,t,n);break;case 1:ue||(Je(n,t),o=n.stateNode,typeof o.componentWillUnmount=="function"&&ov(n,t,o)),ln(e,t,n);break;case 21:ln(e,t,n);break;case 22:ue=(o=ue)||n.memoizedState!==null,ln(e,t,n),ue=o;break;case 30:Je(n,t),ln(e,t,n);break;case 7:ue||Je(n,t),ln(e,t,n);break;default:ln(e,t,n)}}function mv(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Ti(e)}catch(n){pe(t,t.return,n)}}}function gv(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Ti(e)}catch(n){pe(t,t.return,n)}}function Rw(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Dg),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Dg),t;default:throw Error(C(435,e.tag))}}function Yl(e,t){var n=Rw(e);t.forEach(function(o){if(!n.has(o)){n.add(o);var a=Xw.bind(null,e,o);o.then(a,a)}})}function pt(e,t,n){var o=t.deletions;if(o!==null)for(var a=0;a<o.length;a++){var i=o[a],r=e,l=t,c=l;e:for(;c!==null;){switch(c.tag){case 27:if(Bo(c.type)){Ce=c.stateNode,yt=!1;break e}break;case 5:Ce=c.stateNode,yt=!1;break e;case 3:case 4:Ce=c.stateNode.containerInfo,yt=!0;break e}c=c.return}if(Ce===null)throw Error(C(160));pv(r,l,i),Ce=null,yt=!1,r=i.alternate,r!==null&&(r.return=null),i.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)bv(t,e,n),t=t.sibling}var sn=null;function bv(e,t,n){var o=e.alternate,a=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(a&4&&(o=e.updateQueue,o=o!==null?o.events:null,o!==null))for(var i=0;i<o.length;i++){var r=o[i];r.ref.impl=r.nextImpl}pt(t,e,n),mt(e),a&4&&(Do(3,e,e.return),$r(3,e),Do(5,e,e.return));break;case 1:pt(t,e,n),mt(e),a&512&&(ue||o===null||Je(o,o.return)),a&64&&Ge&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(i=sn,pt(t,e,n),mt(e),a&512&&(ue||o===null||Je(o,o.return)),a&4)if(a=o!==null?o.memoizedState:null,n=e.memoizedState,o===null)if(n===null)if(e.stateNode===null)if(Ge)e.stateNode=Kv(e.type,e.memoizedProps,t.containerInfo,e);else{e:{t=e.type,n=e.memoizedProps,a=i.ownerDocument||i;t:switch(t){case"title":o=a.getElementsByTagName("title")[0],(!o||o[Gr]||o[Ie]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=a.createElement(t),a.head.insertBefore(o,a.querySelector("head > title"))),tt(o,t,n),o[Ie]=e,Ze(o),t=o;break e;case"link":if(i=ob("link","href",a).get(t+(n.href||""))){for(r=0;r<i.length;r++)if(o=i[r],o.getAttribute("href")===(n.href==null||n.href===""?null:n.href)&&o.getAttribute("rel")===(n.rel==null?null:n.rel)&&o.getAttribute("title")===(n.title==null?null:n.title)&&o.getAttribute("crossorigin")===(n.crossOrigin==null?null:n.crossOrigin)){i.splice(r,1);break t}}o=a.createElement(t),tt(o,t,n),a.head.appendChild(o);break;case"meta":if(i=ob("meta","content",a).get(t+(n.content||""))){for(r=0;r<i.length;r++)if(o=i[r],o.getAttribute("content")===(n.content==null?null:""+n.content)&&o.getAttribute("name")===(n.name==null?null:n.name)&&o.getAttribute("property")===(n.property==null?null:n.property)&&o.getAttribute("http-equiv")===(n.httpEquiv==null?null:n.httpEquiv)&&o.getAttribute("charset")===(n.charSet==null?null:n.charSet)){i.splice(r,1);break t}}o=a.createElement(t),tt(o,t,n),a.head.appendChild(o);break;default:throw Error(C(468,t))}o[Ie]=e,Ze(o),t=o}e.stateNode=t}else Ge||Xd(i,e.type,e.stateNode);else e.stateNode=nb(i,n,e.memoizedProps);else a!==n?(a===null?(t=o.stateNode,t===null||ue||t.parentNode.removeChild(t)):a.count--,n===null?Ge||Xd(i,e.type,e.stateNode):nb(i,n,e.memoizedProps)):n===null&&e.stateNode!==null&&Tu(e,e.memoizedProps,o.memoizedProps);break;case 27:pt(t,e,n),mt(e),a&512&&(ue||o===null||Je(o,o.return)),o!==null&&a&4&&Tu(e,e.memoizedProps,o.memoizedProps);break;case 5:if(i=vn,vn=!1,pt(t,e,n),vn=i,mt(e),a&512&&(ue||o===null||Je(o,o.return)),e.flags&32){t=e.stateNode;try{gi(t,""),re=!0}catch(p){pe(e,e.return,p)}}a&4&&e.stateNode!=null&&(t=e.memoizedProps,Tu(e,t,o!==null?o.memoizedProps:t)),a&1024&&(Nu=!0);break;case 6:if(pt(t,e,n),mt(e),a&4){if(e.stateNode===null)throw Error(C(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,re=!0}catch(p){pe(e,e.return,p)}}break;case 3:if(re=!1,cc=null,i=sn,sn=Lr(t.containerInfo),pt(t,e,n),sn=i,mt(e),a&4&&o!==null&&o.memoizedState.isDehydrated)try{Ti(t.containerInfo)}catch(p){pe(e,e.return,p)}Nu&&(Nu=!1,hv(e)),re=!1;break;case 4:a=vn,vn=Ge,o=jm(),i=sn,sn=Lr(e.stateNode.containerInfo),pt(t,e,n),mt(e),sn=i,re&&dr&&(Rc=!0),re=o,vn=a;break;case 12:pt(t,e,n),mt(e);break;case 31:pt(t,e,n),mt(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Yl(e,t)));break;case 13:pt(t,e,n),mt(e),e.child.flags&8192&&e.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(ts=_t()),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Yl(e,t)));break;case 22:i=e.memoizedState!==null,r=o!==null&&o.memoizedState!==null;var l=Ge,c=ue,s=vn;Ge=l||i,vn=s||i,ue=c||r,pt(t,e,n),ue=c,vn=s,Ge=l,mt(e),a&8192&&(t=e.stateNode,t._visibility=i?t._visibility&-2:t._visibility|1,!i||o===null||r||Ge||ue||(t=r||ue,n=Ge,o=ue,Ge=i||Ge,ue=t,so(e,2),Ge=n,ue=o),!i&&vn||Cd(e,i)),a&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,Yl(e,n))));break;case 19:pt(t,e,n),mt(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Yl(e,t)));break;case 30:a&512&&(ue||o===null||Je(o,o.return)),a=jm(),i=dr,r=(n&335544064)===n,l=e.memoizedProps,dr=r&&Fn(l.default,l.update)!=="none",pt(t,e,n),mt(e),r&&o!==null&&re&&(e.flags|=4),dr=i,re=a;break;case 21:break;case 7:a&512&&(ue||o===null||Je(o,o.return)),o&&o.stateNode!==null&&(o.stateNode._fragmentFiber=e);default:pt(t,e,n),mt(e)}}function mt(e){var t=e.flags;if(t&2){try{for(var n,o=e.return;o!==null;){if(av(o)){n=o;break}o=o.return}o=null;for(var a=e.return;a!==null;){if(Of(a)){var i=a.stateNode;o===null?o=[i]:o.push(i)}if(zf(a))break;a=a.return}var r=o;if(n==null)throw Error(C(160));switch(n.tag){case 27:var l=n.stateNode,c=Cu(e);zc(e,c,l,r);break;case 5:var s=n.stateNode;n.flags&32&&(gi(s,""),n.flags&=-33);var p=Cu(e);zc(e,p,s,r);break;case 3:case 4:var b=n.stateNode.containerInfo,u=Cu(e);xd(e,u,b,r);break;default:throw Error(C(161))}}catch(d){pe(e,e.return,d)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function hv(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;hv(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,Ei=!0,t.reset(),Ei=!1),e=e.sibling}}function Ya(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)vv(t,e),t=t.sibling;else sv(t,!1)}function vv(e,t){var n=e.alternate;if(n===null)kd(e,!1);else switch(e.tag){case 3:if(Td=yn=!1,Rg(),Ya(t,e),!yn&&!Rc){if(e=wn,e!==null)for(var o=0;o<e.length;o+=3){n=e[o];var a=e[o+1];Gv(n,e[o+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+a+")"})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===""&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),Td=!0}wn=null;break;case 5:Ya(t,e);break;case 4:o=yn,yn=!1,Ya(t,e),yn&&(Rc=!0),yn=o;break;case 22:e.memoizedState===null&&(n.memoizedState!==null?kd(e,!1):Ya(t,e));break;case 30:o=yn,a=Rg(),yn=!1,Ya(t,e),yn&&(e.flags|=4);var i=e.memoizedProps,r=e.stateNode;t=Qn(i,r),r=Qn(n.memoizedProps,r);var l=Fn(i.default,i.update);l==="none"?t=!1:(i=n.memoizedState,n.memoizedState=null,n=e.child,kt=0,t=Rf(e,n,t,r,l,i,!0),kt!==(i===null?0:i.length)&&(e.flags|=32)),(e.flags&4)!==0&&t?(vi(e,e.memoizedProps.onUpdate),wn=a):a!==null&&(a.push.apply(a,wn),wn=a),yn=(e.flags&32)!==0?!0:o;break;default:Ya(t,e)}}function xn(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)uv(e,t.alternate,t),t=t.sibling}function so(e,t){for(e=e.child;e!==null;){var n=e,o=t;switch(n.tag){case 0:case 11:case 14:case 15:Do(4,n,n.return),so(n,o);break;case 1:Je(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&ov(n,n.return,a),so(n,o);break;case 27:(o&2)!==0&&e0(n.stateNode,n.type,n.memoizedProps);case 5:Je(n,n.return),n.tag!==5&&n.tag!==27||kr(n),so(n,o);break;case 6:kr(n);break;case 26:Je(n,n.return),a=n.stateNode,n.memoizedState!==null||a===null||ue||a.parentNode.removeChild(a),so(n,o);break;case 22:n.memoizedState===null&&so(n,o);break;case 30:Je(n,n.return),so(n,o);break;case 7:Je(n,n.return);default:so(n,o)}e=e.sibling}}function cn(e,t,n){for(n=(t.subtreeFlags&8772)!==0?n:n&-2,t=t.child;t!==null;){var o=t.alternate,a=e,i=t,r=i.flags,l=(n&1)!==0;switch(i.tag){case 0:case 11:case 15:cn(a,i,n),$r(4,i);break;case 1:if(cn(a,i,n),o=i,a=o.stateNode,typeof a.componentDidMount=="function")try{a.componentDidMount()}catch(p){pe(o,o.return,p)}if(o=i,a=o.updateQueue,a!==null){var c=o.stateNode;try{var s=a.shared.hiddenCallbacks;if(s!==null)for(a.shared.hiddenCallbacks=null,a=0;a<s.length;a++)dh(s[a],c)}catch(p){pe(o,o.return,p)}}l&&r&64&&nv(i),kn(i,i.return);break;case 27:(n&2)!==0&&iv(i);case 5:i.tag!==5&&i.tag!==27||zg(i),cn(a,i,n),l&&o===null&&r&4&&yd(i),kn(i,i.return);break;case 6:zg(i);break;case 26:c=i.stateNode,i.memoizedState!==null||c===null||Ge||Xd(Lr(c.ownerDocument),i.type,c),cn(a,i,n),l&&o===null&&r&4&&yd(i),kn(i,i.return);break;case 12:cn(a,i,n);break;case 31:cn(a,i,n),l&&r&4&&mv(a,i);break;case 13:cn(a,i,n),l&&r&4&&gv(a,i);break;case 22:i.memoizedState===null&&cn(a,i,n),kn(i,i.return);break;case 30:cn(a,i,n),kn(i,i.return);break;case 7:kn(i,i.return);default:cn(a,i,n)}t=t.sibling}}function Df(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&Zr(n))}function _f(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Zr(e))}function Gt(e,t,n,o){var a=(n&335544064)===n;if(t.subtreeFlags&(a?10262:10256))for(t=t.child;t!==null;)yv(e,t,n,o),t=t.sibling;else a&&cv(t)}function yv(e,t,n,o){var a=(n&335544064)===n;a&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&ac(t);var i=t.flags;switch(t.tag){case 0:case 11:case 15:Gt(e,t,n,o),i&2048&&$r(9,t);break;case 1:Gt(e,t,n,o);break;case 3:Gt(e,t,n,o),a&&Td&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,e.style.viewTransitionName==="root"&&(e.style.viewTransitionName=""),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName==="none"&&(e.style.viewTransitionName="")),i&2048&&(i=null,t.alternate!==null&&(i=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==i&&(t.refCount++,i!=null&&Zr(i)));break;case 12:if(i&2048){Gt(e,t,n,o),i=t.stateNode;try{var r=t.memoizedProps,l=r.id,c=r.onPostCommit;typeof c=="function"&&c(l,t.alternate===null?"mount":"update",i.passiveEffectDuration,-0)}catch(s){pe(t,t.return,s)}}else Gt(e,t,n,o);break;case 31:Gt(e,t,n,o);break;case 13:Gt(e,t,n,o);break;case 23:break;case 22:r=t.stateNode,l=t.alternate,t.memoizedState!==null?(a&&l!==null&&l.memoizedState===null&&ac(l),r._visibility&2?Gt(e,t,n,o):wr(e,t)):(a&&l!==null&&l.memoizedState!==null&&ac(t),r._visibility&2?Gt(e,t,n,o):(r._visibility|=2,Ka(e,t,n,o,(t.subtreeFlags&10256)!==0||!1))),i&2048&&Df(l,t);break;case 24:Gt(e,t,n,o),i&2048&&_f(t.alternate,t);break;case 30:a&&(i=t.alternate,i!==null&&(An(i.child,!0),An(t.child,!0))),Gt(e,t,n,o);break;default:Gt(e,t,n,o)}}function Ka(e,t,n,o,a){for(a=a&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var i=e,r=t,l=n,c=o,s=r.flags;switch(r.tag){case 0:case 11:case 15:Ka(i,r,l,c,a),$r(8,r);break;case 23:break;case 22:var p=r.stateNode;r.memoizedState!==null?p._visibility&2?Ka(i,r,l,c,a):wr(i,r):(p._visibility|=2,Ka(i,r,l,c,a)),a&&s&2048&&Df(r.alternate,r);break;case 24:Ka(i,r,l,c,a),a&&s&2048&&_f(r.alternate,r);break;default:Ka(i,r,l,c,a)}t=t.sibling}}function wr(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,o=t,a=o.flags;switch(o.tag){case 22:wr(n,o),a&2048&&Df(o.alternate,o);break;case 24:wr(n,o),a&2048&&_f(o.alternate,o);break;default:wr(n,o)}t=t.sibling}}var Wo=8192;function Jo(e,t,n){if(e.subtreeFlags&Wo)for(e=e.child;e!==null;)xv(e,t,n),e=e.sibling}function xv(e,t,n){switch(e.tag){case 26:Jo(e,t,n),e.flags&Wo&&(e.memoizedState!==null?BS(n,sn,e.memoizedState,e.memoizedProps):(e=e.stateNode,(t&335544128)===t&&ib(n,e)));break;case 5:Jo(e,t,n),e.flags&Wo&&(e=e.stateNode,(t&335544128)===t&&ib(n,e));break;case 3:case 4:var o=sn;sn=Lr(e.stateNode.containerInfo),Jo(e,t,n),sn=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=Wo,Wo=16777216,Jo(e,t,n),Wo=o):Jo(e,t,n));break;case 30:if((e.flags&Wo)!==0&&(o=e.memoizedProps.name,o!=null&&o!=="auto")){var a=e.stateNode;a.paired=null,Rt===null&&(Rt=new Map),Rt.set(o,a)}Jo(e,t,n);break;default:Jo(e,t,n)}}function kv(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function ar(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];Qe=o,Sv(o,e)}kv(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)wv(e),e=e.sibling}function wv(e){switch(e.tag){case 0:case 11:case 15:ar(e),e.flags&2048&&Do(9,e,e.return);break;case 3:ar(e);break;case 12:ar(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,ic(e)):ar(e);break;default:ar(e)}}function ic(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];Qe=o,Sv(o,e)}kv(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Do(8,t,t.return),ic(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,ic(t));break;default:ic(t)}e=e.sibling}}function Sv(e,t){for(;Qe!==null;){var n=Qe;switch(n.tag){case 0:case 11:case 15:Do(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var o=n.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:Zr(n.memoizedState.cache)}if(o=n.child,o!==null)o.return=n,Qe=o;else e:for(n=e;Qe!==null;){o=Qe;var a=o.sibling,i=o.return;if(fv(o),o===n){Qe=null;break e}if(a!==null){a.return=i,Qe=a;break e}Qe=i}}}var Dw={getCacheForType:function(e){var t=Fe(Le),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return Fe(Le).controller.signal}},_w=typeof WeakMap=="function"?WeakMap:Map,ce=0,be=null,ee=null,te=0,de=0,At=null,ho=!1,zi=!1,Hf=!1,Jn=0,Oe=0,_o=0,ra=0,Dc=0,Dt=0,hi=0,Sr=null,xt=null,Md=!1,ts=0,Ev=0,_c=1/0,Hc=null,Co=null,Ne=0,dn=null,ma=null,Mn=0,Ad=0,zd=null,Tv=null,ui=null,di=null,fi=null,Er=0,rc=null;function Lt(){return(ce&2)!==0&&te!==0?te&-te:Y.T!==null?Lf():Ab()}function Cv(){if(Dt===0)if((te&536870912)===0||J){var e=Ml;Ml<<=1,(Ml&3932160)===0&&(Ml=262144),Dt=e}else Dt=536870912;return e=nt.current,e!==null&&(e.flags|=32),Dt}function vi(e,t){if(t!=null){var n=e.stateNode,o=n.ref;o===null&&(o=n.ref=Zv(Qn(e.memoizedProps,n))),di===null&&(di=[]),di.push(t.bind(null,o))}}function St(e,t,n){(e===be&&(de===2||de===9)||e.cancelPendingCommit!==null)&&(yi(e,0),vo(e,te,Dt,!1)),Xr(e,n),((ce&2)===0||e!==be)&&(e===be&&((ce&2)===0&&(ra|=n),Oe===4&&vo(e,te,Dt,!1)),On(e))}function Nv(e,t,n){if((ce&6)!==0)throw Error(C(327));var o=!n&&(t&127)===0&&(t&e.expiredLanes)===0||Kr(e,t),a=o?Lw(e,t):Mu(e,t,!0),i=o;do{if(a===0){zi&&!o&&vo(e,t,0,!1);break}else{if(n=e.current.alternate,i&&!Hw(n)){a=Mu(e,t,!1),i=!1;continue}if(a===2){if(i=t,e.errorRecoveryDisabledLanes&i)var r=0;else r=e.pendingLanes&-536870913,r=r!==0?r:r&536870912?536870912:0;if(r!==0){t=r;e:{var l=e;a=Sr;var c=l.current.memoizedState.isDehydrated;if(c&&(yi(l,r).flags|=256),r=Mu(l,r,!1),r!==2&&r!==6){if(Hf&&!c){l.errorRecoveryDisabledLanes|=i,ra|=i,a=4;break e}i=xt,xt=a,i!==null&&(xt===null?xt=i:xt.push.apply(xt,i))}a=r}if(i=!1,a!==2)continue}}if(a===1){yi(e,0),vo(e,t,0,!0);break}e:{switch(o=e,i=a,i){case 0:case 1:throw Error(C(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:vo(o,t,Dt,!ho);break e;case 2:xt=null;break;case 3:case 5:break;default:throw Error(C(329))}if((t&62914560)===t&&(a=ts+300-_t(),10<a)){if(vo(o,t,Dt,!ho),Yc(o,0,!0)!==0)break e;Mn=t,o.timeoutHandle=jf(_g.bind(null,o,n,xt,Hc,Md,t,Dt,ra,hi,ho,i,"Throttled",-0,0),a);break e}_g(o,n,xt,Hc,Md,t,Dt,ra,hi,ho,i,null,-0,0)}}break}while(!0);On(e)}function _g(e,t,n,o,a,i,r,l,c,s,p,b,u,d){e.timeoutHandle=-1;var x=t.subtreeFlags,k=(i&335544064)===i;if(b=null,(k||x&8192||(x&16785408)===16785408)&&(b={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:En},Rt=null,xv(t,i,b),k&&(x=b,k=e.containerInfo,k=(k.nodeType===9?k:k.ownerDocument).__reactViewTransition,k!=null&&(x.count++,x.waitingForViewTransition=!0,x=Ur.bind(x),k.finished.then(x,x))),x=(i&62914560)===i?ts-_t():(i&4194048)===i?Ev-_t():0,x=LS(b,x),x!==null)){Mn=i,e.cancelPendingCommit=x(Bg.bind(null,e,t,i,n,o,a,r,l,c,s,p,b,null,u,d)),vo(e,i,r,!s);return}Bg(e,t,i,n,o,a,r,l,c,s,p,b)}function Hw(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var o=0;o<n.length;o++){var a=n[o],i=a.getSnapshot;a=a.value;try{if(!Ut(i(),a))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function vo(e,t,n,o){t=Eb(e,t),t&=~Dc,t&=~ra,e.suspendedLanes|=t,e.pingedLanes&=~t,o&&(e.warmLanes|=t),o=e.expirationTimes;for(var a=t;0<a;){var i=31-Bt(a),r=1<<i;o[i]=-1,a&=~r}n!==0&&Cb(e,n,t)}function ns(){return(ce&6)===0?(Jr(0,!1),!1):!0}function Bf(){if(ee!==null){if(de===0)var e=ee.return;else e=ee,Vn=ya=null,yf(e),li=null,Or=0,e=ee;for(;e!==null;)tv(e.alternate,e),e=e.return;ee=null}}function yi(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,oS(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),Mn=0,Bf(),be=e,ee=n=Kn(e.current,null),te=t,de=0,At=null,ho=!1,zi=Kr(e,t),Hf=!1,hi=Dt=Dc=ra=_o=Oe=0,xt=Sr=null,Md=!1,Jn=Eb(e,t),Qc(),n}function Mv(e,t){Q=null,Y.H=Nc,t===Mi||t===$c?(t=lg(),de=3):t===df?(t=lg(),de=4):de=t===Nf?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,At=t,ee===null&&(Oe=1,Mc(e,Jt(t,e.current)))}function Av(){var e=nt.current;return e===null?!0:(te&4194048)===te?st===null:(te&62914560)===te||(te&536870912)!==0?e===st:!1}function zv(){var e=Y.H;return Y.H=Nc,e===null?Nc:e}function Ov(){var e=Y.A;return Y.A=Dw,e}function Bc(){Oe=4,ho||(te&4194048)!==te&&nt.current!==null||(zi=!0),(_o&134217727)===0&&(ra&134217727)===0||be===null||vo(be,te,Dt,!1)}function Mu(e,t,n){var o=ce;ce|=2;var a=zv(),i=Ov();(be!==e||te!==t)&&(Hc=null,yi(e,t)),t=!1;var r=Oe;e:do try{if(de!==0&&ee!==null){var l=ee,c=At;switch(de){case 8:Bf(),r=6;break e;case 3:case 2:case 9:case 6:nt.current===null&&(t=!0);var s=de;if(de=0,At=null,ni(e,l,c,s),n&&zi){r=0;break e}break;default:s=de,de=0,At=null,ni(e,l,c,s)}}Bw(),r=Oe;break}catch(p){Mv(e,p)}while(!0);return t&&e.shellSuspendCounter++,Vn=ya=null,ce=o,Y.H=a,Y.A=i,ee===null&&(be=null,te=0,Qc()),r}function Bw(){for(;ee!==null;)Rv(ee)}function Lw(e,t){var n=ce;ce|=2;var o=zv(),a=Ov();be!==e||te!==t?(Hc=null,_c=_t()+500,yi(e,t)):zi=Kr(e,t);e:do try{if(de!==0&&ee!==null){t=ee;var i=At;t:switch(de){case 1:de=0,At=null,ni(e,t,i,1);break;case 2:case 9:if(rg(i)){de=0,At=null,Hg(t);break}t=function(){de!==2&&de!==9||be!==e||(de=7),On(e)},i.then(t,t);break e;case 3:de=7;break e;case 4:de=5;break e;case 7:rg(i)?(de=0,At=null,Hg(t)):(de=0,At=null,ni(e,t,i,7));break;case 5:var r=null;switch(ee.tag){case 26:r=ee.memoizedState;case 5:case 27:var l=ee;if(r?o0(r):l.stateNode.complete){de=0,At=null;var c=l.sibling;if(c!==null)ee=c;else{var s=l.return;s!==null?(ee=s,os(s)):ee=null}break t}}de=0,At=null,ni(e,t,i,5);break;case 6:de=0,At=null,ni(e,t,i,6);break;case 8:Bf(),Oe=6;break e;default:throw Error(C(462))}}Uw();break}catch(p){Mv(e,p)}while(!0);return Vn=ya=null,Y.H=o,Y.A=a,ce=n,ee!==null?0:(be=null,te=0,Qc(),Oe)}function Uw(){for(;ee!==null&&!tk();)Rv(ee)}function Rv(e){var t=ev(e.alternate,e,Jn);e.memoizedProps=e.pendingProps,t===null?os(e):ee=t}function Hg(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Sg(n,t,t.pendingProps,t.type,void 0,te);break;case 11:t=Sg(n,t,t.pendingProps,t.type.render,t.ref,te);break;case 5:yf(t);var o=t;o===Pe&&(J?(xc(o),o.tag===5&&o.stateNode!=null&&(ke=o.stateNode)):(xc(o),J=!0));default:tv(n,t),t=ee=nh(t,Jn),t=ev(n,t,Jn)}e.memoizedProps=e.pendingProps,t===null?os(e):ee=t}function ni(e,t,n,o){Vn=ya=null,yf(t),li=null,Or=0;var a=t.return;try{if(Tw(e,a,t,n,te)){Oe=1,Mc(e,Jt(n,e.current)),ee=null;return}}catch(i){if(a!==null)throw ee=a,i;Oe=1,Mc(e,Jt(n,e.current)),ee=null;return}t.flags&32768?(J||o===1?e=!0:zi||(te&536870912)!==0?e=!1:(ho=e=!0,(o===2||o===9||o===3||o===6)&&(o=nt.current,o!==null&&o.tag===13&&(o.flags|=16384))),Dv(t,e)):os(t)}function os(e){var t=e;do{if((t.flags&32768)!==0){Dv(t,ho);return}e=t.return;var n=Aw(t.alternate,t,Jn);if(n!==null){ee=n;return}if(t=t.sibling,t!==null){ee=t;return}ee=t=e}while(t!==null);Oe===0&&(Oe=5)}function Dv(e,t){do{var n=zw(e.alternate,e);if(n!==null){n.flags&=32767,ee=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){ee=e;return}ee=e=n}while(e!==null);Oe=6,ee=null}function Bg(e,t,n,o,a,i,r,l,c,s,p,b){e.cancelPendingCommit=null;do as();while(Ne!==0);if((ce&6)!==0)throw Error(C(327));if(t!==null){if(t===e.current)throw Error(C(177));e===be&&(ee=be=null,te=0),ma=t,dn=e,Mn=n,zd=a,Tv=o,jw(e,t,n,r,l,c,b)}}function jw(e,t,n,o,a,i,r){var l=t.lanes|t.childLanes;if(Ad=l,l|=af,dk(e,n,l,o,a,i),di=null,(n&335544064)===n?(fi=pw(e),o=10262):(fi=null,o=10256),(t.subtreeFlags&o)!==0||(t.flags&o)!==0?(e.callbackNode=null,e.callbackPriority=0,Gw(gc,function(){return _d(),null})):(e.callbackNode=null,e.callbackPriority=0),Oc=!1,o=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||o){o=Y.T,Y.T=null,a=se.p,se.p=2,i=ce,ce|=4;try{Ow(e,t,n)}finally{ce=i,se.p=a,Y.T=o}}Ne=1,Oc?ui=sS(r,e.containerInfo,fi,Od,Rd,Yw,Dd,_d,qw,null,null):(Od(),Rd(),Dd())}function qw(e){if(Ne!==0){var t=dn.onRecoverableError;t(e,{componentStack:null})}}function Yw(){Ne===3&&(Ne=0,vv(ma,dn),Ne=4)}function Od(){if(Ne===1){Ne=0;var e=dn,t=ma,n=Mn,o=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||o){o=Y.T,Y.T=null;var a=se.p;se.p=2;var i=ce;ce|=4;try{dr=Rc=!1,bv(t,e,n),n=Ud;var r=Pb(e.containerInfo),l=n.focusedElem,c=n.selectionRange;if(r!==l&&l&&l.ownerDocument&&Zb(l.ownerDocument.documentElement,l)){if(c!==null&&of(l)){var s=c.start,p=c.end;if(p===void 0&&(p=s),"selectionStart"in l)l.selectionStart=s,l.selectionEnd=Math.min(p,l.value.length);else{var b=l.ownerDocument||document,u=b&&b.defaultView||window;if(u.getSelection){var d=u.getSelection(),x=l.textContent.length,k=Math.min(c.start,x),E=c.end===void 0?k:Math.min(c.end,x);!d.extend&&k>E&&(r=E,E=k,k=r);var m=Fm(l,k),g=Fm(l,E);if(m&&g&&(d.rangeCount!==1||d.anchorNode!==m.node||d.anchorOffset!==m.offset||d.focusNode!==g.node||d.focusOffset!==g.offset)){var f=b.createRange();f.setStart(m.node,m.offset),d.removeAllRanges(),k>E?(d.addRange(f),d.extend(g.node,g.offset)):(f.setEnd(g.node,g.offset),d.addRange(f))}}}}for(b=[],d=l;d=d.parentNode;)d.nodeType===1&&b.push({element:d,left:d.scrollLeft,top:d.scrollTop});for(typeof l.focus=="function"&&l.focus(),l=0;l<b.length;l++){var y=b[l];y.element.scrollLeft=y.left,y.element.scrollTop=y.top}}Ei=!!Ld,Ud=Ld=null}finally{ce=i,se.p=a,Y.T=o}}e.current=t,Ne=2}}function Rd(){if(Ne===2){Ne=0;var e=dn,t=ma,n=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||n){n=Y.T,Y.T=null;var o=se.p;se.p=2;var a=ce;ce|=4;try{uv(e,t.alternate,t)}finally{ce=a,se.p=o,Y.T=n}}Ne=3}}function Dd(){if(Ne===4||Ne===3){Ne=0;var e=ui;ui=null,nk();var t=dn,n=ma,o=Mn,a=Tv,i=(o&335544064)===o?10262:10256;if((n.subtreeFlags&i)!==0||(n.flags&i)!==0?Ne=5:(Ne=0,ma=dn=null,_v(t,t.pendingLanes)),i=t.pendingLanes,i===0&&(Co=null),Id(o),n=n.stateNode,Ht&&typeof Ht.onCommitFiberRoot=="function")try{Ht.onCommitFiberRoot(Vr,n,void 0,(n.current.flags&128)===128)}catch{}if(a!==null){n=Y.T,i=se.p,se.p=2,Y.T=null;try{for(var r=t.onRecoverableError,l=0;l<a.length;l++){var c=a[l];r(c.value,{componentStack:c.stack})}}finally{Y.T=n,se.p=i}}if(a=di,r=fi,fi=null,a!==null&&(di=null,r===null&&(r=[]),e!==null))for(c=0;c<a.length;c++)n=(0,a[c])(r),n!==void 0&&e.finished.finally(n);(Mn&3)!==0&&as(),On(t),i=t.pendingLanes,(o&261930)!==0&&(i&42)!==0?t===rc?Er++:(Er=0,rc=t):(Er=0,rc=null),Jr(0,!1)}}function _v(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Zr(t)))}function as(){return ui!==null&&(ui.skipTransition(),ui=null),Od(),Rd(),Dd(),_d()}function _d(){if(Ne!==5)return!1;var e=dn,t=Ad;Ad=0;var n=Id(Mn),o=Y.T,a=se.p;try{se.p=32>n?32:n,Y.T=null,n=zd,zd=null;var i=dn,r=Mn;if(Ne=0,ma=dn=null,Mn=0,(ce&6)!==0)throw Error(C(331));var l=ce;if(ce|=4,wv(i.current),yv(i,i.current,r,n),ce=l,Jr(0,!1),Ht&&typeof Ht.onPostCommitFiberRoot=="function")try{Ht.onPostCommitFiberRoot(Vr,i)}catch{}return!0}finally{se.p=a,Y.T=o,_v(e,t)}}function Lg(e,t,n){t=Jt(n,t),t=pd(e.stateNode,t,2),e=So(e,t,2),e!==null&&(Xr(e,2),On(e))}function pe(e,t,n){if(e.tag===3)Lg(e,e,n);else for(;t!==null;){if(t.tag===3){Lg(t,e,n);break}else if(t.tag===1){var o=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(Co===null||!Co.has(o))){e=Jt(n,e),n=$h(2),o=So(t,n,2),o!==null&&(Jh(n,o,t,e),Xr(o,2),On(o));break}}t=t.return}}function Au(e,t,n){var o=e.pingCache;if(o===null){o=e.pingCache=new _w;var a=new Set;o.set(t,a)}else a=o.get(t),a===void 0&&(a=new Set,o.set(t,a));a.has(n)||(Hf=!0,a.add(n),e=Vw.bind(null,e,t,n),t.then(e,e))}function Vw(e,t,n){var o=e.pingCache;o!==null&&o.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,be===e&&(te&n)===n&&((Oe===4||Oe===3&&(te&62914560)===te&&300>_t()-ts)&&(ce&2)===0?yi(e,0):Dc|=n,hi===te&&(hi=0)),On(e)}function Hv(e,t){t===0&&(t=Tb()),e=va(e,t),e!==null&&(Xr(e,t),On(e))}function Kw(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Hv(e,n)}function Xw(e,t){var n=0;switch(e.tag){case 31:case 13:var o=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(C(314))}o!==null&&o.delete(t),Hv(e,n)}function Gw(e,t){return $d(e,t)}var xi=null,Xa=null,Hd=!1,Lc=!1,zu=!1,yo=0;function On(e){e!==Xa&&e.next===null&&(Xa===null?xi=Xa=e:Xa=Xa.next=e),Lc=!0,Hd||(Hd=!0,Zw())}function Jr(e,t){if(!zu&&Lc){zu=!0;do for(var n=!1,o=xi;o!==null;){if(!t)if(e!==0){var a=o.pendingLanes;if(a===0)var i=0;else{var r=o.suspendedLanes,l=o.pingedLanes;i=(1<<31-Bt(42|e)+1)-1,i&=a&~(r&~l),i=i&201326741?i&201326741|1:i?i|2:0}i!==0&&(n=!0,Ug(o,i))}else i=te,i=Yc(o,o===be?i:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(i&3)===0||Kr(o,i)||(n=!0,Ug(o,i));o=o.next}while(n);zu=!1}}function Qw(){Bv()}function Bv(){Lc=Hd=!1;var e=0;yo!==0&&nS()&&(e=yo);for(var t=_t(),n=null,o=xi;o!==null;){var a=o.next,i=Lv(o,t);i===0?(o.next=null,n===null?xi=a:n.next=a,a===null&&(Xa=n)):(n=o,(e!==0||(i&3)!==0)&&(Lc=!0)),o=a}Ne!==0&&Ne!==5||Jr(e,!1),yo!==0&&(yo=0)}function Lv(e,t){for(var n=e.suspendedLanes,o=e.pingedLanes,a=e.expirationTimes,i=e.pendingLanes&-62914561;0<i;){var r=31-Bt(i),l=1<<r,c=a[r];c===-1?((l&n)===0||(l&o)!==0)&&(a[r]=uk(l,t)):c<=t&&(e.expiredLanes|=l),i&=~l}if(t=be,n=te,n=Yc(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,n===0||e===t&&(de===2||de===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&cu(o),e.callbackNode=null,e.callbackPriority=0;if((n&3)===0||Kr(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(o!==null&&cu(o),Id(n)){case 2:case 8:n=wb;break;case 32:n=gc;break;case 268435456:n=Sb;break;default:n=gc}return o=Uv.bind(null,e),n=$d(n,o),e.callbackPriority=t,e.callbackNode=n,t}return o!==null&&o!==null&&cu(o),e.callbackPriority=2,e.callbackNode=null,2}function Uv(e,t){if(Ne!==0&&Ne!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(as()&&e.callbackNode!==n)return null;var o=te;return o=Yc(e,e===be?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(Nv(e,o,t),Lv(e,_t()),e.callbackNode!=null&&e.callbackNode===n?Uv.bind(null,e):null)}function Ug(e,t){if(as())return null;Nv(e,t,!0)}function Zw(){aS(function(){(ce&6)!==0?$d(kb,Qw):Bv()})}function Lf(){if(yo===0){var e=ua;e===0&&(e=Nl,Nl<<=1,(Nl&261888)===0&&(Nl=256)),yo=e}return yo}function jg(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:Pl(e)}function Pw(e,t,n,o,a){if(t==="submit"&&n&&n.stateNode===a){var i=jg((a[Tt]||null).action),r=o.submitter;r&&(t=(t=r[Tt]||null)?jg(t.formAction):r.getAttribute("formAction"),t!==null&&(i=t,r=null));var l=new Kc("action","action",null,o,a);e.push({event:l,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(yo!==0){var c=new FormData(a,r);dd(n,{pending:!0,data:c,method:a.method,action:i},null,c)}}else typeof i=="function"&&(l.preventDefault(),c=new FormData(a,r),dd(n,{pending:!0,data:c,method:a.method,action:i},i,c))},currentTarget:a}]})}}for(Vl=0;Vl<ed.length;Vl++)Kl=ed[Vl],qg=Kl.toLowerCase(),Yg=Kl[0].toUpperCase()+Kl.slice(1),fn(qg,"on"+Yg);var Kl,qg,Yg,Vl;fn(Jb,"onAnimationEnd");fn(Ib,"onAnimationIteration");fn(Fb,"onAnimationStart");fn("dblclick","onDoubleClick");fn("focusin","onFocus");fn("focusout","onBlur");fn(iw,"onTransitionRun");fn(rw,"onTransitionStart");fn(lw,"onTransitionCancel");fn(Wb,"onTransitionEnd");mi("onMouseEnter",["mouseout","mouseover"]);mi("onMouseLeave",["mouseout","mouseover"]);mi("onPointerEnter",["pointerout","pointerover"]);mi("onPointerLeave",["pointerout","pointerover"]);ba("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));ba("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));ba("onBeforeInput",["compositionend","keypress","textInput","paste"]);ba("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));ba("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));ba("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var _r="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),$w=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(_r));function jv(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var o=e[n],a=o.event;o=o.listeners;e:{var i=void 0;if(t)for(var r=o.length-1;0<=r;r--){var l=o[r],c=l.instance,s=l.currentTarget;if(l=l.listener,c!==i&&a.isPropagationStopped())break e;i=l,a.currentTarget=s;try{i(a)}catch(p){hc(p)}a.currentTarget=null,i=c}else for(r=0;r<o.length;r++){if(l=o[r],c=l.instance,s=l.currentTarget,l=l.listener,c!==i&&a.isPropagationStopped())break e;i=l,a.currentTarget=s;try{i(a)}catch(p){hc(p)}a.currentTarget=null,i=c}}}}function W(e,t){var n=t[Hm];n===void 0&&(n=t[Hm]=new Set);var o=e+"__bubble";n.has(o)||(qv(t,e,2,!1),n.add(o))}function Ou(e,t,n){var o=0;t&&(o|=4),qv(n,e,o,t)}var Xl="_reactListening"+Math.random().toString(36).slice(2);function Uf(e){if(!e[Xl]){e[Xl]=!0,Ob.forEach(function(n){n!=="selectionchange"&&($w.has(n)||Ou(n,!1,e),Ou(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Xl]||(t[Xl]=!0,Ou("selectionchange",!1,t))}}function qv(e,t,n,o){switch(u0(t)){case 2:var a=YS;break;case 8:a=VS;break;default:a=Gf}n=a.bind(null,t,n,e),a=void 0,!Ju||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(a=!0),o?a!==void 0?e.addEventListener(t,n,{capture:!0,passive:a}):e.addEventListener(t,n,!0):a!==void 0?e.addEventListener(t,n,{passive:a}):e.addEventListener(t,n,!1)}function Ru(e,t,n,o,a){var i=o;if((t&1)===0&&(t&2)===0&&o!==null)e:for(;;){if(o===null)return;var r=o.tag;if(r===3||r===4){var l=o.stateNode.containerInfo;if(l===a)break;if(r===4)for(r=o.return;r!==null;){var c=r.tag;if((c===3||c===4)&&r.stateNode.containerInfo===a)return;r=r.return}for(;l!==null;){if(r=ea(l),r===null)return;if(c=r.tag,c===5||c===6||c===26||c===27){o=i=r;continue e}l=l.parentNode}}o=o.return}jb(function(){var s=i,p=Wd(n),b=[];e:{var u=eh.get(e);if(u!==void 0){var d=Kc,x=e;switch(e){case"keypress":if(Jl(n)===0)break e;case"keydown":case"keyup":d=Hk;break;case"focusin":x="focus",d=mu;break;case"focusout":x="blur",d=mu;break;case"beforeblur":case"afterblur":d=mu;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":d=Km;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":d=Sk;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":d=qk;break;case Jb:case Ib:case Fb:d=Ck;break;case Wb:d=Vk;break;case"scroll":case"scrollend":d=kk;break;case"wheel":d=Xk;break;case"copy":case"cut":case"paste":d=Mk;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":d=Gm;break;case"submit":d=Uk;break;case"toggle":case"beforetoggle":d=Qk}var k=(t&4)!==0,E=!k&&(e==="scroll"||e==="scrollend"),m=k?u!==null?u+"Capture":null:u;k=[];for(var g=s,f;g!==null;){var y=g;if(f=y.stateNode,y=y.tag,y!==5&&y!==26&&y!==27||f===null||m===null||(y=Cr(g,m),y!=null&&k.push(Hr(g,y,f))),E)break;g=g.return}0<k.length&&(u=new d(u,x,null,n,p),b.push({event:u,listeners:k}))}}if((t&7)===0){e:{if(d=e==="mouseover"||e==="pointerover",u=e==="mouseout"||e==="pointerout",d&&n!==$u&&(x=n.relatedTarget||n.fromElement)&&(ea(x)||x[Ci]))break e;(u||d)&&(x=p.window===p?p:(d=p.ownerDocument)?d.defaultView||d.parentWindow:window,u?(d=n.relatedTarget||n.toElement,u=s,d=d?ea(d):null,d!==null&&(E=Yr(d),k=d.tag,d!==E||k!==5&&k!==27&&k!==6)&&(d=null)):(u=null,d=s),u!==d&&(k=Km,y="onMouseLeave",m="onMouseEnter",g="mouse",(e==="pointerout"||e==="pointerover")&&(k=Gm,y="onPointerLeave",m="onPointerEnter",g="pointer"),E=u==null?x:sr(u),f=d==null?x:sr(d),x=new k(y,g+"leave",u,n,p),x.target=E,x.relatedTarget=f,y=null,ea(p)===s&&(k=new k(m,g+"enter",d,n,p),k.target=f,k.relatedTarget=E,y=k),E=y,k=u&&d?Lu(u,d,Jw):null,u!==null&&Vg(b,x,u,k,!1),d!==null&&E!==null&&Vg(b,E,d,k,!0)))}e:{if(u=s?sr(s):window,d=u.nodeName&&u.nodeName.toLowerCase(),d==="select"||d==="input"&&u.type==="file")var h=$m;else if(Pm(u))if(Gb)h=nw;else{h=ew;var S=Wk}else d=u.nodeName,!d||d.toLowerCase()!=="input"||u.type!=="checkbox"&&u.type!=="radio"?s&&Fd(s.elementType)&&(h=$m):h=tw;if(h&&(h=h(e,s))){Xb(b,h,n,p);break e}S&&S(e,u,s)}switch(S=s?sr(s):window,e){case"focusin":(Pm(S)||S.contentEditable==="true")&&(Ja=S,Fu=s,mr=null);break;case"focusout":mr=Fu=Ja=null;break;case"mousedown":Wu=!0;break;case"contextmenu":case"mouseup":case"dragend":Wu=!1,Wm(b,n,p);break;case"selectionchange":if(aw)break;case"keydown":case"keyup":Wm(b,n,p)}var v;if(nf)e:{switch(e){case"compositionstart":var T="onCompositionStart";break e;case"compositionend":T="onCompositionEnd";break e;case"compositionupdate":T="onCompositionUpdate";break e}T=void 0}else $a?Vb(e,n)&&(T="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(T="onCompositionStart");T&&(Yb&&n.locale!=="ko"&&($a||T!=="onCompositionStart"?T==="onCompositionEnd"&&$a&&(v=qb()):(go=p,ef="value"in go?go.value:go.textContent,$a=!0)),S=Uc(s,T),0<S.length&&(T=new Xm(T,e,null,n,p),b.push({event:T,listeners:S}),v?T.data=v:(v=Kb(n),v!==null&&(T.data=v)))),(v=Pk?$k(e,n):Jk(e,n))&&(T=Uc(s,"onBeforeInput"),0<T.length&&(S=new Xm("onBeforeInput","beforeinput",null,n,p),b.push({event:S,listeners:T}),S.data=v)),Pw(b,e,s,n,p)}jv(b,t)})}function Hr(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Uc(e,t){for(var n=t+"Capture",o=[];e!==null;){var a=e,i=a.stateNode;if(a=a.tag,a!==5&&a!==26&&a!==27||i===null||(a=Cr(e,n),a!=null&&o.unshift(Hr(e,a,i)),a=Cr(e,t),a!=null&&o.push(Hr(e,a,i))),e.tag===3)return o;e=e.return}return[]}function Jw(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Vg(e,t,n,o,a){for(var i=t._reactName,r=[];n!==null&&n!==o;){var l=n,c=l.alternate,s=l.stateNode;if(l=l.tag,c!==null&&c===o)break;l!==5&&l!==26&&l!==27||s===null||(c=s,a?(s=Cr(n,i),s!=null&&r.unshift(Hr(n,s,c))):a||(s=Cr(n,i),s!=null&&r.push(Hr(n,s,c)))),n=n.return}r.length!==0&&e.push({event:t,listeners:r})}var Iw=/\r\n?/g,Fw=/\u0000|\uFFFD/g;function Kg(e){return(typeof e=="string"?e:""+e).replace(Iw,`
`).replace(Fw,"")}function Yv(e,t){return t=Kg(t),Kg(e)===t}function fe(e,t,n,o,a,i){switch(n){case"children":if(typeof o=="string")t==="body"||t==="textarea"&&o===""||gi(e,o);else if(typeof o=="number"||typeof o=="bigint")t!=="body"&&gi(e,""+o);else return;break;case"className":zl(e,"class",o);break;case"tabIndex":zl(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":zl(e,n,o);break;case"style":Ub(e,o,i);return;case"data":if(t!=="object"){zl(e,"data",o);break}case"src":case"href":if(o===""&&(t!=="a"||n!=="href")){e.removeAttribute(n);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=Pl(o),e.setAttribute(n,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof i=="function"&&(n==="formAction"?(t!=="input"&&fe(e,t,"name",a.name,a,null),fe(e,t,"formEncType",a.formEncType,a,null),fe(e,t,"formMethod",a.formMethod,a,null),fe(e,t,"formTarget",a.formTarget,a,null)):(fe(e,t,"encType",a.encType,a,null),fe(e,t,"method",a.method,a,null),fe(e,t,"target",a.target,a,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=Pl(o),e.setAttribute(n,o);break;case"onClick":o!=null&&(e.onclick=En);return;case"onScroll":o!=null&&W("scroll",e);return;case"onScrollEnd":o!=null&&W("scrollend",e);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(C(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(C(60));i?.__html!==n&&(e.innerHTML=n)}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}n=Pl(o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":o===!0?e.setAttribute(n,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(n,o):e.removeAttribute(n);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(n):e.setAttribute(n,o);break;case"popover":W("beforetoggle",e),W("toggle",e),Zl(e,"popover",o);break;case"xlinkActuate":jn(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":jn(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":jn(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":jn(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":jn(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":jn(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":jn(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":jn(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":jn(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":Zl(e,"is",o);break;case"innerText":case"textContent":return;default:if(!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")n=yk.get(n)||n,Zl(e,n,o);else return}re=!0}function Bd(e,t,n,o,a,i){switch(n){case"style":Ub(e,o,i);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(C(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(C(60));i?.__html!==n&&(e.innerHTML=n)}}break;case"children":if(typeof o=="string")gi(e,o);else if(typeof o=="number"||typeof o=="bigint")gi(e,""+o);else return;break;case"onScroll":o!=null&&W("scroll",e);return;case"onScrollEnd":o!=null&&W("scrollend",e);return;case"onClick":o!=null&&(e.onclick=En);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!Rb.hasOwnProperty(n))e:{if(n[0]==="o"&&n[1]==="n"&&(a=n.endsWith("Capture"),i=n.slice(2,a?n.length-7:void 0),t=e[Tt]||null,t=t!=null?t[n]:null,typeof t=="function"&&e.removeEventListener(i,t,a),typeof o=="function")){typeof t!="function"&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(i,o,a);break e}re=!0,n in e?e[n]=o:o===!0?e.setAttribute(n,""):Zl(e,n,o)}return}re=!0}function tt(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":W("error",e),W("load",e);var o=!1,a=!1,i;for(i in n)if(n.hasOwnProperty(i)){var r=n[i];if(r!=null)switch(i){case"src":o=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(C(137,t));default:fe(e,t,i,r,n,null)}}a&&fe(e,t,"srcSet",n.srcSet,n,null),o&&fe(e,t,"src",n.src,n,null);return;case"input":W("invalid",e);var l=i=r=a=null,c=null,s=null;for(o in n)if(n.hasOwnProperty(o)){var p=n[o];if(p!=null)switch(o){case"name":a=p;break;case"type":r=p;break;case"checked":c=p;break;case"defaultChecked":s=p;break;case"value":i=p;break;case"defaultValue":l=p;break;case"children":case"dangerouslySetInnerHTML":if(p!=null)throw Error(C(137,t));break;default:fe(e,t,o,p,n,null)}}Hb(e,i,l,c,s,r,a,!1);return;case"select":W("invalid",e),o=r=i=null;for(a in n)if(n.hasOwnProperty(a)&&(l=n[a],l!=null))switch(a){case"value":i=l;break;case"defaultValue":r=l;break;case"multiple":o=l;default:fe(e,t,a,l,n,null)}t=i,n=r,e.multiple=!!o,t!=null?ai(e,!!o,t,!1):n!=null&&ai(e,!!o,n,!0);return;case"textarea":W("invalid",e),i=a=o=null;for(r in n)if(n.hasOwnProperty(r)&&(l=n[r],l!=null))switch(r){case"value":o=l;break;case"defaultValue":a=l;break;case"children":i=l;break;case"dangerouslySetInnerHTML":if(l!=null)throw Error(C(91));break;default:fe(e,t,r,l,n,null)}Lb(e,o,a,i);return;case"option":for(c in n)n.hasOwnProperty(c)&&(o=n[c],o!=null)&&(c==="selected"?e.selected=o&&typeof o!="function"&&typeof o!="symbol":fe(e,t,c,o,n,null));return;case"dialog":W("beforetoggle",e),W("toggle",e),W("cancel",e),W("close",e);break;case"iframe":case"object":W("load",e);break;case"video":case"audio":for(o=0;o<_r.length;o++)W(_r[o],e);break;case"image":W("error",e),W("load",e);break;case"details":W("toggle",e);break;case"embed":case"source":case"link":W("error",e),W("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(s in n)if(n.hasOwnProperty(s)&&(o=n[s],o!=null))switch(s){case"children":case"dangerouslySetInnerHTML":throw Error(C(137,t));default:fe(e,t,s,o,n,null)}return;default:if(Fd(t)){for(p in n)n.hasOwnProperty(p)&&(o=n[p],o!==void 0&&Bd(e,t,p,o,n,void 0));return}}for(l in n)n.hasOwnProperty(l)&&(o=n[l],o!=null&&fe(e,t,l,o,n,null))}var Ww={};function eS(e,t,n,o){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var a=null,i=null,r=null,l=null,c=null,s=null,p=null;for(d in n){var b=n[d];if(n.hasOwnProperty(d)&&b!=null)switch(d){case"checked":break;case"value":break;case"defaultValue":c=b;default:o.hasOwnProperty(d)||fe(e,t,d,null,o,b)}}for(var u in o){var d=o[u];if(b=n[u],o.hasOwnProperty(u)&&(d!=null||b!=null))switch(u){case"type":d!==b&&(re=!0),i=d;break;case"name":d!==b&&(re=!0),a=d;break;case"checked":d!==b&&(re=!0),s=d;break;case"defaultChecked":d!==b&&(re=!0),p=d;break;case"value":d!==b&&(re=!0),r=d;break;case"defaultValue":d!==b&&(re=!0),l=d;break;case"children":case"dangerouslySetInnerHTML":if(d!=null)throw Error(C(137,t));break;default:d!==b&&fe(e,t,u,d,o,b)}}Pu(e,r,l,c,s,p,i,a);return;case"select":d=r=l=u=null;for(i in n)if(c=n[i],n.hasOwnProperty(i)&&c!=null)switch(i){case"value":break;case"multiple":d=c;default:o.hasOwnProperty(i)||fe(e,t,i,null,o,c)}for(a in o)if(i=o[a],c=n[a],o.hasOwnProperty(a)&&(i!=null||c!=null))switch(a){case"value":i!==c&&(re=!0),u=i;break;case"defaultValue":i!==c&&(re=!0),l=i;break;case"multiple":i!==c&&(re=!0),r=i;default:i!==c&&fe(e,t,a,i,o,c)}t=l,n=r,o=d,u!=null?ai(e,!!n,u,!1):!!o!=!!n&&(t!=null?ai(e,!!n,t,!0):ai(e,!!n,n?[]:"",!1));return;case"textarea":d=u=null;for(l in n)if(a=n[l],n.hasOwnProperty(l)&&a!=null&&!o.hasOwnProperty(l))switch(l){case"value":break;case"children":break;default:fe(e,t,l,null,o,a)}for(r in o)if(a=o[r],i=n[r],o.hasOwnProperty(r)&&(a!=null||i!=null))switch(r){case"value":a!==i&&(re=!0),u=a;break;case"defaultValue":a!==i&&(re=!0),d=a;break;case"children":break;case"dangerouslySetInnerHTML":if(a!=null)throw Error(C(91));break;default:a!==i&&fe(e,t,r,a,o,i)}Bb(e,u,d);return;case"option":for(var x in n)u=n[x],n.hasOwnProperty(x)&&u!=null&&!o.hasOwnProperty(x)&&(x==="selected"?e.selected=!1:fe(e,t,x,null,o,u));for(c in o)u=o[c],d=n[c],o.hasOwnProperty(c)&&u!==d&&(u!=null||d!=null)&&(c==="selected"?(u!==d&&(re=!0),e.selected=u&&typeof u!="function"&&typeof u!="symbol"):fe(e,t,c,u,o,d));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var k in n)u=n[k],n.hasOwnProperty(k)&&u!=null&&!o.hasOwnProperty(k)&&fe(e,t,k,null,o,u);for(s in o)if(u=o[s],d=n[s],o.hasOwnProperty(s)&&u!==d&&(u!=null||d!=null))switch(s){case"children":case"dangerouslySetInnerHTML":if(u!=null)throw Error(C(137,t));break;default:fe(e,t,s,u,o,d)}return;default:if(Fd(t)){for(var E in n)u=n[E],n.hasOwnProperty(E)&&u!==void 0&&!o.hasOwnProperty(E)&&Bd(e,t,E,void 0,o,u);for(p in o)u=o[p],d=n[p],!o.hasOwnProperty(p)||u===d||u===void 0&&d===void 0||Bd(e,t,p,u,o,d);return}}for(var m in n)u=n[m],n.hasOwnProperty(m)&&u!=null&&!o.hasOwnProperty(m)&&fe(e,t,m,null,o,u);for(b in o)u=o[b],d=n[b],!o.hasOwnProperty(b)||u===d||u==null&&d==null||fe(e,t,b,u,o,d)}function Xg(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function tS(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,n=performance.getEntriesByType("resource"),o=0;o<n.length;o++){var a=n[o],i=a.transferSize,r=a.initiatorType,l=a.duration;if(i&&l&&Xg(r)){for(r=0,l=a.responseEnd,o+=1;o<n.length;o++){var c=n[o],s=c.startTime;if(s>l)break;var p=c.transferSize,b=c.initiatorType;p&&Xg(b)&&(c=c.responseEnd,r+=p*(c<l?1:(l-s)/(c-s)))}if(--o,t+=8*(i+r)/(a.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Ld=null,Ud=null;function Br(e){return e.nodeType===9?e:e.ownerDocument}function Gg(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Vv(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function Kv(e,t,n,o){return n=Br(n).createElement(e),n[Ie]=o,n[Tt]=t,tt(n,e,t),Ze(n),n}function jd(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Du=null;function nS(){var e=window.event;return e&&e.type==="popstate"?e===Du?!1:(Du=e,!0):(Du=null,!1)}var jf=typeof setTimeout=="function"?setTimeout:void 0,oS=typeof clearTimeout=="function"?clearTimeout:void 0,Qg=typeof Promise=="function"?Promise:void 0,Zg=typeof requestAnimationFrame=="function"?requestAnimationFrame:jf,aS=typeof queueMicrotask=="function"?queueMicrotask:typeof Qg<"u"?function(e){return Qg.resolve(null).then(e).catch(iS)}:jf;function iS(e){setTimeout(function(){throw e})}function Bo(e){return e==="head"}function Pg(e,t){var n=t,o=0;do{var a=n.nextSibling;if(e.removeChild(n),a&&a.nodeType===8)if(n=a.data,n==="/$"||n==="/&"){if(o===0){e.removeChild(a),Ti(t);return}o--}else if(n==="$"||n==="$?"||n==="$~"||n==="$!"||n==="&")o++;else if(n==="html")Hu(e.ownerDocument.documentElement);else if(n==="head"){n=e.ownerDocument.head,Hu(n);for(var i=n.firstChild;i;){var r=i.nextSibling,l=i.nodeName;i[Gr]||l==="SCRIPT"||l==="STYLE"||l==="LINK"&&i.rel.toLowerCase()==="stylesheet"||n.removeChild(i),i=r}}else n==="body"&&Hu(e.ownerDocument.body);n=a}while(n);Ti(t)}function $g(e,t){var n=e;e=0;do{var o=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",n.getAttribute("style")===""&&n.removeAttribute("style")):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),o&&o.nodeType===8)if(n=o.data,n==="/$"){if(e===0)break;e--}else n!=="$"&&n!=="$?"&&n!=="$~"&&n!=="$!"||e++;n=o}while(n)}function Xv(e,t,n){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display==="inline"){if(t=e.getClientRects(),t.length===1)var o=1;else for(var a=o=0;a<t.length;a++){var i=t[a];0<i.width&&0<i.height&&o++}o===1&&(e=e.style,e.display=t.length===1?"inline-block":"block",e.marginTop="-"+n.paddingTop,e.marginBottom="-"+n.paddingBottom)}}function Gv(e,t){e=e.style,t=t.style;var n=t!=null?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=n==null||typeof n=="boolean"?"":(""+n).trim(),n=t!=null?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=n==null||typeof n=="boolean"?"":(""+n).trim(),e.display==="inline-block"&&(t==null?e.display=e.margin="":(n=t.display,e.display=n==null||typeof n=="boolean"?"":n,n=t.margin,n!=null?e.margin=n:(n=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=n==null||typeof n=="boolean"?"":n,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=t==null||typeof t=="boolean"?"":t)))}function Qv(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position==="absolute"||t.position==="fixed",clip:t.clipPath!=="none"||t.overflow!=="visible"||t.filter!=="none"||t.mask!=="none"||t.mask!=="none"||t.borderRadius!=="0px",view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function qd(e){var t=e.getBoundingClientRect(),n=getComputedStyle(e);return Qv(t,n,e)}function rS(e){var t=e.getBoundingClientRect();t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height);var n=getComputedStyle(e);return Qv(t,n,e)}function lS(e){return e.documentElement.clientHeight}function cS(e){this.addEventListener("load",e),this.addEventListener("error",e)}function sS(e,t,n,o,a,i,r,l,c){var s=t.nodeType===9?t:t.ownerDocument;try{var p=s.startViewTransition({update:function(){var u=s.defaultView,d=u.navigation&&u.navigation.transition,x=s.fonts.status;o();var k=[];if(x==="loaded"&&(lS(s),s.fonts.status==="loading"&&k.push(s.fonts.ready)),x=k.length,e!==null)for(var E=e.suspenseyImages,m=0,g=0;g<E.length;g++){var f=E[g];if(!f.complete){var y=f.getBoundingClientRect();if(0<y.bottom&&0<y.right&&y.top<u.innerHeight&&y.left<u.innerWidth){if(m+=a0(f),m>sc){k.length=x;break}f=new Promise(cS.bind(f)),k.push(f)}}}if(0<k.length)return u=Promise.race([Promise.all(k),new Promise(function(h){return setTimeout(h,500)})]).then(a,a),(d?Promise.allSettled([d.finished,u]):u).then(i,i);if(a(),d)return d.finished.then(i,i);i()},types:n});s.__reactViewTransition=p;var b=[];return p.ready.then(function(){for(var u=s.documentElement.getAnimations({subtree:!0}),d=0;d<u.length;d++){var x=u[d],k=x.effect,E=k.pseudoElement;if(E!=null&&E.startsWith("::view-transition")){b.push(x),x=k.getKeyframes();for(var m=E=void 0,g=!0,f=0;f<x.length;f++){var y=x[f],h=y.width;if(E===void 0)E=h;else if(E!==h){g=!1;break}if(h=y.height,m===void 0)m=h;else if(m!==h){g=!1;break}delete y.width,delete y.height,y.transform==="none"&&delete y.transform}g&&E!==void 0&&m!==void 0&&(k.setKeyframes(x),g=getComputedStyle(k.target,k.pseudoElement),g.width!==E||g.height!==m)&&(g=x[0],g.width=E,g.height=m,g=x[x.length-1],g.width=E,g.height=m,k.setKeyframes(x))}}r()},function(u){s.__reactViewTransition===p&&(s.__reactViewTransition=null);try{typeof u=="object"&&u!==null&&u.name==="InvalidStateError"&&(u.message==="View transition was skipped because document visibility state is hidden."||u.message==="Skipping view transition because document visibility state has become hidden."||u.message==="Skipping view transition because viewport size changed."||u.message==="Transition was aborted because of invalid state")&&(u=null),u!==null&&c(u)}finally{o(),a(),r()}}),p.finished.finally(function(){for(var u=0;u<b.length;u++)b[u].cancel();s.__reactViewTransition===p&&(s.__reactViewTransition=null),l()}),p}catch{return o(),a(),r(),null}}function ta(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}ta.prototype.animate=function(e,t){return t=typeof t=="number"?{duration:t}:he({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)};ta.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),o=[],a=0;a<n.length;a++){var i=n[a].effect;i!==null&&i.target===e&&i.pseudoElement===t&&o.push(n[a])}return o};ta.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function Zv(e){return{name:e,group:new ta("group",e),imagePair:new ta("image-pair",e),old:new ta("old",e),new:new ta("new",e)}}function jt(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}jt.prototype.addEventListener=function(e,t,n){var o=null,a=null;if(!(n!=null&&typeof n!="boolean"&&(o=n.signal||null,o!==null&&o.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var i=this._eventListeners;if(Pv(i,e,t,n)===-1){var r=this,l=t;n!=null&&typeof n!="boolean"&&n.once===!0&&(l=function(c){r.removeEventListener(e,t,n),typeof t=="function"?t.call(this,c):t.handleEvent(c)}),o!==null&&(a=r.removeEventListener.bind(r,e,t,n),o.addEventListener("abort",a,{once:!0}),a=o.removeEventListener.bind(o,"abort",a)),o=ki(n),i.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:l,cleanup:a}),Et(this._fragmentFiber.child,!1,uS,e,l,o)}this._eventListeners=i}};function uS(e,t,n,o){return Ve(e).addEventListener(t,n,o),!1}jt.prototype.removeEventListener=function(e,t,n){var o=this._eventListeners;if(o!==null&&(t=Pv(o,e,t,n),t!==-1)){var a=o[t];n=a.attachedListener;var i=a.cleanup;a=ki(a.optionsOrUseCapture),Et(this._fragmentFiber.child,!1,dS,e,n,a),o.splice(t,1),i!==null&&i()}};function dS(e,t,n,o){return Ve(e).removeEventListener(t,n,o),!1}function ki(e){return e!=null&&typeof e!="boolean"&&(e.once===!0||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function Jg(e){return e==null?"c=0":typeof e=="boolean"?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")}function Pv(e,t,n,o){if(e.length===0)return-1;o=Jg(o);for(var a=0;a<e.length;a++){var i=e[a];if(i.type===t&&i.listener===n&&Jg(i.optionsOrUseCapture)===o)return a}return-1}jt.prototype.dispatchEvent=function(e){var t=ga(this._fragmentFiber);if(t===null)return!0;t=Ve(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var o=t.nodeType===9?t.createComment(""):document.createTextNode("");if(n)for(var a=0;a<n.length;a++){var i=n[a];o.addEventListener(i.type,i.attachedListener,ki(i.optionsOrUseCapture))}if(t.appendChild(o),e=o.dispatchEvent(e),n)for(a=0;a<n.length;a++)i=n[a],o.removeEventListener(i.type,i.attachedListener,ki(i.optionsOrUseCapture));return t.removeChild(o),e}return t.dispatchEvent(e)};jt.prototype.focus=function(e){Et(this._fragmentFiber.child,!0,$v,e,void 0,void 0)};function $v(e,t){return e.tag===6?!1:(e=Ve(e),SS(e,t))}jt.prototype.focusLast=function(e){var t=[];Et(this._fragmentFiber.child,!0,qf,t,void 0,void 0);for(var n=t.length-1;0<=n&&!$v(t[n],e);n--);};function qf(e,t){return t.push(e),!1}jt.prototype.blur=function(){var e=ga(this._fragmentFiber);e!==null&&(e=Ve(e),e=Br(e).activeElement,e!==null&&Et(this._fragmentFiber.child,!1,fS,e,void 0,void 0))};function fS(e,t){return e.tag===6?!1:(e=Ve(e),e===t||e.contains(t)?(t.blur(),!0):!1)}jt.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),Et(this._fragmentFiber.child,!1,pS,e,void 0,void 0)};function pS(e,t){return e.tag===6||(e=Ve(e),t.observe(e)),!1}jt.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),Et(this._fragmentFiber.child,!1,mS,e,void 0,void 0);for(var n=t=0;n<un.length;n++){var o=un[n];o.fragmentInstance===this&&o.observer===e?e.unobserve(o.instance):un[t++]=o}un.length=t}};function mS(e,t){return e.tag===6||(e=Ve(e),t.unobserve(e)),!1}var un=[],_u=!1;function gS(e,t,n){un.push({fragmentInstance:e,observer:t,instance:n}),_u||(_u=!0,ES(function(){_u=!1;var o=un;un=[];for(var a=0;a<o.length;a++){var i=o[a];i.observer.unobserve(i.instance)}}))}jt.prototype.getClientRects=function(){var e=[];return Et(this._fragmentFiber.child,!1,bS,e,void 0,void 0),e};function bS(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=Ve(e),t.push.apply(t,e.getClientRects());return!1}jt.prototype.getRootNode=function(e){var t=ga(this._fragmentFiber);return t===null?this:Ve(t).getRootNode(e)};jt.prototype.compareDocumentPosition=function(e){var t=ga(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];Et(this._fragmentFiber.child,!1,qf,n,void 0,void 0);var o=Ve(t);if(n.length===0){if(n=o,Am(this._fragmentFiber)){e:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break e}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var a=o=n.compareDocumentPosition(e);return n===e?a=Node.DOCUMENT_POSITION_CONTAINS:o&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=hb(t)[1],n===null?a=Node.DOCUMENT_POSITION_PRECEDING:(e=Ve(n).compareDocumentPosition(e),a=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),a|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=Ve(n[0]),a=Ve(n[n.length-1]);var i=Am(this._fragmentFiber)?t.parentElement:o;if(i==null)return Node.DOCUMENT_POSITION_DISCONNECTED;o=i.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,i=i.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_CONTAINED_BY;var r=t.compareDocumentPosition(e),l=a.compareDocumentPosition(e),c=r&Node.DOCUMENT_POSITION_CONTAINED_BY||l&Node.DOCUMENT_POSITION_CONTAINED_BY;return l=o&&i&&r&Node.DOCUMENT_POSITION_FOLLOWING&&l&Node.DOCUMENT_POSITION_PRECEDING,t=o&&t===e||i&&a===e||c||l?Node.DOCUMENT_POSITION_CONTAINED_BY:!o&&t===e||!i&&a===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:r,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||hS(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function hS(e,t,n,o,a){var i=ea(a);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!i)e:{for(;i!==null;){if(i.tag===7&&(i===t||i.alternate===t)){n=!0;break e}i=i.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(i===null)return i=a.ownerDocument,a===i||a===i.documentElement||a===i.body;e:{for(i=t,t=ga(t);i!==null;){if(!(i.tag!==5&&i.tag!==3&&i.tag!==27||i!==t&&i.alternate!==t)){i=!0;break e}i=i.return}i=!1}return i}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!i)&&!(t=i===n)&&(t=Lu(n,i,zm),t===null?t=!1:(Et(t,!0,Zx,i,n),i=Ga,Ga=null,t=i!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!i)&&!(t=i===o)&&(t=Lu(o,i,zm),t===null?t=!1:(Et(t,!0,Px,i,o),i=Ga,Bu=Ga=null,t=i!==null)),t):!1}function Ig(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}jt.prototype.scrollIntoView=function(e){if(typeof e=="object")throw Error(C(566));var t=[];Et(this._fragmentFiber.child,!1,qf,t,void 0,void 0);var n=e!==!1;if(t.length===0){var o=hb(this._fragmentFiber);if(o=n?o[1]||o[0]||ga(this._fragmentFiber):o[0]||o[1],o===null)return;if(o.tag===6){e=Ve(o),Ig(e,n);return}if(o=Ve(o),o.nodeType!==9){if(o.nodeType===11){n="host"in o?o.host:null,n!==null&&n.scrollIntoView(e);return}o.scrollIntoView(e)}}for(o=n?t.length-1:0;o!==(n?-1:t.length);){var a=t[o];a.tag===6?(a=Ve(a),Ig(a,n)):Ve(a).scrollIntoView(e),o+=n?-1:1}};function vS(e,t){return e=Ve(e),Jv(e,t),!1}function Jv(e,t){e.reactFragments==null&&(e.reactFragments=new Set),e.reactFragments.add(t)}function Iv(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.addEventListener(a.type,a.attachedListener,ki(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(i){for(var r=0,l=0;l<un.length;l++){var c=un[l];(c.fragmentInstance!==t||c.observer!==i||c.instance!==e)&&(un[r++]=c)}un.length=r,i.observe(e)}),Jv(e,t))}function yS(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.removeEventListener(a.type,a.attachedListener,ki(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(i){typeof i.rootMargin=="string"?gS(t,i,e):i.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function Yd(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":Yd(n),Vc(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(n.rel.toLowerCase()==="stylesheet")continue}e.removeChild(n)}}function xS(e,t,n,o){for(;e.nodeType===1;){var a=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[Gr])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(i=e.getAttribute("rel"),i==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(i!==a.rel||e.getAttribute("href")!==(a.href==null||a.href===""?null:a.href)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin)||e.getAttribute("title")!==(a.title==null?null:a.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(i=e.getAttribute("src"),(i!==(a.src==null?null:a.src)||e.getAttribute("type")!==(a.type==null?null:a.type)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin))&&i&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var i=a.name==null?null:""+a.name;if(a.type==="hidden"&&e.getAttribute("name")===i)return e}else return e;if(e=Ft(e.nextSibling),e===null)break}return null}function kS(e,t,n){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=Ft(e.nextSibling),e===null))return null;return e}function Fv(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=Ft(e.nextSibling),e===null))return null;return e}function Vd(e){return e.data==="$?"||e.data==="$~"}function Yf(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function wS(e,t){var n=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||n.readyState!=="loading")t();else{var o=function(){t(),n.removeEventListener("DOMContentLoaded",o)};n.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function Ft(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var Kd=null;function Fg(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"||n==="/&"){if(t===0)return Ft(e.nextSibling);t--}else n!=="$"&&n!=="$!"&&n!=="$?"&&n!=="$~"&&n!=="&"||t++}e=e.nextSibling}return null}function Wg(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"){if(t===0)return e;t--}else n!=="/$"&&n!=="/&"||t++}e=e.previousSibling}return null}function SS(e,t){function n(){o=!0}if(e.ownerDocument.activeElement===e)return!0;var o=!1;try{e.ownerDocument.addEventListener("focus",n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener("focus",n,!0)}return o}function ES(e){Zg(function(){Zg(function(t){return e(t)})})}function Wv(e,t,n){switch(t=Br(n),e){case"html":if(e=t.documentElement,!e)throw Error(C(452));return e;case"head":if(e=t.head,!e)throw Error(C(453));return e;case"body":if(e=t.body,!e)throw Error(C(454));return e;default:throw Error(C(451))}}function e0(e,t,n){for(var o in n){var a=n[o];n.hasOwnProperty(o)&&a!=null&&fe(e,t,o,null,Ww,a)}n.dangerouslySetInnerHTML!=null&&(e.textContent=""),e.onclick===En&&(e.onclick=null),Vc(e)}function Hu(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);Vc(e)}var Wt=new Map,eb=new Set;function Lr(e){if(typeof e.getRootNode=="function"){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var Wn=se.d;se.d={f:TS,r:CS,D:NS,C:MS,L:AS,m:zS,X:RS,S:OS,M:DS};function TS(){var e=Wn.f(),t=ns();return e||t}function CS(e){var t=Ni(e);t!==null&&t.tag===5&&t.type==="form"?Uh(t):Wn.r(e)}var Oi=typeof document>"u"?null:document;function t0(e,t,n){var o=Oi;if(o&&typeof t=="string"&&t){var a=$t(t);a='link[rel="'+e+'"][href="'+a+'"]',typeof n=="string"&&(a+='[crossorigin="'+n+'"]'),eb.has(a)||(eb.add(a),e={rel:e,crossOrigin:n,href:t},o.querySelector(a)===null&&(t=o.createElement("link"),tt(t,"link",e),Ze(t),o.head.appendChild(t)))}}function NS(e){Wn.D(e),t0("dns-prefetch",e,null)}function MS(e,t){Wn.C(e,t),t0("preconnect",e,t)}function AS(e,t,n){Wn.L(e,t,n);var o=Oi;if(o&&e&&t){var a='link[rel="preload"][as="'+$t(t)+'"]';t==="image"&&n&&n.imageSrcSet?(a+='[imagesrcset="'+$t(n.imageSrcSet)+'"]',typeof n.imageSizes=="string"&&(a+='[imagesizes="'+$t(n.imageSizes)+'"]')):a+='[href="'+$t(e)+'"]';var i=a;switch(t){case"style":i=wi(e);break;case"script":i=Ri(e)}if(!(Wt.has(i)||(e=he({rel:"preload",href:t==="image"&&n&&n.imageSrcSet?void 0:e,as:t},n),Wt.set(i,e),o.querySelector(a)!==null||t==="style"&&o.querySelector(Ir(i))||t==="script"&&o.querySelector(Fr(i))))){var r=o.createElement("link");tt(r,"link",e),t==="style"&&(r[bc]=!0,r.onload=r.onerror=function(){zb(r)}),Ze(r),o.head.appendChild(r)}}}function zS(e,t){Wn.m(e,t);var n=Oi;if(n&&e){var o=t&&typeof t.as=="string"?t.as:"script",a='link[rel="modulepreload"][as="'+$t(o)+'"][href="'+$t(e)+'"]',i=a;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":i=Ri(e)}if(!Wt.has(i)&&(e=he({rel:"modulepreload",href:e},t),Wt.set(i,e),n.querySelector(a)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector(Fr(i)))return}o=n.createElement("link"),tt(o,"link",e),Ze(o),n.head.appendChild(o)}}}function OS(e,t,n){Wn.S(e,t,n);var o=Oi;if(o&&e){var a=oi(o).hoistableStyles,i=wi(e);t=t||"default";var r=a.get(i);if(!r){var l={loading:0,preload:null};if(r=o.querySelector(Ir(i)))l.loading=5;else{e=he({rel:"stylesheet",href:e,"data-precedence":t},n),(n=Wt.get(i))&&Vf(e,n);var c=r=o.createElement("link");Ze(c),tt(c,"link",e),c._p=new Promise(function(s,p){c.onload=s,c.onerror=p}),c.addEventListener("load",function(){l.loading|=1}),c.addEventListener("error",function(){l.loading|=2}),l.loading|=4,lc(r,t,o)}r={type:"stylesheet",instance:r,count:1,state:l},a.set(i,r)}}}function RS(e,t){Wn.X(e,t);var n=Oi;if(n&&e){var o=oi(n).hoistableScripts,a=Ri(e),i=o.get(a);i||(i=n.querySelector(Fr(a)),i||(e=he({src:e,async:!0},t),(t=Wt.get(a))&&Kf(e,t),i=n.createElement("script"),Ze(i),tt(i,"link",e),n.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},o.set(a,i))}}function DS(e,t){Wn.M(e,t);var n=Oi;if(n&&e){var o=oi(n).hoistableScripts,a=Ri(e),i=o.get(a);i||(i=n.querySelector(Fr(a)),i||(e=he({src:e,async:!0,type:"module"},t),(t=Wt.get(a))&&Kf(e,t),i=n.createElement("script"),Ze(i),tt(i,"link",e),n.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},o.set(a,i))}}function tb(e,t,n,o){var a=(a=xo.current)?Lr(a):null;if(!a)throw Error(C(446));switch(e){case"meta":case"title":return null;case"style":return typeof n.precedence=="string"&&typeof n.href=="string"?(n=wi(n.href),t=oi(a).hoistableStyles,o=t.get(n),o||(o={type:"style",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(n.rel==="stylesheet"&&typeof n.href=="string"&&typeof n.precedence=="string"){e=wi(n.href);var i=oi(a).hoistableStyles,r=i.get(e);if(r||(a=a.ownerDocument||a,r={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},i.set(e,r),(i=a.querySelector(Ir(e)))?i._p||(r.instance=i,r.state.loading=5):(i=Wt.get(e),i||(i={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},Wt.set(e,i)),_S(a,e,i,r.state))),t&&o===null)throw Error(C(528,""));return r}if(t&&o!==null)throw Error(C(529,""));return null;case"script":return t=n.async,n=n.src,typeof n=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(n=Ri(n),t=oi(a).hoistableScripts,o=t.get(n),o||(o={type:"script",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(C(444,e))}}function wi(e){return'href="'+$t(e)+'"'}function Ir(e){return'link[rel="stylesheet"]['+e+"]"}function n0(e){return he({},e,{"data-precedence":e.precedence,precedence:null})}function _S(e,t,n,o){if(t=e.querySelector('link[rel="preload"][as="style"]['+t+"]")){if(t[bc]!==!0){o.loading=1;return}}else t=e.createElement("link"),t[bc]=!0,t.onload=t.onerror=zb.bind(null,t),tt(t,"link",n),Ze(t),e.head.appendChild(t);o.preload=t,t.addEventListener("load",function(){return o.loading|=1}),t.addEventListener("error",function(){return o.loading|=2})}function Ri(e){return'[src="'+$t(e)+'"]'}function Fr(e){return"script[async]"+e}function nb(e,t,n){if(t.count++,t.instance===null)switch(t.type){case"style":var o=e.querySelector('style[data-href~="'+$t(n.href)+'"]');if(o)return t.instance=o,Ze(o),o;var a=he({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),Ze(o),tt(o,"style",a),lc(o,n.precedence,e),t.instance=o;case"stylesheet":a=wi(n.href);var i=e.querySelector(Ir(a));if(i)return t.state.loading|=4,t.instance=i,Ze(i),i;o=n0(n),(a=Wt.get(a))&&Vf(o,a),i=(e.ownerDocument||e).createElement("link"),Ze(i);var r=i;return r._p=new Promise(function(l,c){r.onload=l,r.onerror=c}),tt(i,"link",o),t.state.loading|=4,lc(i,n.precedence,e),t.instance=i;case"script":return i=Ri(n.src),(a=e.querySelector(Fr(i)))?(t.instance=a,Ze(a),a):(o=n,(a=Wt.get(i))&&(o=he({},n),Kf(o,a)),e=e.ownerDocument||e,a=e.createElement("script"),Ze(a),tt(a,"link",o),e.head.appendChild(a),t.instance=a);case"void":return null;default:throw Error(C(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(o=t.instance,t.state.loading|=4,lc(o,n.precedence,e));return t.instance}function lc(e,t,n){for(var o=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),a=o.length?o[o.length-1]:null,i=a,r=0;r<o.length;r++){var l=o[r];if(l.dataset.precedence===t)i=l;else if(i!==a)break}i?i.parentNode.insertBefore(e,i.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Vf(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function Kf(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var cc=null;function ob(e,t,n){if(cc===null){var o=new Map,a=cc=new Map;a.set(n,o)}else a=cc,o=a.get(n),o||(o=new Map,a.set(n,o));if(o.has(e))return o;for(o.set(e,null),n=n.getElementsByTagName(e),a=0;a<n.length;a++){var i=n[a];if(!(i[Gr]||i[Ie]||e==="link"&&i.getAttribute("rel")==="stylesheet")&&i.namespaceURI!=="http://www.w3.org/2000/svg"){var r=i.getAttribute(t)||"";r=e+r;var l=o.get(r);l?l.push(i):o.set(r,[i])}}return o}function Xd(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t==="title"?e.querySelector("head > title"):null)}function HS(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function ab(e,t){return e==="img"&&t.src!=null&&t.src!==""&&t.onLoad==null&&t.loading!=="lazy"}function o0(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function a0(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function ib(e,t){typeof t.decode=="function"&&(e.imgCount++,t.complete||(e.imgBytes+=a0(t),e.suspenseyImages.push(t)),e=US.bind(e),t.decode().then(e,e))}function BS(e,t,n,o){if(n.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var a=wi(o.href),i=t.querySelector(Ir(a));if(i){t=i._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=Ur.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=i,Ze(i);return}i=t.ownerDocument||t,o=n0(o),(a=Wt.get(a))&&Vf(o,a),i=i.createElement("link"),Ze(i);var r=i;r._p=new Promise(function(l,c){r.onload=l,r.onerror=c}),tt(i,"link",o),n.instance=i}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(e.count++,n=Ur.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}var sc=0;function LS(e,t){return e.stylesheets&&e.count===0&&uc(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var o=setTimeout(function(){if(e.stylesheets&&uc(e,e.stylesheets),e.unsuspend){var i=e.unsuspend;e.unsuspend=null,i()}},6e4+t);0<e.imgBytes&&sc===0&&(sc=62500*tS());var a=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&uc(e,e.stylesheets),e.unsuspend)){var i=e.unsuspend;e.unsuspend=null,i()}},(e.imgBytes>sc?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(a)}}:null}function i0(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)uc(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function Ur(){this.count--,i0(this)}function US(){this.imgCount--,i0(this)}var jc=null;function uc(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,jc=new Map,t.forEach(jS,e),jc=null,Ur.call(e))}function jS(e,t){if(!(t.state.loading&4)){var n=jc.get(e);if(n)var o=n.get(null);else{n=new Map,jc.set(e,n);for(var a=e.querySelectorAll("link[data-precedence],style[data-precedence]"),i=0;i<a.length;i++){var r=a[i];(r.nodeName==="LINK"||r.getAttribute("media")!=="not all")&&(n.set(r.dataset.precedence,r),o=r)}o&&n.set(null,o)}a=t.instance,r=a.getAttribute("data-precedence"),i=n.get(r)||o,i===o&&n.set(null,a),n.set(r,a),this.count++,o=Ur.bind(this),a.addEventListener("load",o),a.addEventListener("error",o),i?i.parentNode.insertBefore(a,i.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(a,e.firstChild)),t.state.loading|=4}}var Si={$$typeof:Sn,Provider:null,Consumer:null,_currentValue:na,_currentValue2:na,_threadCount:0};function qS(e,t,n,o,a,i,r,l,c){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=su(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=su(0),this.hiddenUpdates=su(null),this.identifierPrefix=o,this.onUncaughtError=a,this.onCaughtError=i,this.onRecoverableError=r,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=c,this.transitionTypes=null,this.incompleteTransitions=new Map}function r0(e,t,n,o,a,i,r,l,c,s,p,b){return e=new qS(e,t,n,r,c,s,p,b,l),t=1,i===!0&&(t|=24),i=wt(3,null,null,t),e.current=i,i.stateNode=e,t=sf(),t.refCount++,e.pooledCache=t,t.refCount++,i.memoizedState={element:o,isDehydrated:n,cache:t},ff(i),e}function l0(e){return e?(e=Wa,e):Wa}function c0(e,t,n,o,a,i){a=l0(a),o.context===null?o.context=a:o.pendingContext=a,o=wo(t),o.payload={element:n},i=i===void 0?null:i,i!==null&&(o.callback=i),n=So(e,o,t),n!==null&&(St(n,e,t),br(n,e,t))}function rb(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function Xf(e,t){rb(e,t),(e=e.alternate)&&rb(e,t)}function s0(e){if(e.tag===13||e.tag===31){var t=va(e,67108864);t!==null&&St(t,e,67108864),Xf(e,67108864)}}function lb(e){if(e.tag===13||e.tag===31){var t=Lt();t=Jd(t);var n=va(e,t);n!==null&&St(n,e,t),Xf(e,t)}}var Ei=!0;function YS(e,t,n,o){var a=Y.T;Y.T=null;var i=se.p;try{se.p=2,Gf(e,t,n,o)}finally{se.p=i,Y.T=a}}function VS(e,t,n,o){var a=Y.T;Y.T=null;var i=se.p;try{se.p=8,Gf(e,t,n,o)}finally{se.p=i,Y.T=a}}function Gf(e,t,n,o){if(Ei){var a=Gd(o);if(a===null)Ru(e,t,o,qc,n),cb(e,o);else if(XS(a,e,t,n,o))o.stopPropagation();else if(cb(e,o),t&4&&-1<KS.indexOf(e)){for(;a!==null;){var i=Ni(a);if(i!==null)switch(i.tag){case 3:if(i=i.stateNode,i.current.memoizedState.isDehydrated){var r=Io(i.pendingLanes);if(r!==0){var l=i;for(l.pendingLanes|=2,l.entangledLanes|=2;r;){var c=1<<31-Bt(r);l.entanglements[1]|=c,r&=~c}On(i),(ce&6)===0&&(_c=_t()+500,Jr(0,!1))}}break;case 31:case 13:l=va(i,2),l!==null&&St(l,i,2),ns(),Xf(i,2)}if(i=Gd(o),i===null&&Ru(e,t,o,qc,n),i===a)break;a=i}a!==null&&o.stopPropagation()}else Ru(e,t,o,null,n)}}function Gd(e){return e=Wd(e),Qf(e)}var qc=null;function Qf(e){if(qc=null,e=ea(e),e!==null){var t=Yr(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=mb(t),e!==null)return e;e=null}else if(n===31){if(e=gb(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return qc=e,null}function u0(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(ok()){case kb:return 2;case wb:return 8;case gc:case ak:return 32;case Sb:return 268435456;default:return 32}default:return 32}}var Qd=!1,No=null,Mo=null,Ao=null,jr=new Map,qr=new Map,po=[],KS="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function cb(e,t){switch(e){case"focusin":case"focusout":No=null;break;case"dragenter":case"dragleave":Mo=null;break;case"mouseover":case"mouseout":Ao=null;break;case"pointerover":case"pointerout":jr.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":qr.delete(t.pointerId)}}function ir(e,t,n,o,a,i){return e===null||e.nativeEvent!==i?(e={blockedOn:t,domEventName:n,eventSystemFlags:o,nativeEvent:i,targetContainers:[a]},t!==null&&(t=Ni(t),t!==null&&s0(t)),e):(e.eventSystemFlags|=o,t=e.targetContainers,a!==null&&t.indexOf(a)===-1&&t.push(a),e)}function XS(e,t,n,o,a){switch(t){case"focusin":return No=ir(No,e,t,n,o,a),!0;case"dragenter":return Mo=ir(Mo,e,t,n,o,a),!0;case"mouseover":return Ao=ir(Ao,e,t,n,o,a),!0;case"pointerover":var i=a.pointerId;return jr.set(i,ir(jr.get(i)||null,e,t,n,o,a)),!0;case"gotpointercapture":return i=a.pointerId,qr.set(i,ir(qr.get(i)||null,e,t,n,o,a)),!0}return!1}function d0(e){var t=ea(e.target);if(t!==null){var n=Yr(t);if(n!==null){if(t=n.tag,t===13){if(t=mb(n),t!==null){e.blockedOn=t,_m(e.priority,function(){lb(n)});return}}else if(t===31){if(t=gb(n),t!==null){e.blockedOn=t,_m(e.priority,function(){lb(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function dc(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=Gd(e.nativeEvent);if(n===null){n=e.nativeEvent;var o=new n.constructor(n.type,n);$u=o,n.target.dispatchEvent(o),$u=null}else return t=Ni(n),t!==null&&s0(t),e.blockedOn=n,!1;t.shift()}return!0}function sb(e,t,n){dc(e)&&n.delete(t)}function GS(){Qd=!1,No!==null&&dc(No)&&(No=null),Mo!==null&&dc(Mo)&&(Mo=null),Ao!==null&&dc(Ao)&&(Ao=null),jr.forEach(sb),qr.forEach(sb)}function Gl(e,t){e.blockedOn===t&&(e.blockedOn=null,Qd||(Qd=!0,Ke.unstable_scheduleCallback(Ke.unstable_NormalPriority,GS)))}var Ql=null;function ub(e){Ql!==e&&(Ql=e,Ke.unstable_scheduleCallback(Ke.unstable_NormalPriority,function(){Ql===e&&(Ql=null);for(var t=0;t<e.length;t+=3){var n=e[t],o=e[t+1],a=e[t+2];if(typeof o!="function"){if(Qf(o||n)===null)continue;break}var i=Ni(n);i!==null&&(e.splice(t,3),t-=3,dd(i,{pending:!0,data:a,method:n.method,action:o},o,a))}}))}function Ti(e){function t(c){return Gl(c,e)}No!==null&&Gl(No,e),Mo!==null&&Gl(Mo,e),Ao!==null&&Gl(Ao,e),jr.forEach(t),qr.forEach(t);for(var n=0;n<po.length;n++){var o=po[n];o.blockedOn===e&&(o.blockedOn=null)}for(;0<po.length&&(n=po[0],n.blockedOn===null);)d0(n),n.blockedOn===null&&po.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(o=0;o<n.length;o+=3){var a=n[o],i=n[o+1],r=a[Tt]||null;if(typeof i=="function")r||ub(n);else if(r){var l=null;if(i&&i.hasAttribute("formAction")){if(a=i,r=i[Tt]||null)l=r.formAction;else if(Qf(a)!==null)continue}else l=r.action;typeof l=="function"?n[o+1]=l:(n.splice(o,3),o-=3),ub(n)}}}function f0(){function e(i){i.canIntercept&&i.info==="react-transition"&&i.intercept({handler:function(){return new Promise(function(r){return a=r})},focusReset:"manual",scroll:"manual"})}function t(){a!==null&&(a(),a=null),o||setTimeout(n,20)}function n(){if(!o&&!navigation.transition){var i=navigation.currentEntry;i&&i.url!=null&&navigation.navigate(i.url,{state:i.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,a=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),a!==null&&(a(),a=null)}}}function Zf(e){this._internalRoot=e}is.prototype.render=Zf.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(C(409));var n=t.current,o=Lt();c0(n,o,e,t,null,null)};is.prototype.unmount=Zf.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;c0(e.current,2,null,e,null,null),ns(),t[Ci]=null}};function is(e){this._internalRoot=e}is.prototype.unstable_scheduleHydration=function(e){if(e){var t=Ab();e={blockedOn:null,target:e,priority:t};for(var n=0;n<po.length&&t!==0&&t<po[n].priority;n++);po.splice(n,0,e),n===0&&d0(e)}};var db=fb.version;if(db!=="19.3.0")throw Error(C(527,db,"19.3.0"));se.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(C(188)):(e=Object.keys(e).join(","),Error(C(268,e)));return e=Qx(t),e=e!==null?bb(e):null,e=e===null?null:e.stateNode,e};var QS={bundleType:0,version:"19.3.0",rendererPackageName:"react-dom",currentDispatcherRef:Y,reconcilerVersion:"19.3.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(rr=__REACT_DEVTOOLS_GLOBAL_HOOK__,!rr.isDisabled&&rr.supportsFiber))try{Vr=rr.inject(QS),Ht=rr}catch{}var rr;rs.createRoot=function(e,t){if(!pb(e))throw Error(C(299));var n=!1,o="",a=Qh,i=Zh,r=Ph;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(o=t.identifierPrefix),t.onUncaughtError!==void 0&&(a=t.onUncaughtError),t.onCaughtError!==void 0&&(i=t.onCaughtError),t.onRecoverableError!==void 0&&(r=t.onRecoverableError)),t=r0(e,1,!1,null,null,n,o,null,a,i,r,f0),e[Ci]=t.current,Uf(e),new Zf(t)};rs.hydrateRoot=function(e,t,n){if(!pb(e))throw Error(C(299));var o=!1,a="",i=Qh,r=Zh,l=Ph,c=null;return n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(a=n.identifierPrefix),n.onUncaughtError!==void 0&&(i=n.onUncaughtError),n.onCaughtError!==void 0&&(r=n.onCaughtError),n.onRecoverableError!==void 0&&(l=n.onRecoverableError),n.formState!==void 0&&(c=n.formState)),t=r0(e,1,!0,t,n??null,o,a,c,i,r,l,f0),t.context=l0(null),n=t.current,o=Lt(),o=Jd(o),a=wo(o),a.callback=null,So(n,a,o),n=o,t.current.lanes=n,Xr(t,n),On(t),e[Ci]=t.current,Uf(e),new is(t)};rs.version="19.3.0"});var b0=bn((RE,g0)=>{"use strict";function m0(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(m0)}catch(e){console.error(e)}}m0(),g0.exports=p0()});var D0=bn(hs=>{"use strict";var FS=Symbol.for("react.transitional.element"),WS=Symbol.for("react.fragment");function R0(e,t,n){var o=null;if(n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),"key"in t){n={};for(var a in t)a!=="key"&&(n[a]=t[a])}else n=t;return t=n.ref,{$$typeof:FS,type:e,key:o,ref:t!==void 0?t:null,props:n}}hs.Fragment=WS;hs.jsx=R0;hs.jsxs=R0});var j=bn((BE,_0)=>{"use strict";_0.exports=D0()});var $p=`/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

@font-face {
	font-family: "codicon";
	font-display: block;
	src: url("./codicon.ttf?9aab6318a6710999273bab9c78a9fd71") format("truetype");
}

.codicon[class*='codicon-'] {
	font: normal normal normal 16px/1 codicon;
	display: inline-block;
	text-decoration: none;
	text-rendering: auto;
	text-align: center;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	user-select: none;
	-webkit-user-select: none;
	-ms-user-select: none;
}

/*---------------------
 *  Modifiers
 *-------------------*/

@keyframes codicon-spin {
	100% {
		transform:rotate(360deg);
	}
}

.codicon-sync.codicon-modifier-spin,
.codicon-loading.codicon-modifier-spin,
.codicon-gear.codicon-modifier-spin {
	/* Use steps to throttle FPS to reduce CPU usage */
	animation: codicon-spin 1.5s steps(30) infinite;
}

.codicon-modifier-disabled {
	opacity: 0.5;
}

.codicon-modifier-hidden {
	opacity: 0;
}

/* custom speed & easing for loading icon */
.codicon-loading {
	animation-duration: 1s !important;
	animation-timing-function: cubic-bezier(0.53, 0.21, 0.29, 0.67) !important;
}

/*---------------------
 *  Icons
 *-------------------*/

.codicon-add:before { content: "\\ea60" }
.codicon-plus:before { content: "\\ea60" }
.codicon-gist-new:before { content: "\\ea60" }
.codicon-repo-create:before { content: "\\ea60" }
.codicon-lightbulb:before { content: "\\ea61" }
.codicon-light-bulb:before { content: "\\ea61" }
.codicon-repo:before { content: "\\ea62" }
.codicon-repo-delete:before { content: "\\ea62" }
.codicon-gist-fork:before { content: "\\ea63" }
.codicon-repo-forked:before { content: "\\ea63" }
.codicon-git-pull-request:before { content: "\\ea64" }
.codicon-git-pull-request-abandoned:before { content: "\\ea64" }
.codicon-record-keys:before { content: "\\ea65" }
.codicon-keyboard:before { content: "\\ea65" }
.codicon-tag:before { content: "\\ea66" }
.codicon-git-pull-request-label:before { content: "\\ea66" }
.codicon-tag-add:before { content: "\\ea66" }
.codicon-tag-remove:before { content: "\\ea66" }
.codicon-person:before { content: "\\ea67" }
.codicon-person-follow:before { content: "\\ea67" }
.codicon-person-outline:before { content: "\\ea67" }
.codicon-person-filled:before { content: "\\ea67" }
.codicon-source-control:before { content: "\\ea68" }
.codicon-mirror:before { content: "\\ea69" }
.codicon-mirror-public:before { content: "\\ea69" }
.codicon-star:before { content: "\\ea6a" }
.codicon-star-add:before { content: "\\ea6a" }
.codicon-star-delete:before { content: "\\ea6a" }
.codicon-star-empty:before { content: "\\ea6a" }
.codicon-comment:before { content: "\\ea6b" }
.codicon-comment-add:before { content: "\\ea6b" }
.codicon-alert:before { content: "\\ea6c" }
.codicon-warning:before { content: "\\ea6c" }
.codicon-search:before { content: "\\ea6d" }
.codicon-search-save:before { content: "\\ea6d" }
.codicon-log-out:before { content: "\\ea6e" }
.codicon-sign-out:before { content: "\\ea6e" }
.codicon-log-in:before { content: "\\ea6f" }
.codicon-sign-in:before { content: "\\ea6f" }
.codicon-eye:before { content: "\\ea70" }
.codicon-eye-unwatch:before { content: "\\ea70" }
.codicon-eye-watch:before { content: "\\ea70" }
.codicon-circle-filled:before { content: "\\ea71" }
.codicon-primitive-dot:before { content: "\\ea71" }
.codicon-close-dirty:before { content: "\\ea71" }
.codicon-debug-breakpoint:before { content: "\\ea71" }
.codicon-debug-breakpoint-disabled:before { content: "\\ea71" }
.codicon-debug-hint:before { content: "\\ea71" }
.codicon-terminal-decoration-success:before { content: "\\ea71" }
.codicon-primitive-square:before { content: "\\ea72" }
.codicon-edit:before { content: "\\ea73" }
.codicon-pencil:before { content: "\\ea73" }
.codicon-info:before { content: "\\ea74" }
.codicon-issue-opened:before { content: "\\ea74" }
.codicon-gist-private:before { content: "\\ea75" }
.codicon-git-fork-private:before { content: "\\ea75" }
.codicon-lock:before { content: "\\ea75" }
.codicon-mirror-private:before { content: "\\ea75" }
.codicon-close:before { content: "\\ea76" }
.codicon-remove-close:before { content: "\\ea76" }
.codicon-x:before { content: "\\ea76" }
.codicon-repo-sync:before { content: "\\ea77" }
.codicon-sync:before { content: "\\ea77" }
.codicon-clone:before { content: "\\ea78" }
.codicon-desktop-download:before { content: "\\ea78" }
.codicon-beaker:before { content: "\\ea79" }
.codicon-microscope:before { content: "\\ea79" }
.codicon-vm:before { content: "\\ea7a" }
.codicon-device-desktop:before { content: "\\ea7a" }
.codicon-file:before { content: "\\ea7b" }
.codicon-more:before { content: "\\ea7c" }
.codicon-ellipsis:before { content: "\\ea7c" }
.codicon-kebab-horizontal:before { content: "\\ea7c" }
.codicon-mail-reply:before { content: "\\ea7d" }
.codicon-reply:before { content: "\\ea7d" }
.codicon-organization:before { content: "\\ea7e" }
.codicon-organization-filled:before { content: "\\ea7e" }
.codicon-organization-outline:before { content: "\\ea7e" }
.codicon-new-file:before { content: "\\ea7f" }
.codicon-file-add:before { content: "\\ea7f" }
.codicon-new-folder:before { content: "\\ea80" }
.codicon-file-directory-create:before { content: "\\ea80" }
.codicon-trash:before { content: "\\ea81" }
.codicon-trashcan:before { content: "\\ea81" }
.codicon-history:before { content: "\\ea82" }
.codicon-clock:before { content: "\\ea82" }
.codicon-folder:before { content: "\\ea83" }
.codicon-file-directory:before { content: "\\ea83" }
.codicon-symbol-folder:before { content: "\\ea83" }
.codicon-logo-github:before { content: "\\ea84" }
.codicon-mark-github:before { content: "\\ea84" }
.codicon-github:before { content: "\\ea84" }
.codicon-terminal:before { content: "\\ea85" }
.codicon-console:before { content: "\\ea85" }
.codicon-repl:before { content: "\\ea85" }
.codicon-zap:before { content: "\\ea86" }
.codicon-symbol-event:before { content: "\\ea86" }
.codicon-error:before { content: "\\ea87" }
.codicon-stop:before { content: "\\ea87" }
.codicon-variable:before { content: "\\ea88" }
.codicon-symbol-variable:before { content: "\\ea88" }
.codicon-array:before { content: "\\ea8a" }
.codicon-symbol-array:before { content: "\\ea8a" }
.codicon-symbol-module:before { content: "\\ea8b" }
.codicon-symbol-package:before { content: "\\ea8b" }
.codicon-symbol-namespace:before { content: "\\ea8b" }
.codicon-symbol-object:before { content: "\\ea8b" }
.codicon-symbol-method:before { content: "\\ea8c" }
.codicon-symbol-function:before { content: "\\ea8c" }
.codicon-symbol-constructor:before { content: "\\ea8c" }
.codicon-symbol-boolean:before { content: "\\ea8f" }
.codicon-symbol-null:before { content: "\\ea8f" }
.codicon-symbol-numeric:before { content: "\\ea90" }
.codicon-symbol-number:before { content: "\\ea90" }
.codicon-symbol-structure:before { content: "\\ea91" }
.codicon-symbol-struct:before { content: "\\ea91" }
.codicon-symbol-parameter:before { content: "\\ea92" }
.codicon-symbol-type-parameter:before { content: "\\ea92" }
.codicon-symbol-key:before { content: "\\ea93" }
.codicon-symbol-text:before { content: "\\ea93" }
.codicon-symbol-reference:before { content: "\\ea94" }
.codicon-go-to-file:before { content: "\\ea94" }
.codicon-symbol-enum:before { content: "\\ea95" }
.codicon-symbol-value:before { content: "\\ea95" }
.codicon-symbol-ruler:before { content: "\\ea96" }
.codicon-symbol-unit:before { content: "\\ea96" }
.codicon-activate-breakpoints:before { content: "\\ea97" }
.codicon-archive:before { content: "\\ea98" }
.codicon-arrow-both:before { content: "\\ea99" }
.codicon-arrow-down:before { content: "\\ea9a" }
.codicon-arrow-left:before { content: "\\ea9b" }
.codicon-arrow-right:before { content: "\\ea9c" }
.codicon-arrow-small-down:before { content: "\\ea9d" }
.codicon-arrow-small-left:before { content: "\\ea9e" }
.codicon-arrow-small-right:before { content: "\\ea9f" }
.codicon-arrow-small-up:before { content: "\\eaa0" }
.codicon-arrow-up:before { content: "\\eaa1" }
.codicon-bell:before { content: "\\eaa2" }
.codicon-bold:before { content: "\\eaa3" }
.codicon-book:before { content: "\\eaa4" }
.codicon-bookmark:before { content: "\\eaa5" }
.codicon-debug-breakpoint-conditional-unverified:before { content: "\\eaa6" }
.codicon-debug-breakpoint-conditional:before { content: "\\eaa7" }
.codicon-debug-breakpoint-conditional-disabled:before { content: "\\eaa7" }
.codicon-debug-breakpoint-data-unverified:before { content: "\\eaa8" }
.codicon-debug-breakpoint-data:before { content: "\\eaa9" }
.codicon-debug-breakpoint-data-disabled:before { content: "\\eaa9" }
.codicon-debug-breakpoint-log-unverified:before { content: "\\eaaa" }
.codicon-debug-breakpoint-log:before { content: "\\eaab" }
.codicon-debug-breakpoint-log-disabled:before { content: "\\eaab" }
.codicon-briefcase:before { content: "\\eaac" }
.codicon-broadcast:before { content: "\\eaad" }
.codicon-browser:before { content: "\\eaae" }
.codicon-bug:before { content: "\\eaaf" }
.codicon-calendar:before { content: "\\eab0" }
.codicon-case-sensitive:before { content: "\\eab1" }
.codicon-check:before { content: "\\eab2" }
.codicon-checklist:before { content: "\\eab3" }
.codicon-chevron-down:before { content: "\\eab4" }
.codicon-chevron-left:before { content: "\\eab5" }
.codicon-chevron-right:before { content: "\\eab6" }
.codicon-chevron-up:before { content: "\\eab7" }
.codicon-chrome-close:before { content: "\\eab8" }
.codicon-chrome-maximize:before { content: "\\eab9" }
.codicon-chrome-minimize:before { content: "\\eaba" }
.codicon-chrome-restore:before { content: "\\eabb" }
.codicon-circle-outline:before { content: "\\eabc" }
.codicon-circle:before { content: "\\eabc" }
.codicon-debug-breakpoint-unverified:before { content: "\\eabc" }
.codicon-terminal-decoration-incomplete:before { content: "\\eabc" }
.codicon-circle-slash:before { content: "\\eabd" }
.codicon-circuit-board:before { content: "\\eabe" }
.codicon-clear-all:before { content: "\\eabf" }
.codicon-clippy:before { content: "\\eac0" }
.codicon-close-all:before { content: "\\eac1" }
.codicon-cloud-download:before { content: "\\eac2" }
.codicon-cloud-upload:before { content: "\\eac3" }
.codicon-code:before { content: "\\eac4" }
.codicon-collapse-all:before { content: "\\eac5" }
.codicon-color-mode:before { content: "\\eac6" }
.codicon-comment-discussion:before { content: "\\eac7" }
.codicon-credit-card:before { content: "\\eac9" }
.codicon-dash:before { content: "\\eacc" }
.codicon-dashboard:before { content: "\\eacd" }
.codicon-database:before { content: "\\eace" }
.codicon-debug-continue:before { content: "\\eacf" }
.codicon-debug-disconnect:before { content: "\\ead0" }
.codicon-debug-pause:before { content: "\\ead1" }
.codicon-debug-restart:before { content: "\\ead2" }
.codicon-debug-start:before { content: "\\ead3" }
.codicon-debug-step-into:before { content: "\\ead4" }
.codicon-debug-step-out:before { content: "\\ead5" }
.codicon-debug-step-over:before { content: "\\ead6" }
.codicon-debug-stop:before { content: "\\ead7" }
.codicon-debug:before { content: "\\ead8" }
.codicon-device-camera-video:before { content: "\\ead9" }
.codicon-device-camera:before { content: "\\eada" }
.codicon-device-mobile:before { content: "\\eadb" }
.codicon-diff-added:before { content: "\\eadc" }
.codicon-diff-ignored:before { content: "\\eadd" }
.codicon-diff-modified:before { content: "\\eade" }
.codicon-diff-removed:before { content: "\\eadf" }
.codicon-diff-renamed:before { content: "\\eae0" }
.codicon-diff:before { content: "\\eae1" }
.codicon-diff-sidebyside:before { content: "\\eae1" }
.codicon-discard:before { content: "\\eae2" }
.codicon-editor-layout:before { content: "\\eae3" }
.codicon-empty-window:before { content: "\\eae4" }
.codicon-exclude:before { content: "\\eae5" }
.codicon-extensions:before { content: "\\eae6" }
.codicon-eye-closed:before { content: "\\eae7" }
.codicon-file-binary:before { content: "\\eae8" }
.codicon-file-code:before { content: "\\eae9" }
.codicon-file-media:before { content: "\\eaea" }
.codicon-file-pdf:before { content: "\\eaeb" }
.codicon-file-submodule:before { content: "\\eaec" }
.codicon-file-symlink-directory:before { content: "\\eaed" }
.codicon-file-symlink-file:before { content: "\\eaee" }
.codicon-file-zip:before { content: "\\eaef" }
.codicon-files:before { content: "\\eaf0" }
.codicon-filter:before { content: "\\eaf1" }
.codicon-flame:before { content: "\\eaf2" }
.codicon-fold-down:before { content: "\\eaf3" }
.codicon-fold-up:before { content: "\\eaf4" }
.codicon-fold:before { content: "\\eaf5" }
.codicon-folder-active:before { content: "\\eaf6" }
.codicon-folder-opened:before { content: "\\eaf7" }
.codicon-gear:before { content: "\\eaf8" }
.codicon-gift:before { content: "\\eaf9" }
.codicon-gist-secret:before { content: "\\eafa" }
.codicon-gist:before { content: "\\eafb" }
.codicon-git-commit:before { content: "\\eafc" }
.codicon-git-compare:before { content: "\\eafd" }
.codicon-compare-changes:before { content: "\\eafd" }
.codicon-git-merge:before { content: "\\eafe" }
.codicon-github-action:before { content: "\\eaff" }
.codicon-github-alt:before { content: "\\eb00" }
.codicon-globe:before { content: "\\eb01" }
.codicon-grabber:before { content: "\\eb02" }
.codicon-graph:before { content: "\\eb03" }
.codicon-gripper:before { content: "\\eb04" }
.codicon-heart:before { content: "\\eb05" }
.codicon-home:before { content: "\\eb06" }
.codicon-horizontal-rule:before { content: "\\eb07" }
.codicon-hubot:before { content: "\\eb08" }
.codicon-inbox:before { content: "\\eb09" }
.codicon-issue-reopened:before { content: "\\eb0b" }
.codicon-issues:before { content: "\\eb0c" }
.codicon-italic:before { content: "\\eb0d" }
.codicon-jersey:before { content: "\\eb0e" }
.codicon-json:before { content: "\\eb0f" }
.codicon-bracket:before { content: "\\eb0f" }
.codicon-kebab-vertical:before { content: "\\eb10" }
.codicon-key:before { content: "\\eb11" }
.codicon-law:before { content: "\\eb12" }
.codicon-lightbulb-autofix:before { content: "\\eb13" }
.codicon-link-external:before { content: "\\eb14" }
.codicon-link:before { content: "\\eb15" }
.codicon-list-ordered:before { content: "\\eb16" }
.codicon-list-unordered:before { content: "\\eb17" }
.codicon-live-share:before { content: "\\eb18" }
.codicon-loading:before { content: "\\eb19" }
.codicon-location:before { content: "\\eb1a" }
.codicon-mail-read:before { content: "\\eb1b" }
.codicon-mail:before { content: "\\eb1c" }
.codicon-markdown:before { content: "\\eb1d" }
.codicon-megaphone:before { content: "\\eb1e" }
.codicon-mention:before { content: "\\eb1f" }
.codicon-milestone:before { content: "\\eb20" }
.codicon-git-pull-request-milestone:before { content: "\\eb20" }
.codicon-mortar-board:before { content: "\\eb21" }
.codicon-move:before { content: "\\eb22" }
.codicon-multiple-windows:before { content: "\\eb23" }
.codicon-mute:before { content: "\\eb24" }
.codicon-no-newline:before { content: "\\eb25" }
.codicon-note:before { content: "\\eb26" }
.codicon-octoface:before { content: "\\eb27" }
.codicon-open-preview:before { content: "\\eb28" }
.codicon-package:before { content: "\\eb29" }
.codicon-paintcan:before { content: "\\eb2a" }
.codicon-pin:before { content: "\\eb2b" }
.codicon-play:before { content: "\\eb2c" }
.codicon-run:before { content: "\\eb2c" }
.codicon-plug:before { content: "\\eb2d" }
.codicon-preserve-case:before { content: "\\eb2e" }
.codicon-preview:before { content: "\\eb2f" }
.codicon-project:before { content: "\\eb30" }
.codicon-pulse:before { content: "\\eb31" }
.codicon-question:before { content: "\\eb32" }
.codicon-quote:before { content: "\\eb33" }
.codicon-radio-tower:before { content: "\\eb34" }
.codicon-reactions:before { content: "\\eb35" }
.codicon-references:before { content: "\\eb36" }
.codicon-refresh:before { content: "\\eb37" }
.codicon-regex:before { content: "\\eb38" }
.codicon-remote-explorer:before { content: "\\eb39" }
.codicon-remote:before { content: "\\eb3a" }
.codicon-remove:before { content: "\\eb3b" }
.codicon-replace-all:before { content: "\\eb3c" }
.codicon-replace:before { content: "\\eb3d" }
.codicon-repo-clone:before { content: "\\eb3e" }
.codicon-repo-force-push:before { content: "\\eb3f" }
.codicon-repo-pull:before { content: "\\eb40" }
.codicon-repo-push:before { content: "\\eb41" }
.codicon-report:before { content: "\\eb42" }
.codicon-request-changes:before { content: "\\eb43" }
.codicon-rocket:before { content: "\\eb44" }
.codicon-root-folder-opened:before { content: "\\eb45" }
.codicon-root-folder:before { content: "\\eb46" }
.codicon-rss:before { content: "\\eb47" }
.codicon-ruby:before { content: "\\eb48" }
.codicon-save-all:before { content: "\\eb49" }
.codicon-save-as:before { content: "\\eb4a" }
.codicon-save:before { content: "\\eb4b" }
.codicon-screen-full:before { content: "\\eb4c" }
.codicon-screen-normal:before { content: "\\eb4d" }
.codicon-search-stop:before { content: "\\eb4e" }
.codicon-server:before { content: "\\eb50" }
.codicon-settings-gear:before { content: "\\eb51" }
.codicon-settings:before { content: "\\eb52" }
.codicon-shield:before { content: "\\eb53" }
.codicon-smiley:before { content: "\\eb54" }
.codicon-sort-precedence:before { content: "\\eb55" }
.codicon-split-horizontal:before { content: "\\eb56" }
.codicon-split-vertical:before { content: "\\eb57" }
.codicon-squirrel:before { content: "\\eb58" }
.codicon-star-full:before { content: "\\eb59" }
.codicon-star-half:before { content: "\\eb5a" }
.codicon-symbol-class:before { content: "\\eb5b" }
.codicon-symbol-color:before { content: "\\eb5c" }
.codicon-symbol-constant:before { content: "\\eb5d" }
.codicon-symbol-enum-member:before { content: "\\eb5e" }
.codicon-symbol-field:before { content: "\\eb5f" }
.codicon-symbol-file:before { content: "\\eb60" }
.codicon-symbol-interface:before { content: "\\eb61" }
.codicon-symbol-keyword:before { content: "\\eb62" }
.codicon-symbol-misc:before { content: "\\eb63" }
.codicon-symbol-operator:before { content: "\\eb64" }
.codicon-symbol-property:before { content: "\\eb65" }
.codicon-wrench:before { content: "\\eb65" }
.codicon-wrench-subaction:before { content: "\\eb65" }
.codicon-symbol-snippet:before { content: "\\eb66" }
.codicon-tasklist:before { content: "\\eb67" }
.codicon-telescope:before { content: "\\eb68" }
.codicon-text-size:before { content: "\\eb69" }
.codicon-three-bars:before { content: "\\eb6a" }
.codicon-thumbsdown:before { content: "\\eb6b" }
.codicon-thumbsup:before { content: "\\eb6c" }
.codicon-tools:before { content: "\\eb6d" }
.codicon-triangle-down:before { content: "\\eb6e" }
.codicon-triangle-left:before { content: "\\eb6f" }
.codicon-triangle-right:before { content: "\\eb70" }
.codicon-triangle-up:before { content: "\\eb71" }
.codicon-twitter:before { content: "\\eb72" }
.codicon-unfold:before { content: "\\eb73" }
.codicon-unlock:before { content: "\\eb74" }
.codicon-unmute:before { content: "\\eb75" }
.codicon-unverified:before { content: "\\eb76" }
.codicon-verified:before { content: "\\eb77" }
.codicon-versions:before { content: "\\eb78" }
.codicon-vm-active:before { content: "\\eb79" }
.codicon-vm-outline:before { content: "\\eb7a" }
.codicon-vm-running:before { content: "\\eb7b" }
.codicon-watch:before { content: "\\eb7c" }
.codicon-whitespace:before { content: "\\eb7d" }
.codicon-whole-word:before { content: "\\eb7e" }
.codicon-window:before { content: "\\eb7f" }
.codicon-word-wrap:before { content: "\\eb80" }
.codicon-zoom-in:before { content: "\\eb81" }
.codicon-zoom-out:before { content: "\\eb82" }
.codicon-list-filter:before { content: "\\eb83" }
.codicon-list-flat:before { content: "\\eb84" }
.codicon-list-selection:before { content: "\\eb85" }
.codicon-selection:before { content: "\\eb85" }
.codicon-list-tree:before { content: "\\eb86" }
.codicon-debug-breakpoint-function-unverified:before { content: "\\eb87" }
.codicon-debug-breakpoint-function:before { content: "\\eb88" }
.codicon-debug-breakpoint-function-disabled:before { content: "\\eb88" }
.codicon-debug-stackframe-active:before { content: "\\eb89" }
.codicon-circle-small-filled:before { content: "\\eb8a" }
.codicon-debug-stackframe-dot:before { content: "\\eb8a" }
.codicon-terminal-decoration-mark:before { content: "\\eb8a" }
.codicon-debug-stackframe:before { content: "\\eb8b" }
.codicon-debug-stackframe-focused:before { content: "\\eb8b" }
.codicon-debug-breakpoint-unsupported:before { content: "\\eb8c" }
.codicon-symbol-string:before { content: "\\eb8d" }
.codicon-debug-reverse-continue:before { content: "\\eb8e" }
.codicon-debug-step-back:before { content: "\\eb8f" }
.codicon-debug-restart-frame:before { content: "\\eb90" }
.codicon-debug-alt:before { content: "\\eb91" }
.codicon-call-incoming:before { content: "\\eb92" }
.codicon-call-outgoing:before { content: "\\eb93" }
.codicon-menu:before { content: "\\eb94" }
.codicon-expand-all:before { content: "\\eb95" }
.codicon-feedback:before { content: "\\eb96" }
.codicon-git-pull-request-reviewer:before { content: "\\eb96" }
.codicon-group-by-ref-type:before { content: "\\eb97" }
.codicon-ungroup-by-ref-type:before { content: "\\eb98" }
.codicon-account:before { content: "\\eb99" }
.codicon-git-pull-request-assignee:before { content: "\\eb99" }
.codicon-bell-dot:before { content: "\\eb9a" }
.codicon-debug-console:before { content: "\\eb9b" }
.codicon-library:before { content: "\\eb9c" }
.codicon-output:before { content: "\\eb9d" }
.codicon-run-all:before { content: "\\eb9e" }
.codicon-sync-ignored:before { content: "\\eb9f" }
.codicon-pinned:before { content: "\\eba0" }
.codicon-github-inverted:before { content: "\\eba1" }
.codicon-server-process:before { content: "\\eba2" }
.codicon-server-environment:before { content: "\\eba3" }
.codicon-pass:before { content: "\\eba4" }
.codicon-issue-closed:before { content: "\\eba4" }
.codicon-stop-circle:before { content: "\\eba5" }
.codicon-play-circle:before { content: "\\eba6" }
.codicon-record:before { content: "\\eba7" }
.codicon-debug-alt-small:before { content: "\\eba8" }
.codicon-vm-connect:before { content: "\\eba9" }
.codicon-cloud:before { content: "\\ebaa" }
.codicon-merge:before { content: "\\ebab" }
.codicon-export:before { content: "\\ebac" }
.codicon-graph-left:before { content: "\\ebad" }
.codicon-magnet:before { content: "\\ebae" }
.codicon-notebook:before { content: "\\ebaf" }
.codicon-redo:before { content: "\\ebb0" }
.codicon-check-all:before { content: "\\ebb1" }
.codicon-pinned-dirty:before { content: "\\ebb2" }
.codicon-pass-filled:before { content: "\\ebb3" }
.codicon-circle-large-filled:before { content: "\\ebb4" }
.codicon-circle-large:before { content: "\\ebb5" }
.codicon-circle-large-outline:before { content: "\\ebb5" }
.codicon-combine:before { content: "\\ebb6" }
.codicon-gather:before { content: "\\ebb6" }
.codicon-table:before { content: "\\ebb7" }
.codicon-variable-group:before { content: "\\ebb8" }
.codicon-type-hierarchy:before { content: "\\ebb9" }
.codicon-type-hierarchy-sub:before { content: "\\ebba" }
.codicon-type-hierarchy-super:before { content: "\\ebbb" }
.codicon-git-pull-request-create:before { content: "\\ebbc" }
.codicon-run-above:before { content: "\\ebbd" }
.codicon-run-below:before { content: "\\ebbe" }
.codicon-notebook-template:before { content: "\\ebbf" }
.codicon-debug-rerun:before { content: "\\ebc0" }
.codicon-workspace-trusted:before { content: "\\ebc1" }
.codicon-workspace-untrusted:before { content: "\\ebc2" }
.codicon-workspace-unknown:before { content: "\\ebc3" }
.codicon-terminal-cmd:before { content: "\\ebc4" }
.codicon-terminal-debian:before { content: "\\ebc5" }
.codicon-terminal-linux:before { content: "\\ebc6" }
.codicon-terminal-powershell:before { content: "\\ebc7" }
.codicon-terminal-tmux:before { content: "\\ebc8" }
.codicon-terminal-ubuntu:before { content: "\\ebc9" }
.codicon-terminal-bash:before { content: "\\ebca" }
.codicon-arrow-swap:before { content: "\\ebcb" }
.codicon-copy:before { content: "\\ebcc" }
.codicon-person-add:before { content: "\\ebcd" }
.codicon-filter-filled:before { content: "\\ebce" }
.codicon-wand:before { content: "\\ebcf" }
.codicon-debug-line-by-line:before { content: "\\ebd0" }
.codicon-inspect:before { content: "\\ebd1" }
.codicon-layers:before { content: "\\ebd2" }
.codicon-layers-dot:before { content: "\\ebd3" }
.codicon-layers-active:before { content: "\\ebd4" }
.codicon-compass:before { content: "\\ebd5" }
.codicon-compass-dot:before { content: "\\ebd6" }
.codicon-compass-active:before { content: "\\ebd7" }
.codicon-azure:before { content: "\\ebd8" }
.codicon-issue-draft:before { content: "\\ebd9" }
.codicon-git-pull-request-closed:before { content: "\\ebda" }
.codicon-git-pull-request-draft:before { content: "\\ebdb" }
.codicon-debug-all:before { content: "\\ebdc" }
.codicon-debug-coverage:before { content: "\\ebdd" }
.codicon-run-errors:before { content: "\\ebde" }
.codicon-folder-library:before { content: "\\ebdf" }
.codicon-debug-continue-small:before { content: "\\ebe0" }
.codicon-beaker-stop:before { content: "\\ebe1" }
.codicon-graph-line:before { content: "\\ebe2" }
.codicon-graph-scatter:before { content: "\\ebe3" }
.codicon-pie-chart:before { content: "\\ebe4" }
.codicon-bracket-dot:before { content: "\\ebe5" }
.codicon-bracket-error:before { content: "\\ebe6" }
.codicon-lock-small:before { content: "\\ebe7" }
.codicon-azure-devops:before { content: "\\ebe8" }
.codicon-verified-filled:before { content: "\\ebe9" }
.codicon-newline:before { content: "\\ebea" }
.codicon-layout:before { content: "\\ebeb" }
.codicon-layout-activitybar-left:before { content: "\\ebec" }
.codicon-layout-activitybar-right:before { content: "\\ebed" }
.codicon-layout-panel-left:before { content: "\\ebee" }
.codicon-layout-panel-center:before { content: "\\ebef" }
.codicon-layout-panel-justify:before { content: "\\ebf0" }
.codicon-layout-panel-right:before { content: "\\ebf1" }
.codicon-layout-panel:before { content: "\\ebf2" }
.codicon-layout-sidebar-left:before { content: "\\ebf3" }
.codicon-layout-sidebar-right:before { content: "\\ebf4" }
.codicon-layout-statusbar:before { content: "\\ebf5" }
.codicon-layout-menubar:before { content: "\\ebf6" }
.codicon-layout-centered:before { content: "\\ebf7" }
.codicon-target:before { content: "\\ebf8" }
.codicon-indent:before { content: "\\ebf9" }
.codicon-record-small:before { content: "\\ebfa" }
.codicon-error-small:before { content: "\\ebfb" }
.codicon-terminal-decoration-error:before { content: "\\ebfb" }
.codicon-arrow-circle-down:before { content: "\\ebfc" }
.codicon-arrow-circle-left:before { content: "\\ebfd" }
.codicon-arrow-circle-right:before { content: "\\ebfe" }
.codicon-arrow-circle-up:before { content: "\\ebff" }
.codicon-layout-sidebar-right-off:before { content: "\\ec00" }
.codicon-layout-panel-off:before { content: "\\ec01" }
.codicon-layout-sidebar-left-off:before { content: "\\ec02" }
.codicon-blank:before { content: "\\ec03" }
.codicon-heart-filled:before { content: "\\ec04" }
.codicon-map:before { content: "\\ec05" }
.codicon-map-horizontal:before { content: "\\ec05" }
.codicon-fold-horizontal:before { content: "\\ec05" }
.codicon-map-filled:before { content: "\\ec06" }
.codicon-map-horizontal-filled:before { content: "\\ec06" }
.codicon-fold-horizontal-filled:before { content: "\\ec06" }
.codicon-circle-small:before { content: "\\ec07" }
.codicon-bell-slash:before { content: "\\ec08" }
.codicon-bell-slash-dot:before { content: "\\ec09" }
.codicon-comment-unresolved:before { content: "\\ec0a" }
.codicon-git-pull-request-go-to-changes:before { content: "\\ec0b" }
.codicon-git-pull-request-new-changes:before { content: "\\ec0c" }
.codicon-search-fuzzy:before { content: "\\ec0d" }
.codicon-comment-draft:before { content: "\\ec0e" }
.codicon-send:before { content: "\\ec0f" }
.codicon-sparkle:before { content: "\\ec10" }
.codicon-insert:before { content: "\\ec11" }
.codicon-mic:before { content: "\\ec12" }
.codicon-thumbsdown-filled:before { content: "\\ec13" }
.codicon-thumbsup-filled:before { content: "\\ec14" }
.codicon-coffee:before { content: "\\ec15" }
.codicon-snake:before { content: "\\ec16" }
.codicon-game:before { content: "\\ec17" }
.codicon-vr:before { content: "\\ec18" }
.codicon-chip:before { content: "\\ec19" }
.codicon-piano:before { content: "\\ec1a" }
.codicon-music:before { content: "\\ec1b" }
.codicon-mic-filled:before { content: "\\ec1c" }
.codicon-repo-fetch:before { content: "\\ec1d" }
.codicon-copilot:before { content: "\\ec1e" }
.codicon-lightbulb-sparkle:before { content: "\\ec1f" }
.codicon-robot:before { content: "\\ec20" }
.codicon-sparkle-filled:before { content: "\\ec21" }
.codicon-diff-single:before { content: "\\ec22" }
.codicon-diff-multiple:before { content: "\\ec23" }
.codicon-surround-with:before { content: "\\ec24" }
.codicon-share:before { content: "\\ec25" }
.codicon-git-stash:before { content: "\\ec26" }
.codicon-git-stash-apply:before { content: "\\ec27" }
.codicon-git-stash-pop:before { content: "\\ec28" }
.codicon-vscode:before { content: "\\ec29" }
.codicon-vscode-insiders:before { content: "\\ec2a" }
.codicon-code-oss:before { content: "\\ec2b" }
.codicon-run-coverage:before { content: "\\ec2c" }
.codicon-run-all-coverage:before { content: "\\ec2d" }
.codicon-coverage:before { content: "\\ec2e" }
.codicon-github-project:before { content: "\\ec2f" }
.codicon-map-vertical:before { content: "\\ec30" }
.codicon-fold-vertical:before { content: "\\ec30" }
.codicon-map-vertical-filled:before { content: "\\ec31" }
.codicon-fold-vertical-filled:before { content: "\\ec31" }
.codicon-go-to-search:before { content: "\\ec32" }
.codicon-percentage:before { content: "\\ec33" }
.codicon-sort-percentage:before { content: "\\ec33" }
.codicon-attach:before { content: "\\ec34" }
.codicon-go-to-editing-session:before { content: "\\ec35" }
.codicon-edit-session:before { content: "\\ec36" }
.codicon-code-review:before { content: "\\ec37" }
.codicon-copilot-warning:before { content: "\\ec38" }
.codicon-python:before { content: "\\ec39" }
.codicon-copilot-large:before { content: "\\ec3a" }
.codicon-copilot-warning-large:before { content: "\\ec3b" }
.codicon-keyboard-tab:before { content: "\\ec3c" }
.codicon-copilot-blocked:before { content: "\\ec3d" }
.codicon-copilot-not-connected:before { content: "\\ec3e" }
.codicon-flag:before { content: "\\ec3f" }
.codicon-lightbulb-empty:before { content: "\\ec40" }
.codicon-symbol-method-arrow:before { content: "\\ec41" }
.codicon-copilot-unavailable:before { content: "\\ec42" }
.codicon-repo-pinned:before { content: "\\ec43" }
.codicon-keyboard-tab-above:before { content: "\\ec44" }
.codicon-keyboard-tab-below:before { content: "\\ec45" }
.codicon-git-pull-request-done:before { content: "\\ec46" }
.codicon-mcp:before { content: "\\ec47" }
.codicon-extensions-large:before { content: "\\ec48" }
.codicon-layout-panel-dock:before { content: "\\ec49" }
.codicon-layout-sidebar-left-dock:before { content: "\\ec4a" }
.codicon-layout-sidebar-right-dock:before { content: "\\ec4b" }
.codicon-copilot-in-progress:before { content: "\\ec4c" }
.codicon-copilot-error:before { content: "\\ec4d" }
.codicon-copilot-success:before { content: "\\ec4e" }
.codicon-chat-sparkle:before { content: "\\ec4f" }
.codicon-search-sparkle:before { content: "\\ec50" }
.codicon-edit-sparkle:before { content: "\\ec51" }
.codicon-copilot-snooze:before { content: "\\ec52" }
.codicon-send-to-remote-agent:before { content: "\\ec53" }
.codicon-comment-discussion-sparkle:before { content: "\\ec54" }
.codicon-chat-sparkle-warning:before { content: "\\ec55" }
.codicon-chat-sparkle-error:before { content: "\\ec56" }
.codicon-collection:before { content: "\\ec57" }
.codicon-new-collection:before { content: "\\ec58" }
.codicon-thinking:before { content: "\\ec59" }
.codicon-build:before { content: "\\ec5a" }
.codicon-comment-discussion-quote:before { content: "\\ec5b" }
.codicon-cursor:before { content: "\\ec5c" }
.codicon-eraser:before { content: "\\ec5d" }
.codicon-file-text:before { content: "\\ec5e" }
.codicon-quotes:before { content: "\\ec60" }
.codicon-rename:before { content: "\\ec61" }
.codicon-run-with-deps:before { content: "\\ec62" }
.codicon-debug-connected:before { content: "\\ec63" }
.codicon-strikethrough:before { content: "\\ec64" }
.codicon-open-in-product:before { content: "\\ec65" }
.codicon-index-zero:before { content: "\\ec66" }
.codicon-agent:before { content: "\\ec67" }
.codicon-edit-code:before { content: "\\ec68" }
.codicon-repo-selected:before { content: "\\ec69" }
.codicon-skip:before { content: "\\ec6a" }
.codicon-merge-into:before { content: "\\ec6b" }
.codicon-git-branch-changes:before { content: "\\ec6c" }
.codicon-git-branch-staged-changes:before { content: "\\ec6d" }
.codicon-git-branch-conflicts:before { content: "\\ec6e" }
.codicon-git-branch:before { content: "\\ec6f" }
.codicon-git-branch-create:before { content: "\\ec6f" }
.codicon-git-branch-delete:before { content: "\\ec6f" }
.codicon-search-large:before { content: "\\ec70" }
.codicon-terminal-git-bash:before { content: "\\ec71" }
.codicon-window-active:before { content: "\\ec72" }
.codicon-forward:before { content: "\\ec73" }
.codicon-download:before { content: "\\ec74" }
.codicon-clockface:before { content: "\\ec75" }
.codicon-unarchive:before { content: "\\ec76" }
.codicon-session-in-progress:before { content: "\\ec77" }
.codicon-collection-small:before { content: "\\ec78" }
.codicon-vm-small:before { content: "\\ec79" }
.codicon-cloud-small:before { content: "\\ec7a" }
.codicon-add-small:before { content: "\\ec7b" }
.codicon-remove-small:before { content: "\\ec7c" }
.codicon-worktree-small:before { content: "\\ec7d" }
.codicon-worktree:before { content: "\\ec7e" }
.codicon-screen-cut:before { content: "\\ec7f" }
.codicon-ask:before { content: "\\ec80" }
.codicon-openai:before { content: "\\ec81" }
.codicon-claude:before { content: "\\ec82" }
.codicon-open-in-window:before { content: "\\ec83" }
.codicon-new-session:before { content: "\\ec84" }
.codicon-terminal-secure:before { content: "\\ec85" }
.codicon-chat-import:before { content: "\\ec86" }
.codicon-chat-export:before { content: "\\ec87" }
.codicon-share-window:before { content: "\\ec88" }
.codicon-circle-slash-compact:before { content: "\\ec89" }
.codicon-copilot-compact:before { content: "\\ec8a" }
.codicon-folder-opened-compact:before { content: "\\ec8b" }
.codicon-folder-compact:before { content: "\\ec8c" }
.codicon-gear-compact:before { content: "\\ec8d" }
.codicon-git-branch-compact:before { content: "\\ec8e" }
.codicon-library-compact:before { content: "\\ec8f" }
.codicon-record-keys-compact:before { content: "\\ec90" }
.codicon-remote-compact:before { content: "\\ec91" }
.codicon-repo-forked-compact:before { content: "\\ec92" }
.codicon-repo-compact:before { content: "\\ec93" }
.codicon-shield-compact:before { content: "\\ec94" }
.codicon-sparkle-compact:before { content: "\\ec95" }
.codicon-symbol-color-compact:before { content: "\\ec96" }
.codicon-window-compact:before { content: "\\ec97" }
.codicon-error-compact:before { content: "\\ec98" }
.codicon-warning-compact:before { content: "\\ec99" }
.codicon-pass-compact:before { content: "\\ec9a" }
.codicon-important:before { content: "\\ec9b" }
.codicon-important-compact:before { content: "\\ec9c" }
.codicon-rocket-compact:before { content: "\\ec9d" }
.codicon-unpin:before { content: "\\ec9e" }
.codicon-add-compact:before { content: "\\ec9f" }
.codicon-attach-compact:before { content: "\\eca0" }
.codicon-beaker-compact:before { content: "\\eca1" }
.codicon-check-compact:before { content: "\\eca2" }
.codicon-checklist-compact:before { content: "\\eca3" }
.codicon-chevron-down-compact:before { content: "\\eca4" }
.codicon-chevron-left-compact:before { content: "\\eca5" }
.codicon-chevron-right-compact:before { content: "\\eca6" }
.codicon-chevron-up-compact:before { content: "\\eca7" }
.codicon-circle-filled-compact:before { content: "\\eca8" }
.codicon-circle-small-filled-compact:before { content: "\\eca9" }
.codicon-close-compact:before { content: "\\ecaa" }
.codicon-collapse-all-compact:before { content: "\\ecab" }
.codicon-comment-compact:before { content: "\\ecac" }
.codicon-comment-unresolved-compact:before { content: "\\ecad" }
.codicon-debug-connected-compact:before { content: "\\ecae" }
.codicon-debug-disconnect-compact:before { content: "\\ecaf" }
.codicon-edit-compact:before { content: "\\ecb0" }
.codicon-file-media-compact:before { content: "\\ecb1" }
.codicon-git-fetch:before { content: "\\ecb2" }
.codicon-lightbulb-compact:before { content: "\\ecb3" }
.codicon-loading-compact:before { content: "\\ecb4" }
.codicon-pass-filled-compact:before { content: "\\ecb5" }
.codicon-project-compact:before { content: "\\ecb6" }
.codicon-refresh-compact:before { content: "\\ecb7" }
.codicon-search-compact:before { content: "\\ecb8" }
.codicon-session-in-progress-compact:before { content: "\\ecb9" }
.codicon-sync-compact:before { content: "\\ecba" }
.codicon-terminal-compact:before { content: "\\ecbb" }
.codicon-vm-pending:before { content: "\\ecbc" }
.codicon-worktree-compact:before { content: "\\ecbd" }
.codicon-developer-tools:before { content: "\\ecbe" }
.codicon-cloud-compact:before { content: "\\ecbf" }
.codicon-agent-compact:before { content: "\\ecc0" }
.codicon-ask-compact:before { content: "\\ecc1" }
.codicon-settings-compact:before { content: "\\ecc2" }
.codicon-vm-compact:before { content: "\\ecc3" }
.codicon-run-compact:before { content: "\\ecc4" }
.codicon-git-pull-request-comment:before { content: "\\ecc5" }
.codicon-git-pull-request-error:before { content: "\\ecc6" }
.codicon-right-panel-hide:before { content: "\\ecc7" }
.codicon-right-panel-show:before { content: "\\ecc8" }
.codicon-vscode-insiders-outline:before { content: "\\ecc9" }
.codicon-vscode-outline:before { content: "\\ecca" }
.codicon-voice-mode:before { content: "\\eccb" }
.codicon-voice-mode-compact:before { content: "\\eccc" }
.codicon-mic-download:before { content: "\\eccd" }
.codicon-mic-download-compact:before { content: "\\ecce" }
.codicon-voice-mode-download:before { content: "\\eccf" }
.codicon-voice-mode-download-compact:before { content: "\\ecd0" }
.codicon-google-gemini:before { content: "\\ecd1" }
.codicon-kimi:before { content: "\\ecd2" }
.codicon-microsoft:before { content: "\\ecd3" }
.codicon-fish1-happy:before { content: "\\ecd4" }
.codicon-fish1-neutral:before { content: "\\ecd5" }
.codicon-fish1-sad:before { content: "\\ecd6" }
.codicon-fish1-very-sad:before { content: "\\ecd7" }
.codicon-fish2-happy:before { content: "\\ecd8" }
.codicon-fish2-neutral:before { content: "\\ecd9" }
.codicon-fish2-sad:before { content: "\\ecda" }
.codicon-fish2-very-sad:before { content: "\\ecdb" }
.codicon-fish3-happy:before { content: "\\ecdc" }
.codicon-fish3-neutral:before { content: "\\ecdd" }
.codicon-fish3-sad:before { content: "\\ecde" }
.codicon-fish3-very-sad:before { content: "\\ecdf" }
.codicon-fish4-happy:before { content: "\\ece0" }
.codicon-fish4-neutral:before { content: "\\ece1" }
.codicon-fish4-sad:before { content: "\\ece2" }
.codicon-fish4-very-sad:before { content: "\\ece3" }
.codicon-person-voice:before { content: "\\ece4" }
.codicon-person-voice-compact:before { content: "\\ece5" }
.codicon-person-voice-filled:before { content: "\\ece6" }
.codicon-person-voice-filled-compact:before { content: "\\ece7" }
`;var Jp=`/* The Inkspect design system: tokens and the shared components (buttons, fields, selects,
   switches, sliders, color picker, menus, toast, drawing toolbar and layer).
   Colors come from VS Code theme variables; hosts outside VS Code define them (theme.css).
   Every surface uses the tokens below, so sizes, radii and elevation stay consistent. */

:root,
:host {
  /* Shape */
  --ink-radius-sm: 4px;
  --ink-radius: 6px;
  --ink-radius-lg: 10px;
  --ink-radius-pill: 999px;
  /* Controls */
  --ink-control-sm: 24px;
  --ink-control: 28px;
  --ink-control-lg: 36px;
  /* Spacing */
  --ink-space-1: 4px;
  --ink-space-2: 8px;
  --ink-space-3: 12px;
  --ink-space-4: 16px;
  --ink-space-5: 24px;
  --ink-space-6: 32px;
  /* Type */
  --ink-font-xs: 11px;
  --ink-font-sm: 12px;
  --ink-font: var(--vscode-font-size, 13px);
  --ink-font-lg: 15px;
  --ink-font-xl: 22px;
  /* Surfaces and lines */
  --ink-surface: var(--vscode-editorWidget-background, var(--vscode-editor-background));
  /* Popups: lifted off the menu background, since many dark themes (Tokyo Night) give menus the
     sidebar's own color, a border the same near-black, and no shadow at all. */
  --ink-surface-raised: color-mix(
    in srgb,
    var(--vscode-foreground, #888) 7%,
    var(--vscode-menu-background, var(--ink-surface))
  );
  --ink-surface-sunken: color-mix(in srgb, var(--vscode-foreground, #888) 4%, transparent);
  --ink-border: var(--vscode-widget-border, rgba(128, 128, 128, 0.35));
  --ink-border-subtle: color-mix(in srgb, var(--vscode-foreground, #888) 10%, transparent);
  --ink-border-strong: color-mix(in srgb, var(--vscode-foreground, #888) 22%, transparent);
  --ink-hover: var(--vscode-toolbar-hoverBackground, rgba(128, 128, 128, 0.18));
  --ink-pressed: var(--vscode-toolbar-activeBackground, rgba(128, 128, 128, 0.26));
  /* Focus rings follow the theme's focus border; accents use the button color, which themes keep
     vivid (the focus border can be very dim). Text on tinted backgrounds uses the link color. */
  --ink-focus: var(--vscode-focusBorder, #0078d4);
  --ink-accent: var(--vscode-button-background, var(--ink-focus));
  --ink-accent-fg: var(--vscode-textLink-foreground, var(--ink-accent));
  --ink-accent-soft: color-mix(in srgb, var(--ink-accent) 20%, transparent);
  /* Secondary text, pulled toward the foreground so it stays readable in low-contrast themes. */
  --ink-muted: color-mix(
    in srgb,
    var(--vscode-descriptionForeground, #9d9d9d) 70%,
    var(--vscode-foreground, #ccc)
  );
  --ink-danger: var(--vscode-errorForeground, #f85149);
  --ink-success: var(--vscode-testing-iconPassed, #73c991);
  --ink-warning: var(--vscode-editorWarning-foreground, #cca700);
  /* The theme's own palette. Every theme defines its terminal ANSI colors, and they are its true
     hues (Tokyo Night's are #7aa2f7, #9ece6a, #e0af68, #f7768e, #bb9af7), unlike button and
     error colors, which some themes keep dim. Pulled slightly toward the foreground so they stay
     readable as text on both light and dark backgrounds. */
  --ink-blue: color-mix(
    in srgb,
    var(--vscode-terminal-ansiBlue, #3b8eea) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-green: color-mix(
    in srgb,
    var(--vscode-terminal-ansiGreen, #23d18b) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-yellow: color-mix(
    in srgb,
    var(--vscode-terminal-ansiYellow, #e5e510) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-red: color-mix(
    in srgb,
    var(--vscode-terminal-ansiRed, #f14c4c) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-magenta: color-mix(
    in srgb,
    var(--vscode-terminal-ansiMagenta, #d670d6) 88%,
    var(--vscode-foreground, #888)
  );
  /* Elevation */
  /* Half the theme's widget shadow, half plain black: some themes make theirs transparent. */
  --ink-shadow-color: color-mix(
    in srgb,
    var(--vscode-widget-shadow, rgba(0, 0, 0, 0.3)) 50%,
    rgba(0, 0, 0, 0.5)
  );
  --ink-shadow-sm: 0 1px 3px var(--ink-shadow-color);
  --ink-shadow: 0 6px 20px var(--ink-shadow-color), 0 1px 4px var(--ink-shadow-color);
  --ink-shadow-lg: 0 12px 32px var(--ink-shadow-color), 0 2px 8px var(--ink-shadow-color);
  /* Motion */
  --ink-ease: cubic-bezier(0.2, 0, 0, 1);
  --ink-fast: 90ms;
  --ink-normal: 160ms;
}

/* Focus ------------------------------------------------------------------------------------ */

.icon-button:focus-visible,
.button:focus-visible,
.link-button:focus-visible,
.menu-item:focus-visible,
.select:focus-visible,
.switch:focus-visible,
.checkbox:focus-visible,
.segment:focus-visible,
.slider-track:focus-visible,
.swatch:focus-visible,
.color-area:focus-visible,
.color-hue:focus-visible,
.chip:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: 1px;
}

/* Icon buttons ----------------------------------------------------------------------------- */

.icon-button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: var(--ink-control);
  height: var(--ink-control);
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--vscode-icon-foreground, var(--vscode-foreground));
  font: inherit;
  cursor: pointer;
  transition: background-color var(--ink-fast) var(--ink-ease);
}

/* DragHandle: the six-dot grip of a floating panel. */
.drag-handle {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: var(--ink-control);
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  cursor: grab;
  touch-action: none;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    color var(--ink-fast) var(--ink-ease);
}

.drag-handle:hover,
.drag-handle.dragging {
  background: var(--ink-hover);
  color: var(--vscode-foreground);
}

.drag-handle.dragging {
  cursor: grabbing;
}

.drag-handle:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.icon-button.small {
  width: var(--ink-control-sm);
  height: var(--ink-control-sm);
}

.icon-button:hover:not(:disabled) {
  background: var(--ink-hover);
}

.icon-button:active:not(:disabled) {
  background: var(--ink-pressed);
}

.icon-button.active {
  background: var(--ink-accent-soft);
  color: var(--vscode-inputOption-activeForeground, var(--vscode-foreground));
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--ink-accent) 60%, transparent);
}

.icon-button:disabled {
  opacity: 0.4;
  cursor: default;
}

/* Buttons ---------------------------------------------------------------------------------- */

.button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: var(--ink-control);
  padding: 0 12px;
  border: 1px solid var(--vscode-button-border, transparent);
  border-radius: var(--ink-radius-sm);
  font: inherit;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.button.small {
  gap: 4px;
  height: var(--ink-control-sm);
  padding: 0 8px;
}

.button .codicon {
  font-size: 14px;
}

.button.primary {
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.primary:hover:not(:disabled) {
  background: var(--vscode-button-hoverBackground);
}

.button.secondary {
  background: var(--vscode-button-secondaryBackground);
  color: var(--vscode-button-secondaryForeground);
}

.button.secondary:hover:not(:disabled) {
  background: var(--vscode-button-secondaryHoverBackground);
}

.button.ghost {
  border-color: transparent;
  background: transparent;
  color: inherit;
}

.button.ghost:hover:not(:disabled) {
  background: var(--ink-hover);
}

/* A solid call to action in the theme's own blue (its palette, see --ink-blue), for themes whose
   button color is dim. Dark text on dark themes, where the palette's blue is light. */
.button.accent {
  border-color: transparent;
  background: var(--ink-blue);
  color: var(--vscode-editor-background, #fff);
  font-weight: 600;
}

.button.accent:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-blue) 85%, var(--vscode-foreground, #fff));
}

body.vscode-light .button.accent {
  color: #fff;
}

body.vscode-high-contrast .button.accent {
  border-color: var(--vscode-contrastBorder, transparent);
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.danger {
  border-color: color-mix(in srgb, var(--ink-danger) 45%, transparent);
  background: transparent;
  color: var(--ink-danger);
}

.button.danger:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-danger) 12%, transparent);
}

.button:disabled {
  opacity: 0.5;
  cursor: default;
}

.link-button {
  padding: 0;
  border: none;
  background: none;
  color: var(--vscode-textLink-foreground);
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.link-button:hover:not(:disabled) {
  color: var(--vscode-textLink-activeForeground, var(--vscode-textLink-foreground));
  text-decoration: underline;
}

.link-button:disabled {
  color: inherit;
  cursor: default;
}

.link-button.danger {
  color: var(--ink-danger);
}

/* Text fields ------------------------------------------------------------------------------ */

.text-field {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: var(--ink-control);
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  transition: border-color var(--ink-fast) var(--ink-ease);
}

.text-field.size-sm {
  height: var(--ink-control-sm);
  padding: 0 6px;
}

.text-field.size-lg {
  height: var(--ink-control-lg);
  padding: 0 12px;
  border-radius: var(--ink-radius);
}

.text-field:hover:not(.disabled) {
  border-color: var(--ink-border-strong);
}

.text-field:focus-within {
  border-color: var(--ink-focus);
  box-shadow: 0 0 0 1px var(--ink-focus);
}

.text-field.invalid {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.text-field.disabled {
  opacity: 0.5;
}

.text-field input {
  flex: 1;
  width: 100%;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: none;
  outline: none;
  background: transparent;
  color: inherit;
  font: inherit;
}

.text-field input::placeholder {
  color: var(--vscode-input-placeholderForeground, var(--ink-muted));
}

/* Numbers: no spinner arrows (the fields accept typing and arrow keys). */
.text-field input::-webkit-outer-spin-button,
.text-field input::-webkit-inner-spin-button {
  margin: 0;
  appearance: none;
}

.text-field input[type='number'] {
  appearance: textfield;
  font-variant-numeric: tabular-nums;
}

.text-field input[type='search']::-webkit-search-cancel-button {
  appearance: none;
}

.text-field-icon {
  flex-shrink: 0;
  color: var(--ink-muted);
}

.text-field-clear {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.text-field-clear:hover {
  background: var(--ink-hover);
  color: inherit;
}

/* Form rows -------------------------------------------------------------------------------- */

.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: var(--ink-space-3);
}

.field.inline {
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ink-space-3);
}

.field-label {
  color: var(--vscode-foreground);
  font-weight: 600;
}

.field.inline .field-label {
  font-weight: normal;
}

.field-control {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  min-width: 0;
}

.field-control > .text-field,
.field-control > .select {
  flex: 1;
}

.field-hint {
  flex-basis: 100%;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.field-hint.error {
  color: var(--ink-danger);
}

/* Select ----------------------------------------------------------------------------------- */

.select {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  height: var(--ink-control);
  padding: 0 6px 0 8px;
  border: 1px solid var(--vscode-dropdown-border, var(--vscode-input-border, var(--ink-border)));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-dropdown-background, var(--vscode-input-background));
  color: var(--vscode-dropdown-foreground, var(--vscode-input-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.select.size-sm {
  height: var(--ink-control-sm);
  padding: 0 4px 0 6px;
}

.select:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
}

.select.open {
  border-color: var(--ink-focus);
}

.select.quiet {
  border-color: transparent;
  background: transparent;
}

.select.quiet:hover:not(:disabled),
.select.quiet.open {
  border-color: transparent;
  background: var(--ink-hover);
}

.select:disabled {
  opacity: 0.45;
  cursor: default;
}

.select-value {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.select-value.placeholder {
  color: var(--ink-muted);
}

.select-chevron {
  flex-shrink: 0;
  font-size: 14px !important;
  opacity: 0.8;
  transition: transform var(--ink-normal) var(--ink-ease);
}

.select.open .select-chevron {
  transform: rotate(180deg);
}

.select-list,
.color-picker,
.menu,
.popover {
  background: var(--ink-surface-raised);
  color: var(--vscode-menu-foreground, var(--vscode-foreground));
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow);
}

.select-list {
  position: fixed;
  z-index: 1000;
  max-height: min(340px, 60vh);
  padding: 4px;
  overflow-y: auto;
  outline: none;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.select-group {
  padding: 8px 8px 4px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.select-group:first-child {
  padding-top: 4px;
}

.select-option {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px 0 4px;
  border-radius: var(--ink-radius-sm);
  white-space: nowrap;
  cursor: pointer;
}

.select-option.active {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
}

.select-option.disabled {
  opacity: 0.45;
  cursor: default;
}

.select-check {
  flex-shrink: 0;
  font-size: 14px !important;
}

.select-option-label {
  flex: 1;
}

.select-option-detail {
  margin-left: 16px;
  opacity: 0.65;
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Switch and checkbox ---------------------------------------------------------------------- */

.switch,
.checkbox {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: var(--ink-space-2);
  padding: 2px 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.switch:disabled,
.checkbox:disabled {
  opacity: 0.45;
  cursor: default;
}

.switch-track {
  position: relative;
  flex-shrink: 0;
  width: 30px;
  height: 16px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-input-background, var(--ink-surface-sunken));
  transition:
    background-color var(--ink-normal) var(--ink-ease),
    border-color var(--ink-normal) var(--ink-ease);
}

.switch-thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--ink-muted);
  transition:
    transform var(--ink-normal) var(--ink-ease),
    background-color var(--ink-normal) var(--ink-ease);
}

.switch.on .switch-track {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
}

.switch.on .switch-thumb {
  background: var(--vscode-button-foreground, #fff);
  transform: translateX(14px);
}

.checkbox-box {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border: 1px solid var(--vscode-checkbox-border, var(--ink-border-strong));
  border-radius: 3px;
  background: var(--vscode-checkbox-background, var(--vscode-input-background));
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.checkbox.on .checkbox-box {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
  color: var(--vscode-button-foreground, #fff);
}

.checkbox-box .codicon {
  font-size: 14px !important;
}

/* Segmented control ------------------------------------------------------------------------ */

.segmented {
  display: inline-flex;
  flex-shrink: 0;
  gap: 2px;
  height: var(--ink-control);
  padding: 2px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
}

.segmented.size-sm {
  height: var(--ink-control-sm);
  padding: 1px;
  border-radius: var(--ink-radius-sm);
}

.segment {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  gap: 5px;
  min-width: 26px;
  padding: 0 10px;
  border: none;
  border-radius: calc(var(--ink-radius) - 2px);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    color var(--ink-fast) var(--ink-ease);
}

.segmented.size-sm .segment {
  padding: 0 8px;
  border-radius: 3px;
}

.segment:hover {
  color: var(--vscode-foreground);
}

.segment.checked {
  background: var(--vscode-button-secondaryBackground, var(--ink-hover));
  color: var(--vscode-button-secondaryForeground, var(--vscode-foreground));
  box-shadow: var(--ink-shadow-sm);
}

.segment-count {
  min-width: 16px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
  text-align: center;
}

.segment-count.error {
  background: var(--ink-danger);
  color: #fff;
}

/* Slider ----------------------------------------------------------------------------------- */

.slider {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  height: var(--ink-control);
}

.slider.disabled {
  opacity: 0.45;
}

.slider > .codicon {
  color: var(--ink-muted);
}

.slider-track {
  position: relative;
  width: 84px;
  height: 18px;
  cursor: pointer;
  touch-action: none;
  border-radius: var(--ink-radius-sm);
}

.slider-track::before,
.slider-fill {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  height: 4px;
  border-radius: var(--ink-radius-pill);
  transform: translateY(-50%);
}

.slider-track::before {
  right: 0;
  background: var(--ink-border-strong);
}

.slider-fill {
  background: var(--ink-accent);
}

.slider-thumb {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid var(--ink-accent);
  border-radius: 50%;
  background: var(--vscode-editor-background, #fff);
  box-shadow: var(--ink-shadow-sm);
  transform: translate(-50%, -50%);
  transition: transform var(--ink-fast) var(--ink-ease);
}

.slider-track:hover .slider-thumb,
.slider-track:active .slider-thumb {
  transform: translate(-50%, -50%) scale(1.15);
}

.slider-value {
  min-width: 34px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Swatches and color picker ---------------------------------------------------------------- */

.swatch {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  padding: 0;
  border: 1px solid color-mix(in srgb, var(--vscode-foreground, #888) 30%, transparent);
  border-radius: 50%;
  cursor: pointer;
  transition: transform var(--ink-fast) var(--ink-ease);
}

.swatch:hover {
  transform: scale(1.12);
}

.swatch.small {
  width: 16px;
  height: 16px;
}

.swatch.active {
  box-shadow:
    0 0 0 2px var(--ink-surface),
    0 0 0 3.5px var(--ink-accent);
}

.color-picker-trigger {
  background: conic-gradient(
    from 90deg,
    #f43f5e,
    #f59e0b,
    #84cc16,
    #06b6d4,
    #6366f1,
    #d946ef,
    #f43f5e
  );
}

.color-picker {
  position: fixed;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 224px;
  padding: 10px;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.color-area {
  position: relative;
  height: 140px;
  border-radius: var(--ink-radius-sm);
  background-image:
    linear-gradient(to top, #000, transparent), linear-gradient(to right, #fff, transparent) !important;
  cursor: crosshair;
  touch-action: none;
}

.color-hue {
  position: relative;
  height: 12px;
  border-radius: var(--ink-radius-pill);
  background: linear-gradient(
    to right,
    #f00 0%,
    #ff0 17%,
    #0f0 33%,
    #0ff 50%,
    #00f 67%,
    #f0f 83%,
    #f00 100%
  );
  cursor: pointer;
  touch-action: none;
}

.color-handle {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.35),
    0 1px 4px rgba(0, 0, 0, 0.4);
  transform: translate(-50%, -50%);
  pointer-events: none;
}

.color-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.color-preview {
  flex-shrink: 0;
  width: 26px;
  height: 26px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
}

.color-hex {
  flex: 1;
  min-width: 0;
  height: 26px;
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  outline: none;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-sm);
  text-transform: lowercase;
}

.color-hex:focus {
  border-color: var(--ink-focus);
}

.color-presets {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  padding-top: 8px;
  border-top: 1px solid var(--ink-border-subtle);
}

/* Chips and badges ------------------------------------------------------------------------- */

.badge {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 7px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  white-space: nowrap;
}

.badge.outline {
  border: 1px solid var(--ink-border-strong);
  background: transparent;
  color: var(--ink-muted);
}

.badge.success {
  background: color-mix(in srgb, var(--ink-success) 18%, transparent);
  color: var(--ink-success);
}

.badge.danger {
  background: color-mix(in srgb, var(--ink-danger) 18%, transparent);
  color: var(--ink-danger);
}

/* Key caps (shortcuts) --------------------------------------------------------------------- */

.keycaps {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 3px;
}

.keycap {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border: 1px solid var(--vscode-keybindingLabel-border, var(--ink-border-strong));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-keybindingLabel-background, var(--ink-surface-sunken));
  box-shadow: inset 0 -1px 0 var(--vscode-keybindingLabel-bottomBorder, var(--ink-border-strong));
  color: var(--vscode-keybindingLabel-foreground, var(--vscode-foreground));
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  line-height: 1;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.keycaps.size-sm .keycap {
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  font-size: 10.5px;
}

/* Cards ------------------------------------------------------------------------------------ */

.card {
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--ink-surface-sunken);
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--ink-space-3);
  padding: var(--ink-space-3) var(--ink-space-4);
  border-bottom: 1px solid var(--ink-border-subtle);
}

.card-title {
  margin: 0;
  font-size: var(--ink-font);
  font-weight: 600;
}

.card-body {
  padding: var(--ink-space-4);
}

.card-row {
  display: flex;
  align-items: center;
  gap: var(--ink-space-4);
  padding: var(--ink-space-3) var(--ink-space-4);
}

.card-row + .card-row {
  border-top: 1px solid var(--ink-border-subtle);
}

.card-row-text {
  flex: 1;
  min-width: 0;
}

.card-row-title {
  font-weight: 500;
}

.card-row-description {
  margin-top: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

/* Menus and popovers ----------------------------------------------------------------------- */

.menu,
.popover {
  position: fixed;
  /* Above the send dialog (900), like select lists and the color picker. */
  z-index: 1000;
  min-width: 200px;
  max-width: 420px;
  padding: 4px;
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

/* Long menus (a big bookmarks folder) stay short and scroll, like Chrome's. Items have a little
   room between them. */
.menu {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 5px;
  max-height: min(420px, calc(100vh - 8px));
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Submenus open without the pop animation, so they don't jump while the pointer moves. */
.menu .menu {
  animation: none;
}

.menu-item.expanded:not(:focus) {
  background: var(--ink-hover);
}

.menu-image {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  object-fit: contain;
}

.menu-arrow {
  margin-left: 12px;
  margin-right: -2px;
  opacity: 0.8;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  width: 100%;
  height: 28px;
  padding: 0 10px 0 8px;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.menu-item:hover:not(:disabled),
.menu-item:focus {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
  outline: none;
}

.menu-item:disabled {
  opacity: 0.45;
  cursor: default;
}

.menu-label {
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.menu-shortcut {
  margin-left: 16px;
  opacity: 0.7;
  font-size: 0.9em;
}

.menu-separator {
  flex-shrink: 0;
  height: 1px;
  margin: 3px 6px;
  background: var(--vscode-menu-separatorBackground, var(--ink-border));
}

/* Toast ------------------------------------------------------------------------------------ */

.toast {
  position: fixed;
  bottom: 16px;
  left: 50%;
  z-index: 200;
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: calc(100% - 32px);
  padding: 8px 14px;
  transform: translateX(-50%);
  background: var(--vscode-notifications-background, var(--ink-surface));
  color: var(--vscode-notifications-foreground, var(--vscode-foreground));
  border: 1px solid var(--vscode-notifications-border, var(--ink-border));
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow-lg);
  animation: toast-in var(--ink-normal) var(--ink-ease);
}

/* A failure: marked as one, longer on screen, and dismissible. */
.toast.error {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.toast.error > .codicon-error {
  flex-shrink: 0;
  color: var(--ink-danger);
}

.toast .toast-dismiss {
  flex-shrink: 0;
  margin: -4px -8px -4px 0;
}

.header-actions,
.button-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
}

/* Drawing ---------------------------------------------------------------------------------- */

.draw-toolbar {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  padding: 4px 8px;
  background: var(--ink-surface);
  border-top: 1px solid var(--ink-border);
  border-bottom: 1px solid var(--ink-border);
}

.draw-group {
  display: flex;
  align-items: center;
  gap: 2px;
  padding-right: 6px;
  border-right: 1px solid var(--ink-border-subtle);
}

.draw-group.colors {
  gap: 6px;
  padding: 0 8px 0 4px;
}

.draw-capture {
  margin-left: 2px;
}

.draw-close {
  margin-left: auto;
}

.drawing-layer {
  position: absolute;
  z-index: 3;
}

.drawing-layer canvas {
  position: relative;
  display: block;
  touch-action: none;
}

/* A live redaction (liveRedactions): blurs the page behind it, under the drawing canvas. Drawn
   over page content, so its colors are fixed. */
.drawing-redaction {
  position: absolute;
  pointer-events: none;
  background: rgba(128, 128, 128, 0.2);
  backdrop-filter: blur(12px) saturate(0.5);
}

.drawing-text-input {
  position: absolute;
  min-width: 160px;
  min-height: 1.6em;
  padding: 2px 4px;
  border: 1px dashed var(--ink-accent);
  background: rgba(255, 255, 255, 0.85);
  font-family: system-ui, sans-serif;
  font-weight: 600;
  resize: both;
  outline: none;
}

/* Motion ----------------------------------------------------------------------------------- */

@keyframes ink-fade-in {
  from {
    opacity: 0;
  }
}

@keyframes ink-pop-in {
  from {
    opacity: 0;
    transform: translateY(-3px) scale(0.985);
  }
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translate(-50%, 8px);
  }
}

@media (prefers-reduced-motion: reduce) {
  .select-list,
  .color-picker,
  .menu,
  .popover,
  .toast {
    animation: none;
  }
}

/* Shortcut list (ShortcutList) ------------------------------------------------------------- */

.shortcuts-warning {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 12px 8px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

/* Groups: a pinned header per mode. */
.group-header {
  position: sticky;
  top: var(--shortcut-sticky-top, 0);
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  height: 28px;
  padding: 0 12px 0 6px;
  border: none;
  border-top: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  color: var(--vscode-sideBarSectionHeader-foreground, var(--vscode-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.group-header:hover {
  background: var(--vscode-list-hoverBackground);
}

.group-header:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.group-icon {
  color: var(--ink-accent-fg);
}

.group-title {
  font-size: var(--ink-font-xs);
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.group-count {
  margin-left: auto;
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
}

/* Rows: label, then actions (on hover), then the keys in a right-aligned column. */
.shortcut-item {
  position: relative;
  padding: 0 12px 0 32px;
  border-radius: var(--ink-radius);
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.shortcut-item::before {
  content: '';
  position: absolute;
  top: 6px;
  bottom: 6px;
  left: 20px;
  width: 2px;
  border-radius: 1px;
  background: transparent;
}

.shortcut-item.changed::before {
  background: var(--ink-accent);
}

.shortcut-item.conflict::before {
  background: var(--ink-warning);
}

/* Outside VS Code (the browser extension) there is no list hover color: the kit's hover. */
.shortcut-item:hover,
.shortcut-item:focus-within {
  background: var(--vscode-list-hoverBackground, var(--ink-hover));
}

body.vscode-high-contrast .shortcut-item:hover,
body.vscode-high-contrast .shortcut-item:focus-within {
  outline: 1px dashed var(--vscode-contrastActiveBorder);
  outline-offset: -1px;
}

.shortcut-main {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 30px;
}

.shortcut-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Where a key works: VS (VS Code Browser) and BR (the browser toolbar), and the browser's own key. */
.shortcut-places {
  display: inline-flex;
  flex-shrink: 0;
  gap: 3px;
}

.shortcut-tag {
  --tag: var(--ink-muted);
  flex-shrink: 0;
  min-width: 22px;
  padding: 0 4px;
  border: 1px solid color-mix(in srgb, var(--tag) 40%, transparent);
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--tag) 10%, transparent);
  color: var(--tag);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 14px;
  text-align: center;
  letter-spacing: 0.02em;
}

.shortcut-tag.vs {
  --tag: var(--ink-blue);
}

.shortcut-tag.br {
  --tag: var(--ink-green);
}

body.vscode-high-contrast .shortcut-tag {
  border-color: var(--vscode-contrastBorder);
  background: transparent;
  color: var(--vscode-foreground);
}

.shortcut-item.changed .shortcut-label {
  font-weight: 500;
}

.shortcut-actions {
  display: inline-flex;
  flex-shrink: 0;
  justify-content: flex-end;
  gap: 1px;
  /* Room for both buttons (reset, add a key) in every row, so the columns line up. */
  min-width: calc(2 * var(--ink-control-sm) + 1px);
  opacity: 0;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.shortcut-item:hover .shortcut-actions,
.shortcut-item:focus-within .shortcut-actions {
  opacity: 1;
}

.shortcut-keys-column {
  display: inline-flex;
  flex-wrap: wrap;
  flex-shrink: 0;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  /* A steady width, so the VS/BR tags before it line up from row to row. */
  min-width: min(184px, 40%);
  max-width: 62%;
}

.key-button-wrap {
  position: relative;
  display: inline-flex;
}

.key-button {
  display: inline-flex;
  padding: 2px;
  border: 1px solid transparent;
  border-radius: var(--ink-radius);
  background: transparent;
  cursor: pointer;
}

.key-button:hover {
  border-color: var(--ink-border-strong);
  background: var(--ink-surface-sunken);
}

.key-button:focus-visible {
  outline: 1px solid var(--ink-focus);
}

/* The remove badge sits on the key's corner, so showing it doesn't move anything. */
.key-remove {
  position: absolute;
  top: -5px;
  right: -5px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 1px solid var(--ink-border-strong);
  border-radius: 50%;
  background: var(--ink-surface-raised);
  color: var(--ink-muted);
  opacity: 0;
  cursor: pointer;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.key-remove .codicon {
  font-size: 10px !important;
}

.key-button-wrap:hover .key-remove,
.key-remove:focus-visible {
  opacity: 1;
}

.key-remove:hover {
  border-color: var(--ink-danger);
  background: var(--ink-danger);
  color: #fff;
}

.key-empty {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 22px;
  padding: 0 8px;
  border: 1px dashed var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  font-size: var(--ink-font-xs);
  cursor: pointer;
}

.key-empty:hover {
  border-color: var(--ink-focus);
  color: var(--vscode-foreground);
}

.key-empty .codicon {
  font-size: 12px !important;
}

.key-recording {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  padding: 0 2px 0 8px;
  border: 1px solid var(--ink-focus);
  border-radius: var(--ink-radius-sm);
  background: var(--ink-accent-soft);
  box-shadow: 0 0 0 1px var(--ink-focus);
  font-size: var(--ink-font-xs);
}

.recording-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #ef4444;
  animation: ink-shortcut-pulse 1s ease-in-out infinite;
}

.key-recording-cancel {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.key-recording-cancel:hover {
  background: var(--ink-hover);
  color: inherit;
}

.shortcut-conflict {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 6px;
  padding: 0 0 6px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

@keyframes ink-shortcut-pulse {
  50% {
    opacity: 0.3;
  }
}

@media (prefers-reduced-motion: reduce) {
  .recording-dot {
    animation: none;
  }
}

body.vscode-high-contrast .key-button:hover {
  border-color: var(--vscode-contrastBorder);
}

/* Several keys for one action: "Ctrl T / Ctrl F4". */
.key-button-wrap + .key-button-wrap::before {
  content: '/';
  align-self: center;
  margin-right: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

/* Element picker hint (PickerHint) ------------------------------------------------------------
   Drawn over page content, so it has its own dark look (the theme's colors could vanish on the
   page), in both products. Each product places it. */
/* One row: what a click does, with each modifier, then the keys. */
.picker-hint {
  display: flex;
  align-items: center;
  gap: 14px;
  /* Its own width: centered with left: 50%, it would otherwise wrap at half the page. */
  width: max-content;
  padding: 6px 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.9);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  line-height: 1;
  pointer-events: none;
  backdrop-filter: blur(6px);
}

.picker-hint-item {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
}

.picker-hint-label {
  color: rgba(250, 250, 250, 0.82);
}

/* The main action, as a sentence; the others read "[Shift] + click  select several". */
.picker-hint-lead {
  color: #fff;
  font-weight: 600;
}

.picker-hint-click {
  color: #fff;
  font-weight: 500;
}

.picker-hint .keycap {
  border-color: rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  box-shadow: inset 0 -1px 0 rgba(255, 255, 255, 0.14);
  color: #fff;
}

/* Multi-selection bar (SelectionBar) ----------------------------------------------------------
   Over page content like the picker hint, so the same dark look; each product places it. */
.selection-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px;
  width: max-content;
  max-width: calc(100vw - 32px);
  padding: 5px 6px 5px 10px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.94);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  pointer-events: auto;
}

.selection-bar-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: 6px;
  font-weight: 600;
}

.selection-bar-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: #0a84ff;
  color: #fff;
  font-size: var(--ink-font-xs);
}

.selection-bar .button.ghost,
.selection-bar .icon-button {
  color: #fafafa;
}

.selection-bar .button.ghost:hover:not(:disabled),
.selection-bar .icon-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.12);
}

.selection-bar .button-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.selection-bar .keycap {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.16);
  box-shadow: none;
  color: #fff;
}

/* Thumbnails with a checkbox each (ThumbPicker): screenshots taken together ------------------- */
.thumb-picker {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(88px, 1fr));
  gap: var(--ink-space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.thumb-picker-item {
  position: relative;
  border-radius: var(--ink-radius);
}

.thumb-picker-image {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  aspect-ratio: 16 / 10;
  padding: 0;
  overflow: hidden;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  color: var(--ink-muted);
  cursor: pointer;
  transition:
    opacity var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.thumb-picker-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

.thumb-picker-image:hover {
  border-color: var(--ink-border-strong);
}

/* Left out: dimmed, so what is sent stands out. */
.thumb-picker-item:not(.on) .thumb-picker-image {
  opacity: 0.45;
}

.thumb-picker-item.on .thumb-picker-image {
  border-color: var(--ink-accent);
}

.thumb-picker-check {
  position: absolute;
  top: 4px;
  left: 4px;
  padding: 2px;
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--vscode-editor-background) 80%, transparent);
  box-shadow: var(--ink-shadow-sm);
}

body.vscode-high-contrast .thumb-picker-item.on .thumb-picker-image {
  outline: 1px solid var(--vscode-contrastActiveBorder);
}

/* The send dialog after a capture (SendModal) ------------------------------------------- */

.ink-modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 900;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--ink-space-4);
  background: color-mix(in srgb, #000 35%, transparent);
  animation: ink-fade-in var(--ink-normal) var(--ink-ease);
  pointer-events: auto;
}

.ink-modal {
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-3);
  width: min(480px, 100%);
  max-height: calc(100vh - 2 * var(--ink-space-4));
  overflow: auto;
  padding: var(--ink-space-4);
  background: var(--ink-surface);
  color: var(--vscode-editorWidget-foreground, var(--vscode-foreground));
  border: 1px solid var(--vscode-editorWidget-border, var(--ink-border));
  border-radius: var(--ink-radius-lg);
  box-shadow: var(--ink-shadow-lg);
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  text-align: left;
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.ink-modal:focus {
  outline: none;
}

.ink-modal-head {
  display: flex;
  align-items: flex-start;
  gap: var(--ink-space-3);
}

.ink-modal-detail {
  line-height: 1.35;
}

/* The captures: one row of equal tiles under the heading. */
.ink-modal-thumbs {
  display: grid;
  grid-auto-columns: minmax(0, 1fr);
  grid-auto-flow: column;
  gap: var(--ink-space-2);
}

.ink-modal-thumb {
  position: relative;
  display: block;
  height: 64px;
  overflow: hidden;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
}

.ink-modal-thumb img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

.ink-modal-more {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  background: color-mix(in srgb, #000 55%, transparent);
  color: #fff;
  font-size: var(--ink-font);
  font-weight: 600;
}

.ink-modal-heading {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: var(--ink-space-1);
  min-width: 0;
}

.ink-modal-project {
  flex-wrap: nowrap;
  white-space: nowrap;
}

.ink-modal-title {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  font-size: calc(var(--ink-font) + 1px);
  font-weight: 600;
}

.ink-modal-title .codicon {
  color: var(--ink-success);
}

.ink-modal-project,
.ink-modal-detail {
  display: flex;
  align-items: center;
  gap: var(--ink-space-1);
  font-size: var(--ink-font-sm);
}

.ink-modal-project-name {
  font-weight: 600;
}

.ink-modal-detail,
.ink-modal-project .ink-muted,
.ink-modal-empty,
.ink-modal-label,
.ink-modal-where,
.ink-modal-status {
  color: var(--ink-muted);
}

.ink-modal-label {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  margin-bottom: calc(-1 * var(--ink-space-1));
  font-size: var(--ink-font-xs);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

.ink-modal-count {
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--ink-surface-sunken);
  letter-spacing: 0;
}

.ink-modal-targets {
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-1);
  margin: 0;
  padding: 0;
  list-style: none;
}

.ink-modal-target {
  display: flex;
  align-items: center;
  gap: var(--ink-space-1);
}

.ink-modal-send {
  display: flex;
  flex: 1;
  align-items: center;
  gap: var(--ink-space-3);
  min-width: 0;
  min-height: 52px;
  padding: var(--ink-space-2) var(--ink-space-3) var(--ink-space-2) var(--ink-space-2);
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--ink-surface-sunken);
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.ink-modal-send:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
  background: var(--ink-hover);
}

.ink-modal-send:disabled {
  cursor: default;
  opacity: 0.6;
}

.ink-modal-send:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.ink-modal-target.default .ink-modal-send {
  border-color: var(--ink-accent);
  background: var(--ink-accent-soft);
}

.ink-modal-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: var(--ink-radius);
  background: color-mix(in srgb, var(--vscode-foreground) 8%, transparent);
}

.ink-modal-icon .codicon {
  font-size: 17px;
}

.ink-modal-target.default .ink-modal-icon {
  background: var(--ink-accent);
  color: var(--vscode-button-foreground, #fff);
}

.ink-modal-text {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
}

.ink-modal-agent {
  overflow: hidden;
  font-weight: 600;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ink-modal-where {
  overflow: hidden;
  font-size: var(--ink-font-sm);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ink-modal-keys {
  display: flex;
  flex: none;
  align-items: center;
  gap: var(--ink-space-1);
}

.ink-modal-number {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

.ink-modal-thread {
  align-self: flex-start;
}

.ink-modal-empty {
  padding: var(--ink-space-3);
  border: 1px dashed var(--ink-border-strong);
  border-radius: var(--ink-radius-lg);
  text-align: center;
}

.ink-modal-foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--ink-space-2);
  padding-top: var(--ink-space-3);
  border-top: 1px solid var(--ink-border-subtle);
}

.ink-modal-status {
  flex: 1;
  min-width: 160px;
  font-size: var(--ink-font-sm);
}

.ink-modal-status.tone-error {
  color: var(--ink-danger);
}

.ink-modal-status.tone-ok {
  color: var(--ink-success);
}

body.vscode-high-contrast .ink-modal-target.default .ink-modal-send {
  outline: 1px solid var(--vscode-contrastActiveBorder);
}

@media (forced-colors: active) {
  .ink-modal-target.default .ink-modal-send {
    outline: 2px solid Highlight;
  }
}

/* Saved list (SavedList) ----------------------------------------------------------------------
   A project's captures, in VS Code's Saved view and the browser's side panel. Cards are a lighter
   tint of the sidebar, with no outline: in themes like Tokyo Night the sidebar, editor and
   borders are all the same near-black. */
.saved {
  --card-bg: color-mix(
    in srgb,
    var(--vscode-foreground, #888) 5%,
    var(--vscode-sideBar-background, transparent)
  );
  display: flex;
  flex-direction: column;
  container: saved / inline-size;
}

/* The agent picker and filters, pinned at the top. */
.saved-header {
  position: sticky;
  top: 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-2);
  padding: var(--ink-space-2) var(--ink-space-3);
  border-bottom: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
}

/* Filters fill the width; below 480px only their icons and counts show (names are tooltips). */
.saved-filter {
  display: flex;
  width: 100%;
}

.saved-filter .segment {
  flex: 1 1 auto;
  min-width: 0;
  gap: 4px;
  padding: 0 4px;
}

@container saved (max-width: 260px) {
  .saved-filter .segment-count:not(.error) {
    display: none;
  }
}

@container saved (max-width: 480px) {
  .saved-filter .segment-label {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
}

/* Items. */
.saved-list {
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-2);
  margin: 0;
  padding: var(--ink-space-2) var(--ink-space-3) var(--ink-space-3);
  list-style: none;
}

.saved-card {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
  padding: 10px;
  border: 1px solid transparent;
  border-radius: var(--ink-radius-lg);
  background: var(--card-bg);
  outline: none;
  transition:
    border-color var(--ink-fast) var(--ink-ease),
    background var(--ink-fast) var(--ink-ease);
}

.saved-card:hover {
  background: color-mix(in srgb, var(--vscode-foreground, #888) 4%, var(--card-bg));
}

.saved-card:focus-visible {
  border-color: var(--ink-focus);
}

/* Screenshots, recordings and element captures: a preview across the card's width. The whole
   image shows (a short element strip isn't cropped to nothing); only tall captures, such as full
   pages, are cropped to their top. */
.saved-thumb {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  min-height: 44px;
  max-height: 150px;
  padding: 6px;
  overflow: hidden;
  border: none;
  border-radius: var(--ink-radius);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  cursor: zoom-in;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.saved-thumb:hover {
  opacity: 0.88;
}

.saved-thumb:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: 1px;
}

.saved-thumb img {
  display: block;
  max-width: 100%;
  max-height: 136px;
  border-radius: var(--ink-radius-sm);
  object-fit: contain;
}

.saved-thumb.tall {
  height: 150px;
  padding: 0;
}

.saved-thumb.tall img {
  width: 100%;
  height: 100%;
  max-height: none;
  border-radius: 0;
  object-fit: cover;
  object-position: top center;
}

.saved-card-head {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
}

.saved-card-icon {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  border-radius: var(--ink-radius);
  background: color-mix(in srgb, var(--kind-tone) 14%, transparent);
  color: var(--kind-tone);
}

.saved-card {
  --kind-tone: var(--ink-blue);
}

.saved-card.kind-errors,
.saved-card.kind-network {
  --kind-tone: var(--ink-red);
}

.saved-card.kind-report,
.saved-card.kind-measure {
  --kind-tone: var(--ink-green);
}

.saved-card.kind-css,
.saved-card.kind-color {
  --kind-tone: var(--ink-magenta);
}

.saved-card-heading {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.saved-card-title-row {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.saved-card-title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  /* The editor text color: some themes (Tokyo Night) keep the sidebar foreground quite dim. */
  color: var(--vscode-editor-foreground, var(--vscode-foreground));
  font-weight: 600;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* A soft chip in the link color, readable on light, dark and high-contrast backgrounds alike. */
.saved-card-badge {
  flex-shrink: 0;
  padding: 0 7px;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--ink-blue) 16%, transparent);
  color: var(--ink-blue);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 16px;
}

.saved-card-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0 6px;
  min-width: 0;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

.saved-card-meta span {
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-card-meta span + span::before {
  content: '\xB7';
  margin-right: 6px;
}

.saved-card-preview {
  margin: 0;
  padding: 6px 8px;
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-textCodeBlock-background, var(--ink-surface));
  color: var(--vscode-descriptionForeground, var(--ink-muted));
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-xs);
  line-height: 1.45;
}

/* Clamped inside the padding, so no half line shows below it. */
.saved-card-preview span {
  display: -webkit-box;
  overflow: hidden;
  word-break: break-word;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}

.saved-card-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
}

/* Send, and a chevron for another agent, joined into one control. */
.saved-send {
  display: inline-flex;
  flex-shrink: 0;
}

.saved-send .saved-send-more {
  min-width: 0;
  /* A hairline of the card shows between the two halves. */
  margin-left: 1px;
  padding: 0 5px;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

.saved-send .button:first-child:not(:last-child) {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}

.saved-card-tools {
  display: inline-flex;
  gap: 1px;
  margin-left: auto;
  opacity: 0.55;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.saved-card:hover .saved-card-tools,
.saved-card:focus-within .saved-card-tools {
  opacity: 1;
}

.saved-card-sent {
  display: flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  color: var(--ink-green);
  font-size: var(--ink-font-xs);
}

.saved-card-sent .codicon {
  flex-shrink: 0;
  font-size: 12px !important;
}

.saved-card-sent span:last-child {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Very narrow: the send button takes the whole row, the tools go below it. */
@container saved (max-width: 210px) {
  .saved-send,
  .saved-send .button:first-child {
    flex: 1;
  }

  .saved-card-tools {
    margin-left: 0;
  }
}

.saved-none {
  margin: var(--ink-space-4) var(--ink-space-3);
  color: var(--ink-muted);
  text-align: center;
}

.saved-footer {
  position: sticky;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ink-space-2);
  margin-top: auto;
  padding: 6px var(--ink-space-3);
  border-top: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
}

.saved-hint {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
}

@container saved (max-width: 320px) {
  .saved-hint {
    display: none;
  }

  .saved-footer {
    justify-content: flex-end;
  }
}

@media (prefers-reduced-motion: reduce) {
  .saved-card,
  .saved-card-tools {
    transition: none;
  }
}

body.vscode-high-contrast .saved-card {
  border-color: var(--vscode-contrastBorder);
}

body.vscode-high-contrast .saved-card.latest,
body.vscode-high-contrast .saved-card:focus-visible {
  border-color: var(--vscode-contrastActiveBorder, var(--ink-focus));
}

/* Selecting cards (to send, remove or group several): a checkbox in the head, shown on hover,
   on focus, and on every card while anything is selected. */
.saved-card-select {
  display: none;
  margin-top: 6px;
}

.saved-card:hover .saved-card-select,
.saved-card:focus-within .saved-card-select,
.saved.selecting .saved-card-select,
.saved-card.selected .saved-card-select {
  display: inline-flex;
}

.saved-card.selected {
  border-color: var(--ink-accent);
  background: color-mix(in srgb, var(--ink-accent) 8%, var(--card-bg));
}

body.vscode-high-contrast .saved-card.selected {
  border-color: var(--vscode-contrastActiveBorder);
}

/* A group: screenshots taken (or grouped) together, one thumbnail each. */
.saved-group .saved-card-icon {
  --kind-tone: var(--ink-blue);
}

.saved-card-count {
  flex-shrink: 0;
  min-width: 18px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--vscode-foreground, #888) 12%, transparent);
  color: var(--vscode-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 16px;
  text-align: center;
}

.saved-group-thumbs {
  grid-template-columns: repeat(auto-fill, minmax(72px, 1fr));
}

/* The footer while cards are selected: what to do with all of them. */
.saved-selection {
  justify-content: flex-start;
  gap: 4px;
}

.saved-selection-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: auto;
  font-weight: 600;
}

.saved-selection-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: var(--ink-accent);
  color: var(--vscode-button-foreground);
  font-size: var(--ink-font-xs);
}

/* A group of elements (or other text): a checklist, one row each. */
.saved-group-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
  margin: 0;
  padding: 4px;
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
  list-style: none;
}

.saved-group-row {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  padding: 3px 4px 3px 6px;
  border-radius: var(--ink-radius-sm);
}

.saved-group-row:hover {
  background: var(--vscode-list-hoverBackground, var(--ink-hover));
}

.saved-group-row:not(.on) .saved-group-row-text,
.saved-group-row:not(.on) .saved-group-row-icon {
  opacity: 0.5;
}

.saved-group-row-icon {
  flex-shrink: 0;
  color: var(--ink-blue);
}

.saved-group-row-text {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
}

.saved-group-row-title {
  overflow: hidden;
  color: var(--vscode-editor-foreground, var(--vscode-foreground));
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-group-row-detail {
  overflow: hidden;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-group-row-open {
  opacity: 0;
}

.saved-group-row:hover .saved-group-row-open,
.saved-group-row:focus-within .saved-group-row-open {
  opacity: 1;
}

/* After a removal: what went, and Undo (for a few seconds). */
.saved-undo-text {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  color: var(--vscode-foreground);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-undo-text .codicon {
  color: var(--ink-muted);
}

/* Send and its chevron, then Open in agentmux. */
.saved-send-group {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 2px;
}

/* A thumbnail that opens nothing (the side panel). */
.saved-thumb.still {
  cursor: default;
}

.saved-thumb.still:hover {
  opacity: 1;
}

@container saved (max-width: 210px) {
  .saved-send-group {
    flex: 1;
  }
}
`;var X1=R(b0());var ls=R(Ae(),1);function cs(e,t,n,o={}){let{align:a="start",gap:i=4,matchWidth:r=!1}=o;(0,ls.useLayoutEffect)(()=>{if(!n)return;let l=()=>{e.current&&t.current&&ZS(e.current,t.current,{align:a,gap:i,matchWidth:r})};l();let c=new ResizeObserver(l);return t.current&&c.observe(t.current),()=>c.disconnect()},[e,t,n,a,i,r])}function ZS(e,t,{align:n,gap:o,matchWidth:a}){let i=e.getBoundingClientRect();a&&(t.style.minWidth=`${i.width}px`);let r=t.getBoundingClientRect(),l=4,c=i.bottom+o,s=c+r.height<=innerHeight-l,p=i.top-o-r.height,b=s||p<l?c:p,u=n==="end"?i.right-r.width:i.left;t.style.top=`${Math.max(l,Math.min(b,innerHeight-r.height-l))}px`,t.style.left=`${Math.max(l,Math.min(u,innerWidth-r.width-l))}px`,t.dataset.side=b===c?"bottom":"top"}function Pf(e,t,n){let o=e().find(Boolean)?.getRootNode(),a=o instanceof ShadowRoot?o:void 0,i=c=>e().some(s=>s&&c.composedPath().includes(s)),r=c=>{a&&c.composedPath().includes(a.host)||i(c)||n(c)},l=c=>{i(c)||n(c)};return window.addEventListener(t,r,!0),a?.addEventListener(t,l,!0),()=>{window.removeEventListener(t,r,!0),a?.removeEventListener(t,l,!0)}}var Wr,h0=e=>{let t=e.composedPath()[0];if(e.button!==0){Wr=void 0;return}t instanceof Element&&(Wr={element:t.closest('button, [role="button"], a')??t,at:performance.now()})};typeof window<"u"&&window.addEventListener("pointerdown",h0,!0);function v0(e){e.addEventListener("pointerdown",h0,!0)}function ss(){return Wr&&performance.now()-Wr.at<1e3?Wr.element:void 0}function PS(e){let t=e.getRootNode(),n=[window];t instanceof ShadowRoot&&n.push(t);let o=r=>{r.composedPath().includes(e)&&(r.stopPropagation(),r.preventDefault(),a())},a=()=>{clearTimeout(i);for(let r of n)r.removeEventListener("click",o,!0)},i=setTimeout(a,1e3);for(let r of n)r.addEventListener("click",o,!0)}function us(e,t,n,o){return Pf(e,"pointerdown",a=>{o?.(a)||(t&&a.composedPath().includes(t)&&PS(t),n(a))})}function ds(e,t,n){(0,ls.useEffect)(()=>{if(!t)return;let o=()=>e.map(c=>c.current),a=Pf(o,"pointerdown",()=>n("outside")),i=Pf(o,"scroll",()=>n("window")),r=c=>{c.key==="Escape"&&(c.preventDefault(),c.stopPropagation(),n("escape"))},l=()=>n("window");return window.addEventListener("keydown",r,!0),window.addEventListener("blur",l),window.addEventListener("resize",l),()=>{a(),i(),window.removeEventListener("keydown",r,!0),window.removeEventListener("blur",l),window.removeEventListener("resize",l)}},[t,n])}function oe(...e){return e.filter(Boolean).join(" ")}function fs(e){let t=e?.getRootNode();return t instanceof ShadowRoot?t:document.body}function y0(e){return e.composedPath().some(t=>t instanceof HTMLElement&&t.dataset.inkPopup!==void 0)}var ka=R(Ae(),1);var el={global:"Browser",inspect:"Element picker",draw:"Drawing",screenshot:"Screenshot",devtools:"Console and network",device:"Device",measure:"Measure",eyedropper:"Eyedropper",overlay:"Design overlay",tweak:"CSS tweak",record:"Record",a11y:"Accessibility check",send:"Send dialog"},ie=e=>`vscodeBrowser.${e}`,pn=[{id:"tab.new",label:"New tab",scope:"global",keys:["ctrl+t"],command:ie("newTab")},{id:"tab.close",label:"Close tab",scope:"global",keys:["ctrl+w","ctrl+f4"],command:ie("closeTab")},{id:"tab.reopen",label:"Reopen closed tab",scope:"global",keys:["ctrl+shift+t"],command:ie("reopenClosedTab")},{id:"tab.next",label:"Next tab",scope:"global",keys:["ctrl+tab","ctrl+pagedown"],mac:["ctrl+tab","cmd+alt+right"],command:ie("nextTab")},{id:"tab.previous",label:"Previous tab",scope:"global",keys:["ctrl+shift+tab","ctrl+pageup"],mac:["ctrl+shift+tab","cmd+alt+left"],command:ie("previousTab")},{id:"tab.duplicate",label:"Duplicate tab",scope:"global",keys:[],command:ie("duplicateTab")},{id:"tab.private",label:"New private tab",scope:"global",keys:["ctrl+shift+n"],command:ie("newPrivateTab")},{id:"window.new",label:"New window",scope:"global",keys:["ctrl+n"],command:ie("newWindow")},{id:"nav.address",label:"Focus the address bar",scope:"global",keys:["ctrl+l","alt+d"],mac:["cmd+l","alt+d"],command:ie("focusAddressBar")},{id:"nav.back",label:"Back",scope:"global",keys:["alt+left"],mac:["cmd+["],command:ie("goBack")},{id:"nav.forward",label:"Forward",scope:"global",keys:["alt+right"],mac:["cmd+]"],command:ie("goForward")},{id:"nav.reload",label:"Reload",scope:"global",keys:["ctrl+r","f5"],mac:["cmd+r"],command:ie("reload")},{id:"nav.hardReload",label:"Hard reload",scope:"global",keys:["ctrl+shift+r","ctrl+f5"],mac:["cmd+shift+r"],command:ie("hardReload")},{id:"nav.stop",label:"Stop loading",scope:"global",keys:[],command:ie("stop")},{id:"nav.home",label:"Home page",scope:"global",keys:["alt+home"],mac:["cmd+shift+h"],command:ie("goHome")},{id:"page.find",label:"Find in page",scope:"global",keys:["ctrl+f"],command:ie("find")},{id:"page.zoomIn",label:"Zoom in",scope:"global",keys:["ctrl+=","ctrl+shift+="],command:ie("zoomIn")},{id:"page.zoomOut",label:"Zoom out",scope:"global",keys:["ctrl+-"],command:ie("zoomOut")},{id:"page.zoomReset",label:"Reset zoom",scope:"global",keys:["ctrl+0"],command:ie("zoomReset")},{id:"page.bookmark",label:"Bookmark this page",scope:"global",keys:["ctrl+d"],command:ie("bookmarkPage")},{id:"page.source",label:"View page source",scope:"global",keys:["ctrl+u"],mac:["cmd+alt+u"],command:ie("viewSource")},{id:"page.pdf",label:"Save page as PDF",scope:"global",keys:[],command:ie("savePdf")},{id:"page.copyUrl",label:"Copy page address",scope:"global",keys:["ctrl+shift+l"],command:ie("copyUrl")},{id:"page.external",label:"Open in system browser",scope:"global",keys:[],command:ie("openInSystemBrowser")},{id:"page.devtools",label:"Open DevTools",scope:"global",keys:["f12"],command:ie("openDevTools")},{id:"page.contextToAgent",label:"Send page context to agent",scope:"global",keys:["ctrl+alt+enter"],command:ie("sendPageContextToChat")},{id:"agent.showContext",label:"Show agent context",scope:"global",keys:["ctrl+shift+alt+a"],command:ie("showAgentContext"),everywhere:!0},{id:"agent.sendLatest",label:"Send the latest capture to the agent",scope:"global",keys:["ctrl+shift+alt+v"],command:ie("sendLatestContext"),everywhere:!0},{id:"open.history",label:"History",scope:"global",keys:["ctrl+h"],mac:["cmd+y"],command:ie("showHistory")},{id:"open.downloads",label:"Downloads",scope:"global",keys:["shift+alt+l"],command:ie("showDownloads")},{id:"open.bookmarks",label:"Bookmark manager",scope:"global",keys:["ctrl+alt+b"],command:ie("showBookmarks")},{id:"open.bookmarksBar",label:"Show or hide the bookmarks bar",scope:"global",keys:["ctrl+shift+b"]},{id:"open.quickActions",label:"Quick actions",scope:"global",keys:["ctrl+shift+k"]},{id:"open.shortcuts",label:"Change keyboard shortcuts",scope:"global",keys:["ctrl+alt+k"],command:ie("editShortcuts")},{id:"open.cheatSheet",label:"Keyboard shortcuts of this mode",scope:"global",keys:["ctrl+shift+/"],mac:["cmd+alt+/"]},{id:"mode.inspect",label:"Element picker",scope:"global",keys:["shift+alt+e"]},{id:"mode.draw",label:"Draw on the page",scope:"global",keys:["shift+alt+w"]},{id:"mode.screenshot",label:"Screenshot",scope:"global",keys:["shift+alt+g"]},{id:"mode.devtools",label:"Console and network",scope:"global",keys:["shift+alt+j"]},{id:"mode.device",label:"Device toolbar",scope:"global",keys:["shift+alt+m"]},{id:"mode.measure",label:"Measure",scope:"global",keys:["shift+alt+u"]},{id:"mode.eyedropper",label:"Eyedropper",scope:"global",keys:["shift+alt+y"]},{id:"mode.overlay",label:"Design overlay",scope:"global",keys:["shift+alt+o"]},{id:"mode.tweak",label:"CSS tweak",scope:"global",keys:["shift+alt+v"]},{id:"mode.record",label:"Record the page",scope:"global",keys:["ctrl+alt+r"]},{id:"mode.a11y",label:"Accessibility check",scope:"global",keys:["shift+alt+h"]},{id:"inspect.parent",label:"Select the parent element",scope:"inspect",keys:["up"]},{id:"inspect.child",label:"Select the first child element",scope:"inspect",keys:["down"]},{id:"inspect.copy",label:"Copy the selected elements",scope:"inspect",keys:["enter","c"]},{id:"inspect.screenshot",label:"Screenshot the element",scope:"inspect",keys:["s"]},{id:"inspect.agent",label:"Send the element to the agent",scope:"inspect",keys:["a"]},{id:"inspect.help",label:"Show these shortcuts",scope:"inspect",keys:["shift+/"]},{id:"inspect.exit",label:"Exit",scope:"inspect",keys:["escape"]},{id:"draw.select",label:"Select and move",scope:"draw",keys:["v"]},{id:"draw.pen",label:"Pen",scope:"draw",keys:["p"]},{id:"draw.pencil",label:"Pencil",scope:"draw",keys:["i"]},{id:"draw.marker",label:"Marker",scope:"draw",keys:["m"]},{id:"draw.brush",label:"Brush",scope:"draw",keys:["u"]},{id:"draw.highlighter",label:"Highlighter",scope:"draw",keys:["h"]},{id:"draw.neon",label:"Neon",scope:"draw",keys:["g"]},{id:"draw.line",label:"Line",scope:"draw",keys:["l"]},{id:"draw.arrow",label:"Arrow",scope:"draw",keys:["a"]},{id:"draw.doubleArrow",label:"Double arrow",scope:"draw",keys:["d"]},{id:"draw.rect",label:"Rectangle",scope:"draw",keys:["r"]},{id:"draw.ellipse",label:"Ellipse",scope:"draw",keys:["o"]},{id:"draw.text",label:"Text",scope:"draw",keys:["t"]},{id:"draw.callout",label:"Numbered callout",scope:"draw",keys:["n"]},{id:"draw.blur",label:"Redact (pixelate)",scope:"draw",keys:["b"]},{id:"draw.eraser",label:"Eraser",scope:"draw",keys:["e"]},...[1,2,3,4,5,6,7,8,9].map(e=>({id:`draw.color${e}`,label:`Color ${e}`,scope:"draw",keys:[String(e)]})),{id:"draw.thinner",label:"Thinner stroke",scope:"draw",keys:["["]},{id:"draw.thicker",label:"Thicker stroke",scope:"draw",keys:["]"]},{id:"draw.fill",label:"Fill shapes on or off",scope:"draw",keys:["f"]},{id:"draw.undo",label:"Undo",scope:"draw",keys:["ctrl+z"]},{id:"draw.redo",label:"Redo",scope:"draw",keys:["ctrl+y","ctrl+shift+z"]},{id:"draw.clear",label:"Clear all drawings",scope:"draw",keys:["shift+backspace"]},{id:"draw.visible",label:"Hide or show drawings",scope:"draw",keys:["w"]},{id:"draw.capture",label:"Screenshot the drawing area",scope:"draw",keys:["enter"]},{id:"draw.captureAgent",label:"Screenshot the drawing area and send it to the agent",scope:"draw",keys:["shift+enter"]},{id:"draw.captureMenu",label:"Screenshot menu",scope:"draw",keys:["s"]},{id:"draw.captureGroups",label:"Screenshot each drawing separately",scope:"draw",keys:["alt+g"]},{id:"draw.captureClean",label:"Screenshot the drawing area without drawings",scope:"draw",keys:["alt+c"]},{id:"draw.captureViewport",label:"Screenshot the visible area with drawings",scope:"draw",keys:["alt+v"]},{id:"draw.captureFullPage",label:"Screenshot the full page with drawings",scope:"draw",keys:["alt+f"]},{id:"draw.help",label:"Show these shortcuts",scope:"draw",keys:["shift+/"]},{id:"draw.exit",label:"Stop drawing",scope:"draw",keys:["escape"]},{id:"shot.viewport",label:"Visible area",scope:"screenshot",keys:["v"]},{id:"shot.fullPage",label:"Full page",scope:"screenshot",keys:["f"]},{id:"shot.region",label:"Region",scope:"screenshot",keys:["r"]},{id:"shot.element",label:"Element",scope:"screenshot",keys:["e"]},{id:"shot.drawing",label:"Drawing area",scope:"screenshot",keys:["d"]},{id:"shot.lastToAgent",label:"Send the last screenshot to the agent",scope:"screenshot",keys:["a"],command:ie("screenshot.sendToTerminal")},{id:"send.default",label:"Send to the default agent",scope:"send",keys:["enter"]},{id:"send.newThread",label:"New agentmux thread",scope:"send",keys:["n"]},{id:"send.project",label:"Change project",scope:"send",keys:["p"]},{id:"send.copy",label:"Copy",scope:"send",keys:["c"]},{id:"send.download",label:"Download",scope:"send",keys:["d"]},{id:"send.close",label:"Close (keep it saved)",scope:"send",keys:["escape"]},{id:"dev.console",label:"Console",scope:"devtools",keys:["alt+1"]},{id:"dev.network",label:"Network",scope:"devtools",keys:["alt+2"]},{id:"dev.filter",label:"Filter",scope:"devtools",keys:["alt+f"]},{id:"dev.copyErrors",label:"Copy console errors",scope:"devtools",keys:["alt+e"]},{id:"dev.copyFailed",label:"Copy failed requests",scope:"devtools",keys:["alt+q"]},{id:"dev.copyContext",label:"Copy page context",scope:"devtools",keys:["alt+p"]},{id:"dev.contextAgent",label:"Send page context to the agent",scope:"devtools",keys:["alt+shift+p"]},{id:"dev.clear",label:"Clear",scope:"devtools",keys:["alt+k"]},{id:"dev.close",label:"Close",scope:"devtools",keys:["alt+w"]},{id:"device.previous",label:"Previous device",scope:"device",keys:["alt+["]},{id:"device.next",label:"Next device",scope:"device",keys:["alt+]"]},{id:"device.rotate",label:"Rotate",scope:"device",keys:["alt+r"]},{id:"device.touch",label:"Touch and mobile on or off",scope:"device",keys:["alt+t"]},{id:"device.fit",label:"Fit to window",scope:"device",keys:["alt+0"]},{id:"device.zoomIn",label:"Zoom in",scope:"device",keys:["alt+="]},{id:"device.zoomOut",label:"Zoom out",scope:"device",keys:["alt+-"]},{id:"device.network",label:"Next network speed",scope:"device",keys:["alt+n"]},{id:"device.theme",label:"Next color scheme",scope:"device",keys:["alt+l"]},{id:"device.close",label:"Close the device toolbar",scope:"device",keys:[]},{id:"measure.grid",label:"Rulers and grid on or off",scope:"measure",keys:["g"]},{id:"measure.copy",label:"Copy the measurements",scope:"measure",keys:["c"]},{id:"measure.clear",label:"Clear the pinned element",scope:"measure",keys:["backspace"]},{id:"measure.help",label:"Show these shortcuts",scope:"measure",keys:["shift+/"]},{id:"measure.exit",label:"Exit",scope:"measure",keys:["escape"]},{id:"eyedropper.hex",label:"Copy colors as hex",scope:"eyedropper",keys:["h"]},{id:"eyedropper.rgb",label:"Copy colors as rgb()",scope:"eyedropper",keys:["r"]},{id:"eyedropper.hsl",label:"Copy colors as hsl()",scope:"eyedropper",keys:["l"]},{id:"eyedropper.help",label:"Show these shortcuts",scope:"eyedropper",keys:["shift+/"]},{id:"eyedropper.exit",label:"Exit",scope:"eyedropper",keys:["escape"]},{id:"overlay.open",label:"Open an image",scope:"overlay",keys:["alt+o"]},{id:"overlay.fainter",label:"Less opaque",scope:"overlay",keys:["alt+,"]},{id:"overlay.stronger",label:"More opaque",scope:"overlay",keys:["alt+."]},{id:"overlay.left",label:"Nudge left",scope:"overlay",keys:["alt+left"]},{id:"overlay.right",label:"Nudge right",scope:"overlay",keys:["alt+right"]},{id:"overlay.up",label:"Nudge up",scope:"overlay",keys:["alt+up"]},{id:"overlay.down",label:"Nudge down",scope:"overlay",keys:["alt+down"]},{id:"overlay.difference",label:"Difference blend on or off",scope:"overlay",keys:["alt+x"]},{id:"overlay.hide",label:"Hide or show the overlay",scope:"overlay",keys:["alt+h"]},{id:"overlay.exit",label:"Close the overlay",scope:"overlay",keys:["alt+z"]},{id:"tweak.agent",label:"Send the CSS changes to the agent",scope:"tweak",keys:["ctrl+enter"]},{id:"tweak.copy",label:"Copy the CSS changes",scope:"tweak",keys:["ctrl+shift+c"]},{id:"tweak.undo",label:"Undo the last change",scope:"tweak",keys:["ctrl+z"]},{id:"tweak.exit",label:"Exit and revert",scope:"tweak",keys:["escape"]},{id:"record.stop",label:"Stop and save",scope:"record",keys:["alt+s"]},{id:"record.pause",label:"Pause or resume",scope:"record",keys:["alt+y"]},{id:"record.cancel",label:"Cancel",scope:"record",keys:["alt+backspace"]},{id:"a11y.next",label:"Next issue",scope:"a11y",keys:["n","down"]},{id:"a11y.previous",label:"Previous issue",scope:"a11y",keys:["p","up"]},{id:"a11y.tabOrder",label:"Tab order on or off",scope:"a11y",keys:["t"]},{id:"a11y.copy",label:"Copy the report",scope:"a11y",keys:["c"]},{id:"a11y.agent",label:"Send the report to the agent",scope:"a11y",keys:["a"]},{id:"a11y.help",label:"Show these shortcuts",scope:"a11y",keys:["shift+/"]},{id:"a11y.exit",label:"Exit",scope:"a11y",keys:["escape"]}];function tl(e,t){return t?[...e.mac??e.keys.map(n=>n.replace(/\bctrl\+/,"cmd+"))]:[...e.keys]}function ps(e){let t=Jf(e.trim());return t.key?[t.ctrl&&"ctrl",t.shift&&"shift",t.alt&&"alt",t.meta&&"cmd",t.key].filter(Boolean).join("+"):""}function ms(e,t){let n={};for(let o of pn){let a=e[o.id],i=(a===void 0?tl(o,t):typeof a=="string"?[a]:[...a]).map(ps);n[o.id]=[...new Set(i.filter(Boolean))]}return n}function C0(e){if(!e||typeof e!="object"||Array.isArray(e))return{};let t=new Set(pn.map(o=>o.id)),n={};for(let[o,a]of Object.entries(e))t.has(o)&&(typeof a=="string"||Array.isArray(a)&&a.every(i=>typeof i=="string"))&&(n[o]=a);return n}var x0=new Set(["devtools","device","overlay","record"]);function N0(e){let t=new Map(pn.map(a=>[a.id,a.scope])),n=new Map;for(let[a,i]of Object.entries(e))for(let r of i)n.set(r,[...n.get(r)??[],a]);let o=[];for(let[a,i]of n)for(let r=0;r<i.length;r++)for(let l=r+1;l<i.length;l++){let[c,s]=[t.get(i[r]),t.get(i[l])];(c===s||x0.has(c)&&x0.has(s))&&o.push({key:a,ids:[i[r],i[l]]})}return o}function nl(e,t,n){let o=gs(n);for(let a of t){let i=pn.find(r=>r.scope===a&&(e[r.id]??[]).includes(o));if(i)return i}}function gs(e){return[e.ctrl&&"ctrl",e.shift&&"shift",e.alt&&"alt",e.meta&&"cmd",e.key].filter(Boolean).join("+")}var $f=new Set(["mode.inspect","mode.draw","mode.screenshot","mode.device","mode.devtools","page.bookmark","open.shortcuts","inspect.parent","inspect.child","inspect.copy","inspect.exit",...["select","pen","pencil","marker","brush","highlighter","neon","line","arrow","doubleArrow","rect","ellipse","text","callout","blur","eraser"].map(e=>`draw.${e}`),...Array.from({length:9},(e,t)=>`draw.color${t+1}`),"draw.thinner","draw.thicker","draw.fill","draw.undo","draw.redo","draw.clear","draw.visible","draw.capture","draw.captureMenu","draw.captureGroups","draw.captureClean","draw.captureViewport","draw.captureFullPage","draw.exit","shot.viewport","shot.fullPage","shot.region","shot.element","shot.drawing","send.default","send.newThread","send.project","send.copy","send.download","send.close"]),$S=new Set([]),k0={id:"vs",label:"VS",title:"Works in VS Code Browser"},w0={id:"br",label:"BR",title:"Works in the Inkspect toolbar in your browser (Chrome, Edge, Firefox...)"};function M0(e){return $S.has(e.scope)?[w0]:$f.has(e.id)?[k0,w0]:[k0]}var JS={control:"ctrl",ctl:"ctrl","\u2303":"ctrl",option:"alt",opt:"alt","\u2325":"alt",command:"cmd",meta:"cmd",win:"cmd",super:"cmd","\u2318":"cmd","\u21E7":"shift",esc:"escape",return:"enter","\u21A9":"enter",del:"delete","\u2191":"up","\u2193":"down","\u2190":"left","\u2192":"right",pgup:"pageup",pgdn:"pagedown","+":"="},S0=new Set(["ctrl","shift","alt","cmd"]);function A0(e,t){let n=t.toLowerCase().replace(/([⌃⌥⇧⌘↩↑↓←→])/g," $1 ").split(/\s+|[+-](?=.)/).filter(Boolean).map(c=>JS[c]??c);if(!n.length)return!1;let o=n.filter(c=>S0.has(c)),a=n.filter(c=>!S0.has(c));if(a.length>1)return!1;let i=Jf(ps(e)),r={ctrl:i.ctrl,shift:i.shift,alt:i.alt,cmd:i.meta};if(!o.every(c=>r[c]))return!1;let[l]=a;return l===void 0||i.key.startsWith(l)}function z0(e){if(!e.key)return;let t=/^f([1-9]|1\d|2[0-4])$/.test(e.key);return e.ctrl||e.alt||e.meta||t?gs(e):void 0}function Di(e,t){let n=qt(e,t);return t?[...[...n.matchAll(/[⌃⌥⇧⌘]/g)].map(a=>a[0]),n.replace(/[⌃⌥⇧⌘]/g,"")]:n.split(/\+(?=.)/)}var O0={global:"browser",inspect:"inspect",draw:"edit",screenshot:"device-camera",devtools:"debug-console",device:"device-mobile",measure:"symbol-ruler",eyedropper:"symbol-color",overlay:"layers",tweak:"symbol-property",record:"record",a11y:"accessibility",send:"send"};function qt(e,t){let n=Jf(e),o={escape:"Esc",enter:t?"\u21A9":"Enter",backspace:t?"\u232B":"Backspace",delete:t?"\u2326":"Delete",up:"\u2191",down:"\u2193",left:"\u2190",right:"\u2192",pageup:"PgUp",pagedown:"PgDn",tab:t?"\u21E5":"Tab",space:"Space","/":n.shift?"?":"/"},a=!(n.key==="/"&&n.shift),i=o[n.key]??(n.key.length===1?n.key.toUpperCase():n.key[0].toUpperCase()+n.key.slice(1));return t?`${n.ctrl?"\u2303":""}${n.alt?"\u2325":""}${n.shift&&a?"\u21E7":""}${n.meta?"\u2318":""}${i}`:[n.ctrl&&"Ctrl",n.alt&&"Alt",n.shift&&a&&"Shift",i].filter(Boolean).join("+")}function Jf(e){let t=e.toLowerCase().split("+"),n=t.pop()??"";return{ctrl:t.includes("ctrl"),shift:t.includes("shift"),alt:t.includes("alt"),meta:t.includes("cmd")||t.includes("meta")||t.includes("win"),key:n}}var IS={arrowleft:"left",arrowright:"right",arrowup:"up",arrowdown:"down",esc:"escape"," ":"space","+":"="},E0={Equal:"=",Minus:"-",BracketLeft:"[",BracketRight:"]",Slash:"/",Backslash:"\\",Comma:",",Period:".",Semicolon:";",Quote:"'",Backquote:"`",NumpadAdd:"=",NumpadSubtract:"-"},bs=new Set(["Control","Shift","Alt","Meta","AltGraph","OS"]),T0={"?":"/","<":",",">":".",":":";",'"':"'","{":"[","}":"]","|":"\\","~":"`",_:"-","+":"=","!":"1","@":"2","#":"3",$:"4","%":"5","^":"6","&":"7","*":"8","(":"9",")":"0"};function eo(e){let t={ctrl:e.ctrlKey,shift:e.shiftKey,alt:e.altKey,meta:e.metaKey};if(e.getModifierState?.("AltGraph"))return{...t,key:""};let n=e.key,o;return/^[a-z0-9]$/i.test(n)?o=n.toLowerCase():e.shiftKey&&T0[n]!==void 0?o=T0[n]:/^[-=[\]\\/,.;'`+]$/.test(n)?o=n:/^Key[A-Z]$/.test(e.code)?o=e.code.slice(3).toLowerCase():/^Digit\d$/.test(e.code)?o=e.code.slice(5):E0[e.code]?o=E0[e.code]:o=n.toLowerCase(),{...t,key:IS[o]??o}}var xa=R(j(),1);function vs({icon:e,trailing:t,size:n="md",onClear:o,invalid:a,className:i,disabled:r,...l}){let c=l.value!==void 0&&String(l.value)!=="";return(0,xa.jsxs)("div",{className:oe("text-field",`size-${n}`,a&&"invalid",r&&"disabled",i),children:[e&&(0,xa.jsx)("span",{className:`codicon codicon-${e} text-field-icon`,"aria-hidden":"true"}),(0,xa.jsx)("input",{spellCheck:!1,...l,disabled:r,"aria-invalid":a||void 0}),o&&c&&(0,xa.jsx)("button",{type:"button",className:"text-field-clear","aria-label":"Clear",title:"Clear",tabIndex:-1,onClick:o,children:(0,xa.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})}),t]})}var L0=R(j(),1),e2=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),to=null;function H0(e){return to?(to(e),!0):!1}typeof window<"u"&&window.addEventListener("keydown",e=>{if(!to||bs.has(e.key))return;e.stopImmediatePropagation();let t=z0(eo(e));t&&(e.preventDefault(),to(t))},!0);function B0({value:e,onChange:t,size:n}){let o=(0,ka.useRef)(t);(0,ka.useEffect)(()=>{o.current=t});let[a]=(0,ka.useState)(()=>i=>o.current(qt(i,e2)));return(0,ka.useEffect)(()=>()=>{to===a&&(to=null)},[a]),(0,L0.jsx)(vs,{size:n,icon:"search",placeholder:"Search actions or keys, or press a shortcut","aria-label":"Search shortcuts: type, or press a shortcut",value:e,onChange:i=>t(i.target.value),onClear:()=>t(""),onFocus:()=>{to=a},onBlur:()=>{to===a&&(to=null)}})}var _=R(Ae());var j0=["pen","pencil","marker","brush","highlighter","neon"],q0=["line","arrow","doubleArrow","rect","ellipse","blur"],_i=["#ff3b30","#ff9500","#ffcc00","#34c759","#00c7be","#007aff","#af52de","#ffffff","#000000"],wa={color:"#ff3b30",width:4,opacity:1,dash:"solid",fill:!1};function If(e){return 12+e.width*2}function Ff(e){return 10+e.width}function ol(e){let t=e.style.width/2+(e.kind==="stroke"&&e.tool==="neon"?8:0),n;switch(e.kind){case"stroke":n=e.points.map(([o,a])=>[o,a]);break;case"text":{let o=If(e.style),a=e.text.split(`
`),i=Math.max(...a.map(r=>r.length))*o*.6;n=[e.at,[e.at[0]+i,e.at[1]+a.length*o*1.25]];break}case"callout":{let o=Ff(e.style);n=[[e.at[0]-o,e.at[1]-o],[e.at[0]+o,e.at[1]+o]];break}default:{let o=e.kind==="arrow"||e.kind==="doubleArrow"?Wf(e.style):0;return n=[e.start,e.end],ys(U0(n),t+o)}}return ys(U0(n),t)}function Wf(e){return 8+e.width*2.5}function U0(e){let t=e.map(i=>i[0]),n=e.map(i=>i[1]),o=Math.min(...t),a=Math.min(...n);return{x:o,y:a,width:Math.max(...t)-o,height:Math.max(...n)-a}}function ys(e,t){return{x:e.x-t,y:e.y-t,width:e.width+t*2,height:e.height+t*2}}function Y0(e){if(!e.length)return;let t=Math.min(...e.map(i=>i.x)),n=Math.min(...e.map(i=>i.y)),o=Math.max(...e.map(i=>i.x+i.width)),a=Math.max(...e.map(i=>i.y+i.height));return{x:t,y:n,width:o-t,height:a-n}}function t2(e,t){let n=Math.max(0,e.x),o=Math.max(0,e.y),a=t?Math.min(t.width,e.x+e.width):e.x+e.width,i=t?Math.min(t.height,e.y+e.height):e.y+e.height;return{x:n,y:o,width:Math.max(1,a-n),height:Math.max(1,i-o)}}function V0(e,t){let n=Y0(e.map(ol));return n&&t2(ys(n,t))}function n2(e,t,n){return e.x-n<=t.x+t.width&&t.x-n<=e.x+e.width&&e.y-n<=t.y+t.height&&t.y-n<=e.y+e.height}function K0(e,t){let n=[];for(let o of e){let a=ol(o),i=n.filter(l=>n2(l.bounds,a,t)),r={shapes:[...i.flatMap(l=>l.shapes),o],bounds:Y0([a,...i.map(l=>l.bounds)])};for(let l of i)n.splice(n.indexOf(l),1);n.push(r)}return n.sort((o,a)=>o.bounds.y-a.bounds.y).map(o=>o.shapes)}function ep(e,t,n){let o=ys(ol(e),n);if(!(t[0]>=o.x&&t[0]<=o.x+o.width&&t[1]>=o.y&&t[1]<=o.y+o.height))return!1;if(e.kind==="stroke"){let i=n+e.style.width/2;return e.points.some(([r,l])=>Math.hypot(r-t[0],l-t[1])<=i+4)}return e.kind==="line"||e.kind==="arrow"||e.kind==="doubleArrow"?o2(t,e.start,e.end)<=n+e.style.width/2:!0}function o2(e,t,n){let o=n[0]-t[0],a=n[1]-t[1],i=o*o+a*a,r=i?Math.max(0,Math.min(1,((e[0]-t[0])*o+(e[1]-t[1])*a)/i)):0;return Math.hypot(e[0]-(t[0]+r*o),e[1]-(t[1]+r*a))}function X0(e,t,n){let o=([a,i])=>[a+t,i+n];switch(e.kind){case"stroke":return{...e,points:e.points.map(([a,i,r])=>[a+t,i+n,r])};case"text":case"callout":return{...e,at:o(e.at)};default:return{...e,start:o(e.start),end:o(e.end)}}}function G0(e,t,n){let o=n[0]-t[0],a=n[1]-t[1];if(e==="rect"||e==="ellipse"||e==="blur"){let l=Math.max(Math.abs(o),Math.abs(a));return[t[0]+Math.sign(o||1)*l,t[1]+Math.sign(a||1)*l]}let i=Math.round(Math.atan2(a,o)/(Math.PI/4))*(Math.PI/4),r=Math.hypot(o,a);return[t[0]+Math.cos(i)*r,t[1]+Math.sin(i)*r]}function Q0(e,t,n){let o=["data-testid","data-test","data-cy","data-qa","aria-label","name"],a=b=>/^(css|sc|jsx|emotion|svelte)-|__[a-z0-9]{5,}$|[_-][a-f0-9]{6,}$|\d{3,}|[:[\]/()]/i.test(b),i=b=>{try{return t(b)===1}catch{return!1}},r=b=>{let u=b.tagName.toLowerCase(),d=[];b.id&&!a(b.id)&&d.push(`#${n(b.id)}`);for(let k of o){let E=b.getAttribute(k);E&&E.length<80&&d.push(`${u}[${k}="${E.replace(/"/g,'\\"')}"]`)}let x=Array.from(b.classList).filter(k=>!a(k)).slice(0,3).map(k=>`.${n(k)}`);return x.length&&d.push(u+x.join("")),d.push(u),d},l=b=>{let u=b.tagName.toLowerCase(),d=b.parentElement;if(!d)return u;let x=Array.from(d.children).filter(k=>k.tagName===b.tagName);return x.length>1?`${u}:nth-of-type(${x.indexOf(b)+1})`:u};for(let b of r(e))if(i(b))return b;let c=r(e).find(b=>b!==e.tagName.toLowerCase())??l(e);i(c)||(c=l(e));let s=e.parentElement;for(;s&&!i(c);){let b=r(s).find(u=>i(u));if(b)return c=`${b} > ${c}`,i(c)?c:`${b} > ${p(e,s,l)}`;c=`${l(s)} > ${c}`,s=s.parentElement}return c;function p(b,u,d){let x=[];for(let k=b;k&&k!==u;k=k.parentElement)x.unshift(d(k));return x.join(" > ")}}function Z0(e){let t=[];for(let n=e;n;n=n.parentElement){let o=n.tagName.toLowerCase(),a=n.parentElement,i=a?Array.from(a.children).filter(r=>r.tagName===n.tagName):[];t.unshift(i.length>1?`${o}[${i.indexOf(n)+1}]`:o)}return`/${t.join("/")}`}var tp=["page","selector","xpath","role","component","box","text","styles","attributes","html"];function al(e){return`${e.tag}${e.id?`#${e.id}`:""}${e.classes.slice(0,3).map(t=>`.${t}`).join("")}`}function a2(e){let t=e.file?` (${e.file}${e.line?`:${e.line}`:""})`:"";return`\`<${e.name}>\`${t} [${e.framework}]`}function np(e,t,n=tp){switch(t){case"selector":return e.map(o=>o.selector).join(`
`);case"html":return e.map(o=>o.html).join(`

`);case"json":{let o=a=>{let i={element:al(a)};return n.includes("page")&&(i.page={url:a.pageUrl,title:a.pageTitle,viewport:a.viewport,frameUrl:a.frameUrl}),n.includes("selector")&&(i.selector=a.selector),n.includes("xpath")&&(i.xpath=a.xpath),n.includes("role")&&(i.role=a.role?{role:a.role,name:a.name}:void 0),n.includes("component")&&(i.component=a.component),n.includes("box")&&(i.box=a.rect),n.includes("text")&&(i.text=a.text),n.includes("styles")&&(i.styles=a.styles),n.includes("attributes")&&(i.attributes=a.attributes),n.includes("html")&&(i.html=a.html),a.screenshot&&(i.screenshot=a.screenshot),i};return JSON.stringify(e.length===1?o(e[0]):e.map(o),null,2)}case"markdown":return e.map((o,a)=>{let i=[`### ${e.length>1?`${a+1}. `:""}Element: \`${al(o)}\``];if(n.includes("page")&&(i.push(`- Page: ${o.pageUrl} (${o.viewport.width}\xD7${o.viewport.height})`),o.frameUrl&&i.push(`- Frame: ${o.frameUrl}`)),n.includes("selector")&&i.push(`- Selector: \`${o.selector}\``),n.includes("xpath")&&i.push(`- XPath: \`${o.xpath}\``),n.includes("role")&&o.role&&i.push(`- Role/name: ${o.role}${o.name?` "${o.name}"`:""}`),n.includes("component")&&o.component&&i.push(`- Component: ${a2(o.component)}`),n.includes("box")){let r=o.rect;i.push(`- Box: ${Math.round(r.width)}\xD7${Math.round(r.height)} at (${Math.round(r.x)}, ${Math.round(r.y)})`)}if(n.includes("text")&&o.text&&i.push(`- Text: "${o.text}"`),n.includes("styles")){let r=Object.entries(o.styles).map(([l,c])=>`${l}:${c}`).join("; ");r&&i.push(`- Styles: ${r}`)}if(n.includes("attributes")){let r=Object.entries(o.attributes).filter(([l])=>l!=="class"&&l!=="id"&&l!=="style").map(([l,c])=>`${l}="${c}"`).join(" ");r&&i.push(`- Attributes: ${r}`)}return o.screenshot&&i.push(`- Screenshot: ${o.screenshot}`),n.includes("html")&&i.push("```html",o.html,"```"),i.join(`
`)}).join(`

`)}}var i2=["display","position","width","height","margin","padding","color","background-color","font-family","font-size","font-weight","line-height","border","border-radius","z-index","flex-direction","justify-content","align-items","gap","grid-template-columns","opacity","overflow"];function P0(e,t,n){let o=e.ownerDocument,a=o.defaultView||window,i=e.getRootNode(),r="querySelectorAll"in i?i:o,l=f=>a.CSS&&a.CSS.escape?a.CSS.escape(f):f,c=n.buildSelector(e,f=>r.querySelectorAll(f).length,l);if(r!==o&&"host"in r&&r.host){let f=r.host.getRootNode();c=n.buildSelector(r.host,h=>("querySelectorAll"in f?f:o).querySelectorAll(h).length,l)+" >>> "+c}let s=e.getBoundingClientRect(),p={};for(let f of Array.from(e.attributes||[]))p[f.name]=f.value.slice(0,300);let u=(e.innerText||e.textContent||"").replace(/\s+/g," ").trim().slice(0,200)||void 0,d=e.outerHTML||"";if(d.length>t){let f=e.cloneNode(!1);e.children.length?f.innerHTML="\u2026":f.textContent=(e.textContent||"").slice(0,80)+"\u2026",d=f.outerHTML.slice(0,t)}let x=a.getComputedStyle(e),k={};for(let f of n.styleProperties){let y=x.getPropertyValue(f);!y||/^(none|normal|auto|0px|static|visible|1|rgba\(0, 0, 0, 0\)|0px none .*)$/.test(y)||(k[f]=y.length>80?y.slice(0,80)+"\u2026":y)}let E=(()=>{try{let f=e,y=Object.keys(f).find(v=>v.startsWith("__reactFiber$")||v.startsWith("__reactInternalInstance$"));if(y)for(let v=f[y];v;v=v.return){let T=v.type;if(!T||typeof T=="string")continue;let z=T.displayName||T.name||T.render&&(T.render.displayName||T.render.name);if(!z)continue;let M=v._debugSource&&v._debugSource.fileName,B=v._debugSource&&v._debugSource.lineNumber,H=v._debugStack&&v._debugStack.stack;if(!M&&typeof H=="string"){let I=H.split(`
`).slice(1).find(D=>!/node_modules|react-dom|react-stack|jsx-dev-runtime|chunk-/.test(D))||"",ne=/\(?((?:https?|file|webpack[\w-]*):\/\/[^\s)]+?):(\d+):\d+\)?\s*$/.exec(I);ne&&(M=ne[1],B=Number(ne[2]))}return{framework:"react",name:z,file:M,line:B}}let h=f.__vueParentComponent;if(h){let v=h.type||{},T=v.__file;return{framework:"vue",name:v.name||v.__name||(T?String(T).split("/").pop().replace(/\.vue$/,""):"Anonymous"),file:T}}if(f.__vue__){let v=f.__vue__.$options||{};return{framework:"vue",name:v.name||v._componentTag||"Anonymous",file:v.__file}}for(let v=f;v;v=v.parentElement)if(v.__svelte_meta){let T=v.__svelte_meta.loc||{};return{framework:"svelte",name:T.file?String(T.file).split("/").pop().replace(/\.svelte$/,""):"Component",file:T.file,line:typeof T.line=="number"?T.line+1:void 0}}let S=a.ng;if(S&&S.getOwningComponent){let v=S.getComponent(e)||S.getOwningComponent(e);if(v)return{framework:"angular",name:v.constructor.name}}}catch{}})(),m=a.location.href,g=o.title;try{m=a.top.location.href,g=a.top.document.title}catch{}return{tag:e.tagName.toLowerCase(),id:e.id||void 0,classes:Array.from(e.classList||[]),selector:c,xpath:n.buildXPath(e),text:u,html:d,attributes:p,rect:{x:s.x,y:s.y,width:s.width,height:s.height},styles:k,component:E,pageUrl:m,pageTitle:g,viewport:{width:a.innerWidth,height:a.innerHeight},frameUrl:a!==a.top?a.location.href:void 0,scroll:{x:a.scrollX,y:a.scrollY}}}var $0={buildSelector:Q0,buildXPath:Z0,styleProperties:i2};var r2={a:"link",article:"article",aside:"complementary",button:"button",dialog:"dialog",footer:"contentinfo",form:"form",h1:"heading",h2:"heading",h3:"heading",h4:"heading",h5:"heading",h6:"heading",header:"banner",hr:"separator",img:"img",li:"listitem",main:"main",nav:"navigation",ol:"list",option:"option",progress:"progressbar",section:"region",select:"combobox",table:"table",textarea:"textbox",ul:"list"},l2={button:"button",checkbox:"checkbox",email:"textbox",image:"button",number:"spinbutton",radio:"radio",range:"slider",reset:"button",search:"searchbox",submit:"button",tel:"textbox",text:"textbox",url:"textbox"},c2=new Set(["button","link","heading","listitem","option","tab","menuitem","cell"]);function xs(e){let t=e.tagName.toLowerCase(),n=e.getAttribute("role")?.split(/\s+/)[0]||void 0;n||(t==="input"?n=l2[(e.getAttribute("type")||"text").toLowerCase()]:t==="a"?n=e.hasAttribute("href")?"link":void 0:t==="section"?n=e.hasAttribute("aria-label")?"region":void 0:n=r2[t]);let o=r=>(r||"").replace(/\s+/g," ").trim().slice(0,200)||void 0,a=e.getAttribute("aria-labelledby"),i;if(a&&(i=o(a.split(/\s+/).map(r=>e.ownerDocument.getElementById(r)?.textContent||"").join(" "))),i??=o(e.getAttribute("aria-label")),!i&&(t==="img"||t==="area")&&(i=o(e.getAttribute("alt"))),!i&&"labels"in e){let r=e.labels;r?.length&&(i=o(Array.from(r,l=>l.textContent).join(" ")))}if(!i&&t==="input"){let r=e;["button","submit","reset"].includes(r.type)&&(i=o(r.value)),i??=o(r.placeholder)}return!i&&n&&c2.has(n)&&(i=o(e.innerText||e.textContent)),i??=o(e.getAttribute("title")),{role:n||"generic",name:i}}function J0(e){let t=e.parentElement||(e.getRootNode().host??null);return t&&t.tagName!=="HTML"?t:null}function I0(e){return e.firstElementChild||e.shadowRoot?.firstElementChild||null}var il=(e,t,n,o,a,i)=>({id:e,name:t,group:"Phones",width:n,height:o,dpr:a,mobile:!0,touch:!0,userAgent:i}),op=(e,t,n,o,a,i)=>({id:e,name:t,group:"Tablets",width:n,height:o,dpr:a,mobile:!0,touch:!0,userAgent:i}),Hi=(e,t,n)=>({id:`desktop-${e}x${t}`,name:`${n} ${e}\xD7${t}`,group:"Desktops",width:e,height:t,dpr:1,mobile:!1,touch:!1,userAgent:"desktop"}),Bi=[il("iphone-se","iPhone SE",375,667,2,"iphone"),il("iphone-16-pro","iPhone 16 Pro",402,874,3,"iphone"),il("iphone-16-pro-max","iPhone 16 Pro Max",440,956,3,"iphone"),il("pixel-8","Pixel 8",412,915,2.625,"android"),il("galaxy-s24","Galaxy S24",360,780,3,"android"),op("ipad-mini","iPad Mini",768,1024,2,"ipad"),op("ipad-pro",'iPad Pro 12.9"',1024,1366,2,"ipad"),op("surface-pro","Surface Pro 7",912,1368,2,"desktop"),Hi(1280,800,"Laptop"),Hi(1366,768,"Laptop"),Hi(1440,900,"Laptop"),Hi(1920,1080,"Full HD"),Hi(2560,1440,"QHD"),Hi(3840,2160,"4K")],F0={none:{label:"No throttling",offline:!1,latency:0,download:-1,upload:-1},offline:{label:"Offline",offline:!0,latency:0,download:0,upload:0},slow3g:{label:"Slow 3G",offline:!1,latency:2e3,download:5e4,upload:5e4},fast3g:{label:"Fast 3G",offline:!1,latency:562.5,download:18e4,upload:84375},fast4g:{label:"Fast 4G",offline:!1,latency:165,download:1012500,upload:168750}},W0=[1,4,6];var ap=50,ip=7680;function ks(e){return{presetId:e.id,width:e.width,height:e.height,dpr:e.dpr,mobile:e.mobile,touch:e.touch,userAgent:e.userAgent}}function ey(e){return{...e,width:e.height,height:e.width}}function ty(e,t,n){return e!=="fit"?e:!n.width||!n.height?1:Math.min(1,n.width/t.width,n.height/t.height)}function ws(e){return!!e.error||e.status!==void 0&&e.status>=400}function ny(e){if(!e.url)return"";let t=e.line!==void 0?`:${e.line+1}`:"",n=e.line!==void 0&&e.column!==void 0?`:${e.column+1}`:"";return`${e.url}${t}${n}`}function oy(e,t,n=!1){let o=e.filter(i=>i.level==="error"||n&&i.level==="warning");if(!o.length)return`### Console errors: ${t}
No errors.`;let a=[`### Console errors: ${t} (${o.length})`];return o.forEach((i,r)=>{let[l,...c]=i.text.split(`
`);a.push(`${r+1}. ${i.level==="warning"?"[warning] ":""}${l}`);for(let p of c.slice(0,8))a.push(`   ${p.trim()}`);let s=ny(i);s&&!i.text.includes(s)&&a.push(`   at ${s}`)}),a.join(`
`)}function ay(e){let t=e.error?e.canceled?"canceled":e.error:`${e.status}${e.mimeType?` ${e.mimeType}`:""}`,n=e.duration!==void 0?`, ${Math.round(e.duration)} ms`:"";return`- ${e.method} ${e.url} \u2192 ${t} (${e.type}${n})`}function iy(e,t){let n=e.filter(ws);return n.length?[`### Failed network requests: ${t} (${n.length})`,...n.map(ay)].join(`
`):`### Failed network requests: ${t}
No failed requests.`}function ry(e){let t=["### Page context",`- URL: ${e.url}`,`- Title: ${e.title}`,`- Viewport: ${e.viewport.width}\xD7${e.viewport.height}${e.device?` (emulating ${e.device})`:""}`];e.selection&&t.push(`- Selected text: "${e.selection.slice(0,500)}"`);let n=e.console.filter(a=>a.level==="error").slice(-5);if(n.length){t.push("",`Recent console errors (${n.length}):`);for(let a of n){let i=ny(a);t.push(`- ${a.text.split(`
`)[0]}${i?` (${i})`:""}`)}}let o=e.network.filter(ws).slice(-5);return o.length&&t.push("",`Failed requests (${o.length}):`,...o.map(ay)),t.join(`
`)}var{PI:s2}=Math,rl=s2+1e-4,ly=.5,cy=[1,1];function sy(e,t,n,o=a=>a){return e*o(.5-t*(.5-n))}var{min:rp}=Math;function vy(e,t,n){let o=rp(1,t/n);return rp(1,e+(rp(1,1-o)-e)*(o*.275))}function u2(e){return[-e[0],-e[1]]}function Rn(e,t){return[e[0]+t[0],e[1]+t[1]]}function uy(e,t,n){return e[0]=t[0]+n[0],e[1]=t[1]+n[1],e}function qo(e,t){return[e[0]-t[0],e[1]-t[1]]}function sp(e,t,n){return e[0]=t[0]-n[0],e[1]=t[1]-n[1],e}function jo(e,t){return[e[0]*t,e[1]*t]}function lp(e,t,n){return e[0]=t[0]*n,e[1]=t[1]*n,e}function d2(e,t){return[e[0]/t,e[1]/t]}function yy(e){return[e[1],-e[0]]}function cp(e,t){let n=t[0];return e[0]=t[1],e[1]=-n,e}function dy(e,t){return e[0]*t[0]+e[1]*t[1]}function f2(e,t){return e[0]===t[0]&&e[1]===t[1]}function p2(e){return Math.hypot(e[0],e[1])}function fy(e,t){let n=e[0]-t[0],o=e[1]-t[1];return n*n+o*o}function xy(e){return d2(e,p2(e))}function m2(e,t){return Math.hypot(e[1]-t[1],e[0]-t[0])}function up(e,t,n){let o=Math.sin(n),a=Math.cos(n),i=e[0]-t[0],r=e[1]-t[1],l=i*a-r*o,c=i*o+r*a;return[l+t[0],c+t[1]]}function py(e,t,n,o){let a=Math.sin(o),i=Math.cos(o),r=t[0]-n[0],l=t[1]-n[1],c=r*i-l*a,s=r*a+l*i;return e[0]=c+n[0],e[1]=s+n[1],e}function my(e,t,n){return Rn(e,jo(qo(t,e),n))}function g2(e,t,n,o){let a=n[0]-t[0],i=n[1]-t[1];return e[0]=t[0]+a*o,e[1]=t[1]+i*o,e}function ky(e,t,n){return Rn(e,jo(t,n))}var ot=[0,0],Lo=[0,0],Uo=[0,0];function b2(e,t){let n=ky(e,xy(yy(qo(e,Rn(e,[1,1])))),-t),o=[],a=1/13;for(let i=a;i<=1;i+=a)o.push(up(n,e,rl*2*i));return o}function h2(e,t,n){let o=[],a=1/n;for(let i=a;i<=1;i+=a)o.push(up(t,e,rl*i));return o}function v2(e,t,n){let o=qo(t,n),a=jo(o,.5),i=jo(o,.51);return[qo(e,a),qo(e,i),Rn(e,i),Rn(e,a)]}function y2(e,t,n,o){let a=[],i=ky(e,t,n),r=1/o;for(let l=r;l<1;l+=r)a.push(up(i,e,rl*3*l));return a}function x2(e,t,n){return[Rn(e,jo(t,n)),Rn(e,jo(t,n*.99)),qo(e,jo(t,n*.99)),qo(e,jo(t,n))]}function gy(e,t,n){return e===!1||e===void 0?0:e===!0?Math.max(t,n):e}function k2(e,t,n){return e.slice(0,10).reduce((o,a)=>{let i=a.pressure;return t&&(i=vy(o,a.distance,n)),(o+i)/2},e[0].pressure)}function w2(e,t={}){let{size:n=16,smoothing:o=.5,thinning:a=.5,simulatePressure:i=!0,easing:r=A=>A,start:l={},end:c={},last:s=!1}=t,{cap:p=!0,easing:b=A=>A*(2-A)}=l,{cap:u=!0,easing:d=A=>--A*A*A+1}=c;if(e.length===0||n<=0)return[];let x=e[e.length-1].runningLength,k=gy(l.taper,n,x),E=gy(c.taper,n,x),m=(n*o)**2,g=[],f=[],y=k2(e,i,n),h=sy(n,a,e[e.length-1].pressure,r),S,v=e[0].vector,T=e[0].point,z=T,M=T,B=z,H=!1;for(let A=0;A<e.length;A++){let{pressure:G}=e[A],{point:ae,vector:ge,distance:Mt,runningLength:ht}=e[A],on=A===e.length-1;if(!on&&x-ht<3)continue;a?(i&&(G=vy(y,Mt,n)),h=sy(n,a,G,r)):h=n/2,S===void 0&&(S=h);let Zi=ht<k?b(ht/k):1,Us=x-ht<E?d((x-ht)/E):1;h=Math.max(.01,h*Math.min(Zi,Us));let Oa=(on?e[A]:e[A+1]).vector,Kt=on?1:dy(ge,Oa),gl=dy(ge,v)<0&&!H,Ko=Kt!==null&&Kt<0;if(gl||Ko){cp(ot,v),lp(ot,ot,h);for(let Ra=0;Ra<=1;Ra+=.07692307692307693)sp(Lo,ae,ot),py(Lo,Lo,ae,rl*Ra),M=[Lo[0],Lo[1]],g.push(M),uy(Uo,ae,ot),py(Uo,Uo,ae,rl*-Ra),B=[Uo[0],Uo[1]],f.push(B);T=M,z=B,Ko&&(H=!0);continue}if(H=!1,on){cp(ot,ge),lp(ot,ot,h),g.push(qo(ae,ot)),f.push(Rn(ae,ot));continue}g2(ot,Oa,ge,Kt),cp(ot,ot),lp(ot,ot,h),sp(Lo,ae,ot),M=[Lo[0],Lo[1]],(A<=1||fy(T,M)>m)&&(g.push(M),T=M),uy(Uo,ae,ot),B=[Uo[0],Uo[1]],(A<=1||fy(z,B)>m)&&(f.push(B),z=B),y=G,v=ge}let I=[e[0].point[0],e[0].point[1]],ne=e.length>1?[e[e.length-1].point[0],e[e.length-1].point[1]]:Rn(e[0].point,[1,1]),D=[],U=[];if(e.length===1){if(!(k||E)||s)return b2(I,S||h)}else{k||E&&e.length===1||(p?D.push(...h2(I,f[0],13)):D.push(...v2(I,g[0],f[0])));let A=yy(u2(e[e.length-1].vector));E||k&&e.length===1?U.push(ne):u?U.push(...y2(ne,A,h,29)):U.push(...x2(ne,A,h))}return g.concat(U,f.reverse(),D)}var by=[0,0];function hy(e){return e!=null&&e>=0}function S2(e,t={}){let{streamline:n=.5,size:o=16,last:a=!1}=t;if(e.length===0)return[];let i=.15+(1-n)*.85,r=Array.isArray(e[0])?e:e.map(({x:u,y:d,pressure:x=ly})=>[u,d,x]);if(r.length===2){let u=r[1];r=r.slice(0,-1);for(let d=1;d<5;d++)r.push(my(r[0],u,d/4))}r.length===1&&(r=[...r,[...Rn(r[0],cy),...r[0].slice(2)]]);let l=[{point:[r[0][0],r[0][1]],pressure:hy(r[0][2])?r[0][2]:.25,vector:[...cy],distance:0,runningLength:0}],c=!1,s=0,p=l[0],b=r.length-1;for(let u=1;u<r.length;u++){let d=a&&u===b?[r[u][0],r[u][1]]:my(p.point,r[u],i);if(f2(p.point,d))continue;let x=m2(d,p.point);if(s+=x,u<b&&!c){if(s<o)continue;c=!0}sp(by,p.point,d),p={point:d,pressure:hy(r[u][2])?r[u][2]:ly,vector:xy(by),distance:x,runningLength:s},l.push(p)}return l[0].vector=l[1]?.vector||[0,0],l}function wy(e,t={}){return w2(S2(e,t),t)}var E2={pen:{size:1.4,thinning:.5},pencil:{size:.7,thinning:.25},marker:{size:2.5,thinning:0},brush:{size:2.2,thinning:.75,taper:!0},highlighter:{size:4,thinning:0,opacity:.35},neon:{size:1.4,thinning:.3}};function Ss(e,t,n,o={}){let a=([i,r])=>[(i-n.offsetX)*n.scale,(r-n.offsetY)*n.scale];for(let i of t)i.kind==="blur"&&!o.skipRedactions&&N2(e,i,a,o.pixelSource);for(let i of t)if(i.kind!=="blur"){switch(e.save(),T2(e,i.style,n.scale),i.kind){case"stroke":C2(e,i.tool,i.points,i.style,n.scale,a);break;case"line":case"arrow":case"doubleArrow":{let[r,l]=[a(i.start),a(i.end)];e.beginPath(),e.moveTo(r[0],r[1]),e.lineTo(l[0],l[1]),e.stroke(),e.setLineDash([]);let c=Wf(i.style)*n.scale;i.kind!=="line"&&Sy(e,r,l,c),i.kind==="doubleArrow"&&Sy(e,l,r,c);break}case"rect":{let[r,l]=[a(i.start),a(i.end)],[c,s,p,b]=[Math.min(r[0],l[0]),Math.min(r[1],l[1]),Math.abs(l[0]-r[0]),Math.abs(l[1]-r[1])];i.style.fill&&Ey(e,()=>e.fillRect(c,s,p,b)),e.strokeRect(c,s,p,b);break}case"ellipse":{let[r,l]=[a(i.start),a(i.end)];e.beginPath(),e.ellipse((r[0]+l[0])/2,(r[1]+l[1])/2,Math.abs(l[0]-r[0])/2,Math.abs(l[1]-r[1])/2,0,0,Math.PI*2),i.style.fill&&Ey(e,()=>e.fill()),e.stroke();break}case"text":{let r=If(i.style)*n.scale,[l,c]=a(i.at);e.font=`600 ${r}px system-ui, sans-serif`,e.textBaseline="top",e.setLineDash([]),e.lineWidth=Math.max(2,r/6),e.strokeStyle=Ty(i.style.color)?"rgba(0,0,0,0.75)":"rgba(255,255,255,0.85)",i.text.split(`
`).forEach((s,p)=>{e.strokeText(s,l,c+p*r*1.25),e.fillText(s,l,c+p*r*1.25)});break}case"callout":{let r=Ff(i.style)*n.scale,[l,c]=a(i.at);e.setLineDash([]),e.beginPath(),e.arc(l,c,r,0,Math.PI*2),e.fill(),e.lineWidth=Math.max(1.5,r/8),e.strokeStyle="rgba(255,255,255,0.9)",e.stroke(),e.fillStyle=Ty(i.style.color)?"#000":"#fff",e.font=`700 ${r*1.1}px system-ui, sans-serif`,e.textAlign="center",e.textBaseline="middle",e.fillText(String(i.number),l,c+r*.05);break}}e.restore(),i.id===o.selectedId&&M2(e,i,n)}}function T2(e,t,n){e.globalAlpha=t.opacity,e.strokeStyle=t.color,e.fillStyle=t.color,e.lineWidth=t.width*n,e.lineCap="round",e.lineJoin="round";let o=t.width*n;e.setLineDash(t.dash==="dashed"?[o*3,o*2]:t.dash==="dotted"?[.1,o*2]:[])}function C2(e,t,n,o,a,i){let r=E2[t];r.opacity!==void 0&&(e.globalAlpha=o.opacity*r.opacity,e.globalCompositeOperation="multiply"),t==="neon"&&(e.shadowColor=o.color,e.shadowBlur=12*a);let l=n.map(s=>[...i(s),s[2]]);if(o.dash!=="solid"||l.length<2){e.lineWidth=o.width*a*r.size,e.beginPath(),l.forEach(([s,p],b)=>b?e.lineTo(s,p):e.moveTo(s,p)),l.length===1&&e.lineTo(l[0][0]+.1,l[0][1]),e.stroke();return}let c=wy(l,{size:o.width*a*r.size,thinning:r.thinning,smoothing:.5,streamline:.4,simulatePressure:l.every(([,,s])=>s===.5),start:{taper:r.taper?o.width*a*6:0,cap:!0},end:{taper:r.taper?o.width*a*6:0,cap:!0}});if(c.length){e.beginPath(),e.moveTo(c[0][0],c[0][1]);for(let s=1;s<c.length;s++){let[p,b]=c[s-1],[u,d]=c[s];e.quadraticCurveTo(p,b,(p+u)/2,(b+d)/2)}e.closePath(),e.fill(),t==="neon"&&(e.shadowBlur=0,e.globalAlpha=.8,e.lineWidth=Math.max(1,o.width*a*.3),e.strokeStyle="rgba(255,255,255,0.8)",e.beginPath(),l.forEach(([s,p],b)=>b?e.lineTo(s,p):e.moveTo(s,p)),e.stroke())}}function Sy(e,t,n,o){let a=Math.atan2(n[1]-t[1],n[0]-t[0]);e.beginPath(),e.moveTo(n[0],n[1]),e.lineTo(n[0]-o*Math.cos(a-Math.PI/7),n[1]-o*Math.sin(a-Math.PI/7)),e.lineTo(n[0]-o*Math.cos(a+Math.PI/7),n[1]-o*Math.sin(a+Math.PI/7)),e.closePath(),e.fill()}function Ey(e,t){let n=e.globalAlpha;e.globalAlpha=n*.25,t(),e.globalAlpha=n}function N2(e,t,n,o){let[a,i]=[n(t.start),n(t.end)],r=Math.round(Math.min(a[0],i[0])),l=Math.round(Math.min(a[1],i[1])),c=Math.round(Math.abs(i[0]-a[0])),s=Math.round(Math.abs(i[1]-a[1]));if(!(c<2||s<2)){if(e.save(),o){let p=Math.max(10,Math.round(Math.min(c,s)/5)),b=new OffscreenCanvas(Math.max(1,Math.ceil(c/p)),Math.max(1,Math.ceil(s/p)));b.getContext("2d").drawImage(o,r,l,c,s,0,0,b.width,b.height),e.imageSmoothingEnabled=!1,e.drawImage(b,0,0,b.width,b.height,r,l,c,s)}else e.fillStyle="rgba(128,128,128,0.9)",e.fillRect(r,l,c,s);e.restore()}}function M2(e,t,n){let o=ol(t);e.save(),e.setLineDash([4,4]),e.lineWidth=1,e.strokeStyle="#0a84ff",e.strokeRect((o.x-n.offsetX)*n.scale-3,(o.y-n.offsetY)*n.scale-3,o.width*n.scale+6,o.height*n.scale+6),e.restore()}function Ty(e){let t=e.replace("#","");if(t.length!==6)return!1;let[n,o,a]=[0,2,4].map(i=>parseInt(t.slice(i,i+2),16));return n*.299+o*.587+a*.114>170}async function Cy(e,t,n,o){let a=await createImageBitmap(new Blob([e],{type:t})),i=new OffscreenCanvas(a.width,a.height),r=i.getContext("2d");r.drawImage(a,0,0),a.close(),o.length&&Ss(r,o,{scale:i.width/n.width,offsetX:n.x,offsetY:n.y},{pixelSource:i});let l=await i.convertToBlob({type:"image/png"});return A2(new Uint8Array(await l.arrayBuffer()))}function A2(e){let t="";for(let n=0;n<e.length;n+=32768)t+=String.fromCharCode(...e.subarray(n,n+32768));return btoa(t)}var Yt=R(Ae(),1);var Li=R(j(),1),z2=1,Es=()=>`s${Date.now().toString(36)}${(z2++).toString(36)}`;function Ny({mapper:e,shapes:t,visible:n,interactive:o,tool:a,style:i,onChange:r,liveRedactions:l,pixelSource:c}){let s=l&&!c,p=(0,Yt.useRef)(null),[b,u]=(0,Yt.useState)(null),d=(0,Yt.useRef)(null),x=D=>{d.current=D,u(D)},[k,E]=(0,Yt.useState)(),[m,g]=(0,Yt.useState)(null),f=(0,Yt.useRef)(null),y=(0,Yt.useRef)(!1),{bounds:h,scale:S,scroll:v}=e;(0,Yt.useLayoutEffect)(()=>{let D=p.current;if(!D)return;let U=window.devicePixelRatio||1,A=Math.round(h.width*U),G=Math.round(h.height*U);(D.width!==A||D.height!==G)&&(D.width=A,D.height=G);let ae=D.getContext("2d");if(ae.clearRect(0,0,A,G),!n)return;let ge=D.closest(".viewport")?.querySelector(".viewport-canvas");Ss(ae,b?[...t,b]:t,{scale:S*U,offsetX:v.x,offsetY:v.y},{pixelSource:c??ge??void 0,skipRedactions:s,selectedId:o?k:void 0})},[s,c,t,b,n,o,k,h.width,h.height,S,v.x,v.y]),(0,Yt.useEffect)(()=>{if(!k)return;let D=U=>{(U.key==="Delete"||U.key==="Backspace")&&!O2(U)&&(U.preventDefault(),U.stopPropagation(),r(t.filter(A=>A.id!==k),!0),E(void 0))};return window.addEventListener("keydown",D,!0),()=>window.removeEventListener("keydown",D,!0)},[k,t,r]);let T=D=>{let U=D.currentTarget.getBoundingClientRect();return[(D.clientX-U.left)/S+v.x,(D.clientY-U.top)/S+v.y]},z=D=>{let U=t.filter(A=>!ep(A,D,6/S));U.length!==t.length&&r(U,!1)},M=()=>{m?.value.trim()&&r([...t,{id:Es(),kind:"text",at:m.at,text:m.value,style:i}],!0),g(null)},B=D=>{if(D.button!==0||!n)return;D.preventDefault();let U=T(D);if(m&&M(),a==="text"){let G=D.currentTarget.getBoundingClientRect();g({at:U,local:[D.clientX-G.left,D.clientY-G.top],value:""});return}if(a==="callout"){let G=Math.max(0,...t.map(ae=>ae.kind==="callout"?ae.number:0))+1;r([...t,{id:Es(),kind:"callout",at:U,number:G,style:i}],!0);return}if(D.currentTarget.setPointerCapture(D.pointerId),a==="eraser"){y.current=!0,r(t,!0),z(U);return}if(a==="select"){let G=[...t].reverse().find(ae=>ep(ae,U,6/S));E(G?.id),G&&(f.current={start:U,original:G},r(t,!0));return}let A=D.pressure||.5;j0.includes(a)?x({id:Es(),kind:"stroke",tool:a,points:[[...U,A]],style:i}):q0.includes(a)&&x({id:Es(),kind:a,start:U,end:U,style:i})},H=D=>{let U=T(D);if(y.current){z(U);return}if(f.current){let{start:G,original:ae}=f.current,ge=X0(ae,U[0]-G[0],U[1]-G[1]);r(t.map(Mt=>Mt.id===ae.id?ge:Mt),!1);return}let A=d.current;A&&(A.kind==="stroke"?x({...A,points:[...A.points,[...U,D.pressure||.5]]}):A.kind!=="text"&&A.kind!=="callout"&&x({...A,end:D.shiftKey?G0(A.kind,A.start,U):U}))},I=()=>{y.current=!1,f.current=null;let D=d.current;if(!D)return;D.kind!=="stroke"&&D.kind!=="text"&&D.kind!=="callout"&&Math.hypot(D.end[0]-D.start[0],D.end[1]-D.start[1])*S<3||r([...t,D],!0),x(null)},ne=a==="select"?"default":a==="text"?"text":a==="eraser"?"cell":"crosshair";return(0,Li.jsxs)("div",{className:"drawing-layer",style:{...h,pointerEvents:n&&o?"auto":"none"},children:[s&&n&&(b?[...t,b]:t).map(D=>{if(D.kind!=="blur")return null;let[U,A]=[D.start,D.end];return(0,Li.jsx)("div",{className:"drawing-redaction",style:{left:(Math.min(U[0],A[0])-v.x)*S,top:(Math.min(U[1],A[1])-v.y)*S,width:Math.abs(A[0]-U[0])*S,height:Math.abs(A[1]-U[1])*S}},D.id)}),(0,Li.jsx)("canvas",{ref:p,style:{width:h.width,height:h.height,cursor:ne},onPointerDown:B,onPointerMove:H,onPointerUp:I,onContextMenu:D=>D.preventDefault()}),m&&(0,Li.jsx)("textarea",{className:"drawing-text-input",autoFocus:!0,value:m.value,placeholder:"Type, then Enter",style:{left:m.local[0],top:m.local[1],color:i.color,fontSize:(12+i.width*2)*S},onChange:D=>g({...m,value:D.target.value}),onBlur:M,onKeyDown:D=>{D.stopPropagation(),D.key==="Enter"&&!D.shiftKey?(D.preventDefault(),M()):D.key==="Escape"&&g(null)}})]})}function O2(e){let t=e.target;return!!t&&(t.tagName==="INPUT"||t.tagName==="TEXTAREA"||t.isContentEditable)}var Ui=R(j(),1);function je({variant:e="secondary",size:t="md",icon:n,iconEnd:o,loading:a,className:i,children:r,disabled:l,type:c="button",...s}){let p=a?"loading":n;return(0,Ui.jsxs)("button",{type:c,className:oe("button",e,t==="sm"&&"small",i),disabled:l||a,"aria-busy":a||void 0,...s,children:[p&&(0,Ui.jsx)("span",{className:oe("codicon",`codicon-${p}`,a&&"codicon-modifier-spin"),"aria-hidden":"true"}),r!==void 0&&(0,Ui.jsx)("span",{className:"button-label",children:r}),o&&(0,Ui.jsx)("span",{className:`codicon codicon-${o}`,"aria-hidden":"true"})]})}var Dn=R(Ae(),1),Dy=R(Tl(),1);function Sa(e){let t=e.trim().toLowerCase(),n=/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/.exec(t);if(n){let a=n[4]===void 0?1:n[4].endsWith("%")?parseFloat(n[4])/100:Number(n[4]);return{r:Number(n[1]),g:Number(n[2]),b:Number(n[3]),a}}let o=/^#([\da-f]{3}|[\da-f]{6})$/.exec(t);if(o){let a=o[1].length===3?[...o[1]].map(i=>i+i).join(""):o[1];return{r:parseInt(a.slice(0,2),16),g:parseInt(a.slice(2,4),16),b:parseInt(a.slice(4,6),16),a:1}}if(t==="transparent")return{r:0,g:0,b:0,a:0}}function ji({r:e,g:t,b:n,a:o}){let a=i=>Math.round(i).toString(16).padStart(2,"0").toUpperCase();return`#${a(e)}${a(t)}${a(n)}${o<1?a(o*255):""}`}function R2(e,t){let n=e.a+t.a*(1-e.a);if(n===0)return{r:0,g:0,b:0,a:0};let o=(a,i)=>(a*e.a+i*t.a*(1-e.a))/n;return{r:o(e.r,t.r),g:o(e.g,t.g),b:o(e.b,t.b),a:n}}function My({r:e,g:t,b:n}){let o=a=>{let i=a/255;return i<=.03928?i/12.92:((i+.055)/1.055)**2.4};return .2126*o(e)+.7152*o(t)+.0722*o(n)}function Ay(e,t){let n=My(R2(e,t)),o=My(t),[a,i]=n>o?[n,o]:[o,n];return(a+.05)/(i+.05)}function zy(e,t,n){let o=t>=24||t>=18.66&&n>=700;return e>=(o?3:4.5)}function Oy({r:e,g:t,b:n}){let[o,a,i]=[e/255,t/255,n/255],r=Math.max(o,a,i),l=r-Math.min(o,a,i),c=0;return l&&(r===o?c=(a-i)/l%6:r===a?c=(i-o)/l+2:c=(o-a)/l+4),{h:(c*60+360)%360,s:r?l/r:0,v:r}}function Ry({h:e,s:t,v:n}){let o=a=>{let i=(a+e/60)%6;return(n-n*t*Math.max(0,Math.min(i,4-i,1)))*255};return{r:o(5),g:o(3),b:o(1),a:1}}function dp(e){let t=e.trim().replace(/^#?/,"#"),n=Sa(t);return n?ji(n).toLowerCase():void 0}var ut=R(j(),1),D2=e=>ji(Ry(e)).toLowerCase(),ll=e=>Oy(Sa(e)??{r:0,g:0,b:0,a:1});function _y({value:e,onChange:t,label:n,presets:o=[],className:a}){let[i,r]=(0,Dn.useState)(!1),[l,c]=(0,Dn.useState)(null),[s,p]=(0,Dn.useState)(()=>ll(e)),[b,u]=(0,Dn.useState)(null),d=(0,Dn.useRef)(null),x=(0,Dn.useRef)(null),k=(0,Dn.useCallback)(h=>{r(!1),h==="escape"&&d.current?.focus()},[]);ds([d,x],i,k),cs(d,x,i);let E=h=>{p(h),u(null),t(D2(h))},m=(h,S,v,T)=>{let z=h.getBoundingClientRect(),M=Math.min(1,Math.max(0,(S-z.left)/z.width)),B=Math.min(1,Math.max(0,(v-z.top)/z.height));E(T==="area"?{...s,s:M,v:1-B}:{...s,h:M*359.9})},g=h=>({onPointerDown:S=>{S.currentTarget.setPointerCapture(S.pointerId),S.currentTarget.focus(),m(S.currentTarget,S.clientX,S.clientY,h)},onPointerMove:S=>{S.currentTarget.hasPointerCapture(S.pointerId)&&m(S.currentTarget,S.clientX,S.clientY,h)}}),f=h=>S=>{let v=S.shiftKey?.1:.01,T={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,1],ArrowDown:[0,-1]}[S.key];if(!T)return;S.preventDefault();let z=M=>Math.min(1,Math.max(0,M));E(h==="area"?{...s,s:z(s.s+T[0]*v),v:z(s.v+T[1]*v)}:{...s,h:Math.min(359.9,Math.max(0,s.h+(T[0]||T[1])*v*360))})},y=`hsl(${s.h} 100% 50%)`;return(0,ut.jsxs)(ut.Fragment,{children:[(0,ut.jsx)("button",{ref:d,type:"button",className:oe("swatch","color-picker-trigger",i&&"active",a),"aria-label":n,title:n,"aria-haspopup":"dialog","aria-expanded":i,onClick:()=>{if(i)return k();p(ll(e)),u(null),c(fs(d.current)),r(!0)}}),i&&l&&(0,Dy.createPortal)((0,ut.jsxs)("div",{ref:x,className:"color-picker","data-ink-popup":"",role:"dialog","aria-label":n,children:[(0,ut.jsx)("div",{className:"color-area",style:{background:y},role:"slider",tabIndex:0,"aria-label":"Saturation and brightness","aria-valuetext":`Saturation ${Math.round(s.s*100)}%, brightness ${Math.round(s.v*100)}%`,onKeyDown:f("area"),...g("area"),children:(0,ut.jsx)("span",{className:"color-handle",style:{left:`${s.s*100}%`,top:`${(1-s.v)*100}%`,background:e}})}),(0,ut.jsx)("div",{className:"color-hue",role:"slider",tabIndex:0,"aria-label":"Hue","aria-valuemin":0,"aria-valuemax":360,"aria-valuenow":Math.round(s.h),onKeyDown:f("hue"),...g("hue"),children:(0,ut.jsx)("span",{className:"color-handle",style:{left:`${s.h/360*100}%`,background:y}})}),(0,ut.jsxs)("div",{className:"color-row",children:[(0,ut.jsx)("span",{className:"color-preview",style:{background:e},"aria-hidden":"true"}),(0,ut.jsx)("input",{className:"color-hex","aria-label":"Hex color",spellCheck:!1,maxLength:7,value:b??e,onChange:h=>{u(h.target.value);let S=dp(h.target.value);S&&h.target.value.replace("#","").length===6&&(p(ll(S)),t(S))},onBlur:()=>u(null),onKeyDown:h=>{if(h.key!=="Enter")return;let S=dp(h.currentTarget.value);S&&(p(ll(S)),t(S),k("escape"))}})]}),o.length>0&&(0,ut.jsx)("div",{className:"color-presets",role:"group","aria-label":"Presets",children:o.map(h=>(0,ut.jsx)("button",{type:"button",className:oe("swatch","small",h===e&&"active"),style:{background:h},"aria-label":h,title:h,onClick:()=>{p(ll(h)),t(h)}},h))})]}),l)]})}var Ct=R(Ae(),1),Hy=R(Tl(),1);var at=R(j(),1);function _n({value:e,options:t,onChange:n,label:o,title:a,placeholder:i="Select\u2026",icon:r,renderValue:l,size:c="md",appearance:s="field",disabled:p,className:b,align:u="start"}){let[d,x]=(0,Ct.useState)(!1),[k,E]=(0,Ct.useState)(-1),[m,g]=(0,Ct.useState)(null),f=(0,Ct.useRef)(null),y=(0,Ct.useRef)(null),h=(0,Ct.useRef)({text:"",at:0}),S=(0,Ct.useId)(),v=t.findIndex(A=>A.value===e),T=t[v],z=(0,Ct.useCallback)(A=>{x(!1),(A==="escape"||A==="chosen")&&f.current?.focus()},[]);ds([f,y],d,z),cs(f,y,d,{align:u,matchWidth:!0});let M=A=>A>=0&&!t[A]?.disabled,B=(A,G)=>{for(let ae=1;ae<=t.length;ae++){let ge=(A+G*ae+t.length*2)%t.length;if(M(ge))return ge}return A},H=(A=v)=>{E(M(A)?A:B(-1,1)),g(fs(f.current)),x(!0)},I=A=>{let G=t[A];!G||G.disabled||(z("chosen"),G.value!==e&&n(G.value))};(0,Ct.useLayoutEffect)(()=>{d&&(y.current?.querySelector(`[data-index="${k}"]`)?.scrollIntoView({block:"nearest"}),y.current?.focus({preventScroll:!0}))},[d,k]);let ne=A=>{let G=Date.now(),ae=(G-h.current.at<700?h.current.text:"")+A.toLowerCase();h.current={text:ae,at:G};let ge=d?k:v,ht=[...t.keys()].map(on=>(ge+(ae.length>1?0:1)+on)%t.length).find(on=>M(on)&&t[on].label.toLowerCase().startsWith(ae));ht!==void 0&&(d?E(ht):t[ht].value!==e&&n(t[ht].value))},D=A=>{["ArrowDown","ArrowUp","Enter"," "].includes(A.key)?(A.preventDefault(),H()):A.key.length===1&&!A.ctrlKey&&!A.metaKey&&!A.altKey&&ne(A.key)},U=A=>{let ae={ArrowDown:()=>E(ge=>B(ge,1)),ArrowUp:()=>E(ge=>B(ge,-1)),Home:()=>E(B(-1,1)),End:()=>E(B(t.length,-1)),PageDown:()=>E(ge=>Math.min(B(ge,1)+7,B(t.length,-1))),PageUp:()=>E(ge=>Math.max(B(ge,-1)-7,B(-1,1))),Enter:()=>I(k)," ":()=>h.current.text&&Date.now()-h.current.at<700?ne(" "):I(k),Tab:()=>z()}[A.key];ae?(A.key!=="Tab"&&A.preventDefault(),ae()):A.key.length===1&&!A.ctrlKey&&!A.metaKey&&!A.altKey&&ne(A.key)};return(0,at.jsxs)(at.Fragment,{children:[(0,at.jsxs)("button",{ref:f,type:"button",className:oe("select",`size-${c}`,s==="quiet"&&"quiet",d&&"open",b),role:"combobox","aria-haspopup":"listbox","aria-expanded":d,"aria-controls":d?`${S}-list`:void 0,"aria-label":o,title:a??o,disabled:p,onClick:()=>d?z():H(),onKeyDown:D,children:[r&&(0,at.jsx)("span",{className:`codicon codicon-${r}`,"aria-hidden":"true"}),!r&&T?.icon&&(0,at.jsx)("span",{className:`codicon codicon-${T.icon}`,"aria-hidden":"true"}),(0,at.jsx)("span",{className:oe("select-value",!T&&"placeholder"),children:T?l?l(T):T.label:i}),(0,at.jsx)("span",{className:"codicon codicon-chevron-down select-chevron","aria-hidden":"true"})]}),d&&m&&(0,Hy.createPortal)((0,at.jsx)("div",{ref:y,id:`${S}-list`,className:"select-list","data-ink-popup":"",role:"listbox","aria-label":o,tabIndex:-1,"aria-activedescendant":k>=0?`${S}-${k}`:void 0,onKeyDown:U,children:t.map((A,G)=>[A.group&&A.group!==t[G-1]?.group?(0,at.jsx)("div",{className:"select-group",role:"presentation",children:A.group},`g-${A.group}`):null,(0,at.jsxs)("div",{id:`${S}-${G}`,"data-index":G,role:"option","aria-selected":G===v,"aria-disabled":A.disabled||void 0,className:oe("select-option",G===k&&"active",G===v&&"selected",A.disabled&&"disabled"),style:A.indent?{paddingLeft:4+A.indent*14}:void 0,onPointerMove:()=>!A.disabled&&E(G),onClick:()=>I(G),children:[(0,at.jsx)("span",{className:`codicon codicon-${G===v?"check":"blank"} select-check`,"aria-hidden":"true"}),A.icon&&(0,at.jsx)("span",{className:`codicon codicon-${A.icon}`,"aria-hidden":"true"}),(0,at.jsx)("span",{className:"select-option-label",children:A.label}),A.detail&&(0,at.jsx)("span",{className:"select-option-detail",children:A.detail})]},A.value)])}),m)]})}var By=R(Ae(),1);var Yo=R(j(),1);function fp({value:e,min:t,max:n,step:o=1,onChange:a,label:i,format:r=String,icon:l,showValue:c,className:s,disabled:p}){let b=(0,By.useRef)(null),u=m=>Math.min(n,Math.max(t,Math.round(m/o)*o)),d=m=>{let g=u(m);g!==e&&a(g)},x=m=>{let g=b.current?.getBoundingClientRect();g?.width&&d(t+(m-g.left)/g.width*(n-t))},k=n>t?(e-t)/(n-t):0,E=m=>{let g=Math.max(o,(n-t)/10),f={ArrowRight:e+o,ArrowUp:e+o,ArrowLeft:e-o,ArrowDown:e-o,PageUp:e+g,PageDown:e-g,Home:t,End:n};m.key in f&&(m.preventDefault(),d(f[m.key]))};return(0,Yo.jsxs)("div",{className:oe("slider",p&&"disabled",s),title:`${i}: ${r(e)}`,children:[l&&(0,Yo.jsx)("span",{className:`codicon codicon-${l}`,"aria-hidden":"true"}),(0,Yo.jsxs)("div",{ref:b,className:"slider-track",role:"slider",tabIndex:p?-1:0,"aria-label":i,"aria-valuemin":t,"aria-valuemax":n,"aria-valuenow":e,"aria-valuetext":r(e),"aria-disabled":p||void 0,onKeyDown:p?void 0:E,onPointerDown:m=>{p||m.button!==0||(m.currentTarget.setPointerCapture(m.pointerId),m.currentTarget.focus(),x(m.clientX))},onPointerMove:m=>{m.currentTarget.hasPointerCapture(m.pointerId)&&x(m.clientX)},children:[(0,Yo.jsx)("span",{className:"slider-fill",style:{width:`${k*100}%`}}),(0,Yo.jsx)("span",{className:"slider-thumb",style:{left:`${k*100}%`}})]}),c&&(0,Yo.jsx)("span",{className:"slider-value",children:r(e)})]})}var pp=R(j(),1),_2={select:"M3 2l9 5-4 1-2 4z",pen:"M11 2l3 3-8 8H3v-3zM9.5 3.5l3 3",pencil:"M11.5 2.5l2 2L6 12l-3 1 1-3zM10 4l2 2",marker:"M10 2l4 4-6 6H4v-4zM4 12l-2 2h4",brush:"M13.5 2.5c-2 1-5 4-6.5 6l1 1c2-1.5 5-4.5 6-6.5zM6.5 9.5c-2 0-3 1.5-3 3 0 .8-.5 1.2-1.5 1.5 3 .5 5.5-1 5.5-3.5",highlighter:"M9 2l5 5-5 5-5-5zM4 7l-2 5 3-1M2 14h12",neon:"M2 12c2-6 4 2 6-4s4 2 6-4M8 1v2M3 3l1.5 1.5M13 3l-1.5 1.5",line:"M3 13L13 3",arrow:"M3 13L13 3M7 3h6v6",doubleArrow:"M3 13L13 3M7 3h6v6M9 13H3V7",rect:"M2.5 3.5h11v9h-11z",ellipse:"M8 3c3.3 0 6 2.2 6 5s-2.7 5-6 5-6-2.2-6-5 2.7-5 6-5z",blur:"M2 2h4v4H2zM6 6h4v4H6zM10 2h4v4h-4zM2 10h4v4H2zM10 10h4v4h-4z",text:"M3 3h10M8 3v10M6 13h4",callout:"M8 2a5 5 0 110 10 5 5 0 010-10zM7 5.5l1.5-1v5M7 9.5h3",eraser:"M9 2l5 5-6 6H4l-2-2zM6 5l5 5M4 13h10"};function Ly({tool:e}){return(0,pp.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.3",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:(0,pp.jsx)("path",{d:_2[e]})})}var ve=R(j(),1),Uy=[[{tool:"select",label:"Select and move"}],[{tool:"pen",label:"Pen"},{tool:"pencil",label:"Pencil"},{tool:"marker",label:"Marker"},{tool:"brush",label:"Brush"},{tool:"highlighter",label:"Highlighter"},{tool:"neon",label:"Neon"}],[{tool:"line",label:"Line"},{tool:"arrow",label:"Arrow"},{tool:"doubleArrow",label:"Double arrow"},{tool:"rect",label:"Rectangle"},{tool:"ellipse",label:"Ellipse"}],[{tool:"text",label:"Text"},{tool:"callout",label:"Numbered callout"},{tool:"blur",label:"Redact (pixelate)"},{tool:"eraser",label:"Eraser"}]],H2=[{value:"solid",label:"Solid"},{value:"dashed",label:"Dashed"},{value:"dotted",label:"Dotted"}],jy=Uy.flat().map(e=>e.tool);function qy(e){let{tool:t,style:n}=e,o=(i,r,l)=>{let c=pn.find(p=>p.id===r),s=e.keyOf?e.keyOf(r):c?.keys[0]?qt(c.keys[0],!1):l;return s?`${i} (${s})`:i},a=[..._i,...e.recentColors.filter(i=>!_i.includes(i))];return(0,ve.jsxs)("div",{className:"draw-toolbar",role:"toolbar","aria-label":"Drawing tools",children:[Uy.map((i,r)=>(0,ve.jsx)("div",{className:"draw-group",children:i.map(({tool:l,label:c})=>(0,ve.jsx)("button",{type:"button",className:`icon-button${t===l?" active":""}`,title:o(c,`draw.${l}`),"aria-label":c,"aria-pressed":t===l,onClick:()=>e.onTool(l),children:(0,ve.jsx)(Ly,{tool:l})},l))},r)),(0,ve.jsxs)("div",{className:"draw-group colors",role:"radiogroup","aria-label":"Colour",children:[a.slice(0,13).map(i=>(0,ve.jsx)("button",{type:"button",role:"radio","aria-checked":n.color===i,"aria-label":i,title:i,className:`swatch${n.color===i?" active":""}`,style:{background:i},onClick:()=>e.onStyle({color:i})},i)),(0,ve.jsx)(_y,{value:n.color,label:"Custom colour",presets:_i,onChange:i=>e.onStyle({color:i})})]}),(0,ve.jsxs)("div",{className:"draw-group",children:[(0,ve.jsx)(fp,{icon:"circle-small-filled",label:"Width",min:1,max:24,value:n.width,format:i=>`${i}px`,onChange:i=>e.onStyle({width:i})}),(0,ve.jsx)(fp,{icon:"color-mode",label:"Opacity",min:10,max:100,step:5,value:Math.round(n.opacity*100),format:i=>`${i}%`,onChange:i=>e.onStyle({opacity:i/100})}),(0,ve.jsx)(_n,{size:"sm",appearance:"quiet",label:"Line style",value:n.dash,options:H2,onChange:i=>e.onStyle({dash:i})}),(0,ve.jsx)("button",{type:"button",className:`icon-button${n.fill?" active":""}`,title:o("Fill shapes","draw.fill"),"aria-label":"Fill shapes","aria-pressed":n.fill,onClick:()=>e.onStyle({fill:!n.fill}),children:(0,ve.jsx)("span",{className:"codicon codicon-circle-filled","aria-hidden":"true"})})]}),(0,ve.jsxs)("div",{className:"draw-group",children:[(0,ve.jsx)("button",{type:"button",className:"icon-button",title:o("Undo","draw.undo","Ctrl+Z"),"aria-label":"Undo",disabled:!e.canUndo,onClick:e.onUndo,children:(0,ve.jsx)("span",{className:"codicon codicon-discard","aria-hidden":"true"})}),(0,ve.jsx)("button",{type:"button",className:"icon-button",title:o("Redo","draw.redo","Ctrl+Y"),"aria-label":"Redo",disabled:!e.canRedo,onClick:e.onRedo,children:(0,ve.jsx)("span",{className:"codicon codicon-redo","aria-hidden":"true"})}),(0,ve.jsx)("button",{type:"button",className:"icon-button",title:o("Clear all drawings","draw.clear"),"aria-label":"Clear all drawings",disabled:!e.hasShapes,onClick:e.onClear,children:(0,ve.jsx)("span",{className:"codicon codicon-clear-all","aria-hidden":"true"})}),(0,ve.jsx)("button",{type:"button",className:`icon-button${e.visible?"":" active"}`,title:o(e.visible?"Hide drawings":"Show drawings","draw.visible"),"aria-label":e.visible?"Hide drawings":"Show drawings",onClick:e.onToggleVisible,children:(0,ve.jsx)("span",{className:`codicon codicon-${e.visible?"eye":"eye-closed"}`,"aria-hidden":"true"})})]}),(0,ve.jsx)(je,{variant:"primary",size:"sm",icon:"device-camera",iconEnd:"chevron-down",className:"draw-capture",disabled:!e.hasShapes,title:o("Screenshot menu","draw.captureMenu"),onClick:i=>{let r=i.currentTarget.getBoundingClientRect();e.onCapture(r.left,r.bottom+2)},children:"Screenshot"}),(0,ve.jsx)("button",{type:"button",className:"icon-button draw-close",title:o("Stop drawing","draw.exit","Esc"),"aria-label":"Stop drawing",onClick:e.onClose,children:(0,ve.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]})}var B2={area:"draw.capture",groups:"draw.captureGroups",clean:"draw.captureClean",viewport:"draw.captureViewport",fullPage:"draw.captureFullPage"};function Yy(e,t){let n=(o,a,i)=>({label:a,icon:i,shortcut:t?.(B2[o]),onSelect:()=>e(o)});return[n("area","Drawing area","device-camera"),n("groups","Each drawing separately","layers"),n("clean","Drawing area without drawings","eye-closed"),{separator:!0},n("viewport","Visible area with drawings","screen-normal"),n("fullPage","Full page with drawings","file-media")]}var mp=R(j(),1);function Vy({label:e,dragging:t,className:n,...o}){return(0,mp.jsx)("button",{type:"button",className:["drag-handle",t&&"dragging",n].filter(Boolean).join(" "),title:e,"aria-label":e,...o,children:(0,mp.jsx)("span",{className:"codicon codicon-gripper","aria-hidden":"true"})})}var gp=R(j(),1);function Se({icon:e,label:t,onClick:n,onContextMenu:o,disabled:a,active:i,spin:r,className:l}){return(0,gp.jsx)("button",{type:"button",className:["icon-button",i&&"active",l].filter(Boolean).join(" "),title:t,"aria-label":t,"aria-pressed":i,disabled:a,onClick:n,onContextMenu:o,children:(0,gp.jsx)("span",{className:`codicon codicon-${e}${r?" codicon-modifier-spin":""}`,"aria-hidden":"true"})})}var en=R(Ae(),1);var Vt=R(j(),1);function Ts({menu:e,onClose:t}){let n=(0,en.useRef)(null),[o]=(0,en.useState)(ss);return(0,en.useEffect)(()=>{let a=us(()=>[n.current],o,()=>t()),i=r=>{r.key==="Escape"&&(r.preventDefault(),r.stopPropagation(),t())};return window.addEventListener("keydown",i,!0),window.addEventListener("blur",t),window.addEventListener("resize",t),()=>{a(),window.removeEventListener("keydown",i,!0),window.removeEventListener("blur",t),window.removeEventListener("resize",t)}},[t,o]),(0,Vt.jsx)("div",{ref:n,className:"menu-root",onContextMenu:a=>a.preventDefault(),children:(0,Vt.jsx)(Ky,{items:e.items,x:e.x,y:e.y,onClose:t,focusFirst:!0})})}function Ky({items:e,x:t,y:n,onClose:o,focusFirst:a,parent:i,onBack:r}){let l=(0,en.useRef)(null),[c,s]=(0,en.useState)(null),p=(0,en.useRef)(void 0);(0,en.useLayoutEffect)(()=>{let E=l.current;if(!E)return;let m=E.getBoundingClientRect(),g=t;i&&t+m.width>innerWidth-4&&(g=i.left-m.width+2),E.style.left=`${Math.max(4,Math.min(g,innerWidth-m.width-4))}px`,E.style.top=`${Math.max(4,Math.min(n,innerHeight-m.height-4))}px`,a&&E.querySelector(":scope > button:not(:disabled)")?.focus({preventScroll:!0})},[t,n,i,a]),(0,en.useEffect)(()=>()=>clearTimeout(p.current),[]);let b=()=>[...l.current?.querySelectorAll(":scope > button:not(:disabled)")??[]],u=(E,m,g)=>{clearTimeout(p.current),s({index:E,rect:m.getBoundingClientRect()}),g&&setTimeout(()=>l.current?.querySelector(":scope > .menu button:not(:disabled)")?.focus({preventScroll:!0}))},d=E=>{if(E.target instanceof HTMLElement&&E.target.closest(".menu")!==l.current)return;let m=b(),g=m.indexOf(document.activeElement);if(E.key==="ArrowDown"||E.key==="ArrowUp")E.preventDefault(),m[(g+(E.key==="ArrowDown"?1:-1)+m.length)%m.length]?.focus();else if(E.key==="ArrowLeft"&&r)E.preventDefault(),E.stopPropagation(),r();else if(E.key==="ArrowRight"){let f=m[g],y=f&&e[Number(f.dataset.index)];y&&"submenu"in y&&y.submenu&&(E.preventDefault(),u(Number(f.dataset.index),f,!0))}},x=c?e[c.index]:void 0,k=x&&"submenu"in x?x.submenu?.():void 0;return(0,Vt.jsxs)("div",{ref:l,className:"menu",role:"menu",style:{left:t,top:n},onKeyDown:d,children:[e.map((E,m)=>"separator"in E?(0,Vt.jsx)("div",{className:"menu-separator",role:"separator"},m):(0,Vt.jsxs)("button",{type:"button",role:"menuitem","data-index":m,"aria-haspopup":E.submenu?"menu":void 0,"aria-expanded":E.submenu?c?.index===m:void 0,className:`menu-item${c?.index===m?" expanded":""}`,disabled:E.disabled,onPointerEnter:g=>{clearTimeout(p.current);let f=g.currentTarget;E.disabled||f.focus({preventScroll:!0}),p.current=setTimeout(()=>E.submenu?u(m,f,!1):s(null),E.submenu?120:250)},onClick:g=>{if(E.submenu){u(m,g.currentTarget,g.detail===0);return}o(),E.onSelect()},children:[E.image?(0,Vt.jsx)("img",{className:"menu-image",src:E.image,alt:"",referrerPolicy:"no-referrer"}):(0,Vt.jsx)("span",{className:`codicon codicon-${E.icon??"blank"}`,"aria-hidden":"true"}),(0,Vt.jsx)("span",{className:"menu-label",children:E.label}),E.shortcut&&(0,Vt.jsx)("span",{className:"menu-shortcut",children:E.shortcut}),E.submenu&&(0,Vt.jsx)("span",{className:"codicon codicon-chevron-right menu-arrow","aria-hidden":"true"})]},m)),c&&k&&(0,Vt.jsx)(Ky,{items:k.length?k:[{label:"(empty)",disabled:!0,onSelect:()=>{}}],x:c.rect.right-2,y:c.rect.top-5,parent:c.rect,onClose:o,onBack:()=>{s(null),l.current?.querySelector(`:scope > button[data-index="${c.index}"]`)?.focus()}},c.index)]})}var no=R(j(),1),L2=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),U2=[{action:"copy",label:"Capture",icon:"inspect"},{action:"screenshot",label:"Screenshot",icon:"device-camera"}];function Xy({count:e,map:t,onAction:n,className:o,style:a}){let i=t["inspect.copy"]?.[0];return(0,no.jsxs)("div",{className:oe("selection-bar",o),style:a,role:"toolbar","aria-label":"Selected elements",onPointerDown:r=>r.stopPropagation(),children:[(0,no.jsxs)("span",{className:"selection-bar-count",children:[(0,no.jsx)("span",{className:"selection-bar-badge",children:e}),"selected"]}),U2.map(({action:r,label:l,icon:c})=>(0,no.jsxs)(je,{size:"sm",variant:r==="copy"?"primary":"ghost",icon:c,onClick:()=>n(r),children:[l,r==="copy"&&i&&(0,no.jsx)("span",{className:"keycaps size-sm",children:Di(i,L2).map(s=>(0,no.jsx)("kbd",{className:"keycap",children:s},s))})]},r)),(0,no.jsx)(Se,{icon:"close",label:"Clear the selection",className:"small selection-bar-clear",onClick:()=>n("clear")})]})}var Gy=["claude","codex","opencode","agy"];var Qy=e=>`agentmux:new:${e}`,Zy={claude:"Claude Code",codex:"Codex",opencode:"opencode",agy:"Antigravity"};var cl=e=>typeof e=="number"&&Number.isFinite(e),dt=e=>typeof e=="boolean",P=e=>t=>typeof t=="string"&&t.length<=e,Hn=e=>t=>typeof t=="string"&&e.test(t),X=e=>t=>t===void 0||e(t),Ea=(...e)=>t=>typeof t=="string"&&e.includes(t),j2=e=>typeof e=="object"&&e!==null&&!Array.isArray(e),Ta=e=>t=>j2(t)&&Object.entries(e).every(([n,o])=>o(t[n])),tn=(e,t=1e5)=>n=>Array.isArray(n)&&n.length<=t&&n.every(e);var BT=1024*1024,q2=64*1024*1024,Y2=["element","screenshot","recording","errors","network","page","report","css","measure","color","text"],vp=/^\d{8}-\d{6}-[0-9a-f]{6}$/,bp=/^[\w-]{1,40}\.[a-z0-9]{1,5}$/;function Py(e){return e.vscode||e.agentmux}var Ca=Hn(/^[\w.-]{1,64}$/),Cs=P(q2),V2=P(4096),LT={auth:{token:P(128),role:Ea("browser","vscode"),origin:X(P(256))}},it=Hn(/^[\w-]{1,64}$/),nn=P(4096),$y=Ea(...Y2),hp=Hn(/^[A-Za-z0-9+/]*={0,2}$/),K2=Ta({kind:$y,title:P(300),detail:X(P(1e3)),text:X(P(5e6)),group:X(Ca),groupIndex:X(cl),image:X(hp),thumb:X(e=>typeof e=="string"&&e.length<=4e5&&hp(e))}),Jy=Ta({id:P(200),kind:Ea("tmux","terminal","chat"),label:P(100),detail:P(300)}),qi=tn(Hn(vp),60),UT={link:{data:Cs},ping:{},"projects.get":{req:it,url:X(P(4096))},"capture.save":{req:it,project:nn,url:X(P(4096)),browser:X(P(100)),captures:tn(K2,60),send:X(P(200))},"item.send":{req:it,project:nn,ids:qi,target:X(P(200)),open:X(dt)},"items.move":{req:it,project:nn,ids:qi,to:nn},"items.get":{req:it,project:nn},"item.thumb":{req:it,project:nn,id:Hn(vp)},"item.remove":{req:it,project:nn,ids:qi},"item.restore":{req:it,project:nn,ids:qi},"project.pin":{req:it,project:nn,pinned:dt}},X2=Ta({path:nn,name:P(300),vscode:dt,agentmux:dt,saved:dt,pinned:dt,targets:X(tn(Jy,50)),defaultTarget:X(P(200)),harnesses:X(tn(Ea(...Gy),10)),inbox:X(dt)}),G2=Ta({v:e=>e===1,id:Hn(vp),kind:$y,title:P(300),detail:X(P(1e3)),url:X(P(4096)),time:cl,group:X(Ca),groupIndex:X(cl),key:X(P(200)),source:Ea("browser","vscode"),browser:X(P(100)),preview:X(P(1e3)),files:Ta({file:X(Hn(bp)),text:X(Hn(bp)),thumb:X(Hn(bp))}),sentTo:tn(P(200),50)}),jT={link:{data:Cs},status:{vscode:dt,peer:X(P(200)),features:X(tn(P(40),50))},relink:{},pong:{},projects:{req:it,projects:tn(X2,500),suggested:X(nn)},"capture.saved":{req:it,ok:dt,ids:X(qi),error:X(P(1e3)),sentTo:X(P(200))},"item.sent":{req:it,ok:dt,sentTo:X(P(200)),error:X(P(1e3))},items:{req:it,ok:dt,items:tn(G2,500),error:X(P(1e3))},thumb:{req:it,data:X(hp),mimeType:X(Ea("image/jpeg","image/png"))},done:{req:it,ok:dt,error:X(P(1e3))}},qT={window:{id:Ca,name:P(200),folders:tn(V2,50),focusedAt:cl,targets:X(tn(Jy,50))},link:{browser:Ca,data:Cs},shutdown:{},ping:{},"run.sent":{req:it,ok:dt,sentTo:X(P(200)),error:X(P(1e3))}},Q2=Ta({id:Ca,name:P(100),origin:P(256)}),YT={welcome:{build:P(100),leader:dt},leader:{leader:dt},browsers:{browsers:tn(Q2,50)},link:{browser:Ca,data:Cs},gone:{browser:Ca},pong:{},"run.send":{req:it,project:nn,ids:qi,target:P(200)}};function Iy(e){return e.inbox?"captures without a project":[e.vscode&&"VS Code",e.agentmux&&"agentmux",!Py(e)&&e.saved&&"saved",e.pinned&&"pinned"].filter(Boolean).join(" \xB7 ")}var Bn=R(Ae(),1);function Fy(e,t){let n=e.find(o=>o.id===t);return n?[n,...e.filter(o=>o!==n)]:[...e]}function Wy(e,t){if(/^[1-9]$/.test(e))return t[Number(e)-1]}function e1(e){return e.kind==="chat"?"comment-discussion":e.kind==="tmux"?"terminal-tmux":"terminal"}var yp=R(j(),1),Z2=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function Na({binding:e,size:t="md"}){let n=Di(e,Z2);return(0,yp.jsx)("span",{className:`keycaps size-${t}`,"aria-label":n.join("+"),children:n.map((o,a)=>(0,yp.jsx)("kbd",{className:"keycap",children:o},a))})}var Z=R(j(),1),t1='button:not([disabled]), [href], input, [tabindex]:not([tabindex="-1"])';function n1(e){let{targets:t,defaultTarget:n,harnesses:o=[],onSend:a,onClose:i,map:r}=e,l=(0,Bn.useRef)(null),c=(0,Bn.useRef)(null),s=(0,Bn.useRef)(null),[p,b]=(0,Bn.useState)(null),u=Fy(t,n),[d,x]=(0,Bn.useState)(),k=u.some(h=>h.id===d)?d:u[0]?.id,E=e.status?.tone==="busy",m=h=>r[h]?.[0];(0,Bn.useEffect)(()=>{let h=l.current?.getRootNode()?.activeElement;return l.current?.focus(),()=>h?.focus?.()},[]),(0,Bn.useEffect)(()=>{let h=l.current,S=h?.parentElement;if(!h||!S)return;let v=h.getRootNode(),T=v instanceof ShadowRoot?v.host:void 0,z=h.ownerDocument,M=z.documentElement,B={htmlOverflow:M.style.overflow,bodyOverflow:z.body.style.overflow,paddingRight:M.style.paddingRight},H=z.defaultView?z.defaultView.innerWidth-M.clientWidth:0;M.style.overflow="hidden",z.body.style.overflow="hidden",H>0&&(M.style.paddingRight=`${H}px`);let I=D=>{(!h.contains(D.target)||h.scrollHeight<=h.clientHeight)&&D.preventDefault()};S.addEventListener("wheel",I,{passive:!1}),S.addEventListener("touchmove",I,{passive:!1});let ne=D=>{let U=D.target;!U||U===T||h.contains(U)||U.closest?.("[data-ink-popup]")||(h.querySelector(t1)??h).focus()};return z.addEventListener("focusin",ne,!0),()=>{M.style.overflow=B.htmlOverflow,z.body.style.overflow=B.bodyOverflow,M.style.paddingRight=B.paddingRight,S.removeEventListener("wheel",I),S.removeEventListener("touchmove",I),z.removeEventListener("focusin",ne,!0)}},[]);let g=h=>{if(!u.length)return;let S=u.findIndex(T=>T.id===k),v=u[(S+h+u.length)%u.length];x(v.id),l.current?.querySelector(`[data-target="${CSS.escape(v.id)}"]`)?.focus()},f=()=>{let h=c.current?.getBoundingClientRect();h&&b({x:h.left,y:h.bottom+4,items:o.map(S=>({label:Zy[S],icon:"terminal-tmux",onSelect:()=>a(Qy(S),{open:!1})}))})},y=h=>{if(h.defaultPrevented)return;if(h.key==="Tab"){let ne=[...l.current?.querySelectorAll(t1)??[]];if(!ne.length)return;let D=l.current.getRootNode(),U=ne.indexOf(D.activeElement),A=h.shiftKey?U<=0?ne.length-1:U-1:(U+1)%ne.length;ne[A].focus(),h.preventDefault();return}if(E){if(h.key!=="Escape")return;h.preventDefault(),h.stopPropagation(),i();return}let S=h.nativeEvent,v=h.target.closest('[role="menu"], [role="listbox"], input');if((h.key==="ArrowDown"||h.key==="ArrowUp")&&!v&&u.length){h.preventDefault(),h.stopPropagation(),g(h.key==="ArrowDown"?1:-1);return}let T=/^Digit([1-9])$/.exec(S.code)?.[1],z=T&&!h.ctrlKey&&!h.altKey&&!h.metaKey?Wy(T,u):void 0;if(z){h.preventDefault(),h.stopPropagation(),a(z.id,{open:h.shiftKey&&z.kind==="tmux"});return}if(h.target.closest("button")&&h.key==="Enter")return;let B=nl(r,["send"],eo(S))?.id,H={"send.default":k?()=>a(k,{open:!1}):void 0,"send.newThread":o.length?f:void 0,"send.project":e.onProject?()=>s.current?.querySelector("button")?.click():void 0,"send.copy":e.onCopy,"send.download":e.onDownload,"send.close":i},I=B?H[B]:h.key==="Escape"?i:void 0;I&&(h.preventDefault(),h.stopPropagation(),I())};return(0,Z.jsx)("div",{className:"ink-modal-backdrop",onMouseDown:h=>{h.target===h.currentTarget&&!E&&i()},children:(0,Z.jsxs)("div",{ref:l,className:"ink-modal",role:"dialog","aria-modal":"true","aria-label":e.title,tabIndex:-1,onKeyDown:y,children:[(0,Z.jsxs)("div",{className:"ink-modal-head",children:[(0,Z.jsxs)("div",{className:"ink-modal-heading",children:[(0,Z.jsxs)("div",{className:"ink-modal-title",children:[(0,Z.jsx)("span",{className:"codicon codicon-pass-filled","aria-hidden":"true"}),e.title]}),e.project&&(0,Z.jsxs)("div",{className:"ink-modal-project",ref:s,children:[(0,Z.jsx)("span",{className:"ink-muted",children:"Saved in"}),e.projects&&e.projects.length>1&&e.onProject?(0,Z.jsx)(_n,{size:"sm",appearance:"quiet",label:"Project",icon:"folder",value:e.project.path,onChange:e.onProject,options:e.projects.map(h=>({value:h.path,label:h.name,detail:h.detail,icon:"folder"}))}):(0,Z.jsx)("span",{className:"ink-modal-project-name",children:e.project.name})]}),e.detail&&(0,Z.jsx)("div",{className:"ink-modal-detail",children:e.detail})]}),(0,Z.jsx)(Se,{icon:"close",label:"Close (it stays saved)",onClick:i})]}),!!e.images?.length&&(0,Z.jsx)("div",{className:"ink-modal-thumbs","aria-hidden":"true",children:e.images.slice(0,4).map((h,S,v)=>(0,Z.jsxs)("span",{className:"ink-modal-thumb",children:[(0,Z.jsx)("img",{src:h,alt:""}),S===v.length-1&&e.images.length>v.length&&(0,Z.jsxs)("span",{className:"ink-modal-more",children:["+",e.images.length-v.length]})]},S))}),(0,Z.jsxs)("div",{className:"ink-modal-label",children:["Send to",u.length>0&&(0,Z.jsx)("span",{className:"ink-modal-count",children:u.length})]}),u.length?(0,Z.jsx)("ul",{className:"ink-modal-targets",role:"list",children:u.map((h,S)=>(0,Z.jsxs)("li",{className:oe("ink-modal-target",h.id===k&&"default"),children:[(0,Z.jsxs)("button",{type:"button",className:"ink-modal-send","data-target":h.id,"aria-current":h.id===k?"true":void 0,disabled:E,onClick:()=>a(h.id,{open:!1}),"aria-keyshortcuts":S<9?String(S+1):void 0,children:[(0,Z.jsx)("span",{className:"ink-modal-icon","aria-hidden":"true",children:(0,Z.jsx)("span",{className:`codicon codicon-${e1(h)}`})}),(0,Z.jsxs)("span",{className:"ink-modal-text",children:[(0,Z.jsx)("span",{className:"ink-modal-agent",children:h.label}),(0,Z.jsx)("span",{className:"ink-modal-where",children:h.detail})]}),(0,Z.jsxs)("span",{className:"ink-modal-keys",children:[S<9&&(0,Z.jsx)("span",{className:"ink-modal-number",children:S+1}),h.id===k&&m("send.default")&&(0,Z.jsx)(Na,{binding:m("send.default"),size:"sm"})]})]}),h.kind==="tmux"&&(0,Z.jsx)(Se,{icon:"link-external",label:`Send and open ${h.detail} in agentmux`,disabled:E,onClick:()=>a(h.id,{open:!0})})]},h.id))}):(0,Z.jsx)("div",{className:"ink-modal-empty",children:e.emptyText??"No agent is running for this project."}),o.length>0&&(0,Z.jsxs)(je,{ref:c,size:"sm",variant:"ghost",icon:"add",iconEnd:"chevron-down",className:"ink-modal-thread",disabled:E,onClick:f,children:["New agentmux thread",m("send.newThread")&&(0,Z.jsx)(Na,{binding:m("send.newThread"),size:"sm"})]}),(0,Z.jsxs)("div",{className:"ink-modal-foot",children:[(0,Z.jsx)("span",{className:oe("ink-modal-status",e.status&&`tone-${e.status.tone}`),role:"status",children:e.status?.text??"Esc keeps it saved without sending."}),e.onCopy&&(0,Z.jsxs)(je,{size:"sm",variant:"ghost",icon:"copy",disabled:E,onClick:e.onCopy,children:["Copy",m("send.copy")&&(0,Z.jsx)(Na,{binding:m("send.copy"),size:"sm"})]}),e.onDownload&&(0,Z.jsxs)(je,{size:"sm",variant:"ghost",icon:"desktop-download",disabled:E,onClick:e.onDownload,children:[e.downloadLabel??"Download",m("send.download")&&(0,Z.jsx)(Na,{binding:m("send.download"),size:"sm"})]})]}),p&&(0,Z.jsx)(Ts,{menu:p,onClose:()=>b(null)})]})})}var o1="inkspect:request",Ns="inkspect:response",xp="data-inkspect-target";async function De(e){try{return await chrome.runtime.sendMessage(e)??{ok:!1,error:"No reply from the extension"}}catch(t){return{ok:!1,error:t instanceof Error?t.message:String(t)}}}var Ms="inkspectShortcuts",sl=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),i1=pn.filter(e=>$f.has(e.id)),P2={"mode.device":"Responsive view","mode.screenshot":"Screenshot menu","open.shortcuts":"Keyboard shortcuts"},r1=e=>P2[e.id]??e.label,l1=e=>e==="global"?"General":el[e],a1=["global","inspect","draw","screenshot"],c1=[...a1,...Object.keys(el).filter(e=>!a1.includes(e))];async function s1(){let e=(await chrome.storage.sync.get(Ms))[Ms];return{overrides:C0(e?.shortcuts??{}),updated:typeof e?.updated=="number"?e.updated:0}}async function u1(e){let{updated:t}=await s1();await chrome.storage.sync.set({[Ms]:{shortcuts:e,updated:Math.max(Date.now(),t+1)}})}function d1(e){let t=()=>{s1().then(o=>e(ms(o.overrides,sl),o))},n=(o,a)=>{a==="sync"&&o[Ms]&&t()};return chrome.storage.onChanged.addListener(n),t(),()=>chrome.storage.onChanged.removeListener(n)}async function kp(e,t,n){let o={...e},a=pn.find(l=>l.id===t),i=a?tl(a,sl).map(ps):[],r=n!==void 0&&n.length===i.length&&n.every(l=>i.includes(l));n===void 0||r?delete o[t]:o[t]=n,await u1(o)}async function f1(){await u1({})}var p1=(e=2)=>new Promise(t=>{let n=o=>o?requestAnimationFrame(()=>n(o-1)):setTimeout(t,30);n(e)});async function $2(e){let t=new Image;return t.src=e,await t.decode(),t}async function ul(e){let t=e();await p1();try{let n=await De({type:"capture"});if(!n.ok||!n.dataUrl)throw new Error(n.ok?"No image":n.error);return await $2(n.dataUrl)}finally{t()}}function J2(){let e=[];for(let t of document.querySelectorAll("body *")){let n=getComputedStyle(t).position;(n==="fixed"||n==="sticky")&&(e.push([t,t.style.getPropertyValue("visibility")]),t.style.setProperty("visibility","hidden","important"))}return()=>{for(let[t,n]of e)n?t.style.setProperty("visibility",n):t.style.removeProperty("visibility")}}function I2(e,t){return Math.min(1,32e3/t,32e3/e,Math.sqrt(25e7/(e*t)))}async function dl(e,t){let n=document.documentElement,o=Math.max(n.scrollWidth,innerWidth),a=Math.max(n.scrollHeight,innerHeight),i=Math.max(0,Math.floor(e.x)),r=Math.max(0,Math.floor(e.y)),l={x:i,y:r,width:Math.max(1,Math.min(Math.ceil(e.width+e.x-i),o-i)),height:Math.max(1,Math.min(Math.ceil(e.height+e.y-r),a-r))},c={x:scrollX,y:scrollY},s=l.x>=scrollX&&l.y>=scrollY&&l.x+l.width<=scrollX+n.clientWidth&&l.y+l.height<=scrollY+n.clientHeight,p=devicePixelRatio,b=I2(l.width*p,l.height*p),u=document.createElement("canvas");u.width=Math.round(l.width*p*b),u.height=Math.round(l.height*p*b);let d=u.getContext("2d"),x=(E,m,g)=>{let f=E.width/innerWidth,y=(l.x-m)*f,h=Math.max(0,l.y-g)*f,S=Math.max(0,g-l.y),v=Math.min(l.height-S,n.clientHeight-Math.max(0,l.y-g));v<=0||d.drawImage(E,y,h,l.width*f,v*f,0,S*p*b,u.width,v*p*b)};if(s)return x(await ul(t),scrollX,scrollY),{dataUrl:u.toDataURL("image/png"),area:l};let k;try{let E=Math.min(l.x,Math.max(0,o-n.clientWidth));for(let m=l.y;m<l.y+l.height;){scrollTo(E,m),await p1(),x(await ul(t),scrollX,scrollY);let g=scrollY+n.clientHeight;if(g>=l.y+l.height||g>=a)break;m=g,k??=J2()}}finally{k?.(),scrollTo(c.x,c.y)}return{dataUrl:u.toDataURL("image/png"),area:l}}function wp(){let e=document.documentElement;return{x:scrollX,y:scrollY,width:e.clientWidth,height:e.clientHeight}}function Sp(){let e=document.documentElement;return{x:0,y:0,width:e.clientWidth,height:Math.max(e.scrollHeight,innerHeight)}}async function m1(e){let t=e.getBoundingClientRect(),n=await ul(()=>()=>{}),o=n.width/innerWidth,a=document.createElement("canvas");return a.width=Math.round(t.width*o),a.height=Math.round(t.height*o),a.getContext("2d").drawImage(n,t.x*o,t.y*o,t.width*o,t.height*o,0,0,a.width,a.height),a.toDataURL("image/png")}async function g1(e,t=480){try{let n=e.replace(/^data:image\/\w+;base64,/,""),o=Uint8Array.from(atob(n),p=>p.charCodeAt(0)),a=await createImageBitmap(new Blob([o],{type:"image/png"})),i=Math.min(1,t/Math.max(a.width,a.height)),r=new OffscreenCanvas(Math.max(1,Math.round(a.width*i)),Math.max(1,Math.round(a.height*i)));r.getContext("2d").drawImage(a,0,0,r.width,r.height),a.close();let l=await r.convertToBlob({type:"image/jpeg",quality:.75}),c=new Uint8Array(await l.arrayBuffer()),s="";for(let p=0;p<c.length;p+=32768)s+=String.fromCharCode(...c.subarray(p,p+32768));return btoa(s)}catch{return}}var oo=R(Ae());var $e=R(j(),1),Ep=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function b1({purpose:e,map:t,helpKey:n,className:o,style:a}){let i=r=>{let l=t[r]?.[0];return l?Di(l,Ep):[]};return e==="screenshot"?(0,$e.jsxs)("div",{className:oe("picker-hint",o),style:a,role:"status",children:[(0,$e.jsx)("span",{className:"picker-hint-lead",children:"Click an element to screenshot it"}),(0,$e.jsx)(fl,{caps:i("inspect.exit"),label:"cancel"})]}):(0,$e.jsxs)("div",{className:oe("picker-hint",o),style:a,role:"status",children:[(0,$e.jsxs)("span",{className:"picker-hint-item",children:[(0,$e.jsx)("span",{className:"picker-hint-lead",children:"Click"}),(0,$e.jsx)("span",{className:"picker-hint-label",children:"to capture"})]}),(0,$e.jsx)(fl,{caps:[Ep?"\u2325":"Alt"],click:!0,label:"screenshot"}),(0,$e.jsx)(fl,{caps:[Ep?"\u21E7":"Shift"],click:!0,label:"to add"}),(0,$e.jsx)(fl,{caps:i("inspect.exit"),label:"stop"}),n&&(0,$e.jsx)(fl,{caps:i("inspect.help"),label:"keys"})]})}function fl({caps:e,click:t,label:n}){return e.length?(0,$e.jsxs)("span",{className:"picker-hint-item",children:[(0,$e.jsx)("span",{className:"keycaps size-sm",children:e.map((o,a)=>(0,$e.jsx)("kbd",{className:"keycap",children:o},a))}),t&&(0,$e.jsx)("span",{className:"picker-hint-click",children:"+ click"}),(0,$e.jsx)("span",{className:"picker-hint-label",children:n})]}):null}var $=R(j()),F2={Escape:"inspect.exit",ArrowUp:"inspect.parent",ArrowDown:"inspect.child",Enter:"inspect.copy"},Xe=e=>parseFloat(e)||0;function W2(e){let t=e.getBoundingClientRect(),n=getComputedStyle(e),o={x:t.x,y:t.y,width:t.width,height:t.height},a={x:o.x-Xe(n.marginLeft),y:o.y-Xe(n.marginTop),width:o.width+Xe(n.marginLeft)+Xe(n.marginRight),height:o.height+Xe(n.marginTop)+Xe(n.marginBottom)},i={x:o.x+Xe(n.borderLeftWidth),y:o.y+Xe(n.borderTopWidth),width:o.width-Xe(n.borderLeftWidth)-Xe(n.borderRightWidth),height:o.height-Xe(n.borderTopWidth)-Xe(n.borderBottomWidth)},r={x:i.x+Xe(n.paddingLeft),y:i.y+Xe(n.paddingTop),width:i.width-Xe(n.paddingLeft)-Xe(n.paddingRight),height:i.height-Xe(n.paddingTop)-Xe(n.paddingBottom)};return{margin:a,border:o,padding:i,content:r}}function eE(e){let t={r:255,g:255,b:255,a:1},n=[];for(let o=e;o;o=o.parentElement){let a=Sa(getComputedStyle(o).backgroundColor);if(a&&a.a>0&&(n.push(a),a.a>=1))break}for(let o of n.reverse())t={r:o.r*o.a+t.r*(1-o.a),g:o.g*o.a+t.g*(1-o.a),b:o.b*o.a+t.b*(1-o.a),a:1};return t}function tE(e){let t=e;return t.disabled?!1:t.tabIndex>=0}var h1=(e,t)=>{let n=["Top","Right","Bottom","Left"].map(o=>e.getPropertyValue(`${t}-${o.toLowerCase()}`));return n.every(o=>o===n[0])?n[0]:n[0]===n[2]&&n[1]===n[3]?`${n[0]} ${n[1]}`:n.join(" ")};function nE(e){let t=getComputedStyle(e),n=e.getBoundingClientRect(),o=Sa(t.color),a=Sa(t.backgroundColor),i=eE(e),r=!!e.innerText?.trim(),l=o&&r?Ay(o,i):void 0,{role:c,name:s}=xs(e),p=h1(t,"margin"),b=h1(t,"padding");return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList).slice(0,4),size:`${Math.round(n.width*100)/100} \xD7 ${Math.round(n.height*100)/100}`,color:r&&o?ji(o):void 0,font:r?`${t.fontSize} ${t.fontFamily.split(",")[0].replace(/["']/g,"")}`:void 0,background:a&&a.a>0?ji(a):void 0,margin:p!=="0px"?p:void 0,padding:b!=="0px"?b:void 0,ratio:l,ratioPasses:l!==void 0?zy(l,Xe(t.fontSize),Number(t.fontWeight)||400):void 0,role:c,name:s,focusable:tE(e),rect:n}}function v1({host:e,purpose:t,selection:n,onPick:o,onCommit:a,onExit:i,actionOf:r,map:l}){let[c,s]=(0,oo.useState)(null),[,p]=(0,oo.useState)(0),b=(0,oo.useRef)(null),u=(0,oo.useRef)({onPick:o,onCommit:a,onExit:i,actionOf:r});(0,oo.useEffect)(()=>{u.current={onPick:o,onCommit:a,onExit:i,actionOf:r}}),(0,oo.useEffect)(()=>{let f=H=>H.composedPath().includes(e),y=(H,I)=>document.elementsFromPoint(H,I).find(ne=>ne!==e&&!e.contains(ne))??null,h=H=>{b.current=H,s(H)},S=H=>{if(f(H))return;let I=y(H.clientX,H.clientY);I!==b.current&&h(I)},v=H=>{f(H)||(H.preventDefault(),H.stopImmediatePropagation())},T=H=>{if(f(H))return;v(H);let I=y(H.clientX,H.clientY)??b.current;I&&u.current.onPick(I,{add:H.shiftKey,screenshot:H.altKey})},z=H=>{let I=u.current.actionOf?u.current.actionOf(H):F2[H.key];if(f(H)&&I!=="inspect.exit")return;let ne=b.current;if(I==="inspect.exit")u.current.onExit();else if(I==="inspect.parent"&&ne)h(J0(ne)??ne);else if(I==="inspect.child"&&ne)h(I0(ne)??ne);else if(I==="inspect.copy")u.current.onCommit(ne);else return;H.preventDefault(),H.stopImmediatePropagation()},M=()=>p(H=>H+1),B=["mousedown","mouseup","pointerdown","pointerup","dblclick","auxclick","contextmenu"];window.addEventListener("mousemove",S,!0),window.addEventListener("click",T,!0),window.addEventListener("keydown",z,!0),window.addEventListener("scroll",M,!0),window.addEventListener("resize",M);for(let H of B)window.addEventListener(H,v,!0);return()=>{window.removeEventListener("mousemove",S,!0),window.removeEventListener("click",T,!0),window.removeEventListener("keydown",z,!0),window.removeEventListener("scroll",M,!0),window.removeEventListener("resize",M);for(let H of B)window.removeEventListener(H,v,!0)}},[e]);let d=c?.isConnected?nE(c):void 0,x=c?.isConnected?W2(c):void 0,k=f=>({left:f.x,top:f.y,width:Math.max(0,f.width),height:Math.max(0,f.height)}),E=250,m=d?d.rect.bottom+8+220<innerHeight?d.rect.bottom+8:Math.max(4,d.rect.top-8-220):0,g=d?Math.max(4,Math.min(d.rect.left,innerWidth-E-8)):0;return(0,$.jsxs)("div",{className:"inspector",children:[(0,$.jsx)(b1,{className:"inspect-hint",purpose:t,map:l}),x&&(0,$.jsxs)($.Fragment,{children:[(0,$.jsx)("div",{className:"hl hl-margin",style:k(x.margin)}),(0,$.jsx)("div",{className:"hl hl-border",style:k(x.border)}),(0,$.jsx)("div",{className:"hl hl-padding",style:k(x.padding)}),(0,$.jsx)("div",{className:"hl hl-content",style:k(x.content)}),(0,$.jsx)("div",{className:"hl hl-outline",style:k(x.border)})]}),n.map((f,y)=>{let h=f.getBoundingClientRect();return(0,$.jsx)("div",{className:"selection-box",style:k(h),children:(0,$.jsx)("span",{className:"selection-badge",children:y+1})},y)}),d&&(0,$.jsxs)("div",{className:"tip",style:{left:g,top:m,width:E},children:[(0,$.jsxs)("div",{className:"tip-head",children:[(0,$.jsxs)("span",{children:[(0,$.jsx)("span",{className:"tip-tag",children:d.tag}),d.id&&(0,$.jsxs)("span",{className:"tip-id",children:["#",d.id]}),d.classes.map(f=>(0,$.jsxs)("span",{className:"tip-class",children:[".",f]},f))]}),(0,$.jsx)("span",{className:"tip-size",children:d.size})]}),d.color&&(0,$.jsx)(Ma,{label:"Color",value:d.color,swatch:d.color}),d.font&&(0,$.jsx)(Ma,{label:"Font",value:d.font}),d.background&&(0,$.jsx)(Ma,{label:"Background",value:d.background,swatch:d.background}),d.margin&&(0,$.jsx)(Ma,{label:"Margin",value:d.margin}),d.padding&&(0,$.jsx)(Ma,{label:"Padding",value:d.padding}),(0,$.jsx)("div",{className:"tip-section",children:"Accessibility"}),d.ratio!==void 0&&(0,$.jsxs)("div",{className:"tip-row",children:[(0,$.jsx)("span",{children:"Contrast"}),(0,$.jsxs)("span",{children:[(0,$.jsx)("span",{className:"tip-aa",style:{color:d.color,background:d.background},children:"Aa"})," ",d.ratio.toFixed(2)," ",(0,$.jsx)("span",{className:d.ratioPasses?"ok":"bad",children:d.ratioPasses?"\u2713":"!"})]})]}),(0,$.jsx)(Ma,{label:"Name",value:d.name??""}),(0,$.jsx)(Ma,{label:"Role",value:d.role??"generic"}),(0,$.jsxs)("div",{className:"tip-row",children:[(0,$.jsx)("span",{children:"Keyboard-focusable"}),(0,$.jsx)("span",{className:d.focusable?"ok":"muted",children:d.focusable?"\u2713":"\u2298"})]})]})]})}function Ma({label:e,value:t,swatch:n}){return(0,$.jsxs)("div",{className:"tip-row",children:[(0,$.jsx)("span",{children:e}),(0,$.jsxs)("span",{className:"tip-value",children:[n&&(0,$.jsx)("span",{className:"tip-swatch",style:{background:n}}),t]})]})}var Gi=R(Ae());var As=R(Ae(),1);var x1=R(j(),1);function y1({children:e,confirmLabel:t,onConfirm:n,icon:o,variant:a="ghost",size:i="sm",disabled:r,title:l,className:c}){let[s,p]=(0,As.useState)(!1);return(0,As.useEffect)(()=>{if(!s)return;let b=setTimeout(()=>p(!1),4e3);return()=>clearTimeout(b)},[s]),(0,x1.jsx)(je,{size:i,variant:s?"danger":a,icon:s?"warning":o,disabled:r,title:l,className:c,"aria-live":"polite",onClick:()=>{if(!s){p(!0);return}p(!1),n()},onBlur:()=>p(!1),children:s?t:e})}var Yi=R(j(),1);function zs({label:e,hint:t,error:n,inline:o,className:a,children:i}){return(0,Yi.jsxs)("label",{className:oe("field",o&&"inline",a),children:[(0,Yi.jsx)("span",{className:"field-label",children:e}),(0,Yi.jsx)("span",{className:"field-control",children:i}),(n||t)&&(0,Yi.jsx)("span",{className:oe("field-hint",n&&"error"),role:n?"alert":void 0,children:n??t})]})}var Vo=R(Ae(),1);var F=R(j(),1),Vi=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function w1({actions:e,scopes:t,map:n,overrides:o,query:a="",labelOf:i=s=>s.label,scopeLabel:r=s=>el[s],onSetKeys:l,onReset:c}){let[s,p]=(0,Vo.useState)(new Set),[b,u]=(0,Vo.useState)(null),d=(0,Vo.useMemo)(()=>new Set(e.map(f=>f.id)),[e]),x=(0,Vo.useMemo)(()=>N0(n).filter(f=>f.ids.every(y=>d.has(y))),[n,d]),k=f=>x.filter(y=>y.ids.includes(f)).map(y=>({key:y.key,other:y.ids.find(h=>h!==f)}));(0,Vo.useEffect)(()=>{if(!b)return;let f=h=>{if(h.preventDefault(),h.stopImmediatePropagation(),bs.has(h.key))return;let S=eo(h);if(!S.key)return;let v=!S.ctrl&&!S.alt&&!S.meta&&!S.shift,T=[...n[b.id]??[]];if(v&&S.key==="escape"){u(null);return}if(v&&S.key==="backspace"&&b.index!==void 0)T.splice(b.index,1);else{let z=gs(S);b.index===void 0?T.push(z):T[b.index]=z}l(b.id,[...new Set(T)]),u(null)},y=h=>{h.composedPath().some(v=>v instanceof HTMLElement&&v.classList.contains("key-recording"))||u(null)};return window.addEventListener("keydown",f,!0),window.addEventListener("pointerdown",y,!0),()=>{window.removeEventListener("keydown",f,!0),window.removeEventListener("pointerdown",y,!0)}},[b,n,l]);let E=a.trim().toLowerCase(),m=f=>!E||i(f).toLowerCase().includes(E)||f.id.toLowerCase().includes(E)||r(f.scope).toLowerCase().includes(E)||(n[f.id]??[]).some(y=>qt(y,Vi).toLowerCase().includes(E)||A0(y,E)),g=f=>{let y=e.find(h=>h.id===f);return y?i(y):f};return(0,F.jsxs)("div",{className:"shortcut-list",children:[x.length>0&&(0,F.jsxs)("p",{className:"shortcuts-warning",role:"alert",children:[(0,F.jsx)("span",{className:"codicon codicon-warning","aria-hidden":"true"}),x.length===1?"1 key is":`${x.length} keys are`," used twice."]}),t.map(f=>{let y=e.filter(S=>S.scope===f&&m(S));if(!y.length)return null;let h=E!==""||!s.has(f);return(0,F.jsxs)("section",{className:"shortcut-group",children:[(0,F.jsxs)("button",{type:"button",className:"group-header","aria-expanded":h,onClick:()=>p(S=>{let v=new Set(S);return v.has(f)?v.delete(f):v.add(f),v}),children:[(0,F.jsx)("span",{className:`codicon codicon-chevron-${h?"down":"right"}`,"aria-hidden":"true"}),(0,F.jsx)("span",{className:`codicon codicon-${O0[f]} group-icon`,"aria-hidden":"true"}),(0,F.jsx)("span",{className:"group-title",children:r(f)}),(0,F.jsx)("span",{className:"group-count",children:y.length})]}),h&&y.map(S=>(0,F.jsx)(oE,{action:S,label:i(S),keys:n[S.id]??[],changed:S.id in o,conflicts:k(S.id).map(v=>({...v,otherLabel:g(v.other)})),recording:b?.id===S.id?b:null,onRecord:v=>u({id:S.id,index:v}),onCancel:()=>u(null),onRemove:v=>l(S.id,(n[S.id]??[]).filter((T,z)=>z!==v)),onReset:()=>c(S.id),onResolve:(v,T)=>l(v,(n[v]??[]).filter(z=>z!==T))},S.id))]},f)})]})}function oE({action:e,label:t,keys:n,changed:o,conflicts:a,recording:i,onRecord:r,onCancel:l,onRemove:c,onReset:s,onResolve:p}){let b=tl(e,Vi).map(d=>qt(d,Vi)).join(", ")||"none",u=i!==null&&i.index===void 0;return(0,F.jsxs)("div",{className:`shortcut-item${o?" changed":""}${a.length?" conflict":""}`,children:[(0,F.jsxs)("div",{className:"shortcut-main",children:[(0,F.jsx)("span",{className:"shortcut-label",title:e.id,children:t}),(0,F.jsx)("span",{className:"shortcut-places",children:M0(e).map(d=>(0,F.jsx)("span",{className:`shortcut-tag ${d.id}`,title:d.title,children:d.label},d.id))}),(0,F.jsxs)("span",{className:"shortcut-actions",children:[o&&(0,F.jsx)(Se,{icon:"discard",label:`Reset to default (${b})`,className:"small",onClick:s}),n.length>0&&!u&&(0,F.jsx)(Se,{icon:"add",label:"Add another key",className:"small add-key",onClick:()=>r()})]}),(0,F.jsxs)("span",{className:"shortcut-keys-column",children:[n.map((d,x)=>i?.index===x?(0,F.jsx)(k1,{onCancel:l},d):(0,F.jsxs)("span",{className:"key-button-wrap",children:[(0,F.jsx)("button",{type:"button",className:"key-button",title:"Change: click, then press the new keys","aria-label":`${qt(d,Vi)}: change`,onClick:()=>r(x),children:(0,F.jsx)(Na,{binding:d,size:"sm"})}),(0,F.jsx)("button",{type:"button",className:"key-remove","aria-label":`Remove ${qt(d,Vi)}`,title:"Remove this key",onClick:()=>c(x),children:(0,F.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]},d)),u&&(0,F.jsx)(k1,{onCancel:l}),!n.length&&!u&&(0,F.jsxs)("button",{type:"button",className:"key-empty",title:"Add a key: click, then press the keys",onClick:()=>r(),children:[(0,F.jsx)("span",{className:"codicon codicon-add","aria-hidden":"true"}),"Add key"]})]})]}),a.map(({key:d,other:x,otherLabel:k})=>(0,F.jsxs)("div",{className:"shortcut-conflict",children:[(0,F.jsx)("span",{className:"codicon codicon-warning","aria-hidden":"true"}),(0,F.jsxs)("span",{children:[qt(d,Vi)," is also \u201C",k,"\u201D"]}),(0,F.jsx)("button",{type:"button",className:"link-button",onClick:()=>p(x,d),children:"Remove it there"})]},`${d}-${x}`))]})}function k1({onCancel:e}){return(0,F.jsxs)("span",{className:"key-recording",role:"status",children:[(0,F.jsx)("span",{className:"recording-dot","aria-hidden":"true"}),"Press keys\u2026",(0,F.jsx)("button",{type:"button",className:"key-recording-cancel","aria-label":"Cancel",onClick:e,children:(0,F.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]})}var S1=R(Ae(),1);var Aa=R(j(),1);function Tp({value:e,options:t,onChange:n,label:o,iconOnly:a,size:i="md",className:r}){let l=(0,S1.useRef)(null),c=s=>{let p={ArrowRight:1,ArrowDown:1,ArrowLeft:-1,ArrowUp:-1}[s.key];if(!p)return;s.preventDefault();let b=t.findIndex(d=>d.value===e),u=t[(b+p+t.length)%t.length];n(u.value),l.current?.querySelector(`[data-value="${CSS.escape(u.value)}"]`)?.focus()};return(0,Aa.jsx)("div",{ref:l,className:oe("segmented",`size-${i}`,r),role:"radiogroup","aria-label":o,onKeyDown:c,children:t.map(s=>{let p=s.value===e;return(0,Aa.jsxs)("button",{type:"button",role:"radio","aria-checked":p,"aria-label":a?s.label:void 0,title:a||s.icon?s.label:void 0,"data-value":s.value,tabIndex:p?0:-1,className:oe("segment",p&&"checked"),onClick:()=>n(s.value),children:[s.icon&&(0,Aa.jsx)("span",{className:`codicon codicon-${s.icon}`,"aria-hidden":"true"}),!a&&(0,Aa.jsx)("span",{className:"segment-label",children:s.label}),s.count!==void 0&&(0,Aa.jsx)("span",{className:oe("segment-count",s.tone),children:s.count})]},s.value)})})}var Ki=R(j(),1);function Cp({checked:e,onChange:t,children:n,label:o,disabled:a,className:i,title:r}){return(0,Ki.jsxs)("button",{type:"button",role:"switch","aria-checked":e,"aria-label":n?void 0:o,title:r,disabled:a,className:oe("switch",e&&"on",i),onClick:()=>t(!e),children:[(0,Ki.jsx)("span",{className:"switch-track","aria-hidden":"true",children:(0,Ki.jsx)("span",{className:"switch-thumb"})}),n&&(0,Ki.jsx)("span",{className:"toggle-label",children:n})]})}var pl=R(Ae());var Os=R(Ae()),Xi=R(j());function E1({value:e,onChange:t,onComplete:n,length:o=6,disabled:a}){let i=(0,Os.useRef)([]),r=Array.from({length:o},(s,p)=>e[p]??""),l=s=>i.current[Math.max(0,Math.min(o-1,s))]?.focus(),c=(s,p)=>{let b=p.replace(/\D/g,"");if(!b)return;let u=(e.slice(0,s)+b).slice(0,o);t(u),l(u.length),u.length===o&&n?.(u)};return(0,Xi.jsx)("div",{className:"code-input",role:"group","aria-label":"Pairing code",children:r.map((s,p)=>(0,Xi.jsxs)(Os.Fragment,{children:[p===o/2&&(0,Xi.jsx)("span",{className:"code-sep","aria-hidden":"true"}),(0,Xi.jsx)("input",{ref:b=>{i.current[p]=b},className:"code-box",inputMode:"numeric",autoComplete:"one-time-code","aria-label":`Digit ${p+1}`,maxLength:o,disabled:a,value:s,onFocus:b=>b.currentTarget.select(),onChange:b=>c(Math.min(p,e.length),b.target.value),onPaste:b=>{b.preventDefault(),c(0,b.clipboardData.getData("text"))},onKeyDown:b=>{if(b.key==="Backspace"){b.preventDefault();let u=s?p:p-1;u>=0&&t(e.slice(0,u)),l(u)}else b.key==="ArrowLeft"?(b.preventDefault(),l(p-1)):b.key==="ArrowRight"&&(b.preventDefault(),l(p+1))}})]},p))})}var le=R(j());function T1({status:e,pair:t,compact:n,startWithCode:o}){let[a,i]=(0,pl.useState)(""),[r,l]=(0,pl.useState)(""),[c,s]=(0,pl.useState)(!1),[p,b]=(0,pl.useState)(!!o);if(e.state==="connected")return null;let u=async(x=a)=>{if(x.length!==6||c)return;s(!0),l("");let k=await t(x).catch(()=>{});if(s(!1),!k){l("The extension did not answer. Reload it and try again.");return}l(k.error??""),k.state==="connected"&&i("")},d=(0,le.jsxs)("p",{className:"card-foot",children:[(0,le.jsx)("span",{className:"codicon codicon-lock","aria-hidden":"true"}),"The link only talks to VS Code on this computer, and only after pairing (or through the browser helper VS Code installs)."]});return e.via==="hub"?(0,le.jsx)("div",{className:oe("card","pair-card",n&&"compact"),children:(0,le.jsxs)("p",{className:"pair-lead",children:[(0,le.jsx)("span",{className:"codicon codicon-plug","aria-hidden":"true"}),(0,le.jsx)("span",{children:"Linked through the browser helper: no pairing needed. VS Code isn't running, so sends to its terminals and chat wait for it; captures still save into your projects, and agentmux agents still get them."})]})}):e.state!=="unpaired"?(0,le.jsxs)("div",{className:oe("card","pair-card",n&&"compact"),children:[(0,le.jsxs)("p",{className:"pair-lead",children:[(0,le.jsx)("span",{className:"codicon codicon-loading codicon-modifier-spin","aria-hidden":"true"}),(0,le.jsxs)("span",{children:["Open VS Code with the VS Code Browser extension. Then click"," ",(0,le.jsx)("b",{children:"Pair Browser Extension"})," in its ",(0,le.jsx)("b",{children:"Browser"})," side panel."]})]}),!n&&d]}):(0,le.jsxs)("form",{className:oe("card","pair-card",n&&"compact"),onSubmit:x=>{x.preventDefault(),u()},children:[(0,le.jsxs)("p",{className:"pair-lead",children:[(0,le.jsx)("span",{className:"codicon codicon-plug","aria-hidden":"true"}),(0,le.jsxs)("span",{children:["In VS Code, click ",(0,le.jsx)("b",{children:"Pair Browser Extension"})," in the ",(0,le.jsx)("b",{children:"Browser"})," side panel (or"," ",(0,le.jsx)("b",{children:"Pair"})," on its notification). No code needed: this updates by itself."]})]}),p?(0,le.jsxs)(le.Fragment,{children:[(0,le.jsxs)("p",{className:"muted",children:["Run ",(0,le.jsx)("kbd",{children:"Browser: Pair Browser Extension with a Code"})," in VS Code, then type the code it shows."]}),(0,le.jsxs)("div",{className:"pair-row",children:[(0,le.jsx)(E1,{value:a,onChange:i,disabled:c,onComplete:x=>{u(x)}}),(0,le.jsx)(je,{type:"submit",variant:"primary",icon:"link",className:"pair-button",loading:c,disabled:a.length!==6,children:"Pair"})]})]}):(0,le.jsx)(je,{size:"sm",variant:"ghost",icon:"key",className:"use-code",onClick:()=>b(!0),children:"Use a code instead"}),r&&(0,le.jsxs)("p",{className:"pair-message",role:"alert",children:[(0,le.jsx)("span",{className:"codicon codicon-error","aria-hidden":"true"}),r]}),!n&&d]})}function za(e,t=2e3){let n=crypto.randomUUID();return new Promise(o=>{let a=r=>{let l;try{l=JSON.parse(r.detail)}catch{return}l.id===n&&(window.removeEventListener(Ns,a),clearTimeout(i),o(l.result))},i=setTimeout(()=>{window.removeEventListener(Ns,a),o(void 0)},t);window.addEventListener(Ns,a),window.dispatchEvent(new CustomEvent(o1,{detail:JSON.stringify({id:n,request:e})}))})}async function ml(e){try{return await navigator.clipboard.writeText(e),!0}catch{let t=document.createElement("textarea");t.value=e,t.style.cssText="position:fixed;left:-9999px;top:0;opacity:0",document.documentElement.appendChild(t),t.select();let n=document.execCommand("copy");return t.remove(),n}}async function Rs(e){try{let t=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({"image/png":t})]),!0}catch{return!1}}var aE={copyFormat:"markdown",fields:[...tp],maxHtml:2e3,annotationPadding:40};async function Np(){let e=await chrome.storage.sync.get("settings").catch(()=>({}));return{...aE,...e.settings}}function Mp(e=new Date){let t=a=>String(a).padStart(2,"0"),n=`${e.getFullYear()}-${t(e.getMonth()+1)}-${t(e.getDate())}_${t(e.getHours())}-${t(e.getMinutes())}-${t(e.getSeconds())}`,o=(location.hostname||"page").replace(/[^a-z0-9.-]+/gi,"-").slice(0,40);return`screenshot-${n}-${o}.png`}var q=R(j());function Ds({title:e,onClose:t,children:n}){return(0,q.jsxs)("div",{className:"panel",role:"dialog","aria-label":e,children:[(0,q.jsxs)("div",{className:"panel-head",children:[(0,q.jsx)("span",{children:e}),(0,q.jsx)("button",{type:"button",className:"icon-button","aria-label":"Close",title:"Close",onClick:t,children:(0,q.jsx)("span",{className:"codicon codicon-close","aria-hidden":"true"})})]}),(0,q.jsx)("div",{className:"panel-body",children:n})]})}var C1={network:"none",cpu:1,colorScheme:"default",print:!1,agent:!0};function N1({onClose:e,value:t,onChange:n}){let a=i=>n({...t,...i});return(0,q.jsxs)(Ds,{title:"Emulation",onClose:e,children:[!1,(0,q.jsx)(Cp,{checked:t.agent,disabled:!1,onChange:i=>a({agent:i}),children:"Device user agent and touch"}),(0,q.jsxs)("div",{className:"row",children:[(0,q.jsx)(zs,{label:"Network",children:(0,q.jsx)(_n,{size:"sm",label:"Network",disabled:!1,value:t.network,onChange:i=>a({network:i}),options:Object.entries(F0).map(([i,r])=>({value:i,label:r.label}))})}),(0,q.jsx)(zs,{label:"CPU",children:(0,q.jsx)(_n,{size:"sm",label:"CPU",disabled:!1,value:String(t.cpu),onChange:i=>a({cpu:Number(i)}),options:W0.map(i=>({value:String(i),label:i===1?"Normal":`${i}\xD7 slower`}))})})]}),(0,q.jsx)(zs,{label:"Color scheme",children:(0,q.jsx)(Tp,{size:"sm",label:"Color scheme",value:t.colorScheme,onChange:i=>a({colorScheme:i}),options:[{value:"default",label:"Page default"},{value:"light",label:"Light",icon:"color-mode"},{value:"dark",label:"Dark",icon:"color-mode"}]})}),(0,q.jsx)(Cp,{checked:t.print,disabled:!1,onChange:i=>a({print:i}),children:"Print media"}),(0,q.jsx)("p",{className:"note",children:"Chrome shows a \u201Cstarted debugging this browser\u201D bar while any of these are on."})]})}var iE={error:"error",warning:"warning",info:"info",debug:"debug",log:"circle-small"};function M1({onClose:e,copy:t,pageContext:n}){let[o,a]=(0,Gi.useState)({console:[],network:[]}),[i,r]=(0,Gi.useState)("console");(0,Gi.useEffect)(()=>{let u=!0,d=async()=>{let k=await za({kind:"logs"});u&&k&&a(k)};d();let x=setInterval(()=>{d()},1e3);return()=>{u=!1,clearInterval(x)}},[]);let l=async()=>await za({kind:"logs"})??o,c=o.console.filter(u=>u.level==="error"),s=o.network.filter(ws),p=i==="console"?o.console.slice(-200).reverse():[],b=i==="console"?!p.length:!s.length;return(0,q.jsxs)(Ds,{title:"Console and network",onClose:e,children:[(0,q.jsxs)("div",{className:"console-tabs",children:[(0,q.jsx)(Tp,{size:"sm",label:"Show",className:"console-view",value:i,onChange:r,options:[{value:"console",label:"Console",icon:"terminal",count:c.length||void 0,tone:c.length?"error":void 0},{value:"network",label:"Failed requests",icon:"globe",count:s.length||void 0,tone:s.length?"error":void 0}]}),(0,q.jsx)(Se,{icon:"clear-all",label:"Clear",onClick:()=>{za({kind:"clearLogs"}).then(()=>a({console:[],network:[]}))}})]}),(0,q.jsxs)("div",{className:"log",children:[i==="console"?p.map(u=>(0,q.jsxs)("div",{className:`log-row level-${u.level}`,children:[(0,q.jsx)("span",{className:`log-icon codicon codicon-${iE[u.level]??"circle-small"}`,"aria-hidden":"true"}),(0,q.jsx)("span",{className:"log-text",children:u.text}),u.url&&(0,q.jsxs)("span",{className:"log-source",title:u.url,children:[u.url.split("/").pop(),u.line!==void 0?`:${u.line+1}`:""]})]},u.id)):s.map(u=>(0,q.jsxs)("div",{className:"log-row level-error",title:u.url,children:[(0,q.jsx)("span",{className:"log-icon codicon codicon-error","aria-hidden":"true"}),(0,q.jsxs)("span",{className:"log-text",children:[u.method," ",u.url]}),(0,q.jsx)("span",{className:"log-source",children:u.error??u.status})]},u.id)),b&&(0,q.jsxs)("div",{className:"log-empty",children:[(0,q.jsx)("span",{className:"codicon codicon-check-all","aria-hidden":"true"}),(0,q.jsx)("strong",{children:i==="console"?"No console messages yet":"No failed requests"}),(0,q.jsx)("span",{children:"They are recorded while the toolbar is open on this page."})]})]}),(0,q.jsxs)("div",{className:"panel-group",children:[(0,q.jsx)("span",{className:"panel-group-title",children:"Copy for AI"}),(0,q.jsxs)("div",{className:"button-row wrap",children:[(0,q.jsx)(je,{size:"sm",icon:"copy",onClick:()=>{l().then(u=>t(oy(u.console,location.href),"Console errors","errors"))},children:"Copy errors"}),(0,q.jsx)(je,{size:"sm",icon:"copy",onClick:()=>{l().then(u=>t(iy(u.network,location.href),"Failed requests","network"))},children:"Copy failed requests"}),(0,q.jsx)(je,{size:"sm",icon:"copy",onClick:()=>{n().then(u=>t(u,"Page context","page"))},children:"Copy page context"})]})]})]})}function A1({onClose:e,status:t}){return(0,q.jsxs)(Ds,{title:"VS Code link",onClose:e,children:[t.state==="connected"?(0,q.jsxs)("p",{className:"status status-connected",children:["Linked with ",t.peer??"VS Code",t.via==="hub"?" through the browser helper":"",". Captures are saved into your projects and offered to send; bookmarks sync both ways."]}):(0,q.jsx)(T1,{compact:!0,status:t,pair:n=>De({type:"pair",code:n}).then(o=>o.ok?o.status:{...t,error:o.error})}),(0,q.jsx)("div",{className:"button-row",children:(0,q.jsx)(je,{size:"sm",variant:"secondary",onClick:()=>{De({type:"openOptions"})},children:"Settings"})})]})}function z1({onClose:e,map:t,overrides:n,linked:o}){let[a,i]=(0,Gi.useState)(""),r=Object.keys(n).length;return(0,q.jsxs)(Ds,{title:"Keyboard shortcuts",onClose:e,children:[(0,q.jsxs)("div",{className:"shortcuts-bar",children:[(0,q.jsx)(B0,{size:"sm",value:a,onChange:i}),(0,q.jsx)(y1,{icon:"discard",confirmLabel:"Click again to reset",title:"Reset all shortcuts (here and in VS Code)",disabled:!r,onConfirm:()=>{f1()},children:"Reset all"})]}),(0,q.jsxs)("p",{className:"note shortcuts-sync",children:[(0,q.jsx)("span",{className:`codicon codicon-${o?"sync":"cloud"}`,"aria-hidden":"true"}),o?"Shared with VS Code: changes here apply there too, and the other way round.":"Saved to your browser account. They sync with VS Code once it is linked."]}),(0,q.jsx)(w1,{actions:pn,scopes:c1,map:t,overrides:n,query:a,labelOf:r1,scopeLabel:l1,onSetKeys:(l,c)=>{kp(n,l,c)},onReset:l=>{kp(n,l,void 0)}})]})}var mn=R(Ae());var _e=R(j()),rE=[{value:"fit",label:"Fit"},...[.5,.75,1,1.25].map(e=>({value:String(e),label:`${e*100}%`}))],lE=[{value:"custom",label:"Custom size",icon:"screen-full"},...Bi.map(e=>({value:e.id,label:e.name,detail:`${e.width}\xD7${e.height}`,group:e.group,icon:e.group==="Desktops"?"vm":"device-mobile"}))],O1=32,cE=36;function D1({top:e,device:t,onDevice:n,zoom:o,onZoom:a,src:i,frameRef:r,emulationActive:l,onEmulation:c,onClose:s}){let p=(0,mn.useRef)(null),b=(0,mn.useRef)(null),[u,d]=(0,mn.useState)({width:0,height:0});(0,mn.useLayoutEffect)(()=>{let h=p.current,S=()=>d({width:h.clientWidth,height:h.clientHeight}),v=new ResizeObserver(S);return v.observe(h),S(),()=>v.disconnect()},[]);let[x,k]=(0,mn.useState)(null),E=x??ty(o,t,{width:u.width-O1*2,height:u.height-O1*2-cE}),m=(0,mn.useRef)(null),g=(h,S)=>(0,_e.jsx)("div",{className:`rv-handle rv-handle-${h}`,role:"separator","aria-label":S,title:S,onPointerDown:v=>{v.preventDefault(),v.currentTarget.setPointerCapture(v.pointerId),m.current={x:v.clientX,y:v.clientY,width:t.width,height:t.height},k(E)},onPointerMove:v=>{let T=m.current;if(!T)return;let z=(M,B)=>Math.round(Math.min(ip,Math.max(ap,M+2*B/E)));n({...t,presetId:void 0,width:h==="y"?t.width:z(T.width,v.clientX-T.x),height:h==="x"?t.height:z(T.height,v.clientY-T.y)})},onPointerUp:()=>{m.current=null,k(null)},onPointerCancel:()=>{m.current=null,k(null)}}),f=(h,S)=>{let v=Math.round(Number(S));!Number.isFinite(v)||v<ap||n({...t,presetId:void 0,[h]:Math.min(ip,v)})},y=Bi.find(h=>h.id===t.presetId);return(0,_e.jsxs)("div",{className:`rv${x!==null?" dragging":""}`,style:{top:e},children:[(0,_e.jsxs)("div",{className:"rv-controls",role:"toolbar","aria-label":"Responsive view",children:[(0,_e.jsx)(_n,{size:"sm",label:"Device",className:"rv-device",value:y?y.id:"custom",options:lE,onChange:h=>{let S=Bi.find(v=>v.id===h);S?n(ks(S)):(n({...t,presetId:void 0}),requestAnimationFrame(()=>b.current?.focus()))}}),(0,_e.jsx)(R1,{label:"Width",value:t.width,onCommit:h=>f("width",h),inputRef:b}),(0,_e.jsx)("span",{className:"rv-times","aria-hidden":"true",children:"\xD7"}),(0,_e.jsx)(R1,{label:"Height",value:t.height,onCommit:h=>f("height",h)}),(0,_e.jsx)(Se,{icon:"sync",label:"Rotate",onClick:()=>n(ey(t))}),(0,_e.jsx)("span",{className:"rv-divider","aria-hidden":"true"}),(0,_e.jsx)(_n,{size:"sm",label:"Zoom",className:"rv-zoom",value:String(o),options:rE,onChange:h=>a(h==="fit"?"fit":Number(h))}),(0,_e.jsx)(Se,{icon:"settings",label:"Network, CPU, color scheme and user agent",active:l,onClick:c}),(0,_e.jsx)(Se,{icon:"close",label:"Close the responsive view",onClick:s})]}),(0,_e.jsx)("div",{className:"rv-area",ref:p,children:(0,_e.jsxs)("div",{className:"rv-stage",children:[(0,_e.jsxs)("div",{className:"rv-frame",children:[(0,_e.jsx)("div",{className:"rv-screen",style:{width:t.width*E,height:t.height*E},children:i&&(0,_e.jsx)("iframe",{ref:r,title:`${y?.name??"Custom size"} preview`,src:i,sandbox:"allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-top-navigation-by-user-activation",style:{width:t.width,height:t.height,transform:`scale(${E})`}})}),g("x","Drag to change the width"),g("y","Drag to change the height"),g("xy","Drag to change the size")]}),(0,_e.jsxs)("div",{className:"rv-caption",children:[y?.name??"Custom size"," \xB7 ",t.width," \xD7 ",t.height,E!==1&&` \xB7 ${Math.round(E*100)}%`]})]})})]})}function R1({label:e,value:t,onCommit:n,inputRef:o}){let[a,i]=(0,mn.useState)(null),r=(0,mn.useRef)(!1),l=()=>{a!==null&&n(a),i(null)};return(0,_e.jsx)(vs,{size:"sm",className:"rv-size",ref:o,"aria-label":e,inputMode:"numeric",value:a??String(t),onChange:c=>i(c.target.value.replace(/\D/g,"")),onFocus:c=>{c.currentTarget.select(),r.current=!0},onMouseUp:c=>{r.current&&c.preventDefault(),r.current=!1},onBlur:l,onKeyDown:c=>{c.key==="Enter"?l():c.key==="Escape"&&i(null)}})}var He=R(Ae()),_s="toolbarPosition",Qi=8,_1=12,sE={k:700,c:40},uE={k:320,c:20},H1=24,dE=()=>matchMedia("(prefers-reduced-motion: reduce)").matches,Hs=e=>({width:e?.offsetWidth??0,height:e?.offsetHeight??0}),B1=e=>Math.round(e*devicePixelRatio)/devicePixelRatio,Bs=(e,t)=>{e&&(e.style.transform=`translate(${B1(t.x)}px, ${B1(t.y)}px)`)};function L1(e,t){let n=(0,He.useRef)(null),[o,a]=(0,He.useState)(null),[i,r]=(0,He.useState)(!1),l=(0,He.useRef)({x:0,y:0}),c=(0,He.useRef)({x:0,y:0}),s=(0,He.useRef)({x:0,y:0}),p=(0,He.useRef)(null),b=(0,He.useRef)(!1),u=(0,He.useRef)(0),d=(0,He.useRef)(0),x=(0,He.useCallback)(v=>{let{width:T,height:z}=Hs(t.current),M=Math.max(Qi,innerWidth-T-Qi),B=Math.max(Qi,innerHeight-z-Qi);return{x:Math.min(M,Math.max(Qi,v.x)),y:Math.min(B,Math.max(Qi,v.y))}},[t]),k=(0,He.useCallback)(()=>{let{width:v,height:T}=Hs(t.current);a({...l.current,width:v,height:T})},[t]),E=(0,He.useCallback)(v=>{let T=Math.min(.032,(v-d.current)/1e3||.016);d.current=v;let{k:z,c:M}=p.current?sE:uE,B=!1;for(let H of["x","y"]){let I=s.current[H]-l.current[H];c.current[H]+=(z*I-M*c.current[H])*T,l.current[H]+=c.current[H]*T,(Math.abs(I)>.3||Math.abs(c.current[H])>4)&&(B=!0)}if(!B&&!p.current){l.current={...s.current},c.current={x:0,y:0},Bs(n.current,l.current),u.current=0,k();return}Bs(n.current,l.current),u.current=requestAnimationFrame(E)},[k]),m=(0,He.useCallback)(v=>{if(s.current=v,dE()){l.current={...v},c.current={x:0,y:0},Bs(n.current,l.current),p.current||k();return}u.current||(d.current=performance.now(),u.current=requestAnimationFrame(E))},[k,E]),g=v=>{chrome.storage.local.set({[_s]:v}).catch(()=>{})};(0,He.useLayoutEffect)(()=>{if(!e)return;let v=!0,T=z=>{if(!v)return;let M=z;b.current=typeof M?.x=="number"&&typeof M.y=="number";let B=M&&b.current?{x:M.x,y:M.y}:{x:(innerWidth-Hs(t.current).width)/2,y:_1};l.current=x(B),s.current={...l.current},c.current={x:0,y:0},Bs(n.current,l.current),k()};return T(void 0),chrome.storage.local.get(_s).then(z=>z[_s]&&T(z[_s])).catch(()=>{}),()=>{v=!1,cancelAnimationFrame(u.current),u.current=0,p.current=null}},[e,x,k,t]),(0,He.useEffect)(()=>{if(!e)return;let v=()=>{if(p.current)return;let z={x:(innerWidth-Hs(t.current).width)/2,y:_1};m(x(b.current?s.current:z))},T=new ResizeObserver(v);return t.current&&T.observe(t.current),addEventListener("resize",v),()=>{T.disconnect(),removeEventListener("resize",v)}},[e,x,m,t]);let f=v=>{v.button===0&&(v.preventDefault(),v.currentTarget.setPointerCapture(v.pointerId),b.current=!0,p.current={id:v.pointerId,x:v.clientX-l.current.x,y:v.clientY-l.current.y},r(!0))},y=v=>{let T=p.current;if(!T||T.id!==v.pointerId)return;let z={x:v.clientX-T.x,y:v.clientY-T.y},M=x(z);m({x:M.x+(z.x-M.x)*.25,y:M.y+(z.y-M.y)*.25})},h=v=>{let T=p.current;if(!T||T.id!==v.pointerId)return;p.current=null,r(!1);let z=x(s.current);m(z),g(z)};return{ref:n,rest:o,dragging:i,handle:{onPointerDown:f,onPointerMove:y,onPointerUp:h,onPointerCancel:h,onKeyDown:v=>{let T=v.shiftKey?H1*4:H1,M={ArrowLeft:{x:-T,y:0},ArrowRight:{x:T,y:0},ArrowUp:{x:0,y:-T},ArrowDown:{x:0,y:T}}[v.key];if(!M)return;v.preventDefault(),v.stopPropagation(),b.current=!0;let B=x({x:s.current.x+M.x,y:s.current.y+M.y});m(B),g(B)}}}}var Nt=R(Ae());var fE=e=>e.replace(/^data:image\/\w+;base64,/,"");function U1(e,t){return{path:t,name:e?.name??t.split("/").pop()??t}}function j1(e){let[t,n]=(0,Nt.useState)(null),o=(0,Nt.useRef)(null),a=(0,Nt.useRef)(0),i=(0,Nt.useCallback)(d=>{o.current=d,n(d)},[]),r=(0,Nt.useCallback)(d=>{o.current&&i({...o.current,...d})},[i]),l=(0,Nt.useCallback)(async(d,x,k)=>{if(!d.length)return;let E=d.flatMap(y=>y.image?[y.image]:[]),m={title:x,detail:k,taken:d,images:E,projects:[],targets:[],harnesses:[]},g=++a.current,f=()=>a.current!==g||!o.current;if(e.projects){i({...m,status:{tone:"busy",text:"Saving\u2026"}});let y=await De({type:"projects",url:location.href}),h=y.ok?y.projects??[]:[],S=y.ok?y.suggested??h[0]?.path:void 0;if(!S){if(f())return;i({...m,projects:h,status:{tone:"error",text:y.ok?"Not saved: no project. Open one in VS Code, or start an agent in agentmux.":y.error}});return}let v=await Promise.all(d.map(M=>M.image?g1(M.image):void 0)),T=await De({type:"saveCapture",project:S,url:location.href,captures:d.map((M,B)=>({kind:M.kind,title:M.title,text:M.text,group:M.group,groupIndex:M.groupIndex,image:M.image?fE(M.image):void 0,thumb:v[B]}))});if(f())return;let z=h.find(M=>M.path===S);i({...m,project:U1(z,S),ids:T.ok?T.ids:void 0,projects:h,targets:z?.targets??[],defaultTarget:z?.defaultTarget,harnesses:z?.harnesses??[],status:T.ok?void 0:{tone:"error",text:T.error}});return}i({...m,empty:"Not linked: install the browser helper or link VS Code to send it to an agent."})},[e.projects,i]),c=(0,Nt.useCallback)(async(d,x)=>{let k=o.current;if(!k)return;let E=a.current;r({status:{tone:"busy",text:"Sending\u2026"}});let m=k.ids&&k.project?await De({type:"sendSaved",project:k.project.path,ids:k.ids,target:d,open:x}):{ok:!1,error:"Not saved, so nothing can be sent."};if(!(a.current!==E||!o.current)){if(!m.ok){r({status:{tone:"error",text:m.error}});return}r({status:{tone:"ok",text:`Sent to ${m.sentTo??"the agent"}`}}),setTimeout(()=>{a.current===E&&o.current?.status?.tone==="ok"&&i(null)},900)}},[i,r]),s=(0,Nt.useCallback)(async d=>{let x=o.current;if(!x?.ids||!x.project||d===x.project.path)return;let k=a.current,E=await De({type:"moveSaved",project:x.project.path,to:d,ids:x.ids});if(a.current!==k)return;if(!E.ok){r({status:{tone:"error",text:E.error}});return}let m=await De({type:"projects",url:location.href});if(a.current!==k)return;let g=m.ok?m.projects??x.projects:x.projects,f=g.find(y=>y.path===d);r({project:U1(f,d),projects:g,targets:f?.targets??[],defaultTarget:f?.defaultTarget,harnesses:f?.harnesses??[],status:void 0})},[r]),p=(0,Nt.useCallback)(async()=>{let d=o.current;if(!d)return;let x=d.images[0]?await Rs(d.images[0]):await ml(d.taken.map(k=>k.text??"").join(`

`));r({status:x?{tone:"ok",text:"Copied"}:{tone:"error",text:"Could not copy"}})},[r]),b=(0,Nt.useCallback)(()=>{let d=o.current;if(d){if(d.images.length)for(let x of d.images)De({type:"download",dataUrl:x,filename:`Inkspect/${Mp()}`});else{let x=d.taken.map(E=>E.text??"").join(`

`),k=`data:text/markdown;base64,${btoa(unescape(encodeURIComponent(x)))}`;De({type:"download",dataUrl:k,filename:`Inkspect/${Mp().replace(/\.png$/,".md")}`})}r({status:{tone:"ok",text:"Downloading"}})}},[r]),u=(0,Nt.useCallback)(()=>{a.current++,i(null)},[i]);return{offer:t,capture:l,sendTo:c,moveTo:s,copyAgain:p,download:b,close:u}}var V=R(j()),pE=new Set(i1.map(e=>e.id)),Ls=" (not available in the responsive view yet)",mE=/\b(failed|could not|can't|cannot|did not|didn't|nothing was|not linked|not running)\b/i,gE={highlighter:{...wa,color:"#ffd60a",width:16,opacity:.4},marker:{...wa,width:8},pencil:{...wa,width:2}},bE={area:"Drawing screenshot",groups:"Drawing screenshot",clean:"Drawing area",viewport:"Annotated viewport",fullPage:"Annotated full page"};function q1({host:e,hideHost:t,toggleSignal:n}){let[o,a]=(0,_.useState)(!1),[i,r]=(0,_.useState)(null),[l,c]=(0,_.useState)(null),[s,p]=(0,_.useState)(null),[b,u]=(0,_.useState)(null),[d,x]=(0,_.useState)([]),[k,E]=(0,_.useState)({state:"offline"}),[m,g]=(0,_.useState)(!1),[f,y]=(0,_.useState)(()=>({map:ms({},sl),overrides:{}})),[h,S]=(0,_.useState)(null),[v,T]=(0,_.useState)(!1),z=(0,_.useRef)(null),M=(0,_.useRef)(null),[B,H]=(0,_.useState)(null),[I,ne]=(0,_.useState)("fit"),[D,U]=(0,_.useState)(null),[A,G]=(0,_.useState)(C1),ae=(0,_.useRef)(null),ge=(0,_.useRef)(null),[Mt,ht]=(0,_.useState)([]),[on,Zi]=(0,_.useState)([]),[Us,Oa]=(0,_.useState)([]),[Kt,gl]=(0,_.useState)("pen"),[Ko,Ra]=(0,_.useState)(gE),[Q1,Z1]=(0,_.useState)([]),[Ap,zp]=(0,_.useState)(!0),[Pi,P1]=(0,_.useState)({x:scrollX,y:scrollY}),[Xo,$1]=(0,_.useState)({width:innerWidth,height:innerHeight}),$i=(0,_.useRef)(Mt),[Da,J1]=(0,_.useState)(null),[I1,Op]=(0,_.useState)(!1);(0,_.useEffect)(()=>{$i.current=Mt},[Mt]);let Rp=(0,_.useRef)(0);(0,_.useEffect)(()=>{n!==Rp.current&&(Rp.current=n,a(w=>(w&&(r(null),c(null),p(null),H(null),U(null)),!w)))},[n]);let{ref:F1,rest:gn,dragging:Dp,handle:W1}=L1(o,z),Me=B!==null;(0,_.useEffect)(()=>{if(!Me)return;let w=document.documentElement,N=w.style.getPropertyValue("overflow"),O=w.style.getPropertyPriority("overflow");return w.style.setProperty("overflow","hidden","important"),()=>{N?w.style.setProperty("overflow",N,O):w.style.removeProperty("overflow")}},[Me]),(0,_.useEffect)(()=>d1((w,N)=>y({map:w,overrides:N.overrides})),[]),(0,_.useEffect)(()=>{if(!o)return;let w="",N=(Ee=!1)=>{!Ee&&location.href===w||(w=location.href,De({type:"isBookmarked",url:w}).then(an=>an.ok&&T(!!an.bookmarked)))};N(!0);let O=setInterval(()=>N(),1e3),L=()=>N(!0);return addEventListener("focus",L),()=>{clearInterval(O),removeEventListener("focus",L)}},[o]);let Go=(0,_.useCallback)(w=>{let N=f.map[w]?.[0];return N?qt(N,sl):void 0},[f.map]),Qo=(w,N)=>{let O=Go(N);return O?`${w} (${O})`:w};(0,_.useEffect)(()=>{Np().then(L=>ge.current=L),De({type:"bridgeStatus"}).then(L=>L.ok&&L.status&&E(L.status));let w=L=>{L.type==="bridgeStatus"&&L.status&&E(L.status)};chrome.runtime.onMessage.addListener(w);let N=()=>P1({x:scrollX,y:scrollY}),O=()=>$1({width:innerWidth,height:innerHeight});return window.addEventListener("scroll",N,{passive:!0}),window.addEventListener("resize",O),()=>{chrome.runtime.onMessage.removeListener(w),window.removeEventListener("scroll",N),window.removeEventListener("resize",O)}},[]);let qe=(0,_.useCallback)((w,N={})=>{let O=N.tone??(mE.test(w)?"error":"info");u({id:Date.now(),message:w,...N,tone:O})},[]),js=B?.userAgent,_p=B?.touch??!1;(0,_.useEffect)(()=>{let w=Me&&A.agent&&js?{userAgent:js,touch:_p}:void 0,N=Me?{agent:w,network:A.network,cpu:A.cpu,colorScheme:A.colorScheme,print:A.print}:{network:"none",cpu:1,colorScheme:"default",print:!1};De({type:"emulate",request:N}).then(O=>{O.ok||qe(O.error)})},[Me,js,_p,A,qe]);let Hp=(0,_.useCallback)(async()=>{r(null),c(O=>O==="console"?null:O),H(O=>O??ks(Bi[0]));let w=location.href,N=await De({type:"allowFraming",url:w});N.ok||qe(`The page may not load in the frame: ${N.error}`),U(w)},[qe]),bl=(0,_.useCallback)(()=>{H(null),U(null),c(w=>w==="emulation"?null:w),De({type:"endFraming"})},[]);(0,_.useEffect)(()=>{if(!b||b.held)return;let w=setTimeout(()=>u(N=>N?.id===b.id?null:N),b.tone==="error"?8e3:3500);return()=>clearTimeout(w)},[b]);let Zo=(0,_.useCallback)(()=>{let w=t();return g(!0),()=>{w(),g(!1)}},[t]),hl=k.state==="connected",{offer:rt,capture:_a,sendTo:ex,moveTo:tx,copyAgain:nx,download:ox,close:ax}=j1(k),Bp=(0,_.useCallback)(async(w,N,O="text")=>{let L=await ml(w);await _a([{kind:O,title:N,text:w}],N,L?"Copied to the clipboard.":void 0)},[_a]),Ln=(0,_.useCallback)(async(w,N)=>{let O=typeof w=="string"?[w]:w;if(!O.length)return;let L=O.length>1,Ee=await Rs(O[0]),an=L?crypto.randomUUID():void 0;await _a(O.map((rn,vt)=>({kind:"screenshot",title:L?`${N} ${vt+1} of ${O.length}`:N,image:rn,group:an,groupIndex:L?vt:void 0})),L?`${O.length} ${N.toLowerCase()}`:N,Ee?L?"The first is copied to the clipboard.":"Copied to the clipboard.":void 0)},[_a]),ao=(0,_.useCallback)(async w=>{if(w==="region")return r({kind:"region"});if(w==="element")return r({kind:"inspect",purpose:"screenshot"});try{let N=w==="viewport"?wp():Sp(),{dataUrl:O}=await dl(N,Zo);await Ln(O,w==="viewport"?"Screenshot":"Full-page screenshot")}catch(N){qe(`Screenshot failed: ${N instanceof Error?N.message:String(N)}`)}},[Ln,Zo,qe]),Lp=(0,_.useCallback)(async w=>{let N=ge.current?.maxHtml??2e3;w.setAttribute(xp,"");try{let O=await za({kind:"collect",maxHtml:N},1500);if(O&&!O.error&&O.tag)return O}finally{w.removeAttribute(xp)}return{...P0(w,N,$0),...xs(w)}},[]),qs=(0,_.useCallback)(async w=>{let N=w.getBoundingClientRect();return dl({x:N.x+scrollX,y:N.y+scrollY,width:N.width,height:N.height},Zo)},[Zo]),ix=async w=>{let N=d;if(x([]),w!=="clear"){if(w==="copy")return vl(N);try{let O=[];for(let L of N)O.push((await qs(L)).dataUrl);await Ln(O,N.length===1?"Element screenshot":"Element screenshots")}catch(O){qe(`Screenshot failed: ${O instanceof Error?O.message:String(O)}`)}}},vl=(0,_.useCallback)(async w=>{let N=ge.current??await Np(),O=await Promise.all(w.map(Lp)),L=O.length===1,Ee=await ml(np(O,N.copyFormat,N.fields)),an=L?void 0:crypto.randomUUID();await _a(O.map((rn,vt)=>({kind:"element",title:`Element ${al(rn)}`,text:np([rn],"markdown",N.fields),group:an,groupIndex:L?void 0:vt})),L?`Element ${al(O[0])}`:`${O.length} elements`,Ee?"Its details are copied to the clipboard.":void 0)},[Lp,_a]),rx=(0,_.useCallback)(async(w,N)=>{let O=i?.kind==="inspect"&&i.purpose==="screenshot";if(O&&r(null),N.add&&!O){x(L=>L.includes(w)?L.filter(Ee=>Ee!==w):[...L,w]);return}if(O||N.screenshot){try{let{dataUrl:L}=await qs(w);await Ln(L,"Element screenshot")}catch(L){qe(`Screenshot failed: ${L instanceof Error?L.message:String(L)}`)}return}await vl([w])},[qs,vl,Ln,qe,i]),Up=(0,_.useCallback)(async()=>{let w=await za({kind:"logs"});return ry({url:location.href,title:document.title,viewport:{width:innerWidth,height:innerHeight},selection:getSelection()?.toString()||void 0,console:w?.console??[],network:w?.network??[]})},[]),Ys=(0,_.useCallback)((w,N)=>{N&&(Zi(O=>[...O.slice(-99),$i.current]),Oa([])),ht(w)},[]),jp=(0,_.useCallback)(()=>{Zi(w=>{let N=w.at(-1);return N?(Oa(O=>[...O,$i.current]),ht(N),w.slice(0,-1)):w})},[]),qp=(0,_.useCallback)(()=>{Oa(w=>{let N=w.at(-1);return N?(Zi(O=>[...O,$i.current]),ht(N),w.slice(0,-1)):w})},[]),Po=(0,_.useCallback)(async w=>{let N=$i.current;if(!N.length&&(w==="area"||w==="groups"||w==="clean")){qe("Draw something first.");return}let O=ge.current?.annotationPadding??40,L=w==="groups"?K0(N,80):[N],Ee=[];for(let an of L){let rn=w==="viewport"?wp():w==="fullPage"?Sp():V0(an,O);if(rn)try{let vt=await dl(rn,Zo),px=new Uint8Array(await(await fetch(vt.dataUrl)).arrayBuffer()),mx=await Cy(px,"image/png",vt.area,w==="clean"?[]:an);Ee.push(`data:image/png;base64,${mx}`)}catch(vt){qe(`Screenshot failed: ${vt instanceof Error?vt.message:String(vt)}`);return}}await Ln(Ee,Ee.length>1?"Drawings":bE[w])},[Ln,Zo,qe]),Yp=Mt.some(w=>w.kind==="blur")||i?.kind==="draw"&&Kt==="blur",Vs=Da&&Da.x===Pi.x&&Da.y===Pi.y&&Da.width===Xo.width&&Da.height===Xo.height?Da.canvas:void 0;(0,_.useEffect)(()=>{if(!o||!Yp||Vs)return;let w=!1,N=setTimeout(()=>{let O={x:scrollX,y:scrollY,width:innerWidth,height:innerHeight};ul(()=>(Op(!0),()=>Op(!1))).then(L=>{if(w)return;let Ee=document.createElement("canvas");Ee.width=Math.round(O.width*devicePixelRatio),Ee.height=Math.round(O.height*devicePixelRatio),Ee.getContext("2d").drawImage(L,0,0,Ee.width,Ee.height),J1({canvas:Ee,...O})}).catch(()=>{})},250);return()=>{w=!0,clearTimeout(N)}},[o,Yp,Vs,Pi.x,Pi.y,Xo.width,Xo.height]);let yl=w=>r(N=>N?.kind===w.kind?null:w),lx=(w,N,O)=>{let L=w.currentTarget.getBoundingClientRect();p({x:L.left,y:L.bottom+4,items:N}),S(O??null)},Vp=(w,N,O)=>{let L=z.current?.querySelector(w);if(!L)return;let Ee=L.getBoundingClientRect();p({x:Ee.left,y:Ee.bottom+4,items:N}),S(O)},Ks=()=>{p(null),S(null)},Ji=w=>{let N=Ko[Kt]??wa;Ra(O=>({...O,[Kt]:{...N,...w}})),w.color&&Z1(O=>[w.color,...O.filter(L=>L!==w.color)].slice(0,6))},cx=()=>{De({type:"openSaved"}).then(w=>{w.ok||qe(w.error,{tone:"error"})})},Kp=()=>{De(v?{type:"unbookmarkPage",url:location.href}:{type:"bookmarkPage",url:location.href,title:document.title}).then(w=>{if(!w.ok)return qe(w.error,{tone:"error"});T(!!w.bookmarked),qe(w.bookmarked?"Bookmarked":"Bookmark removed",w.bookmarked?{tone:"success",detail:hl?"It syncs to VS Code.":void 0}:{})})},Xp=()=>[{label:"Visible area",icon:"device-camera",shortcut:Go("shot.viewport"),onSelect:()=>{ao("viewport")}},{label:"Full page",icon:"file-media",shortcut:Go("shot.fullPage"),onSelect:()=>{ao("fullPage")}},{label:"Select region...",icon:"screen-full",shortcut:Go("shot.region"),onSelect:()=>{ao("region")}},{label:"Select element...",icon:"inspect",shortcut:Go("shot.element"),onSelect:()=>{ao("element")}}],Gp=()=>Yy(w=>{Po(w)},Go),Qp=(0,_.useRef)({});if((0,_.useEffect)(()=>{let w=Object.fromEntries(jy.map(L=>[`draw.${L}`,()=>gl(L)])),N=Object.fromEntries(_i.slice(0,9).map((L,Ee)=>[`draw.color${Ee+1}`,()=>Ji({color:L})])),O=Ko[Kt]?.width??wa.width;Qp.current={"mode.inspect":()=>!Me&&yl({kind:"inspect",purpose:"copy"}),"mode.draw":()=>!Me&&yl({kind:"draw"}),"mode.screenshot":()=>Me?void 0:Vp(".shot-button",Xp(),"screenshot"),"mode.device":()=>Me?bl():void Hp(),"mode.devtools":()=>!Me&&c(L=>L==="console"?null:"console"),"page.bookmark":Kp,"open.shortcuts":()=>c(L=>L==="shortcuts"?null:"shortcuts"),...w,...N,"draw.thinner":()=>Ji({width:Math.max(1,O-(O>6?2:1))}),"draw.thicker":()=>Ji({width:Math.min(24,O+(O>=6?2:1))}),"draw.fill":()=>Ji({fill:!(Ko[Kt]?.fill??!1)}),"draw.undo":jp,"draw.redo":qp,"draw.clear":()=>Ys([],!0),"draw.visible":()=>zp(L=>!L),"draw.capture":()=>{Po("area")},"draw.captureGroups":()=>{Po("groups")},"draw.captureClean":()=>{Po("clean")},"draw.captureViewport":()=>{Po("viewport")},"draw.captureFullPage":()=>{Po("fullPage")},"draw.captureMenu":()=>Vp(".draw-capture",Gp(),"draw"),"draw.exit":()=>r(null),"shot.viewport":()=>{ao("viewport")},"shot.fullPage":()=>{ao("fullPage")},"shot.region":()=>{ao("region")},"shot.element":()=>{ao("element")},"shot.drawing":()=>{Po("area")}}}),(0,_.useEffect)(()=>{if(l)return us(()=>[M.current],ss(),()=>c(null),w=>!z.current||!w.composedPath().includes(z.current)||y0(w))},[l]),(0,_.useEffect)(()=>{if(!o)return;let w=N=>{if(l==="shortcuts"||rt)return;let O=z.current?.getRootNode(),L=N.composedPath().includes(e)&&O instanceof ShadowRoot?O.activeElement:N.composedPath()[0];if(L instanceof HTMLElement&&(L.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(L.tagName))||i?.kind==="inspect"||i?.kind==="region")return;if(N.key==="Escape"&&(s||l&&i?.kind!=="draw")){s?Ks():c(null),N.preventDefault(),N.stopImmediatePropagation();return}let an=s?h?[h]:[]:i?.kind==="draw"?["draw","global"]:["global"],rn=nl(f.map,an,eo(N)),vt=rn&&pE.has(rn.id)&&Qp.current[rn.id];vt&&(N.preventDefault(),N.stopImmediatePropagation(),s&&Ks(),vt())};return window.addEventListener("keydown",w,!0),()=>window.removeEventListener("keydown",w,!0)},[o,i,l,s,h,f.map,e,rt]),!o)return null;let sx=!!gn&&gn.x+gn.width/2>Xo.width/2,ux=!!gn&&gn.y+gn.height/2>Xo.height/2,dx=gn&&gn.y<64?gn.y+gn.height+8:0,fx={scale:1,scroll:Pi,bounds:{left:0,top:0,...Xo}},Zp=Ko[Kt]??wa;return(0,V.jsxs)("div",{className:`inkspect${m?" capturing":""}${I1?" sampling":""}`,children:[(Mt.length>0||i?.kind==="draw")&&(0,V.jsx)("div",{className:"draw-host",children:(0,V.jsx)(Ny,{mapper:fx,shapes:Mt,visible:Ap,interactive:i?.kind==="draw",tool:Kt,style:Zp,onChange:Ys,liveRedactions:!0,pixelSource:Vs})}),i?.kind==="inspect"&&!rt&&(0,V.jsx)(v1,{host:e,map:f.map,purpose:i.purpose,selection:d,onPick:(w,N)=>{rx(w,N)},onCommit:w=>{let N=d.length?d:w?[w]:[];N.length&&vl(N),x([])},onExit:()=>{r(null),x([])},actionOf:w=>nl(f.map,["inspect"],eo(w))?.id}),i?.kind==="inspect"&&!rt&&d.length>0&&(0,V.jsx)(Xy,{className:"toolbar-selection-bar",count:d.length,map:f.map,onAction:w=>{ix(w)}}),i?.kind==="region"&&(0,V.jsx)(hE,{onCancel:()=>r(null),onDone:w=>{r(null),dl({...w,x:w.x+scrollX,y:w.y+scrollY},Zo).then(({dataUrl:N})=>Ln(N,"Region screenshot")).catch(N=>qe(`Screenshot failed: ${String(N)}`))}}),B&&(0,V.jsx)(D1,{top:dx,device:B,onDevice:H,zoom:I,onZoom:ne,src:D,frameRef:ae,emulationActive:l==="emulation",onEmulation:()=>c(w=>w==="emulation"?null:"emulation"),onClose:bl}),(0,V.jsxs)("div",{ref:F1,className:["float",sx&&"align-right",ux&&"above",Dp&&"dragging"].filter(Boolean).join(" "),children:[(0,V.jsxs)("div",{className:"bar",ref:z,role:"toolbar","aria-label":"Inkspect",children:[(0,V.jsxs)("div",{className:"bar-row",children:[(0,V.jsxs)("span",{className:"bar-brand",children:[(0,V.jsx)("img",{src:chrome.runtime.getURL("icons/32.png"),alt:""}),"Inkspect"]}),(0,V.jsx)("span",{className:"separator"}),(0,V.jsx)(Se,{icon:"inspect",label:`${Qo("Select an element to copy its details for AI","mode.inspect")}${Me?Ls:""}`,disabled:Me,active:i?.kind==="inspect",onClick:()=>yl({kind:"inspect",purpose:"copy"})}),(0,V.jsx)(Se,{icon:"edit",label:`${Qo("Draw on the page","mode.draw")}${Me?Ls:""}`,disabled:Me,active:i?.kind==="draw",onClick:()=>yl({kind:"draw"})}),(0,V.jsx)(Se,{icon:"device-camera",label:Qo("Screenshot","mode.screenshot"),className:"shot-button",onClick:w=>lx(w,Me?[{label:"Device screen",icon:"device-mobile",onSelect:()=>{let N=ae.current?.parentElement;N&&m1(N).then(O=>Ln(O,"Device screenshot")).catch(O=>qe(`Screenshot failed: ${String(O)}`))}}]:Xp(),Me?void 0:"screenshot")}),(0,V.jsx)(Se,{icon:"device-mobile",label:Qo("Responsive view","mode.device"),active:Me,onClick:()=>Me?bl():void Hp()}),(0,V.jsx)(Se,{icon:"debug-console",label:`${Qo("Console and network (copy errors for AI)","mode.devtools")}${Me?Ls:""}`,disabled:Me,active:l==="console",onClick:()=>c(w=>w==="console"?null:"console")}),(0,V.jsx)(Se,{icon:"copy",label:`Copy page context for AI${Me?Ls:""}`,disabled:Me,onClick:()=>{Up().then(w=>Bp(w,"Page context","page"))}}),(0,V.jsx)(Se,{icon:v?"star-full":"star-empty",label:Qo(v?"Remove bookmark":"Bookmark this page","page.bookmark"),className:v?"bookmarked":void 0,onClick:Kp}),(0,V.jsx)("span",{className:"separator"}),(0,V.jsx)(je,{size:"sm",variant:"ghost",icon:"layout-sidebar-right",className:"saved-button",title:"Saved captures of this page's project, in the side panel",onClick:cx,children:"Saved"}),(0,V.jsx)("span",{className:"separator"}),(0,V.jsx)(Se,{icon:"keyboard",label:Qo("Keyboard shortcuts (shared with VS Code)","open.shortcuts"),active:l==="shortcuts",onClick:()=>c(w=>w==="shortcuts"?null:"shortcuts")}),(0,V.jsx)(Se,{icon:hl?"plug":"debug-disconnect",label:hl?`Linked with ${k.peer??"VS Code"}`:"Link with VS Code",active:l==="link",className:`link-${k.state}`,onClick:()=>c(w=>w==="link"?null:"link")}),(0,V.jsx)(Se,{icon:"close",label:"Close toolbar",onClick:()=>{bl(),r(null),c(null),a(!1)}}),(0,V.jsx)(Vy,{label:"Move the toolbar (drag, or use the arrow keys)",dragging:Dp,...W1})]}),i?.kind==="draw"&&(0,V.jsx)(qy,{tool:Kt,style:Zp,recentColors:Q1,canUndo:on.length>0,canRedo:Us.length>0,hasShapes:Mt.length>0,visible:Ap,onTool:gl,onStyle:Ji,keyOf:Go,onUndo:jp,onRedo:qp,onClear:()=>Ys([],!0),onToggleVisible:()=>zp(w=>!w),onCapture:(w,N)=>{p({x:w,y:N,items:Gp()}),S("draw")},onClose:()=>r(null)})]}),l&&(0,V.jsxs)("div",{className:"panel-dock",ref:M,children:[l==="emulation"&&(0,V.jsx)(N1,{onClose:()=>c(null),value:A,onChange:G}),l==="console"&&(0,V.jsx)(M1,{onClose:()=>c(null),toast:qe,copy:(w,N,O)=>{Bp(w,N,O)},pageContext:Up}),l==="shortcuts"&&(0,V.jsx)(z1,{onClose:()=>c(null),map:f.map,overrides:f.overrides,linked:hl}),l==="link"&&(0,V.jsx)(A1,{onClose:()=>c(null),toast:qe,status:k})]})]}),s&&(0,V.jsx)(Ts,{menu:s,onClose:Ks}),b&&(0,V.jsx)("div",{className:`toast tone-${b.tone??"info"}`,role:b.tone==="error"?"alert":"status",onPointerEnter:()=>u(w=>w?.id===b.id?{...w,held:!0}:w),onPointerLeave:()=>u(w=>w?.id===b.id?{...w,held:!1}:w),children:(0,V.jsxs)("div",{className:"toast-top",children:[b.tone!=="info"&&(0,V.jsx)("span",{className:`toast-icon codicon codicon-${b.tone==="error"?"error":"pass-filled"}`,"aria-hidden":"true"}),(0,V.jsxs)("div",{className:"toast-body",children:[(0,V.jsx)("div",{className:"toast-title",children:b.message}),b.detail&&(0,V.jsx)("div",{className:"toast-detail",children:b.detail})]}),(0,V.jsx)(Se,{icon:"close",label:"Dismiss",className:"toast-close",onClick:()=>u(null)})]})},b.id),rt&&(0,V.jsx)(n1,{title:rt.title,detail:rt.detail,images:rt.images,project:rt.project,projects:rt.projects.map(w=>({path:w.path,name:w.name,detail:Iy(w)})),onProject:rt.ids&&k.features?.includes("items.move")?w=>{tx(w)}:void 0,targets:rt.targets,defaultTarget:rt.defaultTarget,harnesses:rt.harnesses,emptyText:rt.empty,onSend:(w,{open:N})=>{ex(w,N)},onCopy:()=>{nx()},onDownload:ox,onClose:ax,status:rt.status,map:f.map})]})}function hE({onDone:e,onCancel:t}){let[n,o]=(0,_.useState)(null),a=(0,_.useRef)(null);return(0,_.useEffect)(()=>{let i=r=>{r.key==="Escape"&&t()};return window.addEventListener("keydown",i,!0),()=>window.removeEventListener("keydown",i,!0)},[t]),(0,V.jsxs)("div",{className:"region",onPointerDown:i=>{i.currentTarget.setPointerCapture(i.pointerId),a.current={x:i.clientX,y:i.clientY},o({x:i.clientX,y:i.clientY,width:0,height:0})},onPointerMove:i=>{let r=a.current;r&&o({x:Math.min(r.x,i.clientX),y:Math.min(r.y,i.clientY),width:Math.abs(i.clientX-r.x),height:Math.abs(i.clientY-r.y)})},onPointerUp:()=>{a.current=null,n&&n.width>4&&n.height>4&&e(n)},children:[(0,V.jsx)("div",{className:"inspect-hint",children:"Drag to select a region \xB7 Esc to cancel"}),n&&(0,V.jsx)("div",{className:"region-box",style:{left:n.x,top:n.y,width:n.width,height:n.height},children:(0,V.jsxs)("span",{className:"region-size",children:[Math.round(n.width)," \xD7 ",Math.round(n.height)]})})]})}var Y1=`/* PairCard: linking this browser (one click in VS Code; the code is the fallback), on the full
   page, in the popup and in the toolbar. */

.pair-card {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 16px;
  padding: 24px;
}

.pair-lead {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin: 0;
  font-size: var(--ink-font-lg);
}

.pair-lead .codicon {
  margin-top: 3px;
  color: var(--ink-blue);
}

.pair-card kbd {
  padding: 1px 6px;
  border: 1px solid var(--vscode-keybindingLabel-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-keybindingLabel-background, var(--ink-surface-sunken));
  font-family: inherit;
  font-size: 0.92em;
  font-weight: 600;
  white-space: nowrap;
}

.pair-card > .muted {
  margin: 0;
}

.pair-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
}

.code-input {
  display: flex;
  align-items: center;
  gap: 8px;
}

.code-sep {
  width: 10px;
  height: 2px;
  margin: 0 2px;
  border-radius: 1px;
  background: var(--ink-border-strong);
}

.code-box {
  width: 46px;
  height: 56px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: 12px;
  outline: none;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font-family: var(--vscode-editor-font-family);
  font-size: 24px;
  font-weight: 600;
  text-align: center;
  caret-color: var(--ink-blue);
  transition:
    border-color var(--ink-fast) var(--ink-ease),
    box-shadow var(--ink-fast) var(--ink-ease);
}

.code-box:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
}

.code-box:focus {
  border-color: var(--ink-focus);
  box-shadow: 0 0 0 1px var(--ink-focus);
}

.code-box:disabled {
  opacity: 0.6;
}

.pair-button {
  height: 56px;
  padding: 0 26px;
  border-radius: 12px;
  font-weight: 600;
}

.pair-message {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin: 0;
  color: var(--ink-danger);
}

.pair-message .codicon {
  margin-top: 2px;
}

.card-foot {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  margin: 0;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.card-foot .codicon {
  margin-top: 2px;
}

/* The popup's and the toolbar's smaller card. */
.pair-card.compact {
  gap: 10px;
  padding: 12px;
}

.pair-card.compact .pair-lead {
  font-size: var(--ink-font-sm);
}

.pair-card.compact .code-box {
  width: 30px;
  height: 38px;
  border-radius: 8px;
  font-size: 18px;
}

.pair-card.compact .pair-button {
  height: 38px;
  padding: 0 14px;
  border-radius: 8px;
}

/* Where no page style gives it a surface (the popup, the toolbar). */
.pair-card.compact {
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--vscode-editorWidget-background);
}

.pair-card .muted {
  margin: 0;
  color: var(--ink-muted);
}
`;var V1=`/* The Inkspect toolbar. The shared components use VS Code theme variables, defined here in a
   dark and a light variant that follow the system theme. */

:host,
.inkspect {
  --vscode-font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  --vscode-font-size: 13px;
  --vscode-editor-font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
  --vscode-foreground: #cccccc;
  --vscode-descriptionForeground: #9d9d9d;
  --vscode-editor-background: #1f1f1f;
  --vscode-editorWidget-background: #202020;
  --vscode-widget-border: #3c3c3c;
  --vscode-widget-shadow: rgba(0, 0, 0, 0.45);
  --vscode-focusBorder: #0078d4;
  --vscode-button-background: #0078d4;
  --vscode-button-foreground: #ffffff;
  --vscode-button-hoverBackground: #026ec1;
  --vscode-button-secondaryBackground: #313131;
  --vscode-button-secondaryForeground: #cccccc;
  --vscode-button-secondaryHoverBackground: #3c3c3c;
  --vscode-toolbar-hoverBackground: rgba(90, 93, 94, 0.31);
  --vscode-toolbar-activeBackground: rgba(99, 102, 103, 0.31);
  --vscode-inputOption-activeBackground: rgba(36, 137, 219, 0.51);
  --vscode-inputOption-activeBorder: #2488db;
  --vscode-input-background: #313131;
  --vscode-input-foreground: #cccccc;
  --vscode-input-border: #3c3c3c;
  --vscode-menu-background: #1f1f1f;
  --vscode-menu-foreground: #cccccc;
  --vscode-menu-selectionBackground: #0078d4;
  --vscode-menu-selectionForeground: #ffffff;
  --vscode-menu-separatorBackground: #454545;
  --vscode-menu-border: #454545;
  --vscode-notifications-background: #1f1f1f;
  --vscode-notifications-foreground: #cccccc;
  --vscode-errorForeground: #f85149;
  --vscode-testing-iconPassed: #73c991;
  --vscode-badge-background: #616161;
  --vscode-badge-foreground: #f8f8f8;
  color-scheme: dark;
}

@media (prefers-color-scheme: light) {
  :host,
  .inkspect {
    --vscode-foreground: #3b3b3b;
    --vscode-descriptionForeground: #6f6f6f;
    --vscode-editor-background: #ffffff;
    --vscode-editorWidget-background: #f8f8f8;
    --vscode-widget-border: #d4d4d4;
    --vscode-widget-shadow: rgba(0, 0, 0, 0.16);
    --vscode-focusBorder: #005fb8;
    --vscode-button-background: #005fb8;
    --vscode-button-hoverBackground: #0258a8;
    --vscode-button-secondaryBackground: #e5e5e5;
    --vscode-button-secondaryForeground: #3b3b3b;
    --vscode-button-secondaryHoverBackground: #cccccc;
    --vscode-toolbar-hoverBackground: rgba(184, 184, 184, 0.31);
    --vscode-toolbar-activeBackground: rgba(166, 166, 166, 0.31);
    --vscode-inputOption-activeBackground: rgba(190, 195, 201, 0.51);
    --vscode-input-background: #ffffff;
    --vscode-input-foreground: #3b3b3b;
    --vscode-input-border: #cecece;
    --vscode-menu-background: #ffffff;
    --vscode-menu-foreground: #3b3b3b;
    --vscode-menu-selectionBackground: #005fb8;
    --vscode-menu-separatorBackground: #d4d4d4;
    --vscode-menu-border: #cecece;
    --vscode-notifications-background: #ffffff;
    --vscode-notifications-foreground: #3b3b3b;
    --vscode-errorForeground: #b3261e;
    --vscode-testing-iconPassed: #2e7d32;
    color-scheme: light;
  }
}

.inkspect {
  position: fixed;
  inset: 0;
  font-family: var(--vscode-font-family);
  font-size: var(--vscode-font-size);
  color: var(--vscode-foreground);
  pointer-events: none;
}

.inkspect *,
.inkspect *::before,
.inkspect *::after {
  box-sizing: border-box;
}

/* Everything interactive takes the pointer; the rest of the layer lets the page through. */
.bar,
.rv,
.panel-dock,
.toast,
.menu,
.ink-modal-backdrop,
/* Popups (select lists, color pickers) are portaled to the shadow root, outside .inkspect. */
[data-ink-popup],
.select-list,
.region,
.draw-host .drawing-layer {
  pointer-events: auto;
}

.inkspect.capturing * {
  visibility: hidden !important;
}

/* Capturing the page for redactions to pixelate: everything over the page steps aside for a
   moment, except the bar (there is only more of the bar under it). Transparent rather than
   hidden, so a drag that starts meanwhile still reaches the drawing layer. */
.inkspect.sampling .draw-host,
.inkspect.sampling .panel-dock,
.inkspect.sampling .toast,
.inkspect.sampling .ink-modal-backdrop,
.inkspect.sampling .menu {
  opacity: 0 !important;
}

/* The toolbar floats over the page (the page isn't moved), as wide as its buttons. Its handle
   drags it (useFloating.ts writes the position into the transform); panels hang off its side with
   more room. While drawing, the drawing tools add a second row. */
.float {
  position: fixed;
  top: 0;
  left: 0;
}

.bar {
  width: max-content;
  max-width: calc(100vw - 16px);
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-lg);
  background: var(--vscode-editorWidget-background);
  box-shadow: var(--ink-shadow-lg);
  user-select: none;
  animation: bar-in var(--ink-normal) var(--ink-ease);
  transition:
    box-shadow var(--ink-fast) var(--ink-ease),
    scale var(--ink-fast) var(--ink-ease);
}

/* Lifted while dragged. */
.float.dragging .bar {
  scale: 1.02;
  box-shadow:
    var(--ink-shadow-lg),
    0 16px 40px color-mix(in srgb, #000 30%, transparent);
}

.bar-row {
  display: flex;
  align-items: center;
  gap: 2px;
  height: 40px;
  padding: 0 4px 0 8px;
}

.bar-brand {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 8px;
  padding: 0 4px;
  font-weight: 600;
}

.bar-brand img {
  width: 18px;
  height: 18px;
  border-radius: 4px;
}

.saved-button {
  flex-shrink: 0;
}

/* The drawing tools: the bar's second row. */
.bar .draw-toolbar {
  justify-content: center;
  border-top: 1px solid var(--ink-border-subtle);
  border-bottom: none;
  border-radius: 0 0 var(--ink-radius-lg) var(--ink-radius-lg);
  background: transparent;
}

@keyframes bar-in {
  from {
    opacity: 0;
    scale: 0.96;
  }
}

@media (prefers-reduced-motion: reduce) {
  .bar {
    animation: none;
    transition: none;
  }
}

.separator {
  width: 1px;
  height: 18px;
  margin: 0 4px;
  background: var(--vscode-widget-border);
}

.bookmarked .codicon {
  color: var(--ink-blue);
}

.link-connected .codicon {
  color: var(--vscode-testing-iconPassed);
}

.link-offline .codicon,
.link-unpaired .codicon {
  color: var(--vscode-descriptionForeground);
}

.draw-host {
  position: fixed;
  inset: 0;
}

.menu {
  position: fixed;
}

/* Toast ------------------------------------------------------------------------------------ */

.inkspect .toast {
  position: fixed;
  top: auto;
  right: 16px;
  bottom: 16px;
  left: auto;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 0;
  width: min(460px, calc(100vw - 32px));
  max-width: none;
  padding: 0;
  overflow: hidden;
  transform: none;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-lg);
  background: var(--vscode-editorWidget-background);
  color: var(--vscode-foreground);
  box-shadow: var(--ink-shadow-lg);
  animation: toast-in var(--ink-normal) var(--ink-ease);
}

.inkspect .toast.tone-error {
  border-color: color-mix(in srgb, var(--ink-danger) 45%, var(--ink-border-strong));
}

.toast-top {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  padding: 14px 10px 14px 14px;
}

.toast-icon {
  flex-shrink: 0;
  margin-top: 1px;
  font-size: 18px !important;
}

.tone-success .toast-icon {
  color: var(--vscode-testing-iconPassed);
}

.tone-error .toast-icon {
  color: var(--ink-danger);
}

.toast-body {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  padding-top: 2px;
}

.toast-title {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: var(--ink-font-lg);
  font-weight: 600;
  line-height: 1.3;
  overflow-wrap: anywhere;
}

.toast-detail {
  color: var(--ink-muted);
  overflow-wrap: anywhere;
}

.toast-close {
  flex-shrink: 0;
  margin-top: -2px;
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
}

/* Panels ------------------------------------------------------------------------------------ */

.panel-dock {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  width: 370px;
  max-width: calc(100vw - 16px);
}

.float.align-right .panel-dock {
  right: 0;
  left: auto;
}

.float.above .panel-dock {
  top: auto;
  bottom: calc(100% + 8px);
}

.panel {
  border: 1px solid var(--vscode-widget-border);
  border-radius: 8px;
  background: var(--vscode-editorWidget-background);
  box-shadow: 0 8px 24px var(--vscode-widget-shadow);
}

.panel-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 6px 6px 12px;
  border-bottom: 1px solid var(--vscode-widget-border);
  font-weight: 600;
}

.panel-body {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: min(70vh, 560px);
  padding: 12px;
  overflow: auto;
}

.row {
  display: flex;
  align-items: flex-end;
  gap: 8px;
}

.field {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 4px;
  color: var(--vscode-descriptionForeground);
  font-size: 12px;
}

.field select,
.field input {
  height: 26px;
  padding: 0 6px;
  border: 1px solid var(--vscode-input-border);
  border-radius: 4px;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font: inherit;
  font-size: 13px;
}

.check {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
}

.note {
  margin: 0;
  color: var(--vscode-descriptionForeground);
  font-size: 12px;
}

.note.error,
.status-offline {
  color: var(--vscode-errorForeground);
}

.status {
  margin: 0;
}

.status-connected {
  color: var(--vscode-testing-iconPassed);
}

.button-row.wrap {
  flex-wrap: wrap;
}

/* A labelled group of actions in a panel ("Copy for AI", "Send ... to VS Code"). */
.panel-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding-top: 12px;
  border-top: 1px solid var(--ink-border-subtle);
}

.panel-group-title {
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
  font-weight: 600;
}

/* Console and network. */
.console-tabs {
  display: flex;
  align-items: center;
  gap: 6px;
}

.console-view {
  flex: 1;
}

.console-view .segment {
  flex: 1;
}

.log {
  min-height: 120px;
  max-height: 280px;
  overflow: auto;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  font-family: var(--vscode-editor-font-family);
  font-size: var(--ink-font-sm);
}

.log-row {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 5px 8px;
  border-bottom: 1px solid var(--ink-border-subtle);
}

.log-row:last-child {
  border-bottom: none;
}

.log-icon {
  flex-shrink: 0;
  margin-top: 2px;
  color: var(--ink-muted);
  font-size: 12px !important;
}

.log-row.level-error {
  background: color-mix(in srgb, var(--ink-danger) 8%, transparent);
  color: var(--ink-danger);
}

.log-row.level-error .log-icon {
  color: var(--ink-danger);
}

.log-row.level-warning {
  background: color-mix(in srgb, var(--ink-yellow) 8%, transparent);
  color: var(--ink-yellow);
}

.log-row.level-warning .log-icon {
  color: var(--ink-yellow);
}

.log-text {
  flex: 1;
  min-width: 0;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.log-source {
  flex-shrink: 0;
  color: var(--ink-muted);
}

.log-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  min-height: 118px;
  padding: 16px;
  color: var(--ink-muted);
  font-family: var(--vscode-font-family);
  text-align: center;
}

.log-empty .codicon {
  margin-bottom: 4px;
  color: var(--ink-green);
  font-size: 20px !important;
}

.log-empty strong {
  color: var(--vscode-foreground);
  font-weight: 600;
}

/* Element inspector (DevTools colors) ------------------------------------------------------- */

/* The picker's hint (PickerHint, styled in @inkspect/shared/ui): centered at the bottom. */
.inspect-hint {
  position: fixed;
  left: 50%;
  bottom: 16px;
  max-width: calc(100vw - 32px);
  transform: translateX(-50%);
}

.hl {
  position: fixed;
  pointer-events: none;
}

/* DevTools' box-model colors, lighter so the element's text stays readable, plus an outline. */
.hl-margin {
  background: rgba(246, 178, 107, 0.4);
}

.hl-border {
  background: rgba(255, 229, 153, 0.5);
}

.hl-padding {
  background: rgba(147, 196, 125, 0.4);
}

.hl-content {
  background: rgba(111, 168, 220, 0.4);
}

.hl-outline {
  box-shadow:
    0 0 0 2px #0a84ff,
    0 0 0 3px rgba(255, 255, 255, 0.85);
}

.selection-box {
  position: fixed;
  border: 2px solid #0078d4;
  pointer-events: none;
}

.selection-badge {
  position: absolute;
  top: -10px;
  left: -10px;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 10px;
  background: #0078d4;
  color: #fff;
  font-size: 12px;
  line-height: 20px;
  text-align: center;
}

/* Chrome's inspect tooltip: always light, like in DevTools. */
.tip {
  position: fixed;
  padding: 8px 10px;
  border-radius: 4px;
  background: #fff;
  color: #303942;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
  font:
    12px system-ui,
    sans-serif;
  pointer-events: none;
}

.tip-head {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 6px;
  font-weight: 600;
}

.tip-tag {
  color: #881280;
}

.tip-id,
.tip-class {
  color: #1a1aa6;
}

.tip-size {
  flex-shrink: 0;
  color: #5f6368;
  font-weight: 400;
}

.tip-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 1px 0;
  color: #5f6368;
}

.tip-row > span:last-child {
  color: #303942;
  text-align: right;
  overflow-wrap: anywhere;
}

.tip-value {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.tip-swatch {
  display: inline-block;
  width: 10px;
  height: 10px;
  border: 1px solid #ccc;
}

.tip-section {
  margin: 6px 0 2px;
  padding-top: 6px;
  border-top: 1px solid #e0e0e0;
  color: #5f6368;
  font-size: 10px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
}

.tip-aa {
  padding: 0 3px;
  border: 1px solid #ccc;
}

.ok {
  color: #188038 !important;
}

.bad {
  color: #d93025 !important;
}

/* Region selection --------------------------------------------------------------------------- */

.region {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.25);
  cursor: crosshair;
}

.region-box {
  position: fixed;
  border: 1px dashed #fff;
  outline: 1px dashed rgba(0, 0, 0, 0.6);
  box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.35);
}

.region-size {
  position: absolute;
  top: -22px;
  left: 0;
  padding: 1px 6px;
  border-radius: 3px;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  font-size: 11px;
}

/* Responsive view --------------------------------------------------------------------------- */

/* Covers the page below the bar; the page shows in a device-sized frame, centered. */
.rv {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  display: flex;
  flex-direction: column;
  background: color-mix(in srgb, var(--vscode-foreground) 6%, var(--vscode-editor-background));
}

.rv-controls {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 6px 12px;
  border-bottom: 1px solid var(--ink-border-subtle);
  background: var(--vscode-editorWidget-background);
}

.rv-device {
  width: 200px;
}

.rv-size {
  width: 64px;
}

.rv-size input {
  text-align: center;
  font-variant-numeric: tabular-nums;
}

.rv-zoom {
  width: 84px;
}

.rv-times {
  color: var(--ink-muted);
}

.rv-divider {
  width: 1px;
  height: 18px;
  margin: 0 4px;
  background: var(--ink-border-subtle);
}

.rv-area {
  flex: 1;
  min-height: 0;
  overflow: auto;
}

/* Centered while it fits; scrolls from its top-left corner when zoomed in beyond the area. */
.rv-stage {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 22px;
  min-width: 100%;
  min-height: 100%;
  width: max-content;
  padding: 24px 32px;
}

.rv-screen {
  position: relative;
  flex-shrink: 0;
  overflow: hidden;
  border-radius: 6px;
  background: #fff;
  box-shadow:
    0 0 0 1px var(--ink-border-strong),
    var(--ink-shadow-lg);
}

.rv-screen iframe {
  display: block;
  border: 0;
  transform-origin: 0 0;
  background: #fff;
}

/* The screen and its resize handles (right edge, bottom edge, corner), like DevTools'. */
.rv-frame {
  position: relative;
  flex-shrink: 0;
}

.rv-handle {
  position: absolute;
  z-index: 1;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--vscode-foreground) 28%, transparent);
  touch-action: none;
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.rv-handle:hover,
.rv.dragging .rv-handle {
  background: var(--ink-blue);
}

.rv-handle-x {
  top: 50%;
  right: -14px;
  width: 6px;
  height: 44px;
  transform: translateY(-50%);
  cursor: ew-resize;
}

.rv-handle-y {
  bottom: -14px;
  left: 50%;
  width: 44px;
  height: 6px;
  transform: translateX(-50%);
  cursor: ns-resize;
}

.rv-handle-xy {
  right: -14px;
  bottom: -14px;
  width: 12px;
  height: 12px;
  border-radius: 3px;
  cursor: nwse-resize;
}

/* The frame would take the pointer from the handle mid-drag. */
.rv.dragging iframe {
  pointer-events: none;
}

.rv.dragging {
  user-select: none;
}

.rv-caption {
  height: 14px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  font-variant-numeric: tabular-nums;
}

@media (prefers-reduced-motion: reduce) {
  .bar,
  .inkspect .toast {
    animation: none;
  }
}

/* The shortcuts panel. */
.shortcuts-bar {
  display: flex;
  align-items: center;
  gap: 6px;
}

.shortcuts-bar .text-field {
  flex: 1;
}

/* Group headers pin to the panel's top edge (sticky stops at the padding otherwise, leaving a
   strip where rows show through). */
.panel-body .shortcut-list {
  --shortcut-sticky-top: -12px;
}

.panel-body .group-header {
  background: var(--vscode-editorWidget-background);
}

.shortcuts-sync {
  display: flex;
  gap: 6px;
}

.shortcuts-sync .codicon {
  flex-shrink: 0;
  margin-top: 1px;
}

/* The bar over a Shift+click selection (SelectionBar), just above the picker's hint. */
.toolbar-selection-bar {
  position: fixed;
  left: 50%;
  bottom: 92px;
  transform: translateX(-50%);
}
`;var G1=R(j());async function xE(){try{let e=await(await fetch(chrome.runtime.getURL("codicon.ttf"))).arrayBuffer(),t=new FontFace("codicon",e);await t.load(),document.fonts.add(t)}catch{}}function kE(){let e=document.createElement("inkspect-toolbar");e.style.cssText="all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none; display: block;";let t=e.attachShadow({mode:"closed"});v0(t);let n=document.createElement("style");n.textContent=[$p.replace(/@font-face\s*{[^}]*}/g,""),Jp,Y1,V1].join(`
`);let o=document.createElement("div");t.append(n,o),document.documentElement.appendChild(e),xE();let a=(0,X1.createRoot)(o),i=()=>(e.style.visibility="hidden",()=>{e.style.visibility=""});return r=>{e.isConnected||document.documentElement.appendChild(e),a.render((0,G1.jsx)(q1,{host:e,hideHost:i,toggleSignal:r}))}}var K1=window;if(!K1.__inkspect){K1.__inkspect=!0;let e,t=0;chrome.runtime.onMessage.addListener(n=>{n.type==="toggle"&&(n.key&&H0(n.key)||(e??=kE(),e(++t)))})}})();
