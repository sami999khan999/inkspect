"use strict";(()=>{var Lm=Object.create;var Rd=Object.defineProperty;var Vm=Object.getOwnPropertyDescriptor;var Gm=Object.getOwnPropertyNames;var Xm=Object.getPrototypeOf,Qm=Object.prototype.hasOwnProperty;var Ct=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports}catch(n){throw t=0,n}};var Zm=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of Gm(t))!Qm.call(e,a)&&a!==n&&Rd(e,a,{get:()=>t[a],enumerable:!(o=Vm(t,a))||o.enumerable});return e};var W=(e,t,n)=>(n=e!=null?Lm(Xm(e)):{},Zm(t||!e||!e.__esModule?Rd(n,"default",{value:e,enumerable:!0}):n,e));var Kd=Ct(Hl=>{"use strict";var ap=Symbol.for("react.transitional.element"),lp=Symbol.for("react.fragment");function Zd(e,t,n){var o=null;if(n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),"key"in t){n={};for(var a in t)a!=="key"&&(n[a]=t[a])}else n=t;return t=n.ref,{$$typeof:ap,type:e,key:o,ref:t!==void 0?t:null,props:n}}Hl.Fragment=lp;Hl.jsx=Zd;Hl.jsxs=Zd});var me=Ct((l1,Jd)=>{"use strict";Jd.exports=Kd()});var rf=Ct(_=>{"use strict";var Ci=Symbol.for("react.transitional.element"),cp=Symbol.for("react.portal"),ip=Symbol.for("react.fragment"),rp=Symbol.for("react.strict_mode"),up=Symbol.for("react.profiler"),dp=Symbol.for("react.consumer"),fp=Symbol.for("react.context"),sp=Symbol.for("react.forward_ref"),bp=Symbol.for("react.suspense"),vp=Symbol.for("react.memo"),Pd=Symbol.for("react.lazy"),gp=Symbol.for("react.activity"),mp=Symbol.for("react.view_transition"),$d=Symbol.iterator;function pp(e){return e===null||typeof e!="object"?null:(e=$d&&e[$d]||e["@@iterator"],typeof e=="function"?e:null)}var ef={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},tf=Object.assign,nf={};function No(e,t,n){this.props=e,this.context=t,this.refs=nf,this.updater=n||ef}No.prototype.isReactComponent={};No.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};No.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function of(){}of.prototype=No.prototype;function Di(e,t,n){this.props=e,this.context=t,this.refs=nf,this.updater=n||ef}var Hi=Di.prototype=new of;Hi.constructor=Di;tf(Hi,No.prototype);Hi.isPureReactComponent=!0;var Fd=Array.isArray;function Mi(){}var I={H:null,A:null,T:null,S:null},af=Object.prototype.hasOwnProperty;function Ri(e,t,n){var o=n.ref;return{$$typeof:Ci,type:e,key:t,ref:o!==void 0?o:null,props:n}}function hp(e,t){return Ri(e.type,t,e.props)}function Ui(e){return typeof e=="object"&&e!==null&&e.$$typeof===Ci}function yp(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var Wd=/\/+/g;function _i(e,t){return typeof e=="object"&&e!==null&&e.key!=null?yp(""+e.key):t.toString(36)}function xp(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(Mi,Mi):(e.status="pending",e.then(function(t){e.status==="pending"&&(e.status="fulfilled",e.value=t)},function(t){e.status==="pending"&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function zo(e,t,n,o,a){var l=typeof e;(l==="undefined"||l==="boolean")&&(e=null);var c=!1;if(e===null)c=!0;else switch(l){case"bigint":case"string":case"number":c=!0;break;case"object":switch(e.$$typeof){case Ci:case cp:c=!0;break;case Pd:return c=e._init,zo(c(e._payload),t,n,o,a)}}if(c)return a=a(e),c=o===""?"."+_i(e,0):o,Fd(a)?(n="",c!=null&&(n=c.replace(Wd,"$&/")+"/"),zo(a,t,n,"",function(d){return d})):a!=null&&(Ui(a)&&(a=hp(a,n+(a.key==null||e&&e.key===a.key?"":(""+a.key).replace(Wd,"$&/")+"/")+c)),t.push(a)),1;c=0;var i=o===""?".":o+":";if(Fd(e))for(var r=0;r<e.length;r++)o=e[r],l=i+_i(o,r),c+=zo(o,t,n,l,a);else if(r=pp(e),typeof r=="function")for(e=r.call(e),r=0;!(o=e.next()).done;)o=o.value,l=i+_i(o,r++),c+=zo(o,t,n,l,a);else if(l==="object"){if(typeof e.then=="function")return zo(xp(e),t,n,o,a);throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return c}function Rl(e,t,n){if(e==null)return e;var o=[],a=0;return zo(e,o,"","",function(l){return t.call(n,l,a++)}),o}function kp(e){if(e._status===-1){var t=e._result,n=t();n.then(function(o){(e._status===0||e._status===-1)&&(e._status=1,e._result=o,n.status===void 0&&(n.status="fulfilled",n.value=o))},function(o){(e._status===0||e._status===-1)&&(e._status=2,e._result=o,n.status===void 0&&(n.status="rejected",n.reason=o))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var Id=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)};function lf(e){var t=I.T,n={};n.types=t!==null?t.types:null,I.T=n;try{var o=e(),a=I.S;a!==null&&a(n,o),typeof o=="object"&&o!==null&&typeof o.then=="function"&&o.then(Mi,Id)}catch(l){Id(l)}finally{t!==null&&n.types!==null&&(t.types=n.types),I.T=t}}function cf(e){var t=I.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else lf(cf.bind(null,e))}var Sp={map:Rl,forEach:function(e,t,n){Rl(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return Rl(e,function(){t++}),t},toArray:function(e){return Rl(e,function(t){return t})||[]},only:function(e){if(!Ui(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};_.Activity=gp;_.Children=Sp;_.Component=No;_.Fragment=ip;_.Profiler=up;_.PureComponent=Di;_.StrictMode=rp;_.Suspense=bp;_.ViewTransition=mp;_.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=I;_.__COMPILER_RUNTIME={__proto__:null,c:function(e){return I.H.useMemoCache(e)}};_.addTransitionType=cf;_.cache=function(e){return function(){return e.apply(null,arguments)}};_.cacheSignal=function(){return null};_.cloneElement=function(e,t,n){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var o=tf({},e.props),a=e.key;if(t!=null)for(l in t.key!==void 0&&(a=""+t.key),t)!af.call(t,l)||l==="key"||l==="__self"||l==="__source"||l==="ref"&&t.ref===void 0||(o[l]=t[l]);var l=arguments.length-2;if(l===1)o.children=n;else if(1<l){for(var c=Array(l),i=0;i<l;i++)c[i]=arguments[i+2];o.children=c}return Ri(e.type,a,o)};_.createContext=function(e){return e={$$typeof:fp,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:dp,_context:e},e};_.createElement=function(e,t,n){var o,a={},l=null;if(t!=null)for(o in t.key!==void 0&&(l=""+t.key),t)af.call(t,o)&&o!=="key"&&o!=="__self"&&o!=="__source"&&(a[o]=t[o]);var c=arguments.length-2;if(c===1)a.children=n;else if(1<c){for(var i=Array(c),r=0;r<c;r++)i[r]=arguments[r+2];a.children=i}if(e&&e.defaultProps)for(o in c=e.defaultProps,c)a[o]===void 0&&(a[o]=c[o]);return Ri(e,l,a)};_.createRef=function(){return{current:null}};_.forwardRef=function(e){return{$$typeof:sp,render:e}};_.isValidElement=Ui;_.lazy=function(e){return{$$typeof:Pd,_payload:{_status:-1,_result:e},_init:kp}};_.memo=function(e,t){return{$$typeof:vp,type:e,compare:t===void 0?null:t}};_.startTransition=lf;_.unstable_useCacheRefresh=function(){return I.H.useCacheRefresh()};_.use=function(e){return I.H.use(e)};_.useActionState=function(e,t,n){return I.H.useActionState(e,t,n)};_.useCallback=function(e,t){return I.H.useCallback(e,t)};_.useContext=function(e){return I.H.useContext(e)};_.useDebugValue=function(){};_.useDeferredValue=function(e,t){return I.H.useDeferredValue(e,t)};_.useEffect=function(e,t){return I.H.useEffect(e,t)};_.useEffectEvent=function(e){return I.H.useEffectEvent(e)};_.useId=function(){return I.H.useId()};_.useImperativeHandle=function(e,t,n){return I.H.useImperativeHandle(e,t,n)};_.useInsertionEffect=function(e,t){return I.H.useInsertionEffect(e,t)};_.useLayoutEffect=function(e,t){return I.H.useLayoutEffect(e,t)};_.useMemo=function(e,t){return I.H.useMemo(e,t)};_.useOptimistic=function(e,t){return I.H.useOptimistic(e,t)};_.useReducer=function(e,t,n){return I.H.useReducer(e,t,n)};_.useRef=function(e){return I.H.useRef(e)};_.useState=function(e){return I.H.useState(e)};_.useSyncExternalStore=function(e,t,n){return I.H.useSyncExternalStore(e,t,n)};_.useTransition=function(){return I.H.useTransition()};_.version="19.3.0"});var $t=Ct((r1,uf)=>{"use strict";uf.exports=rf()});var _f=Ct(He=>{"use strict";var Op=$t();function Af(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function vn(){}var qe={d:{f:vn,r:function(){throw Error(Af(522))},D:vn,C:vn,L:vn,m:vn,X:vn,S:vn,M:vn},p:0,findDOMNode:null},Ap=Symbol.for("react.portal"),_p=Symbol.for("react.recoverable"),Of=Symbol.for("react.optimistic_key");function Mp(e,t,n){var o=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Ap,key:o==null?null:o===Of?Of:""+o,children:e,containerInfo:t,implementation:n}}var Aa=Op.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function Bl(e,t){if(e==="font")return"";if(typeof t=="string")return t==="use-credentials"?t:""}He.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=qe;He.browser=function(e){return{$$typeof:_p,_reason:e}};He.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(Af(299));return Mp(e,t,null,n)};He.flushSync=function(e){var t=Aa.T,n=qe.p;try{if(Aa.T=null,qe.p=2,e)return e()}finally{Aa.T=t,qe.p=n,qe.d.f()}};He.preconnect=function(e,t){typeof e=="string"&&(t?(t=t.crossOrigin,t=typeof t=="string"?t==="use-credentials"?t:"":void 0):t=null,qe.d.C(e,t))};He.prefetchDNS=function(e){typeof e=="string"&&qe.d.D(e)};He.preinit=function(e,t){if(typeof e=="string"&&t&&typeof t.as=="string"){var n=t.as,o=Bl(n,t.crossOrigin),a=typeof t.integrity=="string"?t.integrity:void 0,l=typeof t.fetchPriority=="string"?t.fetchPriority:void 0;n==="style"?qe.d.S(e,typeof t.precedence=="string"?t.precedence:void 0,{crossOrigin:o,integrity:a,fetchPriority:l}):n==="script"&&qe.d.X(e,{crossOrigin:o,integrity:a,fetchPriority:l,nonce:typeof t.nonce=="string"?t.nonce:void 0})}};He.preinitModule=function(e,t){if(typeof e=="string")if(typeof t=="object"&&t!==null){if(t.as==null||t.as==="script"){var n=Bl(t.as,t.crossOrigin);qe.d.M(e,{crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}}else t==null&&qe.d.M(e)};He.preload=function(e,t){if(typeof e=="string"&&typeof t=="object"&&t!==null&&typeof t.as=="string"){var n=t.as,o=Bl(n,t.crossOrigin);qe.d.L(e,n,{crossOrigin:o,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,type:typeof t.type=="string"?t.type:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy=="string"?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet=="string"?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes=="string"?t.imageSizes:void 0,media:typeof t.media=="string"?t.media:void 0})}};He.preloadModule=function(e,t){if(typeof e=="string")if(t){var n=Bl(t.as,t.crossOrigin);qe.d.m(e,{as:typeof t.as=="string"&&t.as!=="script"?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}else qe.d.m(e)};He.requestFormReset=function(e){qe.d.r(e)};He.unstable_batchedUpdates=function(e,t){return e(t)};He.useFormState=function(e,t,n){return Aa.H.useFormState(e,t,n)};He.useFormStatus=function(){return Aa.H.useHostTransitionStatus()};He.version="19.3.0"});var qi=Ct((D1,Cf)=>{"use strict";function Mf(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Mf)}catch(e){console.error(e)}}Mf(),Cf.exports=_f()});var Xf=Ct(oe=>{"use strict";function Vi(e,t){var n=e.length;e.push(t);e:for(;0<n;){var o=n-1>>>1,a=e[o];if(0<ql(a,t))e[o]=t,e[n]=a,n=o;else break e}}function Ht(e){return e.length===0?null:e[0]}function Yl(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;e:for(var o=0,a=e.length,l=a>>>1;o<l;){var c=2*(o+1)-1,i=e[c],r=c+1,d=e[r];if(0>ql(i,n))r<a&&0>ql(d,i)?(e[o]=d,e[r]=n,o=r):(e[o]=i,e[c]=n,o=c);else if(r<a&&0>ql(d,n))e[o]=d,e[r]=n,o=r;else break e}}return t}function ql(e,t){var n=e.sortIndex-t.sortIndex;return n!==0?n:e.id-t.id}oe.unstable_now=void 0;typeof performance=="object"&&typeof performance.now=="function"?(Rf=performance,oe.unstable_now=function(){return Rf.now()}):(ji=Date,Uf=ji.now(),oe.unstable_now=function(){return ji.now()-Uf});var Rf,ji,Uf,Ft=[],gn=[],Cp=1,gt=null,Re=3,Gi=!1,_a=!1,Ma=!1,Xi=!1,jf=typeof setTimeout=="function"?setTimeout:null,Yf=typeof clearTimeout=="function"?clearTimeout:null,Bf=typeof setImmediate<"u"?setImmediate:null;function jl(e){for(var t=Ht(gn);t!==null;){if(t.callback===null)Yl(gn);else if(t.startTime<=e)Yl(gn),t.sortIndex=t.expirationTime,Vi(Ft,t);else break;t=Ht(gn)}}function Qi(e){if(Ma=!1,jl(e),!_a)if(Ht(Ft)!==null)_a=!0,Co||(Co=!0,Mo());else{var t=Ht(gn);t!==null&&Zi(Qi,t.startTime-e)}}var Co=!1,Ca=-1,Lf=5,Vf=-1;function Gf(){return Xi?!0:!(oe.unstable_now()-Vf<Lf)}function Yi(){if(Xi=!1,Co){var e=oe.unstable_now();Vf=e;var t=!0;try{e:{_a=!1,Ma&&(Ma=!1,Yf(Ca),Ca=-1),Gi=!0;var n=Re;try{t:{for(jl(e),gt=Ht(Ft);gt!==null&&!(gt.expirationTime>e&&Gf());){var o=gt.callback;if(typeof o=="function"){gt.callback=null,Re=gt.priorityLevel;var a=o(gt.expirationTime<=e);if(e=oe.unstable_now(),typeof a=="function"){gt.callback=a,jl(e),t=!0;break t}gt===Ht(Ft)&&Yl(Ft),jl(e)}else Yl(Ft);gt=Ht(Ft)}if(gt!==null)t=!0;else{var l=Ht(gn);l!==null&&Zi(Qi,l.startTime-e),t=!1}}break e}finally{gt=null,Re=n,Gi=!1}t=void 0}}finally{t?Mo():Co=!1}}}var Mo;typeof Bf=="function"?Mo=function(){Bf(Yi)}:typeof MessageChannel<"u"?(Li=new MessageChannel,qf=Li.port2,Li.port1.onmessage=Yi,Mo=function(){qf.postMessage(null)}):Mo=function(){jf(Yi,0)};var Li,qf;function Zi(e,t){Ca=jf(function(){e(oe.unstable_now())},t)}oe.unstable_IdlePriority=5;oe.unstable_ImmediatePriority=1;oe.unstable_LowPriority=4;oe.unstable_NormalPriority=3;oe.unstable_Profiling=null;oe.unstable_UserBlockingPriority=2;oe.unstable_cancelCallback=function(e){e.callback=null};oe.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):Lf=0<e?Math.floor(1e3/e):5};oe.unstable_getCurrentPriorityLevel=function(){return Re};oe.unstable_next=function(e){switch(Re){case 1:case 2:case 3:var t=3;break;default:t=Re}var n=Re;Re=t;try{return e()}finally{Re=n}};oe.unstable_requestPaint=function(){Xi=!0};oe.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=Re;Re=e;try{return t()}finally{Re=n}};oe.unstable_scheduleCallback=function(e,t,n){var o=oe.unstable_now();switch(typeof n=="object"&&n!==null?(n=n.delay,n=typeof n=="number"&&0<n?o+n:o):n=o,e){case 1:var a=-1;break;case 2:a=250;break;case 5:a=1073741823;break;case 4:a=1e4;break;default:a=5e3}return a=n+a,e={id:Cp++,callback:t,priorityLevel:e,startTime:n,expirationTime:a,sortIndex:-1},n>o?(e.sortIndex=n,Vi(gn,e),Ht(Ft)===null&&e===Ht(gn)&&(Ma?(Yf(Ca),Ca=-1):Ma=!0,Zi(Qi,n-o))):(e.sortIndex=a,Vi(Ft,e),_a||Gi||(_a=!0,Co||(Co=!0,Mo()))),e};oe.unstable_shouldYield=Gf;oe.unstable_wrapCallback=function(e){var t=Re;return function(){var n=Re;Re=t;try{return e.apply(this,arguments)}finally{Re=n}}}});var Zf=Ct((B1,Qf)=>{"use strict";Qf.exports=Xf()});var Cm=Ct(ki=>{"use strict";var ye=Zf(),Mb=$t(),Dp=qi();function h(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function Cb(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function yl(e){for(var t=e,n=t;n&&!n.alternate;)t=n,(t.flags&4098)!==0&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function Db(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Hb(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Kf(e){if(yl(e)!==e)throw Error(h(188))}function Hp(e){var t=e.alternate;if(!t){if(t=yl(e),t===null)throw Error(h(188));return t!==e?null:e}for(var n=e,o=t;;){var a=n.return;if(a===null)break;var l=a.alternate;if(l===null){if(o=a.return,o!==null){n=o;continue}break}if(a.child===l.child){for(l=a.child;l;){if(l===n)return Kf(a),e;if(l===o)return Kf(a),t;l=l.sibling}throw Error(h(188))}if(n.return!==o.return)n=a,o=l;else{for(var c=!1,i=a.child;i;){if(i===n){c=!0,n=a,o=l;break}if(i===o){c=!0,o=a,n=l;break}i=i.sibling}if(!c){for(i=l.child;i;){if(i===n){c=!0,n=l,o=a;break}if(i===o){c=!0,o=l,n=a;break}i=i.sibling}if(!c)throw Error(h(189))}}if(n.alternate!==o)throw Error(h(190))}if(n.tag!==3)throw Error(h(188));return n.stateNode.current===n?e:t}function Rb(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=Rb(e),t!==null)return t;e=e.sibling}return null}function $e(e,t,n,o,a,l){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,o,a,l)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&$e(e.child,t,n,o,a,l))return!0;e=e.sibling}return!1}function ho(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function Jf(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),!(e.tag===3||e.tag===5||e.tag===27));)e=e.return;return t}function Ub(e){var t=[null,null],n=ho(e);return n===null||Bb(t,e,n.child,{foundSelf:!1}),t}function Bb(e,t,n,o){for(;n!==null;){if(n===t)o.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(o.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&Bb(e,t,n.child,o))return!0;n=n.sibling}return!1}function he(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(h(559))}}var jo=null,wr=null;function Rp(e,t,n){return e===n?!0:e===t?(jo=e,!0):!1}function Up(e,t,n){return e===n?(wr=e,!1):e===t?(wr!==null&&(jo=e),!0):!1}function $f(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function Er(e,t,n){for(var o=0,a=e;a;a=n(a))o++;a=0;for(var l=t;l;l=n(l))a++;for(;0<o-a;)e=n(e),o--;for(;0<a-o;)t=n(t),a--;for(;o--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var $=Object.assign,Bp=Symbol.for("react.element"),Ll=Symbol.for("react.transitional.element"),ja=Symbol.for("react.portal"),Yo=Symbol.for("react.fragment"),qb=Symbol.for("react.strict_mode"),zr=Symbol.for("react.profiler"),jb=Symbol.for("react.consumer"),Yt=Symbol.for("react.context"),Ru=Symbol.for("react.forward_ref"),Nr=Symbol.for("react.suspense"),Or=Symbol.for("react.suspense_list"),Uu=Symbol.for("react.memo"),yn=Symbol.for("react.lazy"),Ar=Symbol.for("react.activity"),qp=Symbol.for("react.legacy_hidden"),jp=Symbol.for("react.memo_cache_sentinel"),_r=Symbol.for("react.view_transition"),Yp=Symbol.for("react.recoverable"),Ff=Symbol.iterator;function Da(e){return e===null||typeof e!="object"?null:(e=Ff&&e[Ff]||e["@@iterator"],typeof e=="function"?e:null)}var Lp=Symbol.for("react.client.reference");function Mr(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===Lp?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Yo:return"Fragment";case zr:return"Profiler";case qb:return"StrictMode";case Nr:return"Suspense";case Or:return"SuspenseList";case Ar:return"Activity";case _r:return"ViewTransition"}if(typeof e=="object")switch(e.$$typeof){case ja:return"Portal";case Yt:return e.displayName||"Context";case jb:return(e._context.displayName||"Context")+".Consumer";case Ru:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Uu:return t=e.displayName||null,t!==null?t:Mr(e.type)||"Memo";case yn:t=e._payload,e=e._init;try{return Mr(e(t))}catch{}}return null}var Ya=Array.isArray,O=Mb.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,L=Dp.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ao={pending:!1,data:null,method:null,action:null},Cr=[],Lo=-1;function Kt(e){return{current:e}}function Ae(e){0>Lo||(e.current=Cr[Lo],Cr[Lo]=null,Lo--)}function te(e,t){Lo++,Cr[Lo]=e.current,e.current=t}var Xt=Kt(null),ol=Kt(null),On=Kt(null),Nc=Kt(null);function Oc(e,t){switch(te(On,t),te(ol,e),te(Xt,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?db(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=db(t),e=im(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}Ae(Xt),te(Xt,e)}function ia(){Ae(Xt),Ae(ol),Ae(On)}function Dr(e){var t=e.memoizedState;t!==null&&(pa._currentValue=t.memoizedState,te(Nc,e)),t=Xt.current;var n=im(t,e.type);t!==n&&(te(ol,e),te(Xt,n))}function Ac(e){ol.current===e&&(Ae(Xt),Ae(ol)),Nc.current===e&&(Ae(Nc),pa._currentValue=ao)}var Ki,Wf;function pn(e){if(Ki===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);Ki=t&&t[1]||"",Wf=-1<n.stack.indexOf(`
    at`)?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Ki+e+Wf}var Ji=!1;function $i(e,t){if(!e||Ji)return"";Ji=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(t){var m=function(){throw Error()};if(Object.defineProperty(m.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(m,[])}catch(y){var s=y}Reflect.construct(e,[],m)}else{try{m.call()}catch(y){s=y}m=!1;try{var b=Object.getOwnPropertyDescriptor(e.prototype,"props");Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),m=!0,new e}finally{m&&(b!==void 0?Object.defineProperty(e.prototype,"props",b):delete e.prototype.props)}}}else{try{throw Error()}catch(y){s=y}(m=e())&&typeof m.catch=="function"&&m.catch(function(){})}}catch(y){if(y&&s&&typeof y.stack=="string")return[y.stack,s.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var a=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");a&&a.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var l=o.DetermineComponentFrameRoot(),c=l[0],i=l[1];if(c&&i){var r=c.split(`
`),d=i.split(`
`);for(a=o=0;o<r.length&&!r[o].includes("DetermineComponentFrameRoot");)o++;for(;a<d.length&&!d[a].includes("DetermineComponentFrameRoot");)a++;if(o===r.length||a===d.length)for(o=r.length-1,a=d.length-1;1<=o&&0<=a&&r[o]!==d[a];)a--;for(;1<=o&&0<=a;o--,a--)if(r[o]!==d[a]){if(o!==1||a!==1)do if(o--,a--,0>a||r[o]!==d[a]){var v=`
`+r[o].replace(" at new "," at ");return e.displayName&&v.includes("<anonymous>")&&(v=v.replace("<anonymous>",e.displayName)),v}while(1<=o&&0<=a);break}}}finally{Ji=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?pn(n):""}function Vp(e,t){switch(e.tag){case 26:case 27:case 5:return pn(e.type);case 16:return pn("Lazy");case 13:return e.child!==t&&t!==null?pn("Suspense Fallback"):pn("Suspense");case 19:return pn("SuspenseList");case 0:case 15:return $i(e.type,!1);case 11:return $i(e.type.render,!1);case 1:return $i(e.type,!0);case 31:return pn("Activity");case 30:return pn("ViewTransition");default:return""}}function If(e){try{var t="",n=null;do t+=Vp(e,n),n=e,e=e.return;while(e);return t}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var Hr=Object.prototype.hasOwnProperty,Bu=ye.unstable_scheduleCallback,Fi=ye.unstable_cancelCallback,Gp=ye.unstable_shouldYield,Xp=ye.unstable_requestPaint,lt=ye.unstable_now,Qp=ye.unstable_getCurrentPriorityLevel,Yb=ye.unstable_ImmediatePriority,Lb=ye.unstable_UserBlockingPriority,_c=ye.unstable_NormalPriority,Zp=ye.unstable_LowPriority,Vb=ye.unstable_IdlePriority,Kp=ye.log,Jp=ye.unstable_setDisableYieldValue,xl=null,ct=null;function Sn(e){if(typeof Kp=="function"&&Jp(e),ct&&typeof ct.setStrictMode=="function")try{ct.setStrictMode(xl,e)}catch{}}var it=Math.clz32?Math.clz32:Wp,$p=Math.log,Fp=Math.LN2;function Wp(e){return e>>>=0,e===0?32:31-($p(e)/Fp|0)|0}var Vl=256,Gl=262144,Xl=4194304;function Pn(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function ni(e,t,n){var o=e.pendingLanes;if(o===0)return 0;var a=0,l=e.suspendedLanes,c=e.pingedLanes;e=e.warmLanes;var i=o&134217727;return i!==0?(o=i&~l,o!==0?a=Pn(o):(c&=i,c!==0?a=Pn(c):n||(n=i&~e,n!==0&&(a=Pn(n))))):(i=o&~l,i!==0?a=Pn(i):c!==0?a=Pn(c):n||(n=o&~e,n!==0&&(a=Pn(n)))),a===0?0:t!==0&&t!==a&&(t&l)===0&&(l=a&-a,n=t&-t,l>=n||l===32&&(n&4194048)!==0)?t:a}function kl(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Gb(e,t){(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var o=31-it(n),a=1<<o;t|=e[o],n&=~a}return t}function Ip(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Xb(){var e=Xl;return Xl<<=1,(Xl&62914560)===0&&(Xl=4194304),e}function Wi(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Sl(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Pp(e,t,n,o,a,l){var c=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var i=e.entanglements,r=e.expirationTimes,d=e.hiddenUpdates;for(n=c&~n;0<n;){var v=31-it(n),m=1<<v;i[v]=0,r[v]=-1;var s=d[v];if(s!==null)for(d[v]=null,v=0;v<s.length;v++){var b=s[v];b!==null&&(b.lane&=-536870913)}n&=~m}o!==0&&Qb(e,o,0),l!==0&&a===0&&e.tag!==0&&(e.suspendedLanes|=l&~(c&~t))}function Qb(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var o=31-it(t);e.entangledLanes|=t,e.entanglements[o]=e.entanglements[o]|1073741824|n&261930}function Zb(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var o=31-it(n),a=1<<o;a&t|e[o]&t&&(e[o]|=t),n&=~a}}function Kb(e,t){var n=t&-t;return n=(n&42)!==0?1:qu(n),(n&(e.suspendedLanes|t))!==0?0:n}function qu(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function ju(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Jb(){var e=L.p;return e!==0?e:(e=window.event,e===void 0?32:Am(e.type))}function Pf(e,t){var n=L.p;try{return L.p=e,t()}finally{L.p=n}}var dn=Math.random().toString(36).slice(2),Ne="__reactFiber$"+dn,Fe="__reactProps$"+dn,xa="__reactContainer$"+dn,es="__reactEvents$"+dn,e0="__reactListeners$"+dn,t0="__reactHandles$"+dn,ts="__reactResources$"+dn,Tl="__reactMarker$"+dn,Mc="__reactLoad$"+dn;function oi(e){delete e[Ne],delete e[Fe],delete e[e0],delete e[t0]}function no(e){var t;if(t=e[Ne])return t;for(var n=e.parentNode;n;){if(t=n[xa]||n[Ne]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=hb(e);e!==null;){if(n=e[Ne])return n;e=hb(e)}return t}e=n,n=e.parentNode}return null}function ka(e){if(e=e[Ne]||e[xa]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function La(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(h(33))}function Wo(e){var t=e[ts];return t||(t=e[ts]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function Se(e){e[Tl]=!0}function $b(e){e[Mc]=void 0}var Fb=new Set,Wb={};function yo(e,t){ra(e,t),ra(e+"Capture",t)}function ra(e,t){for(Wb[e]=t,e=0;e<t.length;e++)Fb.add(t[e])}var n0=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),ns={},os={};function o0(e){return Hr.call(os,e)?!0:Hr.call(ns,e)?!1:n0.test(e)?os[e]=!0:(ns[e]=!0,!1)}var j=!1;function as(){var e=j;return j=!1,e}function rc(e,t,n){if(o0(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var o=t.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,n)}}function Ql(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,n)}}function Wt(e,t,n,o){if(o===null)e.removeAttribute(n);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,o)}}function tt(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Ib(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function a0(e,t,n){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var a=o.get,l=o.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return a.call(this)},set:function(c){n=""+c,l.call(this,c)}}),Object.defineProperty(e,t,{enumerable:o.enumerable}),{getValue:function(){return n},setValue:function(c){n=""+c},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Rr(e){if(!e._valueTracker){var t=Ib(e)?"checked":"value";e._valueTracker=a0(e,t,""+e[t])}}function Pb(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),o="";return e&&(o=Ib(e)?e.checked?"true":"false":e.value),e=o,e!==n?(t.setValue(e),!0):!1}var l0=/[\n"\\]/g;function xt(e){return e.replace(l0,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function Ur(e,t,n,o,a,l,c,i){e.name="",c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"?e.type=c:e.removeAttribute("type"),t!=null?c==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+tt(t)):e.value!==""+tt(t)&&(e.value=""+tt(t)):c!=="submit"&&c!=="reset"||e.removeAttribute("value"),t!=null?c==="number"&&e.value==t?Ii(e,tt(e.value)):Ii(e,tt(t)):n!=null?Ii(e,tt(n)):o!=null&&e.removeAttribute("value"),a==null&&l!=null&&(e.defaultChecked=!!l),a!=null&&(e.checked=a&&typeof a!="function"&&typeof a!="symbol"),i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"?e.name=""+tt(i):e.removeAttribute("name")}function ev(e,t,n,o,a,l,c,i){if(l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"&&(e.type=l),t!=null||n!=null){if(!(l!=="submit"&&l!=="reset"||t!=null)){Rr(e);return}n=n!=null?""+tt(n):"",t=t!=null?""+tt(t):n,i||t===e.value||(e.value=t),e.defaultValue=t}o=o??a,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=i?e.checked:!!o,e.defaultChecked=!!o,c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"&&(e.name=c),Rr(e)}function Ii(e,t){e.defaultValue!==""+t&&(e.defaultValue=""+t)}function Io(e,t,n,o){if(e=e.options,t){t={};for(var a=0;a<n.length;a++)t["$"+n[a]]=!0;for(n=0;n<e.length;n++)a=t.hasOwnProperty("$"+e[n].value),e[n].selected!==a&&(e[n].selected=a),a&&o&&(e[n].defaultSelected=!0)}else{for(n=""+tt(n),t=null,a=0;a<e.length;a++){if(e[a].value===n){e[a].selected=!0,o&&(e[a].defaultSelected=!0);return}t!==null||e[a].disabled||(t=e[a])}t!==null&&(t.selected=!0)}}function tv(e,t,n){if(t!=null&&(t=""+tt(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n!=null?""+tt(n):""}function nv(e,t,n,o){if(t==null){if(o!=null){if(n!=null)throw Error(h(92));if(Ya(o)){if(1<o.length)throw Error(h(93));o=o[0]}n=o}n==null&&(n=""),t=n}n=tt(t),e.defaultValue=n,o=e.textContent,o===n&&o!==""&&o!==null&&(e.value=o),Rr(e)}function ua(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var c0=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function ls(e,t,n){var o=t.indexOf("--")===0;n==null||typeof n=="boolean"||n===""?o?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":o?e.setProperty(t,n):typeof n!="number"||n===0||c0.has(t)?t==="float"?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function ov(e,t,n){if(t!=null&&typeof t!="object")throw Error(h(62));if(e=e.style,n!=null){for(var o in n)!n.hasOwnProperty(o)||t!=null&&t.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="",j=!0);for(var a in t)o=t[a],t.hasOwnProperty(a)&&n[a]!==o&&(ls(e,a,o),j=!0)}else for(var l in t)t.hasOwnProperty(l)&&ls(e,l,t[l])}function Yu(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var i0=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),r0=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function uc(e){return r0.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function Lt(){}var Br=null;function Lu(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Vo=null,Po=null;function cs(e){var t=ka(e);if(t&&(e=t.stateNode)){var n=e[Fe]||null;e:switch(e=t.stateNode,t.type){case"input":if(Ur(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+xt(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var o=n[t];if(o!==e&&o.form===e.form){var a=o[Fe]||null;if(!a)throw Error(h(90));Ur(o,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)o=n[t],o.form===e.form&&Pb(o)}break e;case"textarea":tv(e,n.value,n.defaultValue);break e;case"select":t=n.value,t!=null&&Io(e,!!n.multiple,t,!1)}}}var Pi=!1;function av(e,t,n){if(Pi)return e(t,n);Pi=!0;try{var o=e(t);return o}finally{if(Pi=!1,(Vo!==null||Po!==null)&&(pi(),Vo&&(t=Vo,e=Po,Po=Vo=null,cs(t),e)))for(t=0;t<e.length;t++)cs(e[t])}}function al(e,t){var n=e.stateNode;if(n===null)return null;var o=n[Fe]||null;if(o===null)return null;n=o[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(h(231,t,typeof n));return n}var on=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),qr=!1;if(on)try{Do={},Object.defineProperty(Do,"passive",{get:function(){qr=!0}}),window.addEventListener("test",Do,Do),window.removeEventListener("test",Do,Do)}catch{qr=!1}var Do,Tn=null,Vu=null,dc=null;function lv(){if(dc)return dc;var e,t=Vu,n=t.length,o,a="value"in Tn?Tn.value:Tn.textContent,l=a.length;for(e=0;e<n&&t[e]===a[e];e++);var c=n-e;for(o=1;o<=c&&t[n-o]===a[l-o];o++);return dc=a.slice(e,1<o?1-o:void 0)}function fc(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Zl(){return!0}function is(){return!1}function Ve(e){function t(n,o,a,l,c){this._reactName=n,this._targetInst=a,this.type=o,this.nativeEvent=l,this.target=c,this.currentTarget=null;for(var i in e)e.hasOwnProperty(i)&&(n=e[i],this[i]=n?n(l):l[i]);return this.isDefaultPrevented=(l.defaultPrevented!=null?l.defaultPrevented:l.returnValue===!1)?Zl:is,this.isPropagationStopped=is,this}return $(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=Zl)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=Zl)},persist:function(){},isPersistent:Zl}),t}var Gn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},ai=Ve(Gn),wl=$({},Gn,{view:0,detail:0}),u0=Ve(wl),er,tr,Ha,li=$({},wl,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Gu,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Ha&&(Ha&&e.type==="mousemove"?(er=e.screenX-Ha.screenX,tr=e.screenY-Ha.screenY):tr=er=0,Ha=e),er)},movementY:function(e){return"movementY"in e?e.movementY:tr}}),rs=Ve(li),d0=$({},li,{dataTransfer:0}),f0=Ve(d0),s0=$({},wl,{relatedTarget:0}),nr=Ve(s0),b0=$({},Gn,{animationName:0,elapsedTime:0,pseudoElement:0}),v0=Ve(b0),g0=$({},Gn,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),m0=Ve(g0),p0=$({},Gn,{data:0}),us=Ve(p0),h0={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},y0={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},x0={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function k0(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=x0[e])?!!t[e]:!1}function Gu(){return k0}var S0=$({},wl,{key:function(e){if(e.key){var t=h0[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=fc(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?y0[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Gu,charCode:function(e){return e.type==="keypress"?fc(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?fc(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),T0=Ve(S0),w0=$({},li,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),ds=Ve(w0),E0=$({},Gn,{submitter:0}),z0=Ve(E0),N0=$({},wl,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Gu}),O0=Ve(N0),A0=$({},Gn,{propertyName:0,elapsedTime:0,pseudoElement:0}),_0=Ve(A0),M0=$({},li,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),C0=Ve(M0),D0=$({},Gn,{newState:0,oldState:0,source:0}),H0=Ve(D0),R0=[9,13,27,32],Xu=on&&"CompositionEvent"in window,Xa=null;on&&"documentMode"in document&&(Xa=document.documentMode);var U0=on&&"TextEvent"in window&&!Xa,cv=on&&(!Xu||Xa&&8<Xa&&11>=Xa),fs=" ",ss=!1;function iv(e,t){switch(e){case"keyup":return R0.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function rv(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Go=!1;function B0(e,t){switch(e){case"compositionend":return rv(t);case"keypress":return t.which!==32?null:(ss=!0,fs);case"textInput":return e=t.data,e===fs&&ss?null:e;default:return null}}function q0(e,t){if(Go)return e==="compositionend"||!Xu&&iv(e,t)?(e=lv(),dc=Vu=Tn=null,Go=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return cv&&t.locale!=="ko"?null:t.data;default:return null}}var j0={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function bs(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!j0[e.type]:t==="textarea"}function uv(e,t,n,o){Vo?Po?Po.push(o):Po=[o]:Vo=o,t=Pc(t,"onChange"),0<t.length&&(n=new ai("onChange","change",null,n,o),e.push({event:n,listeners:t}))}var Qa=null,ll=null;function Y0(e){am(e,0)}function ci(e){var t=La(e);if(Pb(t))return e}function vs(e,t){if(e==="change")return t}var dv=!1;on&&(on?(Jl="oninput"in document,Jl||(or=document.createElement("div"),or.setAttribute("oninput","return;"),Jl=typeof or.oninput=="function"),Kl=Jl):Kl=!1,dv=Kl&&(!document.documentMode||9<document.documentMode));var Kl,Jl,or;function gs(){Qa&&(Qa.detachEvent("onpropertychange",fv),ll=Qa=null)}function fv(e){if(e.propertyName==="value"&&ci(ll)){var t=[];uv(t,ll,e,Lu(e)),av(Y0,t)}}function L0(e,t,n){e==="focusin"?(gs(),Qa=t,ll=n,Qa.attachEvent("onpropertychange",fv)):e==="focusout"&&gs()}function V0(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return ci(ll)}function G0(e,t){if(e==="click")return ci(t)}function X0(e,t){if(e==="input"||e==="change")return ci(t)}function Q0(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var ut=typeof Object.is=="function"?Object.is:Q0;function cl(e,t){if(ut(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),o=Object.keys(t);if(n.length!==o.length)return!1;for(o=0;o<n.length;o++){var a=n[o];if(!Hr.call(t,a)||!ut(e[a],t[a]))return!1}return!0}function jr(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function ms(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function ps(e,t){var n=ms(e);e=0;for(var o;n;){if(n.nodeType===3){if(o=e+n.textContent.length,e<=t&&o>=t)return{node:n,offset:t-e};e=o}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=ms(n)}}function sv(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?sv(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function bv(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=jr(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=jr(e.document)}return t}function Qu(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var Z0=on&&"documentMode"in document&&11>=document.documentMode,Xo=null,Yr=null,Za=null,Lr=!1;function hs(e,t,n){var o=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Lr||Xo==null||Xo!==jr(o)||(o=Xo,"selectionStart"in o&&Qu(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),Za&&cl(Za,o)||(Za=o,o=Pc(Yr,"onSelect"),0<o.length&&(t=new ai("onSelect","select",null,t,n),e.push({event:t,listeners:o}),t.target=Xo)))}function Wn(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var Qo={animationend:Wn("Animation","AnimationEnd"),animationiteration:Wn("Animation","AnimationIteration"),animationstart:Wn("Animation","AnimationStart"),transitionrun:Wn("Transition","TransitionRun"),transitionstart:Wn("Transition","TransitionStart"),transitioncancel:Wn("Transition","TransitionCancel"),transitionend:Wn("Transition","TransitionEnd")},ar={},vv={};on&&(vv=document.createElement("div").style,"AnimationEvent"in window||(delete Qo.animationend.animation,delete Qo.animationiteration.animation,delete Qo.animationstart.animation),"TransitionEvent"in window||delete Qo.transitionend.transition);function xo(e){if(ar[e])return ar[e];if(!Qo[e])return e;var t=Qo[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in vv)return ar[e]=t[n];return e}var gv=xo("animationend"),mv=xo("animationiteration"),pv=xo("animationstart"),K0=xo("transitionrun"),J0=xo("transitionstart"),$0=xo("transitioncancel"),hv=xo("transitionend"),yv=new Map,Vr="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Vr.push("scrollEnd");function Mt(e,t){yv.set(e,t),yo(t,[e])}var F0=0;function an(e,t){if(e.name!=null&&e.name!=="auto")return e.name;if(t.autoName!==null)return t.autoName;e=_t.identifierPrefix;var n=F0++;return e="_"+e+"t_"+n.toString(32)+"_",t.autoName=e}function ys(e){if(e==null||typeof e=="string")return e;var t=null,n=ca;if(n!==null)for(var o=0;o<n.length;o++){var a=e[n[o]];if(a!=null){if(a==="none")return"none";t=t==null?a:t+(" "+a)}}return t??e.default}function fn(e,t){return e=ys(e),t=ys(t),t==null?e==="auto"?null:e:t==="auto"?null:t}var Cc=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},pt=[],Zo=0,Zu=0;function ii(){for(var e=Zo,t=Zu=Zo=0;t<e;){var n=pt[t];pt[t++]=null;var o=pt[t];pt[t++]=null;var a=pt[t];pt[t++]=null;var l=pt[t];if(pt[t++]=null,o!==null&&a!==null){var c=o.pending;c===null?a.next=a:(a.next=c.next,c.next=a),o.pending=a}l!==0&&xv(n,a,l)}}function ri(e,t,n,o){pt[Zo++]=e,pt[Zo++]=t,pt[Zo++]=n,pt[Zo++]=o,Zu|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function Ku(e,t,n,o){return ri(e,t,n,o),Dc(e)}function ko(e,t){return ri(e,null,null,t),Dc(e)}function xv(e,t,n){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n);for(var a=!1,l=e.return;l!==null;)l.childLanes|=n,o=l.alternate,o!==null&&(o.childLanes|=n),l.tag===22&&(e=l.stateNode,e===null||e._visibility&1||(a=!0)),e=l,l=l.return;return e.tag===3?(l=e.stateNode,a&&t!==null&&(a=31-it(n),e=l.hiddenUpdates,o=e[a],o===null?e[a]=[t]:o.push(t),t.lane=n|536870912),l):null}function Dc(e){if(50<nl)throw nl=0,kc=null,Error(h(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Ko={};function W0(e,t,n,o){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Ke(e,t,n,o){return new W0(e,t,n,o)}function Ju(e){return e=e.prototype,!(!e||!e.isReactComponent)}function tn(e,t){var n=e.alternate;return n===null?(n=Ke(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function kv(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function sc(e,t,n,o,a,l){var c=0;if(o=e,typeof o=="function")Ju(o)&&(c=1);else if(typeof o=="string")c=Ty(e,n,Xt.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(o){case Ar:return e=Ke(31,n,t,a),e.elementType=Ar,e.lanes=l,e;case Yo:return lo(n.children,a,l,t);case qb:c=8,a|=24;break;case zr:return e=Ke(12,n,t,a|2),e.elementType=zr,e.lanes=l,e;case Nr:return e=Ke(13,n,t,a),e.elementType=Nr,e.lanes=l,e;case Or:return e=Ke(19,n,t,a),e.elementType=Or,e.lanes=l,e;case qp:case _r:return e=a|32,e=Ke(30,n,t,e),e.elementType=_r,e.lanes=l,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof o=="object"&&o!==null)switch(o.$$typeof){case Yt:c=10;break e;case jb:c=9;break e;case Ru:c=11;break e;case Uu:c=14;break e;case yn:c=16,o=null;break e}c=29,n=Error(h(130,e===null?"null":typeof e,"")),o=null}return t=Ke(c,n,t,a),t.elementType=e,t.type=o,t.lanes=l,t}function lo(e,t,n,o){return e=Ke(7,e,o,t),e.lanes=n,e}function lr(e,t,n){return e=Ke(6,e,null,t),e.lanes=n,e}function Sv(e){var t=Ke(18,null,null,0);return t.stateNode=e,t}function cr(e,t,n){return t=Ke(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var xs=new WeakMap;function kt(e,t){if(typeof e=="object"&&e!==null){var n=xs.get(e);return n!==void 0?n:(t={value:e,source:t,stack:If(t)},xs.set(e,t),t)}return{value:e,source:t,stack:If(t)}}var Jo=[],$o=0,Hc=null,il=0,ht=[],yt=0,qn=null,Vt=1,Gt="";function Pt(e,t){Jo[$o++]=il,Jo[$o++]=Hc,Hc=e,il=t}function Tv(e,t,n){ht[yt++]=Vt,ht[yt++]=Gt,ht[yt++]=qn,qn=e;var o=Vt;e=Gt;var a=32-it(o)-1;o&=~(1<<a),n+=1;var l=32-it(t)+a;if(30<l){var c=a-a%5;l=(o&(1<<c)-1).toString(32),o>>=c,a-=c,Vt=1<<32-it(t)+a|n<<a|o,Gt=l+e}else Vt=1<<l|n<<a|o,Gt=e}function ui(e){e.return!==null&&(Pt(e,1),Tv(e,1,0))}function $u(e){for(;e===Hc;)Hc=Jo[--$o],Jo[$o]=null,il=Jo[--$o],Jo[$o]=null;for(;e===qn;)qn=ht[--yt],ht[yt]=null,Gt=ht[--yt],ht[yt]=null,Vt=ht[--yt],ht[yt]=null}function wv(e,t){ht[yt++]=Vt,ht[yt++]=Gt,ht[yt++]=qn,Vt=t.id,Gt=t.overflow,qn=e}var Te=null,ee=null,R=!1,An=null,St=!1,Gr=Error(h(519));function jn(e){var t=Error(h(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw rl(kt(t,e)),Gr}function ks(e){var t=e.stateNode,n=e.type,o=e.memoizedProps;switch(t[Ne]=e,t[Fe]=o,n){case"dialog":U("cancel",t),U("close",t);break;case"iframe":case"object":case"embed":U("load",t);break;case"video":case"audio":for(n=0;n<sl.length;n++)U(sl[n],t);break;case"source":U("error",t);break;case"img":case"image":case"link":U("error",t),U("load",t);break;case"details":U("toggle",t);break;case"input":U("invalid",t),ev(t,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":U("invalid",t);break;case"textarea":U("invalid",t),nv(t,o.value,o.defaultValue,o.children)}n=o.children,typeof n!="string"&&typeof n!="number"&&typeof n!="bigint"||t.textContent===""+n||o.suppressHydrationWarning===!0||cm(t.textContent,n)?(o.popover!=null&&(U("beforetoggle",t),U("toggle",t)),o.onScroll!=null&&U("scroll",t),o.onScrollEnd!=null&&U("scrollend",t),o.onClick!=null&&(t.onclick=Lt),t=!0):t=!1,t||jn(e,!0)}function Rc(e){for(Te=e.return;Te;)switch(Te.tag){case 5:case 31:case 13:St=!1;return;case 27:case 3:St=!0;return;default:Te=Te.return}}function Ho(e){if(e!==Te)return!1;if(!R)return Rc(e),R=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!=="form"&&n!=="button")||Nu(e.type,e.memoizedProps)),n=!n),n&&ee&&jn(e),Rc(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(h(317));ee=pb(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(h(317));ee=pb(e)}else t===27?(t=ee,Xn(e.type)?(e=Mu,Mu=null,ee=e):ee=t):ee=Te?Tt(e.stateNode.nextSibling):null;return!0}function uo(){ee=Te=null,R=!1}function ir(){var e=An;return e!==null&&(Qe===null?Qe=e:Qe.push.apply(Qe,e),An=null),e}function rl(e){An===null?An=[e]:An.push(e)}var Xr=Kt(null),So=null,en=null;function wn(e,t,n){te(Xr,t._currentValue),t._currentValue=n}function nn(e){e._currentValue=Xr.current,Ae(Xr)}function bc(e,t,n){for(;e!==null;){var o=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,o!==null&&(o.childLanes|=t)):o!==null&&(o.childLanes&t)!==t&&(o.childLanes|=t),e===n)break;e=e.return}}function Qr(e,t,n,o){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var l=a.dependencies;if(l!==null){var c=a.child;l=l.firstContext;e:for(;l!==null;){var i=l;l=a;for(var r=0;r<t.length;r++)if(i.context===t[r]){l.lanes|=n,i=l.alternate,i!==null&&(i.lanes|=n),bc(l.return,n,e),o||(c=null);break e}l=i.next}}else if(a.tag===18){if(c=a.return,c===null)throw Error(h(341));c.lanes|=n,l=c.alternate,l!==null&&(l.lanes|=n),bc(c,n,e),c=null}else a.tag===13&&a.memoizedState!==null&&a.memoizedState.dehydrated===null?(a.lanes|=n,c=a.alternate,c!==null&&(c.lanes|=n),bc(a.return,n,e),c=a.child,c=c!==null?c.sibling:null):c=a.child;if(c!==null)c.return=a;else for(c=a;c!==null;){if(c===e){c=null;break}if(a=c.sibling,a!==null){a.return=c.return,c=a;break}c=c.return}a=c}}function fo(e,t,n,o){e=null;for(var a=t,l=!1;a!==null;){if(!l){if((a.flags&524288)!==0)l=!0;else if((a.flags&262144)!==0)break}if(a.tag===10){var c=a.alternate;if(c===null)throw Error(h(387));if(c=c.memoizedProps,c!==null){var i=a.type;ut(a.pendingProps.value,c.value)||(e!==null?e.push(i):e=[i])}}else if(a===Nc.current){if(c=a.alternate,c===null)throw Error(h(387));c.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e!==null?e.push(pa):e=[pa])}a=a.return}return e!==null&&Qr(t,e,n,o),t.flags|=262144,e!==null}function Uc(e){for(e=e.firstContext;e!==null;){if(!ut(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function so(e){So=e,en=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function Oe(e){return Ev(So,e)}function $l(e,t){return So===null&&so(e),Ev(e,t)}function Ev(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},en===null){if(e===null)throw Error(h(308));en=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else en=en.next=t;return n}var I0=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(n,o){e.push(o)}};this.abort=function(){t.aborted=!0,e.forEach(function(n){return n()})}},P0=ye.unstable_scheduleCallback,eh=ye.unstable_NormalPriority,be={$$typeof:Yt,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Fu(){return{controller:new I0,data:new Map,refCount:0}}function El(e){e.refCount--,e.refCount===0&&P0(eh,function(){e.controller.abort()})}function Ss(e,t){if((e.pendingLanes&4194048)!==0){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var o=t[e];n.indexOf(o)===-1&&n.push(o)}}}var Va=null;function th(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var Ka=null,Zr=0,bo=0,ea=null;function nh(e,t){if(Ka===null){var n=Ka=[];Zr=0,bo=wd(),ea={status:"pending",value:void 0,then:function(o){n.push(o)}}}return Zr++,t.then(Ts,Ts),t}function Ts(){if(--Zr===0&&(Va=null,Ka!==null)){ea!==null&&(ea.status="fulfilled");var e=Ka;Ka=null,bo=0,ea=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function oh(e,t){var n=[],o={status:"pending",value:null,reason:null,then:function(a){n.push(a)}};return e.then(function(){o.status="fulfilled",o.value=t;for(var a=0;a<n.length;a++)(0,n[a])(t)},function(a){for(o.status="rejected",o.reason=a,a=0;a<n.length;a++)(0,n[a])(void 0)}),o}var ws=O.S;O.S=function(e,t){if(Gg=lt(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&nh(e,t),Va!==null)for(var n=va;n!==null;)Ss(n,Va),n=n.next;if(n=e.types,n!==null){for(var o=va;o!==null;)Ss(o,n),o=o.next;if(bo!==0){o=Va,o===null&&(o=Va=[]);for(var a=0;a<n.length;a++){var l=n[a];o.indexOf(l)===-1&&o.push(l)}}}ws!==null&&ws(e,t)};var co=Kt(null);function Wu(){var e=co.current;return e!==null?e:J.pooledCache}function vc(e,t){t===null?te(co,co.current):te(co,t.pool)}function zv(){var e=Wu();return e===null?null:{parent:be._currentValue,pool:e}}var Sa=Error(h(460)),Iu=Error(h(474)),di=Error(h(542)),Bc={then:function(){}};function Es(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Nv(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(Lt,Lt),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Ns(e),e===void 0&&!("reason"in t)?Error(h(600)):e;default:if(typeof t.status=="string")t.then(Lt,Lt);else{if(e=J,e!==null&&100<e.shellSuspendCounter)throw Error(h(482));e=t,e.status="pending",e.then(function(o){if(t.status==="pending"){var a=t;a.status="fulfilled",a.value=o}},function(o){if(t.status==="pending"){var a=t;a.status="rejected",a.reason=o}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Ns(e),e}throw io=t,Sa}}function eo(e){try{var t=e._init;return t(e._payload)}catch(n){throw n!==null&&typeof n=="object"&&typeof n.then=="function"?(io=n,Sa):n}}var io=null;function zs(){if(io===null)throw Error(h(459));var e=io;return io=null,e}function Ns(e){if(e===Sa||e===di)throw Error(h(483))}var ta=null,ul=0;function Fl(e){var t=ul;return ul+=1,ta===null&&(ta=[]),Nv(ta,e,t)}function mn(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function Wl(e,t){throw t.$$typeof===Bp?Error(h(525)):(e=Object.prototype.toString.call(t),Error(h(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function Ov(e){function t(f,u){if(e){var g=f.deletions;g===null?(f.deletions=[u],f.flags|=16):g.push(u)}}function n(f,u){if(!e)return null;for(;u!==null;)t(f,u),u=u.sibling;return null}function o(f){for(var u=new Map;f!==null;)f.key===null?u.set(f.index,f):u.set(f.key,f),f=f.sibling;return u}function a(f,u){return f=tn(f,u),f.index=0,f.sibling=null,f}function l(f,u,g){return f.index=g,e?(g=f.alternate,g!==null?(g=g.index,g<u?(f.flags|=2,u):g):(f.flags|=134217730,u)):(f.flags|=1048576,u)}function c(f){return e&&f.alternate===null&&(f.flags|=134217730),f}function i(f,u,g,p){return u===null||u.tag!==6?(u=lr(g,f.mode,p),u.return=f,u):(u=a(u,g),u.return=f,u)}function r(f,u,g,p){var T=g.type;return T===Yo?(f=v(f,u,g.props.children,p,g.key),mn(f,g),f):u!==null&&(u.elementType===T||typeof T=="object"&&T!==null&&T.$$typeof===yn&&eo(T)===u.type)?(u=a(u,g.props),mn(u,g),u.return=f,u):(u=sc(g.type,g.key,g.props,null,f.mode,p),mn(u,g),u.return=f,u)}function d(f,u,g,p){return u===null||u.tag!==4||u.stateNode.containerInfo!==g.containerInfo||u.stateNode.implementation!==g.implementation?(u=cr(g,f.mode,p),u.return=f,u):(u=a(u,g.children||[]),u.return=f,u)}function v(f,u,g,p,T){return u===null||u.tag!==7?(u=lo(g,f.mode,p,T),u.return=f,u):(u=a(u,g),u.return=f,u)}function m(f,u,g){if(typeof u=="string"&&u!==""||typeof u=="number"||typeof u=="bigint")return u=lr(""+u,f.mode,g),u.return=f,u;if(typeof u=="object"&&u!==null){switch(u.$$typeof){case Ll:return g=sc(u.type,u.key,u.props,null,f.mode,g),mn(g,u),g.return=f,g;case ja:return u=cr(u,f.mode,g),u.return=f,u;case yn:return u=eo(u),m(f,u,g)}if(Ya(u)||Da(u))return u=lo(u,f.mode,g,null),u.return=f,u;if(typeof u.then=="function")return m(f,Fl(u),g);if(u.$$typeof===Yt)return m(f,$l(f,u),g);Wl(f,u)}return null}function s(f,u,g,p){var T=u!==null?u.key:null;if(typeof g=="string"&&g!==""||typeof g=="number"||typeof g=="bigint")return T!==null?null:i(f,u,""+g,p);if(typeof g=="object"&&g!==null){switch(g.$$typeof){case Ll:return g.key===T?r(f,u,g,p):null;case ja:return g.key===T?d(f,u,g,p):null;case yn:return g=eo(g),s(f,u,g,p)}if(Ya(g)||Da(g))return T!==null?null:v(f,u,g,p,null);if(typeof g.then=="function")return s(f,u,Fl(g),p);if(g.$$typeof===Yt)return s(f,u,$l(f,g),p);Wl(f,g)}return null}function b(f,u,g,p,T){if(typeof p=="string"&&p!==""||typeof p=="number"||typeof p=="bigint")return f=f.get(g)||null,i(u,f,""+p,T);if(typeof p=="object"&&p!==null){switch(p.$$typeof){case Ll:return f=f.get(p.key===null?g:p.key)||null,r(u,f,p,T);case ja:return f=f.get(p.key===null?g:p.key)||null,d(u,f,p,T);case yn:return p=eo(p),b(f,u,g,p,T)}if(Ya(p)||Da(p))return f=f.get(g)||null,v(u,f,p,T,null);if(typeof p.then=="function")return b(f,u,g,Fl(p),T);if(p.$$typeof===Yt)return b(f,u,g,$l(u,p),T);Wl(u,p)}return null}function y(f,u,g,p){for(var T=null,A=null,w=u,E=u=0,V=null;w!==null&&E<g.length;E++){w.index>E?(V=w,w=null):V=w.sibling;var D=s(f,w,g[E],p);if(D===null){w===null&&(w=V);break}e&&w&&D.alternate===null&&t(f,w),u=l(D,u,E),A===null?T=D:A.sibling=D,A=D,w=V}if(E===g.length)return n(f,w),R&&Pt(f,E),T;if(w===null){for(;E<g.length;E++)w=m(f,g[E],p),w!==null&&(u=l(w,u,E),A===null?T=w:A.sibling=w,A=w);return R&&Pt(f,E),T}for(w=o(w);E<g.length;E++)V=b(w,f,E,g[E],p),V!==null&&(e&&(D=V.alternate,D!==null&&w.delete(D.key===null?E:D.key)),u=l(V,u,E),A===null?T=V:A.sibling=V,A=V);return e&&w.forEach(function(ue){return t(f,ue)}),R&&Pt(f,E),T}function k(f,u,g,p){if(g==null)throw Error(h(151));for(var T=null,A=null,w=u,E=u=0,V=null,D=g.next();w!==null&&!D.done;E++,D=g.next()){w.index>E?(V=w,w=null):V=w.sibling;var ue=s(f,w,D.value,p);if(ue===null){w===null&&(w=V);break}e&&w&&ue.alternate===null&&t(f,w),u=l(ue,u,E),A===null?T=ue:A.sibling=ue,A=ue,w=V}if(D.done)return n(f,w),R&&Pt(f,E),T;if(w===null){for(;!D.done;E++,D=g.next())D=m(f,D.value,p),D!==null&&(u=l(D,u,E),A===null?T=D:A.sibling=D,A=D);return R&&Pt(f,E),T}for(w=o(w);!D.done;E++,D=g.next())D=b(w,f,E,D.value,p),D!==null&&(e&&(V=D.alternate,V!==null&&w.delete(V.key===null?E:V.key)),u=l(D,u,E),A===null?T=D:A.sibling=D,A=D);return e&&w.forEach(function(z){return t(f,z)}),R&&Pt(f,E),T}function x(f,u,g,p){if(typeof g=="object"&&g!==null&&g.type===Yo&&g.key===null&&g.props.ref===void 0&&(g=g.props.children),typeof g=="object"&&g!==null){switch(g.$$typeof){case Ll:e:{for(var T=g.key;u!==null;){if(u.key===T){if(T=g.type,T===Yo){if(u.tag===7){n(f,u.sibling),p=a(u,g.props.children),mn(p,g),p.return=f,f=p;break e}}else if(u.elementType===T||typeof T=="object"&&T!==null&&T.$$typeof===yn&&eo(T)===u.type){n(f,u.sibling),p=a(u,g.props),mn(p,g),p.return=f,f=p;break e}n(f,u);break}else t(f,u);u=u.sibling}g.type===Yo?(p=lo(g.props.children,f.mode,p,g.key),mn(p,g),p.return=f,f=p):(p=sc(g.type,g.key,g.props,null,f.mode,p),mn(p,g),p.return=f,f=p)}return c(f);case ja:e:{for(T=g.key;u!==null;){if(u.key===T)if(u.tag===4&&u.stateNode.containerInfo===g.containerInfo&&u.stateNode.implementation===g.implementation){n(f,u.sibling),p=a(u,g.children||[]),p.return=f,f=p;break e}else{n(f,u);break}else t(f,u);u=u.sibling}p=cr(g,f.mode,p),p.return=f,f=p}return c(f);case yn:return g=eo(g),x(f,u,g,p)}if(Ya(g))return y(f,u,g,p);if(Da(g)){if(T=Da(g),typeof T!="function")throw Error(h(150));return g=T.call(g),k(f,u,g,p)}if(typeof g.then=="function")return x(f,u,Fl(g),p);if(g.$$typeof===Yt)return x(f,u,$l(f,g),p);Wl(f,g)}return typeof g=="string"&&g!==""||typeof g=="number"||typeof g=="bigint"?(g=""+g,u!==null&&u.tag===6?(n(f,u.sibling),p=a(u,g),p.return=f,f=p):(n(f,u),p=lr(g,f.mode,p),p.return=f,f=p),c(f)):n(f,u)}return function(f,u,g,p){try{ul=0;var T=x(f,u,g,p);return ta=null,T}catch(w){if(w===Sa||w===di)throw w;var A=Ke(29,w,null,f.mode);return A.lanes=p,A.return=f,A}}}var vo=Ov(!0),Av=Ov(!1),xn=!1;function Pu(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Kr(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function _n(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Mn(e,t,n){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(Y&2)!==0){var a=o.pending;return a===null?t.next=t:(t.next=a.next,a.next=t),o.pending=t,t=Dc(e),xv(e,null,n),t}return ri(e,o,t,n),Dc(e)}function Ja(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194048)!==0)){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Zb(e,n)}}function rr(e,t){var n=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,n===o)){var a=null,l=null;if(n=n.firstBaseUpdate,n!==null){do{var c={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};l===null?a=l=c:l=l.next=c,n=n.next}while(n!==null);l===null?a=l=t:l=l.next=t}else a=l=t;n={baseState:o.baseState,firstBaseUpdate:a,lastBaseUpdate:l,shared:o.shared,callbacks:o.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var Jr=!1;function $a(){if(Jr){var e=ea;if(e!==null)throw e}}function Fa(e,t,n,o){Jr=!1;var a=e.updateQueue;xn=!1;var l=a.firstBaseUpdate,c=a.lastBaseUpdate,i=a.shared.pending;if(i!==null){a.shared.pending=null;var r=i,d=r.next;r.next=null,c===null?l=d:c.next=d,c=r;var v=e.alternate;v!==null&&(v=v.updateQueue,i=v.lastBaseUpdate,i!==c&&(i===null?v.firstBaseUpdate=d:i.next=d,v.lastBaseUpdate=r))}if(l!==null){var m=a.baseState;c=0,v=d=r=null,i=l;do{var s=i.lane&-536870913,b=s!==i.lane;if(b?(q&s)===s:(o&s)===s){s!==0&&s===bo&&(Jr=!0),v!==null&&(v=v.next={lane:0,tag:i.tag,payload:i.payload,callback:null,next:null});e:{var y=e,k=i;s=t;var x=n;switch(k.tag){case 1:if(y=k.payload,typeof y=="function"){m=y.call(x,m,s);break e}m=y;break e;case 3:y.flags=y.flags&-65537|128;case 0:if(y=k.payload,s=typeof y=="function"?y.call(x,m,s):y,s==null)break e;m=$({},m,s);break e;case 2:xn=!0}}s=i.callback,s!==null&&(e.flags|=64,b&&(e.flags|=8192),b=a.callbacks,b===null?a.callbacks=[s]:b.push(s))}else b={lane:s,tag:i.tag,payload:i.payload,callback:i.callback,next:null},v===null?(d=v=b,r=m):v=v.next=b,c|=s;if(i=i.next,i===null){if(i=a.shared.pending,i===null)break;b=i,i=b.next,b.next=null,a.lastBaseUpdate=b,a.shared.pending=null}}while(!0);v===null&&(r=m),a.baseState=r,a.firstBaseUpdate=d,a.lastBaseUpdate=v,l===null&&(a.shared.lanes=0),Vn|=c,e.lanes=c,e.memoizedState=m}}function _v(e,t){if(typeof e!="function")throw Error(h(191,e));e.call(t)}function Mv(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)_v(n[e],t)}var Yn=Kt(null),qc=Kt(0);function Os(e,t){e=un,te(qc,e),te(Yn,t),un=e|t.baseLanes}function $r(){te(qc,un),te(Yn,Yn.current)}function ed(){un=qc.current,Ae(Yn),Ae(qc)}var Ce=Kt(null),Ue=null;function Cn(e){var t=e.alternate;te(_e,_e.current&1),te(Ce,e),Ue===null&&(t===null||Yn.current!==null||t.memoizedState!==null)&&(Ue=e)}function Fr(e){te(_e,_e.current),te(Ce,e),Ue===null&&(Ue=e)}function Cv(e){e.tag===22?(te(_e,_e.current),te(Ce,e),Ue===null&&(Ue=e)):Dn()}function Dn(){te(_e,_e.current),te(Ce,Ce.current)}function nt(e){Ae(Ce),Ue===e&&(Ue=null),Ae(_e)}var _e=Kt(0);function dl(e,t){te(Ce,Ce.current),te(_e,t)}function td(e){Ae(_e),Ae(Ce),Ue===e&&(Ue=null)}function jc(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||_u(n)||Od(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!=="independent"){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var ln=0,C=null,K=null,se=null,Yc=!1,na=!1,go=!1,Lc=0,fl=0,oa=null,ah=0;function ie(){throw Error(h(321))}function nd(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!ut(e[n],t[n]))return!1;return!0}function od(e,t,n,o,a,l){return ln=l,C=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,O.H=e===null||e.memoizedState===null?ug:dg,go=!1,l=n(o,a),go=!1,na&&(l=Hv(t,n,o,a)),Dv(e),l}function Dv(e){O.H=Vc;var t=K!==null&&K.next!==null;if(ln=0,se=K=C=null,Yc=!1,fl=0,oa=null,t)throw Error(h(300));e===null||ve||(e=e.dependencies,e!==null&&Uc(e)&&(ve=!0))}function Hv(e,t,n,o){C=e;var a=0;do{if(na&&(oa=null),fl=0,na=!1,25<=a)throw Error(h(301));if(a+=1,se=K=null,e.updateQueue!=null){var l=e.updateQueue;l.lastEffect=null,l.events=null,l.stores=null,l.memoCache!=null&&(l.memoCache.index=0)}O.H=sh,l=t(n,o)}while(na);return l}function lh(){var e=O.H,t=e.useState()[0];return t=typeof t.then=="function"?zl(t):t,e=e.useState()[0],(K!==null?K.memoizedState:null)!==e&&(C.flags|=1024),t}function ad(){var e=Lc!==0;return Lc=0,e}function ld(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function cd(e){if(Yc){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Yc=!1}ln=0,se=K=C=null,na=!1,fl=Lc=0,oa=null}function Le(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return se===null?C.memoizedState=se=e:se=se.next=e,se}function de(){if(K===null){var e=C.alternate;e=e!==null?e.memoizedState:null}else e=K.next;var t=se===null?C.memoizedState:se.next;if(t!==null)se=t,K=e;else{if(e===null)throw C.alternate===null?Error(h(467)):Error(h(310));K=e,e={memoizedState:K.memoizedState,baseState:K.baseState,baseQueue:K.baseQueue,queue:K.queue,next:null},se===null?C.memoizedState=se=e:se=se.next=e}return se}function fi(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function zl(e){var t=fl;return fl+=1,oa===null&&(oa=[]),e=Nv(oa,e,t),t=C,(se===null?t.memoizedState:se.next)===null&&(t=t.alternate,O.H=t===null||t.memoizedState===null?ug:dg),e}function si(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return zl(e);if(e.$$typeof===Yp)return;if(e.$$typeof===Yt)return Oe(e)}throw Error(h(438,String(e)))}function id(e){var t=null,n=C.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var o=C.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(t={data:o.data.map(function(a){return a.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),n===null&&(n=fi(),C.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),o=0;o<e;o++)n[o]=jp;return t.index++,n}function cn(e,t){return typeof t=="function"?t(e):t}function gc(e){var t=de();return rd(t,K,e)}function rd(e,t,n){var o=e.queue;if(o===null)throw Error(h(311));o.lastRenderedReducer=n;var a=e.baseQueue,l=o.pending;if(l!==null){if(a!==null){var c=a.next;a.next=l.next,l.next=c}t.baseQueue=a=l,o.pending=null}if(l=e.baseState,a===null)e.memoizedState=l;else{t=a.next;var i=c=null,r=null,d=t,v=!1;do{var m=d.lane&-536870913;if(m!==d.lane?(q&m)===m:(ln&m)===m){var s=d.revertLane;if(s===0)r!==null&&(r=r.next={lane:0,revertLane:0,gesture:null,action:d.action,hasEagerState:d.hasEagerState,eagerState:d.eagerState,next:null}),m===bo&&(v=!0);else if((ln&s)===s){d=d.next,s===bo&&(v=!0);continue}else m={lane:0,revertLane:d.revertLane,gesture:null,action:d.action,hasEagerState:d.hasEagerState,eagerState:d.eagerState,next:null},r===null?(i=r=m,c=l):r=r.next=m,C.lanes|=s,Vn|=s;m=d.action,go&&n(l,m),l=d.hasEagerState?d.eagerState:n(l,m)}else s={lane:m,revertLane:d.revertLane,gesture:d.gesture,action:d.action,hasEagerState:d.hasEagerState,eagerState:d.eagerState,next:null},r===null?(i=r=s,c=l):r=r.next=s,C.lanes|=m,Vn|=m;d=d.next}while(d!==null&&d!==t);if(r===null?c=l:r.next=i,!ut(l,e.memoizedState)&&(ve=!0,v&&(n=ea,n!==null)))throw n;e.memoizedState=l,e.baseState=c,e.baseQueue=r,o.lastRenderedState=l}return a===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function ur(e){var t=de(),n=t.queue;if(n===null)throw Error(h(311));n.lastRenderedReducer=e;var o=n.dispatch,a=n.pending,l=t.memoizedState;if(a!==null){n.pending=null;var c=a=a.next;do l=e(l,c.action),c=c.next;while(c!==a);ut(l,t.memoizedState)||(ve=!0),t.memoizedState=l,t.baseQueue===null&&(t.baseState=l),n.lastRenderedState=l}return[l,o]}function Rv(e,t,n){var o=C,a=de(),l=R;if(l){if(n===void 0)throw Error(h(407));n=n()}else n=t();var c=!ut((K||a).memoizedState,n);if(c&&(a.memoizedState=n,ve=!0),a=a.queue,ud(qv.bind(null,o,a,e),[e]),e=a.getSnapshot!==t||c||se!==null&&(se.memoizedState.tag&1)!==0,da(e?9:8,{destroy:void 0},Bv.bind(null,o,a,n,t),null),e){if(o.flags|=2048,J===null)throw Error(h(349));l||(ln&127)!==0||Uv(o,t,n)}return n}function Uv(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=C.updateQueue,t===null?(t=fi(),C.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Bv(e,t,n,o){t.value=n,t.getSnapshot=o,jv(t)&&Yv(e)}function qv(e,t,n){return n(function(){jv(t)&&Yv(e)})}function jv(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!ut(e,n)}catch{return!0}}function Yv(e){var t=ko(e,2);t!==null&&Je(t,e,2)}function Wr(e){var t=Le();if(typeof e=="function"){var n=e;if(e=n(),go){Sn(!0);try{n()}finally{Sn(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:cn,lastRenderedState:e},t}function Lv(e,t,n,o){return e.baseState=n,rd(e,K,typeof o=="function"?o:cn)}function ch(e,t,n,o,a){if(vi(e))throw Error(h(485));if(e=t.action,e!==null){var l={payload:a,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(c){l.listeners.push(c)}};O.T!==null?n(!0):l.isTransition=!1,o(l),n=t.pending,n===null?(l.next=t.pending=l,Vv(t,l)):(l.next=n.next,t.pending=n.next=l)}}function Vv(e,t){var n=t.action,o=t.payload,a=e.state;if(t.isTransition){var l=O.T,c={};c.types=l!==null?l.types:null,O.T=c;try{var i=n(a,o),r=O.S;r!==null&&r(c,i),As(e,t,i)}catch(d){Ir(e,t,d)}finally{l!==null&&c.types!==null&&(l.types=c.types),O.T=l}}else try{l=n(a,o),As(e,t,l)}catch(d){Ir(e,t,d)}}function As(e,t,n){n!==null&&typeof n=="object"&&typeof n.then=="function"?n.then(function(o){_s(e,t,o)},function(o){return Ir(e,t,o)}):_s(e,t,n)}function _s(e,t,n){t.status="fulfilled",t.value=n,Gv(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Vv(e,n)))}function Ir(e,t,n){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do t.status="rejected",t.reason=n,Gv(t),t=t.next;while(t!==o)}e.action=null}function Gv(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Xv(e,t){return t}function Ms(e,t){if(R){var n=J.formState;if(n!==null){e:{var o=C;if(R){if(ee){t:{for(var a=ee,l=St;a.nodeType!==8;){if(!l){a=null;break t}if(a=Tt(a.nextSibling),a===null){a=null;break t}}l=a.data,a=l==="F!"||l==="F"?a:null}if(a){ee=Tt(a.nextSibling),o=a.data==="F!";break e}}jn(o)}o=!1}o&&(t=n[0])}}return n=Le(),n.memoizedState=n.baseState=t,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Xv,lastRenderedState:t},n.queue=o,n=cg.bind(null,C,o),o.dispatch=n,o=Wr(!1),l=bd.bind(null,C,!1,o.queue),o=Le(),a={state:t,dispatch:null,action:e,pending:null},o.queue=a,n=ch.bind(null,C,a,l,n),a.dispatch=n,o.memoizedState=e,[t,n,!1]}function Cs(e){var t=de();return Qv(t,K,e)}function Qv(e,t,n){if(t=rd(e,t,Xv)[0],e=gc(cn)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var o=zl(t)}catch(c){throw c===Sa?di:c}else o=t;t=de();var a=t.queue,l=a.dispatch;return n!==t.memoizedState&&(C.flags|=2048,da(9,{destroy:void 0},ih.bind(null,a,n),null)),[o,l,e]}function ih(e,t){e.action=t}function Ds(e){var t=de(),n=K;if(n!==null)return Qv(t,n,e);de(),t=t.memoizedState,n=de();var o=n.queue.dispatch;return n.memoizedState=e,[t,o,!1]}function da(e,t,n,o){return e={tag:e,create:n,deps:o,inst:t,next:null},t=C.updateQueue,t===null&&(t=fi(),C.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(o=n.next,n.next=e,e.next=o,t.lastEffect=e),e}function Zv(){return de().memoizedState}function mc(e,t,n,o){var a=Le();C.flags|=e,a.memoizedState=da(1|t,{destroy:void 0},n,o===void 0?null:o)}function bi(e,t,n,o){var a=de();o=o===void 0?null:o;var l=a.memoizedState.inst;K!==null&&o!==null&&nd(o,K.memoizedState.deps)?a.memoizedState=da(t,l,n,o):(C.flags|=e,a.memoizedState=da(1|t,l,n,o))}function Hs(e,t){mc(8390656,8,e,t)}function ud(e,t){bi(2048,8,e,t)}function rh(e){C.flags|=4;var t=C.updateQueue;if(t===null)t=fi(),C.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Kv(e){var t=de().memoizedState;return rh({ref:t,nextImpl:e}),function(){if((Y&2)!==0)throw Error(h(440));return t.impl.apply(void 0,arguments)}}function Jv(e,t){return bi(4,2,e,t)}function $v(e,t){return bi(4,4,e,t)}function Fv(e,t){if(typeof t=="function"){e=e();var n=t(e);return function(){typeof n=="function"?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Wv(e,t,n){n=n!=null?n.concat([e]):null,bi(4,4,Fv.bind(null,t,e),n)}function dd(){}function Iv(e,t){var n=de();t=t===void 0?null:t;var o=n.memoizedState;return t!==null&&nd(t,o[1])?o[0]:(n.memoizedState=[e,t],e)}function Pv(e,t){var n=de();t=t===void 0?null:t;var o=n.memoizedState;if(t!==null&&nd(t,o[1]))return o[0];if(o=e(),go){Sn(!0);try{e()}finally{Sn(!1)}}return n.memoizedState=[o,t],o}function fd(e,t,n){return n===void 0||(ln&1073741824)!==0&&(q&261930)===0?e.memoizedState=t:(e.memoizedState=n,e=Qg(),C.lanes|=e,Vn|=e,n)}function eg(e,t,n,o){return ut(n,t)?n:Yn.current!==null?(e=fd(e,n,o),ut(e,t)||(ve=!0),e):(ln&106)===0||(ln&1073741824)!==0&&(q&261930)===0?(ve=!0,e.memoizedState=n):(e=Qg(),C.lanes|=e,Vn|=e,t)}function tg(e,t,n,o,a){var l=L.p;L.p=l!==0&&8>l?l:8;var c=O.T,i={};i.types=c!==null?c.types:null,O.T=i,bd(e,!1,t,n);try{var r=a(),d=O.S;if(d!==null&&d(i,r),r!==null&&typeof r=="object"&&typeof r.then=="function"){var v=oh(r,o);Wa(e,t,v,rt(e))}else Wa(e,t,o,rt(e))}catch(m){Wa(e,t,{then:function(){},status:"rejected",reason:m},rt())}finally{L.p=l,c!==null&&i.types!==null&&(c.types=i.types),O.T=c}}function uh(){}function Pr(e,t,n,o){if(e.tag!==5)throw Error(h(476));var a=ng(e).queue;tg(e,a,t,ao,n===null?uh:function(){return og(e),n(o)})}function ng(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:ao,baseState:ao,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:cn,lastRenderedState:ao},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:cn,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function og(e){var t=ng(e);t.next===null&&(t=e.alternate.memoizedState),Wa(e,t.next.queue,{},rt())}function sd(){return Oe(pa)}function ag(){return de().memoizedState}function lg(){return de().memoizedState}function dh(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=rt();e=_n(n);var o=Mn(t,e,n);o!==null&&(Je(o,t,n),Ja(o,t,n)),t={cache:Fu()},e.payload=t;return}t=t.return}}function fh(e,t,n){var o=rt();n={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},vi(e)?ig(t,n):(n=Ku(e,t,n,o),n!==null&&(Je(n,e,o),rg(n,t,o)))}function cg(e,t,n){var o=rt();Wa(e,t,n,o)}function Wa(e,t,n,o){var a={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(vi(e))ig(t,a);else{var l=e.alternate;if(e.lanes===0&&(l===null||l.lanes===0)&&(l=t.lastRenderedReducer,l!==null))try{var c=t.lastRenderedState,i=l(c,n);if(a.hasEagerState=!0,a.eagerState=i,ut(i,c))return ri(e,t,a,0),J===null&&ii(),!1}catch{}if(n=Ku(e,t,a,o),n!==null)return Je(n,e,o),rg(n,t,o),!0}return!1}function bd(e,t,n,o){if(o={lane:2,revertLane:wd(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},vi(e)){if(t)throw Error(h(479))}else t=Ku(e,n,o,2),t!==null&&Je(t,e,2)}function vi(e){var t=e.alternate;return e===C||t!==null&&t===C}function ig(e,t){na=Yc=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function rg(e,t,n){if((n&4194048)!==0){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Zb(e,n)}}var Vc={readContext:Oe,use:si,useCallback:ie,useContext:ie,useEffect:ie,useImperativeHandle:ie,useLayoutEffect:ie,useInsertionEffect:ie,useMemo:ie,useReducer:ie,useRef:ie,useState:ie,useDebugValue:ie,useDeferredValue:ie,useTransition:ie,useSyncExternalStore:ie,useId:ie,useHostTransitionStatus:ie,useFormState:ie,useActionState:ie,useOptimistic:ie,useMemoCache:ie,useCacheRefresh:ie,useEffectEvent:ie},ug={readContext:Oe,use:si,useCallback:function(e,t){return Le().memoizedState=[e,t===void 0?null:t],e},useContext:Oe,useEffect:Hs,useImperativeHandle:function(e,t,n){n=n!=null?n.concat([e]):null,mc(4194308,4,Fv.bind(null,t,e),n)},useLayoutEffect:function(e,t){return mc(4194308,4,e,t)},useInsertionEffect:function(e,t){mc(4,2,e,t)},useMemo:function(e,t){var n=Le();t=t===void 0?null:t;var o=e();if(go){Sn(!0);try{e()}finally{Sn(!1)}}return n.memoizedState=[o,t],o},useReducer:function(e,t,n){var o=Le();if(n!==void 0){var a=n(t);if(go){Sn(!0);try{n(t)}finally{Sn(!1)}}}else a=t;return o.memoizedState=o.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:a},o.queue=e,e=e.dispatch=fh.bind(null,C,e),[o.memoizedState,e]},useRef:function(e){var t=Le();return e={current:e},t.memoizedState=e},useState:function(e){e=Wr(e);var t=e.queue,n=cg.bind(null,C,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:dd,useDeferredValue:function(e,t){var n=Le();return fd(n,e,t)},useTransition:function(){var e=Wr(!1);return e=tg.bind(null,C,e.queue,!0,!1),Le().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var o=C,a=Le();if(R){if(n===void 0)throw Error(h(407));n=n()}else{if(n=t(),J===null)throw Error(h(349));(q&127)!==0||Uv(o,t,n)}a.memoizedState=n;var l={value:n,getSnapshot:t};return a.queue=l,Hs(qv.bind(null,o,l,e),[e]),o.flags|=2048,da(9,{destroy:void 0},Bv.bind(null,o,l,n,t),null),n},useId:function(){var e=Le(),t=J.identifierPrefix;if(R){var n=Gt,o=Vt;n=(o&~(1<<32-it(o)-1)).toString(32)+n,t="_"+t+"R_"+n,n=Lc++,0<n&&(t+="H"+n.toString(32)),t+="_"}else n=ah++,t="_"+t+"r_"+n.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:sd,useFormState:Ms,useActionState:Ms,useOptimistic:function(e){var t=Le();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=bd.bind(null,C,!0,n),n.dispatch=t,[e,t]},useMemoCache:id,useCacheRefresh:function(){return Le().memoizedState=dh.bind(null,C)},useEffectEvent:function(e){var t=Le(),n={impl:e};return t.memoizedState=n,function(){if((Y&2)!==0)throw Error(h(440));return n.impl.apply(void 0,arguments)}}},dg={readContext:Oe,use:si,useCallback:Iv,useContext:Oe,useEffect:ud,useImperativeHandle:Wv,useInsertionEffect:Jv,useLayoutEffect:$v,useMemo:Pv,useReducer:gc,useRef:Zv,useState:function(){return gc(cn)},useDebugValue:dd,useDeferredValue:function(e,t){var n=de();return eg(n,K.memoizedState,e,t)},useTransition:function(){var e=gc(cn)[0],t=de().memoizedState;return[typeof e=="boolean"?e:zl(e),t]},useSyncExternalStore:Rv,useId:ag,useHostTransitionStatus:sd,useFormState:Cs,useActionState:Cs,useOptimistic:function(e,t){var n=de();return Lv(n,K,e,t)},useMemoCache:id,useCacheRefresh:lg,useEffectEvent:Kv},sh={readContext:Oe,use:si,useCallback:Iv,useContext:Oe,useEffect:ud,useImperativeHandle:Wv,useInsertionEffect:Jv,useLayoutEffect:$v,useMemo:Pv,useReducer:ur,useRef:Zv,useState:function(){return ur(cn)},useDebugValue:dd,useDeferredValue:function(e,t){var n=de();return K===null?fd(n,e,t):eg(n,K.memoizedState,e,t)},useTransition:function(){var e=ur(cn)[0],t=de().memoizedState;return[typeof e=="boolean"?e:zl(e),t]},useSyncExternalStore:Rv,useId:ag,useHostTransitionStatus:sd,useFormState:Ds,useActionState:Ds,useOptimistic:function(e,t){var n=de();return K!==null?Lv(n,K,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:id,useCacheRefresh:lg,useEffectEvent:Kv};function dr(e,t,n,o){t=e.memoizedState,n=n(o,t),n=n==null?t:$({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var eu={enqueueSetState:function(e,t,n){e=e._reactInternals;var o=rt(),a=_n(o);a.payload=t,n!=null&&(a.callback=n),t=Mn(e,a,o),t!==null&&(Je(t,e,o),Ja(t,e,o))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var o=rt(),a=_n(o);a.tag=1,a.payload=t,n!=null&&(a.callback=n),t=Mn(e,a,o),t!==null&&(Je(t,e,o),Ja(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=rt(),o=_n(n);o.tag=2,t!=null&&(o.callback=t),t=Mn(e,o,n),t!==null&&(Je(t,e,n),Ja(t,e,n))}};function Rs(e,t,n,o,a,l,c){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,l,c):t.prototype&&t.prototype.isPureReactComponent?!cl(n,o)||!cl(a,l):!0}function Us(e,t,n,o){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,o),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,o),t.state!==e&&eu.enqueueReplaceState(t,t.state,null)}function mo(e,t){var n=t;if("ref"in t){n={};for(var o in t)o!=="ref"&&(n[o]=t[o])}if(e=e.defaultProps){n===t&&(n=$({},n));for(var a in e)n[a]===void 0&&(n[a]=e[a])}return n}function fg(e){Cc(e)}function sg(e){console.error(e)}function bg(e){Cc(e)}function Gc(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(o){setTimeout(function(){throw o})}}function Bs(e,t,n){try{var o=e.onCaughtError;o(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(a){setTimeout(function(){throw a})}}function tu(e,t,n){return n=_n(n),n.tag=3,n.payload={element:null},n.callback=function(){Gc(e,t)},n}function vg(e){return e=_n(e),e.tag=3,e}function gg(e,t,n,o){var a=n.type.getDerivedStateFromError;if(typeof a=="function"){var l=o.value;e.payload=function(){return a(l)},e.callback=function(){Bs(t,n,o)}}var c=n.stateNode;c!==null&&typeof c.componentDidCatch=="function"&&(e.callback=function(){Bs(t,n,o),typeof a!="function"&&(Hn===null?Hn=new Set([this]):Hn.add(this));var i=o.stack;this.componentDidCatch(o.value,{componentStack:i!==null?i:""})})}function bh(e,t,n,o,a){if(n.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(t=n.alternate,t!==null&&fo(t,n,a,!0),n=Ce.current,n!==null){switch(n.tag){case 31:case 13:case 19:return Ue===null?Wc():n.alternate===null&&re===0&&(re=3),n.flags&=-257,n.flags|=65536,n.lanes=a,o===Bc?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([o]):t.add(o),pr(e,o,a)),!1;case 22:return n.flags|=65536,o===Bc?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([o])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([o]):n.add(o)),pr(e,o,a)),!1}throw Error(h(435,n.tag))}return pr(e,o,a),Wc(),!1}if(R)return t=Ce.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=a,o!==Gr&&(e=Error(h(422),{cause:o}),rl(kt(e,n)))):(o!==Gr&&(t=Error(h(423),{cause:o}),rl(kt(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,o=kt(o,n),a=tu(e.stateNode,o,a),rr(e,a),re!==4&&(re=2)),!1;var l=Error(h(520),{cause:o});if(l=kt(l,n),tl===null?tl=[l]:tl.push(l),re!==4&&(re=2),t===null)return!0;o=kt(o,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=tu(n.stateNode,o,e),rr(n,e),!1;case 1:if(t=n.type,l=n.stateNode,(n.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||l!==null&&typeof l.componentDidCatch=="function"&&(Hn===null||!Hn.has(l))))return n.flags|=65536,a&=-a,n.lanes|=a,a=vg(a),gg(a,e,n,o),rr(n,a),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var vd=Error(h(461)),ve=!1;function pe(e,t,n,o){t.child=e===null?Av(t,null,n,o):vo(t,e.child,n,o)}function qs(e,t,n,o,a){n=n.render;var l=t.ref;if("ref"in o){var c={};for(var i in o)i!=="ref"&&(c[i]=o[i])}else c=o;return so(t),o=od(e,t,n,c,l,a),i=ad(),e!==null&&!ve?(ld(e,t,a),rn(e,t,a)):(R&&i&&ui(t),t.flags|=1,pe(e,t,o,a),t.child)}function js(e,t,n,o,a){if(e===null){var l=n.type;return typeof l=="function"&&!Ju(l)&&l.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=l,mg(e,t,l,o,a)):(e=sc(n.type,null,o,t,t.mode,a),e.ref=t.ref,e.return=t,t.child=e)}if(l=e.child,!md(e,a)){var c=l.memoizedProps;if(n=n.compare,n=n!==null?n:cl,n(c,o)&&e.ref===t.ref)return rn(e,t,a)}return t.flags|=1,e=tn(l,o),e.ref=t.ref,e.return=t,t.child=e}function mg(e,t,n,o,a){if(e!==null){var l=e.memoizedProps;if(cl(l,o)&&e.ref===t.ref)if(ve=!1,t.pendingProps=o=l,md(e,a))(e.flags&131072)!==0&&(ve=!0);else return t.lanes=e.lanes,rn(e,t,a)}return nu(e,t,n,o,a)}function pg(e,t,n,o){var a=o.children,l=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((t.flags&128)!==0){if(l=l!==null?l.baseLanes|n:n,e!==null){for(o=t.child=e.child,a=0;o!==null;)a=a|o.lanes|o.childLanes,o=o.sibling;o=a&~l}else o=0,t.child=null;return Ys(e,t,l,n,o)}if((n&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&vc(t,l!==null?l.cachePool:null),l!==null?Os(t,l):$r(),Cv(t);else return o=t.lanes=536870912,Ys(e,t,l!==null?l.baseLanes|n:n,n,o)}else l!==null?(vc(t,l.cachePool),Os(t,l),Dn(),t.memoizedState=null):(e!==null&&vc(t,null),$r(),Dn());return pe(e,t,a,n),t.child}function Ia(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Ys(e,t,n,o,a){var l=Wu();return l=l===null?null:{parent:be._currentValue,pool:l},t.memoizedState={baseLanes:n,cachePool:l},e!==null&&vc(t,null),$r(),Cv(t),e!==null&&fo(e,t,o,!0),t.childLanes=a,null}function pc(e,t){return t=gi({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Ls(e,t,n){return vo(t,e.child,null,n),e=pc(t,t.pendingProps),e.flags|=2,nt(t),t.memoizedState=null,e}function vh(e,t,n){var o=t.pendingProps,a=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(R){if(o.mode==="hidden")return e=pc(t,o),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},Ia(null,e);if(Fr(t),(e=ee)?(e=pm(e,St),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:qn!==null?{id:Vt,overflow:Gt}:null,retryLane:536870912,hydrationErrors:null},n=Sv(e),n.return=t,t.child=n,Te=t,ee=null)):e=null,e===null)throw jn(t);return t.lanes=536870912,null}return pc(t,o)}var l=e.memoizedState;if(l!==null){var c=l.dehydrated;if(Fr(t),a)if(t.flags&256)t.flags&=-257,t=Ls(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(h(558));else if(ve||fo(e,t,n,!1),a=(n&e.childLanes)!==0,ve||a){if(Yn.current===null){if(o=J,o!==null&&(c=Kb(o,n),c!==0&&c!==l.retryLane))throw l.retryLane=c,ko(e,c),Je(o,e,c),vd;Wc()}t=Ls(e,t,n)}else e=l.treeContext,ee=Tt(c.nextSibling),Te=t,R=!0,An=null,St=!1,e!==null&&wv(t,e),t=pc(t,o),t.flags|=134221824;return t}return e=tn(e.child,{mode:o.mode,children:o.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Uo(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!="function"&&typeof n!="object")throw Error(h(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function nu(e,t,n,o,a){return so(t),n=od(e,t,n,o,void 0,a),o=ad(),e!==null&&!ve?(ld(e,t,a),rn(e,t,a)):(R&&o&&ui(t),t.flags|=1,pe(e,t,n,a),t.child)}function Vs(e,t,n,o,a,l){return so(t),t.updateQueue=null,n=Hv(t,o,n,a),Dv(e),o=ad(),e!==null&&!ve?(ld(e,t,l),rn(e,t,l)):(R&&o&&ui(t),t.flags|=1,pe(e,t,n,l),t.child)}function Gs(e,t,n,o,a){if(so(t),t.stateNode===null){var l=Ko,c=n.contextType;typeof c=="object"&&c!==null&&(l=Oe(c)),l=new n(o,l),t.memoizedState=l.state!==null&&l.state!==void 0?l.state:null,l.updater=eu,t.stateNode=l,l._reactInternals=t,l=t.stateNode,l.props=o,l.state=t.memoizedState,l.refs={},Pu(t),c=n.contextType,l.context=typeof c=="object"&&c!==null?Oe(c):Ko,l.state=t.memoizedState,c=n.getDerivedStateFromProps,typeof c=="function"&&(dr(t,n,c,o),l.state=t.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof l.getSnapshotBeforeUpdate=="function"||typeof l.UNSAFE_componentWillMount!="function"&&typeof l.componentWillMount!="function"||(c=l.state,typeof l.componentWillMount=="function"&&l.componentWillMount(),typeof l.UNSAFE_componentWillMount=="function"&&l.UNSAFE_componentWillMount(),c!==l.state&&eu.enqueueReplaceState(l,l.state,null),Fa(t,o,l,a),$a(),l.state=t.memoizedState),typeof l.componentDidMount=="function"&&(t.flags|=4194308),o=!0}else if(e===null){l=t.stateNode;var i=t.memoizedProps,r=mo(n,i);l.props=r;var d=l.context,v=n.contextType;c=Ko,typeof v=="object"&&v!==null&&(c=Oe(v));var m=n.getDerivedStateFromProps;v=typeof m=="function"||typeof l.getSnapshotBeforeUpdate=="function",i=t.pendingProps!==i,v||typeof l.UNSAFE_componentWillReceiveProps!="function"&&typeof l.componentWillReceiveProps!="function"||(i||d!==c)&&Us(t,l,o,c),xn=!1;var s=t.memoizedState;l.state=s,Fa(t,o,l,a),$a(),d=t.memoizedState,i||s!==d||xn?(typeof m=="function"&&(dr(t,n,m,o),d=t.memoizedState),(r=xn||Rs(t,n,r,o,s,d,c))?(v||typeof l.UNSAFE_componentWillMount!="function"&&typeof l.componentWillMount!="function"||(typeof l.componentWillMount=="function"&&l.componentWillMount(),typeof l.UNSAFE_componentWillMount=="function"&&l.UNSAFE_componentWillMount()),typeof l.componentDidMount=="function"&&(t.flags|=4194308)):(typeof l.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=o,t.memoizedState=d),l.props=o,l.state=d,l.context=c,o=r):(typeof l.componentDidMount=="function"&&(t.flags|=4194308),o=!1)}else{l=t.stateNode,Kr(e,t),c=t.memoizedProps,v=mo(n,c),l.props=v,m=t.pendingProps,s=l.context,d=n.contextType,r=Ko,typeof d=="object"&&d!==null&&(r=Oe(d)),i=n.getDerivedStateFromProps,(d=typeof i=="function"||typeof l.getSnapshotBeforeUpdate=="function")||typeof l.UNSAFE_componentWillReceiveProps!="function"&&typeof l.componentWillReceiveProps!="function"||(c!==m||s!==r)&&Us(t,l,o,r),xn=!1,s=t.memoizedState,l.state=s,Fa(t,o,l,a),$a();var b=t.memoizedState;c!==m||s!==b||xn||e!==null&&e.dependencies!==null&&Uc(e.dependencies)?(typeof i=="function"&&(dr(t,n,i,o),b=t.memoizedState),(v=xn||Rs(t,n,v,o,s,b,r)||e!==null&&e.dependencies!==null&&Uc(e.dependencies))?(d||typeof l.UNSAFE_componentWillUpdate!="function"&&typeof l.componentWillUpdate!="function"||(typeof l.componentWillUpdate=="function"&&l.componentWillUpdate(o,b,r),typeof l.UNSAFE_componentWillUpdate=="function"&&l.UNSAFE_componentWillUpdate(o,b,r)),typeof l.componentDidUpdate=="function"&&(t.flags|=4),typeof l.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof l.componentDidUpdate!="function"||c===e.memoizedProps&&s===e.memoizedState||(t.flags|=4),typeof l.getSnapshotBeforeUpdate!="function"||c===e.memoizedProps&&s===e.memoizedState||(t.flags|=1024),t.memoizedProps=o,t.memoizedState=b),l.props=o,l.state=b,l.context=r,o=v):(typeof l.componentDidUpdate!="function"||c===e.memoizedProps&&s===e.memoizedState||(t.flags|=4),typeof l.getSnapshotBeforeUpdate!="function"||c===e.memoizedProps&&s===e.memoizedState||(t.flags|=1024),o=!1)}return l=o,Uo(e,t),o=(t.flags&128)!==0,l||o?(l=t.stateNode,n=o&&typeof n.getDerivedStateFromError!="function"?null:l.render(),t.flags|=1,e!==null&&o?(t.child=vo(t,e.child,null,a),t.child=vo(t,null,n,a)):pe(e,t,n,a),t.memoizedState=l.state,e=t.child):e=rn(e,t,a),e}function Xs(e,t,n,o){return uo(),t.flags|=256,pe(e,t,n,o),t.child}var ou={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function au(e){return{baseLanes:e,cachePool:zv()}}function lu(e,t,n){return e=e!==null?e.childLanes&~n:0,t&&(e|=at),e}function hg(e,t,n){var o=t.pendingProps,a=!1,l=(t.flags&128)!==0,c;if((c=l)||(c=e!==null&&e.memoizedState===null?!1:(_e.current&2)!==0),c&&(a=!0,t.flags&=-129),c=(t.flags&32)!==0,t.flags&=-33,e===null){if(R){if(a?Cn(t):Dn(),(e=ee)?(e=pm(e,St),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:qn!==null?{id:Vt,overflow:Gt}:null,retryLane:536870912,hydrationErrors:null},n=Sv(e),n.return=t,t.child=n,Te=t,ee=null)):e=null,e===null)throw jn(t);return Od(e)?t.lanes=32:t.lanes=536870912,null}return l=o.children,o=o.fallback,a?(Dn(),a=t.mode,l=gi({mode:"hidden",children:l},a),o=lo(o,a,n,null),l.return=t,o.return=t,l.sibling=o,t.child=l,o=t.child,o.memoizedState=au(n),o.childLanes=lu(e,c,n),t.memoizedState=ou,Ia(null,o)):(Cn(t),gd(t,l))}var i=e.memoizedState;if(i!==null){var r=i.dehydrated;if(r!==null)return gh(e,t,l,c,o,r,i,n)}return a?(Dn(),a=o.fallback,l=t.mode,i=e.child,r=i.sibling,o=tn(i,{mode:"hidden",children:o.children}),o.subtreeFlags=i.subtreeFlags&1206910976,r!==null?a=tn(r,a):(a=lo(a,l,n,null),a.flags|=2),a.return=t,o.return=t,o.sibling=a,t.child=o,Ia(null,o),o=t.child,a=e.child.memoizedState,a===null?a=au(n):(l=a.cachePool,l!==null?(i=be._currentValue,l=l.parent!==i?{parent:i,pool:i}:l):l=zv(),a={baseLanes:a.baseLanes|n,cachePool:l}),o.memoizedState=a,o.childLanes=lu(e,c,n),t.memoizedState=ou,Ia(e.child,o)):(Cn(t),n=e.child,e=n.sibling,n=tn(n,{mode:"visible",children:o.children}),n.return=t,n.sibling=null,e!==null&&(c=t.deletions,c===null?(t.deletions=[e],t.flags|=16):c.push(e)),t.child=n,t.memoizedState=null,n)}function gd(e,t){return t=gi({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function gi(e,t){return e=Ke(22,e,null,t),e.lanes=0,e}function Il(e,t,n){return vo(t,e.child,null,n),e=gd(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function gh(e,t,n,o,a,l,c,i){if(n)return t.flags&256?(Cn(t),t.flags&=-257,Il(e,t,i)):t.memoizedState!==null?(Dn(),t.child=e.child,t.flags|=128,null):(Dn(),l=a.fallback,c=t.mode,a=gi({mode:"visible",children:a.children},c),l=lo(l,c,i,null),l.flags|=2,a.return=t,l.return=t,a.sibling=l,t.child=a,vo(t,e.child,null,i),a=t.child,a.memoizedState=au(i),a.childLanes=lu(e,o,i),t.memoizedState=ou,Ia(null,a));if(Cn(t),Od(l)){if(o=l.nextSibling&&l.nextSibling.dataset,o)var r=o.dgst;return o=r,o!==""&&(a=Error(h(419)),a.stack="",a.digest=o,rl({value:a,source:null,stack:null})),Il(e,t,i)}if(ve||fo(e,t,i,!1),o=(i&e.childLanes)!==0,ve||o){if(Yn.current!==null)return Il(e,t,i);if(o=J,o!==null&&(a=Kb(o,i),a!==0&&a!==c.retryLane))throw c.retryLane=a,ko(e,a),Je(o,e,a),vd;return _u(l)||Wc(),Il(e,t,i)}return _u(l)?(t.flags|=192,t.child=e.child,null):(e=c.treeContext,ee=Tt(l.nextSibling),Te=t,R=!0,An=null,St=!1,e!==null&&wv(t,e),t=gd(t,a.children),t.flags|=134221824,t)}function Qs(e,t,n){e.lanes|=t;var o=e.alternate;o!==null&&(o.lanes|=t),bc(e.return,t,n)}function Zs(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&jc(n)===null&&(t=e),e=e.sibling}return t}function Pl(e,t,n,o,a,l){var c=e.memoizedState;c===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:o,tail:n,tailMode:a,treeForkCount:l}:(c.isBackwards=t,c.rendering=null,c.renderingStartTime=0,c.last=o,c.tail=n,c.tailMode=a,c.treeForkCount=l)}function fr(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function cu(e,t,n){var o=t.pendingProps,a=o.revealOrder,l=o.tail;o=o.children;var c=_e.current;if(t.flags&128)return dl(t,c),null;var i=(c&2)!==0;if(i?(c=c&1|2,t.flags|=128):c&=1,dl(t,c),a==="backwards"&&e!==null?(fr(e),pe(e,t,o,n),fr(e)):pe(e,t,o,n),o=R?il:0,!i&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Qs(e,n,t);else if(e.tag===19)Qs(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(a){case"backwards":n=Zs(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null,fr(t)),Pl(t,!0,a,null,l,o);break;case"unstable_legacy-backwards":for(n=null,a=t.child,t.child=null;a!==null;){if(e=a.alternate,e!==null&&jc(e)===null){t.child=a;break}e=a.sibling,a.sibling=n,n=a,a=e}Pl(t,!0,n,null,l,o);break;case"together":Pl(t,!1,null,null,void 0,o);break;case"independent":t.memoizedState=null;break;default:n=Zs(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null),Pl(t,!1,a,n,l,o)}return t.child}function Ks(e,t,n){var o=t.pendingProps;return wn(t,t.type,o.value),pe(e,t,o.children,n),t.child}function rn(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Vn|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(fo(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(h(153));if(t.child!==null){for(e=t.child,n=tn(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=tn(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function md(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&Uc(e)))}function mh(e,t,n){switch(t.tag){case 3:Oc(t,t.stateNode.containerInfo),wn(t,be,e.memoizedState.cache),uo();break;case 27:case 5:Dr(t);break;case 4:Oc(t,t.stateNode.containerInfo);break;case 10:wn(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,Fr(t),null;break;case 13:var o=t.memoizedState;if(o!==null){if(o.dehydrated!==null)return Cn(t),t.flags|=128,null;o=fo(e,t,n,!1);var a=t.child.childLanes;return o||(n&a)!==0?hg(e,t,n):(Cn(t),e=rn(e,t,n),e!==null?e.sibling:null)}Cn(t);break;case 19:if(t.flags&128)return cu(e,t,n);if(a=(e.flags&128)!==0,o=(n&t.childLanes)!==0,o||(fo(e,t,n,!1),o=(n&t.childLanes)!==0),a){if(o)return cu(e,t,n);t.flags|=128}if(a=t.memoizedState,a!==null&&(a.rendering=null,a.tail=null,a.lastEffect=null),dl(t,_e.current),o)break;return null;case 22:return t.lanes=0,pg(e,t,n,t.pendingProps);case 24:wn(t,be,e.memoizedState.cache)}return rn(e,t,n)}function yg(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)ve=!0;else{if(!md(e,n)&&(t.flags&128)===0)return ve=!1,mh(e,t,n);ve=(e.flags&131072)!==0}else ve=!1,R&&(t.flags&1048576)!==0&&Tv(t,il,t.index);switch(t.lanes=0,t.tag){case 16:e:{var o=t.pendingProps;if(e=eo(t.elementType),t.type=e,typeof e=="function")Ju(e)?(o=mo(e,o),t.tag=1,t=Gs(null,t,e,o,n)):(t.tag=0,t=nu(null,t,e,o,n));else{if(e!=null){var a=e.$$typeof;if(a===Ru){t.tag=11,t=qs(null,t,e,o,n);break e}else if(a===Uu){t.tag=14,t=js(null,t,e,o,n);break e}else if(a===Yt){t.tag=10,t.type=e,t=Ks(null,t,n);break e}}throw t=Mr(e)||e,Error(h(306,t,""))}}return t;case 0:return nu(e,t,t.type,t.pendingProps,n);case 1:return o=t.type,a=mo(o,t.pendingProps),Gs(e,t,o,a,n);case 3:e:{if(Oc(t,t.stateNode.containerInfo),e===null)throw Error(h(387));o=t.pendingProps;var l=t.memoizedState;a=l.element,Kr(e,t),Fa(t,o,null,n);var c=t.memoizedState;if(o=c.cache,wn(t,be,o),o!==l.cache&&Qr(t,[be],n,!0),$a(),o=c.element,l.isDehydrated)if(l={element:o,isDehydrated:!1,cache:c.cache},t.updateQueue.baseState=l,t.memoizedState=l,t.flags&256){t=Xs(e,t,o,n);break e}else if(o!==a){a=kt(Error(h(424)),t),rl(a),t=Xs(e,t,o,n);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,ee=Tt(e.firstChild),Te=t,R=!0,An=null,St=!0,n=Av(t,null,o,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling;else{if(uo(),o===a){t=rn(e,t,n);break e}pe(e,t,o,n)}t=t.child}return t;case 26:return Uo(e,t),e===null?(n=xb(t.type,null,t.pendingProps,null))?t.memoizedState=n:R||(t.stateNode=rm(t.type,t.pendingProps,On.current,t)):t.memoizedState=xb(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return Dr(t),e===null&&R&&(o=t.stateNode=hm(t.type,t.pendingProps,On.current),Te=t,St=!0,a=ee,Xn(t.type)?(Mu=a,ee=Tt(o.firstChild)):ee=a),pe(e,t,t.pendingProps.children,n),Uo(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&R&&((a=o=ee)&&(o=ry(o,t.type,t.pendingProps,St),o!==null?(t.stateNode=o,Te=t,ee=Tt(o.firstChild),St=!1,a=!0):a=!1),a||jn(t)),Dr(t),a=t.type,l=t.pendingProps,c=e!==null?e.memoizedProps:null,o=l.children,Nu(a,l)?o=null:c!==null&&Nu(a,c)&&(t.flags|=32),t.memoizedState!==null&&(a=od(e,t,lh,null,null,n),pa._currentValue=a),Uo(e,t),pe(e,t,o,n),t.child;case 6:return e===null&&R&&((e=n=ee)&&(n=uy(n,t.pendingProps,St),n!==null?(t.stateNode=n,Te=t,ee=null,e=!0):e=!1),e||jn(t)),null;case 13:return hg(e,t,n);case 4:return Oc(t,t.stateNode.containerInfo),o=t.pendingProps,e===null?t.child=vo(t,null,o,n):pe(e,t,o,n),t.child;case 11:return qs(e,t,t.type,t.pendingProps,n);case 7:return o=t.pendingProps,Uo(e,t),pe(e,t,o,n),t.child;case 8:return pe(e,t,t.pendingProps.children,n),t.child;case 12:return pe(e,t,t.pendingProps.children,n),t.child;case 10:return Ks(e,t,n);case 9:return a=t.type._context,o=t.pendingProps.children,so(t),a=Oe(a),o=o(a),t.flags|=1,pe(e,t,o,n),t.child;case 14:return js(e,t,t.type,t.pendingProps,n);case 15:return mg(e,t,t.type,t.pendingProps,n);case 19:return cu(e,t,n);case 31:return vh(e,t,n);case 22:return pg(e,t,n,t.pendingProps);case 24:return so(t),o=Oe(be),e===null?(a=Wu(),a===null&&(a=J,l=Fu(),a.pooledCache=l,l.refCount++,l!==null&&(a.pooledCacheLanes|=n),a=l),t.memoizedState={parent:o,cache:a},Pu(t),wn(t,be,a)):((e.lanes&n)!==0&&(Kr(e,t),Fa(t,null,null,n),$a()),a=e.memoizedState,l=t.memoizedState,a.parent!==o?(a={parent:o,cache:o},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),wn(t,be,o)):(o=l.cache,wn(t,be,o),o!==a.cache&&Qr(t,[be],n,!0))),pe(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),o=t.pendingProps,o.name!=null&&o.name!=="auto"?t.flags|=e===null?18882560:18874368:R&&ui(t),e!==null&&e.memoizedProps.name!==o.name?t.flags|=4194816:Uo(e,t),pe(e,t,o.children,n),t.child;case 29:throw t.pendingProps}throw Error(h(156,t.tag))}function It(e){e.flags|=4}function sr(e,t,n,o,a){var l;if((l=(e.mode&32)!==0)&&(l=n===null?Tb(t,o):Tb(t,o)&&(o.src!==n.src||o.srcSet!==n.srcSet)),l){if(e.flags|=16777216,(a&335544128)===a)if(e.stateNode.complete)e.flags|=8192;else if(Jg())e.flags|=8192;else throw io=Bc,Iu}else e.flags&=-16777217}function Js(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!Sm(t))if(Jg())e.flags|=8192;else throw io=Bc,Iu}function ec(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?Xb():536870912,e.lanes|=t,fa|=t)}function Ra(e,t){if(!R)switch(e.tailMode){case"visible":break;case"collapsed":for(var n=e.tail,o=null;n!==null;)n.alternate!==null&&(o=n),n=n.sibling;o===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function P(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,o=0;if(t)for(var a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags&1206910976,o|=a.flags&1206910976,a.return=e,a=a.sibling;else for(a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags,o|=a.flags,a.return=e,a=a.sibling;return e.subtreeFlags|=o,e.childLanes=n,t}function ph(e,t,n){var o=t.pendingProps;switch($u(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return P(t),null;case 1:return P(t),null;case 3:return n=t.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),t.memoizedState.cache!==o&&(t.flags|=2048),nn(be),ia(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(Ho(t)?It(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,ir())),P(t),null;case 26:var a=t.type,l=t.memoizedState;return e===null?(It(t),l!==null?(P(t),Js(t,l)):(P(t),sr(t,a,null,o,n))):l?l!==e.memoizedState?(It(t),P(t),Js(t,l)):(P(t),t.flags&=-16777217):(e=e.memoizedProps,e!==o&&It(t),P(t),sr(t,a,e,o,n)),null;case 27:if(Ac(t),n=On.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&It(t);else{if(!o){if(t.stateNode===null)throw Error(h(166));return P(t),t.subtreeFlags&=-33554433,null}e=Xt.current,Ho(t)?ks(t,e):(e=hm(a,o,n),t.stateNode=e,It(t))}return P(t),t.subtreeFlags&=-33554433,null;case 5:if(Ac(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&It(t);else{if(!o){if(t.stateNode===null)throw Error(h(166));return P(t),t.subtreeFlags&=-33554433,null}if(l=Xt.current,Ho(t))ks(t,l);else{var c=vl(On.current);switch(l){case 1:l=c.createElementNS("http://www.w3.org/2000/svg",a);break;case 2:l=c.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;default:switch(a){case"svg":l=c.createElementNS("http://www.w3.org/2000/svg",a);break;case"math":l=c.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;case"script":l=c.createElement("div"),l.innerHTML="<script><\/script>",l=l.removeChild(l.firstChild);break;case"select":l=typeof o.is=="string"?c.createElement("select",{is:o.is}):c.createElement("select"),o.multiple?l.multiple=!0:o.size&&(l.size=o.size);break;default:l=typeof o.is=="string"?c.createElement(a,{is:o.is}):c.createElement(a)}}l[Ne]=t,l[Fe]=o;e:for(c=t.child;c!==null;){if(c.tag===5||c.tag===6)l.appendChild(c.stateNode);else if(c.tag!==4&&c.tag!==27&&c.child!==null){c.child.return=c,c=c.child;continue}if(c===t)break e;for(;c.sibling===null;){if(c.return===null||c.return===t)break e;c=c.return}c.sibling.return=c.return,c=c.sibling}t.stateNode=l;e:switch(Me(l,a,o),a){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&It(t)}}return P(t),t.subtreeFlags&=-33554433,sr(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==o&&It(t);else{if(typeof o!="string"&&t.stateNode===null)throw Error(h(166));if(e=On.current,Ho(t)){if(e=t.stateNode,n=t.memoizedProps,o=null,a=Te,a!==null)switch(a.tag){case 27:case 5:o=a.memoizedProps}e[Ne]=t,e=!!(e.nodeValue===n||o!==null&&o.suppressHydrationWarning===!0||cm(e.nodeValue,n)),e||jn(t,!0)}else e=vl(e).createTextNode(o),e[Ne]=t,t.stateNode=e}return P(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(o=Ho(t),n!==null){if(e===null){if(!o)throw Error(h(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(h(557));e[Ne]=t}else uo(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;P(t),e=!1}else n=ir(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(nt(t),t):(nt(t),null);if((t.flags&128)!==0)throw Error(h(558))}return P(t),null;case 13:if(o=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=Ho(t),o!==null&&o.dehydrated!==null){if(e===null){if(!a)throw Error(h(318));if(a=t.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(h(317));a[Ne]=t}else uo(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;P(t),a=!1}else a=ir(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(nt(t),t):(nt(t),null)}return nt(t),(t.flags&128)!==0?(t.lanes=n,t):(n=o!==null,e=e!==null&&e.memoizedState!==null,n&&(o=t.child,a=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(a=o.alternate.memoizedState.cachePool.pool),l=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(l=o.memoizedState.cachePool.pool),l!==a&&(o.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),ec(t,t.updateQueue),P(t),null);case 4:return ia(),e===null&&Ed(t.stateNode.containerInfo),t.flags|=67108864,P(t),null;case 10:return nn(t.type),P(t),null;case 19:if(td(t),o=t.memoizedState,o===null)return P(t),null;if(a=(t.flags&128)!==0,l=o.rendering,l===null)if(a)Ra(o,!1);else{if(re!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(l=jc(e),l!==null){for(t.flags|=128,Ra(o,!1),e=l.updateQueue,t.updateQueue=e,ec(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)kv(n,e),n=n.sibling;return dl(t,_e.current&1|2),R&&Pt(t,o.treeForkCount),t.child}e=e.sibling}o.tail!==null&&lt()>$c&&(t.flags|=128,a=!0,Ra(o,!1),t.lanes=4194304)}else{if(!a)if(e=jc(l),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,ec(t,e),Ra(o,!0),o.tail===null&&o.tailMode!=="collapsed"&&o.tailMode!=="visible"&&!l.alternate&&!R)return P(t),null}else 2*lt()-o.renderingStartTime>$c&&n!==536870912&&(t.flags|=128,a=!0,Ra(o,!1),t.lanes=4194304);o.isBackwards?(l.sibling=t.child,t.child=l):(e=o.last,e!==null?e.sibling=l:t.child=l,o.last=l)}if(o.tail!==null){e=o.tail;e:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break e}n=n.sibling}n=!0}return o.rendering=e,o.tail=e.sibling,o.renderingStartTime=lt(),e.sibling=null,l=_e.current,l=a?l&1|2:l&1,o.tailMode==="visible"||o.tailMode==="collapsed"||!n||R?dl(t,l):(n=l,te(Ce,t),te(_e,n),Ue===null&&(Ue=t)),R&&Pt(t,o.treeForkCount),e}return P(t),null;case 22:case 23:return nt(t),ed(),o=t.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(t.flags|=8192):o&&(t.flags|=8192),o?(n&536870912)!==0&&(t.flags&128)===0&&(P(t),t.subtreeFlags&6&&(t.flags|=8192)):P(t),n=t.updateQueue,n!==null&&ec(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),o=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),o!==n&&(t.flags|=2048),e!==null&&Ae(co),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),nn(be),P(t),null;case 25:return null;case 30:return t.flags|=33554432,P(t),null}throw Error(h(156,t.tag))}function hh(e,t){switch($u(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return nn(be),ia(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return Ac(t),null;case 31:if(t.memoizedState!==null){if(nt(t),t.alternate===null)throw Error(h(340));uo()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(nt(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(h(340));uo()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return td(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return ia(),null;case 10:return nn(t.type),null;case 22:case 23:return nt(t),ed(),e!==null&&Ae(co),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return nn(be),null;case 25:return null;default:return null}}function xg(e,t){switch($u(t),t.tag){case 3:nn(be),ia();break;case 26:case 27:case 5:Ac(t);break;case 4:ia();break;case 31:t.memoizedState!==null&&nt(t);break;case 13:nt(t);break;case 19:td(t);break;case 10:nn(t.type);break;case 22:case 23:nt(t),ed(),e!==null&&Ae(co);break;case 24:nn(be)}}function Nl(e,t){try{var n=t.updateQueue,o=n!==null?n.lastEffect:null;if(o!==null){var a=o.next;n=a;do{if((n.tag&e)===e){o=void 0;var l=n.create,c=n.inst;o=l(),c.destroy=o}n=n.next}while(n!==a)}}catch(i){Z(t,t.return,i)}}function Ln(e,t,n){try{var o=t.updateQueue,a=o!==null?o.lastEffect:null;if(a!==null){var l=a.next;o=l;do{if((o.tag&e)===e){var c=o.inst,i=c.destroy;if(i!==void 0){c.destroy=void 0,a=t;var r=n,d=i;try{d()}catch(v){Z(a,r,v)}}}o=o.next}while(o!==l)}}catch(v){Z(t,t.return,v)}}function kg(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{Mv(t,n)}catch(o){Z(e,e.return,o)}}}function Sg(e,t,n){n.props=mo(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(o){Z(e,t,o)}}function qt(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:var a=e.stateNode,l=an(e.memoizedProps,a);(a.ref===null||a.ref.name!==l)&&(a.ref=sm(l)),o=a.ref;break;case 7:if(e.stateNode===null){var c=new dt(e);$e(e.child,!1,cy,c,void 0,void 0),e.stateNode=c}o=e.stateNode;break;default:o=e.stateNode}typeof n=="function"?e.refCleanup=n(o):n.current=o}}catch(i){Z(e,t,i)}}function ze(e,t){var n=e.ref,o=e.refCleanup;if(n!==null)if(typeof o=="function")try{o()}catch(a){Z(e,t,a)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n=="function")try{n(null)}catch(a){Z(e,t,a)}else n.current=null}function Xc(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)mm(e.stateNode,t[n])}function $s(e){for(var t=e.return;t!==null&&(hd(t)&&mm(e.stateNode,t.stateNode),!pd(t));)t=t.return}function Pa(e){for(var t=e.return;t!==null&&(hd(t)&&iy(e.stateNode,t.stateNode),!pd(t));)t=t.return}function pd(e){return e.tag===5||e.tag===3||e.tag===27}function hd(e){return e&&e.tag===7&&e.stateNode!==null}function iu(e){var t=e.type,n=e.memoizedProps,o=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&o.focus();break e;case"img":n.src?o.src=n.src:n.srcSet&&(o.srcset=n.srcSet)}}catch(a){Z(e,e.return,a)}}function br(e,t,n){try{var o=e.stateNode;Vh(o,e.type,n,t),o[Fe]=t}catch(a){Z(e,e.return,a)}}function Tg(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Xn(e.type)||e.tag===4}function vr(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Tg(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Xn(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function ru(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n).insertBefore(a,t):(t=n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.appendChild(a),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=Lt)),Xc(e,o),j=!0;else if(a!==4&&(a===27&&(Xc(e,o),o=null,Xn(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(ru(e,t,n,o),e=e.sibling;e!==null;)ru(e,t,n,o),e=e.sibling}function Qc(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?n.insertBefore(a,t):n.appendChild(a),Xc(e,o),j=!0;else if(a!==4&&(a===27&&(Xc(e,o),o=null,Xn(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(Qc(e,t,n,o),e=e.sibling;e!==null;)Qc(e,t,n,o),e=e.sibling}function wg(e){var t=e.stateNode,n=e.memoizedProps;try{for(var o=e.type,a=t.attributes;a.length;)t.removeAttributeNode(a[0]);Me(t,o,n),t[Ne]=e,t[Fe]=n}catch(l){Z(e,e.return,l)}}var Zc=!1,ot=null;function Fs(e){(e.tag===30||(e.subtreeFlags&33554432)!==0)&&(Zc=!0)}var jt=null;function Ws(){var e=jt;return jt=null,e}var Ze=0;function Ta(e,t,n,o,a){return Ze=0,Eg(e.child,t,n,o,a)}function Eg(e,t,n,o,a){for(var l=!1;e!==null;){if(e.tag===5){var c=e.stateNode;if(o!==null){var i=Ou(c);o.push(i),i.view&&(l=!0)}else l||Ou(c).view&&(l=!0);Zc=!0,um(c,Ze===0?t:t+"_"+Ze,n),Ze++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&a||Eg(e.child,t,n,o,a)&&(l=!0));e=e.sibling}return l}function Zt(e,t){for(;e!==null;)e.tag===5?dm(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||Zt(e.child,t)),e=e.sibling}function hc(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(hc(e),e.tag===30&&(e.flags&18874368)!==0&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name==="auto")throw Error(h(544));var n=t.name;t=fn(t.default,t.share),t!=="none"&&(Ta(e,n,t,null,!1)||Zt(e.child,!1))}e=e.sibling}}function uu(e,t){if(e.tag===30){var n=e.stateNode,o=e.memoizedProps,a=an(o,n),l=fn(o.default,n.paired?o.share:o.enter);l!=="none"?Ta(e,a,l,null,!1)?(hc(e),n.paired||t||sa(e,o.onEnter)):Zt(e.child,!1):hc(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)uu(e,t),e=e.sibling;else hc(e)}function du(e){if(ot!==null&&ot.size!==0){var t=ot;if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var n=e.memoizedProps,o=n.name;if(o!=null&&o!=="auto"){var a=t.get(o);if(a!==void 0){var l=fn(n.default,n.share);if(l!=="none"&&(Ta(e,o,l,null,!1)?(l=e.stateNode,a.paired=l,l.paired=a,sa(e,n.onShare)):Zt(e.child,!1)),t.delete(o),t.size===0)break}}}du(e)}e=e.sibling}}}function fu(e){if(e.tag===30){var t=e.memoizedProps,n=an(t,e.stateNode),o=ot!==null?ot.get(n):void 0,a=fn(t.default,o!==void 0?t.share:t.exit);a!=="none"&&(Ta(e,n,a,null,!1)?o!==void 0?(a=e.stateNode,o.paired=a,a.paired=o,ot.delete(n),sa(e,t.onShare)):sa(e,t.onExit):Zt(e.child,!1)),ot!==null&&du(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)fu(e),e=e.sibling;else ot!==null&&du(e)}function zg(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=an(t,e.stateNode);t=fn(t.default,t.update),e.flags&=-5,t!=="none"&&Ta(e,n,t,e.memoizedState=[],!1)}else(e.subtreeFlags&33554432)!==0&&zg(e);e=e.sibling}}function su(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var t=e.stateNode;t.paired!==null&&(t.paired=null,Zt(e.child,!1))}su(e)}e=e.sibling}}function yc(e){if(e.tag===30)e.stateNode.paired=null,Zt(e.child,!1),su(e);else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)yc(e),e=e.sibling;else su(e)}function Ng(e){for(e=e.child;e!==null;)e.tag===30?Zt(e.child,!1):(e.subtreeFlags&33554432)!==0&&Ng(e),e=e.sibling}function yd(e,t,n,o,a,l,c){for(var i=!1;t!==null;){if(t.tag===5){var r=t.stateNode;if(l!==null&&Ze<l.length){var d=l[Ze],v=Ou(r);(d.view||v.view)&&(i=!0);var m;if(m=(e.flags&4)===0)if(v.clip)m=!0;else{m=d.rect;var s=v.rect;m=m.y!==s.y||m.x!==s.x||m.height!==s.height||m.width!==s.width}m&&(e.flags|=4),v.abs?v=!d.abs:(d=d.rect,v=v.rect,v=d.height!==v.height||d.width!==v.width),v&&(e.flags|=32)}else e.flags|=32;(e.flags&4)!==0&&um(r,Ze===0?n:n+"_"+Ze,a),i&&(e.flags&4)!==0||(jt===null&&(jt=[]),jt.push(r,Ze===0?o:o+"_"+Ze,t.memoizedProps)),Ze++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&c?e.flags|=t.flags&32:yd(e,t.child,n,o,a,l,c)&&(i=!0));t=t.sibling}return i}function Og(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,o=e.stateNode,a=an(n,o),l=fn(n.default,n.update);if(t){o=o.clones;var c=o===null?null:o.map(Jh)}else c=e.memoizedState,e.memoizedState=null;o=e;var i=e.child;Ze=0,a=yd(o,i,a,a,l,c,!1),(e.flags&4)!==0&&a&&(t||sa(e,n.onUpdate))}else(e.subtreeFlags&33554432)!==0&&Og(e,t);e=e.sibling}}var xe=!1,G=!1,Rt=!1,gr=!1,Is=typeof WeakSet=="function"?WeakSet:Set,ke=null,Ut=!1,Ga=!1,Kc=!1,bu=!1;function yh(e,t,n){if(e=e.containerInfo,Eu=ha,e=bv(e),Qu(e)){if("selectionStart"in e)var o={start:e.selectionStart,end:e.selectionEnd};else e:{o=(o=e.ownerDocument)&&o.defaultView||window;var a=o.getSelection&&o.getSelection();if(a&&a.rangeCount!==0){o=a.anchorNode;var l=a.anchorOffset,c=a.focusNode;a=a.focusOffset;try{o.nodeType,c.nodeType}catch{o=null;break e}var i=0,r=-1,d=-1,v=0,m=0,s=e,b=null;t:for(;;){for(var y;s!==o||l!==0&&s.nodeType!==3||(r=i+l),s!==c||a!==0&&s.nodeType!==3||(d=i+a),s.nodeType===3&&(i+=s.nodeValue.length),(y=s.firstChild)!==null;)b=s,s=y;for(;;){if(s===e)break t;if(b===o&&++v===l&&(r=i),b===c&&++m===a&&(d=i),(y=s.nextSibling)!==null)break;s=b,b=s.parentNode}s=y}o=r===-1||d===-1?null:{start:r,end:d}}else o=null}o=o||{start:0,end:0}}else o=null;for(zu={focusedElem:e,selectionRange:o},ha=!1,n=(n&335544064)===n,ke=t,t=n?9270:1024;ke!==null;){if(e=ke,n&&(o=e.deletions,o!==null))for(l=0;l<o.length;l++)n&&fu(o[l]);if(e.alternate===null&&(e.flags&2)!==0)n&&Fs(e),tc(n);else{if(e.tag===22){if(o=e.alternate,e.memoizedState!==null){o!==null&&o.memoizedState===null&&n&&fu(o),tc(n);continue}else if(o!==null&&o.memoizedState!==null){n&&Fs(e),tc(n);continue}}o=e.child,(e.subtreeFlags&t)!==0&&o!==null?(o.return=e,ke=o):(n&&zg(e),tc(n))}}ot=null}function tc(e){for(;ke!==null;){var t=ke,n=e,o=t.alternate,a=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if((a&1024)!==0&&o!==null){n=void 0,a=o.memoizedProps,o=o.memoizedState;var l=t.stateNode;try{var c=mo(t.type,a);n=l.getSnapshotBeforeUpdate(c,o),l.__reactInternalSnapshotBeforeUpdate=n}catch(i){Z(t,t.return,i)}}break;case 3:if((a&1024)!==0){if(o=t.stateNode.containerInfo,n=o.nodeType,n===9)Au(o);else if(n===1)switch(o.nodeName){case"HEAD":case"HTML":case"BODY":Au(o);break;default:o.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&o!==null&&(n=an(o.memoizedProps,o.stateNode),a=t.memoizedProps,a=fn(a.default,a.update),a!=="none"&&Ta(o,n,a,o.memoizedState=[],!0));break;default:if((a&1024)!==0)throw Error(h(163))}if(o=t.sibling,o!==null){o.return=t.return,ke=o;break}ke=t.return}}function Ag(e,t,n){var o=n.flags;switch(n.tag){case 0:case 11:case 15:Bt(e,n),o&4&&Nl(5,n);break;case 1:if(Bt(e,n),o&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(c){Z(n,n.return,c)}else{var a=mo(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(a,t,e.__reactInternalSnapshotBeforeUpdate)}catch(c){Z(n,n.return,c)}}o&64&&kg(n),o&512&&qt(n,n.return);break;case 3:if(Bt(e,n),o&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{Mv(e,t)}catch(c){Z(n,n.return,c)}}break;case 27:t===null&&o&4&&wg(n);case 26:case 5:Bt(e,n),t===null&&o&4&&iu(n),o&512&&qt(n,n.return);break;case 12:Bt(e,n);break;case 31:Bt(e,n),o&4&&Dg(e,n);break;case 13:Bt(e,n),o&4&&Hg(e,n),o&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=Mh.bind(null,n),dy(e,n))));break;case 22:if(o=n.memoizedState!==null||xe,!o){var l=t!==null&&t.memoizedState!==null||G;t=xe,a=G,xe=o,(G=l)&&!a?(o=2,(n.subtreeFlags&8772)!==0&&(o|=1),Nt(e,n,o)):Bt(e,n),xe=t,G=a}break;case 30:Bt(e,n),o&512&&qt(n,n.return);break;case 7:o&512&&qt(n,n.return);default:Bt(e,n)}}function vu(e,t){for(e=e.child;e!==null;)_g(e,t),e=e.sibling}function _g(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var o=n.style;typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"}else{var a=e.stateNode,l=e.memoizedProps.style,c=l!=null&&l.hasOwnProperty("display")?l.display:null;a.style.display=c==null||typeof c=="boolean"?"":(""+c).trim()}}catch(r){Z(e,e.return,r)}gu(e,t);break;case 6:try{e.stateNode.nodeValue=t?"":e.memoizedProps,j=!0}catch(r){Z(e,e.return,r)}break;case 18:try{var i=e.stateNode;t?vb(i,!0):vb(e.stateNode,!1)}catch(r){Z(e,e.return,r)}break;case 22:case 23:e.memoizedState===null&&vu(e,t);break;default:vu(e,t)}}function gu(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){e:{var n=e,o=t;switch(n.tag){case 4:_g(n,o);break e;case 22:n.memoizedState===null&&gu(n,o);break e;default:gu(n,o)}}e=e.sibling}}function Mg(e){var t=e.alternate;t!==null&&(e.alternate=null,Mg(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&oi(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var ae=null,Xe=!1;function zt(e,t,n){for(n=n.child;n!==null;)Cg(e,t,n),n=n.sibling}function Cg(e,t,n){if(ct&&typeof ct.onCommitFiberUnmount=="function")try{ct.onCommitFiberUnmount(xl,n)}catch{}switch(n.tag){case 26:G||ze(n,t),zt(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!G&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:G||ze(n,t),Pa(n);var o=ae,a=Xe;Xn(n.type)&&(ae=n.stateNode,Xe=!1),zt(e,t,n),ym(n.stateNode,n.type,n.memoizedProps),ae=o,Xe=a;break;case 5:G||ze(n,t),Pa(n);case 6:if(n.tag===6&&Pa(n),o=ae,a=Xe,ae=null,zt(e,t,n),ae=o,Xe=a,ae!==null)if(Xe)try{(ae.nodeType===9?ae.body:ae.nodeName==="HTML"?ae.ownerDocument.body:ae).removeChild(n.stateNode),j=!0}catch(l){Z(n,t,l)}else try{ae.removeChild(n.stateNode),j=!0}catch(l){Z(n,t,l)}break;case 18:ae!==null&&(Xe?(e=ae,bb(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,n.stateNode),ya(e)):bb(ae,n.stateNode));break;case 4:o=ae,a=Xe,ae=n.stateNode.containerInfo,Xe=!0,zt(e,t,n),ae=o,Xe=a;break;case 0:case 11:case 14:case 15:Ln(2,n,t),G||Ln(4,n,t),zt(e,t,n);break;case 1:G||(ze(n,t),o=n.stateNode,typeof o.componentWillUnmount=="function"&&Sg(n,t,o)),zt(e,t,n);break;case 21:zt(e,t,n);break;case 22:G=(o=G)||n.memoizedState!==null,zt(e,t,n),G=o;break;case 30:ze(n,t),zt(e,t,n);break;case 7:G||ze(n,t),zt(e,t,n);break;default:zt(e,t,n)}}function Dg(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{ya(e)}catch(n){Z(t,t.return,n)}}}function Hg(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{ya(e)}catch(n){Z(t,t.return,n)}}function xh(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Is),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Is),t;default:throw Error(h(435,e.tag))}}function nc(e,t){var n=xh(e);t.forEach(function(o){if(!n.has(o)){n.add(o);var a=Ch.bind(null,e,o);o.then(a,a)}})}function je(e,t,n){var o=t.deletions;if(o!==null)for(var a=0;a<o.length;a++){var l=o[a],c=e,i=t,r=i;e:for(;r!==null;){switch(r.tag){case 27:if(Xn(r.type)){ae=r.stateNode,Xe=!1;break e}break;case 5:ae=r.stateNode,Xe=!1;break e;case 3:case 4:ae=r.stateNode.containerInfo,Xe=!0;break e}r=r.return}if(ae===null)throw Error(h(160));Cg(c,i,l),ae=null,Xe=!1,c=l.alternate,c!==null&&(c.return=null),l.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)Rg(t,e,n),t=t.sibling}var Ot=null;function Rg(e,t,n){var o=e.alternate,a=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(a&4&&(o=e.updateQueue,o=o!==null?o.events:null,o!==null))for(var l=0;l<o.length;l++){var c=o[l];c.ref.impl=c.nextImpl}je(t,e,n),Ye(e),a&4&&(Ln(3,e,e.return),Nl(3,e),Ln(5,e,e.return));break;case 1:je(t,e,n),Ye(e),a&512&&(G||o===null||ze(o,o.return)),a&64&&xe&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(l=Ot,je(t,e,n),Ye(e),a&512&&(G||o===null||ze(o,o.return)),a&4)if(a=o!==null?o.memoizedState:null,n=e.memoizedState,o===null)if(n===null)if(e.stateNode===null)if(xe)e.stateNode=rm(e.type,e.memoizedProps,t.containerInfo,e);else{e:{t=e.type,n=e.memoizedProps,a=l.ownerDocument||l;t:switch(t){case"title":o=a.getElementsByTagName("title")[0],(!o||o[Tl]||o[Ne]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=a.createElement(t),a.head.insertBefore(o,a.querySelector("head > title"))),Me(o,t,n),o[Ne]=e,Se(o),t=o;break e;case"link":if(l=Sb("link","href",a).get(t+(n.href||""))){for(c=0;c<l.length;c++)if(o=l[c],o.getAttribute("href")===(n.href==null||n.href===""?null:n.href)&&o.getAttribute("rel")===(n.rel==null?null:n.rel)&&o.getAttribute("title")===(n.title==null?null:n.title)&&o.getAttribute("crossorigin")===(n.crossOrigin==null?null:n.crossOrigin)){l.splice(c,1);break t}}o=a.createElement(t),Me(o,t,n),a.head.appendChild(o);break;case"meta":if(l=Sb("meta","content",a).get(t+(n.content||""))){for(c=0;c<l.length;c++)if(o=l[c],o.getAttribute("content")===(n.content==null?null:""+n.content)&&o.getAttribute("name")===(n.name==null?null:n.name)&&o.getAttribute("property")===(n.property==null?null:n.property)&&o.getAttribute("http-equiv")===(n.httpEquiv==null?null:n.httpEquiv)&&o.getAttribute("charset")===(n.charSet==null?null:n.charSet)){l.splice(c,1);break t}}o=a.createElement(t),Me(o,t,n),a.head.appendChild(o);break;default:throw Error(h(468,t))}o[Ne]=e,Se(o),t=o}e.stateNode=t}else xe||Cu(l,e.type,e.stateNode);else e.stateNode=kb(l,n,e.memoizedProps);else a!==n?(a===null?(t=o.stateNode,t===null||G||t.parentNode.removeChild(t)):a.count--,n===null?xe||Cu(l,e.type,e.stateNode):kb(l,n,e.memoizedProps)):n===null&&e.stateNode!==null&&br(e,e.memoizedProps,o.memoizedProps);break;case 27:je(t,e,n),Ye(e),a&512&&(G||o===null||ze(o,o.return)),o!==null&&a&4&&br(e,e.memoizedProps,o.memoizedProps);break;case 5:if(l=Rt,Rt=!1,je(t,e,n),Rt=l,Ye(e),a&512&&(G||o===null||ze(o,o.return)),e.flags&32){t=e.stateNode;try{ua(t,""),j=!0}catch(v){Z(e,e.return,v)}}a&4&&e.stateNode!=null&&(t=e.memoizedProps,br(e,t,o!==null?o.memoizedProps:t)),a&1024&&(gr=!0);break;case 6:if(je(t,e,n),Ye(e),a&4){if(e.stateNode===null)throw Error(h(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,j=!0}catch(v){Z(e,e.return,v)}}break;case 3:if(j=!1,Tc=null,l=Ot,Ot=gl(t.containerInfo),je(t,e,n),Ot=l,Ye(e),a&4&&o!==null&&o.memoizedState.isDehydrated)try{ya(t.containerInfo)}catch(v){Z(e,e.return,v)}gr&&(gr=!1,Ug(e)),j=!1;break;case 4:a=Rt,Rt=xe,o=as(),l=Ot,Ot=gl(e.stateNode.containerInfo),je(t,e,n),Ye(e),Ot=l,j&&Ga&&(Kc=!0),j=o,Rt=a;break;case 12:je(t,e,n),Ye(e);break;case 31:je(t,e,n),Ye(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,nc(e,t)));break;case 13:je(t,e,n),Ye(e),e.child.flags&8192&&e.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(mi=lt()),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,nc(e,t)));break;case 22:l=e.memoizedState!==null,c=o!==null&&o.memoizedState!==null;var i=xe,r=G,d=Rt;xe=i||l,Rt=d||l,G=r||c,je(t,e,n),G=r,Rt=d,xe=i,Ye(e),a&8192&&(t=e.stateNode,t._visibility=l?t._visibility&-2:t._visibility|1,!l||o===null||c||xe||G||(t=c||G,n=xe,o=G,xe=l||xe,G=t,hn(e,2),xe=n,G=o),!l&&Rt||vu(e,l)),a&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,nc(e,n))));break;case 19:je(t,e,n),Ye(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,nc(e,t)));break;case 30:a&512&&(G||o===null||ze(o,o.return)),a=as(),l=Ga,c=(n&335544064)===n,i=e.memoizedProps,Ga=c&&fn(i.default,i.update)!=="none",je(t,e,n),Ye(e),c&&o!==null&&j&&(e.flags|=4),Ga=l,j=a;break;case 21:break;case 7:a&512&&(G||o===null||ze(o,o.return)),o&&o.stateNode!==null&&(o.stateNode._fragmentFiber=e);default:je(t,e,n),Ye(e)}}function Ye(e){var t=e.flags;if(t&2){try{for(var n,o=e.return;o!==null;){if(Tg(o)){n=o;break}o=o.return}o=null;for(var a=e.return;a!==null;){if(hd(a)){var l=a.stateNode;o===null?o=[l]:o.push(l)}if(pd(a))break;a=a.return}var c=o;if(n==null)throw Error(h(160));switch(n.tag){case 27:var i=n.stateNode,r=vr(e);Qc(e,r,i,c);break;case 5:var d=n.stateNode;n.flags&32&&(ua(d,""),n.flags&=-33);var v=vr(e);Qc(e,v,d,c);break;case 3:case 4:var m=n.stateNode.containerInfo,s=vr(e);ru(e,s,m,c);break;default:throw Error(h(161))}}catch(b){Z(e,e.return,b)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Ug(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Ug(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,ha=!0,t.reset(),ha=!1),e=e.sibling}}function Ro(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)Bg(t,e),t=t.sibling;else Og(t,!1)}function Bg(e,t){var n=e.alternate;if(n===null)uu(e,!1);else switch(e.tag){case 3:if(bu=Ut=!1,Ws(),Ro(t,e),!Ut&&!Kc){if(e=jt,e!==null)for(var o=0;o<e.length;o+=3){n=e[o];var a=e[o+1];dm(n,e[o+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+a+")"})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===""&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),bu=!0}jt=null;break;case 5:Ro(t,e);break;case 4:o=Ut,Ut=!1,Ro(t,e),Ut&&(Kc=!0),Ut=o;break;case 22:e.memoizedState===null&&(n.memoizedState!==null?uu(e,!1):Ro(t,e));break;case 30:o=Ut,a=Ws(),Ut=!1,Ro(t,e),Ut&&(e.flags|=4);var l=e.memoizedProps,c=e.stateNode;t=an(l,c),c=an(n.memoizedProps,c);var i=fn(l.default,l.update);i==="none"?t=!1:(l=n.memoizedState,n.memoizedState=null,n=e.child,Ze=0,t=yd(e,n,t,c,i,l,!0),Ze!==(l===null?0:l.length)&&(e.flags|=32)),(e.flags&4)!==0&&t?(sa(e,e.memoizedProps.onUpdate),jt=a):a!==null&&(a.push.apply(a,jt),jt=a),Ut=(e.flags&32)!==0?!0:o;break;default:Ro(t,e)}}function Bt(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)Ag(e,t.alternate,t),t=t.sibling}function hn(e,t){for(e=e.child;e!==null;){var n=e,o=t;switch(n.tag){case 0:case 11:case 14:case 15:Ln(4,n,n.return),hn(n,o);break;case 1:ze(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&Sg(n,n.return,a),hn(n,o);break;case 27:(o&2)!==0&&ym(n.stateNode,n.type,n.memoizedProps);case 5:ze(n,n.return),n.tag!==5&&n.tag!==27||Pa(n),hn(n,o);break;case 6:Pa(n);break;case 26:ze(n,n.return),a=n.stateNode,n.memoizedState!==null||a===null||G||a.parentNode.removeChild(a),hn(n,o);break;case 22:n.memoizedState===null&&hn(n,o);break;case 30:ze(n,n.return),hn(n,o);break;case 7:ze(n,n.return);default:hn(n,o)}e=e.sibling}}function Nt(e,t,n){for(n=(t.subtreeFlags&8772)!==0?n:n&-2,t=t.child;t!==null;){var o=t.alternate,a=e,l=t,c=l.flags,i=(n&1)!==0;switch(l.tag){case 0:case 11:case 15:Nt(a,l,n),Nl(4,l);break;case 1:if(Nt(a,l,n),o=l,a=o.stateNode,typeof a.componentDidMount=="function")try{a.componentDidMount()}catch(v){Z(o,o.return,v)}if(o=l,a=o.updateQueue,a!==null){var r=o.stateNode;try{var d=a.shared.hiddenCallbacks;if(d!==null)for(a.shared.hiddenCallbacks=null,a=0;a<d.length;a++)_v(d[a],r)}catch(v){Z(o,o.return,v)}}i&&c&64&&kg(l),qt(l,l.return);break;case 27:(n&2)!==0&&wg(l);case 5:l.tag!==5&&l.tag!==27||$s(l),Nt(a,l,n),i&&o===null&&c&4&&iu(l),qt(l,l.return);break;case 6:$s(l);break;case 26:r=l.stateNode,l.memoizedState!==null||r===null||xe||Cu(gl(r.ownerDocument),l.type,r),Nt(a,l,n),i&&o===null&&c&4&&iu(l),qt(l,l.return);break;case 12:Nt(a,l,n);break;case 31:Nt(a,l,n),i&&c&4&&Dg(a,l);break;case 13:Nt(a,l,n),i&&c&4&&Hg(a,l);break;case 22:l.memoizedState===null&&Nt(a,l,n),qt(l,l.return);break;case 30:Nt(a,l,n),qt(l,l.return);break;case 7:qt(l,l.return);default:Nt(a,l,n)}t=t.sibling}}function xd(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&El(n))}function kd(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&El(e))}function mt(e,t,n,o){var a=(n&335544064)===n;if(t.subtreeFlags&(a?10262:10256))for(t=t.child;t!==null;)qg(e,t,n,o),t=t.sibling;else a&&Ng(t)}function qg(e,t,n,o){var a=(n&335544064)===n;a&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&yc(t);var l=t.flags;switch(t.tag){case 0:case 11:case 15:mt(e,t,n,o),l&2048&&Nl(9,t);break;case 1:mt(e,t,n,o);break;case 3:mt(e,t,n,o),a&&bu&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,e.style.viewTransitionName==="root"&&(e.style.viewTransitionName=""),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName==="none"&&(e.style.viewTransitionName="")),l&2048&&(l=null,t.alternate!==null&&(l=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==l&&(t.refCount++,l!=null&&El(l)));break;case 12:if(l&2048){mt(e,t,n,o),l=t.stateNode;try{var c=t.memoizedProps,i=c.id,r=c.onPostCommit;typeof r=="function"&&r(i,t.alternate===null?"mount":"update",l.passiveEffectDuration,-0)}catch(d){Z(t,t.return,d)}}else mt(e,t,n,o);break;case 31:mt(e,t,n,o);break;case 13:mt(e,t,n,o);break;case 23:break;case 22:c=t.stateNode,i=t.alternate,t.memoizedState!==null?(a&&i!==null&&i.memoizedState===null&&yc(i),c._visibility&2?mt(e,t,n,o):el(e,t)):(a&&i!==null&&i.memoizedState!==null&&yc(t),c._visibility&2?mt(e,t,n,o):(c._visibility|=2,Bo(e,t,n,o,(t.subtreeFlags&10256)!==0||!1))),l&2048&&xd(i,t);break;case 24:mt(e,t,n,o),l&2048&&kd(t.alternate,t);break;case 30:a&&(l=t.alternate,l!==null&&(Zt(l.child,!0),Zt(t.child,!0))),mt(e,t,n,o);break;default:mt(e,t,n,o)}}function Bo(e,t,n,o,a){for(a=a&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var l=e,c=t,i=n,r=o,d=c.flags;switch(c.tag){case 0:case 11:case 15:Bo(l,c,i,r,a),Nl(8,c);break;case 23:break;case 22:var v=c.stateNode;c.memoizedState!==null?v._visibility&2?Bo(l,c,i,r,a):el(l,c):(v._visibility|=2,Bo(l,c,i,r,a)),a&&d&2048&&xd(c.alternate,c);break;case 24:Bo(l,c,i,r,a),a&&d&2048&&kd(c.alternate,c);break;default:Bo(l,c,i,r,a)}t=t.sibling}}function el(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,o=t,a=o.flags;switch(o.tag){case 22:el(n,o),a&2048&&xd(o.alternate,o);break;case 24:el(n,o),a&2048&&kd(o.alternate,o);break;default:el(n,o)}t=t.sibling}}var to=8192;function In(e,t,n){if(e.subtreeFlags&to)for(e=e.child;e!==null;)jg(e,t,n),e=e.sibling}function jg(e,t,n){switch(e.tag){case 26:In(e,t,n),e.flags&to&&(e.memoizedState!==null?wy(n,Ot,e.memoizedState,e.memoizedProps):(e=e.stateNode,(t&335544128)===t&&wb(n,e)));break;case 5:In(e,t,n),e.flags&to&&(e=e.stateNode,(t&335544128)===t&&wb(n,e));break;case 3:case 4:var o=Ot;Ot=gl(e.stateNode.containerInfo),In(e,t,n),Ot=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=to,to=16777216,In(e,t,n),to=o):In(e,t,n));break;case 30:if((e.flags&to)!==0&&(o=e.memoizedProps.name,o!=null&&o!=="auto")){var a=e.stateNode;a.paired=null,ot===null&&(ot=new Map),ot.set(o,a)}In(e,t,n);break;default:In(e,t,n)}}function Yg(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Ua(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];ke=o,Vg(o,e)}Yg(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Lg(e),e=e.sibling}function Lg(e){switch(e.tag){case 0:case 11:case 15:Ua(e),e.flags&2048&&Ln(9,e,e.return);break;case 3:Ua(e);break;case 12:Ua(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,xc(e)):Ua(e);break;default:Ua(e)}}function xc(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];ke=o,Vg(o,e)}Yg(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Ln(8,t,t.return),xc(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,xc(t));break;default:xc(t)}e=e.sibling}}function Vg(e,t){for(;ke!==null;){var n=ke;switch(n.tag){case 0:case 11:case 15:Ln(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var o=n.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:El(n.memoizedState.cache)}if(o=n.child,o!==null)o.return=n,ke=o;else e:for(n=e;ke!==null;){o=ke;var a=o.sibling,l=o.return;if(Mg(o),o===n){ke=null;break e}if(a!==null){a.return=l,ke=a;break e}ke=l}}}var kh={getCacheForType:function(e){var t=Oe(be),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return Oe(be).controller.signal}},Sh=typeof WeakMap=="function"?WeakMap:Map,Y=0,J=null,B=null,q=0,X=0,et=null,En=!1,wa=!1,Sd=!1,un=0,re=0,Vn=0,ro=0,Jc=0,at=0,fa=0,tl=null,Qe=null,mu=!1,mi=0,Gg=0,$c=1/0,Fc=null,Hn=null,ce=0,_t=null,po=null,Qt=0,pu=0,hu=null,Xg=null,aa=null,la=null,ca=null,nl=0,kc=null;function rt(){return(Y&2)!==0&&q!==0?q&-q:O.T!==null?wd():Jb()}function Qg(){if(at===0)if((q&536870912)===0||R){var e=Gl;Gl<<=1,(Gl&3932160)===0&&(Gl=262144),at=e}else at=536870912;return e=Ce.current,e!==null&&(e.flags|=32),at}function sa(e,t){if(t!=null){var n=e.stateNode,o=n.ref;o===null&&(o=n.ref=sm(an(e.memoizedProps,n))),la===null&&(la=[]),la.push(t.bind(null,o))}}function Je(e,t,n){(e===J&&(X===2||X===9)||e.cancelPendingCommit!==null)&&(ba(e,0),zn(e,q,at,!1)),Sl(e,n),((Y&2)===0||e!==J)&&(e===J&&((Y&2)===0&&(ro|=n),re===4&&zn(e,q,at,!1)),Jt(e))}function Zg(e,t,n){if((Y&6)!==0)throw Error(h(327));var o=!n&&(t&127)===0&&(t&e.expiredLanes)===0||kl(e,t),a=o?Eh(e,t):mr(e,t,!0),l=o;do{if(a===0){wa&&!o&&zn(e,t,0,!1);break}else{if(n=e.current.alternate,l&&!Th(n)){a=mr(e,t,!1),l=!1;continue}if(a===2){if(l=t,e.errorRecoveryDisabledLanes&l)var c=0;else c=e.pendingLanes&-536870913,c=c!==0?c:c&536870912?536870912:0;if(c!==0){t=c;e:{var i=e;a=tl;var r=i.current.memoizedState.isDehydrated;if(r&&(ba(i,c).flags|=256),c=mr(i,c,!1),c!==2&&c!==6){if(Sd&&!r){i.errorRecoveryDisabledLanes|=l,ro|=l,a=4;break e}l=Qe,Qe=a,l!==null&&(Qe===null?Qe=l:Qe.push.apply(Qe,l))}a=c}if(l=!1,a!==2)continue}}if(a===1){ba(e,0),zn(e,t,0,!0);break}e:{switch(o=e,l=a,l){case 0:case 1:throw Error(h(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:zn(o,t,at,!En);break e;case 2:Qe=null;break;case 3:case 5:break;default:throw Error(h(329))}if((t&62914560)===t&&(a=mi+300-lt(),10<a)){if(zn(o,t,at,!En),ni(o,0,!0)!==0)break e;Qt=t,o.timeoutHandle=zd(Ps.bind(null,o,n,Qe,Fc,mu,t,at,ro,fa,En,l,"Throttled",-0,0),a);break e}Ps(o,n,Qe,Fc,mu,t,at,ro,fa,En,l,null,-0,0)}}break}while(!0);Jt(e)}function Ps(e,t,n,o,a,l,c,i,r,d,v,m,s,b){e.timeoutHandle=-1;var y=t.subtreeFlags,k=(l&335544064)===l;if(m=null,(k||y&8192||(y&16785408)===16785408)&&(m={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Lt},ot=null,jg(t,l,m),k&&(y=m,k=e.containerInfo,k=(k.nodeType===9?k:k.ownerDocument).__reactViewTransition,k!=null&&(y.count++,y.waitingForViewTransition=!0,y=ml.bind(y),k.finished.then(y,y))),y=(l&62914560)===l?mi-lt():(l&4194048)===l?Gg-lt():0,y=Ey(m,y),y!==null)){Qt=l,e.cancelPendingCommit=y(tb.bind(null,e,t,l,n,o,a,c,i,r,d,v,m,null,s,b)),zn(e,l,c,!d);return}tb(e,t,l,n,o,a,c,i,r,d,v,m)}function Th(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var o=0;o<n.length;o++){var a=n[o],l=a.getSnapshot;a=a.value;try{if(!ut(l(),a))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function zn(e,t,n,o){t=Gb(e,t),t&=~Jc,t&=~ro,e.suspendedLanes|=t,e.pingedLanes&=~t,o&&(e.warmLanes|=t),o=e.expirationTimes;for(var a=t;0<a;){var l=31-it(a),c=1<<l;o[l]=-1,a&=~c}n!==0&&Qb(e,n,t)}function pi(){return(Y&6)===0?(Ol(0,!1),!1):!0}function Td(){if(B!==null){if(X===0)var e=B.return;else e=B,en=So=null,cd(e),ta=null,ul=0,e=B;for(;e!==null;)xg(e.alternate,e),e=e.return;B=null}}function ba(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,Qh(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),Qt=0,Td(),J=e,B=n=tn(e.current,null),q=t,X=0,et=null,En=!1,wa=kl(e,t),Sd=!1,fa=at=Jc=ro=Vn=re=0,Qe=tl=null,mu=!1,un=Gb(e,t),ii(),n}function Kg(e,t){C=null,O.H=Vc,t===Sa||t===di?(t=zs(),X=3):t===Iu?(t=zs(),X=4):X=t===vd?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,et=t,B===null&&(re=1,Gc(e,kt(t,e.current)))}function Jg(){var e=Ce.current;return e===null?!0:(q&4194048)===q?Ue===null:(q&62914560)===q||(q&536870912)!==0?e===Ue:!1}function $g(){var e=O.H;return O.H=Vc,e===null?Vc:e}function Fg(){var e=O.A;return O.A=kh,e}function Wc(){re=4,En||(q&4194048)!==q&&Ce.current!==null||(wa=!0),(Vn&134217727)===0&&(ro&134217727)===0||J===null||zn(J,q,at,!1)}function mr(e,t,n){var o=Y;Y|=2;var a=$g(),l=Fg();(J!==e||q!==t)&&(Fc=null,ba(e,t)),t=!1;var c=re;e:do try{if(X!==0&&B!==null){var i=B,r=et;switch(X){case 8:Td(),c=6;break e;case 3:case 2:case 9:case 6:Ce.current===null&&(t=!0);var d=X;if(X=0,et=null,Fo(e,i,r,d),n&&wa){c=0;break e}break;default:d=X,X=0,et=null,Fo(e,i,r,d)}}wh(),c=re;break}catch(v){Kg(e,v)}while(!0);return t&&e.shellSuspendCounter++,en=So=null,Y=o,O.H=a,O.A=l,B===null&&(J=null,q=0,ii()),c}function wh(){for(;B!==null;)Wg(B)}function Eh(e,t){var n=Y;Y|=2;var o=$g(),a=Fg();J!==e||q!==t?(Fc=null,$c=lt()+500,ba(e,t)):wa=kl(e,t);e:do try{if(X!==0&&B!==null){t=B;var l=et;t:switch(X){case 1:X=0,et=null,Fo(e,t,l,1);break;case 2:case 9:if(Es(l)){X=0,et=null,eb(t);break}t=function(){X!==2&&X!==9||J!==e||(X=7),Jt(e)},l.then(t,t);break e;case 3:X=7;break e;case 4:X=5;break e;case 7:Es(l)?(X=0,et=null,eb(t)):(X=0,et=null,Fo(e,t,l,7));break;case 5:var c=null;switch(B.tag){case 26:c=B.memoizedState;case 5:case 27:var i=B;if(c?Sm(c):i.stateNode.complete){X=0,et=null;var r=i.sibling;if(r!==null)B=r;else{var d=i.return;d!==null?(B=d,hi(d)):B=null}break t}}X=0,et=null,Fo(e,t,l,5);break;case 6:X=0,et=null,Fo(e,t,l,6);break;case 8:Td(),re=6;break e;default:throw Error(h(462))}}zh();break}catch(v){Kg(e,v)}while(!0);return en=So=null,O.H=o,O.A=a,Y=n,B!==null?0:(J=null,q=0,ii(),re)}function zh(){for(;B!==null&&!Gp();)Wg(B)}function Wg(e){var t=yg(e.alternate,e,un);e.memoizedProps=e.pendingProps,t===null?hi(e):B=t}function eb(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Vs(n,t,t.pendingProps,t.type,void 0,q);break;case 11:t=Vs(n,t,t.pendingProps,t.type.render,t.ref,q);break;case 5:cd(t);var o=t;o===Te&&(R?(Rc(o),o.tag===5&&o.stateNode!=null&&(ee=o.stateNode)):(Rc(o),R=!0));default:xg(n,t),t=B=kv(t,un),t=yg(n,t,un)}e.memoizedProps=e.pendingProps,t===null?hi(e):B=t}function Fo(e,t,n,o){en=So=null,cd(t),ta=null,ul=0;var a=t.return;try{if(bh(e,a,t,n,q)){re=1,Gc(e,kt(n,e.current)),B=null;return}}catch(l){if(a!==null)throw B=a,l;re=1,Gc(e,kt(n,e.current)),B=null;return}t.flags&32768?(R||o===1?e=!0:wa||(q&536870912)!==0?e=!1:(En=e=!0,(o===2||o===9||o===3||o===6)&&(o=Ce.current,o!==null&&o.tag===13&&(o.flags|=16384))),Ig(t,e)):hi(t)}function hi(e){var t=e;do{if((t.flags&32768)!==0){Ig(t,En);return}e=t.return;var n=ph(t.alternate,t,un);if(n!==null){B=n;return}if(t=t.sibling,t!==null){B=t;return}B=t=e}while(t!==null);re===0&&(re=5)}function Ig(e,t){do{var n=hh(e.alternate,e);if(n!==null){n.flags&=32767,B=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){B=e;return}B=e=n}while(e!==null);re=6,B=null}function tb(e,t,n,o,a,l,c,i,r,d,v,m){e.cancelPendingCommit=null;do yi();while(ce!==0);if((Y&6)!==0)throw Error(h(327));if(t!==null){if(t===e.current)throw Error(h(177));e===J&&(B=J=null,q=0),po=t,_t=e,Qt=n,hu=a,Xg=o,Nh(e,t,n,c,i,r,m)}}function Nh(e,t,n,o,a,l,c){var i=t.lanes|t.childLanes;if(pu=i,i|=Zu,Pp(e,n,i,o,a,l),la=null,(n&335544064)===n?(ca=th(e),o=10262):(ca=null,o=10256),(t.subtreeFlags&o)!==0||(t.flags&o)!==0?(e.callbackNode=null,e.callbackPriority=0,Dh(_c,function(){return Su(),null})):(e.callbackNode=null,e.callbackPriority=0),Zc=!1,o=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||o){o=O.T,O.T=null,a=L.p,L.p=2,l=Y,Y|=4;try{yh(e,t,n)}finally{Y=l,L.p=a,O.T=o}}ce=1,Zc?aa=Wh(c,e.containerInfo,ca,yu,xu,Ah,ku,Su,Oh,null,null):(yu(),xu(),ku())}function Oh(e){if(ce!==0){var t=_t.onRecoverableError;t(e,{componentStack:null})}}function Ah(){ce===3&&(ce=0,Bg(po,_t),ce=4)}function yu(){if(ce===1){ce=0;var e=_t,t=po,n=Qt,o=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||o){o=O.T,O.T=null;var a=L.p;L.p=2;var l=Y;Y|=4;try{Ga=Kc=!1,Rg(t,e,n),n=zu;var c=bv(e.containerInfo),i=n.focusedElem,r=n.selectionRange;if(c!==i&&i&&i.ownerDocument&&sv(i.ownerDocument.documentElement,i)){if(r!==null&&Qu(i)){var d=r.start,v=r.end;if(v===void 0&&(v=d),"selectionStart"in i)i.selectionStart=d,i.selectionEnd=Math.min(v,i.value.length);else{var m=i.ownerDocument||document,s=m&&m.defaultView||window;if(s.getSelection){var b=s.getSelection(),y=i.textContent.length,k=Math.min(r.start,y),x=r.end===void 0?k:Math.min(r.end,y);!b.extend&&k>x&&(c=x,x=k,k=c);var f=ps(i,k),u=ps(i,x);if(f&&u&&(b.rangeCount!==1||b.anchorNode!==f.node||b.anchorOffset!==f.offset||b.focusNode!==u.node||b.focusOffset!==u.offset)){var g=m.createRange();g.setStart(f.node,f.offset),b.removeAllRanges(),k>x?(b.addRange(g),b.extend(u.node,u.offset)):(g.setEnd(u.node,u.offset),b.addRange(g))}}}}for(m=[],b=i;b=b.parentNode;)b.nodeType===1&&m.push({element:b,left:b.scrollLeft,top:b.scrollTop});for(typeof i.focus=="function"&&i.focus(),i=0;i<m.length;i++){var p=m[i];p.element.scrollLeft=p.left,p.element.scrollTop=p.top}}ha=!!Eu,zu=Eu=null}finally{Y=l,L.p=a,O.T=o}}e.current=t,ce=2}}function xu(){if(ce===2){ce=0;var e=_t,t=po,n=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||n){n=O.T,O.T=null;var o=L.p;L.p=2;var a=Y;Y|=4;try{Ag(e,t.alternate,t)}finally{Y=a,L.p=o,O.T=n}}ce=3}}function ku(){if(ce===4||ce===3){ce=0;var e=aa;aa=null,Xp();var t=_t,n=po,o=Qt,a=Xg,l=(o&335544064)===o?10262:10256;if((n.subtreeFlags&l)!==0||(n.flags&l)!==0?ce=5:(ce=0,po=_t=null,Pg(t,t.pendingLanes)),l=t.pendingLanes,l===0&&(Hn=null),ju(o),n=n.stateNode,ct&&typeof ct.onCommitFiberRoot=="function")try{ct.onCommitFiberRoot(xl,n,void 0,(n.current.flags&128)===128)}catch{}if(a!==null){n=O.T,l=L.p,L.p=2,O.T=null;try{for(var c=t.onRecoverableError,i=0;i<a.length;i++){var r=a[i];c(r.value,{componentStack:r.stack})}}finally{O.T=n,L.p=l}}if(a=la,c=ca,ca=null,a!==null&&(la=null,c===null&&(c=[]),e!==null))for(r=0;r<a.length;r++)n=(0,a[r])(c),n!==void 0&&e.finished.finally(n);(Qt&3)!==0&&yi(),Jt(t),l=t.pendingLanes,(o&261930)!==0&&(l&42)!==0?t===kc?nl++:(nl=0,kc=t):(nl=0,kc=null),Ol(0,!1)}}function Pg(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,El(t)))}function yi(){return aa!==null&&(aa.skipTransition(),aa=null),yu(),xu(),ku(),Su()}function Su(){if(ce!==5)return!1;var e=_t,t=pu;pu=0;var n=ju(Qt),o=O.T,a=L.p;try{L.p=32>n?32:n,O.T=null,n=hu,hu=null;var l=_t,c=Qt;if(ce=0,po=_t=null,Qt=0,(Y&6)!==0)throw Error(h(331));var i=Y;if(Y|=4,Lg(l.current),qg(l,l.current,c,n),Y=i,Ol(0,!1),ct&&typeof ct.onPostCommitFiberRoot=="function")try{ct.onPostCommitFiberRoot(xl,l)}catch{}return!0}finally{L.p=a,O.T=o,Pg(e,t)}}function nb(e,t,n){t=kt(n,t),t=tu(e.stateNode,t,2),e=Mn(e,t,2),e!==null&&(Sl(e,2),Jt(e))}function Z(e,t,n){if(e.tag===3)nb(e,e,n);else for(;t!==null;){if(t.tag===3){nb(t,e,n);break}else if(t.tag===1){var o=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(Hn===null||!Hn.has(o))){e=kt(n,e),n=vg(2),o=Mn(t,n,2),o!==null&&(gg(n,o,t,e),Sl(o,2),Jt(o));break}}t=t.return}}function pr(e,t,n){var o=e.pingCache;if(o===null){o=e.pingCache=new Sh;var a=new Set;o.set(t,a)}else a=o.get(t),a===void 0&&(a=new Set,o.set(t,a));a.has(n)||(Sd=!0,a.add(n),e=_h.bind(null,e,t,n),t.then(e,e))}function _h(e,t,n){var o=e.pingCache;o!==null&&o.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,J===e&&(q&n)===n&&((re===4||re===3&&(q&62914560)===q&&300>lt()-mi)&&(Y&2)===0?ba(e,0):Jc|=n,fa===q&&(fa=0)),Jt(e)}function em(e,t){t===0&&(t=Xb()),e=ko(e,t),e!==null&&(Sl(e,t),Jt(e))}function Mh(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),em(e,n)}function Ch(e,t){var n=0;switch(e.tag){case 31:case 13:var o=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(h(314))}o!==null&&o.delete(t),em(e,n)}function Dh(e,t){return Bu(e,t)}var va=null,qo=null,Tu=!1,Ic=!1,hr=!1,Nn=0;function Jt(e){e!==qo&&e.next===null&&(qo===null?va=qo=e:qo=qo.next=e),Ic=!0,Tu||(Tu=!0,Rh())}function Ol(e,t){if(!hr&&Ic){hr=!0;do for(var n=!1,o=va;o!==null;){if(!t)if(e!==0){var a=o.pendingLanes;if(a===0)var l=0;else{var c=o.suspendedLanes,i=o.pingedLanes;l=(1<<31-it(42|e)+1)-1,l&=a&~(c&~i),l=l&201326741?l&201326741|1:l?l|2:0}l!==0&&(n=!0,ob(o,l))}else l=q,l=ni(o,o===J?l:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(l&3)===0||kl(o,l)||(n=!0,ob(o,l));o=o.next}while(n);hr=!1}}function Hh(){tm()}function tm(){Ic=Tu=!1;var e=0;Nn!==0&&Xh()&&(e=Nn);for(var t=lt(),n=null,o=va;o!==null;){var a=o.next,l=nm(o,t);l===0?(o.next=null,n===null?va=a:n.next=a,a===null&&(qo=n)):(n=o,(e!==0||(l&3)!==0)&&(Ic=!0)),o=a}ce!==0&&ce!==5||Ol(e,!1),Nn!==0&&(Nn=0)}function nm(e,t){for(var n=e.suspendedLanes,o=e.pingedLanes,a=e.expirationTimes,l=e.pendingLanes&-62914561;0<l;){var c=31-it(l),i=1<<c,r=a[c];r===-1?((i&n)===0||(i&o)!==0)&&(a[c]=Ip(i,t)):r<=t&&(e.expiredLanes|=i),l&=~i}if(t=J,n=q,n=ni(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,n===0||e===t&&(X===2||X===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&Fi(o),e.callbackNode=null,e.callbackPriority=0;if((n&3)===0||kl(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(o!==null&&Fi(o),ju(n)){case 2:case 8:n=Lb;break;case 32:n=_c;break;case 268435456:n=Vb;break;default:n=_c}return o=om.bind(null,e),n=Bu(n,o),e.callbackPriority=t,e.callbackNode=n,t}return o!==null&&o!==null&&Fi(o),e.callbackPriority=2,e.callbackNode=null,2}function om(e,t){if(ce!==0&&ce!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(yi()&&e.callbackNode!==n)return null;var o=q;return o=ni(e,e===J?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(Zg(e,o,t),nm(e,lt()),e.callbackNode!=null&&e.callbackNode===n?om.bind(null,e):null)}function ob(e,t){if(yi())return null;Zg(e,t,!0)}function Rh(){Zh(function(){(Y&6)!==0?Bu(Yb,Hh):tm()})}function wd(){if(Nn===0){var e=bo;e===0&&(e=Vl,Vl<<=1,(Vl&261888)===0&&(Vl=256)),Nn=e}return Nn}function ab(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:uc(e)}function Uh(e,t,n,o,a){if(t==="submit"&&n&&n.stateNode===a){var l=ab((a[Fe]||null).action),c=o.submitter;c&&(t=(t=c[Fe]||null)?ab(t.formAction):c.getAttribute("formAction"),t!==null&&(l=t,c=null));var i=new ai("action","action",null,o,a);e.push({event:i,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(Nn!==0){var r=new FormData(a,c);Pr(n,{pending:!0,data:r,method:a.method,action:l},null,r)}}else typeof l=="function"&&(i.preventDefault(),r=new FormData(a,c),Pr(n,{pending:!0,data:r,method:a.method,action:l},l,r))},currentTarget:a}]})}}for(oc=0;oc<Vr.length;oc++)ac=Vr[oc],lb=ac.toLowerCase(),cb=ac[0].toUpperCase()+ac.slice(1),Mt(lb,"on"+cb);var ac,lb,cb,oc;Mt(gv,"onAnimationEnd");Mt(mv,"onAnimationIteration");Mt(pv,"onAnimationStart");Mt("dblclick","onDoubleClick");Mt("focusin","onFocus");Mt("focusout","onBlur");Mt(K0,"onTransitionRun");Mt(J0,"onTransitionStart");Mt($0,"onTransitionCancel");Mt(hv,"onTransitionEnd");ra("onMouseEnter",["mouseout","mouseover"]);ra("onMouseLeave",["mouseout","mouseover"]);ra("onPointerEnter",["pointerout","pointerover"]);ra("onPointerLeave",["pointerout","pointerover"]);yo("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));yo("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));yo("onBeforeInput",["compositionend","keypress","textInput","paste"]);yo("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));yo("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));yo("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var sl="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Bh=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(sl));function am(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var o=e[n],a=o.event;o=o.listeners;e:{var l=void 0;if(t)for(var c=o.length-1;0<=c;c--){var i=o[c],r=i.instance,d=i.currentTarget;if(i=i.listener,r!==l&&a.isPropagationStopped())break e;l=i,a.currentTarget=d;try{l(a)}catch(v){Cc(v)}a.currentTarget=null,l=r}else for(c=0;c<o.length;c++){if(i=o[c],r=i.instance,d=i.currentTarget,i=i.listener,r!==l&&a.isPropagationStopped())break e;l=i,a.currentTarget=d;try{l(a)}catch(v){Cc(v)}a.currentTarget=null,l=r}}}}function U(e,t){var n=t[es];n===void 0&&(n=t[es]=new Set);var o=e+"__bubble";n.has(o)||(lm(t,e,2,!1),n.add(o))}function yr(e,t,n){var o=0;t&&(o|=4),lm(n,e,o,t)}var lc="_reactListening"+Math.random().toString(36).slice(2);function Ed(e){if(!e[lc]){e[lc]=!0,Fb.forEach(function(n){n!=="selectionchange"&&(Bh.has(n)||yr(n,!1,e),yr(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[lc]||(t[lc]=!0,yr("selectionchange",!1,t))}}function lm(e,t,n,o){switch(Am(t)){case 2:var a=Ay;break;case 8:a=_y;break;default:a=Cd}n=a.bind(null,t,n,e),a=void 0,!qr||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(a=!0),o?a!==void 0?e.addEventListener(t,n,{capture:!0,passive:a}):e.addEventListener(t,n,!0):a!==void 0?e.addEventListener(t,n,{passive:a}):e.addEventListener(t,n,!1)}function xr(e,t,n,o,a){var l=o;if((t&1)===0&&(t&2)===0&&o!==null)e:for(;;){if(o===null)return;var c=o.tag;if(c===3||c===4){var i=o.stateNode.containerInfo;if(i===a)break;if(c===4)for(c=o.return;c!==null;){var r=c.tag;if((r===3||r===4)&&c.stateNode.containerInfo===a)return;c=c.return}for(;i!==null;){if(c=no(i),c===null)return;if(r=c.tag,r===5||r===6||r===26||r===27){o=l=c;continue e}i=i.parentNode}}o=o.return}av(function(){var d=l,v=Lu(n),m=[];e:{var s=yv.get(e);if(s!==void 0){var b=ai,y=e;switch(e){case"keypress":if(fc(n)===0)break e;case"keydown":case"keyup":b=T0;break;case"focusin":y="focus",b=nr;break;case"focusout":y="blur",b=nr;break;case"beforeblur":case"afterblur":b=nr;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":b=rs;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":b=f0;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":b=O0;break;case gv:case mv:case pv:b=v0;break;case hv:b=_0;break;case"scroll":case"scrollend":b=u0;break;case"wheel":b=C0;break;case"copy":case"cut":case"paste":b=m0;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":b=ds;break;case"submit":b=z0;break;case"toggle":case"beforetoggle":b=H0}var k=(t&4)!==0,x=!k&&(e==="scroll"||e==="scrollend"),f=k?s!==null?s+"Capture":null:s;k=[];for(var u=d,g;u!==null;){var p=u;if(g=p.stateNode,p=p.tag,p!==5&&p!==26&&p!==27||g===null||f===null||(p=al(u,f),p!=null&&k.push(bl(u,p,g))),x)break;u=u.return}0<k.length&&(s=new b(s,y,null,n,v),m.push({event:s,listeners:k}))}}if((t&7)===0){e:{if(b=e==="mouseover"||e==="pointerover",s=e==="mouseout"||e==="pointerout",b&&n!==Br&&(y=n.relatedTarget||n.fromElement)&&(no(y)||y[xa]))break e;(s||b)&&(y=v.window===v?v:(b=v.ownerDocument)?b.defaultView||b.parentWindow:window,s?(b=n.relatedTarget||n.toElement,s=d,b=b?no(b):null,b!==null&&(x=yl(b),k=b.tag,b!==x||k!==5&&k!==27&&k!==6)&&(b=null)):(s=null,b=d),s!==b&&(k=rs,p="onMouseLeave",f="onMouseEnter",u="mouse",(e==="pointerout"||e==="pointerover")&&(k=ds,p="onPointerLeave",f="onPointerEnter",u="pointer"),x=s==null?y:La(s),g=b==null?y:La(b),y=new k(p,u+"leave",s,n,v),y.target=x,y.relatedTarget=g,p=null,no(v)===d&&(k=new k(f,u+"enter",b,n,v),k.target=g,k.relatedTarget=x,p=k),x=p,k=s&&b?Er(s,b,qh):null,s!==null&&ib(m,y,s,k,!1),b!==null&&x!==null&&ib(m,x,b,k,!0)))}e:{if(s=d?La(d):window,b=s.nodeName&&s.nodeName.toLowerCase(),b==="select"||b==="input"&&s.type==="file")var T=vs;else if(bs(s))if(dv)T=X0;else{T=V0;var A=L0}else b=s.nodeName,!b||b.toLowerCase()!=="input"||s.type!=="checkbox"&&s.type!=="radio"?d&&Yu(d.elementType)&&(T=vs):T=G0;if(T&&(T=T(e,d))){uv(m,T,n,v);break e}A&&A(e,s,d)}switch(A=d?La(d):window,e){case"focusin":(bs(A)||A.contentEditable==="true")&&(Xo=A,Yr=d,Za=null);break;case"focusout":Za=Yr=Xo=null;break;case"mousedown":Lr=!0;break;case"contextmenu":case"mouseup":case"dragend":Lr=!1,hs(m,n,v);break;case"selectionchange":if(Z0)break;case"keydown":case"keyup":hs(m,n,v)}var w;if(Xu)e:{switch(e){case"compositionstart":var E="onCompositionStart";break e;case"compositionend":E="onCompositionEnd";break e;case"compositionupdate":E="onCompositionUpdate";break e}E=void 0}else Go?iv(e,n)&&(E="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(E="onCompositionStart");E&&(cv&&n.locale!=="ko"&&(Go||E!=="onCompositionStart"?E==="onCompositionEnd"&&Go&&(w=lv()):(Tn=v,Vu="value"in Tn?Tn.value:Tn.textContent,Go=!0)),A=Pc(d,E),0<A.length&&(E=new us(E,e,null,n,v),m.push({event:E,listeners:A}),w?E.data=w:(w=rv(n),w!==null&&(E.data=w)))),(w=U0?B0(e,n):q0(e,n))&&(E=Pc(d,"onBeforeInput"),0<E.length&&(A=new us("onBeforeInput","beforeinput",null,n,v),m.push({event:A,listeners:E}),A.data=w)),Uh(m,e,d,n,v)}am(m,t)})}function bl(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Pc(e,t){for(var n=t+"Capture",o=[];e!==null;){var a=e,l=a.stateNode;if(a=a.tag,a!==5&&a!==26&&a!==27||l===null||(a=al(e,n),a!=null&&o.unshift(bl(e,a,l)),a=al(e,t),a!=null&&o.push(bl(e,a,l))),e.tag===3)return o;e=e.return}return[]}function qh(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function ib(e,t,n,o,a){for(var l=t._reactName,c=[];n!==null&&n!==o;){var i=n,r=i.alternate,d=i.stateNode;if(i=i.tag,r!==null&&r===o)break;i!==5&&i!==26&&i!==27||d===null||(r=d,a?(d=al(n,l),d!=null&&c.unshift(bl(n,d,r))):a||(d=al(n,l),d!=null&&c.push(bl(n,d,r)))),n=n.return}c.length!==0&&e.push({event:t,listeners:c})}var jh=/\r\n?/g,Yh=/\u0000|\uFFFD/g;function rb(e){return(typeof e=="string"?e:""+e).replace(jh,`
`).replace(Yh,"")}function cm(e,t){return t=rb(t),rb(e)===t}function Q(e,t,n,o,a,l){switch(n){case"children":if(typeof o=="string")t==="body"||t==="textarea"&&o===""||ua(e,o);else if(typeof o=="number"||typeof o=="bigint")t!=="body"&&ua(e,""+o);else return;break;case"className":Ql(e,"class",o);break;case"tabIndex":Ql(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":Ql(e,n,o);break;case"style":ov(e,o,l);return;case"data":if(t!=="object"){Ql(e,"data",o);break}case"src":case"href":if(o===""&&(t!=="a"||n!=="href")){e.removeAttribute(n);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=uc(o),e.setAttribute(n,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof l=="function"&&(n==="formAction"?(t!=="input"&&Q(e,t,"name",a.name,a,null),Q(e,t,"formEncType",a.formEncType,a,null),Q(e,t,"formMethod",a.formMethod,a,null),Q(e,t,"formTarget",a.formTarget,a,null)):(Q(e,t,"encType",a.encType,a,null),Q(e,t,"method",a.method,a,null),Q(e,t,"target",a.target,a,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=uc(o),e.setAttribute(n,o);break;case"onClick":o!=null&&(e.onclick=Lt);return;case"onScroll":o!=null&&U("scroll",e);return;case"onScrollEnd":o!=null&&U("scrollend",e);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(h(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(h(60));l?.__html!==n&&(e.innerHTML=n)}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}n=uc(o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":o===!0?e.setAttribute(n,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(n,o):e.removeAttribute(n);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(n):e.setAttribute(n,o);break;case"popover":U("beforetoggle",e),U("toggle",e),rc(e,"popover",o);break;case"xlinkActuate":Wt(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Wt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Wt(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Wt(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Wt(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Wt(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Wt(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Wt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Wt(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":rc(e,"is",o);break;case"innerText":case"textContent":return;default:if(!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")n=i0.get(n)||n,rc(e,n,o);else return}j=!0}function wu(e,t,n,o,a,l){switch(n){case"style":ov(e,o,l);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(h(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(h(60));l?.__html!==n&&(e.innerHTML=n)}}break;case"children":if(typeof o=="string")ua(e,o);else if(typeof o=="number"||typeof o=="bigint")ua(e,""+o);else return;break;case"onScroll":o!=null&&U("scroll",e);return;case"onScrollEnd":o!=null&&U("scrollend",e);return;case"onClick":o!=null&&(e.onclick=Lt);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!Wb.hasOwnProperty(n))e:{if(n[0]==="o"&&n[1]==="n"&&(a=n.endsWith("Capture"),l=n.slice(2,a?n.length-7:void 0),t=e[Fe]||null,t=t!=null?t[n]:null,typeof t=="function"&&e.removeEventListener(l,t,a),typeof o=="function")){typeof t!="function"&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(l,o,a);break e}j=!0,n in e?e[n]=o:o===!0?e.setAttribute(n,""):rc(e,n,o)}return}j=!0}function Me(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":U("error",e),U("load",e);var o=!1,a=!1,l;for(l in n)if(n.hasOwnProperty(l)){var c=n[l];if(c!=null)switch(l){case"src":o=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(h(137,t));default:Q(e,t,l,c,n,null)}}a&&Q(e,t,"srcSet",n.srcSet,n,null),o&&Q(e,t,"src",n.src,n,null);return;case"input":U("invalid",e);var i=l=c=a=null,r=null,d=null;for(o in n)if(n.hasOwnProperty(o)){var v=n[o];if(v!=null)switch(o){case"name":a=v;break;case"type":c=v;break;case"checked":r=v;break;case"defaultChecked":d=v;break;case"value":l=v;break;case"defaultValue":i=v;break;case"children":case"dangerouslySetInnerHTML":if(v!=null)throw Error(h(137,t));break;default:Q(e,t,o,v,n,null)}}ev(e,l,i,r,d,c,a,!1);return;case"select":U("invalid",e),o=c=l=null;for(a in n)if(n.hasOwnProperty(a)&&(i=n[a],i!=null))switch(a){case"value":l=i;break;case"defaultValue":c=i;break;case"multiple":o=i;default:Q(e,t,a,i,n,null)}t=l,n=c,e.multiple=!!o,t!=null?Io(e,!!o,t,!1):n!=null&&Io(e,!!o,n,!0);return;case"textarea":U("invalid",e),l=a=o=null;for(c in n)if(n.hasOwnProperty(c)&&(i=n[c],i!=null))switch(c){case"value":o=i;break;case"defaultValue":a=i;break;case"children":l=i;break;case"dangerouslySetInnerHTML":if(i!=null)throw Error(h(91));break;default:Q(e,t,c,i,n,null)}nv(e,o,a,l);return;case"option":for(r in n)n.hasOwnProperty(r)&&(o=n[r],o!=null)&&(r==="selected"?e.selected=o&&typeof o!="function"&&typeof o!="symbol":Q(e,t,r,o,n,null));return;case"dialog":U("beforetoggle",e),U("toggle",e),U("cancel",e),U("close",e);break;case"iframe":case"object":U("load",e);break;case"video":case"audio":for(o=0;o<sl.length;o++)U(sl[o],e);break;case"image":U("error",e),U("load",e);break;case"details":U("toggle",e);break;case"embed":case"source":case"link":U("error",e),U("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(d in n)if(n.hasOwnProperty(d)&&(o=n[d],o!=null))switch(d){case"children":case"dangerouslySetInnerHTML":throw Error(h(137,t));default:Q(e,t,d,o,n,null)}return;default:if(Yu(t)){for(v in n)n.hasOwnProperty(v)&&(o=n[v],o!==void 0&&wu(e,t,v,o,n,void 0));return}}for(i in n)n.hasOwnProperty(i)&&(o=n[i],o!=null&&Q(e,t,i,o,n,null))}var Lh={};function Vh(e,t,n,o){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var a=null,l=null,c=null,i=null,r=null,d=null,v=null;for(b in n){var m=n[b];if(n.hasOwnProperty(b)&&m!=null)switch(b){case"checked":break;case"value":break;case"defaultValue":r=m;default:o.hasOwnProperty(b)||Q(e,t,b,null,o,m)}}for(var s in o){var b=o[s];if(m=n[s],o.hasOwnProperty(s)&&(b!=null||m!=null))switch(s){case"type":b!==m&&(j=!0),l=b;break;case"name":b!==m&&(j=!0),a=b;break;case"checked":b!==m&&(j=!0),d=b;break;case"defaultChecked":b!==m&&(j=!0),v=b;break;case"value":b!==m&&(j=!0),c=b;break;case"defaultValue":b!==m&&(j=!0),i=b;break;case"children":case"dangerouslySetInnerHTML":if(b!=null)throw Error(h(137,t));break;default:b!==m&&Q(e,t,s,b,o,m)}}Ur(e,c,i,r,d,v,l,a);return;case"select":b=c=i=s=null;for(l in n)if(r=n[l],n.hasOwnProperty(l)&&r!=null)switch(l){case"value":break;case"multiple":b=r;default:o.hasOwnProperty(l)||Q(e,t,l,null,o,r)}for(a in o)if(l=o[a],r=n[a],o.hasOwnProperty(a)&&(l!=null||r!=null))switch(a){case"value":l!==r&&(j=!0),s=l;break;case"defaultValue":l!==r&&(j=!0),i=l;break;case"multiple":l!==r&&(j=!0),c=l;default:l!==r&&Q(e,t,a,l,o,r)}t=i,n=c,o=b,s!=null?Io(e,!!n,s,!1):!!o!=!!n&&(t!=null?Io(e,!!n,t,!0):Io(e,!!n,n?[]:"",!1));return;case"textarea":b=s=null;for(i in n)if(a=n[i],n.hasOwnProperty(i)&&a!=null&&!o.hasOwnProperty(i))switch(i){case"value":break;case"children":break;default:Q(e,t,i,null,o,a)}for(c in o)if(a=o[c],l=n[c],o.hasOwnProperty(c)&&(a!=null||l!=null))switch(c){case"value":a!==l&&(j=!0),s=a;break;case"defaultValue":a!==l&&(j=!0),b=a;break;case"children":break;case"dangerouslySetInnerHTML":if(a!=null)throw Error(h(91));break;default:a!==l&&Q(e,t,c,a,o,l)}tv(e,s,b);return;case"option":for(var y in n)s=n[y],n.hasOwnProperty(y)&&s!=null&&!o.hasOwnProperty(y)&&(y==="selected"?e.selected=!1:Q(e,t,y,null,o,s));for(r in o)s=o[r],b=n[r],o.hasOwnProperty(r)&&s!==b&&(s!=null||b!=null)&&(r==="selected"?(s!==b&&(j=!0),e.selected=s&&typeof s!="function"&&typeof s!="symbol"):Q(e,t,r,s,o,b));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var k in n)s=n[k],n.hasOwnProperty(k)&&s!=null&&!o.hasOwnProperty(k)&&Q(e,t,k,null,o,s);for(d in o)if(s=o[d],b=n[d],o.hasOwnProperty(d)&&s!==b&&(s!=null||b!=null))switch(d){case"children":case"dangerouslySetInnerHTML":if(s!=null)throw Error(h(137,t));break;default:Q(e,t,d,s,o,b)}return;default:if(Yu(t)){for(var x in n)s=n[x],n.hasOwnProperty(x)&&s!==void 0&&!o.hasOwnProperty(x)&&wu(e,t,x,void 0,o,s);for(v in o)s=o[v],b=n[v],!o.hasOwnProperty(v)||s===b||s===void 0&&b===void 0||wu(e,t,v,s,o,b);return}}for(var f in n)s=n[f],n.hasOwnProperty(f)&&s!=null&&!o.hasOwnProperty(f)&&Q(e,t,f,null,o,s);for(m in o)s=o[m],b=n[m],!o.hasOwnProperty(m)||s===b||s==null&&b==null||Q(e,t,m,s,o,b)}function ub(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function Gh(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,n=performance.getEntriesByType("resource"),o=0;o<n.length;o++){var a=n[o],l=a.transferSize,c=a.initiatorType,i=a.duration;if(l&&i&&ub(c)){for(c=0,i=a.responseEnd,o+=1;o<n.length;o++){var r=n[o],d=r.startTime;if(d>i)break;var v=r.transferSize,m=r.initiatorType;v&&ub(m)&&(r=r.responseEnd,c+=v*(r<i?1:(i-d)/(r-d)))}if(--o,t+=8*(l+c)/(a.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Eu=null,zu=null;function vl(e){return e.nodeType===9?e:e.ownerDocument}function db(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function im(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function rm(e,t,n,o){return n=vl(n).createElement(e),n[Ne]=o,n[Fe]=t,Me(n,e,t),Se(n),n}function Nu(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var kr=null;function Xh(){var e=window.event;return e&&e.type==="popstate"?e===kr?!1:(kr=e,!0):(kr=null,!1)}var zd=typeof setTimeout=="function"?setTimeout:void 0,Qh=typeof clearTimeout=="function"?clearTimeout:void 0,fb=typeof Promise=="function"?Promise:void 0,sb=typeof requestAnimationFrame=="function"?requestAnimationFrame:zd,Zh=typeof queueMicrotask=="function"?queueMicrotask:typeof fb<"u"?function(e){return fb.resolve(null).then(e).catch(Kh)}:zd;function Kh(e){setTimeout(function(){throw e})}function Xn(e){return e==="head"}function bb(e,t){var n=t,o=0;do{var a=n.nextSibling;if(e.removeChild(n),a&&a.nodeType===8)if(n=a.data,n==="/$"||n==="/&"){if(o===0){e.removeChild(a),ya(t);return}o--}else if(n==="$"||n==="$?"||n==="$~"||n==="$!"||n==="&")o++;else if(n==="html")Tr(e.ownerDocument.documentElement);else if(n==="head"){n=e.ownerDocument.head,Tr(n);for(var l=n.firstChild;l;){var c=l.nextSibling,i=l.nodeName;l[Tl]||i==="SCRIPT"||i==="STYLE"||i==="LINK"&&l.rel.toLowerCase()==="stylesheet"||n.removeChild(l),l=c}}else n==="body"&&Tr(e.ownerDocument.body);n=a}while(n);ya(t)}function vb(e,t){var n=e;e=0;do{var o=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",n.getAttribute("style")===""&&n.removeAttribute("style")):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),o&&o.nodeType===8)if(n=o.data,n==="/$"){if(e===0)break;e--}else n!=="$"&&n!=="$?"&&n!=="$~"&&n!=="$!"||e++;n=o}while(n)}function um(e,t,n){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display==="inline"){if(t=e.getClientRects(),t.length===1)var o=1;else for(var a=o=0;a<t.length;a++){var l=t[a];0<l.width&&0<l.height&&o++}o===1&&(e=e.style,e.display=t.length===1?"inline-block":"block",e.marginTop="-"+n.paddingTop,e.marginBottom="-"+n.paddingBottom)}}function dm(e,t){e=e.style,t=t.style;var n=t!=null?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=n==null||typeof n=="boolean"?"":(""+n).trim(),n=t!=null?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=n==null||typeof n=="boolean"?"":(""+n).trim(),e.display==="inline-block"&&(t==null?e.display=e.margin="":(n=t.display,e.display=n==null||typeof n=="boolean"?"":n,n=t.margin,n!=null?e.margin=n:(n=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=n==null||typeof n=="boolean"?"":n,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=t==null||typeof t=="boolean"?"":t)))}function fm(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position==="absolute"||t.position==="fixed",clip:t.clipPath!=="none"||t.overflow!=="visible"||t.filter!=="none"||t.mask!=="none"||t.mask!=="none"||t.borderRadius!=="0px",view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function Ou(e){var t=e.getBoundingClientRect(),n=getComputedStyle(e);return fm(t,n,e)}function Jh(e){var t=e.getBoundingClientRect();t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height);var n=getComputedStyle(e);return fm(t,n,e)}function $h(e){return e.documentElement.clientHeight}function Fh(e){this.addEventListener("load",e),this.addEventListener("error",e)}function Wh(e,t,n,o,a,l,c,i,r){var d=t.nodeType===9?t:t.ownerDocument;try{var v=d.startViewTransition({update:function(){var s=d.defaultView,b=s.navigation&&s.navigation.transition,y=d.fonts.status;o();var k=[];if(y==="loaded"&&($h(d),d.fonts.status==="loading"&&k.push(d.fonts.ready)),y=k.length,e!==null)for(var x=e.suspenseyImages,f=0,u=0;u<x.length;u++){var g=x[u];if(!g.complete){var p=g.getBoundingClientRect();if(0<p.bottom&&0<p.right&&p.top<s.innerHeight&&p.left<s.innerWidth){if(f+=Tm(g),f>wc){k.length=y;break}g=new Promise(Fh.bind(g)),k.push(g)}}}if(0<k.length)return s=Promise.race([Promise.all(k),new Promise(function(T){return setTimeout(T,500)})]).then(a,a),(b?Promise.allSettled([b.finished,s]):s).then(l,l);if(a(),b)return b.finished.then(l,l);l()},types:n});d.__reactViewTransition=v;var m=[];return v.ready.then(function(){for(var s=d.documentElement.getAnimations({subtree:!0}),b=0;b<s.length;b++){var y=s[b],k=y.effect,x=k.pseudoElement;if(x!=null&&x.startsWith("::view-transition")){m.push(y),y=k.getKeyframes();for(var f=x=void 0,u=!0,g=0;g<y.length;g++){var p=y[g],T=p.width;if(x===void 0)x=T;else if(x!==T){u=!1;break}if(T=p.height,f===void 0)f=T;else if(f!==T){u=!1;break}delete p.width,delete p.height,p.transform==="none"&&delete p.transform}u&&x!==void 0&&f!==void 0&&(k.setKeyframes(y),u=getComputedStyle(k.target,k.pseudoElement),u.width!==x||u.height!==f)&&(u=y[0],u.width=x,u.height=f,u=y[y.length-1],u.width=x,u.height=f,k.setKeyframes(y))}}c()},function(s){d.__reactViewTransition===v&&(d.__reactViewTransition=null);try{typeof s=="object"&&s!==null&&s.name==="InvalidStateError"&&(s.message==="View transition was skipped because document visibility state is hidden."||s.message==="Skipping view transition because document visibility state has become hidden."||s.message==="Skipping view transition because viewport size changed."||s.message==="Transition was aborted because of invalid state")&&(s=null),s!==null&&r(s)}finally{o(),a(),c()}}),v.finished.finally(function(){for(var s=0;s<m.length;s++)m[s].cancel();d.__reactViewTransition===v&&(d.__reactViewTransition=null),i()}),v}catch{return o(),a(),c(),null}}function oo(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}oo.prototype.animate=function(e,t){return t=typeof t=="number"?{duration:t}:$({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)};oo.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),o=[],a=0;a<n.length;a++){var l=n[a].effect;l!==null&&l.target===e&&l.pseudoElement===t&&o.push(n[a])}return o};oo.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function sm(e){return{name:e,group:new oo("group",e),imagePair:new oo("image-pair",e),old:new oo("old",e),new:new oo("new",e)}}function dt(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}dt.prototype.addEventListener=function(e,t,n){var o=null,a=null;if(!(n!=null&&typeof n!="boolean"&&(o=n.signal||null,o!==null&&o.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var l=this._eventListeners;if(bm(l,e,t,n)===-1){var c=this,i=t;n!=null&&typeof n!="boolean"&&n.once===!0&&(i=function(r){c.removeEventListener(e,t,n),typeof t=="function"?t.call(this,r):t.handleEvent(r)}),o!==null&&(a=c.removeEventListener.bind(c,e,t,n),o.addEventListener("abort",a,{once:!0}),a=o.removeEventListener.bind(o,"abort",a)),o=ga(n),l.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:i,cleanup:a}),$e(this._fragmentFiber.child,!1,Ih,e,i,o)}this._eventListeners=l}};function Ih(e,t,n,o){return he(e).addEventListener(t,n,o),!1}dt.prototype.removeEventListener=function(e,t,n){var o=this._eventListeners;if(o!==null&&(t=bm(o,e,t,n),t!==-1)){var a=o[t];n=a.attachedListener;var l=a.cleanup;a=ga(a.optionsOrUseCapture),$e(this._fragmentFiber.child,!1,Ph,e,n,a),o.splice(t,1),l!==null&&l()}};function Ph(e,t,n,o){return he(e).removeEventListener(t,n,o),!1}function ga(e){return e!=null&&typeof e!="boolean"&&(e.once===!0||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function gb(e){return e==null?"c=0":typeof e=="boolean"?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")}function bm(e,t,n,o){if(e.length===0)return-1;o=gb(o);for(var a=0;a<e.length;a++){var l=e[a];if(l.type===t&&l.listener===n&&gb(l.optionsOrUseCapture)===o)return a}return-1}dt.prototype.dispatchEvent=function(e){var t=ho(this._fragmentFiber);if(t===null)return!0;t=he(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var o=t.nodeType===9?t.createComment(""):document.createTextNode("");if(n)for(var a=0;a<n.length;a++){var l=n[a];o.addEventListener(l.type,l.attachedListener,ga(l.optionsOrUseCapture))}if(t.appendChild(o),e=o.dispatchEvent(e),n)for(a=0;a<n.length;a++)l=n[a],o.removeEventListener(l.type,l.attachedListener,ga(l.optionsOrUseCapture));return t.removeChild(o),e}return t.dispatchEvent(e)};dt.prototype.focus=function(e){$e(this._fragmentFiber.child,!0,vm,e,void 0,void 0)};function vm(e,t){return e.tag===6?!1:(e=he(e),fy(e,t))}dt.prototype.focusLast=function(e){var t=[];$e(this._fragmentFiber.child,!0,Nd,t,void 0,void 0);for(var n=t.length-1;0<=n&&!vm(t[n],e);n--);};function Nd(e,t){return t.push(e),!1}dt.prototype.blur=function(){var e=ho(this._fragmentFiber);e!==null&&(e=he(e),e=vl(e).activeElement,e!==null&&$e(this._fragmentFiber.child,!1,ey,e,void 0,void 0))};function ey(e,t){return e.tag===6?!1:(e=he(e),e===t||e.contains(t)?(t.blur(),!0):!1)}dt.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),$e(this._fragmentFiber.child,!1,ty,e,void 0,void 0)};function ty(e,t){return e.tag===6||(e=he(e),t.observe(e)),!1}dt.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),$e(this._fragmentFiber.child,!1,ny,e,void 0,void 0);for(var n=t=0;n<At.length;n++){var o=At[n];o.fragmentInstance===this&&o.observer===e?e.unobserve(o.instance):At[t++]=o}At.length=t}};function ny(e,t){return e.tag===6||(e=he(e),t.unobserve(e)),!1}var At=[],Sr=!1;function oy(e,t,n){At.push({fragmentInstance:e,observer:t,instance:n}),Sr||(Sr=!0,sy(function(){Sr=!1;var o=At;At=[];for(var a=0;a<o.length;a++){var l=o[a];l.observer.unobserve(l.instance)}}))}dt.prototype.getClientRects=function(){var e=[];return $e(this._fragmentFiber.child,!1,ay,e,void 0,void 0),e};function ay(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=he(e),t.push.apply(t,e.getClientRects());return!1}dt.prototype.getRootNode=function(e){var t=ho(this._fragmentFiber);return t===null?this:he(t).getRootNode(e)};dt.prototype.compareDocumentPosition=function(e){var t=ho(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];$e(this._fragmentFiber.child,!1,Nd,n,void 0,void 0);var o=he(t);if(n.length===0){if(n=o,Jf(this._fragmentFiber)){e:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break e}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var a=o=n.compareDocumentPosition(e);return n===e?a=Node.DOCUMENT_POSITION_CONTAINS:o&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=Ub(t)[1],n===null?a=Node.DOCUMENT_POSITION_PRECEDING:(e=he(n).compareDocumentPosition(e),a=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),a|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=he(n[0]),a=he(n[n.length-1]);var l=Jf(this._fragmentFiber)?t.parentElement:o;if(l==null)return Node.DOCUMENT_POSITION_DISCONNECTED;o=l.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,l=l.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_CONTAINED_BY;var c=t.compareDocumentPosition(e),i=a.compareDocumentPosition(e),r=c&Node.DOCUMENT_POSITION_CONTAINED_BY||i&Node.DOCUMENT_POSITION_CONTAINED_BY;return i=o&&l&&c&Node.DOCUMENT_POSITION_FOLLOWING&&i&Node.DOCUMENT_POSITION_PRECEDING,t=o&&t===e||l&&a===e||r||i?Node.DOCUMENT_POSITION_CONTAINED_BY:!o&&t===e||!l&&a===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:c,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||ly(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function ly(e,t,n,o,a){var l=no(a);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!l)e:{for(;l!==null;){if(l.tag===7&&(l===t||l.alternate===t)){n=!0;break e}l=l.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(l===null)return l=a.ownerDocument,a===l||a===l.documentElement||a===l.body;e:{for(l=t,t=ho(t);l!==null;){if(!(l.tag!==5&&l.tag!==3&&l.tag!==27||l!==t&&l.alternate!==t)){l=!0;break e}l=l.return}l=!1}return l}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!l)&&!(t=l===n)&&(t=Er(n,l,$f),t===null?t=!1:($e(t,!0,Rp,l,n),l=jo,jo=null,t=l!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!l)&&!(t=l===o)&&(t=Er(o,l,$f),t===null?t=!1:($e(t,!0,Up,l,o),l=jo,wr=jo=null,t=l!==null)),t):!1}function mb(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}dt.prototype.scrollIntoView=function(e){if(typeof e=="object")throw Error(h(566));var t=[];$e(this._fragmentFiber.child,!1,Nd,t,void 0,void 0);var n=e!==!1;if(t.length===0){var o=Ub(this._fragmentFiber);if(o=n?o[1]||o[0]||ho(this._fragmentFiber):o[0]||o[1],o===null)return;if(o.tag===6){e=he(o),mb(e,n);return}if(o=he(o),o.nodeType!==9){if(o.nodeType===11){n="host"in o?o.host:null,n!==null&&n.scrollIntoView(e);return}o.scrollIntoView(e)}}for(o=n?t.length-1:0;o!==(n?-1:t.length);){var a=t[o];a.tag===6?(a=he(a),mb(a,n)):he(a).scrollIntoView(e),o+=n?-1:1}};function cy(e,t){return e=he(e),gm(e,t),!1}function gm(e,t){e.reactFragments==null&&(e.reactFragments=new Set),e.reactFragments.add(t)}function mm(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.addEventListener(a.type,a.attachedListener,ga(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(l){for(var c=0,i=0;i<At.length;i++){var r=At[i];(r.fragmentInstance!==t||r.observer!==l||r.instance!==e)&&(At[c++]=r)}At.length=c,l.observe(e)}),gm(e,t))}function iy(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.removeEventListener(a.type,a.attachedListener,ga(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(l){typeof l.rootMargin=="string"?oy(t,l,e):l.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function Au(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":Au(n),oi(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(n.rel.toLowerCase()==="stylesheet")continue}e.removeChild(n)}}function ry(e,t,n,o){for(;e.nodeType===1;){var a=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[Tl])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(l=e.getAttribute("rel"),l==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(l!==a.rel||e.getAttribute("href")!==(a.href==null||a.href===""?null:a.href)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin)||e.getAttribute("title")!==(a.title==null?null:a.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(l=e.getAttribute("src"),(l!==(a.src==null?null:a.src)||e.getAttribute("type")!==(a.type==null?null:a.type)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin))&&l&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var l=a.name==null?null:""+a.name;if(a.type==="hidden"&&e.getAttribute("name")===l)return e}else return e;if(e=Tt(e.nextSibling),e===null)break}return null}function uy(e,t,n){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=Tt(e.nextSibling),e===null))return null;return e}function pm(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=Tt(e.nextSibling),e===null))return null;return e}function _u(e){return e.data==="$?"||e.data==="$~"}function Od(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function dy(e,t){var n=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||n.readyState!=="loading")t();else{var o=function(){t(),n.removeEventListener("DOMContentLoaded",o)};n.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function Tt(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var Mu=null;function pb(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"||n==="/&"){if(t===0)return Tt(e.nextSibling);t--}else n!=="$"&&n!=="$!"&&n!=="$?"&&n!=="$~"&&n!=="&"||t++}e=e.nextSibling}return null}function hb(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"){if(t===0)return e;t--}else n!=="/$"&&n!=="/&"||t++}e=e.previousSibling}return null}function fy(e,t){function n(){o=!0}if(e.ownerDocument.activeElement===e)return!0;var o=!1;try{e.ownerDocument.addEventListener("focus",n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener("focus",n,!0)}return o}function sy(e){sb(function(){sb(function(t){return e(t)})})}function hm(e,t,n){switch(t=vl(n),e){case"html":if(e=t.documentElement,!e)throw Error(h(452));return e;case"head":if(e=t.head,!e)throw Error(h(453));return e;case"body":if(e=t.body,!e)throw Error(h(454));return e;default:throw Error(h(451))}}function ym(e,t,n){for(var o in n){var a=n[o];n.hasOwnProperty(o)&&a!=null&&Q(e,t,o,null,Lh,a)}n.dangerouslySetInnerHTML!=null&&(e.textContent=""),e.onclick===Lt&&(e.onclick=null),oi(e)}function Tr(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);oi(e)}var wt=new Map,yb=new Set;function gl(e){if(typeof e.getRootNode=="function"){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var sn=L.d;L.d={f:by,r:vy,D:gy,C:my,L:py,m:hy,X:xy,S:yy,M:ky};function by(){var e=sn.f(),t=pi();return e||t}function vy(e){var t=ka(e);t!==null&&t.tag===5&&t.type==="form"?og(t):sn.r(e)}var Ea=typeof document>"u"?null:document;function xm(e,t,n){var o=Ea;if(o&&typeof t=="string"&&t){var a=xt(t);a='link[rel="'+e+'"][href="'+a+'"]',typeof n=="string"&&(a+='[crossorigin="'+n+'"]'),yb.has(a)||(yb.add(a),e={rel:e,crossOrigin:n,href:t},o.querySelector(a)===null&&(t=o.createElement("link"),Me(t,"link",e),Se(t),o.head.appendChild(t)))}}function gy(e){sn.D(e),xm("dns-prefetch",e,null)}function my(e,t){sn.C(e,t),xm("preconnect",e,t)}function py(e,t,n){sn.L(e,t,n);var o=Ea;if(o&&e&&t){var a='link[rel="preload"][as="'+xt(t)+'"]';t==="image"&&n&&n.imageSrcSet?(a+='[imagesrcset="'+xt(n.imageSrcSet)+'"]',typeof n.imageSizes=="string"&&(a+='[imagesizes="'+xt(n.imageSizes)+'"]')):a+='[href="'+xt(e)+'"]';var l=a;switch(t){case"style":l=ma(e);break;case"script":l=za(e)}if(!(wt.has(l)||(e=$({rel:"preload",href:t==="image"&&n&&n.imageSrcSet?void 0:e,as:t},n),wt.set(l,e),o.querySelector(a)!==null||t==="style"&&o.querySelector(Al(l))||t==="script"&&o.querySelector(_l(l))))){var c=o.createElement("link");Me(c,"link",e),t==="style"&&(c[Mc]=!0,c.onload=c.onerror=function(){$b(c)}),Se(c),o.head.appendChild(c)}}}function hy(e,t){sn.m(e,t);var n=Ea;if(n&&e){var o=t&&typeof t.as=="string"?t.as:"script",a='link[rel="modulepreload"][as="'+xt(o)+'"][href="'+xt(e)+'"]',l=a;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":l=za(e)}if(!wt.has(l)&&(e=$({rel:"modulepreload",href:e},t),wt.set(l,e),n.querySelector(a)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector(_l(l)))return}o=n.createElement("link"),Me(o,"link",e),Se(o),n.head.appendChild(o)}}}function yy(e,t,n){sn.S(e,t,n);var o=Ea;if(o&&e){var a=Wo(o).hoistableStyles,l=ma(e);t=t||"default";var c=a.get(l);if(!c){var i={loading:0,preload:null};if(c=o.querySelector(Al(l)))i.loading=5;else{e=$({rel:"stylesheet",href:e,"data-precedence":t},n),(n=wt.get(l))&&Ad(e,n);var r=c=o.createElement("link");Se(r),Me(r,"link",e),r._p=new Promise(function(d,v){r.onload=d,r.onerror=v}),r.addEventListener("load",function(){i.loading|=1}),r.addEventListener("error",function(){i.loading|=2}),i.loading|=4,Sc(c,t,o)}c={type:"stylesheet",instance:c,count:1,state:i},a.set(l,c)}}}function xy(e,t){sn.X(e,t);var n=Ea;if(n&&e){var o=Wo(n).hoistableScripts,a=za(e),l=o.get(a);l||(l=n.querySelector(_l(a)),l||(e=$({src:e,async:!0},t),(t=wt.get(a))&&_d(e,t),l=n.createElement("script"),Se(l),Me(l,"link",e),n.head.appendChild(l)),l={type:"script",instance:l,count:1,state:null},o.set(a,l))}}function ky(e,t){sn.M(e,t);var n=Ea;if(n&&e){var o=Wo(n).hoistableScripts,a=za(e),l=o.get(a);l||(l=n.querySelector(_l(a)),l||(e=$({src:e,async:!0,type:"module"},t),(t=wt.get(a))&&_d(e,t),l=n.createElement("script"),Se(l),Me(l,"link",e),n.head.appendChild(l)),l={type:"script",instance:l,count:1,state:null},o.set(a,l))}}function xb(e,t,n,o){var a=(a=On.current)?gl(a):null;if(!a)throw Error(h(446));switch(e){case"meta":case"title":return null;case"style":return typeof n.precedence=="string"&&typeof n.href=="string"?(n=ma(n.href),t=Wo(a).hoistableStyles,o=t.get(n),o||(o={type:"style",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(n.rel==="stylesheet"&&typeof n.href=="string"&&typeof n.precedence=="string"){e=ma(n.href);var l=Wo(a).hoistableStyles,c=l.get(e);if(c||(a=a.ownerDocument||a,c={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},l.set(e,c),(l=a.querySelector(Al(e)))?l._p||(c.instance=l,c.state.loading=5):(l=wt.get(e),l||(l={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},wt.set(e,l)),Sy(a,e,l,c.state))),t&&o===null)throw Error(h(528,""));return c}if(t&&o!==null)throw Error(h(529,""));return null;case"script":return t=n.async,n=n.src,typeof n=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(n=za(n),t=Wo(a).hoistableScripts,o=t.get(n),o||(o={type:"script",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(h(444,e))}}function ma(e){return'href="'+xt(e)+'"'}function Al(e){return'link[rel="stylesheet"]['+e+"]"}function km(e){return $({},e,{"data-precedence":e.precedence,precedence:null})}function Sy(e,t,n,o){if(t=e.querySelector('link[rel="preload"][as="style"]['+t+"]")){if(t[Mc]!==!0){o.loading=1;return}}else t=e.createElement("link"),t[Mc]=!0,t.onload=t.onerror=$b.bind(null,t),Me(t,"link",n),Se(t),e.head.appendChild(t);o.preload=t,t.addEventListener("load",function(){return o.loading|=1}),t.addEventListener("error",function(){return o.loading|=2})}function za(e){return'[src="'+xt(e)+'"]'}function _l(e){return"script[async]"+e}function kb(e,t,n){if(t.count++,t.instance===null)switch(t.type){case"style":var o=e.querySelector('style[data-href~="'+xt(n.href)+'"]');if(o)return t.instance=o,Se(o),o;var a=$({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),Se(o),Me(o,"style",a),Sc(o,n.precedence,e),t.instance=o;case"stylesheet":a=ma(n.href);var l=e.querySelector(Al(a));if(l)return t.state.loading|=4,t.instance=l,Se(l),l;o=km(n),(a=wt.get(a))&&Ad(o,a),l=(e.ownerDocument||e).createElement("link"),Se(l);var c=l;return c._p=new Promise(function(i,r){c.onload=i,c.onerror=r}),Me(l,"link",o),t.state.loading|=4,Sc(l,n.precedence,e),t.instance=l;case"script":return l=za(n.src),(a=e.querySelector(_l(l)))?(t.instance=a,Se(a),a):(o=n,(a=wt.get(l))&&(o=$({},n),_d(o,a)),e=e.ownerDocument||e,a=e.createElement("script"),Se(a),Me(a,"link",o),e.head.appendChild(a),t.instance=a);case"void":return null;default:throw Error(h(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(o=t.instance,t.state.loading|=4,Sc(o,n.precedence,e));return t.instance}function Sc(e,t,n){for(var o=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),a=o.length?o[o.length-1]:null,l=a,c=0;c<o.length;c++){var i=o[c];if(i.dataset.precedence===t)l=i;else if(l!==a)break}l?l.parentNode.insertBefore(e,l.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Ad(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function _d(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var Tc=null;function Sb(e,t,n){if(Tc===null){var o=new Map,a=Tc=new Map;a.set(n,o)}else a=Tc,o=a.get(n),o||(o=new Map,a.set(n,o));if(o.has(e))return o;for(o.set(e,null),n=n.getElementsByTagName(e),a=0;a<n.length;a++){var l=n[a];if(!(l[Tl]||l[Ne]||e==="link"&&l.getAttribute("rel")==="stylesheet")&&l.namespaceURI!=="http://www.w3.org/2000/svg"){var c=l.getAttribute(t)||"";c=e+c;var i=o.get(c);i?i.push(l):o.set(c,[l])}}return o}function Cu(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t==="title"?e.querySelector("head > title"):null)}function Ty(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function Tb(e,t){return e==="img"&&t.src!=null&&t.src!==""&&t.onLoad==null&&t.loading!=="lazy"}function Sm(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function Tm(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function wb(e,t){typeof t.decode=="function"&&(e.imgCount++,t.complete||(e.imgBytes+=Tm(t),e.suspenseyImages.push(t)),e=zy.bind(e),t.decode().then(e,e))}function wy(e,t,n,o){if(n.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var a=ma(o.href),l=t.querySelector(Al(a));if(l){t=l._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=ml.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=l,Se(l);return}l=t.ownerDocument||t,o=km(o),(a=wt.get(a))&&Ad(o,a),l=l.createElement("link"),Se(l);var c=l;c._p=new Promise(function(i,r){c.onload=i,c.onerror=r}),Me(l,"link",o),n.instance=l}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(e.count++,n=ml.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}var wc=0;function Ey(e,t){return e.stylesheets&&e.count===0&&Ec(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var o=setTimeout(function(){if(e.stylesheets&&Ec(e,e.stylesheets),e.unsuspend){var l=e.unsuspend;e.unsuspend=null,l()}},6e4+t);0<e.imgBytes&&wc===0&&(wc=62500*Gh());var a=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&Ec(e,e.stylesheets),e.unsuspend)){var l=e.unsuspend;e.unsuspend=null,l()}},(e.imgBytes>wc?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(a)}}:null}function wm(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)Ec(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function ml(){this.count--,wm(this)}function zy(){this.imgCount--,wm(this)}var ei=null;function Ec(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,ei=new Map,t.forEach(Ny,e),ei=null,ml.call(e))}function Ny(e,t){if(!(t.state.loading&4)){var n=ei.get(e);if(n)var o=n.get(null);else{n=new Map,ei.set(e,n);for(var a=e.querySelectorAll("link[data-precedence],style[data-precedence]"),l=0;l<a.length;l++){var c=a[l];(c.nodeName==="LINK"||c.getAttribute("media")!=="not all")&&(n.set(c.dataset.precedence,c),o=c)}o&&n.set(null,o)}a=t.instance,c=a.getAttribute("data-precedence"),l=n.get(c)||o,l===o&&n.set(null,a),n.set(c,a),this.count++,o=ml.bind(this),a.addEventListener("load",o),a.addEventListener("error",o),l?l.parentNode.insertBefore(a,l.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(a,e.firstChild)),t.state.loading|=4}}var pa={$$typeof:Yt,Provider:null,Consumer:null,_currentValue:ao,_currentValue2:ao,_threadCount:0};function Oy(e,t,n,o,a,l,c,i,r){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Wi(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Wi(0),this.hiddenUpdates=Wi(null),this.identifierPrefix=o,this.onUncaughtError=a,this.onCaughtError=l,this.onRecoverableError=c,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=r,this.transitionTypes=null,this.incompleteTransitions=new Map}function Em(e,t,n,o,a,l,c,i,r,d,v,m){return e=new Oy(e,t,n,c,r,d,v,m,i),t=1,l===!0&&(t|=24),l=Ke(3,null,null,t),e.current=l,l.stateNode=e,t=Fu(),t.refCount++,e.pooledCache=t,t.refCount++,l.memoizedState={element:o,isDehydrated:n,cache:t},Pu(l),e}function zm(e){return e?(e=Ko,e):Ko}function Nm(e,t,n,o,a,l){a=zm(a),o.context===null?o.context=a:o.pendingContext=a,o=_n(t),o.payload={element:n},l=l===void 0?null:l,l!==null&&(o.callback=l),n=Mn(e,o,t),n!==null&&(Je(n,e,t),Ja(n,e,t))}function Eb(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function Md(e,t){Eb(e,t),(e=e.alternate)&&Eb(e,t)}function Om(e){if(e.tag===13||e.tag===31){var t=ko(e,67108864);t!==null&&Je(t,e,67108864),Md(e,67108864)}}function zb(e){if(e.tag===13||e.tag===31){var t=rt();t=qu(t);var n=ko(e,t);n!==null&&Je(n,e,t),Md(e,t)}}var ha=!0;function Ay(e,t,n,o){var a=O.T;O.T=null;var l=L.p;try{L.p=2,Cd(e,t,n,o)}finally{L.p=l,O.T=a}}function _y(e,t,n,o){var a=O.T;O.T=null;var l=L.p;try{L.p=8,Cd(e,t,n,o)}finally{L.p=l,O.T=a}}function Cd(e,t,n,o){if(ha){var a=Du(o);if(a===null)xr(e,t,o,ti,n),Nb(e,o);else if(Cy(a,e,t,n,o))o.stopPropagation();else if(Nb(e,o),t&4&&-1<My.indexOf(e)){for(;a!==null;){var l=ka(a);if(l!==null)switch(l.tag){case 3:if(l=l.stateNode,l.current.memoizedState.isDehydrated){var c=Pn(l.pendingLanes);if(c!==0){var i=l;for(i.pendingLanes|=2,i.entangledLanes|=2;c;){var r=1<<31-it(c);i.entanglements[1]|=r,c&=~r}Jt(l),(Y&6)===0&&($c=lt()+500,Ol(0,!1))}}break;case 31:case 13:i=ko(l,2),i!==null&&Je(i,l,2),pi(),Md(l,2)}if(l=Du(o),l===null&&xr(e,t,o,ti,n),l===a)break;a=l}a!==null&&o.stopPropagation()}else xr(e,t,o,null,n)}}function Du(e){return e=Lu(e),Dd(e)}var ti=null;function Dd(e){if(ti=null,e=no(e),e!==null){var t=yl(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=Db(t),e!==null)return e;e=null}else if(n===31){if(e=Hb(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return ti=e,null}function Am(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Qp()){case Yb:return 2;case Lb:return 8;case _c:case Zp:return 32;case Vb:return 268435456;default:return 32}default:return 32}}var Hu=!1,Rn=null,Un=null,Bn=null,pl=new Map,hl=new Map,kn=[],My="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Nb(e,t){switch(e){case"focusin":case"focusout":Rn=null;break;case"dragenter":case"dragleave":Un=null;break;case"mouseover":case"mouseout":Bn=null;break;case"pointerover":case"pointerout":pl.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":hl.delete(t.pointerId)}}function Ba(e,t,n,o,a,l){return e===null||e.nativeEvent!==l?(e={blockedOn:t,domEventName:n,eventSystemFlags:o,nativeEvent:l,targetContainers:[a]},t!==null&&(t=ka(t),t!==null&&Om(t)),e):(e.eventSystemFlags|=o,t=e.targetContainers,a!==null&&t.indexOf(a)===-1&&t.push(a),e)}function Cy(e,t,n,o,a){switch(t){case"focusin":return Rn=Ba(Rn,e,t,n,o,a),!0;case"dragenter":return Un=Ba(Un,e,t,n,o,a),!0;case"mouseover":return Bn=Ba(Bn,e,t,n,o,a),!0;case"pointerover":var l=a.pointerId;return pl.set(l,Ba(pl.get(l)||null,e,t,n,o,a)),!0;case"gotpointercapture":return l=a.pointerId,hl.set(l,Ba(hl.get(l)||null,e,t,n,o,a)),!0}return!1}function _m(e){var t=no(e.target);if(t!==null){var n=yl(t);if(n!==null){if(t=n.tag,t===13){if(t=Db(n),t!==null){e.blockedOn=t,Pf(e.priority,function(){zb(n)});return}}else if(t===31){if(t=Hb(n),t!==null){e.blockedOn=t,Pf(e.priority,function(){zb(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function zc(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=Du(e.nativeEvent);if(n===null){n=e.nativeEvent;var o=new n.constructor(n.type,n);Br=o,n.target.dispatchEvent(o),Br=null}else return t=ka(n),t!==null&&Om(t),e.blockedOn=n,!1;t.shift()}return!0}function Ob(e,t,n){zc(e)&&n.delete(t)}function Dy(){Hu=!1,Rn!==null&&zc(Rn)&&(Rn=null),Un!==null&&zc(Un)&&(Un=null),Bn!==null&&zc(Bn)&&(Bn=null),pl.forEach(Ob),hl.forEach(Ob)}function cc(e,t){e.blockedOn===t&&(e.blockedOn=null,Hu||(Hu=!0,ye.unstable_scheduleCallback(ye.unstable_NormalPriority,Dy)))}var ic=null;function Ab(e){ic!==e&&(ic=e,ye.unstable_scheduleCallback(ye.unstable_NormalPriority,function(){ic===e&&(ic=null);for(var t=0;t<e.length;t+=3){var n=e[t],o=e[t+1],a=e[t+2];if(typeof o!="function"){if(Dd(o||n)===null)continue;break}var l=ka(n);l!==null&&(e.splice(t,3),t-=3,Pr(l,{pending:!0,data:a,method:n.method,action:o},o,a))}}))}function ya(e){function t(r){return cc(r,e)}Rn!==null&&cc(Rn,e),Un!==null&&cc(Un,e),Bn!==null&&cc(Bn,e),pl.forEach(t),hl.forEach(t);for(var n=0;n<kn.length;n++){var o=kn[n];o.blockedOn===e&&(o.blockedOn=null)}for(;0<kn.length&&(n=kn[0],n.blockedOn===null);)_m(n),n.blockedOn===null&&kn.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(o=0;o<n.length;o+=3){var a=n[o],l=n[o+1],c=a[Fe]||null;if(typeof l=="function")c||Ab(n);else if(c){var i=null;if(l&&l.hasAttribute("formAction")){if(a=l,c=l[Fe]||null)i=c.formAction;else if(Dd(a)!==null)continue}else i=c.action;typeof i=="function"?n[o+1]=i:(n.splice(o,3),o-=3),Ab(n)}}}function Mm(){function e(l){l.canIntercept&&l.info==="react-transition"&&l.intercept({handler:function(){return new Promise(function(c){return a=c})},focusReset:"manual",scroll:"manual"})}function t(){a!==null&&(a(),a=null),o||setTimeout(n,20)}function n(){if(!o&&!navigation.transition){var l=navigation.currentEntry;l&&l.url!=null&&navigation.navigate(l.url,{state:l.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,a=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),a!==null&&(a(),a=null)}}}function Hd(e){this._internalRoot=e}xi.prototype.render=Hd.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(h(409));var n=t.current,o=rt();Nm(n,o,e,t,null,null)};xi.prototype.unmount=Hd.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Nm(e.current,2,null,e,null,null),pi(),t[xa]=null}};function xi(e){this._internalRoot=e}xi.prototype.unstable_scheduleHydration=function(e){if(e){var t=Jb();e={blockedOn:null,target:e,priority:t};for(var n=0;n<kn.length&&t!==0&&t<kn[n].priority;n++);kn.splice(n,0,e),n===0&&_m(e)}};var _b=Mb.version;if(_b!=="19.3.0")throw Error(h(527,_b,"19.3.0"));L.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(h(188)):(e=Object.keys(e).join(","),Error(h(268,e)));return e=Hp(t),e=e!==null?Rb(e):null,e=e===null?null:e.stateNode,e};var Hy={bundleType:0,version:"19.3.0",rendererPackageName:"react-dom",currentDispatcherRef:O,reconcilerVersion:"19.3.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(qa=__REACT_DEVTOOLS_GLOBAL_HOOK__,!qa.isDisabled&&qa.supportsFiber))try{xl=qa.inject(Hy),ct=qa}catch{}var qa;ki.createRoot=function(e,t){if(!Cb(e))throw Error(h(299));var n=!1,o="",a=fg,l=sg,c=bg;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(o=t.identifierPrefix),t.onUncaughtError!==void 0&&(a=t.onUncaughtError),t.onCaughtError!==void 0&&(l=t.onCaughtError),t.onRecoverableError!==void 0&&(c=t.onRecoverableError)),t=Em(e,1,!1,null,null,n,o,null,a,l,c,Mm),e[xa]=t.current,Ed(e),new Hd(t)};ki.hydrateRoot=function(e,t,n){if(!Cb(e))throw Error(h(299));var o=!1,a="",l=fg,c=sg,i=bg,r=null;return n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(a=n.identifierPrefix),n.onUncaughtError!==void 0&&(l=n.onUncaughtError),n.onCaughtError!==void 0&&(c=n.onCaughtError),n.onRecoverableError!==void 0&&(i=n.onRecoverableError),n.formState!==void 0&&(r=n.formState)),t=Em(e,1,!0,t,n??null,o,a,r,l,c,i,Mm),t.context=zm(null),n=t.current,o=rt(),o=qu(o),a=_n(o),a.callback=null,Mn(n,a,o),n=o,t.current.lanes=n,Sl(t,n),Jt(t),e[xa]=t.current,Ed(e),new xi(t)};ki.version="19.3.0"});var Rm=Ct((j1,Hm)=>{"use strict";function Dm(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Dm)}catch(e){console.error(e)}}Dm(),Hm.exports=Cm()});var Ud=`/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

@font-face {
	font-family: "codicon";
	font-display: block;
	src: url("./codicon.ttf?9aab6318a6710999273bab9c78a9fd71") format("truetype");
}

.codicon[class*='codicon-'] {
	font: normal normal normal 16px/1 codicon;
	display: inline-block;
	text-decoration: none;
	text-rendering: auto;
	text-align: center;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	user-select: none;
	-webkit-user-select: none;
	-ms-user-select: none;
}

/*---------------------
 *  Modifiers
 *-------------------*/

@keyframes codicon-spin {
	100% {
		transform:rotate(360deg);
	}
}

.codicon-sync.codicon-modifier-spin,
.codicon-loading.codicon-modifier-spin,
.codicon-gear.codicon-modifier-spin {
	/* Use steps to throttle FPS to reduce CPU usage */
	animation: codicon-spin 1.5s steps(30) infinite;
}

.codicon-modifier-disabled {
	opacity: 0.5;
}

.codicon-modifier-hidden {
	opacity: 0;
}

/* custom speed & easing for loading icon */
.codicon-loading {
	animation-duration: 1s !important;
	animation-timing-function: cubic-bezier(0.53, 0.21, 0.29, 0.67) !important;
}

/*---------------------
 *  Icons
 *-------------------*/

.codicon-add:before { content: "\\ea60" }
.codicon-plus:before { content: "\\ea60" }
.codicon-gist-new:before { content: "\\ea60" }
.codicon-repo-create:before { content: "\\ea60" }
.codicon-lightbulb:before { content: "\\ea61" }
.codicon-light-bulb:before { content: "\\ea61" }
.codicon-repo:before { content: "\\ea62" }
.codicon-repo-delete:before { content: "\\ea62" }
.codicon-gist-fork:before { content: "\\ea63" }
.codicon-repo-forked:before { content: "\\ea63" }
.codicon-git-pull-request:before { content: "\\ea64" }
.codicon-git-pull-request-abandoned:before { content: "\\ea64" }
.codicon-record-keys:before { content: "\\ea65" }
.codicon-keyboard:before { content: "\\ea65" }
.codicon-tag:before { content: "\\ea66" }
.codicon-git-pull-request-label:before { content: "\\ea66" }
.codicon-tag-add:before { content: "\\ea66" }
.codicon-tag-remove:before { content: "\\ea66" }
.codicon-person:before { content: "\\ea67" }
.codicon-person-follow:before { content: "\\ea67" }
.codicon-person-outline:before { content: "\\ea67" }
.codicon-person-filled:before { content: "\\ea67" }
.codicon-source-control:before { content: "\\ea68" }
.codicon-mirror:before { content: "\\ea69" }
.codicon-mirror-public:before { content: "\\ea69" }
.codicon-star:before { content: "\\ea6a" }
.codicon-star-add:before { content: "\\ea6a" }
.codicon-star-delete:before { content: "\\ea6a" }
.codicon-star-empty:before { content: "\\ea6a" }
.codicon-comment:before { content: "\\ea6b" }
.codicon-comment-add:before { content: "\\ea6b" }
.codicon-alert:before { content: "\\ea6c" }
.codicon-warning:before { content: "\\ea6c" }
.codicon-search:before { content: "\\ea6d" }
.codicon-search-save:before { content: "\\ea6d" }
.codicon-log-out:before { content: "\\ea6e" }
.codicon-sign-out:before { content: "\\ea6e" }
.codicon-log-in:before { content: "\\ea6f" }
.codicon-sign-in:before { content: "\\ea6f" }
.codicon-eye:before { content: "\\ea70" }
.codicon-eye-unwatch:before { content: "\\ea70" }
.codicon-eye-watch:before { content: "\\ea70" }
.codicon-circle-filled:before { content: "\\ea71" }
.codicon-primitive-dot:before { content: "\\ea71" }
.codicon-close-dirty:before { content: "\\ea71" }
.codicon-debug-breakpoint:before { content: "\\ea71" }
.codicon-debug-breakpoint-disabled:before { content: "\\ea71" }
.codicon-debug-hint:before { content: "\\ea71" }
.codicon-terminal-decoration-success:before { content: "\\ea71" }
.codicon-primitive-square:before { content: "\\ea72" }
.codicon-edit:before { content: "\\ea73" }
.codicon-pencil:before { content: "\\ea73" }
.codicon-info:before { content: "\\ea74" }
.codicon-issue-opened:before { content: "\\ea74" }
.codicon-gist-private:before { content: "\\ea75" }
.codicon-git-fork-private:before { content: "\\ea75" }
.codicon-lock:before { content: "\\ea75" }
.codicon-mirror-private:before { content: "\\ea75" }
.codicon-close:before { content: "\\ea76" }
.codicon-remove-close:before { content: "\\ea76" }
.codicon-x:before { content: "\\ea76" }
.codicon-repo-sync:before { content: "\\ea77" }
.codicon-sync:before { content: "\\ea77" }
.codicon-clone:before { content: "\\ea78" }
.codicon-desktop-download:before { content: "\\ea78" }
.codicon-beaker:before { content: "\\ea79" }
.codicon-microscope:before { content: "\\ea79" }
.codicon-vm:before { content: "\\ea7a" }
.codicon-device-desktop:before { content: "\\ea7a" }
.codicon-file:before { content: "\\ea7b" }
.codicon-more:before { content: "\\ea7c" }
.codicon-ellipsis:before { content: "\\ea7c" }
.codicon-kebab-horizontal:before { content: "\\ea7c" }
.codicon-mail-reply:before { content: "\\ea7d" }
.codicon-reply:before { content: "\\ea7d" }
.codicon-organization:before { content: "\\ea7e" }
.codicon-organization-filled:before { content: "\\ea7e" }
.codicon-organization-outline:before { content: "\\ea7e" }
.codicon-new-file:before { content: "\\ea7f" }
.codicon-file-add:before { content: "\\ea7f" }
.codicon-new-folder:before { content: "\\ea80" }
.codicon-file-directory-create:before { content: "\\ea80" }
.codicon-trash:before { content: "\\ea81" }
.codicon-trashcan:before { content: "\\ea81" }
.codicon-history:before { content: "\\ea82" }
.codicon-clock:before { content: "\\ea82" }
.codicon-folder:before { content: "\\ea83" }
.codicon-file-directory:before { content: "\\ea83" }
.codicon-symbol-folder:before { content: "\\ea83" }
.codicon-logo-github:before { content: "\\ea84" }
.codicon-mark-github:before { content: "\\ea84" }
.codicon-github:before { content: "\\ea84" }
.codicon-terminal:before { content: "\\ea85" }
.codicon-console:before { content: "\\ea85" }
.codicon-repl:before { content: "\\ea85" }
.codicon-zap:before { content: "\\ea86" }
.codicon-symbol-event:before { content: "\\ea86" }
.codicon-error:before { content: "\\ea87" }
.codicon-stop:before { content: "\\ea87" }
.codicon-variable:before { content: "\\ea88" }
.codicon-symbol-variable:before { content: "\\ea88" }
.codicon-array:before { content: "\\ea8a" }
.codicon-symbol-array:before { content: "\\ea8a" }
.codicon-symbol-module:before { content: "\\ea8b" }
.codicon-symbol-package:before { content: "\\ea8b" }
.codicon-symbol-namespace:before { content: "\\ea8b" }
.codicon-symbol-object:before { content: "\\ea8b" }
.codicon-symbol-method:before { content: "\\ea8c" }
.codicon-symbol-function:before { content: "\\ea8c" }
.codicon-symbol-constructor:before { content: "\\ea8c" }
.codicon-symbol-boolean:before { content: "\\ea8f" }
.codicon-symbol-null:before { content: "\\ea8f" }
.codicon-symbol-numeric:before { content: "\\ea90" }
.codicon-symbol-number:before { content: "\\ea90" }
.codicon-symbol-structure:before { content: "\\ea91" }
.codicon-symbol-struct:before { content: "\\ea91" }
.codicon-symbol-parameter:before { content: "\\ea92" }
.codicon-symbol-type-parameter:before { content: "\\ea92" }
.codicon-symbol-key:before { content: "\\ea93" }
.codicon-symbol-text:before { content: "\\ea93" }
.codicon-symbol-reference:before { content: "\\ea94" }
.codicon-go-to-file:before { content: "\\ea94" }
.codicon-symbol-enum:before { content: "\\ea95" }
.codicon-symbol-value:before { content: "\\ea95" }
.codicon-symbol-ruler:before { content: "\\ea96" }
.codicon-symbol-unit:before { content: "\\ea96" }
.codicon-activate-breakpoints:before { content: "\\ea97" }
.codicon-archive:before { content: "\\ea98" }
.codicon-arrow-both:before { content: "\\ea99" }
.codicon-arrow-down:before { content: "\\ea9a" }
.codicon-arrow-left:before { content: "\\ea9b" }
.codicon-arrow-right:before { content: "\\ea9c" }
.codicon-arrow-small-down:before { content: "\\ea9d" }
.codicon-arrow-small-left:before { content: "\\ea9e" }
.codicon-arrow-small-right:before { content: "\\ea9f" }
.codicon-arrow-small-up:before { content: "\\eaa0" }
.codicon-arrow-up:before { content: "\\eaa1" }
.codicon-bell:before { content: "\\eaa2" }
.codicon-bold:before { content: "\\eaa3" }
.codicon-book:before { content: "\\eaa4" }
.codicon-bookmark:before { content: "\\eaa5" }
.codicon-debug-breakpoint-conditional-unverified:before { content: "\\eaa6" }
.codicon-debug-breakpoint-conditional:before { content: "\\eaa7" }
.codicon-debug-breakpoint-conditional-disabled:before { content: "\\eaa7" }
.codicon-debug-breakpoint-data-unverified:before { content: "\\eaa8" }
.codicon-debug-breakpoint-data:before { content: "\\eaa9" }
.codicon-debug-breakpoint-data-disabled:before { content: "\\eaa9" }
.codicon-debug-breakpoint-log-unverified:before { content: "\\eaaa" }
.codicon-debug-breakpoint-log:before { content: "\\eaab" }
.codicon-debug-breakpoint-log-disabled:before { content: "\\eaab" }
.codicon-briefcase:before { content: "\\eaac" }
.codicon-broadcast:before { content: "\\eaad" }
.codicon-browser:before { content: "\\eaae" }
.codicon-bug:before { content: "\\eaaf" }
.codicon-calendar:before { content: "\\eab0" }
.codicon-case-sensitive:before { content: "\\eab1" }
.codicon-check:before { content: "\\eab2" }
.codicon-checklist:before { content: "\\eab3" }
.codicon-chevron-down:before { content: "\\eab4" }
.codicon-chevron-left:before { content: "\\eab5" }
.codicon-chevron-right:before { content: "\\eab6" }
.codicon-chevron-up:before { content: "\\eab7" }
.codicon-chrome-close:before { content: "\\eab8" }
.codicon-chrome-maximize:before { content: "\\eab9" }
.codicon-chrome-minimize:before { content: "\\eaba" }
.codicon-chrome-restore:before { content: "\\eabb" }
.codicon-circle-outline:before { content: "\\eabc" }
.codicon-circle:before { content: "\\eabc" }
.codicon-debug-breakpoint-unverified:before { content: "\\eabc" }
.codicon-terminal-decoration-incomplete:before { content: "\\eabc" }
.codicon-circle-slash:before { content: "\\eabd" }
.codicon-circuit-board:before { content: "\\eabe" }
.codicon-clear-all:before { content: "\\eabf" }
.codicon-clippy:before { content: "\\eac0" }
.codicon-close-all:before { content: "\\eac1" }
.codicon-cloud-download:before { content: "\\eac2" }
.codicon-cloud-upload:before { content: "\\eac3" }
.codicon-code:before { content: "\\eac4" }
.codicon-collapse-all:before { content: "\\eac5" }
.codicon-color-mode:before { content: "\\eac6" }
.codicon-comment-discussion:before { content: "\\eac7" }
.codicon-credit-card:before { content: "\\eac9" }
.codicon-dash:before { content: "\\eacc" }
.codicon-dashboard:before { content: "\\eacd" }
.codicon-database:before { content: "\\eace" }
.codicon-debug-continue:before { content: "\\eacf" }
.codicon-debug-disconnect:before { content: "\\ead0" }
.codicon-debug-pause:before { content: "\\ead1" }
.codicon-debug-restart:before { content: "\\ead2" }
.codicon-debug-start:before { content: "\\ead3" }
.codicon-debug-step-into:before { content: "\\ead4" }
.codicon-debug-step-out:before { content: "\\ead5" }
.codicon-debug-step-over:before { content: "\\ead6" }
.codicon-debug-stop:before { content: "\\ead7" }
.codicon-debug:before { content: "\\ead8" }
.codicon-device-camera-video:before { content: "\\ead9" }
.codicon-device-camera:before { content: "\\eada" }
.codicon-device-mobile:before { content: "\\eadb" }
.codicon-diff-added:before { content: "\\eadc" }
.codicon-diff-ignored:before { content: "\\eadd" }
.codicon-diff-modified:before { content: "\\eade" }
.codicon-diff-removed:before { content: "\\eadf" }
.codicon-diff-renamed:before { content: "\\eae0" }
.codicon-diff:before { content: "\\eae1" }
.codicon-diff-sidebyside:before { content: "\\eae1" }
.codicon-discard:before { content: "\\eae2" }
.codicon-editor-layout:before { content: "\\eae3" }
.codicon-empty-window:before { content: "\\eae4" }
.codicon-exclude:before { content: "\\eae5" }
.codicon-extensions:before { content: "\\eae6" }
.codicon-eye-closed:before { content: "\\eae7" }
.codicon-file-binary:before { content: "\\eae8" }
.codicon-file-code:before { content: "\\eae9" }
.codicon-file-media:before { content: "\\eaea" }
.codicon-file-pdf:before { content: "\\eaeb" }
.codicon-file-submodule:before { content: "\\eaec" }
.codicon-file-symlink-directory:before { content: "\\eaed" }
.codicon-file-symlink-file:before { content: "\\eaee" }
.codicon-file-zip:before { content: "\\eaef" }
.codicon-files:before { content: "\\eaf0" }
.codicon-filter:before { content: "\\eaf1" }
.codicon-flame:before { content: "\\eaf2" }
.codicon-fold-down:before { content: "\\eaf3" }
.codicon-fold-up:before { content: "\\eaf4" }
.codicon-fold:before { content: "\\eaf5" }
.codicon-folder-active:before { content: "\\eaf6" }
.codicon-folder-opened:before { content: "\\eaf7" }
.codicon-gear:before { content: "\\eaf8" }
.codicon-gift:before { content: "\\eaf9" }
.codicon-gist-secret:before { content: "\\eafa" }
.codicon-gist:before { content: "\\eafb" }
.codicon-git-commit:before { content: "\\eafc" }
.codicon-git-compare:before { content: "\\eafd" }
.codicon-compare-changes:before { content: "\\eafd" }
.codicon-git-merge:before { content: "\\eafe" }
.codicon-github-action:before { content: "\\eaff" }
.codicon-github-alt:before { content: "\\eb00" }
.codicon-globe:before { content: "\\eb01" }
.codicon-grabber:before { content: "\\eb02" }
.codicon-graph:before { content: "\\eb03" }
.codicon-gripper:before { content: "\\eb04" }
.codicon-heart:before { content: "\\eb05" }
.codicon-home:before { content: "\\eb06" }
.codicon-horizontal-rule:before { content: "\\eb07" }
.codicon-hubot:before { content: "\\eb08" }
.codicon-inbox:before { content: "\\eb09" }
.codicon-issue-reopened:before { content: "\\eb0b" }
.codicon-issues:before { content: "\\eb0c" }
.codicon-italic:before { content: "\\eb0d" }
.codicon-jersey:before { content: "\\eb0e" }
.codicon-json:before { content: "\\eb0f" }
.codicon-bracket:before { content: "\\eb0f" }
.codicon-kebab-vertical:before { content: "\\eb10" }
.codicon-key:before { content: "\\eb11" }
.codicon-law:before { content: "\\eb12" }
.codicon-lightbulb-autofix:before { content: "\\eb13" }
.codicon-link-external:before { content: "\\eb14" }
.codicon-link:before { content: "\\eb15" }
.codicon-list-ordered:before { content: "\\eb16" }
.codicon-list-unordered:before { content: "\\eb17" }
.codicon-live-share:before { content: "\\eb18" }
.codicon-loading:before { content: "\\eb19" }
.codicon-location:before { content: "\\eb1a" }
.codicon-mail-read:before { content: "\\eb1b" }
.codicon-mail:before { content: "\\eb1c" }
.codicon-markdown:before { content: "\\eb1d" }
.codicon-megaphone:before { content: "\\eb1e" }
.codicon-mention:before { content: "\\eb1f" }
.codicon-milestone:before { content: "\\eb20" }
.codicon-git-pull-request-milestone:before { content: "\\eb20" }
.codicon-mortar-board:before { content: "\\eb21" }
.codicon-move:before { content: "\\eb22" }
.codicon-multiple-windows:before { content: "\\eb23" }
.codicon-mute:before { content: "\\eb24" }
.codicon-no-newline:before { content: "\\eb25" }
.codicon-note:before { content: "\\eb26" }
.codicon-octoface:before { content: "\\eb27" }
.codicon-open-preview:before { content: "\\eb28" }
.codicon-package:before { content: "\\eb29" }
.codicon-paintcan:before { content: "\\eb2a" }
.codicon-pin:before { content: "\\eb2b" }
.codicon-play:before { content: "\\eb2c" }
.codicon-run:before { content: "\\eb2c" }
.codicon-plug:before { content: "\\eb2d" }
.codicon-preserve-case:before { content: "\\eb2e" }
.codicon-preview:before { content: "\\eb2f" }
.codicon-project:before { content: "\\eb30" }
.codicon-pulse:before { content: "\\eb31" }
.codicon-question:before { content: "\\eb32" }
.codicon-quote:before { content: "\\eb33" }
.codicon-radio-tower:before { content: "\\eb34" }
.codicon-reactions:before { content: "\\eb35" }
.codicon-references:before { content: "\\eb36" }
.codicon-refresh:before { content: "\\eb37" }
.codicon-regex:before { content: "\\eb38" }
.codicon-remote-explorer:before { content: "\\eb39" }
.codicon-remote:before { content: "\\eb3a" }
.codicon-remove:before { content: "\\eb3b" }
.codicon-replace-all:before { content: "\\eb3c" }
.codicon-replace:before { content: "\\eb3d" }
.codicon-repo-clone:before { content: "\\eb3e" }
.codicon-repo-force-push:before { content: "\\eb3f" }
.codicon-repo-pull:before { content: "\\eb40" }
.codicon-repo-push:before { content: "\\eb41" }
.codicon-report:before { content: "\\eb42" }
.codicon-request-changes:before { content: "\\eb43" }
.codicon-rocket:before { content: "\\eb44" }
.codicon-root-folder-opened:before { content: "\\eb45" }
.codicon-root-folder:before { content: "\\eb46" }
.codicon-rss:before { content: "\\eb47" }
.codicon-ruby:before { content: "\\eb48" }
.codicon-save-all:before { content: "\\eb49" }
.codicon-save-as:before { content: "\\eb4a" }
.codicon-save:before { content: "\\eb4b" }
.codicon-screen-full:before { content: "\\eb4c" }
.codicon-screen-normal:before { content: "\\eb4d" }
.codicon-search-stop:before { content: "\\eb4e" }
.codicon-server:before { content: "\\eb50" }
.codicon-settings-gear:before { content: "\\eb51" }
.codicon-settings:before { content: "\\eb52" }
.codicon-shield:before { content: "\\eb53" }
.codicon-smiley:before { content: "\\eb54" }
.codicon-sort-precedence:before { content: "\\eb55" }
.codicon-split-horizontal:before { content: "\\eb56" }
.codicon-split-vertical:before { content: "\\eb57" }
.codicon-squirrel:before { content: "\\eb58" }
.codicon-star-full:before { content: "\\eb59" }
.codicon-star-half:before { content: "\\eb5a" }
.codicon-symbol-class:before { content: "\\eb5b" }
.codicon-symbol-color:before { content: "\\eb5c" }
.codicon-symbol-constant:before { content: "\\eb5d" }
.codicon-symbol-enum-member:before { content: "\\eb5e" }
.codicon-symbol-field:before { content: "\\eb5f" }
.codicon-symbol-file:before { content: "\\eb60" }
.codicon-symbol-interface:before { content: "\\eb61" }
.codicon-symbol-keyword:before { content: "\\eb62" }
.codicon-symbol-misc:before { content: "\\eb63" }
.codicon-symbol-operator:before { content: "\\eb64" }
.codicon-symbol-property:before { content: "\\eb65" }
.codicon-wrench:before { content: "\\eb65" }
.codicon-wrench-subaction:before { content: "\\eb65" }
.codicon-symbol-snippet:before { content: "\\eb66" }
.codicon-tasklist:before { content: "\\eb67" }
.codicon-telescope:before { content: "\\eb68" }
.codicon-text-size:before { content: "\\eb69" }
.codicon-three-bars:before { content: "\\eb6a" }
.codicon-thumbsdown:before { content: "\\eb6b" }
.codicon-thumbsup:before { content: "\\eb6c" }
.codicon-tools:before { content: "\\eb6d" }
.codicon-triangle-down:before { content: "\\eb6e" }
.codicon-triangle-left:before { content: "\\eb6f" }
.codicon-triangle-right:before { content: "\\eb70" }
.codicon-triangle-up:before { content: "\\eb71" }
.codicon-twitter:before { content: "\\eb72" }
.codicon-unfold:before { content: "\\eb73" }
.codicon-unlock:before { content: "\\eb74" }
.codicon-unmute:before { content: "\\eb75" }
.codicon-unverified:before { content: "\\eb76" }
.codicon-verified:before { content: "\\eb77" }
.codicon-versions:before { content: "\\eb78" }
.codicon-vm-active:before { content: "\\eb79" }
.codicon-vm-outline:before { content: "\\eb7a" }
.codicon-vm-running:before { content: "\\eb7b" }
.codicon-watch:before { content: "\\eb7c" }
.codicon-whitespace:before { content: "\\eb7d" }
.codicon-whole-word:before { content: "\\eb7e" }
.codicon-window:before { content: "\\eb7f" }
.codicon-word-wrap:before { content: "\\eb80" }
.codicon-zoom-in:before { content: "\\eb81" }
.codicon-zoom-out:before { content: "\\eb82" }
.codicon-list-filter:before { content: "\\eb83" }
.codicon-list-flat:before { content: "\\eb84" }
.codicon-list-selection:before { content: "\\eb85" }
.codicon-selection:before { content: "\\eb85" }
.codicon-list-tree:before { content: "\\eb86" }
.codicon-debug-breakpoint-function-unverified:before { content: "\\eb87" }
.codicon-debug-breakpoint-function:before { content: "\\eb88" }
.codicon-debug-breakpoint-function-disabled:before { content: "\\eb88" }
.codicon-debug-stackframe-active:before { content: "\\eb89" }
.codicon-circle-small-filled:before { content: "\\eb8a" }
.codicon-debug-stackframe-dot:before { content: "\\eb8a" }
.codicon-terminal-decoration-mark:before { content: "\\eb8a" }
.codicon-debug-stackframe:before { content: "\\eb8b" }
.codicon-debug-stackframe-focused:before { content: "\\eb8b" }
.codicon-debug-breakpoint-unsupported:before { content: "\\eb8c" }
.codicon-symbol-string:before { content: "\\eb8d" }
.codicon-debug-reverse-continue:before { content: "\\eb8e" }
.codicon-debug-step-back:before { content: "\\eb8f" }
.codicon-debug-restart-frame:before { content: "\\eb90" }
.codicon-debug-alt:before { content: "\\eb91" }
.codicon-call-incoming:before { content: "\\eb92" }
.codicon-call-outgoing:before { content: "\\eb93" }
.codicon-menu:before { content: "\\eb94" }
.codicon-expand-all:before { content: "\\eb95" }
.codicon-feedback:before { content: "\\eb96" }
.codicon-git-pull-request-reviewer:before { content: "\\eb96" }
.codicon-group-by-ref-type:before { content: "\\eb97" }
.codicon-ungroup-by-ref-type:before { content: "\\eb98" }
.codicon-account:before { content: "\\eb99" }
.codicon-git-pull-request-assignee:before { content: "\\eb99" }
.codicon-bell-dot:before { content: "\\eb9a" }
.codicon-debug-console:before { content: "\\eb9b" }
.codicon-library:before { content: "\\eb9c" }
.codicon-output:before { content: "\\eb9d" }
.codicon-run-all:before { content: "\\eb9e" }
.codicon-sync-ignored:before { content: "\\eb9f" }
.codicon-pinned:before { content: "\\eba0" }
.codicon-github-inverted:before { content: "\\eba1" }
.codicon-server-process:before { content: "\\eba2" }
.codicon-server-environment:before { content: "\\eba3" }
.codicon-pass:before { content: "\\eba4" }
.codicon-issue-closed:before { content: "\\eba4" }
.codicon-stop-circle:before { content: "\\eba5" }
.codicon-play-circle:before { content: "\\eba6" }
.codicon-record:before { content: "\\eba7" }
.codicon-debug-alt-small:before { content: "\\eba8" }
.codicon-vm-connect:before { content: "\\eba9" }
.codicon-cloud:before { content: "\\ebaa" }
.codicon-merge:before { content: "\\ebab" }
.codicon-export:before { content: "\\ebac" }
.codicon-graph-left:before { content: "\\ebad" }
.codicon-magnet:before { content: "\\ebae" }
.codicon-notebook:before { content: "\\ebaf" }
.codicon-redo:before { content: "\\ebb0" }
.codicon-check-all:before { content: "\\ebb1" }
.codicon-pinned-dirty:before { content: "\\ebb2" }
.codicon-pass-filled:before { content: "\\ebb3" }
.codicon-circle-large-filled:before { content: "\\ebb4" }
.codicon-circle-large:before { content: "\\ebb5" }
.codicon-circle-large-outline:before { content: "\\ebb5" }
.codicon-combine:before { content: "\\ebb6" }
.codicon-gather:before { content: "\\ebb6" }
.codicon-table:before { content: "\\ebb7" }
.codicon-variable-group:before { content: "\\ebb8" }
.codicon-type-hierarchy:before { content: "\\ebb9" }
.codicon-type-hierarchy-sub:before { content: "\\ebba" }
.codicon-type-hierarchy-super:before { content: "\\ebbb" }
.codicon-git-pull-request-create:before { content: "\\ebbc" }
.codicon-run-above:before { content: "\\ebbd" }
.codicon-run-below:before { content: "\\ebbe" }
.codicon-notebook-template:before { content: "\\ebbf" }
.codicon-debug-rerun:before { content: "\\ebc0" }
.codicon-workspace-trusted:before { content: "\\ebc1" }
.codicon-workspace-untrusted:before { content: "\\ebc2" }
.codicon-workspace-unknown:before { content: "\\ebc3" }
.codicon-terminal-cmd:before { content: "\\ebc4" }
.codicon-terminal-debian:before { content: "\\ebc5" }
.codicon-terminal-linux:before { content: "\\ebc6" }
.codicon-terminal-powershell:before { content: "\\ebc7" }
.codicon-terminal-tmux:before { content: "\\ebc8" }
.codicon-terminal-ubuntu:before { content: "\\ebc9" }
.codicon-terminal-bash:before { content: "\\ebca" }
.codicon-arrow-swap:before { content: "\\ebcb" }
.codicon-copy:before { content: "\\ebcc" }
.codicon-person-add:before { content: "\\ebcd" }
.codicon-filter-filled:before { content: "\\ebce" }
.codicon-wand:before { content: "\\ebcf" }
.codicon-debug-line-by-line:before { content: "\\ebd0" }
.codicon-inspect:before { content: "\\ebd1" }
.codicon-layers:before { content: "\\ebd2" }
.codicon-layers-dot:before { content: "\\ebd3" }
.codicon-layers-active:before { content: "\\ebd4" }
.codicon-compass:before { content: "\\ebd5" }
.codicon-compass-dot:before { content: "\\ebd6" }
.codicon-compass-active:before { content: "\\ebd7" }
.codicon-azure:before { content: "\\ebd8" }
.codicon-issue-draft:before { content: "\\ebd9" }
.codicon-git-pull-request-closed:before { content: "\\ebda" }
.codicon-git-pull-request-draft:before { content: "\\ebdb" }
.codicon-debug-all:before { content: "\\ebdc" }
.codicon-debug-coverage:before { content: "\\ebdd" }
.codicon-run-errors:before { content: "\\ebde" }
.codicon-folder-library:before { content: "\\ebdf" }
.codicon-debug-continue-small:before { content: "\\ebe0" }
.codicon-beaker-stop:before { content: "\\ebe1" }
.codicon-graph-line:before { content: "\\ebe2" }
.codicon-graph-scatter:before { content: "\\ebe3" }
.codicon-pie-chart:before { content: "\\ebe4" }
.codicon-bracket-dot:before { content: "\\ebe5" }
.codicon-bracket-error:before { content: "\\ebe6" }
.codicon-lock-small:before { content: "\\ebe7" }
.codicon-azure-devops:before { content: "\\ebe8" }
.codicon-verified-filled:before { content: "\\ebe9" }
.codicon-newline:before { content: "\\ebea" }
.codicon-layout:before { content: "\\ebeb" }
.codicon-layout-activitybar-left:before { content: "\\ebec" }
.codicon-layout-activitybar-right:before { content: "\\ebed" }
.codicon-layout-panel-left:before { content: "\\ebee" }
.codicon-layout-panel-center:before { content: "\\ebef" }
.codicon-layout-panel-justify:before { content: "\\ebf0" }
.codicon-layout-panel-right:before { content: "\\ebf1" }
.codicon-layout-panel:before { content: "\\ebf2" }
.codicon-layout-sidebar-left:before { content: "\\ebf3" }
.codicon-layout-sidebar-right:before { content: "\\ebf4" }
.codicon-layout-statusbar:before { content: "\\ebf5" }
.codicon-layout-menubar:before { content: "\\ebf6" }
.codicon-layout-centered:before { content: "\\ebf7" }
.codicon-target:before { content: "\\ebf8" }
.codicon-indent:before { content: "\\ebf9" }
.codicon-record-small:before { content: "\\ebfa" }
.codicon-error-small:before { content: "\\ebfb" }
.codicon-terminal-decoration-error:before { content: "\\ebfb" }
.codicon-arrow-circle-down:before { content: "\\ebfc" }
.codicon-arrow-circle-left:before { content: "\\ebfd" }
.codicon-arrow-circle-right:before { content: "\\ebfe" }
.codicon-arrow-circle-up:before { content: "\\ebff" }
.codicon-layout-sidebar-right-off:before { content: "\\ec00" }
.codicon-layout-panel-off:before { content: "\\ec01" }
.codicon-layout-sidebar-left-off:before { content: "\\ec02" }
.codicon-blank:before { content: "\\ec03" }
.codicon-heart-filled:before { content: "\\ec04" }
.codicon-map:before { content: "\\ec05" }
.codicon-map-horizontal:before { content: "\\ec05" }
.codicon-fold-horizontal:before { content: "\\ec05" }
.codicon-map-filled:before { content: "\\ec06" }
.codicon-map-horizontal-filled:before { content: "\\ec06" }
.codicon-fold-horizontal-filled:before { content: "\\ec06" }
.codicon-circle-small:before { content: "\\ec07" }
.codicon-bell-slash:before { content: "\\ec08" }
.codicon-bell-slash-dot:before { content: "\\ec09" }
.codicon-comment-unresolved:before { content: "\\ec0a" }
.codicon-git-pull-request-go-to-changes:before { content: "\\ec0b" }
.codicon-git-pull-request-new-changes:before { content: "\\ec0c" }
.codicon-search-fuzzy:before { content: "\\ec0d" }
.codicon-comment-draft:before { content: "\\ec0e" }
.codicon-send:before { content: "\\ec0f" }
.codicon-sparkle:before { content: "\\ec10" }
.codicon-insert:before { content: "\\ec11" }
.codicon-mic:before { content: "\\ec12" }
.codicon-thumbsdown-filled:before { content: "\\ec13" }
.codicon-thumbsup-filled:before { content: "\\ec14" }
.codicon-coffee:before { content: "\\ec15" }
.codicon-snake:before { content: "\\ec16" }
.codicon-game:before { content: "\\ec17" }
.codicon-vr:before { content: "\\ec18" }
.codicon-chip:before { content: "\\ec19" }
.codicon-piano:before { content: "\\ec1a" }
.codicon-music:before { content: "\\ec1b" }
.codicon-mic-filled:before { content: "\\ec1c" }
.codicon-repo-fetch:before { content: "\\ec1d" }
.codicon-copilot:before { content: "\\ec1e" }
.codicon-lightbulb-sparkle:before { content: "\\ec1f" }
.codicon-robot:before { content: "\\ec20" }
.codicon-sparkle-filled:before { content: "\\ec21" }
.codicon-diff-single:before { content: "\\ec22" }
.codicon-diff-multiple:before { content: "\\ec23" }
.codicon-surround-with:before { content: "\\ec24" }
.codicon-share:before { content: "\\ec25" }
.codicon-git-stash:before { content: "\\ec26" }
.codicon-git-stash-apply:before { content: "\\ec27" }
.codicon-git-stash-pop:before { content: "\\ec28" }
.codicon-vscode:before { content: "\\ec29" }
.codicon-vscode-insiders:before { content: "\\ec2a" }
.codicon-code-oss:before { content: "\\ec2b" }
.codicon-run-coverage:before { content: "\\ec2c" }
.codicon-run-all-coverage:before { content: "\\ec2d" }
.codicon-coverage:before { content: "\\ec2e" }
.codicon-github-project:before { content: "\\ec2f" }
.codicon-map-vertical:before { content: "\\ec30" }
.codicon-fold-vertical:before { content: "\\ec30" }
.codicon-map-vertical-filled:before { content: "\\ec31" }
.codicon-fold-vertical-filled:before { content: "\\ec31" }
.codicon-go-to-search:before { content: "\\ec32" }
.codicon-percentage:before { content: "\\ec33" }
.codicon-sort-percentage:before { content: "\\ec33" }
.codicon-attach:before { content: "\\ec34" }
.codicon-go-to-editing-session:before { content: "\\ec35" }
.codicon-edit-session:before { content: "\\ec36" }
.codicon-code-review:before { content: "\\ec37" }
.codicon-copilot-warning:before { content: "\\ec38" }
.codicon-python:before { content: "\\ec39" }
.codicon-copilot-large:before { content: "\\ec3a" }
.codicon-copilot-warning-large:before { content: "\\ec3b" }
.codicon-keyboard-tab:before { content: "\\ec3c" }
.codicon-copilot-blocked:before { content: "\\ec3d" }
.codicon-copilot-not-connected:before { content: "\\ec3e" }
.codicon-flag:before { content: "\\ec3f" }
.codicon-lightbulb-empty:before { content: "\\ec40" }
.codicon-symbol-method-arrow:before { content: "\\ec41" }
.codicon-copilot-unavailable:before { content: "\\ec42" }
.codicon-repo-pinned:before { content: "\\ec43" }
.codicon-keyboard-tab-above:before { content: "\\ec44" }
.codicon-keyboard-tab-below:before { content: "\\ec45" }
.codicon-git-pull-request-done:before { content: "\\ec46" }
.codicon-mcp:before { content: "\\ec47" }
.codicon-extensions-large:before { content: "\\ec48" }
.codicon-layout-panel-dock:before { content: "\\ec49" }
.codicon-layout-sidebar-left-dock:before { content: "\\ec4a" }
.codicon-layout-sidebar-right-dock:before { content: "\\ec4b" }
.codicon-copilot-in-progress:before { content: "\\ec4c" }
.codicon-copilot-error:before { content: "\\ec4d" }
.codicon-copilot-success:before { content: "\\ec4e" }
.codicon-chat-sparkle:before { content: "\\ec4f" }
.codicon-search-sparkle:before { content: "\\ec50" }
.codicon-edit-sparkle:before { content: "\\ec51" }
.codicon-copilot-snooze:before { content: "\\ec52" }
.codicon-send-to-remote-agent:before { content: "\\ec53" }
.codicon-comment-discussion-sparkle:before { content: "\\ec54" }
.codicon-chat-sparkle-warning:before { content: "\\ec55" }
.codicon-chat-sparkle-error:before { content: "\\ec56" }
.codicon-collection:before { content: "\\ec57" }
.codicon-new-collection:before { content: "\\ec58" }
.codicon-thinking:before { content: "\\ec59" }
.codicon-build:before { content: "\\ec5a" }
.codicon-comment-discussion-quote:before { content: "\\ec5b" }
.codicon-cursor:before { content: "\\ec5c" }
.codicon-eraser:before { content: "\\ec5d" }
.codicon-file-text:before { content: "\\ec5e" }
.codicon-quotes:before { content: "\\ec60" }
.codicon-rename:before { content: "\\ec61" }
.codicon-run-with-deps:before { content: "\\ec62" }
.codicon-debug-connected:before { content: "\\ec63" }
.codicon-strikethrough:before { content: "\\ec64" }
.codicon-open-in-product:before { content: "\\ec65" }
.codicon-index-zero:before { content: "\\ec66" }
.codicon-agent:before { content: "\\ec67" }
.codicon-edit-code:before { content: "\\ec68" }
.codicon-repo-selected:before { content: "\\ec69" }
.codicon-skip:before { content: "\\ec6a" }
.codicon-merge-into:before { content: "\\ec6b" }
.codicon-git-branch-changes:before { content: "\\ec6c" }
.codicon-git-branch-staged-changes:before { content: "\\ec6d" }
.codicon-git-branch-conflicts:before { content: "\\ec6e" }
.codicon-git-branch:before { content: "\\ec6f" }
.codicon-git-branch-create:before { content: "\\ec6f" }
.codicon-git-branch-delete:before { content: "\\ec6f" }
.codicon-search-large:before { content: "\\ec70" }
.codicon-terminal-git-bash:before { content: "\\ec71" }
.codicon-window-active:before { content: "\\ec72" }
.codicon-forward:before { content: "\\ec73" }
.codicon-download:before { content: "\\ec74" }
.codicon-clockface:before { content: "\\ec75" }
.codicon-unarchive:before { content: "\\ec76" }
.codicon-session-in-progress:before { content: "\\ec77" }
.codicon-collection-small:before { content: "\\ec78" }
.codicon-vm-small:before { content: "\\ec79" }
.codicon-cloud-small:before { content: "\\ec7a" }
.codicon-add-small:before { content: "\\ec7b" }
.codicon-remove-small:before { content: "\\ec7c" }
.codicon-worktree-small:before { content: "\\ec7d" }
.codicon-worktree:before { content: "\\ec7e" }
.codicon-screen-cut:before { content: "\\ec7f" }
.codicon-ask:before { content: "\\ec80" }
.codicon-openai:before { content: "\\ec81" }
.codicon-claude:before { content: "\\ec82" }
.codicon-open-in-window:before { content: "\\ec83" }
.codicon-new-session:before { content: "\\ec84" }
.codicon-terminal-secure:before { content: "\\ec85" }
.codicon-chat-import:before { content: "\\ec86" }
.codicon-chat-export:before { content: "\\ec87" }
.codicon-share-window:before { content: "\\ec88" }
.codicon-circle-slash-compact:before { content: "\\ec89" }
.codicon-copilot-compact:before { content: "\\ec8a" }
.codicon-folder-opened-compact:before { content: "\\ec8b" }
.codicon-folder-compact:before { content: "\\ec8c" }
.codicon-gear-compact:before { content: "\\ec8d" }
.codicon-git-branch-compact:before { content: "\\ec8e" }
.codicon-library-compact:before { content: "\\ec8f" }
.codicon-record-keys-compact:before { content: "\\ec90" }
.codicon-remote-compact:before { content: "\\ec91" }
.codicon-repo-forked-compact:before { content: "\\ec92" }
.codicon-repo-compact:before { content: "\\ec93" }
.codicon-shield-compact:before { content: "\\ec94" }
.codicon-sparkle-compact:before { content: "\\ec95" }
.codicon-symbol-color-compact:before { content: "\\ec96" }
.codicon-window-compact:before { content: "\\ec97" }
.codicon-error-compact:before { content: "\\ec98" }
.codicon-warning-compact:before { content: "\\ec99" }
.codicon-pass-compact:before { content: "\\ec9a" }
.codicon-important:before { content: "\\ec9b" }
.codicon-important-compact:before { content: "\\ec9c" }
.codicon-rocket-compact:before { content: "\\ec9d" }
.codicon-unpin:before { content: "\\ec9e" }
.codicon-add-compact:before { content: "\\ec9f" }
.codicon-attach-compact:before { content: "\\eca0" }
.codicon-beaker-compact:before { content: "\\eca1" }
.codicon-check-compact:before { content: "\\eca2" }
.codicon-checklist-compact:before { content: "\\eca3" }
.codicon-chevron-down-compact:before { content: "\\eca4" }
.codicon-chevron-left-compact:before { content: "\\eca5" }
.codicon-chevron-right-compact:before { content: "\\eca6" }
.codicon-chevron-up-compact:before { content: "\\eca7" }
.codicon-circle-filled-compact:before { content: "\\eca8" }
.codicon-circle-small-filled-compact:before { content: "\\eca9" }
.codicon-close-compact:before { content: "\\ecaa" }
.codicon-collapse-all-compact:before { content: "\\ecab" }
.codicon-comment-compact:before { content: "\\ecac" }
.codicon-comment-unresolved-compact:before { content: "\\ecad" }
.codicon-debug-connected-compact:before { content: "\\ecae" }
.codicon-debug-disconnect-compact:before { content: "\\ecaf" }
.codicon-edit-compact:before { content: "\\ecb0" }
.codicon-file-media-compact:before { content: "\\ecb1" }
.codicon-git-fetch:before { content: "\\ecb2" }
.codicon-lightbulb-compact:before { content: "\\ecb3" }
.codicon-loading-compact:before { content: "\\ecb4" }
.codicon-pass-filled-compact:before { content: "\\ecb5" }
.codicon-project-compact:before { content: "\\ecb6" }
.codicon-refresh-compact:before { content: "\\ecb7" }
.codicon-search-compact:before { content: "\\ecb8" }
.codicon-session-in-progress-compact:before { content: "\\ecb9" }
.codicon-sync-compact:before { content: "\\ecba" }
.codicon-terminal-compact:before { content: "\\ecbb" }
.codicon-vm-pending:before { content: "\\ecbc" }
.codicon-worktree-compact:before { content: "\\ecbd" }
.codicon-developer-tools:before { content: "\\ecbe" }
.codicon-cloud-compact:before { content: "\\ecbf" }
.codicon-agent-compact:before { content: "\\ecc0" }
.codicon-ask-compact:before { content: "\\ecc1" }
.codicon-settings-compact:before { content: "\\ecc2" }
.codicon-vm-compact:before { content: "\\ecc3" }
.codicon-run-compact:before { content: "\\ecc4" }
.codicon-git-pull-request-comment:before { content: "\\ecc5" }
.codicon-git-pull-request-error:before { content: "\\ecc6" }
.codicon-right-panel-hide:before { content: "\\ecc7" }
.codicon-right-panel-show:before { content: "\\ecc8" }
.codicon-vscode-insiders-outline:before { content: "\\ecc9" }
.codicon-vscode-outline:before { content: "\\ecca" }
.codicon-voice-mode:before { content: "\\eccb" }
.codicon-voice-mode-compact:before { content: "\\eccc" }
.codicon-mic-download:before { content: "\\eccd" }
.codicon-mic-download-compact:before { content: "\\ecce" }
.codicon-voice-mode-download:before { content: "\\eccf" }
.codicon-voice-mode-download-compact:before { content: "\\ecd0" }
.codicon-google-gemini:before { content: "\\ecd1" }
.codicon-kimi:before { content: "\\ecd2" }
.codicon-microsoft:before { content: "\\ecd3" }
.codicon-fish1-happy:before { content: "\\ecd4" }
.codicon-fish1-neutral:before { content: "\\ecd5" }
.codicon-fish1-sad:before { content: "\\ecd6" }
.codicon-fish1-very-sad:before { content: "\\ecd7" }
.codicon-fish2-happy:before { content: "\\ecd8" }
.codicon-fish2-neutral:before { content: "\\ecd9" }
.codicon-fish2-sad:before { content: "\\ecda" }
.codicon-fish2-very-sad:before { content: "\\ecdb" }
.codicon-fish3-happy:before { content: "\\ecdc" }
.codicon-fish3-neutral:before { content: "\\ecdd" }
.codicon-fish3-sad:before { content: "\\ecde" }
.codicon-fish3-very-sad:before { content: "\\ecdf" }
.codicon-fish4-happy:before { content: "\\ece0" }
.codicon-fish4-neutral:before { content: "\\ece1" }
.codicon-fish4-sad:before { content: "\\ece2" }
.codicon-fish4-very-sad:before { content: "\\ece3" }
.codicon-person-voice:before { content: "\\ece4" }
.codicon-person-voice-compact:before { content: "\\ece5" }
.codicon-person-voice-filled:before { content: "\\ece6" }
.codicon-person-voice-filled-compact:before { content: "\\ece7" }
`;var Bd=["claude","codex","opencode","agy"];var Na=e=>typeof e=="number"&&Number.isFinite(e),De=e=>typeof e=="boolean",H=e=>t=>typeof t=="string"&&t.length<=e,Dt=e=>t=>typeof t=="string"&&e.test(t),M=e=>t=>t===void 0||e(t),Zn=(...e)=>t=>typeof t=="string"&&e.includes(t),Jm=e=>typeof e=="object"&&e!==null&&!Array.isArray(e),Kn=e=>t=>Jm(t)&&Object.entries(e).every(([n,o])=>o(t[n])),st=(e,t=1e5)=>n=>Array.isArray(n)&&n.length<=t&&n.every(e);var Ky=1024*1024,$m=64*1024*1024,Fm=["element","screenshot","recording","errors","network","page","report","css","measure","color","text"],wi=/^\d{8}-\d{6}-[0-9a-f]{6}$/,Si=/^[\w-]{1,40}\.[a-z0-9]{1,5}$/;function Eo(e){return e.vscode||e.agentmux}var Jn=Dt(/^[\w.-]{1,64}$/),Dl=H($m),Wm=H(4096),Jy={auth:{token:H(128),role:Zn("browser","vscode"),origin:M(H(256))}},we=Dt(/^[\w-]{1,64}$/),bt=H(4096),qd=Zn(...Fm),Ti=Dt(/^[A-Za-z0-9+/]*={0,2}$/),Im=Kn({kind:qd,title:H(300),detail:M(H(1e3)),text:M(H(5e6)),group:M(Jn),groupIndex:M(Na),image:M(Ti),thumb:M(e=>typeof e=="string"&&e.length<=4e5&&Ti(e))}),jd=Kn({id:H(200),kind:Zn("tmux","terminal","chat"),label:H(100),detail:H(300)}),wo=st(Dt(wi),60),$y={link:{data:Dl},ping:{},"projects.get":{req:we,url:M(H(4096))},"capture.save":{req:we,project:bt,url:M(H(4096)),browser:M(H(100)),captures:st(Im,60),send:M(H(200))},"item.send":{req:we,project:bt,ids:wo,target:M(H(200)),open:M(De)},"items.move":{req:we,project:bt,ids:wo,to:bt},"items.get":{req:we,project:bt},"item.thumb":{req:we,project:bt,id:Dt(wi)},"item.remove":{req:we,project:bt,ids:wo},"item.restore":{req:we,project:bt,ids:wo},"project.pin":{req:we,project:bt,pinned:De}},Pm=Kn({path:bt,name:H(300),vscode:De,agentmux:De,saved:De,pinned:De,targets:M(st(jd,50)),defaultTarget:M(H(200)),harnesses:M(st(Zn(...Bd),10)),inbox:M(De)}),ep=Kn({v:e=>e===1,id:Dt(wi),kind:qd,title:H(300),detail:M(H(1e3)),url:M(H(4096)),time:Na,group:M(Jn),groupIndex:M(Na),key:M(H(200)),source:Zn("browser","vscode"),browser:M(H(100)),preview:M(H(1e3)),files:Kn({file:M(Dt(Si)),text:M(Dt(Si)),thumb:M(Dt(Si))}),sentTo:st(H(200),50)}),Fy={link:{data:Dl},status:{vscode:De,peer:M(H(200)),features:M(st(H(40),50))},relink:{},pong:{},projects:{req:we,projects:st(Pm,500),suggested:M(bt)},"capture.saved":{req:we,ok:De,ids:M(wo),error:M(H(1e3)),sentTo:M(H(200))},"item.sent":{req:we,ok:De,sentTo:M(H(200)),error:M(H(1e3))},items:{req:we,ok:De,items:st(ep,500),error:M(H(1e3))},thumb:{req:we,data:M(Ti),mimeType:M(Zn("image/jpeg","image/png"))},done:{req:we,ok:De,error:M(H(1e3))}},Wy={window:{id:Jn,name:H(200),folders:st(Wm,50),focusedAt:Na,targets:M(st(jd,50))},link:{browser:Jn,data:Dl},shutdown:{},ping:{},"run.sent":{req:we,ok:De,sentTo:M(H(200)),error:M(H(1e3))}},tp=Kn({id:Jn,name:H(100),origin:H(256)}),Iy={welcome:{build:H(100),leader:De},leader:{leader:De},browsers:{browsers:st(tp,50)},link:{browser:Jn,data:Dl},gone:{browser:Jn},pong:{},"run.send":{req:we,project:bt,ids:wo,target:H(200)}};var Ei={element:"inspect",screenshot:"device-camera",recording:"record",errors:"error",network:"globe",page:"browser",report:"checklist",css:"symbol-color",measure:"symbol-ruler",color:"symbol-color",text:"note"},zi={element:"Element",screenshot:"Screenshot",recording:"Recording",errors:"Console errors",network:"Failed requests",page:"Page context",report:"Report",css:"CSS changes",measure:"Measurements",color:"Color",text:"Text"};function Ni(e,t=Date.now()){let n=Math.max(0,Math.round((t-e)/1e3));if(n<45)return"just now";let o=Math.round(n/60);if(o<60)return`${o} min ago`;let a=Math.round(o/60);return a<24?`${a} h ago`:new Date(e).toLocaleDateString()}function Yd(e){let t=[],n=new Set;for(let o of e){if(!o.group){t.push({kind:"item",key:o.id,item:o});continue}if(n.has(o.group))continue;n.add(o.group);let a=e.filter(l=>l.group===o.group).sort((l,c)=>(l.groupIndex??0)-(c.groupIndex??0)||l.time-c.time);t.push(a.length>1?{kind:"group",key:`group:${o.group}`,group:o.group,items:a}:{kind:"item",key:o.id,item:o})}return t}var Oi=e=>e.kind==="item"?[e.item.id]:e.items.map(t=>t.id);function Ld(e){if(e.every(o=>o.kind==="element"))return"Elements";let t=new Set(e.map(o=>o.title.replace(/\s+\d+\s+of\s+\d+$/,""))),[n]=t;return t.size===1&&n?n:"Screenshots"}function Vd(e){return{id:e.id,kind:e.kind,title:e.title,detail:e.detail,preview:e.preview,image:!!(e.files.thumb||e.files.file&&e.kind!=="recording"),url:e.url,time:e.time,sentTo:e.sentTo,group:e.group,groupIndex:e.groupIndex,source:e.source==="browser"?e.browser??"Browser":"VS Code"}}function Gd(e){return e.inbox?"captures without a project":[e.vscode&&"VS Code",e.agentmux&&"agentmux",!Eo(e)&&e.saved&&"saved",e.pinned&&"pinned"].filter(Boolean).join(" \xB7 ")}var Xd=`/* VS Code theme variables for hosts outside VS Code (the browser extension's pages): a dark and
   a light set that follow the system theme, matching VS Code's Dark Modern and Light Modern. */

.ink-theme {
  --vscode-font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  --vscode-font-size: 13px;
  --vscode-editor-font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
  --vscode-foreground: #cccccc;
  --vscode-descriptionForeground: #9d9d9d;
  --vscode-icon-foreground: #cccccc;
  --vscode-editor-background: #1f1f1f;
  --vscode-editorWidget-background: #202020;
  --vscode-widget-border: #313131;
  --vscode-widget-shadow: rgba(0, 0, 0, 0.36);
  --vscode-focusBorder: #0078d4;
  --vscode-button-background: #0078d4;
  --vscode-button-foreground: #ffffff;
  --vscode-button-hoverBackground: #026ec1;
  --vscode-button-border: rgba(255, 255, 255, 0.07);
  --vscode-button-secondaryBackground: #313131;
  --vscode-button-secondaryForeground: #cccccc;
  --vscode-button-secondaryHoverBackground: #3c3c3c;
  --vscode-toolbar-hoverBackground: rgba(90, 93, 94, 0.31);
  --vscode-toolbar-activeBackground: rgba(99, 102, 103, 0.31);
  --vscode-input-background: #313131;
  --vscode-input-foreground: #cccccc;
  --vscode-input-border: #3c3c3c;
  --vscode-input-placeholderForeground: #989898;
  --vscode-dropdown-background: #313131;
  --vscode-dropdown-foreground: #cccccc;
  --vscode-dropdown-border: #3c3c3c;
  --vscode-checkbox-background: #313131;
  --vscode-checkbox-border: #3c3c3c;
  --vscode-menu-background: #1f1f1f;
  --vscode-menu-foreground: #cccccc;
  --vscode-menu-selectionBackground: #0078d4;
  --vscode-menu-selectionForeground: #ffffff;
  --vscode-menu-separatorBackground: #454545;
  --vscode-menu-border: #454545;
  --vscode-notifications-background: #1f1f1f;
  --vscode-notifications-foreground: #cccccc;
  --vscode-notifications-border: #2b2b2b;
  --vscode-textLink-foreground: #4daafc;
  --vscode-errorForeground: #f85149;
  --vscode-testing-iconPassed: #73c991;
  --vscode-editorWarning-foreground: #cca700;
  --vscode-terminal-ansiBlue: #4daafc;
  --vscode-terminal-ansiGreen: #3fb950;
  --vscode-terminal-ansiYellow: #d7ba7d;
  --vscode-terminal-ansiRed: #f85149;
  --vscode-terminal-ansiMagenta: #d670d6;
  --vscode-badge-background: #616161;
  --vscode-badge-foreground: #f8f8f8;
  --vscode-keybindingLabel-background: rgba(128, 128, 128, 0.17);
  --vscode-keybindingLabel-foreground: #cccccc;
  --vscode-keybindingLabel-border: rgba(51, 51, 51, 0.6);
  color-scheme: dark;
}

@media (prefers-color-scheme: light) {
  .ink-theme {
    --vscode-foreground: #3b3b3b;
    --vscode-descriptionForeground: #6f6f6f;
    --vscode-icon-foreground: #3b3b3b;
    --vscode-editor-background: #ffffff;
    --vscode-editorWidget-background: #f8f8f8;
    --vscode-widget-border: #e5e5e5;
    --vscode-widget-shadow: rgba(0, 0, 0, 0.16);
    --vscode-focusBorder: #005fb8;
    --vscode-button-background: #005fb8;
    --vscode-button-hoverBackground: #0258a8;
    --vscode-button-border: rgba(0, 0, 0, 0.1);
    --vscode-button-secondaryBackground: #e5e5e5;
    --vscode-button-secondaryForeground: #3b3b3b;
    --vscode-button-secondaryHoverBackground: #cccccc;
    --vscode-toolbar-hoverBackground: rgba(184, 184, 184, 0.31);
    --vscode-toolbar-activeBackground: rgba(166, 166, 166, 0.31);
    --vscode-input-background: #ffffff;
    --vscode-input-foreground: #3b3b3b;
    --vscode-input-border: #cecece;
    --vscode-input-placeholderForeground: #767676;
    --vscode-dropdown-background: #ffffff;
    --vscode-dropdown-foreground: #3b3b3b;
    --vscode-dropdown-border: #cecece;
    --vscode-checkbox-background: #f8f8f8;
    --vscode-checkbox-border: #cecece;
    --vscode-menu-background: #ffffff;
    --vscode-menu-foreground: #3b3b3b;
    --vscode-menu-selectionBackground: #005fb8;
    --vscode-menu-separatorBackground: #d4d4d4;
    --vscode-menu-border: #cecece;
    --vscode-notifications-background: #ffffff;
    --vscode-notifications-foreground: #3b3b3b;
    --vscode-notifications-border: #e5e5e5;
    --vscode-textLink-foreground: #005fb8;
    --vscode-errorForeground: #b3261e;
    --vscode-testing-iconPassed: #2e7d32;
    --vscode-editorWarning-foreground: #895503;
    --vscode-terminal-ansiBlue: #005fb8;
    --vscode-terminal-ansiGreen: #1a7f37;
    --vscode-terminal-ansiYellow: #895503;
    --vscode-terminal-ansiRed: #c72e0f;
    --vscode-terminal-ansiMagenta: #a626a4;
    --vscode-badge-background: #cccccc;
    --vscode-badge-foreground: #3b3b3b;
    --vscode-keybindingLabel-foreground: #3b3b3b;
    --vscode-keybindingLabel-border: rgba(204, 204, 204, 0.4);
    color-scheme: light;
  }
}
`;var Qd=`/* The Inkspect design system: tokens and the shared components (buttons, fields, selects,
   switches, sliders, color picker, menus, toast, drawing toolbar and layer).
   Colors come from VS Code theme variables; hosts outside VS Code define them (theme.css).
   Every surface uses the tokens below, so sizes, radii and elevation stay consistent. */

:root,
:host {
  /* Shape */
  --ink-radius-sm: 4px;
  --ink-radius: 6px;
  --ink-radius-lg: 10px;
  --ink-radius-pill: 999px;
  /* Controls */
  --ink-control-sm: 24px;
  --ink-control: 28px;
  --ink-control-lg: 36px;
  /* Spacing */
  --ink-space-1: 4px;
  --ink-space-2: 8px;
  --ink-space-3: 12px;
  --ink-space-4: 16px;
  --ink-space-5: 24px;
  --ink-space-6: 32px;
  /* Type */
  --ink-font-xs: 11px;
  --ink-font-sm: 12px;
  --ink-font: var(--vscode-font-size, 13px);
  --ink-font-lg: 15px;
  --ink-font-xl: 22px;
  /* Surfaces and lines */
  --ink-surface: var(--vscode-editorWidget-background, var(--vscode-editor-background));
  /* Popups: lifted off the menu background, since many dark themes (Tokyo Night) give menus the
     sidebar's own color, a border the same near-black, and no shadow at all. */
  --ink-surface-raised: color-mix(
    in srgb,
    var(--vscode-foreground, #888) 7%,
    var(--vscode-menu-background, var(--ink-surface))
  );
  --ink-surface-sunken: color-mix(in srgb, var(--vscode-foreground, #888) 4%, transparent);
  --ink-border: var(--vscode-widget-border, rgba(128, 128, 128, 0.35));
  --ink-border-subtle: color-mix(in srgb, var(--vscode-foreground, #888) 10%, transparent);
  --ink-border-strong: color-mix(in srgb, var(--vscode-foreground, #888) 22%, transparent);
  --ink-hover: var(--vscode-toolbar-hoverBackground, rgba(128, 128, 128, 0.18));
  --ink-pressed: var(--vscode-toolbar-activeBackground, rgba(128, 128, 128, 0.26));
  /* Focus rings follow the theme's focus border; accents use the button color, which themes keep
     vivid (the focus border can be very dim). Text on tinted backgrounds uses the link color. */
  --ink-focus: var(--vscode-focusBorder, #0078d4);
  --ink-accent: var(--vscode-button-background, var(--ink-focus));
  --ink-accent-fg: var(--vscode-textLink-foreground, var(--ink-accent));
  --ink-accent-soft: color-mix(in srgb, var(--ink-accent) 20%, transparent);
  /* Secondary text, pulled toward the foreground so it stays readable in low-contrast themes. */
  --ink-muted: color-mix(
    in srgb,
    var(--vscode-descriptionForeground, #9d9d9d) 70%,
    var(--vscode-foreground, #ccc)
  );
  --ink-danger: var(--vscode-errorForeground, #f85149);
  --ink-success: var(--vscode-testing-iconPassed, #73c991);
  --ink-warning: var(--vscode-editorWarning-foreground, #cca700);
  /* The theme's own palette. Every theme defines its terminal ANSI colors, and they are its true
     hues (Tokyo Night's are #7aa2f7, #9ece6a, #e0af68, #f7768e, #bb9af7), unlike button and
     error colors, which some themes keep dim. Pulled slightly toward the foreground so they stay
     readable as text on both light and dark backgrounds. */
  --ink-blue: color-mix(
    in srgb,
    var(--vscode-terminal-ansiBlue, #3b8eea) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-green: color-mix(
    in srgb,
    var(--vscode-terminal-ansiGreen, #23d18b) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-yellow: color-mix(
    in srgb,
    var(--vscode-terminal-ansiYellow, #e5e510) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-red: color-mix(
    in srgb,
    var(--vscode-terminal-ansiRed, #f14c4c) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-magenta: color-mix(
    in srgb,
    var(--vscode-terminal-ansiMagenta, #d670d6) 88%,
    var(--vscode-foreground, #888)
  );
  /* Elevation */
  /* Half the theme's widget shadow, half plain black: some themes make theirs transparent. */
  --ink-shadow-color: color-mix(
    in srgb,
    var(--vscode-widget-shadow, rgba(0, 0, 0, 0.3)) 50%,
    rgba(0, 0, 0, 0.5)
  );
  --ink-shadow-sm: 0 1px 3px var(--ink-shadow-color);
  --ink-shadow: 0 6px 20px var(--ink-shadow-color), 0 1px 4px var(--ink-shadow-color);
  --ink-shadow-lg: 0 12px 32px var(--ink-shadow-color), 0 2px 8px var(--ink-shadow-color);
  /* Motion */
  --ink-ease: cubic-bezier(0.2, 0, 0, 1);
  --ink-fast: 90ms;
  --ink-normal: 160ms;
}

/* Focus ------------------------------------------------------------------------------------ */

.icon-button:focus-visible,
.button:focus-visible,
.link-button:focus-visible,
.menu-item:focus-visible,
.select:focus-visible,
.switch:focus-visible,
.checkbox:focus-visible,
.segment:focus-visible,
.slider-track:focus-visible,
.swatch:focus-visible,
.color-area:focus-visible,
.color-hue:focus-visible,
.chip:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: 1px;
}

/* Icon buttons ----------------------------------------------------------------------------- */

.icon-button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: var(--ink-control);
  height: var(--ink-control);
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--vscode-icon-foreground, var(--vscode-foreground));
  font: inherit;
  cursor: pointer;
  transition: background-color var(--ink-fast) var(--ink-ease);
}

/* DragHandle: the six-dot grip of a floating panel. */
.drag-handle {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: var(--ink-control);
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  cursor: grab;
  touch-action: none;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    color var(--ink-fast) var(--ink-ease);
}

.drag-handle:hover,
.drag-handle.dragging {
  background: var(--ink-hover);
  color: var(--vscode-foreground);
}

.drag-handle.dragging {
  cursor: grabbing;
}

.drag-handle:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.icon-button.small {
  width: var(--ink-control-sm);
  height: var(--ink-control-sm);
}

.icon-button:hover:not(:disabled) {
  background: var(--ink-hover);
}

.icon-button:active:not(:disabled) {
  background: var(--ink-pressed);
}

.icon-button.active {
  background: var(--ink-accent-soft);
  color: var(--vscode-inputOption-activeForeground, var(--vscode-foreground));
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--ink-accent) 60%, transparent);
}

.icon-button:disabled {
  opacity: 0.4;
  cursor: default;
}

/* Buttons ---------------------------------------------------------------------------------- */

.button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: var(--ink-control);
  padding: 0 12px;
  border: 1px solid var(--vscode-button-border, transparent);
  border-radius: var(--ink-radius-sm);
  font: inherit;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.button.small {
  gap: 4px;
  height: var(--ink-control-sm);
  padding: 0 8px;
}

.button .codicon {
  font-size: 14px;
}

.button.primary {
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.primary:hover:not(:disabled) {
  background: var(--vscode-button-hoverBackground);
}

.button.secondary {
  background: var(--vscode-button-secondaryBackground);
  color: var(--vscode-button-secondaryForeground);
}

.button.secondary:hover:not(:disabled) {
  background: var(--vscode-button-secondaryHoverBackground);
}

.button.ghost {
  border-color: transparent;
  background: transparent;
  color: inherit;
}

.button.ghost:hover:not(:disabled) {
  background: var(--ink-hover);
}

/* A solid call to action in the theme's own blue (its palette, see --ink-blue), for themes whose
   button color is dim. Dark text on dark themes, where the palette's blue is light. */
.button.accent {
  border-color: transparent;
  background: var(--ink-blue);
  color: var(--vscode-editor-background, #fff);
  font-weight: 600;
}

.button.accent:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-blue) 85%, var(--vscode-foreground, #fff));
}

body.vscode-light .button.accent {
  color: #fff;
}

body.vscode-high-contrast .button.accent {
  border-color: var(--vscode-contrastBorder, transparent);
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.danger {
  border-color: color-mix(in srgb, var(--ink-danger) 45%, transparent);
  background: transparent;
  color: var(--ink-danger);
}

.button.danger:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-danger) 12%, transparent);
}

.button:disabled {
  opacity: 0.5;
  cursor: default;
}

.link-button {
  padding: 0;
  border: none;
  background: none;
  color: var(--vscode-textLink-foreground);
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.link-button:hover:not(:disabled) {
  color: var(--vscode-textLink-activeForeground, var(--vscode-textLink-foreground));
  text-decoration: underline;
}

.link-button:disabled {
  color: inherit;
  cursor: default;
}

.link-button.danger {
  color: var(--ink-danger);
}

/* Text fields ------------------------------------------------------------------------------ */

.text-field {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: var(--ink-control);
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  transition: border-color var(--ink-fast) var(--ink-ease);
}

.text-field.size-sm {
  height: var(--ink-control-sm);
  padding: 0 6px;
}

.text-field.size-lg {
  height: var(--ink-control-lg);
  padding: 0 12px;
  border-radius: var(--ink-radius);
}

.text-field:hover:not(.disabled) {
  border-color: var(--ink-border-strong);
}

.text-field:focus-within {
  border-color: var(--ink-focus);
  box-shadow: 0 0 0 1px var(--ink-focus);
}

.text-field.invalid {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.text-field.disabled {
  opacity: 0.5;
}

.text-field input {
  flex: 1;
  width: 100%;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: none;
  outline: none;
  background: transparent;
  color: inherit;
  font: inherit;
}

.text-field input::placeholder {
  color: var(--vscode-input-placeholderForeground, var(--ink-muted));
}

/* Numbers: no spinner arrows (the fields accept typing and arrow keys). */
.text-field input::-webkit-outer-spin-button,
.text-field input::-webkit-inner-spin-button {
  margin: 0;
  appearance: none;
}

.text-field input[type='number'] {
  appearance: textfield;
  font-variant-numeric: tabular-nums;
}

.text-field input[type='search']::-webkit-search-cancel-button {
  appearance: none;
}

.text-field-icon {
  flex-shrink: 0;
  color: var(--ink-muted);
}

.text-field-clear {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.text-field-clear:hover {
  background: var(--ink-hover);
  color: inherit;
}

/* Form rows -------------------------------------------------------------------------------- */

.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: var(--ink-space-3);
}

.field.inline {
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ink-space-3);
}

.field-label {
  color: var(--vscode-foreground);
  font-weight: 600;
}

.field.inline .field-label {
  font-weight: normal;
}

.field-control {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  min-width: 0;
}

.field-control > .text-field,
.field-control > .select {
  flex: 1;
}

.field-hint {
  flex-basis: 100%;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.field-hint.error {
  color: var(--ink-danger);
}

/* Select ----------------------------------------------------------------------------------- */

.select {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  height: var(--ink-control);
  padding: 0 6px 0 8px;
  border: 1px solid var(--vscode-dropdown-border, var(--vscode-input-border, var(--ink-border)));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-dropdown-background, var(--vscode-input-background));
  color: var(--vscode-dropdown-foreground, var(--vscode-input-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.select.size-sm {
  height: var(--ink-control-sm);
  padding: 0 4px 0 6px;
}

.select:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
}

.select.open {
  border-color: var(--ink-focus);
}

.select.quiet {
  border-color: transparent;
  background: transparent;
}

.select.quiet:hover:not(:disabled),
.select.quiet.open {
  border-color: transparent;
  background: var(--ink-hover);
}

.select:disabled {
  opacity: 0.45;
  cursor: default;
}

.select-value {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.select-value.placeholder {
  color: var(--ink-muted);
}

.select-chevron {
  flex-shrink: 0;
  font-size: 14px !important;
  opacity: 0.8;
  transition: transform var(--ink-normal) var(--ink-ease);
}

.select.open .select-chevron {
  transform: rotate(180deg);
}

.select-list,
.color-picker,
.menu,
.popover {
  background: var(--ink-surface-raised);
  color: var(--vscode-menu-foreground, var(--vscode-foreground));
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow);
}

.select-list {
  position: fixed;
  z-index: 1000;
  max-height: min(340px, 60vh);
  padding: 4px;
  overflow-y: auto;
  outline: none;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.select-group {
  padding: 8px 8px 4px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.select-group:first-child {
  padding-top: 4px;
}

.select-option {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px 0 4px;
  border-radius: var(--ink-radius-sm);
  white-space: nowrap;
  cursor: pointer;
}

.select-option.active {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
}

.select-option.disabled {
  opacity: 0.45;
  cursor: default;
}

.select-check {
  flex-shrink: 0;
  font-size: 14px !important;
}

.select-option-label {
  flex: 1;
}

.select-option-detail {
  margin-left: 16px;
  opacity: 0.65;
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Switch and checkbox ---------------------------------------------------------------------- */

.switch,
.checkbox {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: var(--ink-space-2);
  padding: 2px 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.switch:disabled,
.checkbox:disabled {
  opacity: 0.45;
  cursor: default;
}

.switch-track {
  position: relative;
  flex-shrink: 0;
  width: 30px;
  height: 16px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-input-background, var(--ink-surface-sunken));
  transition:
    background-color var(--ink-normal) var(--ink-ease),
    border-color var(--ink-normal) var(--ink-ease);
}

.switch-thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--ink-muted);
  transition:
    transform var(--ink-normal) var(--ink-ease),
    background-color var(--ink-normal) var(--ink-ease);
}

.switch.on .switch-track {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
}

.switch.on .switch-thumb {
  background: var(--vscode-button-foreground, #fff);
  transform: translateX(14px);
}

.checkbox-box {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border: 1px solid var(--vscode-checkbox-border, var(--ink-border-strong));
  border-radius: 3px;
  background: var(--vscode-checkbox-background, var(--vscode-input-background));
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.checkbox.on .checkbox-box {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
  color: var(--vscode-button-foreground, #fff);
}

.checkbox-box .codicon {
  font-size: 14px !important;
}

/* Segmented control ------------------------------------------------------------------------ */

.segmented {
  display: inline-flex;
  flex-shrink: 0;
  gap: 2px;
  height: var(--ink-control);
  padding: 2px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
}

.segmented.size-sm {
  height: var(--ink-control-sm);
  padding: 1px;
  border-radius: var(--ink-radius-sm);
}

.segment {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  gap: 5px;
  min-width: 26px;
  padding: 0 10px;
  border: none;
  border-radius: calc(var(--ink-radius) - 2px);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    color var(--ink-fast) var(--ink-ease);
}

.segmented.size-sm .segment {
  padding: 0 8px;
  border-radius: 3px;
}

.segment:hover {
  color: var(--vscode-foreground);
}

.segment.checked {
  background: var(--vscode-button-secondaryBackground, var(--ink-hover));
  color: var(--vscode-button-secondaryForeground, var(--vscode-foreground));
  box-shadow: var(--ink-shadow-sm);
}

.segment-count {
  min-width: 16px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
  text-align: center;
}

.segment-count.error {
  background: var(--ink-danger);
  color: #fff;
}

/* Slider ----------------------------------------------------------------------------------- */

.slider {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  height: var(--ink-control);
}

.slider.disabled {
  opacity: 0.45;
}

.slider > .codicon {
  color: var(--ink-muted);
}

.slider-track {
  position: relative;
  width: 84px;
  height: 18px;
  cursor: pointer;
  touch-action: none;
  border-radius: var(--ink-radius-sm);
}

.slider-track::before,
.slider-fill {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  height: 4px;
  border-radius: var(--ink-radius-pill);
  transform: translateY(-50%);
}

.slider-track::before {
  right: 0;
  background: var(--ink-border-strong);
}

.slider-fill {
  background: var(--ink-accent);
}

.slider-thumb {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid var(--ink-accent);
  border-radius: 50%;
  background: var(--vscode-editor-background, #fff);
  box-shadow: var(--ink-shadow-sm);
  transform: translate(-50%, -50%);
  transition: transform var(--ink-fast) var(--ink-ease);
}

.slider-track:hover .slider-thumb,
.slider-track:active .slider-thumb {
  transform: translate(-50%, -50%) scale(1.15);
}

.slider-value {
  min-width: 34px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Swatches and color picker ---------------------------------------------------------------- */

.swatch {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  padding: 0;
  border: 1px solid color-mix(in srgb, var(--vscode-foreground, #888) 30%, transparent);
  border-radius: 50%;
  cursor: pointer;
  transition: transform var(--ink-fast) var(--ink-ease);
}

.swatch:hover {
  transform: scale(1.12);
}

.swatch.small {
  width: 16px;
  height: 16px;
}

.swatch.active {
  box-shadow:
    0 0 0 2px var(--ink-surface),
    0 0 0 3.5px var(--ink-accent);
}

.color-picker-trigger {
  background: conic-gradient(
    from 90deg,
    #f43f5e,
    #f59e0b,
    #84cc16,
    #06b6d4,
    #6366f1,
    #d946ef,
    #f43f5e
  );
}

.color-picker {
  position: fixed;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 224px;
  padding: 10px;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.color-area {
  position: relative;
  height: 140px;
  border-radius: var(--ink-radius-sm);
  background-image:
    linear-gradient(to top, #000, transparent), linear-gradient(to right, #fff, transparent) !important;
  cursor: crosshair;
  touch-action: none;
}

.color-hue {
  position: relative;
  height: 12px;
  border-radius: var(--ink-radius-pill);
  background: linear-gradient(
    to right,
    #f00 0%,
    #ff0 17%,
    #0f0 33%,
    #0ff 50%,
    #00f 67%,
    #f0f 83%,
    #f00 100%
  );
  cursor: pointer;
  touch-action: none;
}

.color-handle {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.35),
    0 1px 4px rgba(0, 0, 0, 0.4);
  transform: translate(-50%, -50%);
  pointer-events: none;
}

.color-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.color-preview {
  flex-shrink: 0;
  width: 26px;
  height: 26px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
}

.color-hex {
  flex: 1;
  min-width: 0;
  height: 26px;
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  outline: none;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-sm);
  text-transform: lowercase;
}

.color-hex:focus {
  border-color: var(--ink-focus);
}

.color-presets {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  padding-top: 8px;
  border-top: 1px solid var(--ink-border-subtle);
}

/* Chips and badges ------------------------------------------------------------------------- */

.badge {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 7px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  white-space: nowrap;
}

.badge.outline {
  border: 1px solid var(--ink-border-strong);
  background: transparent;
  color: var(--ink-muted);
}

.badge.success {
  background: color-mix(in srgb, var(--ink-success) 18%, transparent);
  color: var(--ink-success);
}

.badge.danger {
  background: color-mix(in srgb, var(--ink-danger) 18%, transparent);
  color: var(--ink-danger);
}

/* Key caps (shortcuts) --------------------------------------------------------------------- */

.keycaps {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 3px;
}

.keycap {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border: 1px solid var(--vscode-keybindingLabel-border, var(--ink-border-strong));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-keybindingLabel-background, var(--ink-surface-sunken));
  box-shadow: inset 0 -1px 0 var(--vscode-keybindingLabel-bottomBorder, var(--ink-border-strong));
  color: var(--vscode-keybindingLabel-foreground, var(--vscode-foreground));
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  line-height: 1;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.keycaps.size-sm .keycap {
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  font-size: 10.5px;
}

/* Cards ------------------------------------------------------------------------------------ */

.card {
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--ink-surface-sunken);
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--ink-space-3);
  padding: var(--ink-space-3) var(--ink-space-4);
  border-bottom: 1px solid var(--ink-border-subtle);
}

.card-title {
  margin: 0;
  font-size: var(--ink-font);
  font-weight: 600;
}

.card-body {
  padding: var(--ink-space-4);
}

.card-row {
  display: flex;
  align-items: center;
  gap: var(--ink-space-4);
  padding: var(--ink-space-3) var(--ink-space-4);
}

.card-row + .card-row {
  border-top: 1px solid var(--ink-border-subtle);
}

.card-row-text {
  flex: 1;
  min-width: 0;
}

.card-row-title {
  font-weight: 500;
}

.card-row-description {
  margin-top: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

/* Menus and popovers ----------------------------------------------------------------------- */

.menu,
.popover {
  position: fixed;
  /* Above the send dialog (900), like select lists and the color picker. */
  z-index: 1000;
  min-width: 200px;
  max-width: 420px;
  padding: 4px;
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

/* Long menus (a big bookmarks folder) stay short and scroll, like Chrome's. Items have a little
   room between them. */
.menu {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 5px;
  max-height: min(420px, calc(100vh - 8px));
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Submenus open without the pop animation, so they don't jump while the pointer moves. */
.menu .menu {
  animation: none;
}

.menu-item.expanded:not(:focus) {
  background: var(--ink-hover);
}

.menu-image {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  object-fit: contain;
}

.menu-arrow {
  margin-left: 12px;
  margin-right: -2px;
  opacity: 0.8;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  width: 100%;
  height: 28px;
  padding: 0 10px 0 8px;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.menu-item:hover:not(:disabled),
.menu-item:focus {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
  outline: none;
}

.menu-item:disabled {
  opacity: 0.45;
  cursor: default;
}

.menu-label {
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.menu-shortcut {
  margin-left: 16px;
  opacity: 0.7;
  font-size: 0.9em;
}

.menu-separator {
  flex-shrink: 0;
  height: 1px;
  margin: 3px 6px;
  background: var(--vscode-menu-separatorBackground, var(--ink-border));
}

/* Toast ------------------------------------------------------------------------------------ */

.toast {
  position: fixed;
  bottom: 16px;
  left: 50%;
  z-index: 200;
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: calc(100% - 32px);
  padding: 8px 14px;
  transform: translateX(-50%);
  background: var(--vscode-notifications-background, var(--ink-surface));
  color: var(--vscode-notifications-foreground, var(--vscode-foreground));
  border: 1px solid var(--vscode-notifications-border, var(--ink-border));
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow-lg);
  animation: toast-in var(--ink-normal) var(--ink-ease);
}

/* A failure: marked as one, longer on screen, and dismissible. */
.toast.error {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.toast.error > .codicon-error {
  flex-shrink: 0;
  color: var(--ink-danger);
}

.toast .toast-dismiss {
  flex-shrink: 0;
  margin: -4px -8px -4px 0;
}

.header-actions,
.button-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
}

/* Drawing ---------------------------------------------------------------------------------- */

.draw-toolbar {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  padding: 4px 8px;
  background: var(--ink-surface);
  border-top: 1px solid var(--ink-border);
  border-bottom: 1px solid var(--ink-border);
}

.draw-group {
  display: flex;
  align-items: center;
  gap: 2px;
  padding-right: 6px;
  border-right: 1px solid var(--ink-border-subtle);
}

.draw-group.colors {
  gap: 6px;
  padding: 0 8px 0 4px;
}

.draw-capture {
  margin-left: 2px;
}

.draw-close {
  margin-left: auto;
}

.drawing-layer {
  position: absolute;
  z-index: 3;
}

.drawing-layer canvas {
  position: relative;
  display: block;
  touch-action: none;
}

/* A live redaction (liveRedactions): blurs the page behind it, under the drawing canvas. Drawn
   over page content, so its colors are fixed. */
.drawing-redaction {
  position: absolute;
  pointer-events: none;
  background: rgba(128, 128, 128, 0.2);
  backdrop-filter: blur(12px) saturate(0.5);
}

.drawing-text-input {
  position: absolute;
  min-width: 160px;
  min-height: 1.6em;
  padding: 2px 4px;
  border: 1px dashed var(--ink-accent);
  background: rgba(255, 255, 255, 0.85);
  font-family: system-ui, sans-serif;
  font-weight: 600;
  resize: both;
  outline: none;
}

/* Motion ----------------------------------------------------------------------------------- */

@keyframes ink-fade-in {
  from {
    opacity: 0;
  }
}

@keyframes ink-pop-in {
  from {
    opacity: 0;
    transform: translateY(-3px) scale(0.985);
  }
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translate(-50%, 8px);
  }
}

@media (prefers-reduced-motion: reduce) {
  .select-list,
  .color-picker,
  .menu,
  .popover,
  .toast {
    animation: none;
  }
}

/* Shortcut list (ShortcutList) ------------------------------------------------------------- */

.shortcuts-warning {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 12px 8px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

/* Groups: a pinned header per mode. */
.group-header {
  position: sticky;
  top: var(--shortcut-sticky-top, 0);
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  height: 28px;
  padding: 0 12px 0 6px;
  border: none;
  border-top: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  color: var(--vscode-sideBarSectionHeader-foreground, var(--vscode-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.group-header:hover {
  background: var(--vscode-list-hoverBackground);
}

.group-header:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.group-icon {
  color: var(--ink-accent-fg);
}

.group-title {
  font-size: var(--ink-font-xs);
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.group-count {
  margin-left: auto;
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
}

/* Rows: label, then actions (on hover), then the keys in a right-aligned column. */
.shortcut-item {
  position: relative;
  padding: 0 12px 0 32px;
  border-radius: var(--ink-radius);
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.shortcut-item::before {
  content: '';
  position: absolute;
  top: 6px;
  bottom: 6px;
  left: 20px;
  width: 2px;
  border-radius: 1px;
  background: transparent;
}

.shortcut-item.changed::before {
  background: var(--ink-accent);
}

.shortcut-item.conflict::before {
  background: var(--ink-warning);
}

/* Outside VS Code (the browser extension) there is no list hover color: the kit's hover. */
.shortcut-item:hover,
.shortcut-item:focus-within {
  background: var(--vscode-list-hoverBackground, var(--ink-hover));
}

body.vscode-high-contrast .shortcut-item:hover,
body.vscode-high-contrast .shortcut-item:focus-within {
  outline: 1px dashed var(--vscode-contrastActiveBorder);
  outline-offset: -1px;
}

.shortcut-main {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 30px;
}

.shortcut-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Where a key works: VS (VS Code Browser) and BR (the browser toolbar), and the browser's own key. */
.shortcut-places {
  display: inline-flex;
  flex-shrink: 0;
  gap: 3px;
}

.shortcut-tag {
  --tag: var(--ink-muted);
  flex-shrink: 0;
  min-width: 22px;
  padding: 0 4px;
  border: 1px solid color-mix(in srgb, var(--tag) 40%, transparent);
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--tag) 10%, transparent);
  color: var(--tag);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 14px;
  text-align: center;
  letter-spacing: 0.02em;
}

.shortcut-tag.vs {
  --tag: var(--ink-blue);
}

.shortcut-tag.br {
  --tag: var(--ink-green);
}

body.vscode-high-contrast .shortcut-tag {
  border-color: var(--vscode-contrastBorder);
  background: transparent;
  color: var(--vscode-foreground);
}

.shortcut-item.changed .shortcut-label {
  font-weight: 500;
}

.shortcut-actions {
  display: inline-flex;
  flex-shrink: 0;
  justify-content: flex-end;
  gap: 1px;
  /* Room for both buttons (reset, add a key) in every row, so the columns line up. */
  min-width: calc(2 * var(--ink-control-sm) + 1px);
  opacity: 0;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.shortcut-item:hover .shortcut-actions,
.shortcut-item:focus-within .shortcut-actions {
  opacity: 1;
}

.shortcut-keys-column {
  display: inline-flex;
  flex-wrap: wrap;
  flex-shrink: 0;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  /* A steady width, so the VS/BR tags before it line up from row to row. */
  min-width: min(184px, 40%);
  max-width: 62%;
}

.key-button-wrap {
  position: relative;
  display: inline-flex;
}

.key-button {
  display: inline-flex;
  padding: 2px;
  border: 1px solid transparent;
  border-radius: var(--ink-radius);
  background: transparent;
  cursor: pointer;
}

.key-button:hover {
  border-color: var(--ink-border-strong);
  background: var(--ink-surface-sunken);
}

.key-button:focus-visible {
  outline: 1px solid var(--ink-focus);
}

/* The remove badge sits on the key's corner, so showing it doesn't move anything. */
.key-remove {
  position: absolute;
  top: -5px;
  right: -5px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 1px solid var(--ink-border-strong);
  border-radius: 50%;
  background: var(--ink-surface-raised);
  color: var(--ink-muted);
  opacity: 0;
  cursor: pointer;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.key-remove .codicon {
  font-size: 10px !important;
}

.key-button-wrap:hover .key-remove,
.key-remove:focus-visible {
  opacity: 1;
}

.key-remove:hover {
  border-color: var(--ink-danger);
  background: var(--ink-danger);
  color: #fff;
}

.key-empty {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 22px;
  padding: 0 8px;
  border: 1px dashed var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  font-size: var(--ink-font-xs);
  cursor: pointer;
}

.key-empty:hover {
  border-color: var(--ink-focus);
  color: var(--vscode-foreground);
}

.key-empty .codicon {
  font-size: 12px !important;
}

.key-recording {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  padding: 0 2px 0 8px;
  border: 1px solid var(--ink-focus);
  border-radius: var(--ink-radius-sm);
  background: var(--ink-accent-soft);
  box-shadow: 0 0 0 1px var(--ink-focus);
  font-size: var(--ink-font-xs);
}

.recording-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #ef4444;
  animation: ink-shortcut-pulse 1s ease-in-out infinite;
}

.key-recording-cancel {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.key-recording-cancel:hover {
  background: var(--ink-hover);
  color: inherit;
}

.shortcut-conflict {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 6px;
  padding: 0 0 6px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

@keyframes ink-shortcut-pulse {
  50% {
    opacity: 0.3;
  }
}

@media (prefers-reduced-motion: reduce) {
  .recording-dot {
    animation: none;
  }
}

body.vscode-high-contrast .key-button:hover {
  border-color: var(--vscode-contrastBorder);
}

/* Several keys for one action: "Ctrl T / Ctrl F4". */
.key-button-wrap + .key-button-wrap::before {
  content: '/';
  align-self: center;
  margin-right: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

/* Element picker hint (PickerHint) ------------------------------------------------------------
   Drawn over page content, so it has its own dark look (the theme's colors could vanish on the
   page), in both products. Each product places it. */
/* One row: what a click does, with each modifier, then the keys. */
.picker-hint {
  display: flex;
  align-items: center;
  gap: 14px;
  /* Its own width: centered with left: 50%, it would otherwise wrap at half the page. */
  width: max-content;
  padding: 6px 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.9);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  line-height: 1;
  pointer-events: none;
  backdrop-filter: blur(6px);
}

.picker-hint-item {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
}

.picker-hint-label {
  color: rgba(250, 250, 250, 0.82);
}

/* The main action, as a sentence; the others read "[Shift] + click  select several". */
.picker-hint-lead {
  color: #fff;
  font-weight: 600;
}

.picker-hint-click {
  color: #fff;
  font-weight: 500;
}

.picker-hint .keycap {
  border-color: rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  box-shadow: inset 0 -1px 0 rgba(255, 255, 255, 0.14);
  color: #fff;
}

/* Multi-selection bar (SelectionBar) ----------------------------------------------------------
   Over page content like the picker hint, so the same dark look; each product places it. */
.selection-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px;
  width: max-content;
  max-width: calc(100vw - 32px);
  padding: 5px 6px 5px 10px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.94);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  pointer-events: auto;
}

.selection-bar-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: 6px;
  font-weight: 600;
}

.selection-bar-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: #0a84ff;
  color: #fff;
  font-size: var(--ink-font-xs);
}

.selection-bar .button.ghost,
.selection-bar .icon-button {
  color: #fafafa;
}

.selection-bar .button.ghost:hover:not(:disabled),
.selection-bar .icon-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.12);
}

.selection-bar .button-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.selection-bar .keycap {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.16);
  box-shadow: none;
  color: #fff;
}

/* Thumbnails with a checkbox each (ThumbPicker): screenshots taken together ------------------- */
.thumb-picker {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(88px, 1fr));
  gap: var(--ink-space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.thumb-picker-item {
  position: relative;
  border-radius: var(--ink-radius);
}

.thumb-picker-image {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  aspect-ratio: 16 / 10;
  padding: 0;
  overflow: hidden;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  color: var(--ink-muted);
  cursor: pointer;
  transition:
    opacity var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.thumb-picker-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

.thumb-picker-image:hover {
  border-color: var(--ink-border-strong);
}

/* Left out: dimmed, so what is sent stands out. */
.thumb-picker-item:not(.on) .thumb-picker-image {
  opacity: 0.45;
}

.thumb-picker-item.on .thumb-picker-image {
  border-color: var(--ink-accent);
}

.thumb-picker-check {
  position: absolute;
  top: 4px;
  left: 4px;
  padding: 2px;
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--vscode-editor-background) 80%, transparent);
  box-shadow: var(--ink-shadow-sm);
}

body.vscode-high-contrast .thumb-picker-item.on .thumb-picker-image {
  outline: 1px solid var(--vscode-contrastActiveBorder);
}

/* The send dialog after a capture (SendModal) ------------------------------------------- */

.ink-modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 900;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--ink-space-4);
  background: color-mix(in srgb, #000 35%, transparent);
  animation: ink-fade-in var(--ink-normal) var(--ink-ease);
  pointer-events: auto;
}

.ink-modal {
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-3);
  width: min(480px, 100%);
  max-height: calc(100vh - 2 * var(--ink-space-4));
  overflow: auto;
  padding: var(--ink-space-4);
  background: var(--ink-surface);
  color: var(--vscode-editorWidget-foreground, var(--vscode-foreground));
  border: 1px solid var(--vscode-editorWidget-border, var(--ink-border));
  border-radius: var(--ink-radius-lg);
  box-shadow: var(--ink-shadow-lg);
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  text-align: left;
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.ink-modal:focus {
  outline: none;
}

.ink-modal-head {
  display: flex;
  align-items: flex-start;
  gap: var(--ink-space-3);
}

.ink-modal-detail {
  line-height: 1.35;
}

/* The captures: one row of equal tiles under the heading. */
.ink-modal-thumbs {
  display: grid;
  grid-auto-columns: minmax(0, 1fr);
  grid-auto-flow: column;
  gap: var(--ink-space-2);
}

.ink-modal-thumb {
  position: relative;
  display: block;
  height: 64px;
  overflow: hidden;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
}

.ink-modal-thumb img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

.ink-modal-more {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  background: color-mix(in srgb, #000 55%, transparent);
  color: #fff;
  font-size: var(--ink-font);
  font-weight: 600;
}

.ink-modal-heading {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: var(--ink-space-1);
  min-width: 0;
}

.ink-modal-project {
  flex-wrap: nowrap;
  white-space: nowrap;
}

.ink-modal-title {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  font-size: calc(var(--ink-font) + 1px);
  font-weight: 600;
}

.ink-modal-title .codicon {
  color: var(--ink-success);
}

.ink-modal-project,
.ink-modal-detail {
  display: flex;
  align-items: center;
  gap: var(--ink-space-1);
  font-size: var(--ink-font-sm);
}

.ink-modal-project-name {
  font-weight: 600;
}

.ink-modal-detail,
.ink-modal-project .ink-muted,
.ink-modal-empty,
.ink-modal-label,
.ink-modal-where,
.ink-modal-status {
  color: var(--ink-muted);
}

.ink-modal-label {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  margin-bottom: calc(-1 * var(--ink-space-1));
  font-size: var(--ink-font-xs);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

.ink-modal-count {
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--ink-surface-sunken);
  letter-spacing: 0;
}

.ink-modal-targets {
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-1);
  margin: 0;
  padding: 0;
  list-style: none;
}

.ink-modal-target {
  display: flex;
  align-items: center;
  gap: var(--ink-space-1);
}

.ink-modal-send {
  display: flex;
  flex: 1;
  align-items: center;
  gap: var(--ink-space-3);
  min-width: 0;
  min-height: 52px;
  padding: var(--ink-space-2) var(--ink-space-3) var(--ink-space-2) var(--ink-space-2);
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--ink-surface-sunken);
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.ink-modal-send:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
  background: var(--ink-hover);
}

.ink-modal-send:disabled {
  cursor: default;
  opacity: 0.6;
}

.ink-modal-send:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.ink-modal-target.default .ink-modal-send {
  border-color: var(--ink-accent);
  background: var(--ink-accent-soft);
}

.ink-modal-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: var(--ink-radius);
  background: color-mix(in srgb, var(--vscode-foreground) 8%, transparent);
}

.ink-modal-icon .codicon {
  font-size: 17px;
}

.ink-modal-target.default .ink-modal-icon {
  background: var(--ink-accent);
  color: var(--vscode-button-foreground, #fff);
}

.ink-modal-text {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
}

.ink-modal-agent {
  overflow: hidden;
  font-weight: 600;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ink-modal-where {
  overflow: hidden;
  font-size: var(--ink-font-sm);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ink-modal-keys {
  display: flex;
  flex: none;
  align-items: center;
  gap: var(--ink-space-1);
}

.ink-modal-number {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

.ink-modal-thread {
  align-self: flex-start;
}

.ink-modal-empty {
  padding: var(--ink-space-3);
  border: 1px dashed var(--ink-border-strong);
  border-radius: var(--ink-radius-lg);
  text-align: center;
}

.ink-modal-foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--ink-space-2);
  padding-top: var(--ink-space-3);
  border-top: 1px solid var(--ink-border-subtle);
}

.ink-modal-status {
  flex: 1;
  min-width: 160px;
  font-size: var(--ink-font-sm);
}

.ink-modal-status.tone-error {
  color: var(--ink-danger);
}

.ink-modal-status.tone-ok {
  color: var(--ink-success);
}

body.vscode-high-contrast .ink-modal-target.default .ink-modal-send {
  outline: 1px solid var(--vscode-contrastActiveBorder);
}

@media (forced-colors: active) {
  .ink-modal-target.default .ink-modal-send {
    outline: 2px solid Highlight;
  }
}

/* Saved list (SavedList) ----------------------------------------------------------------------
   A project's captures, in VS Code's Saved view and the browser's side panel. Cards are a lighter
   tint of the sidebar, with no outline: in themes like Tokyo Night the sidebar, editor and
   borders are all the same near-black. */
.saved {
  --card-bg: color-mix(
    in srgb,
    var(--vscode-foreground, #888) 5%,
    var(--vscode-sideBar-background, transparent)
  );
  display: flex;
  flex-direction: column;
  container: saved / inline-size;
}

/* The agent picker and filters, pinned at the top. */
.saved-header {
  position: sticky;
  top: 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-2);
  padding: var(--ink-space-2) var(--ink-space-3);
  border-bottom: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
}

/* Filters fill the width; below 480px only their icons and counts show (names are tooltips). */
.saved-filter {
  display: flex;
  width: 100%;
}

.saved-filter .segment {
  flex: 1 1 auto;
  min-width: 0;
  gap: 4px;
  padding: 0 4px;
}

@container saved (max-width: 260px) {
  .saved-filter .segment-count:not(.error) {
    display: none;
  }
}

@container saved (max-width: 480px) {
  .saved-filter .segment-label {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
}

/* Items. */
.saved-list {
  display: flex;
  flex-direction: column;
  gap: var(--ink-space-2);
  margin: 0;
  padding: var(--ink-space-2) var(--ink-space-3) var(--ink-space-3);
  list-style: none;
}

.saved-card {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
  padding: 10px;
  border: 1px solid transparent;
  border-radius: var(--ink-radius-lg);
  background: var(--card-bg);
  outline: none;
  transition:
    border-color var(--ink-fast) var(--ink-ease),
    background var(--ink-fast) var(--ink-ease);
}

.saved-card:hover {
  background: color-mix(in srgb, var(--vscode-foreground, #888) 4%, var(--card-bg));
}

.saved-card:focus-visible {
  border-color: var(--ink-focus);
}

/* Screenshots, recordings and element captures: a preview across the card's width. The whole
   image shows (a short element strip isn't cropped to nothing); only tall captures, such as full
   pages, are cropped to their top. */
.saved-thumb {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  min-height: 44px;
  max-height: 150px;
  padding: 6px;
  overflow: hidden;
  border: none;
  border-radius: var(--ink-radius);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  cursor: zoom-in;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.saved-thumb:hover {
  opacity: 0.88;
}

.saved-thumb:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: 1px;
}

.saved-thumb img {
  display: block;
  max-width: 100%;
  max-height: 136px;
  border-radius: var(--ink-radius-sm);
  object-fit: contain;
}

.saved-thumb.tall {
  height: 150px;
  padding: 0;
}

.saved-thumb.tall img {
  width: 100%;
  height: 100%;
  max-height: none;
  border-radius: 0;
  object-fit: cover;
  object-position: top center;
}

.saved-card-head {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
}

.saved-card-icon {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  border-radius: var(--ink-radius);
  background: color-mix(in srgb, var(--kind-tone) 14%, transparent);
  color: var(--kind-tone);
}

.saved-card {
  --kind-tone: var(--ink-blue);
}

.saved-card.kind-errors,
.saved-card.kind-network {
  --kind-tone: var(--ink-red);
}

.saved-card.kind-report,
.saved-card.kind-measure {
  --kind-tone: var(--ink-green);
}

.saved-card.kind-css,
.saved-card.kind-color {
  --kind-tone: var(--ink-magenta);
}

.saved-card-heading {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.saved-card-title-row {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.saved-card-title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  /* The editor text color: some themes (Tokyo Night) keep the sidebar foreground quite dim. */
  color: var(--vscode-editor-foreground, var(--vscode-foreground));
  font-weight: 600;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* A soft chip in the link color, readable on light, dark and high-contrast backgrounds alike. */
.saved-card-badge {
  flex-shrink: 0;
  padding: 0 7px;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--ink-blue) 16%, transparent);
  color: var(--ink-blue);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 16px;
}

.saved-card-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0 6px;
  min-width: 0;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

.saved-card-meta span {
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-card-meta span + span::before {
  content: '\xB7';
  margin-right: 6px;
}

.saved-card-preview {
  margin: 0;
  padding: 6px 8px;
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-textCodeBlock-background, var(--ink-surface));
  color: var(--vscode-descriptionForeground, var(--ink-muted));
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-xs);
  line-height: 1.45;
}

/* Clamped inside the padding, so no half line shows below it. */
.saved-card-preview span {
  display: -webkit-box;
  overflow: hidden;
  word-break: break-word;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}

.saved-card-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
}

/* Send, and a chevron for another agent, joined into one control. */
.saved-send {
  display: inline-flex;
  flex-shrink: 0;
}

.saved-send .saved-send-more {
  min-width: 0;
  /* A hairline of the card shows between the two halves. */
  margin-left: 1px;
  padding: 0 5px;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

.saved-send .button:first-child:not(:last-child) {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}

.saved-card-tools {
  display: inline-flex;
  gap: 1px;
  margin-left: auto;
  opacity: 0.55;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.saved-card:hover .saved-card-tools,
.saved-card:focus-within .saved-card-tools {
  opacity: 1;
}

.saved-card-sent {
  display: flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  color: var(--ink-green);
  font-size: var(--ink-font-xs);
}

.saved-card-sent .codicon {
  flex-shrink: 0;
  font-size: 12px !important;
}

.saved-card-sent span:last-child {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Very narrow: the send button takes the whole row, the tools go below it. */
@container saved (max-width: 210px) {
  .saved-send,
  .saved-send .button:first-child {
    flex: 1;
  }

  .saved-card-tools {
    margin-left: 0;
  }
}

.saved-none {
  margin: var(--ink-space-4) var(--ink-space-3);
  color: var(--ink-muted);
  text-align: center;
}

.saved-footer {
  position: sticky;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ink-space-2);
  margin-top: auto;
  padding: 6px var(--ink-space-3);
  border-top: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
}

.saved-hint {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
}

@container saved (max-width: 320px) {
  .saved-hint {
    display: none;
  }

  .saved-footer {
    justify-content: flex-end;
  }
}

@media (prefers-reduced-motion: reduce) {
  .saved-card,
  .saved-card-tools {
    transition: none;
  }
}

body.vscode-high-contrast .saved-card {
  border-color: var(--vscode-contrastBorder);
}

body.vscode-high-contrast .saved-card.latest,
body.vscode-high-contrast .saved-card:focus-visible {
  border-color: var(--vscode-contrastActiveBorder, var(--ink-focus));
}

/* Selecting cards (to send, remove or group several): a checkbox in the head, shown on hover,
   on focus, and on every card while anything is selected. */
.saved-card-select {
  display: none;
  margin-top: 6px;
}

.saved-card:hover .saved-card-select,
.saved-card:focus-within .saved-card-select,
.saved.selecting .saved-card-select,
.saved-card.selected .saved-card-select {
  display: inline-flex;
}

.saved-card.selected {
  border-color: var(--ink-accent);
  background: color-mix(in srgb, var(--ink-accent) 8%, var(--card-bg));
}

body.vscode-high-contrast .saved-card.selected {
  border-color: var(--vscode-contrastActiveBorder);
}

/* A group: screenshots taken (or grouped) together, one thumbnail each. */
.saved-group .saved-card-icon {
  --kind-tone: var(--ink-blue);
}

.saved-card-count {
  flex-shrink: 0;
  min-width: 18px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--vscode-foreground, #888) 12%, transparent);
  color: var(--vscode-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 16px;
  text-align: center;
}

.saved-group-thumbs {
  grid-template-columns: repeat(auto-fill, minmax(72px, 1fr));
}

/* The footer while cards are selected: what to do with all of them. */
.saved-selection {
  justify-content: flex-start;
  gap: 4px;
}

.saved-selection-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: auto;
  font-weight: 600;
}

.saved-selection-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: var(--ink-accent);
  color: var(--vscode-button-foreground);
  font-size: var(--ink-font-xs);
}

/* A group of elements (or other text): a checklist, one row each. */
.saved-group-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
  margin: 0;
  padding: 4px;
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
  list-style: none;
}

.saved-group-row {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  padding: 3px 4px 3px 6px;
  border-radius: var(--ink-radius-sm);
}

.saved-group-row:hover {
  background: var(--vscode-list-hoverBackground, var(--ink-hover));
}

.saved-group-row:not(.on) .saved-group-row-text,
.saved-group-row:not(.on) .saved-group-row-icon {
  opacity: 0.5;
}

.saved-group-row-icon {
  flex-shrink: 0;
  color: var(--ink-blue);
}

.saved-group-row-text {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
}

.saved-group-row-title {
  overflow: hidden;
  color: var(--vscode-editor-foreground, var(--vscode-foreground));
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-group-row-detail {
  overflow: hidden;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-group-row-open {
  opacity: 0;
}

.saved-group-row:hover .saved-group-row-open,
.saved-group-row:focus-within .saved-group-row-open {
  opacity: 1;
}

/* After a removal: what went, and Undo (for a few seconds). */
.saved-undo-text {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  color: var(--vscode-foreground);
  font-size: var(--ink-font-xs);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.saved-undo-text .codicon {
  color: var(--ink-muted);
}

/* Send and its chevron, then Open in agentmux. */
.saved-send-group {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 2px;
}

/* A thumbnail that opens nothing (the side panel). */
.saved-thumb.still {
  cursor: default;
}

.saved-thumb.still:hover {
  opacity: 1;
}

@container saved (max-width: 210px) {
  .saved-send-group {
    flex: 1;
  }
}
`;var Ai=W(me(),1);function We({icon:e,label:t,onClick:n,onContextMenu:o,disabled:a,active:l,spin:c,className:i}){return(0,Ai.jsx)("button",{type:"button",className:["icon-button",l&&"active",i].filter(Boolean).join(" "),title:t,"aria-label":t,"aria-pressed":l,disabled:a,onClick:n,onContextMenu:o,children:(0,Ai.jsx)("span",{className:`codicon codicon-${e}${c?" codicon-modifier-spin":""}`,"aria-hidden":"true"})})}var Pe=W($t(),1);function df(e,t){let n=e.find(o=>o.id===t);return n?[n,...e.filter(o=>o!==n)]:[...e]}function ff(e){return e.kind==="chat"?"comment-discussion":e.kind==="tmux"?"terminal-tmux":"terminal"}var Ul=W($t(),1);function sf(e,t,n,o={}){let{align:a="start",gap:l=4,matchWidth:c=!1}=o;(0,Ul.useLayoutEffect)(()=>{if(!n)return;let i=()=>{e.current&&t.current&&Tp(e.current,t.current,{align:a,gap:l,matchWidth:c})};i();let r=new ResizeObserver(i);return t.current&&r.observe(t.current),()=>r.disconnect()},[e,t,n,a,l,c])}function Tp(e,t,{align:n,gap:o,matchWidth:a}){let l=e.getBoundingClientRect();a&&(t.style.minWidth=`${l.width}px`);let c=t.getBoundingClientRect(),i=4,r=l.bottom+o,d=r+c.height<=innerHeight-i,v=l.top-o-c.height,m=d||v<i?r:v,s=n==="end"?l.right-c.width:l.left;t.style.top=`${Math.max(i,Math.min(m,innerHeight-c.height-i))}px`,t.style.left=`${Math.max(i,Math.min(s,innerWidth-c.width-i))}px`,t.dataset.side=m===r?"bottom":"top"}function Bi(e,t,n){let o=e().find(Boolean)?.getRootNode(),a=o instanceof ShadowRoot?o:void 0,l=r=>e().some(d=>d&&r.composedPath().includes(d)),c=r=>{a&&r.composedPath().includes(a.host)||l(r)||n(r)},i=r=>{l(r)||n(r)};return window.addEventListener(t,c,!0),a?.addEventListener(t,i,!0),()=>{window.removeEventListener(t,c,!0),a?.removeEventListener(t,i,!0)}}var Oa,wp=e=>{let t=e.composedPath()[0];if(e.button!==0){Oa=void 0;return}t instanceof Element&&(Oa={element:t.closest('button, [role="button"], a')??t,at:performance.now()})};typeof window<"u"&&window.addEventListener("pointerdown",wp,!0);function bf(){return Oa&&performance.now()-Oa.at<1e3?Oa.element:void 0}function Ep(e){let t=e.getRootNode(),n=[window];t instanceof ShadowRoot&&n.push(t);let o=c=>{c.composedPath().includes(e)&&(c.stopPropagation(),c.preventDefault(),a())},a=()=>{clearTimeout(l);for(let c of n)c.removeEventListener("click",o,!0)},l=setTimeout(a,1e3);for(let c of n)c.addEventListener("click",o,!0)}function vf(e,t,n,o){return Bi(e,"pointerdown",a=>{o?.(a)||(t&&a.composedPath().includes(t)&&Ep(t),n(a))})}function gf(e,t,n){(0,Ul.useEffect)(()=>{if(!t)return;let o=()=>e.map(r=>r.current),a=Bi(o,"pointerdown",()=>n("outside")),l=Bi(o,"scroll",()=>n("window")),c=r=>{r.key==="Escape"&&(r.preventDefault(),r.stopPropagation(),n("escape"))},i=()=>n("window");return window.addEventListener("keydown",c,!0),window.addEventListener("blur",i),window.addEventListener("resize",i),()=>{a(),l(),window.removeEventListener("keydown",c,!0),window.removeEventListener("blur",i),window.removeEventListener("resize",i)}},[t,n])}function le(...e){return e.filter(Boolean).join(" ")}function mf(e){let t=e?.getRootNode();return t instanceof ShadowRoot?t:document.body}var Oo=W(me(),1);function $n({variant:e="secondary",size:t="md",icon:n,iconEnd:o,loading:a,className:l,children:c,disabled:i,type:r="button",...d}){let v=a?"loading":n;return(0,Oo.jsxs)("button",{type:r,className:le("button",e,t==="sm"&&"small",l),disabled:i||a,"aria-busy":a||void 0,...d,children:[v&&(0,Oo.jsx)("span",{className:le("codicon",`codicon-${v}`,a&&"codicon-modifier-spin"),"aria-hidden":"true"}),c!==void 0&&(0,Oo.jsx)("span",{className:"button-label",children:c}),o&&(0,Oo.jsx)("span",{className:`codicon codicon-${o}`,"aria-hidden":"true"})]})}var vt=W($t(),1);var Ie=W(me(),1);function pf({menu:e,onClose:t}){let n=(0,vt.useRef)(null),[o]=(0,vt.useState)(bf);return(0,vt.useEffect)(()=>{let a=vf(()=>[n.current],o,()=>t()),l=c=>{c.key==="Escape"&&(c.preventDefault(),c.stopPropagation(),t())};return window.addEventListener("keydown",l,!0),window.addEventListener("blur",t),window.addEventListener("resize",t),()=>{a(),window.removeEventListener("keydown",l,!0),window.removeEventListener("blur",t),window.removeEventListener("resize",t)}},[t,o]),(0,Ie.jsx)("div",{ref:n,className:"menu-root",onContextMenu:a=>a.preventDefault(),children:(0,Ie.jsx)(hf,{items:e.items,x:e.x,y:e.y,onClose:t,focusFirst:!0})})}function hf({items:e,x:t,y:n,onClose:o,focusFirst:a,parent:l,onBack:c}){let i=(0,vt.useRef)(null),[r,d]=(0,vt.useState)(null),v=(0,vt.useRef)(void 0);(0,vt.useLayoutEffect)(()=>{let x=i.current;if(!x)return;let f=x.getBoundingClientRect(),u=t;l&&t+f.width>innerWidth-4&&(u=l.left-f.width+2),x.style.left=`${Math.max(4,Math.min(u,innerWidth-f.width-4))}px`,x.style.top=`${Math.max(4,Math.min(n,innerHeight-f.height-4))}px`,a&&x.querySelector(":scope > button:not(:disabled)")?.focus({preventScroll:!0})},[t,n,l,a]),(0,vt.useEffect)(()=>()=>clearTimeout(v.current),[]);let m=()=>[...i.current?.querySelectorAll(":scope > button:not(:disabled)")??[]],s=(x,f,u)=>{clearTimeout(v.current),d({index:x,rect:f.getBoundingClientRect()}),u&&setTimeout(()=>i.current?.querySelector(":scope > .menu button:not(:disabled)")?.focus({preventScroll:!0}))},b=x=>{if(x.target instanceof HTMLElement&&x.target.closest(".menu")!==i.current)return;let f=m(),u=f.indexOf(document.activeElement);if(x.key==="ArrowDown"||x.key==="ArrowUp")x.preventDefault(),f[(u+(x.key==="ArrowDown"?1:-1)+f.length)%f.length]?.focus();else if(x.key==="ArrowLeft"&&c)x.preventDefault(),x.stopPropagation(),c();else if(x.key==="ArrowRight"){let g=f[u],p=g&&e[Number(g.dataset.index)];p&&"submenu"in p&&p.submenu&&(x.preventDefault(),s(Number(g.dataset.index),g,!0))}},y=r?e[r.index]:void 0,k=y&&"submenu"in y?y.submenu?.():void 0;return(0,Ie.jsxs)("div",{ref:i,className:"menu",role:"menu",style:{left:t,top:n},onKeyDown:b,children:[e.map((x,f)=>"separator"in x?(0,Ie.jsx)("div",{className:"menu-separator",role:"separator"},f):(0,Ie.jsxs)("button",{type:"button",role:"menuitem","data-index":f,"aria-haspopup":x.submenu?"menu":void 0,"aria-expanded":x.submenu?r?.index===f:void 0,className:`menu-item${r?.index===f?" expanded":""}`,disabled:x.disabled,onPointerEnter:u=>{clearTimeout(v.current);let g=u.currentTarget;x.disabled||g.focus({preventScroll:!0}),v.current=setTimeout(()=>x.submenu?s(f,g,!1):d(null),x.submenu?120:250)},onClick:u=>{if(x.submenu){s(f,u.currentTarget,u.detail===0);return}o(),x.onSelect()},children:[x.image?(0,Ie.jsx)("img",{className:"menu-image",src:x.image,alt:"",referrerPolicy:"no-referrer"}):(0,Ie.jsx)("span",{className:`codicon codicon-${x.icon??"blank"}`,"aria-hidden":"true"}),(0,Ie.jsx)("span",{className:"menu-label",children:x.label}),x.shortcut&&(0,Ie.jsx)("span",{className:"menu-shortcut",children:x.shortcut}),x.submenu&&(0,Ie.jsx)("span",{className:"codicon codicon-chevron-right menu-arrow","aria-hidden":"true"})]},f)),r&&k&&(0,Ie.jsx)(hf,{items:k.length?k:[{label:"(empty)",disabled:!0,onSelect:()=>{}}],x:r.rect.right-2,y:r.rect.top-5,parent:r.rect,onClose:o,onBack:()=>{d(null),i.current?.querySelector(`:scope > button[data-index="${r.index}"]`)?.focus()}},r.index)]})}var yf=W($t(),1);var Fn=W(me(),1);function xf({value:e,options:t,onChange:n,label:o,iconOnly:a,size:l="md",className:c}){let i=(0,yf.useRef)(null),r=d=>{let v={ArrowRight:1,ArrowDown:1,ArrowLeft:-1,ArrowUp:-1}[d.key];if(!v)return;d.preventDefault();let m=t.findIndex(b=>b.value===e),s=t[(m+v+t.length)%t.length];n(s.value),i.current?.querySelector(`[data-value="${CSS.escape(s.value)}"]`)?.focus()};return(0,Fn.jsx)("div",{ref:i,className:le("segmented",`size-${l}`,c),role:"radiogroup","aria-label":o,onKeyDown:r,children:t.map(d=>{let v=d.value===e;return(0,Fn.jsxs)("button",{type:"button",role:"radio","aria-checked":v,"aria-label":a?d.label:void 0,title:a||d.icon?d.label:void 0,"data-value":d.value,tabIndex:v?0:-1,className:le("segment",v&&"checked"),onClick:()=>n(d.value),children:[d.icon&&(0,Fn.jsx)("span",{className:`codicon codicon-${d.icon}`,"aria-hidden":"true"}),!a&&(0,Fn.jsx)("span",{className:"segment-label",children:d.label}),d.count!==void 0&&(0,Fn.jsx)("span",{className:le("segment-count",d.tone),children:d.count})]},d.value)})})}var Ao=W(me(),1);function _o({checked:e,onChange:t,children:n,label:o,disabled:a,className:l,title:c}){return(0,Ao.jsxs)("button",{type:"button",role:"checkbox","aria-checked":e,"aria-label":n?void 0:o,title:c,disabled:a,className:le("checkbox",e&&"on",l),onClick:()=>t(!e),children:[(0,Ao.jsx)("span",{className:"checkbox-box","aria-hidden":"true",children:e&&(0,Ao.jsx)("span",{className:"codicon codicon-check"})}),n&&(0,Ao.jsx)("span",{className:"toggle-label",children:n})]})}var bn=W(me(),1);function kf({items:e,checked:t,onToggle:n,onOpen:o,className:a}){return(0,bn.jsx)("ul",{className:le("thumb-picker",a),"aria-label":"Screenshots",children:e.map(l=>{let c=t.has(l.id);return(0,bn.jsxs)("li",{className:le("thumb-picker-item",c&&"on"),title:l.label,children:[(0,bn.jsx)("button",{type:"button",className:"thumb-picker-image","aria-label":o?`Open ${l.label}`:`Include ${l.label}`,"aria-pressed":o?void 0:c,onClick:()=>o?o(l.id):n(l.id),children:l.src?(0,bn.jsx)("img",{src:l.src,alt:""}):(0,bn.jsx)("span",{className:"codicon codicon-file-media","aria-hidden":"true"})}),(0,bn.jsx)(_o,{className:"thumb-picker-check",checked:c,label:`Include ${l.label}`,onChange:()=>n(l.id)})]},l.id)})})}var S=W(me(),1),Sf={elements:["element"],images:["screenshot","recording"],errors:["errors","network"],other:["page","report","css","measure","color","text"]};function wf(e){let{items:t,targets:n,defaultTarget:o,canSend:a=!0}=e,[l,c]=(0,Pe.useState)("all"),[i,r]=(0,Pe.useState)(null),[d,v]=(0,Pe.useState)(new Set),[m,s]=(0,Pe.useState)(new Set),b=(0,Pe.useMemo)(()=>{let z={all:t.length,elements:0,images:0,errors:0,other:0};for(let F of t)for(let[ge,Qn]of Object.entries(Sf))Qn.includes(F.kind)&&z[ge]++;return z},[t]),y=l==="all"?t:t.filter(z=>Sf[l].includes(z.kind)),k=(0,Pe.useMemo)(()=>Yd(y),[y]),x=(0,Pe.useMemo)(()=>t.reduce((z,F)=>!z||F.time>z.time?F:z,void 0)?.id,[t]),f=df(n,o),u=n.find(z=>z.id===o),g=f.filter(z=>z.kind==="tmux"),p=a&&n.length>0,T=k.filter(z=>d.has(z.key)),A=T.flatMap(Oi).filter(z=>!m.has(z)),w=z=>{let F=new Set(m);F.has(z)?F.delete(z):F.add(z),s(F)},E=z=>{let F=new Set(d);F.has(z)?F.delete(z):F.add(z),v(F)},V=()=>v(new Set),D=(z,F)=>{let ge=z.getBoundingClientRect();r({x:Math.max(4,Math.min(ge.left,window.innerWidth-224)),y:ge.bottom+2,items:F})},ue={target:u,canChoose:p&&n.length>1,sending:p,canOpenThread:!!e.onOpenInAgentmux&&p&&g.length>0,send:z=>e.onSend(z),choose:(z,F)=>D(F,f.map(ge=>({label:ge.kind==="chat"?ge.label:`${ge.label} (${ge.detail})`,icon:ff(ge),onSelect:()=>e.onSend(z,ge.id)}))),openThread:(z,F)=>{let ge=e.onOpenInAgentmux;if(ge){if(g.length===1)return ge(z,g[0].id);D(F,g.map(Qn=>({label:`${Qn.label} (${Qn.detail})`,icon:"terminal-tmux",onSelect:()=>ge(z,Qn.id)})))}},copy:e.onCopy,open:e.onOpen,remove:e.onRemove,ungroup:e.onUngroup};return(0,S.jsxs)("div",{className:le("saved",T.length>0&&"selecting",e.className),children:[(e.header||e.filters&&t.length>0)&&(0,S.jsxs)("header",{className:"saved-header",children:[e.header,e.filters&&t.length>0&&(0,S.jsx)(xf,{size:"sm",label:"Show",value:l,onChange:c,className:"saved-filter",options:[{value:"all",label:"All",icon:"list-flat",count:b.all},{value:"elements",label:"Elements",icon:"inspect",count:b.elements||void 0},{value:"images",label:"Images",icon:"file-media",count:b.images||void 0},{value:"errors",label:"Errors",icon:"error",count:b.errors||void 0,tone:b.errors?"error":void 0},{value:"other",label:"Other",icon:"ellipsis",count:b.other||void 0}]})]}),t.length===0?e.empty:k.length===0?(0,S.jsx)("p",{className:"saved-none",children:"Nothing here yet."}):(0,S.jsx)("ul",{className:"saved-list","aria-label":"Saved captures",children:k.map(z=>z.kind==="item"?(0,S.jsx)(zp,{item:z.item,latest:z.item.id===x,thumbnail:e.thumbnails[z.item.id],actions:ue,selected:d.has(z.key),onSelect:()=>E(z.key)},z.key):(0,S.jsx)(Np,{group:z.group,items:z.items,latest:z.items.some(F=>F.id===x),thumbnails:e.thumbnails,actions:ue,selected:d.has(z.key),onSelect:()=>E(z.key),unchecked:m,onToggle:w},z.key))}),T.length>0?(0,S.jsxs)("footer",{className:"saved-footer saved-selection",role:"toolbar","aria-label":"Selection",children:[(0,S.jsxs)("span",{className:"saved-selection-count",children:[(0,S.jsx)("span",{className:"saved-selection-badge",children:A.length}),"selected"]}),p&&(0,S.jsx)($n,{size:"sm",variant:"accent",icon:"send",disabled:!A.length,title:u?`Send to ${u.label}`:"Send to an agent",onClick:()=>{e.onSend(A),V()},children:"Send"}),e.onGroup&&(0,S.jsx)($n,{size:"sm",variant:"ghost",icon:"layers",disabled:A.length<2,title:"Show them as one group, sent together",onClick:()=>{e.onGroup?.(A),V()},children:"Group"}),(0,S.jsx)(We,{icon:"trash",label:"Remove them",onClick:()=>{e.onRemove(T.flatMap(Oi)),V()}}),(0,S.jsx)(We,{icon:"close",label:"Clear the selection",onClick:V})]}):e.undo?(0,S.jsxs)("footer",{className:"saved-footer saved-undo",role:"status",children:[(0,S.jsxs)("span",{className:"saved-undo-text",children:[(0,S.jsx)("span",{className:"codicon codicon-trash","aria-hidden":"true"}),e.undo.label]}),(0,S.jsx)($n,{size:"sm",variant:"secondary",icon:"discard",onClick:e.undo.onUndo,children:"Undo"})]}):t.length>0&&(e.hint||e.onClear)&&(0,S.jsxs)("footer",{className:"saved-footer",children:[e.hint&&(0,S.jsx)("span",{className:"saved-hint",children:e.hint}),e.onClear&&(0,S.jsx)($n,{variant:"ghost",size:"sm",icon:"clear-all",onClick:e.onClear,children:"Clear all"})]}),i&&(0,S.jsx)(pf,{menu:i,onClose:()=>r(null)})]})}function Ef(e){return{onClick:t=>{(t.ctrlKey||t.metaKey||t.shiftKey)&&t.target.closest("button")===null&&(t.preventDefault(),e())}}}function zf({ids:e,label:t,sent:n,disabled:o,actions:a}){let l=(0,Pe.useRef)(null);return a.sending?(0,S.jsxs)("span",{className:"saved-send-group",children:[(0,S.jsxs)("span",{className:"saved-send",children:[(0,S.jsx)($n,{size:"sm",variant:n?"secondary":"accent",icon:n?"check":"send",disabled:o,onClick:()=>a.send(e),title:a.target?`Send to ${a.target.label}`:"Send to an agent",children:t}),a.canChoose&&(0,S.jsx)($n,{ref:l,size:"sm",variant:n?"secondary":"accent",icon:"chevron-down",className:"saved-send-more",disabled:o,"aria-label":"Send to\u2026",title:"Send to another agent",onClick:()=>l.current&&a.choose(e,l.current)})]}),a.canOpenThread&&(0,S.jsx)(We,{icon:"terminal-tmux",label:"Open in agentmux",disabled:o,onClick:c=>a.openThread(e,c.currentTarget)})]}):null}function zp({item:e,latest:t,thumbnail:n,actions:o,selected:a,onSelect:l}){let[c,i]=(0,Pe.useState)(!1),[r,d]=(0,Pe.useState)(!1),v=e.sentTo.length>0,m=n&&!c?n:void 0,s=o.open;return(0,S.jsxs)("li",{className:le("saved-card",`kind-${e.kind}`,t&&"latest",a&&"selected"),tabIndex:0,"aria-label":`${zi[e.kind]}: ${e.title}`,"aria-selected":a,onDoubleClick:s&&(()=>s(e.id)),...Ef(l),onKeyDown:b=>{b.target===b.currentTarget&&(b.key==="Enter"&&o.sending?o.send([e.id]):b.key===" "?(b.preventDefault(),l()):b.key==="Delete"||b.key==="Backspace"?o.remove([e.id]):b.key==="c"&&(b.ctrlKey||b.metaKey)&&o.copy?.(e.id))},children:[m&&(s?(0,S.jsx)("button",{type:"button",className:le("saved-thumb",r&&"tall"),"aria-label":`Open ${e.title}`,onClick:()=>s(e.id),children:(0,S.jsx)(Tf,{src:m,onBroken:()=>i(!0),onTall:d})}):(0,S.jsx)("div",{className:le("saved-thumb","still",r&&"tall"),children:(0,S.jsx)(Tf,{src:m,onBroken:()=>i(!0),onTall:d})})),(0,S.jsxs)("div",{className:"saved-card-head",children:[(0,S.jsx)(_o,{className:"saved-card-select",checked:a,label:`Select ${e.title}`,onChange:l}),!m&&(0,S.jsx)("span",{className:"saved-card-icon","aria-hidden":"true",children:(0,S.jsx)("span",{className:`codicon codicon-${Ei[e.kind]}`})}),(0,S.jsxs)("div",{className:"saved-card-heading",children:[(0,S.jsxs)("div",{className:"saved-card-title-row",children:[(0,S.jsx)("span",{className:"saved-card-title",title:e.title,children:e.title}),t&&(0,S.jsx)("span",{className:"saved-card-badge",children:"Latest"})]}),(0,S.jsxs)("div",{className:"saved-card-meta",children:[(0,S.jsx)("span",{children:zi[e.kind]}),e.detail&&(0,S.jsx)("span",{title:e.url,children:e.detail}),(0,S.jsx)("span",{children:Ni(e.time)}),e.source&&(0,S.jsx)("span",{children:e.source})]})]})]}),e.preview&&!m&&(0,S.jsx)("p",{className:"saved-card-preview",children:(0,S.jsx)("span",{children:e.preview})}),(0,S.jsxs)("div",{className:"saved-card-actions",children:[(0,S.jsx)(zf,{ids:[e.id],label:v?"Send again":"Send",sent:v,actions:o}),(0,S.jsxs)("span",{className:"saved-card-tools",children:[o.copy&&(0,S.jsx)(We,{icon:"copy",label:"Copy",onClick:()=>o.copy?.(e.id)}),s&&(0,S.jsx)(We,{icon:"go-to-file",label:"Open",onClick:()=>s(e.id)}),(0,S.jsx)(We,{icon:"trash",label:"Remove",onClick:()=>o.remove([e.id])})]})]}),v&&(0,S.jsx)(Nf,{agents:e.sentTo})]})}function Tf({src:e,onBroken:t,onTall:n}){return(0,S.jsx)("img",{src:e,alt:"",onError:t,onLoad:o=>{let{naturalWidth:a,naturalHeight:l}=o.currentTarget;n(a>0&&l/a>1.1)}})}function Np({group:e,items:t,latest:n,thumbnails:o,actions:a,selected:l,onSelect:c,unchecked:i,onToggle:r}){let d=t.filter(u=>!i.has(u.id)).map(u=>u.id),v=d.length===t.length,m=[...new Set(t.flatMap(u=>u.sentTo))],s=d.length>0&&d.every(u=>t.find(g=>g.id===u).sentTo.length),b=Ld(t),y=Math.max(...t.map(u=>u.time)),k=new Set(t.map(u=>u.kind)),x=k.size===1&&k.has("screenshot")?"screenshots":k.size===1&&k.has("element")?"elements":"items",f=a.open;return(0,S.jsxs)("li",{className:le("saved-card","saved-group",n&&"latest",l&&"selected"),tabIndex:0,"aria-label":`${t.length} ${x}: ${b}`,"aria-selected":l,...Ef(c),onKeyDown:u=>{u.target===u.currentTarget&&(u.key==="Enter"&&a.sending&&d.length?a.send(d):u.key===" "?(u.preventDefault(),c()):(u.key==="Delete"||u.key==="Backspace")&&a.remove(t.map(g=>g.id)))},children:[(0,S.jsxs)("div",{className:"saved-card-head",children:[(0,S.jsx)(_o,{className:"saved-card-select",checked:l,label:`Select ${b}`,onChange:c}),(0,S.jsx)("span",{className:"saved-card-icon","aria-hidden":"true",children:(0,S.jsx)("span",{className:"codicon codicon-layers"})}),(0,S.jsxs)("div",{className:"saved-card-heading",children:[(0,S.jsxs)("div",{className:"saved-card-title-row",children:[(0,S.jsx)("span",{className:"saved-card-title",title:b,children:b}),(0,S.jsx)("span",{className:"saved-card-count",children:t.length}),n&&(0,S.jsx)("span",{className:"saved-card-badge",children:"Latest"})]}),(0,S.jsxs)("div",{className:"saved-card-meta",children:[(0,S.jsx)("span",{children:v?`${t.length} ${x}`:`${d.length} of ${t.length} checked`}),t[0].detail&&(0,S.jsx)("span",{title:t[0].url,children:t[0].detail}),(0,S.jsx)("span",{children:Ni(y)}),t[0].source&&(0,S.jsx)("span",{children:t[0].source})]})]})]}),t.some(u=>u.image)?(0,S.jsx)(kf,{className:"saved-group-thumbs",items:t.map(u=>({id:u.id,src:o[u.id],label:u.title})),checked:new Set(d),onToggle:r,onOpen:f}):(0,S.jsx)("ul",{className:"saved-group-list","aria-label":b,children:t.map(u=>(0,S.jsxs)("li",{className:le("saved-group-row",!i.has(u.id)&&"on"),onDoubleClick:f&&(()=>f(u.id)),children:[(0,S.jsx)(_o,{checked:!i.has(u.id),label:`Include ${u.title}`,onChange:()=>r(u.id)}),(0,S.jsx)("span",{className:`codicon codicon-${Ei[u.kind]} saved-group-row-icon`,"aria-hidden":"true"}),(0,S.jsxs)("span",{className:"saved-group-row-text",children:[(0,S.jsx)("span",{className:"saved-group-row-title",title:u.title,children:u.title}),u.detail&&u.detail!==t[0].detail&&(0,S.jsx)("span",{className:"saved-group-row-detail",children:u.detail})]}),f&&(0,S.jsx)(We,{icon:"go-to-file",label:`Open ${u.title}`,className:"small saved-group-row-open",onClick:()=>f(u.id)})]},u.id))}),(0,S.jsxs)("div",{className:"saved-card-actions",children:[(0,S.jsx)(zf,{ids:d,label:v?`${s?"Send all again":"Send all"} ${t.length}`:`Send ${d.length} of ${t.length}`,sent:s,disabled:!d.length,actions:a}),(0,S.jsxs)("span",{className:"saved-card-tools",children:[a.ungroup&&(0,S.jsx)(We,{icon:"list-flat",label:"Ungroup (show them one by one)",onClick:()=>a.ungroup?.(e)}),(0,S.jsx)(We,{icon:"trash",label:"Remove the group",onClick:()=>a.remove(t.map(u=>u.id))})]})]}),m.length>0&&(0,S.jsx)(Nf,{agents:m})]})}function Nf({agents:e}){return(0,S.jsxs)("div",{className:"saved-card-sent",title:`Sent to ${e.join(", ")}`,children:[(0,S.jsx)("span",{className:"codicon codicon-pass-filled","aria-hidden":"true"}),(0,S.jsxs)("span",{children:["Sent to ",e.join(", ")]})]})}var Ge=W($t(),1),Df=W(qi(),1);var Ee=W(me(),1);function Hf({value:e,options:t,onChange:n,label:o,title:a,placeholder:l="Select\u2026",icon:c,renderValue:i,size:r="md",appearance:d="field",disabled:v,className:m,align:s="start"}){let[b,y]=(0,Ge.useState)(!1),[k,x]=(0,Ge.useState)(-1),[f,u]=(0,Ge.useState)(null),g=(0,Ge.useRef)(null),p=(0,Ge.useRef)(null),T=(0,Ge.useRef)({text:"",at:0}),A=(0,Ge.useId)(),w=t.findIndex(N=>N.value===e),E=t[w],V=(0,Ge.useCallback)(N=>{y(!1),(N==="escape"||N==="chosen")&&g.current?.focus()},[]);gf([g,p],b,V),sf(g,p,b,{align:s,matchWidth:!0});let D=N=>N>=0&&!t[N]?.disabled,ue=(N,fe)=>{for(let Et=1;Et<=t.length;Et++){let ft=(N+fe*Et+t.length*2)%t.length;if(D(ft))return ft}return N},z=(N=w)=>{x(D(N)?N:ue(-1,1)),u(mf(g.current)),y(!0)},F=N=>{let fe=t[N];!fe||fe.disabled||(V("chosen"),fe.value!==e&&n(fe.value))};(0,Ge.useLayoutEffect)(()=>{b&&(p.current?.querySelector(`[data-index="${k}"]`)?.scrollIntoView({block:"nearest"}),p.current?.focus({preventScroll:!0}))},[b,k]);let ge=N=>{let fe=Date.now(),Et=(fe-T.current.at<700?T.current.text:"")+N.toLowerCase();T.current={text:Et,at:fe};let ft=b?k:w,Ml=[...t.keys()].map(Cl=>(ft+(Et.length>1?0:1)+Cl)%t.length).find(Cl=>D(Cl)&&t[Cl].label.toLowerCase().startsWith(Et));Ml!==void 0&&(b?x(Ml):t[Ml].value!==e&&n(t[Ml].value))},Qn=N=>{["ArrowDown","ArrowUp","Enter"," "].includes(N.key)?(N.preventDefault(),z()):N.key.length===1&&!N.ctrlKey&&!N.metaKey&&!N.altKey&&ge(N.key)},Ym=N=>{let Et={ArrowDown:()=>x(ft=>ue(ft,1)),ArrowUp:()=>x(ft=>ue(ft,-1)),Home:()=>x(ue(-1,1)),End:()=>x(ue(t.length,-1)),PageDown:()=>x(ft=>Math.min(ue(ft,1)+7,ue(t.length,-1))),PageUp:()=>x(ft=>Math.max(ue(ft,-1)-7,ue(-1,1))),Enter:()=>F(k)," ":()=>T.current.text&&Date.now()-T.current.at<700?ge(" "):F(k),Tab:()=>V()}[N.key];Et?(N.key!=="Tab"&&N.preventDefault(),Et()):N.key.length===1&&!N.ctrlKey&&!N.metaKey&&!N.altKey&&ge(N.key)};return(0,Ee.jsxs)(Ee.Fragment,{children:[(0,Ee.jsxs)("button",{ref:g,type:"button",className:le("select",`size-${r}`,d==="quiet"&&"quiet",b&&"open",m),role:"combobox","aria-haspopup":"listbox","aria-expanded":b,"aria-controls":b?`${A}-list`:void 0,"aria-label":o,title:a??o,disabled:v,onClick:()=>b?V():z(),onKeyDown:Qn,children:[c&&(0,Ee.jsx)("span",{className:`codicon codicon-${c}`,"aria-hidden":"true"}),!c&&E?.icon&&(0,Ee.jsx)("span",{className:`codicon codicon-${E.icon}`,"aria-hidden":"true"}),(0,Ee.jsx)("span",{className:le("select-value",!E&&"placeholder"),children:E?i?i(E):E.label:l}),(0,Ee.jsx)("span",{className:"codicon codicon-chevron-down select-chevron","aria-hidden":"true"})]}),b&&f&&(0,Df.createPortal)((0,Ee.jsx)("div",{ref:p,id:`${A}-list`,className:"select-list","data-ink-popup":"",role:"listbox","aria-label":o,tabIndex:-1,"aria-activedescendant":k>=0?`${A}-${k}`:void 0,onKeyDown:Ym,children:t.map((N,fe)=>[N.group&&N.group!==t[fe-1]?.group?(0,Ee.jsx)("div",{className:"select-group",role:"presentation",children:N.group},`g-${N.group}`):null,(0,Ee.jsxs)("div",{id:`${A}-${fe}`,"data-index":fe,role:"option","aria-selected":fe===w,"aria-disabled":N.disabled||void 0,className:le("select-option",fe===k&&"active",fe===w&&"selected",N.disabled&&"disabled"),style:N.indent?{paddingLeft:4+N.indent*14}:void 0,onPointerMove:()=>!N.disabled&&x(fe),onClick:()=>F(fe),children:[(0,Ee.jsx)("span",{className:`codicon codicon-${fe===w?"check":"blank"} select-check`,"aria-hidden":"true"}),N.icon&&(0,Ee.jsx)("span",{className:`codicon codicon-${N.icon}`,"aria-hidden":"true"}),(0,Ee.jsx)("span",{className:"select-option-label",children:N.label}),N.detail&&(0,Ee.jsx)("span",{className:"select-option-detail",children:N.detail})]},N.value)])}),f)]})}var Be=W($t()),qm=W(Rm());var Um=`/* The side panel. The Saved list (SavedList), components and tokens come from @inkspect/shared/ui. */

* {
  box-sizing: border-box;
}

html,
body {
  margin: 0;
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  color: var(--vscode-foreground);
  font-family: var(--vscode-font-family);
  font-size: var(--vscode-font-size);
  line-height: 1.45;
}

.sp {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.sp-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--ink-space-2) var(--ink-space-3) 0;
}

.sp-title {
  font-size: var(--ink-font-lg);
  font-weight: 600;
}

.sp-empty,
.sp-target {
  color: var(--ink-muted);
}

.sp-empty {
  padding: var(--ink-space-2) var(--ink-space-3);
}

/* The project shown (the page's own, or one picked), and its pin. */
.sp-project {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  padding: var(--ink-space-2) var(--ink-space-3) 0;
}

.sp-project-select {
  flex: 1;
  min-width: 0;
}

.sp-dot {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: var(--ink-radius-pill);
  background: var(--ink-border-strong);
}

.sp-dot.on {
  background: var(--ink-success);
}

.sp-target,
.sp-note {
  padding: var(--ink-space-1) var(--ink-space-3) 0;
  font-size: var(--ink-font-sm);
}

.sp-note.ok {
  color: var(--ink-success);
}

.sp-note.error {
  color: var(--ink-danger);
}

/* The list fills the rest of the panel (its footer sticks to the bottom). */
.sp .saved {
  flex: 1;
}

@media (forced-colors: active) {
  .sp-dot.on {
    background: Highlight;
  }
}
`;var ne=W(me());async function To(e){return await chrome.runtime.sendMessage({type:"hub",request:{...e,req:crypto.randomUUID()}})??void 0}async function Uy(){let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return To({type:"projects.get",url:e?.url?.slice(0,4096)})}var Bm=e=>To({type:"items.get",project:e}).then(t=>t?.ok?t.items:[]);function By({project:e,canUndo:t}){let[n,o]=(0,Be.useState)(),[a,l]=(0,Be.useState)({}),[c,i]=(0,Be.useState)(),[r,d]=(0,Be.useState)(),v=Eo(e),m=e.targets??[],s=m.find(f=>f.id===e.defaultTarget);(0,Be.useEffect)(()=>{let f=!0,u=()=>{Bm(e.path).then(p=>{f&&o(p)})};u();let g=setInterval(u,4e3);return()=>{f=!1,clearInterval(g)}},[e.path]),(0,Be.useEffect)(()=>{let f=!0;for(let u of n??[])a[u.id]||!(u.files.thumb||u.files.file)||u.kind!=="recording"&&To({type:"item.thumb",project:e.path,id:u.id}).then(g=>{if(!f||!g?.data)return;let p=`data:${g.mimeType??"image/jpeg"};base64,${g.data}`;l(T=>({...T,[u.id]:p}))});return()=>{f=!1}},[n,a,e.path]);let b=()=>{Bm(e.path).then(o)},y=async(f,u,g=!1)=>{i(void 0);let p=await To({type:"item.send",project:e.path,ids:f,target:u,open:g});i(p?.ok?{text:`Sent to ${p.sentTo??"the agent"}.`,tone:"ok"}:{text:p?.error??"The browser helper did not answer.",tone:"error"}),b()},k=async f=>{await To({type:"item.remove",project:e.path,ids:f}),t&&d(f),b()},x=(0,Be.useMemo)(()=>(n??[]).map(Vd),[n]);return n?(0,ne.jsxs)(ne.Fragment,{children:[(0,ne.jsx)("div",{className:"sp-target",title:e.path,children:v?s?`Send goes to ${s.label} \xB7 ${s.detail}`:"No agent is running here.":"Nothing is open here: captures are kept, sending is off."}),c&&(0,ne.jsx)("div",{className:`sp-note ${c.tone}`,role:"status",children:c.text}),(0,ne.jsx)(wf,{items:x,thumbnails:a,targets:m,defaultTarget:e.defaultTarget,canSend:v,onSend:(f,u)=>{y(f,u)},onOpenInAgentmux:(f,u)=>{y(f,u,!0)},onRemove:f=>{k(f)},undo:r&&{label:r.length===1?"Removed 1 item":`Removed ${r.length} items`,onUndo:()=>{d(void 0),To({type:"item.restore",project:e.path,ids:r}).then(b)}},empty:(0,ne.jsxs)("div",{className:"sp-empty",children:["Nothing saved in ",e.name," yet. Capture something with the toolbar: it is saved here at once."]})})]}):(0,ne.jsx)("div",{className:"sp-empty",children:"Loading\u2026"})}function qy(){let[e,t]=(0,Be.useState)({state:"connecting"}),[n,o]=(0,Be.useState)(),[a,l]=(0,Be.useState)(),c=(0,Be.useCallback)(()=>{Uy().then(o)},[]);(0,Be.useEffect)(()=>{let v=()=>{chrome.runtime.sendMessage({type:"status"}).then(y=>y&&t(y)),c()};v();let m=setInterval(v,5e3),s=()=>{l(void 0),c()},b=(y,k)=>{(k.url||k.status==="complete")&&c()};return chrome.tabs.onActivated.addListener(s),chrome.tabs.onUpdated.addListener(b),()=>{clearInterval(m),chrome.tabs.onActivated.removeListener(s),chrome.tabs.onUpdated.removeListener(b)}},[c]);let i=n?.projects??[],r=i.find(v=>v.path===a)??i.find(v=>v.path===n?.suggested)??i[0],d=!!e.projects;return(0,ne.jsxs)("main",{className:"sp",children:[(0,ne.jsxs)("header",{className:"sp-head",children:[(0,ne.jsx)("span",{className:"sp-title",children:"Saved"}),(0,ne.jsx)(We,{icon:"refresh",label:"Refresh",onClick:c})]}),d?n?r?(0,ne.jsxs)(ne.Fragment,{children:[(0,ne.jsxs)("div",{className:"sp-project",children:[(0,ne.jsx)("span",{className:`sp-dot ${Eo(r)?"on":""}`,"aria-hidden":"true"}),(0,ne.jsx)(Hf,{size:"sm",label:"Project",icon:r.inbox?"inbox":"folder",className:"sp-project-select",value:r.path,onChange:l,options:i.map(v=>({value:v.path,label:v.name,detail:Gd(v),icon:v.inbox?"inbox":v.pinned?"pinned":v.vscode?"vscode":"folder",group:v.inbox?"Inbox":Eo(v)?"Open":"Saved"}))}),!r.inbox&&(0,ne.jsx)(We,{icon:r.pinned?"pinned":"pin",label:r.pinned?`Unpin ${r.name}`:`Pin ${r.name}`,active:r.pinned,onClick:()=>{To({type:"project.pin",project:r.path,pinned:!r.pinned}).then(c)}})]}),(0,ne.jsx)(By,{project:r,canUndo:!!e.features?.includes("item.restore")},r.path)]}):(0,ne.jsx)("div",{className:"sp-empty",children:"No projects yet: open a folder in VS Code, or start an agent in agentmux."}):(0,ne.jsx)("div",{className:"sp-empty",children:"Loading\u2026"}):(0,ne.jsx)("div",{className:"sp-empty",children:"Not linked with VS Code. Open VS Code with VS Code Browser: on Linux its browser helper links this browser by itself (restart the browser once); elsewhere, pair it from the Inkspect button."})]})}var jm=document.createElement("style");jm.textContent=[Ud,Xd,Qd,Um].join(`
`);document.head.append(jm);document.documentElement.classList.add("ink-theme");(0,qm.createRoot)(document.getElementById("root")).render((0,ne.jsx)(qy,{}));})();
