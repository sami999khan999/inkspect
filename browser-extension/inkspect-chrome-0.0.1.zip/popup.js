"use strict";(()=>{var Zg=Object.create;var $r=Object.defineProperty;var Kg=Object.getOwnPropertyDescriptor;var Jg=Object.getOwnPropertyNames;var Fg=Object.getPrototypeOf,Wg=Object.prototype.hasOwnProperty;var dt=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports}catch(n){throw t=0,n}};var $g=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of Jg(t))!Wg.call(e,a)&&a!==n&&$r(e,a,{get:()=>t[a],enumerable:!(o=Kg(t,a))||o.enumerable});return e};var Be=(e,t,n)=>(n=e!=null?Zg(Fg(e)):{},$g(t||!e||!e.__esModule?$r(n,"default",{value:e,enumerable:!0}):n,e));var xf=dt(w=>{"use strict";var Vc=Symbol.for("react.transitional.element"),nm=Symbol.for("react.portal"),om=Symbol.for("react.fragment"),am=Symbol.for("react.strict_mode"),lm=Symbol.for("react.profiler"),cm=Symbol.for("react.consumer"),im=Symbol.for("react.context"),um=Symbol.for("react.forward_ref"),rm=Symbol.for("react.suspense"),fm=Symbol.for("react.memo"),bf=Symbol.for("react.lazy"),dm=Symbol.for("react.activity"),sm=Symbol.for("react.view_transition"),rf=Symbol.iterator;function bm(e){return e===null||typeof e!="object"?null:(e=rf&&e[rf]||e["@@iterator"],typeof e=="function"?e:null)}var vf={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},gf=Object.assign,mf={};function Fn(e,t,n){this.props=e,this.context=t,this.refs=mf,this.updater=n||vf}Fn.prototype.isReactComponent={};Fn.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};Fn.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function pf(){}pf.prototype=Fn.prototype;function Qc(e,t,n){this.props=e,this.context=t,this.refs=mf,this.updater=n||vf}var Xc=Qc.prototype=new pf;Xc.constructor=Qc;gf(Xc,Fn.prototype);Xc.isPureReactComponent=!0;var ff=Array.isArray;function Lc(){}var Z={H:null,A:null,T:null,S:null},hf=Object.prototype.hasOwnProperty;function Zc(e,t,n){var o=n.ref;return{$$typeof:Vc,type:e,key:t,ref:o!==void 0?o:null,props:n}}function vm(e,t){return Zc(e.type,t,e.props)}function Kc(e){return typeof e=="object"&&e!==null&&e.$$typeof===Vc}function gm(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var df=/\/+/g;function jc(e,t){return typeof e=="object"&&e!==null&&e.key!=null?gm(""+e.key):t.toString(36)}function mm(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(Lc,Lc):(e.status="pending",e.then(function(t){e.status==="pending"&&(e.status="fulfilled",e.value=t)},function(t){e.status==="pending"&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function Jn(e,t,n,o,a){var l=typeof e;(l==="undefined"||l==="boolean")&&(e=null);var c=!1;if(e===null)c=!0;else switch(l){case"bigint":case"string":case"number":c=!0;break;case"object":switch(e.$$typeof){case Vc:case nm:c=!0;break;case bf:return c=e._init,Jn(c(e._payload),t,n,o,a)}}if(c)return a=a(e),c=o===""?"."+jc(e,0):o,ff(a)?(n="",c!=null&&(n=c.replace(df,"$&/")+"/"),Jn(a,t,n,"",function(f){return f})):a!=null&&(Kc(a)&&(a=vm(a,n+(a.key==null||e&&e.key===a.key?"":(""+a.key).replace(df,"$&/")+"/")+c)),t.push(a)),1;c=0;var i=o===""?".":o+":";if(ff(e))for(var u=0;u<e.length;u++)o=e[u],l=i+jc(o,u),c+=Jn(o,t,n,l,a);else if(u=bm(e),typeof u=="function")for(e=u.call(e),u=0;!(o=e.next()).done;)o=o.value,l=i+jc(o,u++),c+=Jn(o,t,n,l,a);else if(l==="object"){if(typeof e.then=="function")return Jn(mm(e),t,n,o,a);throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return c}function el(e,t,n){if(e==null)return e;var o=[],a=0;return Jn(e,o,"","",function(l){return t.call(n,l,a++)}),o}function pm(e){if(e._status===-1){var t=e._result,n=t();n.then(function(o){(e._status===0||e._status===-1)&&(e._status=1,e._result=o,n.status===void 0&&(n.status="fulfilled",n.value=o))},function(o){(e._status===0||e._status===-1)&&(e._status=2,e._result=o,n.status===void 0&&(n.status="rejected",n.reason=o))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var sf=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)};function yf(e){var t=Z.T,n={};n.types=t!==null?t.types:null,Z.T=n;try{var o=e(),a=Z.S;a!==null&&a(n,o),typeof o=="object"&&o!==null&&typeof o.then=="function"&&o.then(Lc,sf)}catch(l){sf(l)}finally{t!==null&&n.types!==null&&(t.types=n.types),Z.T=t}}function Sf(e){var t=Z.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else yf(Sf.bind(null,e))}var hm={map:el,forEach:function(e,t,n){el(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return el(e,function(){t++}),t},toArray:function(e){return el(e,function(t){return t})||[]},only:function(e){if(!Kc(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};w.Activity=dm;w.Children=hm;w.Component=Fn;w.Fragment=om;w.Profiler=lm;w.PureComponent=Qc;w.StrictMode=am;w.Suspense=rm;w.ViewTransition=sm;w.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=Z;w.__COMPILER_RUNTIME={__proto__:null,c:function(e){return Z.H.useMemoCache(e)}};w.addTransitionType=Sf;w.cache=function(e){return function(){return e.apply(null,arguments)}};w.cacheSignal=function(){return null};w.cloneElement=function(e,t,n){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var o=gf({},e.props),a=e.key;if(t!=null)for(l in t.key!==void 0&&(a=""+t.key),t)!hf.call(t,l)||l==="key"||l==="__self"||l==="__source"||l==="ref"&&t.ref===void 0||(o[l]=t[l]);var l=arguments.length-2;if(l===1)o.children=n;else if(1<l){for(var c=Array(l),i=0;i<l;i++)c[i]=arguments[i+2];o.children=c}return Zc(e.type,a,o)};w.createContext=function(e){return e={$$typeof:im,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:cm,_context:e},e};w.createElement=function(e,t,n){var o,a={},l=null;if(t!=null)for(o in t.key!==void 0&&(l=""+t.key),t)hf.call(t,o)&&o!=="key"&&o!=="__self"&&o!=="__source"&&(a[o]=t[o]);var c=arguments.length-2;if(c===1)a.children=n;else if(1<c){for(var i=Array(c),u=0;u<c;u++)i[u]=arguments[u+2];a.children=i}if(e&&e.defaultProps)for(o in c=e.defaultProps,c)a[o]===void 0&&(a[o]=c[o]);return Zc(e,l,a)};w.createRef=function(){return{current:null}};w.forwardRef=function(e){return{$$typeof:um,render:e}};w.isValidElement=Kc;w.lazy=function(e){return{$$typeof:bf,_payload:{_status:-1,_result:e},_init:pm}};w.memo=function(e,t){return{$$typeof:fm,type:e,compare:t===void 0?null:t}};w.startTransition=yf;w.unstable_useCacheRefresh=function(){return Z.H.useCacheRefresh()};w.use=function(e){return Z.H.use(e)};w.useActionState=function(e,t,n){return Z.H.useActionState(e,t,n)};w.useCallback=function(e,t){return Z.H.useCallback(e,t)};w.useContext=function(e){return Z.H.useContext(e)};w.useDebugValue=function(){};w.useDeferredValue=function(e,t){return Z.H.useDeferredValue(e,t)};w.useEffect=function(e,t){return Z.H.useEffect(e,t)};w.useEffectEvent=function(e){return Z.H.useEffectEvent(e)};w.useId=function(){return Z.H.useId()};w.useImperativeHandle=function(e,t,n){return Z.H.useImperativeHandle(e,t,n)};w.useInsertionEffect=function(e,t){return Z.H.useInsertionEffect(e,t)};w.useLayoutEffect=function(e,t){return Z.H.useLayoutEffect(e,t)};w.useMemo=function(e,t){return Z.H.useMemo(e,t)};w.useOptimistic=function(e,t){return Z.H.useOptimistic(e,t)};w.useReducer=function(e,t,n){return Z.H.useReducer(e,t,n)};w.useRef=function(e){return Z.H.useRef(e)};w.useState=function(e){return Z.H.useState(e)};w.useSyncExternalStore=function(e,t,n){return Z.H.useSyncExternalStore(e,t,n)};w.useTransition=function(){return Z.H.useTransition()};w.version="19.3.0"});var Jo=dt((Q0,kf)=>{"use strict";kf.exports=xf()});var zf=dt(tl=>{"use strict";var Sm=Symbol.for("react.transitional.element"),xm=Symbol.for("react.fragment");function wf(e,t,n){var o=null;if(n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),"key"in t){n={};for(var a in t)a!=="key"&&(n[a]=t[a])}else n=t;return t=n.ref,{$$typeof:Sm,type:e,key:o,ref:t!==void 0?t:null,props:n}}tl.Fragment=xm;tl.jsx=wf;tl.jsxs=wf});var at=dt((K0,Of)=>{"use strict";Of.exports=zf()});var qf=dt(W=>{"use strict";function ti(e,t){var n=e.length;e.push(t);e:for(;0<n;){var o=n-1>>>1,a=e[o];if(0<nl(a,t))e[o]=t,e[n]=a,n=o;else break e}}function st(e){return e.length===0?null:e[0]}function al(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;e:for(var o=0,a=e.length,l=a>>>1;o<l;){var c=2*(o+1)-1,i=e[c],u=c+1,f=e[u];if(0>nl(i,n))u<a&&0>nl(f,i)?(e[o]=f,e[u]=n,o=u):(e[o]=i,e[c]=n,o=c);else if(u<a&&0>nl(f,n))e[o]=f,e[u]=n,o=u;else break e}}return t}function nl(e,t){var n=e.sortIndex-t.sortIndex;return n!==0?n:e.id-t.id}W.unstable_now=void 0;typeof performance=="object"&&typeof performance.now=="function"?(Af=performance,W.unstable_now=function(){return Af.now()}):(Ic=Date,_f=Ic.now(),W.unstable_now=function(){return Ic.now()-_f});var Af,Ic,_f,Ot=[],Qt=[],Tm=1,Je=null,xe=3,ni=!1,Wo=!1,$o=!1,oi=!1,Df=typeof setTimeout=="function"?setTimeout:null,Rf=typeof clearTimeout=="function"?clearTimeout:null,Cf=typeof setImmediate<"u"?setImmediate:null;function ol(e){for(var t=st(Qt);t!==null;){if(t.callback===null)al(Qt);else if(t.startTime<=e)al(Qt),t.sortIndex=t.expirationTime,ti(Ot,t);else break;t=st(Qt)}}function ai(e){if($o=!1,ol(e),!Wo)if(st(Ot)!==null)Wo=!0,In||(In=!0,$n());else{var t=st(Qt);t!==null&&li(ai,t.startTime-e)}}var In=!1,Io=-1,Uf=5,Bf=-1;function Hf(){return oi?!0:!(W.unstable_now()-Bf<Uf)}function Pc(){if(oi=!1,In){var e=W.unstable_now();Bf=e;var t=!0;try{e:{Wo=!1,$o&&($o=!1,Rf(Io),Io=-1),ni=!0;var n=xe;try{t:{for(ol(e),Je=st(Ot);Je!==null&&!(Je.expirationTime>e&&Hf());){var o=Je.callback;if(typeof o=="function"){Je.callback=null,xe=Je.priorityLevel;var a=o(Je.expirationTime<=e);if(e=W.unstable_now(),typeof a=="function"){Je.callback=a,ol(e),t=!0;break t}Je===st(Ot)&&al(Ot),ol(e)}else al(Ot);Je=st(Ot)}if(Je!==null)t=!0;else{var l=st(Qt);l!==null&&li(ai,l.startTime-e),t=!1}}break e}finally{Je=null,xe=n,ni=!1}t=void 0}}finally{t?$n():In=!1}}}var $n;typeof Cf=="function"?$n=function(){Cf(Pc)}:typeof MessageChannel<"u"?(ei=new MessageChannel,Mf=ei.port2,ei.port1.onmessage=Pc,$n=function(){Mf.postMessage(null)}):$n=function(){Df(Pc,0)};var ei,Mf;function li(e,t){Io=Df(function(){e(W.unstable_now())},t)}W.unstable_IdlePriority=5;W.unstable_ImmediatePriority=1;W.unstable_LowPriority=4;W.unstable_NormalPriority=3;W.unstable_Profiling=null;W.unstable_UserBlockingPriority=2;W.unstable_cancelCallback=function(e){e.callback=null};W.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):Uf=0<e?Math.floor(1e3/e):5};W.unstable_getCurrentPriorityLevel=function(){return xe};W.unstable_next=function(e){switch(xe){case 1:case 2:case 3:var t=3;break;default:t=xe}var n=xe;xe=t;try{return e()}finally{xe=n}};W.unstable_requestPaint=function(){oi=!0};W.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=xe;xe=e;try{return t()}finally{xe=n}};W.unstable_scheduleCallback=function(e,t,n){var o=W.unstable_now();switch(typeof n=="object"&&n!==null?(n=n.delay,n=typeof n=="number"&&0<n?o+n:o):n=o,e){case 1:var a=-1;break;case 2:a=250;break;case 5:a=1073741823;break;case 4:a=1e4;break;default:a=5e3}return a=n+a,e={id:Tm++,callback:t,priorityLevel:e,startTime:n,expirationTime:a,sortIndex:-1},n>o?(e.sortIndex=n,ti(Qt,e),st(Ot)===null&&e===st(Qt)&&($o?(Rf(Io),Io=-1):$o=!0,li(ai,n-o))):(e.sortIndex=a,ti(Ot,e),Wo||ni||(Wo=!0,In||(In=!0,$n()))),e};W.unstable_shouldYield=Hf;W.unstable_wrapCallback=function(e){var t=xe;return function(){var n=xe;xe=t;try{return e.apply(this,arguments)}finally{xe=n}}}});var Gf=dt((ey,Yf)=>{"use strict";Yf.exports=qf()});var Vf=dt(ke=>{"use strict";var Em=Jo();function Lf(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function Xt(){}var Ee={d:{f:Xt,r:function(){throw Error(Lf(522))},D:Xt,C:Xt,L:Xt,m:Xt,X:Xt,S:Xt,M:Xt},p:0,findDOMNode:null},wm=Symbol.for("react.portal"),zm=Symbol.for("react.recoverable"),jf=Symbol.for("react.optimistic_key");function Om(e,t,n){var o=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:wm,key:o==null?null:o===jf?jf:""+o,children:e,containerInfo:t,implementation:n}}var Po=Em.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function ll(e,t){if(e==="font")return"";if(typeof t=="string")return t==="use-credentials"?t:""}ke.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=Ee;ke.browser=function(e){return{$$typeof:zm,_reason:e}};ke.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(Lf(299));return Om(e,t,null,n)};ke.flushSync=function(e){var t=Po.T,n=Ee.p;try{if(Po.T=null,Ee.p=2,e)return e()}finally{Po.T=t,Ee.p=n,Ee.d.f()}};ke.preconnect=function(e,t){typeof e=="string"&&(t?(t=t.crossOrigin,t=typeof t=="string"?t==="use-credentials"?t:"":void 0):t=null,Ee.d.C(e,t))};ke.prefetchDNS=function(e){typeof e=="string"&&Ee.d.D(e)};ke.preinit=function(e,t){if(typeof e=="string"&&t&&typeof t.as=="string"){var n=t.as,o=ll(n,t.crossOrigin),a=typeof t.integrity=="string"?t.integrity:void 0,l=typeof t.fetchPriority=="string"?t.fetchPriority:void 0;n==="style"?Ee.d.S(e,typeof t.precedence=="string"?t.precedence:void 0,{crossOrigin:o,integrity:a,fetchPriority:l}):n==="script"&&Ee.d.X(e,{crossOrigin:o,integrity:a,fetchPriority:l,nonce:typeof t.nonce=="string"?t.nonce:void 0})}};ke.preinitModule=function(e,t){if(typeof e=="string")if(typeof t=="object"&&t!==null){if(t.as==null||t.as==="script"){var n=ll(t.as,t.crossOrigin);Ee.d.M(e,{crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}}else t==null&&Ee.d.M(e)};ke.preload=function(e,t){if(typeof e=="string"&&typeof t=="object"&&t!==null&&typeof t.as=="string"){var n=t.as,o=ll(n,t.crossOrigin);Ee.d.L(e,n,{crossOrigin:o,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,type:typeof t.type=="string"?t.type:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy=="string"?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet=="string"?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes=="string"?t.imageSizes:void 0,media:typeof t.media=="string"?t.media:void 0})}};ke.preloadModule=function(e,t){if(typeof e=="string")if(t){var n=ll(t.as,t.crossOrigin);Ee.d.m(e,{as:typeof t.as=="string"&&t.as!=="script"?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}else Ee.d.m(e)};ke.requestFormReset=function(e){Ee.d.r(e)};ke.unstable_batchedUpdates=function(e,t){return e(t)};ke.useFormState=function(e,t,n){return Po.H.useFormState(e,t,n)};ke.useFormStatus=function(){return Po.H.useHostTransitionStatus()};ke.version="19.3.0"});var Zf=dt((ny,Xf)=>{"use strict";function Qf(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Qf)}catch(e){console.error(e)}}Qf(),Xf.exports=Vf()});var Mg=dt(Gc=>{"use strict";var re=Gf(),Cs=Jo(),Nm=Zf();function h(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function Ms(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Ga(e){for(var t=e,n=t;n&&!n.alternate;)t=n,(t.flags&4098)!==0&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function Ds(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Rs(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Kf(e){if(Ga(e)!==e)throw Error(h(188))}function Am(e){var t=e.alternate;if(!t){if(t=Ga(e),t===null)throw Error(h(188));return t!==e?null:e}for(var n=e,o=t;;){var a=n.return;if(a===null)break;var l=a.alternate;if(l===null){if(o=a.return,o!==null){n=o;continue}break}if(a.child===l.child){for(l=a.child;l;){if(l===n)return Kf(a),e;if(l===o)return Kf(a),t;l=l.sibling}throw Error(h(188))}if(n.return!==o.return)n=a,o=l;else{for(var c=!1,i=a.child;i;){if(i===n){c=!0,n=a,o=l;break}if(i===o){c=!0,o=a,n=l;break}i=i.sibling}if(!c){for(i=l.child;i;){if(i===n){c=!0,n=l,o=a;break}if(i===o){c=!0,o=l,n=a;break}i=i.sibling}if(!c)throw Error(h(189))}}if(n.alternate!==o)throw Error(h(190))}if(n.tag!==3)throw Error(h(188));return n.stateNode.current===n?e:t}function Us(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=Us(e),t!==null)return t;e=e.sibling}return null}function Re(e,t,n,o,a,l){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,o,a,l)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&Re(e.child,t,n,o,a,l))return!0;e=e.sibling}return!1}function Ln(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function Jf(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),!(e.tag===3||e.tag===5||e.tag===27));)e=e.return;return t}function Bs(e){var t=[null,null],n=Ln(e);return n===null||Hs(t,e,n.child,{foundSelf:!1}),t}function Hs(e,t,n,o){for(;n!==null;){if(n===t)o.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(o.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&Hs(e,t,n.child,o))return!0;n=n.sibling}return!1}function ue(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(h(559))}}var lo=null,Hi=null;function _m(e,t,n){return e===n?!0:e===t?(lo=e,!0):!1}function Cm(e,t,n){return e===n?(Hi=e,!1):e===t?(Hi!==null&&(lo=e),!0):!1}function Ff(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function qi(e,t,n){for(var o=0,a=e;a;a=n(a))o++;a=0;for(var l=t;l;l=n(l))a++;for(;0<o-a;)e=n(e),o--;for(;0<a-o;)t=n(t),a--;for(;o--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var X=Object.assign,Mm=Symbol.for("react.element"),cl=Symbol.for("react.transitional.element"),ca=Symbol.for("react.portal"),co=Symbol.for("react.fragment"),qs=Symbol.for("react.strict_mode"),Yi=Symbol.for("react.profiler"),Ys=Symbol.for("react.consumer"),ht=Symbol.for("react.context"),Ju=Symbol.for("react.forward_ref"),Gi=Symbol.for("react.suspense"),ji=Symbol.for("react.suspense_list"),Fu=Symbol.for("react.memo"),Ft=Symbol.for("react.lazy"),Li=Symbol.for("react.activity"),Dm=Symbol.for("react.legacy_hidden"),Rm=Symbol.for("react.memo_cache_sentinel"),Vi=Symbol.for("react.view_transition"),Um=Symbol.for("react.recoverable"),Wf=Symbol.iterator;function ea(e){return e===null||typeof e!="object"?null:(e=Wf&&e[Wf]||e["@@iterator"],typeof e=="function"?e:null)}var Bm=Symbol.for("react.client.reference");function Qi(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===Bm?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case co:return"Fragment";case Yi:return"Profiler";case qs:return"StrictMode";case Gi:return"Suspense";case ji:return"SuspenseList";case Li:return"Activity";case Vi:return"ViewTransition"}if(typeof e=="object")switch(e.$$typeof){case ca:return"Portal";case ht:return e.displayName||"Context";case Ys:return(e._context.displayName||"Context")+".Consumer";case Ju:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Fu:return t=e.displayName||null,t!==null?t:Qi(e.type)||"Memo";case Ft:t=e._payload,e=e._init;try{return Qi(e(t))}catch{}}return null}var ia=Array.isArray,E=Cs.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,q=Nm.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,An={pending:!1,data:null,method:null,action:null},Xi=[],io=-1;function wt(e){return{current:e}}function pe(e){0>io||(e.current=Xi[io],Xi[io]=null,io--)}function F(e,t){io++,Xi[io]=e.current,e.current=t}var kt=wt(null),Ea=wt(null),an=wt(null),Zl=wt(null);function Kl(e,t){switch(F(an,t),F(Ea,e),F(kt,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?fs(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=fs(t),e=ig(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}pe(kt),F(kt,e)}function No(){pe(kt),pe(Ea),pe(an)}function Zi(e){var t=e.memoizedState;t!==null&&(qo._currentValue=t.memoizedState,F(Zl,e)),t=kt.current;var n=ig(t,e.type);t!==n&&(F(Ea,e),F(kt,n))}function Jl(e){Ea.current===e&&(pe(kt),pe(Ea)),Zl.current===e&&(pe(Zl),qo._currentValue=An)}var ci,$f;function Kt(e){if(ci===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);ci=t&&t[1]||"",$f=-1<n.stack.indexOf(`
    at`)?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return`
`+ci+e+$f}var ii=!1;function ui(e,t){if(!e||ii)return"";ii=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(t){var m=function(){throw Error()};if(Object.defineProperty(m.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(m,[])}catch(y){var d=y}Reflect.construct(e,[],m)}else{try{m.call()}catch(y){d=y}m=!1;try{var v=Object.getOwnPropertyDescriptor(e.prototype,"props");Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),m=!0,new e}finally{m&&(v!==void 0?Object.defineProperty(e.prototype,"props",v):delete e.prototype.props)}}}else{try{throw Error()}catch(y){d=y}(m=e())&&typeof m.catch=="function"&&m.catch(function(){})}}catch(y){if(y&&d&&typeof y.stack=="string")return[y.stack,d.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var a=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");a&&a.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var l=o.DetermineComponentFrameRoot(),c=l[0],i=l[1];if(c&&i){var u=c.split(`
`),f=i.split(`
`);for(a=o=0;o<u.length&&!u[o].includes("DetermineComponentFrameRoot");)o++;for(;a<f.length&&!f[a].includes("DetermineComponentFrameRoot");)a++;if(o===u.length||a===f.length)for(o=u.length-1,a=f.length-1;1<=o&&0<=a&&u[o]!==f[a];)a--;for(;1<=o&&0<=a;o--,a--)if(u[o]!==f[a]){if(o!==1||a!==1)do if(o--,a--,0>a||u[o]!==f[a]){var g=`
`+u[o].replace(" at new "," at ");return e.displayName&&g.includes("<anonymous>")&&(g=g.replace("<anonymous>",e.displayName)),g}while(1<=o&&0<=a);break}}}finally{ii=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?Kt(n):""}function Hm(e,t){switch(e.tag){case 26:case 27:case 5:return Kt(e.type);case 16:return Kt("Lazy");case 13:return e.child!==t&&t!==null?Kt("Suspense Fallback"):Kt("Suspense");case 19:return Kt("SuspenseList");case 0:case 15:return ui(e.type,!1);case 11:return ui(e.type.render,!1);case 1:return ui(e.type,!0);case 31:return Kt("Activity");case 30:return Kt("ViewTransition");default:return""}}function If(e){try{var t="",n=null;do t+=Hm(e,n),n=e,e=e.return;while(e);return t}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var Ki=Object.prototype.hasOwnProperty,Wu=re.unstable_scheduleCallback,ri=re.unstable_cancelCallback,qm=re.unstable_shouldYield,Ym=re.unstable_requestPaint,Le=re.unstable_now,Gm=re.unstable_getCurrentPriorityLevel,Gs=re.unstable_ImmediatePriority,js=re.unstable_UserBlockingPriority,Fl=re.unstable_NormalPriority,jm=re.unstable_LowPriority,Ls=re.unstable_IdlePriority,Lm=re.log,Vm=re.unstable_setDisableYieldValue,ja=null,Ve=null;function It(e){if(typeof Lm=="function"&&Vm(e),Ve&&typeof Ve.setStrictMode=="function")try{Ve.setStrictMode(ja,e)}catch{}}var Qe=Math.clz32?Math.clz32:Zm,Qm=Math.log,Xm=Math.LN2;function Zm(e){return e>>>=0,e===0?32:31-(Qm(e)/Xm|0)|0}var il=256,ul=262144,rl=4194304;function En(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function xc(e,t,n){var o=e.pendingLanes;if(o===0)return 0;var a=0,l=e.suspendedLanes,c=e.pingedLanes;e=e.warmLanes;var i=o&134217727;return i!==0?(o=i&~l,o!==0?a=En(o):(c&=i,c!==0?a=En(c):n||(n=i&~e,n!==0&&(a=En(n))))):(i=o&~l,i!==0?a=En(i):c!==0?a=En(c):n||(n=o&~e,n!==0&&(a=En(n)))),a===0?0:t!==0&&t!==a&&(t&l)===0&&(l=a&-a,n=t&-t,l>=n||l===32&&(n&4194048)!==0)?t:a}function La(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Vs(e,t){(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var o=31-Qe(n),a=1<<o;t|=e[o],n&=~a}return t}function Km(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Qs(){var e=rl;return rl<<=1,(rl&62914560)===0&&(rl=4194304),e}function fi(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Va(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Jm(e,t,n,o,a,l){var c=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var i=e.entanglements,u=e.expirationTimes,f=e.hiddenUpdates;for(n=c&~n;0<n;){var g=31-Qe(n),m=1<<g;i[g]=0,u[g]=-1;var d=f[g];if(d!==null)for(f[g]=null,g=0;g<d.length;g++){var v=d[g];v!==null&&(v.lane&=-536870913)}n&=~m}o!==0&&Xs(e,o,0),l!==0&&a===0&&e.tag!==0&&(e.suspendedLanes|=l&~(c&~t))}function Xs(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var o=31-Qe(t);e.entangledLanes|=t,e.entanglements[o]=e.entanglements[o]|1073741824|n&261930}function Zs(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var o=31-Qe(n),a=1<<o;a&t|e[o]&t&&(e[o]|=t),n&=~a}}function Ks(e,t){var n=t&-t;return n=(n&42)!==0?1:$u(n),(n&(e.suspendedLanes|t))!==0?0:n}function $u(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Iu(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Js(){var e=q.p;return e!==0?e:(e=window.event,e===void 0?32:Ag(e.type))}function Pf(e,t){var n=q.p;try{return q.p=e,t()}finally{q.p=n}}var Gt=Math.random().toString(36).slice(2),ge="__reactFiber$"+Gt,Ue="__reactProps$"+Gt,jo="__reactContainer$"+Gt,ed="__reactEvents$"+Gt,Fm="__reactListeners$"+Gt,Wm="__reactHandles$"+Gt,td="__reactResources$"+Gt,Qa="__reactMarker$"+Gt,Wl="__reactLoad$"+Gt;function kc(e){delete e[ge],delete e[Ue],delete e[Fm],delete e[Wm]}function On(e){var t;if(t=e[ge])return t;for(var n=e.parentNode;n;){if(t=n[jo]||n[ge]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=hs(e);e!==null;){if(n=e[ge])return n;e=hs(e)}return t}e=n,n=e.parentNode}return null}function Lo(e){if(e=e[ge]||e[jo]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function ua(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(h(33))}function ho(e){var t=e[td];return t||(t=e[td]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function se(e){e[Qa]=!0}function Fs(e){e[Wl]=void 0}var Ws=new Set,$s={};function Vn(e,t){Ao(e,t),Ao(e+"Capture",t)}function Ao(e,t){for($s[e]=t,e=0;e<t.length;e++)Ws.add(t[e])}var $m=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),nd={},od={};function Im(e){return Ki.call(od,e)?!0:Ki.call(nd,e)?!1:$m.test(e)?od[e]=!0:(nd[e]=!0,!1)}var B=!1;function ad(){var e=B;return B=!1,e}function Ol(e,t,n){if(Im(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var o=t.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,n)}}function fl(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,n)}}function Nt(e,t,n,o){if(o===null)e.removeAttribute(n);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,o)}}function qe(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Is(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Pm(e,t,n){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var a=o.get,l=o.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return a.call(this)},set:function(c){n=""+c,l.call(this,c)}}),Object.defineProperty(e,t,{enumerable:o.enumerable}),{getValue:function(){return n},setValue:function(c){n=""+c},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Ji(e){if(!e._valueTracker){var t=Is(e)?"checked":"value";e._valueTracker=Pm(e,t,""+e[t])}}function Ps(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),o="";return e&&(o=Is(e)?e.checked?"true":"false":e.value),e=o,e!==n?(t.setValue(e),!0):!1}var ep=/[\n"\\]/g;function Pe(e){return e.replace(ep,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function Fi(e,t,n,o,a,l,c,i){e.name="",c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"?e.type=c:e.removeAttribute("type"),t!=null?c==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+qe(t)):e.value!==""+qe(t)&&(e.value=""+qe(t)):c!=="submit"&&c!=="reset"||e.removeAttribute("value"),t!=null?c==="number"&&e.value==t?di(e,qe(e.value)):di(e,qe(t)):n!=null?di(e,qe(n)):o!=null&&e.removeAttribute("value"),a==null&&l!=null&&(e.defaultChecked=!!l),a!=null&&(e.checked=a&&typeof a!="function"&&typeof a!="symbol"),i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"?e.name=""+qe(i):e.removeAttribute("name")}function eb(e,t,n,o,a,l,c,i){if(l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"&&(e.type=l),t!=null||n!=null){if(!(l!=="submit"&&l!=="reset"||t!=null)){Ji(e);return}n=n!=null?""+qe(n):"",t=t!=null?""+qe(t):n,i||t===e.value||(e.value=t),e.defaultValue=t}o=o??a,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=i?e.checked:!!o,e.defaultChecked=!!o,c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"&&(e.name=c),Ji(e)}function di(e,t){e.defaultValue!==""+t&&(e.defaultValue=""+t)}function yo(e,t,n,o){if(e=e.options,t){t={};for(var a=0;a<n.length;a++)t["$"+n[a]]=!0;for(n=0;n<e.length;n++)a=t.hasOwnProperty("$"+e[n].value),e[n].selected!==a&&(e[n].selected=a),a&&o&&(e[n].defaultSelected=!0)}else{for(n=""+qe(n),t=null,a=0;a<e.length;a++){if(e[a].value===n){e[a].selected=!0,o&&(e[a].defaultSelected=!0);return}t!==null||e[a].disabled||(t=e[a])}t!==null&&(t.selected=!0)}}function tb(e,t,n){if(t!=null&&(t=""+qe(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n!=null?""+qe(n):""}function nb(e,t,n,o){if(t==null){if(o!=null){if(n!=null)throw Error(h(92));if(ia(o)){if(1<o.length)throw Error(h(93));o=o[0]}n=o}n==null&&(n=""),t=n}n=qe(t),e.defaultValue=n,o=e.textContent,o===n&&o!==""&&o!==null&&(e.value=o),Ji(e)}function _o(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var tp=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function ld(e,t,n){var o=t.indexOf("--")===0;n==null||typeof n=="boolean"||n===""?o?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":o?e.setProperty(t,n):typeof n!="number"||n===0||tp.has(t)?t==="float"?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function ob(e,t,n){if(t!=null&&typeof t!="object")throw Error(h(62));if(e=e.style,n!=null){for(var o in n)!n.hasOwnProperty(o)||t!=null&&t.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="",B=!0);for(var a in t)o=t[a],t.hasOwnProperty(a)&&n[a]!==o&&(ld(e,a,o),B=!0)}else for(var l in t)t.hasOwnProperty(l)&&ld(e,l,t[l])}function Pu(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var np=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),op=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Nl(e){return op.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function yt(){}var Wi=null;function er(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var uo=null,So=null;function cd(e){var t=Lo(e);if(t&&(e=t.stateNode)){var n=e[Ue]||null;e:switch(e=t.stateNode,t.type){case"input":if(Fi(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+Pe(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var o=n[t];if(o!==e&&o.form===e.form){var a=o[Ue]||null;if(!a)throw Error(h(90));Fi(o,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)o=n[t],o.form===e.form&&Ps(o)}break e;case"textarea":tb(e,n.value,n.defaultValue);break e;case"select":t=n.value,t!=null&&yo(e,!!n.multiple,t,!1)}}}var si=!1;function ab(e,t,n){if(si)return e(t,n);si=!0;try{var o=e(t);return o}finally{if(si=!1,(uo!==null||So!==null)&&(Bc(),uo&&(t=uo,e=So,So=uo=null,cd(t),e)))for(t=0;t<e.length;t++)cd(e[t])}}function wa(e,t){var n=e.stateNode;if(n===null)return null;var o=n[Ue]||null;if(o===null)return null;n=o[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(h(231,t,typeof n));return n}var Rt=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),$i=!1;if(Rt)try{Pn={},Object.defineProperty(Pn,"passive",{get:function(){$i=!0}}),window.addEventListener("test",Pn,Pn),window.removeEventListener("test",Pn,Pn)}catch{$i=!1}var Pn,Pt=null,tr=null,Al=null;function lb(){if(Al)return Al;var e,t=tr,n=t.length,o,a="value"in Pt?Pt.value:Pt.textContent,l=a.length;for(e=0;e<n&&t[e]===a[e];e++);var c=n-e;for(o=1;o<=c&&t[n-o]===a[l-o];o++);return Al=a.slice(e,1<o?1-o:void 0)}function _l(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function dl(){return!0}function id(){return!1}function Ne(e){function t(n,o,a,l,c){this._reactName=n,this._targetInst=a,this.type=o,this.nativeEvent=l,this.target=c,this.currentTarget=null;for(var i in e)e.hasOwnProperty(i)&&(n=e[i],this[i]=n?n(l):l[i]);return this.isDefaultPrevented=(l.defaultPrevented!=null?l.defaultPrevented:l.returnValue===!1)?dl:id,this.isPropagationStopped=id,this}return X(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=dl)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=dl)},persist:function(){},isPersistent:dl}),t}var Sn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Tc=Ne(Sn),Xa=X({},Sn,{view:0,detail:0}),ap=Ne(Xa),bi,vi,ta,Ec=X({},Xa,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:nr,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==ta&&(ta&&e.type==="mousemove"?(bi=e.screenX-ta.screenX,vi=e.screenY-ta.screenY):vi=bi=0,ta=e),bi)},movementY:function(e){return"movementY"in e?e.movementY:vi}}),ud=Ne(Ec),lp=X({},Ec,{dataTransfer:0}),cp=Ne(lp),ip=X({},Xa,{relatedTarget:0}),gi=Ne(ip),up=X({},Sn,{animationName:0,elapsedTime:0,pseudoElement:0}),rp=Ne(up),fp=X({},Sn,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),dp=Ne(fp),sp=X({},Sn,{data:0}),rd=Ne(sp),bp={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},vp={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},gp={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function mp(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=gp[e])?!!t[e]:!1}function nr(){return mp}var pp=X({},Xa,{key:function(e){if(e.key){var t=bp[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=_l(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?vp[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:nr,charCode:function(e){return e.type==="keypress"?_l(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?_l(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),hp=Ne(pp),yp=X({},Ec,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),fd=Ne(yp),Sp=X({},Sn,{submitter:0}),xp=Ne(Sp),kp=X({},Xa,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:nr}),Tp=Ne(kp),Ep=X({},Sn,{propertyName:0,elapsedTime:0,pseudoElement:0}),wp=Ne(Ep),zp=X({},Ec,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Op=Ne(zp),Np=X({},Sn,{newState:0,oldState:0,source:0}),Ap=Ne(Np),_p=[9,13,27,32],or=Rt&&"CompositionEvent"in window,da=null;Rt&&"documentMode"in document&&(da=document.documentMode);var Cp=Rt&&"TextEvent"in window&&!da,cb=Rt&&(!or||da&&8<da&&11>=da),dd=" ",sd=!1;function ib(e,t){switch(e){case"keyup":return _p.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function ub(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var ro=!1;function Mp(e,t){switch(e){case"compositionend":return ub(t);case"keypress":return t.which!==32?null:(sd=!0,dd);case"textInput":return e=t.data,e===dd&&sd?null:e;default:return null}}function Dp(e,t){if(ro)return e==="compositionend"||!or&&ib(e,t)?(e=lb(),Al=tr=Pt=null,ro=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return cb&&t.locale!=="ko"?null:t.data;default:return null}}var Rp={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function bd(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Rp[e.type]:t==="textarea"}function rb(e,t,n,o){uo?So?So.push(o):So=[o]:uo=o,t=hc(t,"onChange"),0<t.length&&(n=new Tc("onChange","change",null,n,o),e.push({event:n,listeners:t}))}var sa=null,za=null;function Up(e){ag(e,0)}function wc(e){var t=ua(e);if(Ps(t))return e}function vd(e,t){if(e==="change")return t}var fb=!1;Rt&&(Rt?(bl="oninput"in document,bl||(mi=document.createElement("div"),mi.setAttribute("oninput","return;"),bl=typeof mi.oninput=="function"),sl=bl):sl=!1,fb=sl&&(!document.documentMode||9<document.documentMode));var sl,bl,mi;function gd(){sa&&(sa.detachEvent("onpropertychange",db),za=sa=null)}function db(e){if(e.propertyName==="value"&&wc(za)){var t=[];rb(t,za,e,er(e)),ab(Up,t)}}function Bp(e,t,n){e==="focusin"?(gd(),sa=t,za=n,sa.attachEvent("onpropertychange",db)):e==="focusout"&&gd()}function Hp(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return wc(za)}function qp(e,t){if(e==="click")return wc(t)}function Yp(e,t){if(e==="input"||e==="change")return wc(t)}function Gp(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Ze=typeof Object.is=="function"?Object.is:Gp;function Oa(e,t){if(Ze(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),o=Object.keys(t);if(n.length!==o.length)return!1;for(o=0;o<n.length;o++){var a=n[o];if(!Ki.call(t,a)||!Ze(e[a],t[a]))return!1}return!0}function Ii(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function md(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function pd(e,t){var n=md(e);e=0;for(var o;n;){if(n.nodeType===3){if(o=e+n.textContent.length,e<=t&&o>=t)return{node:n,offset:t-e};e=o}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=md(n)}}function sb(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?sb(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function bb(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=Ii(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=Ii(e.document)}return t}function ar(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var jp=Rt&&"documentMode"in document&&11>=document.documentMode,fo=null,Pi=null,ba=null,eu=!1;function hd(e,t,n){var o=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;eu||fo==null||fo!==Ii(o)||(o=fo,"selectionStart"in o&&ar(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),ba&&Oa(ba,o)||(ba=o,o=hc(Pi,"onSelect"),0<o.length&&(t=new Tc("onSelect","select",null,t,n),e.push({event:t,listeners:o}),t.target=fo)))}function kn(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var so={animationend:kn("Animation","AnimationEnd"),animationiteration:kn("Animation","AnimationIteration"),animationstart:kn("Animation","AnimationStart"),transitionrun:kn("Transition","TransitionRun"),transitionstart:kn("Transition","TransitionStart"),transitioncancel:kn("Transition","TransitionCancel"),transitionend:kn("Transition","TransitionEnd")},pi={},vb={};Rt&&(vb=document.createElement("div").style,"AnimationEvent"in window||(delete so.animationend.animation,delete so.animationiteration.animation,delete so.animationstart.animation),"TransitionEvent"in window||delete so.transitionend.transition);function Qn(e){if(pi[e])return pi[e];if(!so[e])return e;var t=so[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in vb)return pi[e]=t[n];return e}var gb=Qn("animationend"),mb=Qn("animationiteration"),pb=Qn("animationstart"),Lp=Qn("transitionrun"),Vp=Qn("transitionstart"),Qp=Qn("transitioncancel"),hb=Qn("transitionend"),yb=new Map,tu="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");tu.push("scrollEnd");function ft(e,t){yb.set(e,t),Vn(t,[e])}var Xp=0;function Ut(e,t){if(e.name!=null&&e.name!=="auto")return e.name;if(t.autoName!==null)return t.autoName;e=rt.identifierPrefix;var n=Xp++;return e="_"+e+"t_"+n.toString(32)+"_",t.autoName=e}function yd(e){if(e==null||typeof e=="string")return e;var t=null,n=Oo;if(n!==null)for(var o=0;o<n.length;o++){var a=e[n[o]];if(a!=null){if(a==="none")return"none";t=t==null?a:t+(" "+a)}}return t??e.default}function jt(e,t){return e=yd(e),t=yd(t),t==null?e==="auto"?null:e:t==="auto"?null:t}var $l=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},We=[],bo=0,lr=0;function zc(){for(var e=bo,t=lr=bo=0;t<e;){var n=We[t];We[t++]=null;var o=We[t];We[t++]=null;var a=We[t];We[t++]=null;var l=We[t];if(We[t++]=null,o!==null&&a!==null){var c=o.pending;c===null?a.next=a:(a.next=c.next,c.next=a),o.pending=a}l!==0&&Sb(n,a,l)}}function Oc(e,t,n,o){We[bo++]=e,We[bo++]=t,We[bo++]=n,We[bo++]=o,lr|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function cr(e,t,n,o){return Oc(e,t,n,o),Il(e)}function Xn(e,t){return Oc(e,null,null,t),Il(e)}function Sb(e,t,n){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n);for(var a=!1,l=e.return;l!==null;)l.childLanes|=n,o=l.alternate,o!==null&&(o.childLanes|=n),l.tag===22&&(e=l.stateNode,e===null||e._visibility&1||(a=!0)),e=l,l=l.return;return e.tag===3?(l=e.stateNode,a&&t!==null&&(a=31-Qe(n),e=l.hiddenUpdates,o=e[a],o===null?e[a]=[t]:o.push(t),t.lane=n|536870912),l):null}function Il(e){if(50<Ta)throw Ta=0,Gl=null,Error(h(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var vo={};function Zp(e,t,n,o){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Me(e,t,n,o){return new Zp(e,t,n,o)}function ir(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Mt(e,t){var n=e.alternate;return n===null?(n=Me(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function xb(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Cl(e,t,n,o,a,l){var c=0;if(o=e,typeof o=="function")ir(o)&&(c=1);else if(typeof o=="string")c=h0(e,n,kt.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(o){case Li:return e=Me(31,n,t,a),e.elementType=Li,e.lanes=l,e;case co:return _n(n.children,a,l,t);case qs:c=8,a|=24;break;case Yi:return e=Me(12,n,t,a|2),e.elementType=Yi,e.lanes=l,e;case Gi:return e=Me(13,n,t,a),e.elementType=Gi,e.lanes=l,e;case ji:return e=Me(19,n,t,a),e.elementType=ji,e.lanes=l,e;case Dm:case Vi:return e=a|32,e=Me(30,n,t,e),e.elementType=Vi,e.lanes=l,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof o=="object"&&o!==null)switch(o.$$typeof){case ht:c=10;break e;case Ys:c=9;break e;case Ju:c=11;break e;case Fu:c=14;break e;case Ft:c=16,o=null;break e}c=29,n=Error(h(130,e===null?"null":typeof e,"")),o=null}return t=Me(c,n,t,a),t.elementType=e,t.type=o,t.lanes=l,t}function _n(e,t,n,o){return e=Me(7,e,o,t),e.lanes=n,e}function hi(e,t,n){return e=Me(6,e,null,t),e.lanes=n,e}function kb(e){var t=Me(18,null,null,0);return t.stateNode=e,t}function yi(e,t,n){return t=Me(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var Sd=new WeakMap;function et(e,t){if(typeof e=="object"&&e!==null){var n=Sd.get(e);return n!==void 0?n:(t={value:e,source:t,stack:If(t)},Sd.set(e,t),t)}return{value:e,source:t,stack:If(t)}}var go=[],mo=0,Pl=null,Na=0,$e=[],Ie=0,gn=null,St=1,xt="";function _t(e,t){go[mo++]=Na,go[mo++]=Pl,Pl=e,Na=t}function Tb(e,t,n){$e[Ie++]=St,$e[Ie++]=xt,$e[Ie++]=gn,gn=e;var o=St;e=xt;var a=32-Qe(o)-1;o&=~(1<<a),n+=1;var l=32-Qe(t)+a;if(30<l){var c=a-a%5;l=(o&(1<<c)-1).toString(32),o>>=c,a-=c,St=1<<32-Qe(t)+a|n<<a|o,xt=l+e}else St=1<<l|n<<a|o,xt=e}function Nc(e){e.return!==null&&(_t(e,1),Tb(e,1,0))}function ur(e){for(;e===Pl;)Pl=go[--mo],go[mo]=null,Na=go[--mo],go[mo]=null;for(;e===gn;)gn=$e[--Ie],$e[Ie]=null,xt=$e[--Ie],$e[Ie]=null,St=$e[--Ie],$e[Ie]=null}function Eb(e,t){$e[Ie++]=St,$e[Ie++]=xt,$e[Ie++]=gn,St=t.id,xt=t.overflow,gn=e}var be=null,J=null,N=!1,ln=null,tt=!1,nu=Error(h(519));function mn(e){var t=Error(h(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Aa(et(t,e)),nu}function xd(e){var t=e.stateNode,n=e.type,o=e.memoizedProps;switch(t[ge]=e,t[Ue]=o,n){case"dialog":A("cancel",t),A("close",t);break;case"iframe":case"object":case"embed":A("load",t);break;case"video":case"audio":for(n=0;n<Da.length;n++)A(Da[n],t);break;case"source":A("error",t);break;case"img":case"image":case"link":A("error",t),A("load",t);break;case"details":A("toggle",t);break;case"input":A("invalid",t),eb(t,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":A("invalid",t);break;case"textarea":A("invalid",t),nb(t,o.value,o.defaultValue,o.children)}n=o.children,typeof n!="string"&&typeof n!="number"&&typeof n!="bigint"||t.textContent===""+n||o.suppressHydrationWarning===!0||cg(t.textContent,n)?(o.popover!=null&&(A("beforetoggle",t),A("toggle",t)),o.onScroll!=null&&A("scroll",t),o.onScrollEnd!=null&&A("scrollend",t),o.onClick!=null&&(t.onclick=yt),t=!0):t=!1,t||mn(e,!0)}function ec(e){for(be=e.return;be;)switch(be.tag){case 5:case 31:case 13:tt=!1;return;case 27:case 3:tt=!0;return;default:be=be.return}}function eo(e){if(e!==be)return!1;if(!N)return ec(e),N=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!=="form"&&n!=="button")||Gu(e.type,e.memoizedProps)),n=!n),n&&J&&mn(e),ec(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(h(317));J=ps(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(h(317));J=ps(e)}else t===27?(t=J,xn(e.type)?(e=Qu,Qu=null,J=e):J=t):J=be?nt(e.stateNode.nextSibling):null;return!0}function Rn(){J=be=null,N=!1}function Si(){var e=ln;return e!==null&&(_e===null?_e=e:_e.push.apply(_e,e),ln=null),e}function Aa(e){ln===null?ln=[e]:ln.push(e)}var ou=wt(null),Zn=null,Ct=null;function en(e,t,n){F(ou,t._currentValue),t._currentValue=n}function Dt(e){e._currentValue=ou.current,pe(ou)}function Ml(e,t,n){for(;e!==null;){var o=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,o!==null&&(o.childLanes|=t)):o!==null&&(o.childLanes&t)!==t&&(o.childLanes|=t),e===n)break;e=e.return}}function au(e,t,n,o){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var l=a.dependencies;if(l!==null){var c=a.child;l=l.firstContext;e:for(;l!==null;){var i=l;l=a;for(var u=0;u<t.length;u++)if(i.context===t[u]){l.lanes|=n,i=l.alternate,i!==null&&(i.lanes|=n),Ml(l.return,n,e),o||(c=null);break e}l=i.next}}else if(a.tag===18){if(c=a.return,c===null)throw Error(h(341));c.lanes|=n,l=c.alternate,l!==null&&(l.lanes|=n),Ml(c,n,e),c=null}else a.tag===13&&a.memoizedState!==null&&a.memoizedState.dehydrated===null?(a.lanes|=n,c=a.alternate,c!==null&&(c.lanes|=n),Ml(a.return,n,e),c=a.child,c=c!==null?c.sibling:null):c=a.child;if(c!==null)c.return=a;else for(c=a;c!==null;){if(c===e){c=null;break}if(a=c.sibling,a!==null){a.return=c.return,c=a;break}c=c.return}a=c}}function Un(e,t,n,o){e=null;for(var a=t,l=!1;a!==null;){if(!l){if((a.flags&524288)!==0)l=!0;else if((a.flags&262144)!==0)break}if(a.tag===10){var c=a.alternate;if(c===null)throw Error(h(387));if(c=c.memoizedProps,c!==null){var i=a.type;Ze(a.pendingProps.value,c.value)||(e!==null?e.push(i):e=[i])}}else if(a===Zl.current){if(c=a.alternate,c===null)throw Error(h(387));c.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e!==null?e.push(qo):e=[qo])}a=a.return}return e!==null&&au(t,e,n,o),t.flags|=262144,e!==null}function tc(e){for(e=e.firstContext;e!==null;){if(!Ze(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function Bn(e){Zn=e,Ct=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function me(e){return wb(Zn,e)}function vl(e,t){return Zn===null&&Bn(e),wb(e,t)}function wb(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},Ct===null){if(e===null)throw Error(h(308));Ct=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else Ct=Ct.next=t;return n}var Kp=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(n,o){e.push(o)}};this.abort=function(){t.aborted=!0,e.forEach(function(n){return n()})}},Jp=re.unstable_scheduleCallback,Fp=re.unstable_NormalPriority,ae={$$typeof:ht,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function rr(){return{controller:new Kp,data:new Map,refCount:0}}function Za(e){e.refCount--,e.refCount===0&&Jp(Fp,function(){e.controller.abort()})}function kd(e,t){if((e.pendingLanes&4194048)!==0){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var o=t[e];n.indexOf(o)===-1&&n.push(o)}}}var ra=null;function Wp(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var va=null,lu=0,Hn=0,xo=null;function $p(e,t){if(va===null){var n=va=[];lu=0,Hn=Hr(),xo={status:"pending",value:void 0,then:function(o){n.push(o)}}}return lu++,t.then(Td,Td),t}function Td(){if(--lu===0&&(ra=null,va!==null)){xo!==null&&(xo.status="fulfilled");var e=va;va=null,Hn=0,xo=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Ip(e,t){var n=[],o={status:"pending",value:null,reason:null,then:function(a){n.push(a)}};return e.then(function(){o.status="fulfilled",o.value=t;for(var a=0;a<n.length;a++)(0,n[a])(t)},function(a){for(o.status="rejected",o.reason=a,a=0;a<n.length;a++)(0,n[a])(void 0)}),o}var Ed=E.S;E.S=function(e,t){if(Vv=Le(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&$p(e,t),ra!==null)for(var n=Uo;n!==null;)kd(n,ra),n=n.next;if(n=e.types,n!==null){for(var o=Uo;o!==null;)kd(o,n),o=o.next;if(Hn!==0){o=ra,o===null&&(o=ra=[]);for(var a=0;a<n.length;a++){var l=n[a];o.indexOf(l)===-1&&o.push(l)}}}Ed!==null&&Ed(e,t)};var Cn=wt(null);function fr(){var e=Cn.current;return e!==null?e:Q.pooledCache}function Dl(e,t){t===null?F(Cn,Cn.current):F(Cn,t.pool)}function zb(){var e=fr();return e===null?null:{parent:ae._currentValue,pool:e}}var Vo=Error(h(460)),dr=Error(h(474)),Ac=Error(h(542)),nc={then:function(){}};function wd(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Ob(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(yt,yt),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Od(e),e===void 0&&!("reason"in t)?Error(h(600)):e;default:if(typeof t.status=="string")t.then(yt,yt);else{if(e=Q,e!==null&&100<e.shellSuspendCounter)throw Error(h(482));e=t,e.status="pending",e.then(function(o){if(t.status==="pending"){var a=t;a.status="fulfilled",a.value=o}},function(o){if(t.status==="pending"){var a=t;a.status="rejected",a.reason=o}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Od(e),e}throw Mn=t,Vo}}function wn(e){try{var t=e._init;return t(e._payload)}catch(n){throw n!==null&&typeof n=="object"&&typeof n.then=="function"?(Mn=n,Vo):n}}var Mn=null;function zd(){if(Mn===null)throw Error(h(459));var e=Mn;return Mn=null,e}function Od(e){if(e===Vo||e===Ac)throw Error(h(483))}var ko=null,_a=0;function gl(e){var t=_a;return _a+=1,ko===null&&(ko=[]),Ob(ko,e,t)}function Zt(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function ml(e,t){throw t.$$typeof===Mm?Error(h(525)):(e=Object.prototype.toString.call(t),Error(h(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function Nb(e){function t(s,r){if(e){var b=s.deletions;b===null?(s.deletions=[r],s.flags|=16):b.push(r)}}function n(s,r){if(!e)return null;for(;r!==null;)t(s,r),r=r.sibling;return null}function o(s){for(var r=new Map;s!==null;)s.key===null?r.set(s.index,s):r.set(s.key,s),s=s.sibling;return r}function a(s,r){return s=Mt(s,r),s.index=0,s.sibling=null,s}function l(s,r,b){return s.index=b,e?(b=s.alternate,b!==null?(b=b.index,b<r?(s.flags|=2,r):b):(s.flags|=134217730,r)):(s.flags|=1048576,r)}function c(s){return e&&s.alternate===null&&(s.flags|=134217730),s}function i(s,r,b,p){return r===null||r.tag!==6?(r=hi(b,s.mode,p),r.return=s,r):(r=a(r,b),r.return=s,r)}function u(s,r,b,p){var S=b.type;return S===co?(s=g(s,r,b.props.children,p,b.key),Zt(s,b),s):r!==null&&(r.elementType===S||typeof S=="object"&&S!==null&&S.$$typeof===Ft&&wn(S)===r.type)?(r=a(r,b.props),Zt(r,b),r.return=s,r):(r=Cl(b.type,b.key,b.props,null,s.mode,p),Zt(r,b),r.return=s,r)}function f(s,r,b,p){return r===null||r.tag!==4||r.stateNode.containerInfo!==b.containerInfo||r.stateNode.implementation!==b.implementation?(r=yi(b,s.mode,p),r.return=s,r):(r=a(r,b.children||[]),r.return=s,r)}function g(s,r,b,p,S){return r===null||r.tag!==7?(r=_n(b,s.mode,p,S),r.return=s,r):(r=a(r,b),r.return=s,r)}function m(s,r,b){if(typeof r=="string"&&r!==""||typeof r=="number"||typeof r=="bigint")return r=hi(""+r,s.mode,b),r.return=s,r;if(typeof r=="object"&&r!==null){switch(r.$$typeof){case cl:return b=Cl(r.type,r.key,r.props,null,s.mode,b),Zt(b,r),b.return=s,b;case ca:return r=yi(r,s.mode,b),r.return=s,r;case Ft:return r=wn(r),m(s,r,b)}if(ia(r)||ea(r))return r=_n(r,s.mode,b,null),r.return=s,r;if(typeof r.then=="function")return m(s,gl(r),b);if(r.$$typeof===ht)return m(s,vl(s,r),b);ml(s,r)}return null}function d(s,r,b,p){var S=r!==null?r.key:null;if(typeof b=="string"&&b!==""||typeof b=="number"||typeof b=="bigint")return S!==null?null:i(s,r,""+b,p);if(typeof b=="object"&&b!==null){switch(b.$$typeof){case cl:return b.key===S?u(s,r,b,p):null;case ca:return b.key===S?f(s,r,b,p):null;case Ft:return b=wn(b),d(s,r,b,p)}if(ia(b)||ea(b))return S!==null?null:g(s,r,b,p,null);if(typeof b.then=="function")return d(s,r,gl(b),p);if(b.$$typeof===ht)return d(s,r,vl(s,b),p);ml(s,b)}return null}function v(s,r,b,p,S){if(typeof p=="string"&&p!==""||typeof p=="number"||typeof p=="bigint")return s=s.get(b)||null,i(r,s,""+p,S);if(typeof p=="object"&&p!==null){switch(p.$$typeof){case cl:return s=s.get(p.key===null?b:p.key)||null,u(r,s,p,S);case ca:return s=s.get(p.key===null?b:p.key)||null,f(r,s,p,S);case Ft:return p=wn(p),v(s,r,b,p,S)}if(ia(p)||ea(p))return s=s.get(b)||null,g(r,s,p,S,null);if(typeof p.then=="function")return v(s,r,b,gl(p),S);if(p.$$typeof===ht)return v(s,r,b,vl(r,p),S);ml(r,p)}return null}function y(s,r,b,p){for(var S=null,M=null,k=r,T=r=0,ne=null;k!==null&&T<b.length;T++){k.index>T?(ne=k,k=null):ne=k.sibling;var R=d(s,k,b[T],p);if(R===null){k===null&&(k=ne);break}e&&k&&R.alternate===null&&t(s,k),r=l(R,r,T),M===null?S=R:M.sibling=R,M=R,k=ne}if(T===b.length)return n(s,k),N&&_t(s,T),S;if(k===null){for(;T<b.length;T++)k=m(s,b[T],p),k!==null&&(r=l(k,r,T),M===null?S=k:M.sibling=k,M=k);return N&&_t(s,T),S}for(k=o(k);T<b.length;T++)ne=v(k,s,T,b[T],p),ne!==null&&(e&&(R=ne.alternate,R!==null&&k.delete(R.key===null?T:R.key)),r=l(ne,r,T),M===null?S=ne:M.sibling=ne,M=ne);return e&&k.forEach(function(Vt){return t(s,Vt)}),N&&_t(s,T),S}function x(s,r,b,p){if(b==null)throw Error(h(151));for(var S=null,M=null,k=r,T=r=0,ne=null,R=b.next();k!==null&&!R.done;T++,R=b.next()){k.index>T?(ne=k,k=null):ne=k.sibling;var Vt=d(s,k,R.value,p);if(Vt===null){k===null&&(k=ne);break}e&&k&&Vt.alternate===null&&t(s,k),r=l(Vt,r,T),M===null?S=Vt:M.sibling=Vt,M=Vt,k=ne}if(R.done)return n(s,k),N&&_t(s,T),S;if(k===null){for(;!R.done;T++,R=b.next())R=m(s,R.value,p),R!==null&&(r=l(R,r,T),M===null?S=R:M.sibling=R,M=R);return N&&_t(s,T),S}for(k=o(k);!R.done;T++,R=b.next())R=v(k,s,T,R.value,p),R!==null&&(e&&(ne=R.alternate,ne!==null&&k.delete(ne.key===null?T:ne.key)),r=l(R,r,T),M===null?S=R:M.sibling=R,M=R);return e&&k.forEach(function(Xg){return t(s,Xg)}),N&&_t(s,T),S}function z(s,r,b,p){if(typeof b=="object"&&b!==null&&b.type===co&&b.key===null&&b.props.ref===void 0&&(b=b.props.children),typeof b=="object"&&b!==null){switch(b.$$typeof){case cl:e:{for(var S=b.key;r!==null;){if(r.key===S){if(S=b.type,S===co){if(r.tag===7){n(s,r.sibling),p=a(r,b.props.children),Zt(p,b),p.return=s,s=p;break e}}else if(r.elementType===S||typeof S=="object"&&S!==null&&S.$$typeof===Ft&&wn(S)===r.type){n(s,r.sibling),p=a(r,b.props),Zt(p,b),p.return=s,s=p;break e}n(s,r);break}else t(s,r);r=r.sibling}b.type===co?(p=_n(b.props.children,s.mode,p,b.key),Zt(p,b),p.return=s,s=p):(p=Cl(b.type,b.key,b.props,null,s.mode,p),Zt(p,b),p.return=s,s=p)}return c(s);case ca:e:{for(S=b.key;r!==null;){if(r.key===S)if(r.tag===4&&r.stateNode.containerInfo===b.containerInfo&&r.stateNode.implementation===b.implementation){n(s,r.sibling),p=a(r,b.children||[]),p.return=s,s=p;break e}else{n(s,r);break}else t(s,r);r=r.sibling}p=yi(b,s.mode,p),p.return=s,s=p}return c(s);case Ft:return b=wn(b),z(s,r,b,p)}if(ia(b))return y(s,r,b,p);if(ea(b)){if(S=ea(b),typeof S!="function")throw Error(h(150));return b=S.call(b),x(s,r,b,p)}if(typeof b.then=="function")return z(s,r,gl(b),p);if(b.$$typeof===ht)return z(s,r,vl(s,b),p);ml(s,b)}return typeof b=="string"&&b!==""||typeof b=="number"||typeof b=="bigint"?(b=""+b,r!==null&&r.tag===6?(n(s,r.sibling),p=a(r,b),p.return=s,s=p):(n(s,r),p=hi(b,s.mode,p),p.return=s,s=p),c(s)):n(s,r)}return function(s,r,b,p){try{_a=0;var S=z(s,r,b,p);return ko=null,S}catch(k){if(k===Vo||k===Ac)throw k;var M=Me(29,k,null,s.mode);return M.lanes=p,M.return=s,M}}}var qn=Nb(!0),Ab=Nb(!1),Wt=!1;function sr(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function cu(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function cn(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function un(e,t,n){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(H&2)!==0){var a=o.pending;return a===null?t.next=t:(t.next=a.next,a.next=t),o.pending=t,t=Il(e),Sb(e,null,n),t}return Oc(e,o,t,n),Il(e)}function ga(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194048)!==0)){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Zs(e,n)}}function xi(e,t){var n=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,n===o)){var a=null,l=null;if(n=n.firstBaseUpdate,n!==null){do{var c={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};l===null?a=l=c:l=l.next=c,n=n.next}while(n!==null);l===null?a=l=t:l=l.next=t}else a=l=t;n={baseState:o.baseState,firstBaseUpdate:a,lastBaseUpdate:l,shared:o.shared,callbacks:o.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var iu=!1;function ma(){if(iu){var e=xo;if(e!==null)throw e}}function pa(e,t,n,o){iu=!1;var a=e.updateQueue;Wt=!1;var l=a.firstBaseUpdate,c=a.lastBaseUpdate,i=a.shared.pending;if(i!==null){a.shared.pending=null;var u=i,f=u.next;u.next=null,c===null?l=f:c.next=f,c=u;var g=e.alternate;g!==null&&(g=g.updateQueue,i=g.lastBaseUpdate,i!==c&&(i===null?g.firstBaseUpdate=f:i.next=f,g.lastBaseUpdate=u))}if(l!==null){var m=a.baseState;c=0,g=f=u=null,i=l;do{var d=i.lane&-536870913,v=d!==i.lane;if(v?(D&d)===d:(o&d)===d){d!==0&&d===Hn&&(iu=!0),g!==null&&(g=g.next={lane:0,tag:i.tag,payload:i.payload,callback:null,next:null});e:{var y=e,x=i;d=t;var z=n;switch(x.tag){case 1:if(y=x.payload,typeof y=="function"){m=y.call(z,m,d);break e}m=y;break e;case 3:y.flags=y.flags&-65537|128;case 0:if(y=x.payload,d=typeof y=="function"?y.call(z,m,d):y,d==null)break e;m=X({},m,d);break e;case 2:Wt=!0}}d=i.callback,d!==null&&(e.flags|=64,v&&(e.flags|=8192),v=a.callbacks,v===null?a.callbacks=[d]:v.push(d))}else v={lane:d,tag:i.tag,payload:i.payload,callback:i.callback,next:null},g===null?(f=g=v,u=m):g=g.next=v,c|=d;if(i=i.next,i===null){if(i=a.shared.pending,i===null)break;v=i,i=v.next,v.next=null,a.lastBaseUpdate=v,a.shared.pending=null}}while(!0);g===null&&(u=m),a.baseState=u,a.firstBaseUpdate=f,a.lastBaseUpdate=g,l===null&&(a.shared.lanes=0),yn|=c,e.lanes=c,e.memoizedState=m}}function _b(e,t){if(typeof e!="function")throw Error(h(191,e));e.call(t)}function Cb(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)_b(n[e],t)}var pn=wt(null),oc=wt(0);function Nd(e,t){e=Yt,F(oc,e),F(pn,t),Yt=e|t.baseLanes}function uu(){F(oc,Yt),F(pn,pn.current)}function br(){Yt=oc.current,pe(pn),pe(oc)}var Se=wt(null),Te=null;function rn(e){var t=e.alternate;F(he,he.current&1),F(Se,e),Te===null&&(t===null||pn.current!==null||t.memoizedState!==null)&&(Te=e)}function ru(e){F(he,he.current),F(Se,e),Te===null&&(Te=e)}function Mb(e){e.tag===22?(F(he,he.current),F(Se,e),Te===null&&(Te=e)):fn()}function fn(){F(he,he.current),F(Se,Se.current)}function Ye(e){pe(Se),Te===e&&(Te=null),pe(he)}var he=wt(0);function Ca(e,t){F(Se,Se.current),F(he,t)}function vr(e){pe(he),pe(Se),Te===e&&(Te=null)}function ac(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||Vu(n)||jr(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!=="independent"){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Bt=0,O=null,V=null,oe=null,lc=!1,To=!1,Yn=!1,cc=0,Ma=0,Eo=null,Pp=0;function P(){throw Error(h(321))}function gr(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Ze(e[n],t[n]))return!1;return!0}function mr(e,t,n,o,a,l){return Bt=l,O=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,E.H=e===null||e.memoizedState===null?rv:fv,Yn=!1,l=n(o,a),Yn=!1,To&&(l=Rb(t,n,o,a)),Db(e),l}function Db(e){E.H=ic;var t=V!==null&&V.next!==null;if(Bt=0,oe=V=O=null,lc=!1,Ma=0,Eo=null,t)throw Error(h(300));e===null||le||(e=e.dependencies,e!==null&&tc(e)&&(le=!0))}function Rb(e,t,n,o){O=e;var a=0;do{if(To&&(Eo=null),Ma=0,To=!1,25<=a)throw Error(h(301));if(a+=1,oe=V=null,e.updateQueue!=null){var l=e.updateQueue;l.lastEffect=null,l.events=null,l.stores=null,l.memoCache!=null&&(l.memoCache.index=0)}E.H=ih,l=t(n,o)}while(To);return l}function eh(){var e=E.H,t=e.useState()[0];return t=typeof t.then=="function"?Ka(t):t,e=e.useState()[0],(V!==null?V.memoizedState:null)!==e&&(O.flags|=1024),t}function pr(){var e=cc!==0;return cc=0,e}function hr(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function yr(e){if(lc){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}lc=!1}Bt=0,oe=V=O=null,To=!1,Ma=cc=0,Eo=null}function Oe(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return oe===null?O.memoizedState=oe=e:oe=oe.next=e,oe}function te(){if(V===null){var e=O.alternate;e=e!==null?e.memoizedState:null}else e=V.next;var t=oe===null?O.memoizedState:oe.next;if(t!==null)oe=t,V=e;else{if(e===null)throw O.alternate===null?Error(h(467)):Error(h(310));V=e,e={memoizedState:V.memoizedState,baseState:V.baseState,baseQueue:V.baseQueue,queue:V.queue,next:null},oe===null?O.memoizedState=oe=e:oe=oe.next=e}return oe}function _c(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Ka(e){var t=Ma;return Ma+=1,Eo===null&&(Eo=[]),e=Ob(Eo,e,t),t=O,(oe===null?t.memoizedState:oe.next)===null&&(t=t.alternate,E.H=t===null||t.memoizedState===null?rv:fv),e}function Cc(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Ka(e);if(e.$$typeof===Um)return;if(e.$$typeof===ht)return me(e)}throw Error(h(438,String(e)))}function Sr(e){var t=null,n=O.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var o=O.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(t={data:o.data.map(function(a){return a.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),n===null&&(n=_c(),O.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),o=0;o<e;o++)n[o]=Rm;return t.index++,n}function Ht(e,t){return typeof t=="function"?t(e):t}function Rl(e){var t=te();return xr(t,V,e)}function xr(e,t,n){var o=e.queue;if(o===null)throw Error(h(311));o.lastRenderedReducer=n;var a=e.baseQueue,l=o.pending;if(l!==null){if(a!==null){var c=a.next;a.next=l.next,l.next=c}t.baseQueue=a=l,o.pending=null}if(l=e.baseState,a===null)e.memoizedState=l;else{t=a.next;var i=c=null,u=null,f=t,g=!1;do{var m=f.lane&-536870913;if(m!==f.lane?(D&m)===m:(Bt&m)===m){var d=f.revertLane;if(d===0)u!==null&&(u=u.next={lane:0,revertLane:0,gesture:null,action:f.action,hasEagerState:f.hasEagerState,eagerState:f.eagerState,next:null}),m===Hn&&(g=!0);else if((Bt&d)===d){f=f.next,d===Hn&&(g=!0);continue}else m={lane:0,revertLane:f.revertLane,gesture:null,action:f.action,hasEagerState:f.hasEagerState,eagerState:f.eagerState,next:null},u===null?(i=u=m,c=l):u=u.next=m,O.lanes|=d,yn|=d;m=f.action,Yn&&n(l,m),l=f.hasEagerState?f.eagerState:n(l,m)}else d={lane:m,revertLane:f.revertLane,gesture:f.gesture,action:f.action,hasEagerState:f.hasEagerState,eagerState:f.eagerState,next:null},u===null?(i=u=d,c=l):u=u.next=d,O.lanes|=m,yn|=m;f=f.next}while(f!==null&&f!==t);if(u===null?c=l:u.next=i,!Ze(l,e.memoizedState)&&(le=!0,g&&(n=xo,n!==null)))throw n;e.memoizedState=l,e.baseState=c,e.baseQueue=u,o.lastRenderedState=l}return a===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function ki(e){var t=te(),n=t.queue;if(n===null)throw Error(h(311));n.lastRenderedReducer=e;var o=n.dispatch,a=n.pending,l=t.memoizedState;if(a!==null){n.pending=null;var c=a=a.next;do l=e(l,c.action),c=c.next;while(c!==a);Ze(l,t.memoizedState)||(le=!0),t.memoizedState=l,t.baseQueue===null&&(t.baseState=l),n.lastRenderedState=l}return[l,o]}function Ub(e,t,n){var o=O,a=te(),l=N;if(l){if(n===void 0)throw Error(h(407));n=n()}else n=t();var c=!Ze((V||a).memoizedState,n);if(c&&(a.memoizedState=n,le=!0),a=a.queue,kr(qb.bind(null,o,a,e),[e]),e=a.getSnapshot!==t||c||oe!==null&&(oe.memoizedState.tag&1)!==0,Co(e?9:8,{destroy:void 0},Hb.bind(null,o,a,n,t),null),e){if(o.flags|=2048,Q===null)throw Error(h(349));l||(Bt&127)!==0||Bb(o,t,n)}return n}function Bb(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=O.updateQueue,t===null?(t=_c(),O.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Hb(e,t,n,o){t.value=n,t.getSnapshot=o,Yb(t)&&Gb(e)}function qb(e,t,n){return n(function(){Yb(t)&&Gb(e)})}function Yb(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Ze(e,n)}catch{return!0}}function Gb(e){var t=Xn(e,2);t!==null&&De(t,e,2)}function fu(e){var t=Oe();if(typeof e=="function"){var n=e;if(e=n(),Yn){It(!0);try{n()}finally{It(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ht,lastRenderedState:e},t}function jb(e,t,n,o){return e.baseState=n,xr(e,V,typeof o=="function"?o:Ht)}function th(e,t,n,o,a){if(Dc(e))throw Error(h(485));if(e=t.action,e!==null){var l={payload:a,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(c){l.listeners.push(c)}};E.T!==null?n(!0):l.isTransition=!1,o(l),n=t.pending,n===null?(l.next=t.pending=l,Lb(t,l)):(l.next=n.next,t.pending=n.next=l)}}function Lb(e,t){var n=t.action,o=t.payload,a=e.state;if(t.isTransition){var l=E.T,c={};c.types=l!==null?l.types:null,E.T=c;try{var i=n(a,o),u=E.S;u!==null&&u(c,i),Ad(e,t,i)}catch(f){du(e,t,f)}finally{l!==null&&c.types!==null&&(l.types=c.types),E.T=l}}else try{l=n(a,o),Ad(e,t,l)}catch(f){du(e,t,f)}}function Ad(e,t,n){n!==null&&typeof n=="object"&&typeof n.then=="function"?n.then(function(o){_d(e,t,o)},function(o){return du(e,t,o)}):_d(e,t,n)}function _d(e,t,n){t.status="fulfilled",t.value=n,Vb(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Lb(e,n)))}function du(e,t,n){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do t.status="rejected",t.reason=n,Vb(t),t=t.next;while(t!==o)}e.action=null}function Vb(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Qb(e,t){return t}function Cd(e,t){if(N){var n=Q.formState;if(n!==null){e:{var o=O;if(N){if(J){t:{for(var a=J,l=tt;a.nodeType!==8;){if(!l){a=null;break t}if(a=nt(a.nextSibling),a===null){a=null;break t}}l=a.data,a=l==="F!"||l==="F"?a:null}if(a){J=nt(a.nextSibling),o=a.data==="F!";break e}}mn(o)}o=!1}o&&(t=n[0])}}return n=Oe(),n.memoizedState=n.baseState=t,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Qb,lastRenderedState:t},n.queue=o,n=cv.bind(null,O,o),o.dispatch=n,o=fu(!1),l=zr.bind(null,O,!1,o.queue),o=Oe(),a={state:t,dispatch:null,action:e,pending:null},o.queue=a,n=th.bind(null,O,a,l,n),a.dispatch=n,o.memoizedState=e,[t,n,!1]}function Md(e){var t=te();return Xb(t,V,e)}function Xb(e,t,n){if(t=xr(e,t,Qb)[0],e=Rl(Ht)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var o=Ka(t)}catch(c){throw c===Vo?Ac:c}else o=t;t=te();var a=t.queue,l=a.dispatch;return n!==t.memoizedState&&(O.flags|=2048,Co(9,{destroy:void 0},nh.bind(null,a,n),null)),[o,l,e]}function nh(e,t){e.action=t}function Dd(e){var t=te(),n=V;if(n!==null)return Xb(t,n,e);te(),t=t.memoizedState,n=te();var o=n.queue.dispatch;return n.memoizedState=e,[t,o,!1]}function Co(e,t,n,o){return e={tag:e,create:n,deps:o,inst:t,next:null},t=O.updateQueue,t===null&&(t=_c(),O.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(o=n.next,n.next=e,e.next=o,t.lastEffect=e),e}function Zb(){return te().memoizedState}function Ul(e,t,n,o){var a=Oe();O.flags|=e,a.memoizedState=Co(1|t,{destroy:void 0},n,o===void 0?null:o)}function Mc(e,t,n,o){var a=te();o=o===void 0?null:o;var l=a.memoizedState.inst;V!==null&&o!==null&&gr(o,V.memoizedState.deps)?a.memoizedState=Co(t,l,n,o):(O.flags|=e,a.memoizedState=Co(1|t,l,n,o))}function Rd(e,t){Ul(8390656,8,e,t)}function kr(e,t){Mc(2048,8,e,t)}function oh(e){O.flags|=4;var t=O.updateQueue;if(t===null)t=_c(),O.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Kb(e){var t=te().memoizedState;return oh({ref:t,nextImpl:e}),function(){if((H&2)!==0)throw Error(h(440));return t.impl.apply(void 0,arguments)}}function Jb(e,t){return Mc(4,2,e,t)}function Fb(e,t){return Mc(4,4,e,t)}function Wb(e,t){if(typeof t=="function"){e=e();var n=t(e);return function(){typeof n=="function"?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function $b(e,t,n){n=n!=null?n.concat([e]):null,Mc(4,4,Wb.bind(null,t,e),n)}function Tr(){}function Ib(e,t){var n=te();t=t===void 0?null:t;var o=n.memoizedState;return t!==null&&gr(t,o[1])?o[0]:(n.memoizedState=[e,t],e)}function Pb(e,t){var n=te();t=t===void 0?null:t;var o=n.memoizedState;if(t!==null&&gr(t,o[1]))return o[0];if(o=e(),Yn){It(!0);try{e()}finally{It(!1)}}return n.memoizedState=[o,t],o}function Er(e,t,n){return n===void 0||(Bt&1073741824)!==0&&(D&261930)===0?e.memoizedState=t:(e.memoizedState=n,e=Xv(),O.lanes|=e,yn|=e,n)}function ev(e,t,n,o){return Ze(n,t)?n:pn.current!==null?(e=Er(e,n,o),Ze(e,t)||(le=!0),e):(Bt&106)===0||(Bt&1073741824)!==0&&(D&261930)===0?(le=!0,e.memoizedState=n):(e=Xv(),O.lanes|=e,yn|=e,t)}function tv(e,t,n,o,a){var l=q.p;q.p=l!==0&&8>l?l:8;var c=E.T,i={};i.types=c!==null?c.types:null,E.T=i,zr(e,!1,t,n);try{var u=a(),f=E.S;if(f!==null&&f(i,u),u!==null&&typeof u=="object"&&typeof u.then=="function"){var g=Ip(u,o);ha(e,t,g,Xe(e))}else ha(e,t,o,Xe(e))}catch(m){ha(e,t,{then:function(){},status:"rejected",reason:m},Xe())}finally{q.p=l,c!==null&&i.types!==null&&(c.types=i.types),E.T=c}}function ah(){}function su(e,t,n,o){if(e.tag!==5)throw Error(h(476));var a=nv(e).queue;tv(e,a,t,An,n===null?ah:function(){return ov(e),n(o)})}function nv(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:An,baseState:An,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ht,lastRenderedState:An},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ht,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function ov(e){var t=nv(e);t.next===null&&(t=e.alternate.memoizedState),ha(e,t.next.queue,{},Xe())}function wr(){return me(qo)}function av(){return te().memoizedState}function lv(){return te().memoizedState}function lh(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=Xe();e=cn(n);var o=un(t,e,n);o!==null&&(De(o,t,n),ga(o,t,n)),t={cache:rr()},e.payload=t;return}t=t.return}}function ch(e,t,n){var o=Xe();n={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},Dc(e)?iv(t,n):(n=cr(e,t,n,o),n!==null&&(De(n,e,o),uv(n,t,o)))}function cv(e,t,n){var o=Xe();ha(e,t,n,o)}function ha(e,t,n,o){var a={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(Dc(e))iv(t,a);else{var l=e.alternate;if(e.lanes===0&&(l===null||l.lanes===0)&&(l=t.lastRenderedReducer,l!==null))try{var c=t.lastRenderedState,i=l(c,n);if(a.hasEagerState=!0,a.eagerState=i,Ze(i,c))return Oc(e,t,a,0),Q===null&&zc(),!1}catch{}if(n=cr(e,t,a,o),n!==null)return De(n,e,o),uv(n,t,o),!0}return!1}function zr(e,t,n,o){if(o={lane:2,revertLane:Hr(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Dc(e)){if(t)throw Error(h(479))}else t=cr(e,n,o,2),t!==null&&De(t,e,2)}function Dc(e){var t=e.alternate;return e===O||t!==null&&t===O}function iv(e,t){To=lc=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function uv(e,t,n){if((n&4194048)!==0){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,Zs(e,n)}}var ic={readContext:me,use:Cc,useCallback:P,useContext:P,useEffect:P,useImperativeHandle:P,useLayoutEffect:P,useInsertionEffect:P,useMemo:P,useReducer:P,useRef:P,useState:P,useDebugValue:P,useDeferredValue:P,useTransition:P,useSyncExternalStore:P,useId:P,useHostTransitionStatus:P,useFormState:P,useActionState:P,useOptimistic:P,useMemoCache:P,useCacheRefresh:P,useEffectEvent:P},rv={readContext:me,use:Cc,useCallback:function(e,t){return Oe().memoizedState=[e,t===void 0?null:t],e},useContext:me,useEffect:Rd,useImperativeHandle:function(e,t,n){n=n!=null?n.concat([e]):null,Ul(4194308,4,Wb.bind(null,t,e),n)},useLayoutEffect:function(e,t){return Ul(4194308,4,e,t)},useInsertionEffect:function(e,t){Ul(4,2,e,t)},useMemo:function(e,t){var n=Oe();t=t===void 0?null:t;var o=e();if(Yn){It(!0);try{e()}finally{It(!1)}}return n.memoizedState=[o,t],o},useReducer:function(e,t,n){var o=Oe();if(n!==void 0){var a=n(t);if(Yn){It(!0);try{n(t)}finally{It(!1)}}}else a=t;return o.memoizedState=o.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:a},o.queue=e,e=e.dispatch=ch.bind(null,O,e),[o.memoizedState,e]},useRef:function(e){var t=Oe();return e={current:e},t.memoizedState=e},useState:function(e){e=fu(e);var t=e.queue,n=cv.bind(null,O,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:Tr,useDeferredValue:function(e,t){var n=Oe();return Er(n,e,t)},useTransition:function(){var e=fu(!1);return e=tv.bind(null,O,e.queue,!0,!1),Oe().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var o=O,a=Oe();if(N){if(n===void 0)throw Error(h(407));n=n()}else{if(n=t(),Q===null)throw Error(h(349));(D&127)!==0||Bb(o,t,n)}a.memoizedState=n;var l={value:n,getSnapshot:t};return a.queue=l,Rd(qb.bind(null,o,l,e),[e]),o.flags|=2048,Co(9,{destroy:void 0},Hb.bind(null,o,l,n,t),null),n},useId:function(){var e=Oe(),t=Q.identifierPrefix;if(N){var n=xt,o=St;n=(o&~(1<<32-Qe(o)-1)).toString(32)+n,t="_"+t+"R_"+n,n=cc++,0<n&&(t+="H"+n.toString(32)),t+="_"}else n=Pp++,t="_"+t+"r_"+n.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:wr,useFormState:Cd,useActionState:Cd,useOptimistic:function(e){var t=Oe();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=zr.bind(null,O,!0,n),n.dispatch=t,[e,t]},useMemoCache:Sr,useCacheRefresh:function(){return Oe().memoizedState=lh.bind(null,O)},useEffectEvent:function(e){var t=Oe(),n={impl:e};return t.memoizedState=n,function(){if((H&2)!==0)throw Error(h(440));return n.impl.apply(void 0,arguments)}}},fv={readContext:me,use:Cc,useCallback:Ib,useContext:me,useEffect:kr,useImperativeHandle:$b,useInsertionEffect:Jb,useLayoutEffect:Fb,useMemo:Pb,useReducer:Rl,useRef:Zb,useState:function(){return Rl(Ht)},useDebugValue:Tr,useDeferredValue:function(e,t){var n=te();return ev(n,V.memoizedState,e,t)},useTransition:function(){var e=Rl(Ht)[0],t=te().memoizedState;return[typeof e=="boolean"?e:Ka(e),t]},useSyncExternalStore:Ub,useId:av,useHostTransitionStatus:wr,useFormState:Md,useActionState:Md,useOptimistic:function(e,t){var n=te();return jb(n,V,e,t)},useMemoCache:Sr,useCacheRefresh:lv,useEffectEvent:Kb},ih={readContext:me,use:Cc,useCallback:Ib,useContext:me,useEffect:kr,useImperativeHandle:$b,useInsertionEffect:Jb,useLayoutEffect:Fb,useMemo:Pb,useReducer:ki,useRef:Zb,useState:function(){return ki(Ht)},useDebugValue:Tr,useDeferredValue:function(e,t){var n=te();return V===null?Er(n,e,t):ev(n,V.memoizedState,e,t)},useTransition:function(){var e=ki(Ht)[0],t=te().memoizedState;return[typeof e=="boolean"?e:Ka(e),t]},useSyncExternalStore:Ub,useId:av,useHostTransitionStatus:wr,useFormState:Dd,useActionState:Dd,useOptimistic:function(e,t){var n=te();return V!==null?jb(n,V,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:Sr,useCacheRefresh:lv,useEffectEvent:Kb};function Ti(e,t,n,o){t=e.memoizedState,n=n(o,t),n=n==null?t:X({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var bu={enqueueSetState:function(e,t,n){e=e._reactInternals;var o=Xe(),a=cn(o);a.payload=t,n!=null&&(a.callback=n),t=un(e,a,o),t!==null&&(De(t,e,o),ga(t,e,o))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var o=Xe(),a=cn(o);a.tag=1,a.payload=t,n!=null&&(a.callback=n),t=un(e,a,o),t!==null&&(De(t,e,o),ga(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Xe(),o=cn(n);o.tag=2,t!=null&&(o.callback=t),t=un(e,o,n),t!==null&&(De(t,e,n),ga(t,e,n))}};function Ud(e,t,n,o,a,l,c){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,l,c):t.prototype&&t.prototype.isPureReactComponent?!Oa(n,o)||!Oa(a,l):!0}function Bd(e,t,n,o){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,o),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,o),t.state!==e&&bu.enqueueReplaceState(t,t.state,null)}function Gn(e,t){var n=t;if("ref"in t){n={};for(var o in t)o!=="ref"&&(n[o]=t[o])}if(e=e.defaultProps){n===t&&(n=X({},n));for(var a in e)n[a]===void 0&&(n[a]=e[a])}return n}function dv(e){$l(e)}function sv(e){console.error(e)}function bv(e){$l(e)}function uc(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(o){setTimeout(function(){throw o})}}function Hd(e,t,n){try{var o=e.onCaughtError;o(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(a){setTimeout(function(){throw a})}}function vu(e,t,n){return n=cn(n),n.tag=3,n.payload={element:null},n.callback=function(){uc(e,t)},n}function vv(e){return e=cn(e),e.tag=3,e}function gv(e,t,n,o){var a=n.type.getDerivedStateFromError;if(typeof a=="function"){var l=o.value;e.payload=function(){return a(l)},e.callback=function(){Hd(t,n,o)}}var c=n.stateNode;c!==null&&typeof c.componentDidCatch=="function"&&(e.callback=function(){Hd(t,n,o),typeof a!="function"&&(dn===null?dn=new Set([this]):dn.add(this));var i=o.stack;this.componentDidCatch(o.value,{componentStack:i!==null?i:""})})}function uh(e,t,n,o,a){if(n.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(t=n.alternate,t!==null&&Un(t,n,a,!0),n=Se.current,n!==null){switch(n.tag){case 31:case 13:case 19:return Te===null?mc():n.alternate===null&&ee===0&&(ee=3),n.flags&=-257,n.flags|=65536,n.lanes=a,o===nc?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([o]):t.add(o),_i(e,o,a)),!1;case 22:return n.flags|=65536,o===nc?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([o])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([o]):n.add(o)),_i(e,o,a)),!1}throw Error(h(435,n.tag))}return _i(e,o,a),mc(),!1}if(N)return t=Se.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=a,o!==nu&&(e=Error(h(422),{cause:o}),Aa(et(e,n)))):(o!==nu&&(t=Error(h(423),{cause:o}),Aa(et(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,o=et(o,n),a=vu(e.stateNode,o,a),xi(e,a),ee!==4&&(ee=2)),!1;var l=Error(h(520),{cause:o});if(l=et(l,n),ka===null?ka=[l]:ka.push(l),ee!==4&&(ee=2),t===null)return!0;o=et(o,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=vu(n.stateNode,o,e),xi(n,e),!1;case 1:if(t=n.type,l=n.stateNode,(n.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||l!==null&&typeof l.componentDidCatch=="function"&&(dn===null||!dn.has(l))))return n.flags|=65536,a&=-a,n.lanes|=a,a=vv(a),gv(a,e,n,o),xi(n,a),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var Or=Error(h(461)),le=!1;function ie(e,t,n,o){t.child=e===null?Ab(t,null,n,o):qn(t,e.child,n,o)}function qd(e,t,n,o,a){n=n.render;var l=t.ref;if("ref"in o){var c={};for(var i in o)i!=="ref"&&(c[i]=o[i])}else c=o;return Bn(t),o=mr(e,t,n,c,l,a),i=pr(),e!==null&&!le?(hr(e,t,a),qt(e,t,a)):(N&&i&&Nc(t),t.flags|=1,ie(e,t,o,a),t.child)}function Yd(e,t,n,o,a){if(e===null){var l=n.type;return typeof l=="function"&&!ir(l)&&l.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=l,mv(e,t,l,o,a)):(e=Cl(n.type,null,o,t,t.mode,a),e.ref=t.ref,e.return=t,t.child=e)}if(l=e.child,!Ar(e,a)){var c=l.memoizedProps;if(n=n.compare,n=n!==null?n:Oa,n(c,o)&&e.ref===t.ref)return qt(e,t,a)}return t.flags|=1,e=Mt(l,o),e.ref=t.ref,e.return=t,t.child=e}function mv(e,t,n,o,a){if(e!==null){var l=e.memoizedProps;if(Oa(l,o)&&e.ref===t.ref)if(le=!1,t.pendingProps=o=l,Ar(e,a))(e.flags&131072)!==0&&(le=!0);else return t.lanes=e.lanes,qt(e,t,a)}return gu(e,t,n,o,a)}function pv(e,t,n,o){var a=o.children,l=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((t.flags&128)!==0){if(l=l!==null?l.baseLanes|n:n,e!==null){for(o=t.child=e.child,a=0;o!==null;)a=a|o.lanes|o.childLanes,o=o.sibling;o=a&~l}else o=0,t.child=null;return Gd(e,t,l,n,o)}if((n&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Dl(t,l!==null?l.cachePool:null),l!==null?Nd(t,l):uu(),Mb(t);else return o=t.lanes=536870912,Gd(e,t,l!==null?l.baseLanes|n:n,n,o)}else l!==null?(Dl(t,l.cachePool),Nd(t,l),fn(),t.memoizedState=null):(e!==null&&Dl(t,null),uu(),fn());return ie(e,t,a,n),t.child}function ya(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Gd(e,t,n,o,a){var l=fr();return l=l===null?null:{parent:ae._currentValue,pool:l},t.memoizedState={baseLanes:n,cachePool:l},e!==null&&Dl(t,null),uu(),Mb(t),e!==null&&Un(e,t,o,!0),t.childLanes=a,null}function Bl(e,t){return t=Rc({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function jd(e,t,n){return qn(t,e.child,null,n),e=Bl(t,t.pendingProps),e.flags|=2,Ye(t),t.memoizedState=null,e}function rh(e,t,n){var o=t.pendingProps,a=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(N){if(o.mode==="hidden")return e=Bl(t,o),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},ya(null,e);if(ru(t),(e=J)?(e=pg(e,tt),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:gn!==null?{id:St,overflow:xt}:null,retryLane:536870912,hydrationErrors:null},n=kb(e),n.return=t,t.child=n,be=t,J=null)):e=null,e===null)throw mn(t);return t.lanes=536870912,null}return Bl(t,o)}var l=e.memoizedState;if(l!==null){var c=l.dehydrated;if(ru(t),a)if(t.flags&256)t.flags&=-257,t=jd(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(h(558));else if(le||Un(e,t,n,!1),a=(n&e.childLanes)!==0,le||a){if(pn.current===null){if(o=Q,o!==null&&(c=Ks(o,n),c!==0&&c!==l.retryLane))throw l.retryLane=c,Xn(e,c),De(o,e,c),Or;mc()}t=jd(e,t,n)}else e=l.treeContext,J=nt(c.nextSibling),be=t,N=!0,ln=null,tt=!1,e!==null&&Eb(t,e),t=Bl(t,o),t.flags|=134221824;return t}return e=Mt(e.child,{mode:o.mode,children:o.children}),e.ref=t.ref,t.child=e,e.return=t,e}function no(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!="function"&&typeof n!="object")throw Error(h(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function gu(e,t,n,o,a){return Bn(t),n=mr(e,t,n,o,void 0,a),o=pr(),e!==null&&!le?(hr(e,t,a),qt(e,t,a)):(N&&o&&Nc(t),t.flags|=1,ie(e,t,n,a),t.child)}function Ld(e,t,n,o,a,l){return Bn(t),t.updateQueue=null,n=Rb(t,o,n,a),Db(e),o=pr(),e!==null&&!le?(hr(e,t,l),qt(e,t,l)):(N&&o&&Nc(t),t.flags|=1,ie(e,t,n,l),t.child)}function Vd(e,t,n,o,a){if(Bn(t),t.stateNode===null){var l=vo,c=n.contextType;typeof c=="object"&&c!==null&&(l=me(c)),l=new n(o,l),t.memoizedState=l.state!==null&&l.state!==void 0?l.state:null,l.updater=bu,t.stateNode=l,l._reactInternals=t,l=t.stateNode,l.props=o,l.state=t.memoizedState,l.refs={},sr(t),c=n.contextType,l.context=typeof c=="object"&&c!==null?me(c):vo,l.state=t.memoizedState,c=n.getDerivedStateFromProps,typeof c=="function"&&(Ti(t,n,c,o),l.state=t.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof l.getSnapshotBeforeUpdate=="function"||typeof l.UNSAFE_componentWillMount!="function"&&typeof l.componentWillMount!="function"||(c=l.state,typeof l.componentWillMount=="function"&&l.componentWillMount(),typeof l.UNSAFE_componentWillMount=="function"&&l.UNSAFE_componentWillMount(),c!==l.state&&bu.enqueueReplaceState(l,l.state,null),pa(t,o,l,a),ma(),l.state=t.memoizedState),typeof l.componentDidMount=="function"&&(t.flags|=4194308),o=!0}else if(e===null){l=t.stateNode;var i=t.memoizedProps,u=Gn(n,i);l.props=u;var f=l.context,g=n.contextType;c=vo,typeof g=="object"&&g!==null&&(c=me(g));var m=n.getDerivedStateFromProps;g=typeof m=="function"||typeof l.getSnapshotBeforeUpdate=="function",i=t.pendingProps!==i,g||typeof l.UNSAFE_componentWillReceiveProps!="function"&&typeof l.componentWillReceiveProps!="function"||(i||f!==c)&&Bd(t,l,o,c),Wt=!1;var d=t.memoizedState;l.state=d,pa(t,o,l,a),ma(),f=t.memoizedState,i||d!==f||Wt?(typeof m=="function"&&(Ti(t,n,m,o),f=t.memoizedState),(u=Wt||Ud(t,n,u,o,d,f,c))?(g||typeof l.UNSAFE_componentWillMount!="function"&&typeof l.componentWillMount!="function"||(typeof l.componentWillMount=="function"&&l.componentWillMount(),typeof l.UNSAFE_componentWillMount=="function"&&l.UNSAFE_componentWillMount()),typeof l.componentDidMount=="function"&&(t.flags|=4194308)):(typeof l.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=o,t.memoizedState=f),l.props=o,l.state=f,l.context=c,o=u):(typeof l.componentDidMount=="function"&&(t.flags|=4194308),o=!1)}else{l=t.stateNode,cu(e,t),c=t.memoizedProps,g=Gn(n,c),l.props=g,m=t.pendingProps,d=l.context,f=n.contextType,u=vo,typeof f=="object"&&f!==null&&(u=me(f)),i=n.getDerivedStateFromProps,(f=typeof i=="function"||typeof l.getSnapshotBeforeUpdate=="function")||typeof l.UNSAFE_componentWillReceiveProps!="function"&&typeof l.componentWillReceiveProps!="function"||(c!==m||d!==u)&&Bd(t,l,o,u),Wt=!1,d=t.memoizedState,l.state=d,pa(t,o,l,a),ma();var v=t.memoizedState;c!==m||d!==v||Wt||e!==null&&e.dependencies!==null&&tc(e.dependencies)?(typeof i=="function"&&(Ti(t,n,i,o),v=t.memoizedState),(g=Wt||Ud(t,n,g,o,d,v,u)||e!==null&&e.dependencies!==null&&tc(e.dependencies))?(f||typeof l.UNSAFE_componentWillUpdate!="function"&&typeof l.componentWillUpdate!="function"||(typeof l.componentWillUpdate=="function"&&l.componentWillUpdate(o,v,u),typeof l.UNSAFE_componentWillUpdate=="function"&&l.UNSAFE_componentWillUpdate(o,v,u)),typeof l.componentDidUpdate=="function"&&(t.flags|=4),typeof l.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof l.componentDidUpdate!="function"||c===e.memoizedProps&&d===e.memoizedState||(t.flags|=4),typeof l.getSnapshotBeforeUpdate!="function"||c===e.memoizedProps&&d===e.memoizedState||(t.flags|=1024),t.memoizedProps=o,t.memoizedState=v),l.props=o,l.state=v,l.context=u,o=g):(typeof l.componentDidUpdate!="function"||c===e.memoizedProps&&d===e.memoizedState||(t.flags|=4),typeof l.getSnapshotBeforeUpdate!="function"||c===e.memoizedProps&&d===e.memoizedState||(t.flags|=1024),o=!1)}return l=o,no(e,t),o=(t.flags&128)!==0,l||o?(l=t.stateNode,n=o&&typeof n.getDerivedStateFromError!="function"?null:l.render(),t.flags|=1,e!==null&&o?(t.child=qn(t,e.child,null,a),t.child=qn(t,null,n,a)):ie(e,t,n,a),t.memoizedState=l.state,e=t.child):e=qt(e,t,a),e}function Qd(e,t,n,o){return Rn(),t.flags|=256,ie(e,t,n,o),t.child}var mu={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function pu(e){return{baseLanes:e,cachePool:zb()}}function hu(e,t,n){return e=e!==null?e.childLanes&~n:0,t&&(e|=je),e}function hv(e,t,n){var o=t.pendingProps,a=!1,l=(t.flags&128)!==0,c;if((c=l)||(c=e!==null&&e.memoizedState===null?!1:(he.current&2)!==0),c&&(a=!0,t.flags&=-129),c=(t.flags&32)!==0,t.flags&=-33,e===null){if(N){if(a?rn(t):fn(),(e=J)?(e=pg(e,tt),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:gn!==null?{id:St,overflow:xt}:null,retryLane:536870912,hydrationErrors:null},n=kb(e),n.return=t,t.child=n,be=t,J=null)):e=null,e===null)throw mn(t);return jr(e)?t.lanes=32:t.lanes=536870912,null}return l=o.children,o=o.fallback,a?(fn(),a=t.mode,l=Rc({mode:"hidden",children:l},a),o=_n(o,a,n,null),l.return=t,o.return=t,l.sibling=o,t.child=l,o=t.child,o.memoizedState=pu(n),o.childLanes=hu(e,c,n),t.memoizedState=mu,ya(null,o)):(rn(t),Nr(t,l))}var i=e.memoizedState;if(i!==null){var u=i.dehydrated;if(u!==null)return fh(e,t,l,c,o,u,i,n)}return a?(fn(),a=o.fallback,l=t.mode,i=e.child,u=i.sibling,o=Mt(i,{mode:"hidden",children:o.children}),o.subtreeFlags=i.subtreeFlags&1206910976,u!==null?a=Mt(u,a):(a=_n(a,l,n,null),a.flags|=2),a.return=t,o.return=t,o.sibling=a,t.child=o,ya(null,o),o=t.child,a=e.child.memoizedState,a===null?a=pu(n):(l=a.cachePool,l!==null?(i=ae._currentValue,l=l.parent!==i?{parent:i,pool:i}:l):l=zb(),a={baseLanes:a.baseLanes|n,cachePool:l}),o.memoizedState=a,o.childLanes=hu(e,c,n),t.memoizedState=mu,ya(e.child,o)):(rn(t),n=e.child,e=n.sibling,n=Mt(n,{mode:"visible",children:o.children}),n.return=t,n.sibling=null,e!==null&&(c=t.deletions,c===null?(t.deletions=[e],t.flags|=16):c.push(e)),t.child=n,t.memoizedState=null,n)}function Nr(e,t){return t=Rc({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function Rc(e,t){return e=Me(22,e,null,t),e.lanes=0,e}function pl(e,t,n){return qn(t,e.child,null,n),e=Nr(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function fh(e,t,n,o,a,l,c,i){if(n)return t.flags&256?(rn(t),t.flags&=-257,pl(e,t,i)):t.memoizedState!==null?(fn(),t.child=e.child,t.flags|=128,null):(fn(),l=a.fallback,c=t.mode,a=Rc({mode:"visible",children:a.children},c),l=_n(l,c,i,null),l.flags|=2,a.return=t,l.return=t,a.sibling=l,t.child=a,qn(t,e.child,null,i),a=t.child,a.memoizedState=pu(i),a.childLanes=hu(e,o,i),t.memoizedState=mu,ya(null,a));if(rn(t),jr(l)){if(o=l.nextSibling&&l.nextSibling.dataset,o)var u=o.dgst;return o=u,o!==""&&(a=Error(h(419)),a.stack="",a.digest=o,Aa({value:a,source:null,stack:null})),pl(e,t,i)}if(le||Un(e,t,i,!1),o=(i&e.childLanes)!==0,le||o){if(pn.current!==null)return pl(e,t,i);if(o=Q,o!==null&&(a=Ks(o,i),a!==0&&a!==c.retryLane))throw c.retryLane=a,Xn(e,a),De(o,e,a),Or;return Vu(l)||mc(),pl(e,t,i)}return Vu(l)?(t.flags|=192,t.child=e.child,null):(e=c.treeContext,J=nt(l.nextSibling),be=t,N=!0,ln=null,tt=!1,e!==null&&Eb(t,e),t=Nr(t,a.children),t.flags|=134221824,t)}function Xd(e,t,n){e.lanes|=t;var o=e.alternate;o!==null&&(o.lanes|=t),Ml(e.return,t,n)}function Zd(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&ac(n)===null&&(t=e),e=e.sibling}return t}function hl(e,t,n,o,a,l){var c=e.memoizedState;c===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:o,tail:n,tailMode:a,treeForkCount:l}:(c.isBackwards=t,c.rendering=null,c.renderingStartTime=0,c.last=o,c.tail=n,c.tailMode=a,c.treeForkCount=l)}function Ei(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function yu(e,t,n){var o=t.pendingProps,a=o.revealOrder,l=o.tail;o=o.children;var c=he.current;if(t.flags&128)return Ca(t,c),null;var i=(c&2)!==0;if(i?(c=c&1|2,t.flags|=128):c&=1,Ca(t,c),a==="backwards"&&e!==null?(Ei(e),ie(e,t,o,n),Ei(e)):ie(e,t,o,n),o=N?Na:0,!i&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Xd(e,n,t);else if(e.tag===19)Xd(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(a){case"backwards":n=Zd(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null,Ei(t)),hl(t,!0,a,null,l,o);break;case"unstable_legacy-backwards":for(n=null,a=t.child,t.child=null;a!==null;){if(e=a.alternate,e!==null&&ac(e)===null){t.child=a;break}e=a.sibling,a.sibling=n,n=a,a=e}hl(t,!0,n,null,l,o);break;case"together":hl(t,!1,null,null,void 0,o);break;case"independent":t.memoizedState=null;break;default:n=Zd(t.child),n===null?(a=t.child,t.child=null):(a=n.sibling,n.sibling=null),hl(t,!1,a,n,l,o)}return t.child}function Kd(e,t,n){var o=t.pendingProps;return en(t,t.type,o.value),ie(e,t,o.children,n),t.child}function qt(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),yn|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(Un(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(h(153));if(t.child!==null){for(e=t.child,n=Mt(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Mt(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function Ar(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&tc(e)))}function dh(e,t,n){switch(t.tag){case 3:Kl(t,t.stateNode.containerInfo),en(t,ae,e.memoizedState.cache),Rn();break;case 27:case 5:Zi(t);break;case 4:Kl(t,t.stateNode.containerInfo);break;case 10:en(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,ru(t),null;break;case 13:var o=t.memoizedState;if(o!==null){if(o.dehydrated!==null)return rn(t),t.flags|=128,null;o=Un(e,t,n,!1);var a=t.child.childLanes;return o||(n&a)!==0?hv(e,t,n):(rn(t),e=qt(e,t,n),e!==null?e.sibling:null)}rn(t);break;case 19:if(t.flags&128)return yu(e,t,n);if(a=(e.flags&128)!==0,o=(n&t.childLanes)!==0,o||(Un(e,t,n,!1),o=(n&t.childLanes)!==0),a){if(o)return yu(e,t,n);t.flags|=128}if(a=t.memoizedState,a!==null&&(a.rendering=null,a.tail=null,a.lastEffect=null),Ca(t,he.current),o)break;return null;case 22:return t.lanes=0,pv(e,t,n,t.pendingProps);case 24:en(t,ae,e.memoizedState.cache)}return qt(e,t,n)}function yv(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)le=!0;else{if(!Ar(e,n)&&(t.flags&128)===0)return le=!1,dh(e,t,n);le=(e.flags&131072)!==0}else le=!1,N&&(t.flags&1048576)!==0&&Tb(t,Na,t.index);switch(t.lanes=0,t.tag){case 16:e:{var o=t.pendingProps;if(e=wn(t.elementType),t.type=e,typeof e=="function")ir(e)?(o=Gn(e,o),t.tag=1,t=Vd(null,t,e,o,n)):(t.tag=0,t=gu(null,t,e,o,n));else{if(e!=null){var a=e.$$typeof;if(a===Ju){t.tag=11,t=qd(null,t,e,o,n);break e}else if(a===Fu){t.tag=14,t=Yd(null,t,e,o,n);break e}else if(a===ht){t.tag=10,t.type=e,t=Kd(null,t,n);break e}}throw t=Qi(e)||e,Error(h(306,t,""))}}return t;case 0:return gu(e,t,t.type,t.pendingProps,n);case 1:return o=t.type,a=Gn(o,t.pendingProps),Vd(e,t,o,a,n);case 3:e:{if(Kl(t,t.stateNode.containerInfo),e===null)throw Error(h(387));o=t.pendingProps;var l=t.memoizedState;a=l.element,cu(e,t),pa(t,o,null,n);var c=t.memoizedState;if(o=c.cache,en(t,ae,o),o!==l.cache&&au(t,[ae],n,!0),ma(),o=c.element,l.isDehydrated)if(l={element:o,isDehydrated:!1,cache:c.cache},t.updateQueue.baseState=l,t.memoizedState=l,t.flags&256){t=Qd(e,t,o,n);break e}else if(o!==a){a=et(Error(h(424)),t),Aa(a),t=Qd(e,t,o,n);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,J=nt(e.firstChild),be=t,N=!0,ln=null,tt=!0,n=Ab(t,null,o,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling;else{if(Rn(),o===a){t=qt(e,t,n);break e}ie(e,t,o,n)}t=t.child}return t;case 26:return no(e,t),e===null?(n=Ss(t.type,null,t.pendingProps,null))?t.memoizedState=n:N||(t.stateNode=ug(t.type,t.pendingProps,an.current,t)):t.memoizedState=Ss(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return Zi(t),e===null&&N&&(o=t.stateNode=hg(t.type,t.pendingProps,an.current),be=t,tt=!0,a=J,xn(t.type)?(Qu=a,J=nt(o.firstChild)):J=a),ie(e,t,t.pendingProps.children,n),no(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&N&&((a=o=J)&&(o=o0(o,t.type,t.pendingProps,tt),o!==null?(t.stateNode=o,be=t,J=nt(o.firstChild),tt=!1,a=!0):a=!1),a||mn(t)),Zi(t),a=t.type,l=t.pendingProps,c=e!==null?e.memoizedProps:null,o=l.children,Gu(a,l)?o=null:c!==null&&Gu(a,c)&&(t.flags|=32),t.memoizedState!==null&&(a=mr(e,t,eh,null,null,n),qo._currentValue=a),no(e,t),ie(e,t,o,n),t.child;case 6:return e===null&&N&&((e=n=J)&&(n=a0(n,t.pendingProps,tt),n!==null?(t.stateNode=n,be=t,J=null,e=!0):e=!1),e||mn(t)),null;case 13:return hv(e,t,n);case 4:return Kl(t,t.stateNode.containerInfo),o=t.pendingProps,e===null?t.child=qn(t,null,o,n):ie(e,t,o,n),t.child;case 11:return qd(e,t,t.type,t.pendingProps,n);case 7:return o=t.pendingProps,no(e,t),ie(e,t,o,n),t.child;case 8:return ie(e,t,t.pendingProps.children,n),t.child;case 12:return ie(e,t,t.pendingProps.children,n),t.child;case 10:return Kd(e,t,n);case 9:return a=t.type._context,o=t.pendingProps.children,Bn(t),a=me(a),o=o(a),t.flags|=1,ie(e,t,o,n),t.child;case 14:return Yd(e,t,t.type,t.pendingProps,n);case 15:return mv(e,t,t.type,t.pendingProps,n);case 19:return yu(e,t,n);case 31:return rh(e,t,n);case 22:return pv(e,t,n,t.pendingProps);case 24:return Bn(t),o=me(ae),e===null?(a=fr(),a===null&&(a=Q,l=rr(),a.pooledCache=l,l.refCount++,l!==null&&(a.pooledCacheLanes|=n),a=l),t.memoizedState={parent:o,cache:a},sr(t),en(t,ae,a)):((e.lanes&n)!==0&&(cu(e,t),pa(t,null,null,n),ma()),a=e.memoizedState,l=t.memoizedState,a.parent!==o?(a={parent:o,cache:o},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),en(t,ae,o)):(o=l.cache,en(t,ae,o),o!==a.cache&&au(t,[ae],n,!0))),ie(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),o=t.pendingProps,o.name!=null&&o.name!=="auto"?t.flags|=e===null?18882560:18874368:N&&Nc(t),e!==null&&e.memoizedProps.name!==o.name?t.flags|=4194816:no(e,t),ie(e,t,o.children,n),t.child;case 29:throw t.pendingProps}throw Error(h(156,t.tag))}function At(e){e.flags|=4}function wi(e,t,n,o,a){var l;if((l=(e.mode&32)!==0)&&(l=n===null?Ts(t,o):Ts(t,o)&&(o.src!==n.src||o.srcSet!==n.srcSet)),l){if(e.flags|=16777216,(a&335544128)===a)if(e.stateNode.complete)e.flags|=8192;else if(Jv())e.flags|=8192;else throw Mn=nc,dr}else e.flags&=-16777217}function Jd(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!kg(t))if(Jv())e.flags|=8192;else throw Mn=nc,dr}function yl(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?Qs():536870912,e.lanes|=t,Mo|=t)}function na(e,t){if(!N)switch(e.tailMode){case"visible":break;case"collapsed":for(var n=e.tail,o=null;n!==null;)n.alternate!==null&&(o=n),n=n.sibling;o===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function K(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,o=0;if(t)for(var a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags&1206910976,o|=a.flags&1206910976,a.return=e,a=a.sibling;else for(a=e.child;a!==null;)n|=a.lanes|a.childLanes,o|=a.subtreeFlags,o|=a.flags,a.return=e,a=a.sibling;return e.subtreeFlags|=o,e.childLanes=n,t}function sh(e,t,n){var o=t.pendingProps;switch(ur(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return K(t),null;case 1:return K(t),null;case 3:return n=t.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),t.memoizedState.cache!==o&&(t.flags|=2048),Dt(ae),No(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(eo(t)?At(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,Si())),K(t),null;case 26:var a=t.type,l=t.memoizedState;return e===null?(At(t),l!==null?(K(t),Jd(t,l)):(K(t),wi(t,a,null,o,n))):l?l!==e.memoizedState?(At(t),K(t),Jd(t,l)):(K(t),t.flags&=-16777217):(e=e.memoizedProps,e!==o&&At(t),K(t),wi(t,a,e,o,n)),null;case 27:if(Jl(t),n=an.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&At(t);else{if(!o){if(t.stateNode===null)throw Error(h(166));return K(t),t.subtreeFlags&=-33554433,null}e=kt.current,eo(t)?xd(t,e):(e=hg(a,o,n),t.stateNode=e,At(t))}return K(t),t.subtreeFlags&=-33554433,null;case 5:if(Jl(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&At(t);else{if(!o){if(t.stateNode===null)throw Error(h(166));return K(t),t.subtreeFlags&=-33554433,null}if(l=kt.current,eo(t))xd(t,l);else{var c=Ua(an.current);switch(l){case 1:l=c.createElementNS("http://www.w3.org/2000/svg",a);break;case 2:l=c.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;default:switch(a){case"svg":l=c.createElementNS("http://www.w3.org/2000/svg",a);break;case"math":l=c.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;case"script":l=c.createElement("div"),l.innerHTML="<script><\/script>",l=l.removeChild(l.firstChild);break;case"select":l=typeof o.is=="string"?c.createElement("select",{is:o.is}):c.createElement("select"),o.multiple?l.multiple=!0:o.size&&(l.size=o.size);break;default:l=typeof o.is=="string"?c.createElement(a,{is:o.is}):c.createElement(a)}}l[ge]=t,l[Ue]=o;e:for(c=t.child;c!==null;){if(c.tag===5||c.tag===6)l.appendChild(c.stateNode);else if(c.tag!==4&&c.tag!==27&&c.child!==null){c.child.return=c,c=c.child;continue}if(c===t)break e;for(;c.sibling===null;){if(c.return===null||c.return===t)break e;c=c.return}c.sibling.return=c.return,c=c.sibling}t.stateNode=l;e:switch(ye(l,a,o),a){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&At(t)}}return K(t),t.subtreeFlags&=-33554433,wi(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==o&&At(t);else{if(typeof o!="string"&&t.stateNode===null)throw Error(h(166));if(e=an.current,eo(t)){if(e=t.stateNode,n=t.memoizedProps,o=null,a=be,a!==null)switch(a.tag){case 27:case 5:o=a.memoizedProps}e[ge]=t,e=!!(e.nodeValue===n||o!==null&&o.suppressHydrationWarning===!0||cg(e.nodeValue,n)),e||mn(t,!0)}else e=Ua(e).createTextNode(o),e[ge]=t,t.stateNode=e}return K(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(o=eo(t),n!==null){if(e===null){if(!o)throw Error(h(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(h(557));e[ge]=t}else Rn(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;K(t),e=!1}else n=Si(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(Ye(t),t):(Ye(t),null);if((t.flags&128)!==0)throw Error(h(558))}return K(t),null;case 13:if(o=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=eo(t),o!==null&&o.dehydrated!==null){if(e===null){if(!a)throw Error(h(318));if(a=t.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(h(317));a[ge]=t}else Rn(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;K(t),a=!1}else a=Si(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(Ye(t),t):(Ye(t),null)}return Ye(t),(t.flags&128)!==0?(t.lanes=n,t):(n=o!==null,e=e!==null&&e.memoizedState!==null,n&&(o=t.child,a=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(a=o.alternate.memoizedState.cachePool.pool),l=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(l=o.memoizedState.cachePool.pool),l!==a&&(o.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),yl(t,t.updateQueue),K(t),null);case 4:return No(),e===null&&qr(t.stateNode.containerInfo),t.flags|=67108864,K(t),null;case 10:return Dt(t.type),K(t),null;case 19:if(vr(t),o=t.memoizedState,o===null)return K(t),null;if(a=(t.flags&128)!==0,l=o.rendering,l===null)if(a)na(o,!1);else{if(ee!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(l=ac(e),l!==null){for(t.flags|=128,na(o,!1),e=l.updateQueue,t.updateQueue=e,yl(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)xb(n,e),n=n.sibling;return Ca(t,he.current&1|2),N&&_t(t,o.treeForkCount),t.child}e=e.sibling}o.tail!==null&&Le()>vc&&(t.flags|=128,a=!0,na(o,!1),t.lanes=4194304)}else{if(!a)if(e=ac(l),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,yl(t,e),na(o,!0),o.tail===null&&o.tailMode!=="collapsed"&&o.tailMode!=="visible"&&!l.alternate&&!N)return K(t),null}else 2*Le()-o.renderingStartTime>vc&&n!==536870912&&(t.flags|=128,a=!0,na(o,!1),t.lanes=4194304);o.isBackwards?(l.sibling=t.child,t.child=l):(e=o.last,e!==null?e.sibling=l:t.child=l,o.last=l)}if(o.tail!==null){e=o.tail;e:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break e}n=n.sibling}n=!0}return o.rendering=e,o.tail=e.sibling,o.renderingStartTime=Le(),e.sibling=null,l=he.current,l=a?l&1|2:l&1,o.tailMode==="visible"||o.tailMode==="collapsed"||!n||N?Ca(t,l):(n=l,F(Se,t),F(he,n),Te===null&&(Te=t)),N&&_t(t,o.treeForkCount),e}return K(t),null;case 22:case 23:return Ye(t),br(),o=t.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(t.flags|=8192):o&&(t.flags|=8192),o?(n&536870912)!==0&&(t.flags&128)===0&&(K(t),t.subtreeFlags&6&&(t.flags|=8192)):K(t),n=t.updateQueue,n!==null&&yl(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),o=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),o!==n&&(t.flags|=2048),e!==null&&pe(Cn),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),Dt(ae),K(t),null;case 25:return null;case 30:return t.flags|=33554432,K(t),null}throw Error(h(156,t.tag))}function bh(e,t){switch(ur(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return Dt(ae),No(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return Jl(t),null;case 31:if(t.memoizedState!==null){if(Ye(t),t.alternate===null)throw Error(h(340));Rn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(Ye(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(h(340));Rn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return vr(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return No(),null;case 10:return Dt(t.type),null;case 22:case 23:return Ye(t),br(),e!==null&&pe(Cn),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return Dt(ae),null;case 25:return null;default:return null}}function Sv(e,t){switch(ur(t),t.tag){case 3:Dt(ae),No();break;case 26:case 27:case 5:Jl(t);break;case 4:No();break;case 31:t.memoizedState!==null&&Ye(t);break;case 13:Ye(t);break;case 19:vr(t);break;case 10:Dt(t.type);break;case 22:case 23:Ye(t),br(),e!==null&&pe(Cn);break;case 24:Dt(ae)}}function Ja(e,t){try{var n=t.updateQueue,o=n!==null?n.lastEffect:null;if(o!==null){var a=o.next;n=a;do{if((n.tag&e)===e){o=void 0;var l=n.create,c=n.inst;o=l(),c.destroy=o}n=n.next}while(n!==a)}}catch(i){L(t,t.return,i)}}function hn(e,t,n){try{var o=t.updateQueue,a=o!==null?o.lastEffect:null;if(a!==null){var l=a.next;o=l;do{if((o.tag&e)===e){var c=o.inst,i=c.destroy;if(i!==void 0){c.destroy=void 0,a=t;var u=n,f=i;try{f()}catch(g){L(a,u,g)}}}o=o.next}while(o!==l)}}catch(g){L(t,t.return,g)}}function xv(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{Cb(t,n)}catch(o){L(e,e.return,o)}}}function kv(e,t,n){n.props=Gn(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(o){L(e,t,o)}}function mt(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:var a=e.stateNode,l=Ut(e.memoizedProps,a);(a.ref===null||a.ref.name!==l)&&(a.ref=sg(l)),o=a.ref;break;case 7:if(e.stateNode===null){var c=new Ke(e);Re(e.child,!1,t0,c,void 0,void 0),e.stateNode=c}o=e.stateNode;break;default:o=e.stateNode}typeof n=="function"?e.refCleanup=n(o):n.current=o}}catch(i){L(e,t,i)}}function ve(e,t){var n=e.ref,o=e.refCleanup;if(n!==null)if(typeof o=="function")try{o()}catch(a){L(e,t,a)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n=="function")try{n(null)}catch(a){L(e,t,a)}else n.current=null}function rc(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)mg(e.stateNode,t[n])}function Fd(e){for(var t=e.return;t!==null&&(Cr(t)&&mg(e.stateNode,t.stateNode),!_r(t));)t=t.return}function Sa(e){for(var t=e.return;t!==null&&(Cr(t)&&n0(e.stateNode,t.stateNode),!_r(t));)t=t.return}function _r(e){return e.tag===5||e.tag===3||e.tag===27}function Cr(e){return e&&e.tag===7&&e.stateNode!==null}function Su(e){var t=e.type,n=e.memoizedProps,o=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&o.focus();break e;case"img":n.src?o.src=n.src:n.srcSet&&(o.srcset=n.srcSet)}}catch(a){L(e,e.return,a)}}function zi(e,t,n){try{var o=e.stateNode;Hh(o,e.type,n,t),o[Ue]=t}catch(a){L(e,e.return,a)}}function Tv(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&xn(e.type)||e.tag===4}function Oi(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Tv(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&xn(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function xu(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n).insertBefore(a,t):(t=n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.appendChild(a),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=yt)),rc(e,o),B=!0;else if(a!==4&&(a===27&&(rc(e,o),o=null,xn(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(xu(e,t,n,o),e=e.sibling;e!==null;)xu(e,t,n,o),e=e.sibling}function fc(e,t,n,o){var a=e.tag;if(a===5||a===6)a=e.stateNode,t?n.insertBefore(a,t):n.appendChild(a),rc(e,o),B=!0;else if(a!==4&&(a===27&&(rc(e,o),o=null,xn(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(fc(e,t,n,o),e=e.sibling;e!==null;)fc(e,t,n,o),e=e.sibling}function Ev(e){var t=e.stateNode,n=e.memoizedProps;try{for(var o=e.type,a=t.attributes;a.length;)t.removeAttributeNode(a[0]);ye(t,o,n),t[ge]=e,t[Ue]=n}catch(l){L(e,e.return,l)}}var dc=!1,Ge=null;function Wd(e){(e.tag===30||(e.subtreeFlags&33554432)!==0)&&(dc=!0)}var pt=null;function $d(){var e=pt;return pt=null,e}var Ce=0;function Qo(e,t,n,o,a){return Ce=0,wv(e.child,t,n,o,a)}function wv(e,t,n,o,a){for(var l=!1;e!==null;){if(e.tag===5){var c=e.stateNode;if(o!==null){var i=ju(c);o.push(i),i.view&&(l=!0)}else l||ju(c).view&&(l=!0);dc=!0,rg(c,Ce===0?t:t+"_"+Ce,n),Ce++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&a||wv(e.child,t,n,o,a)&&(l=!0));e=e.sibling}return l}function Et(e,t){for(;e!==null;)e.tag===5?fg(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||Et(e.child,t)),e=e.sibling}function Hl(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(Hl(e),e.tag===30&&(e.flags&18874368)!==0&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name==="auto")throw Error(h(544));var n=t.name;t=jt(t.default,t.share),t!=="none"&&(Qo(e,n,t,null,!1)||Et(e.child,!1))}e=e.sibling}}function ku(e,t){if(e.tag===30){var n=e.stateNode,o=e.memoizedProps,a=Ut(o,n),l=jt(o.default,n.paired?o.share:o.enter);l!=="none"?Qo(e,a,l,null,!1)?(Hl(e),n.paired||t||Do(e,o.onEnter)):Et(e.child,!1):Hl(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)ku(e,t),e=e.sibling;else Hl(e)}function Tu(e){if(Ge!==null&&Ge.size!==0){var t=Ge;if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var n=e.memoizedProps,o=n.name;if(o!=null&&o!=="auto"){var a=t.get(o);if(a!==void 0){var l=jt(n.default,n.share);if(l!=="none"&&(Qo(e,o,l,null,!1)?(l=e.stateNode,a.paired=l,l.paired=a,Do(e,n.onShare)):Et(e.child,!1)),t.delete(o),t.size===0)break}}}Tu(e)}e=e.sibling}}}function Eu(e){if(e.tag===30){var t=e.memoizedProps,n=Ut(t,e.stateNode),o=Ge!==null?Ge.get(n):void 0,a=jt(t.default,o!==void 0?t.share:t.exit);a!=="none"&&(Qo(e,n,a,null,!1)?o!==void 0?(a=e.stateNode,o.paired=a,a.paired=o,Ge.delete(n),Do(e,t.onShare)):Do(e,t.onExit):Et(e.child,!1)),Ge!==null&&Tu(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Eu(e),e=e.sibling;else Ge!==null&&Tu(e)}function zv(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=Ut(t,e.stateNode);t=jt(t.default,t.update),e.flags&=-5,t!=="none"&&Qo(e,n,t,e.memoizedState=[],!1)}else(e.subtreeFlags&33554432)!==0&&zv(e);e=e.sibling}}function wu(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var t=e.stateNode;t.paired!==null&&(t.paired=null,Et(e.child,!1))}wu(e)}e=e.sibling}}function ql(e){if(e.tag===30)e.stateNode.paired=null,Et(e.child,!1),wu(e);else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)ql(e),e=e.sibling;else wu(e)}function Ov(e){for(e=e.child;e!==null;)e.tag===30?Et(e.child,!1):(e.subtreeFlags&33554432)!==0&&Ov(e),e=e.sibling}function Mr(e,t,n,o,a,l,c){for(var i=!1;t!==null;){if(t.tag===5){var u=t.stateNode;if(l!==null&&Ce<l.length){var f=l[Ce],g=ju(u);(f.view||g.view)&&(i=!0);var m;if(m=(e.flags&4)===0)if(g.clip)m=!0;else{m=f.rect;var d=g.rect;m=m.y!==d.y||m.x!==d.x||m.height!==d.height||m.width!==d.width}m&&(e.flags|=4),g.abs?g=!f.abs:(f=f.rect,g=g.rect,g=f.height!==g.height||f.width!==g.width),g&&(e.flags|=32)}else e.flags|=32;(e.flags&4)!==0&&rg(u,Ce===0?n:n+"_"+Ce,a),i&&(e.flags&4)!==0||(pt===null&&(pt=[]),pt.push(u,Ce===0?o:o+"_"+Ce,t.memoizedProps)),Ce++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&c?e.flags|=t.flags&32:Mr(e,t.child,n,o,a,l,c)&&(i=!0));t=t.sibling}return i}function Nv(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,o=e.stateNode,a=Ut(n,o),l=jt(n.default,n.update);if(t){o=o.clones;var c=o===null?null:o.map(Vh)}else c=e.memoizedState,e.memoizedState=null;o=e;var i=e.child;Ce=0,a=Mr(o,i,a,a,l,c,!1),(e.flags&4)!==0&&a&&(t||Do(e,n.onUpdate))}else(e.subtreeFlags&33554432)!==0&&Nv(e,t);e=e.sibling}}var fe=!1,Y=!1,bt=!1,Ni=!1,Id=typeof WeakSet=="function"?WeakSet:Set,de=null,vt=!1,fa=!1,sc=!1,zu=!1;function vh(e,t,n){if(e=e.containerInfo,qu=Yo,e=bb(e),ar(e)){if("selectionStart"in e)var o={start:e.selectionStart,end:e.selectionEnd};else e:{o=(o=e.ownerDocument)&&o.defaultView||window;var a=o.getSelection&&o.getSelection();if(a&&a.rangeCount!==0){o=a.anchorNode;var l=a.anchorOffset,c=a.focusNode;a=a.focusOffset;try{o.nodeType,c.nodeType}catch{o=null;break e}var i=0,u=-1,f=-1,g=0,m=0,d=e,v=null;t:for(;;){for(var y;d!==o||l!==0&&d.nodeType!==3||(u=i+l),d!==c||a!==0&&d.nodeType!==3||(f=i+a),d.nodeType===3&&(i+=d.nodeValue.length),(y=d.firstChild)!==null;)v=d,d=y;for(;;){if(d===e)break t;if(v===o&&++g===l&&(u=i),v===c&&++m===a&&(f=i),(y=d.nextSibling)!==null)break;d=v,v=d.parentNode}d=y}o=u===-1||f===-1?null:{start:u,end:f}}else o=null}o=o||{start:0,end:0}}else o=null;for(Yu={focusedElem:e,selectionRange:o},Yo=!1,n=(n&335544064)===n,de=t,t=n?9270:1024;de!==null;){if(e=de,n&&(o=e.deletions,o!==null))for(l=0;l<o.length;l++)n&&Eu(o[l]);if(e.alternate===null&&(e.flags&2)!==0)n&&Wd(e),Sl(n);else{if(e.tag===22){if(o=e.alternate,e.memoizedState!==null){o!==null&&o.memoizedState===null&&n&&Eu(o),Sl(n);continue}else if(o!==null&&o.memoizedState!==null){n&&Wd(e),Sl(n);continue}}o=e.child,(e.subtreeFlags&t)!==0&&o!==null?(o.return=e,de=o):(n&&zv(e),Sl(n))}}Ge=null}function Sl(e){for(;de!==null;){var t=de,n=e,o=t.alternate,a=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if((a&1024)!==0&&o!==null){n=void 0,a=o.memoizedProps,o=o.memoizedState;var l=t.stateNode;try{var c=Gn(t.type,a);n=l.getSnapshotBeforeUpdate(c,o),l.__reactInternalSnapshotBeforeUpdate=n}catch(i){L(t,t.return,i)}}break;case 3:if((a&1024)!==0){if(o=t.stateNode.containerInfo,n=o.nodeType,n===9)Lu(o);else if(n===1)switch(o.nodeName){case"HEAD":case"HTML":case"BODY":Lu(o);break;default:o.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&o!==null&&(n=Ut(o.memoizedProps,o.stateNode),a=t.memoizedProps,a=jt(a.default,a.update),a!=="none"&&Qo(o,n,a,o.memoizedState=[],!0));break;default:if((a&1024)!==0)throw Error(h(163))}if(o=t.sibling,o!==null){o.return=t.return,de=o;break}de=t.return}}function Av(e,t,n){var o=n.flags;switch(n.tag){case 0:case 11:case 15:gt(e,n),o&4&&Ja(5,n);break;case 1:if(gt(e,n),o&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(c){L(n,n.return,c)}else{var a=Gn(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(a,t,e.__reactInternalSnapshotBeforeUpdate)}catch(c){L(n,n.return,c)}}o&64&&xv(n),o&512&&mt(n,n.return);break;case 3:if(gt(e,n),o&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{Cb(e,t)}catch(c){L(n,n.return,c)}}break;case 27:t===null&&o&4&&Ev(n);case 26:case 5:gt(e,n),t===null&&o&4&&Su(n),o&512&&mt(n,n.return);break;case 12:gt(e,n);break;case 31:gt(e,n),o&4&&Dv(e,n);break;case 13:gt(e,n),o&4&&Rv(e,n),o&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=zh.bind(null,n),l0(e,n))));break;case 22:if(o=n.memoizedState!==null||fe,!o){var l=t!==null&&t.memoizedState!==null||Y;t=fe,a=Y,fe=o,(Y=l)&&!a?(o=2,(n.subtreeFlags&8772)!==0&&(o|=1),ct(e,n,o)):gt(e,n),fe=t,Y=a}break;case 30:gt(e,n),o&512&&mt(n,n.return);break;case 7:o&512&&mt(n,n.return);default:gt(e,n)}}function Ou(e,t){for(e=e.child;e!==null;)_v(e,t),e=e.sibling}function _v(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var o=n.style;typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"}else{var a=e.stateNode,l=e.memoizedProps.style,c=l!=null&&l.hasOwnProperty("display")?l.display:null;a.style.display=c==null||typeof c=="boolean"?"":(""+c).trim()}}catch(u){L(e,e.return,u)}Nu(e,t);break;case 6:try{e.stateNode.nodeValue=t?"":e.memoizedProps,B=!0}catch(u){L(e,e.return,u)}break;case 18:try{var i=e.stateNode;t?vs(i,!0):vs(e.stateNode,!1)}catch(u){L(e,e.return,u)}break;case 22:case 23:e.memoizedState===null&&Ou(e,t);break;default:Ou(e,t)}}function Nu(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){e:{var n=e,o=t;switch(n.tag){case 4:_v(n,o);break e;case 22:n.memoizedState===null&&Nu(n,o);break e;default:Nu(n,o)}}e=e.sibling}}function Cv(e){var t=e.alternate;t!==null&&(e.alternate=null,Cv(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&kc(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var $=null,Ae=!1;function lt(e,t,n){for(n=n.child;n!==null;)Mv(e,t,n),n=n.sibling}function Mv(e,t,n){if(Ve&&typeof Ve.onCommitFiberUnmount=="function")try{Ve.onCommitFiberUnmount(ja,n)}catch{}switch(n.tag){case 26:Y||ve(n,t),lt(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!Y&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:Y||ve(n,t),Sa(n);var o=$,a=Ae;xn(n.type)&&($=n.stateNode,Ae=!1),lt(e,t,n),yg(n.stateNode,n.type,n.memoizedProps),$=o,Ae=a;break;case 5:Y||ve(n,t),Sa(n);case 6:if(n.tag===6&&Sa(n),o=$,a=Ae,$=null,lt(e,t,n),$=o,Ae=a,$!==null)if(Ae)try{($.nodeType===9?$.body:$.nodeName==="HTML"?$.ownerDocument.body:$).removeChild(n.stateNode),B=!0}catch(l){L(n,t,l)}else try{$.removeChild(n.stateNode),B=!0}catch(l){L(n,t,l)}break;case 18:$!==null&&(Ae?(e=$,bs(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,n.stateNode),Go(e)):bs($,n.stateNode));break;case 4:o=$,a=Ae,$=n.stateNode.containerInfo,Ae=!0,lt(e,t,n),$=o,Ae=a;break;case 0:case 11:case 14:case 15:hn(2,n,t),Y||hn(4,n,t),lt(e,t,n);break;case 1:Y||(ve(n,t),o=n.stateNode,typeof o.componentWillUnmount=="function"&&kv(n,t,o)),lt(e,t,n);break;case 21:lt(e,t,n);break;case 22:Y=(o=Y)||n.memoizedState!==null,lt(e,t,n),Y=o;break;case 30:ve(n,t),lt(e,t,n);break;case 7:Y||ve(n,t),lt(e,t,n);break;default:lt(e,t,n)}}function Dv(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Go(e)}catch(n){L(t,t.return,n)}}}function Rv(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Go(e)}catch(n){L(t,t.return,n)}}function gh(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Id),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Id),t;default:throw Error(h(435,e.tag))}}function xl(e,t){var n=gh(e);t.forEach(function(o){if(!n.has(o)){n.add(o);var a=Oh.bind(null,e,o);o.then(a,a)}})}function we(e,t,n){var o=t.deletions;if(o!==null)for(var a=0;a<o.length;a++){var l=o[a],c=e,i=t,u=i;e:for(;u!==null;){switch(u.tag){case 27:if(xn(u.type)){$=u.stateNode,Ae=!1;break e}break;case 5:$=u.stateNode,Ae=!1;break e;case 3:case 4:$=u.stateNode.containerInfo,Ae=!0;break e}u=u.return}if($===null)throw Error(h(160));Mv(c,i,l),$=null,Ae=!1,c=l.alternate,c!==null&&(c.return=null),l.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)Uv(t,e,n),t=t.sibling}var it=null;function Uv(e,t,n){var o=e.alternate,a=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(a&4&&(o=e.updateQueue,o=o!==null?o.events:null,o!==null))for(var l=0;l<o.length;l++){var c=o[l];c.ref.impl=c.nextImpl}we(t,e,n),ze(e),a&4&&(hn(3,e,e.return),Ja(3,e),hn(5,e,e.return));break;case 1:we(t,e,n),ze(e),a&512&&(Y||o===null||ve(o,o.return)),a&64&&fe&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(l=it,we(t,e,n),ze(e),a&512&&(Y||o===null||ve(o,o.return)),a&4)if(a=o!==null?o.memoizedState:null,n=e.memoizedState,o===null)if(n===null)if(e.stateNode===null)if(fe)e.stateNode=ug(e.type,e.memoizedProps,t.containerInfo,e);else{e:{t=e.type,n=e.memoizedProps,a=l.ownerDocument||l;t:switch(t){case"title":o=a.getElementsByTagName("title")[0],(!o||o[Qa]||o[ge]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=a.createElement(t),a.head.insertBefore(o,a.querySelector("head > title"))),ye(o,t,n),o[ge]=e,se(o),t=o;break e;case"link":if(l=ks("link","href",a).get(t+(n.href||""))){for(c=0;c<l.length;c++)if(o=l[c],o.getAttribute("href")===(n.href==null||n.href===""?null:n.href)&&o.getAttribute("rel")===(n.rel==null?null:n.rel)&&o.getAttribute("title")===(n.title==null?null:n.title)&&o.getAttribute("crossorigin")===(n.crossOrigin==null?null:n.crossOrigin)){l.splice(c,1);break t}}o=a.createElement(t),ye(o,t,n),a.head.appendChild(o);break;case"meta":if(l=ks("meta","content",a).get(t+(n.content||""))){for(c=0;c<l.length;c++)if(o=l[c],o.getAttribute("content")===(n.content==null?null:""+n.content)&&o.getAttribute("name")===(n.name==null?null:n.name)&&o.getAttribute("property")===(n.property==null?null:n.property)&&o.getAttribute("http-equiv")===(n.httpEquiv==null?null:n.httpEquiv)&&o.getAttribute("charset")===(n.charSet==null?null:n.charSet)){l.splice(c,1);break t}}o=a.createElement(t),ye(o,t,n),a.head.appendChild(o);break;default:throw Error(h(468,t))}o[ge]=e,se(o),t=o}e.stateNode=t}else fe||Xu(l,e.type,e.stateNode);else e.stateNode=xs(l,n,e.memoizedProps);else a!==n?(a===null?(t=o.stateNode,t===null||Y||t.parentNode.removeChild(t)):a.count--,n===null?fe||Xu(l,e.type,e.stateNode):xs(l,n,e.memoizedProps)):n===null&&e.stateNode!==null&&zi(e,e.memoizedProps,o.memoizedProps);break;case 27:we(t,e,n),ze(e),a&512&&(Y||o===null||ve(o,o.return)),o!==null&&a&4&&zi(e,e.memoizedProps,o.memoizedProps);break;case 5:if(l=bt,bt=!1,we(t,e,n),bt=l,ze(e),a&512&&(Y||o===null||ve(o,o.return)),e.flags&32){t=e.stateNode;try{_o(t,""),B=!0}catch(g){L(e,e.return,g)}}a&4&&e.stateNode!=null&&(t=e.memoizedProps,zi(e,t,o!==null?o.memoizedProps:t)),a&1024&&(Ni=!0);break;case 6:if(we(t,e,n),ze(e),a&4){if(e.stateNode===null)throw Error(h(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,B=!0}catch(g){L(e,e.return,g)}}break;case 3:if(B=!1,Ll=null,l=it,it=Ba(t.containerInfo),we(t,e,n),it=l,ze(e),a&4&&o!==null&&o.memoizedState.isDehydrated)try{Go(t.containerInfo)}catch(g){L(e,e.return,g)}Ni&&(Ni=!1,Bv(e)),B=!1;break;case 4:a=bt,bt=fe,o=ad(),l=it,it=Ba(e.stateNode.containerInfo),we(t,e,n),ze(e),it=l,B&&fa&&(sc=!0),B=o,bt=a;break;case 12:we(t,e,n),ze(e);break;case 31:we(t,e,n),ze(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,xl(e,t)));break;case 13:we(t,e,n),ze(e),e.child.flags&8192&&e.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(Uc=Le()),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,xl(e,t)));break;case 22:l=e.memoizedState!==null,c=o!==null&&o.memoizedState!==null;var i=fe,u=Y,f=bt;fe=i||l,bt=f||l,Y=u||c,we(t,e,n),Y=u,bt=f,fe=i,ze(e),a&8192&&(t=e.stateNode,t._visibility=l?t._visibility&-2:t._visibility|1,!l||o===null||c||fe||Y||(t=c||Y,n=fe,o=Y,fe=l||fe,Y=t,Jt(e,2),fe=n,Y=o),!l&&bt||Ou(e,l)),a&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,xl(e,n))));break;case 19:we(t,e,n),ze(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,xl(e,t)));break;case 30:a&512&&(Y||o===null||ve(o,o.return)),a=ad(),l=fa,c=(n&335544064)===n,i=e.memoizedProps,fa=c&&jt(i.default,i.update)!=="none",we(t,e,n),ze(e),c&&o!==null&&B&&(e.flags|=4),fa=l,B=a;break;case 21:break;case 7:a&512&&(Y||o===null||ve(o,o.return)),o&&o.stateNode!==null&&(o.stateNode._fragmentFiber=e);default:we(t,e,n),ze(e)}}function ze(e){var t=e.flags;if(t&2){try{for(var n,o=e.return;o!==null;){if(Tv(o)){n=o;break}o=o.return}o=null;for(var a=e.return;a!==null;){if(Cr(a)){var l=a.stateNode;o===null?o=[l]:o.push(l)}if(_r(a))break;a=a.return}var c=o;if(n==null)throw Error(h(160));switch(n.tag){case 27:var i=n.stateNode,u=Oi(e);fc(e,u,i,c);break;case 5:var f=n.stateNode;n.flags&32&&(_o(f,""),n.flags&=-33);var g=Oi(e);fc(e,g,f,c);break;case 3:case 4:var m=n.stateNode.containerInfo,d=Oi(e);xu(e,d,m,c);break;default:throw Error(h(161))}}catch(v){L(e,e.return,v)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Bv(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Bv(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,Yo=!0,t.reset(),Yo=!1),e=e.sibling}}function to(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)Hv(t,e),t=t.sibling;else Nv(t,!1)}function Hv(e,t){var n=e.alternate;if(n===null)ku(e,!1);else switch(e.tag){case 3:if(zu=vt=!1,$d(),to(t,e),!vt&&!sc){if(e=pt,e!==null)for(var o=0;o<e.length;o+=3){n=e[o];var a=e[o+1];fg(n,e[o+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+a+")"})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===""&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),zu=!0}pt=null;break;case 5:to(t,e);break;case 4:o=vt,vt=!1,to(t,e),vt&&(sc=!0),vt=o;break;case 22:e.memoizedState===null&&(n.memoizedState!==null?ku(e,!1):to(t,e));break;case 30:o=vt,a=$d(),vt=!1,to(t,e),vt&&(e.flags|=4);var l=e.memoizedProps,c=e.stateNode;t=Ut(l,c),c=Ut(n.memoizedProps,c);var i=jt(l.default,l.update);i==="none"?t=!1:(l=n.memoizedState,n.memoizedState=null,n=e.child,Ce=0,t=Mr(e,n,t,c,i,l,!0),Ce!==(l===null?0:l.length)&&(e.flags|=32)),(e.flags&4)!==0&&t?(Do(e,e.memoizedProps.onUpdate),pt=a):a!==null&&(a.push.apply(a,pt),pt=a),vt=(e.flags&32)!==0?!0:o;break;default:to(t,e)}}function gt(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)Av(e,t.alternate,t),t=t.sibling}function Jt(e,t){for(e=e.child;e!==null;){var n=e,o=t;switch(n.tag){case 0:case 11:case 14:case 15:hn(4,n,n.return),Jt(n,o);break;case 1:ve(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&kv(n,n.return,a),Jt(n,o);break;case 27:(o&2)!==0&&yg(n.stateNode,n.type,n.memoizedProps);case 5:ve(n,n.return),n.tag!==5&&n.tag!==27||Sa(n),Jt(n,o);break;case 6:Sa(n);break;case 26:ve(n,n.return),a=n.stateNode,n.memoizedState!==null||a===null||Y||a.parentNode.removeChild(a),Jt(n,o);break;case 22:n.memoizedState===null&&Jt(n,o);break;case 30:ve(n,n.return),Jt(n,o);break;case 7:ve(n,n.return);default:Jt(n,o)}e=e.sibling}}function ct(e,t,n){for(n=(t.subtreeFlags&8772)!==0?n:n&-2,t=t.child;t!==null;){var o=t.alternate,a=e,l=t,c=l.flags,i=(n&1)!==0;switch(l.tag){case 0:case 11:case 15:ct(a,l,n),Ja(4,l);break;case 1:if(ct(a,l,n),o=l,a=o.stateNode,typeof a.componentDidMount=="function")try{a.componentDidMount()}catch(g){L(o,o.return,g)}if(o=l,a=o.updateQueue,a!==null){var u=o.stateNode;try{var f=a.shared.hiddenCallbacks;if(f!==null)for(a.shared.hiddenCallbacks=null,a=0;a<f.length;a++)_b(f[a],u)}catch(g){L(o,o.return,g)}}i&&c&64&&xv(l),mt(l,l.return);break;case 27:(n&2)!==0&&Ev(l);case 5:l.tag!==5&&l.tag!==27||Fd(l),ct(a,l,n),i&&o===null&&c&4&&Su(l),mt(l,l.return);break;case 6:Fd(l);break;case 26:u=l.stateNode,l.memoizedState!==null||u===null||fe||Xu(Ba(u.ownerDocument),l.type,u),ct(a,l,n),i&&o===null&&c&4&&Su(l),mt(l,l.return);break;case 12:ct(a,l,n);break;case 31:ct(a,l,n),i&&c&4&&Dv(a,l);break;case 13:ct(a,l,n),i&&c&4&&Rv(a,l);break;case 22:l.memoizedState===null&&ct(a,l,n),mt(l,l.return);break;case 30:ct(a,l,n),mt(l,l.return);break;case 7:mt(l,l.return);default:ct(a,l,n)}t=t.sibling}}function Dr(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&Za(n))}function Rr(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Za(e))}function Fe(e,t,n,o){var a=(n&335544064)===n;if(t.subtreeFlags&(a?10262:10256))for(t=t.child;t!==null;)qv(e,t,n,o),t=t.sibling;else a&&Ov(t)}function qv(e,t,n,o){var a=(n&335544064)===n;a&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&ql(t);var l=t.flags;switch(t.tag){case 0:case 11:case 15:Fe(e,t,n,o),l&2048&&Ja(9,t);break;case 1:Fe(e,t,n,o);break;case 3:Fe(e,t,n,o),a&&zu&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,e.style.viewTransitionName==="root"&&(e.style.viewTransitionName=""),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName==="none"&&(e.style.viewTransitionName="")),l&2048&&(l=null,t.alternate!==null&&(l=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==l&&(t.refCount++,l!=null&&Za(l)));break;case 12:if(l&2048){Fe(e,t,n,o),l=t.stateNode;try{var c=t.memoizedProps,i=c.id,u=c.onPostCommit;typeof u=="function"&&u(i,t.alternate===null?"mount":"update",l.passiveEffectDuration,-0)}catch(f){L(t,t.return,f)}}else Fe(e,t,n,o);break;case 31:Fe(e,t,n,o);break;case 13:Fe(e,t,n,o);break;case 23:break;case 22:c=t.stateNode,i=t.alternate,t.memoizedState!==null?(a&&i!==null&&i.memoizedState===null&&ql(i),c._visibility&2?Fe(e,t,n,o):xa(e,t)):(a&&i!==null&&i.memoizedState!==null&&ql(t),c._visibility&2?Fe(e,t,n,o):(c._visibility|=2,oo(e,t,n,o,(t.subtreeFlags&10256)!==0||!1))),l&2048&&Dr(i,t);break;case 24:Fe(e,t,n,o),l&2048&&Rr(t.alternate,t);break;case 30:a&&(l=t.alternate,l!==null&&(Et(l.child,!0),Et(t.child,!0))),Fe(e,t,n,o);break;default:Fe(e,t,n,o)}}function oo(e,t,n,o,a){for(a=a&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var l=e,c=t,i=n,u=o,f=c.flags;switch(c.tag){case 0:case 11:case 15:oo(l,c,i,u,a),Ja(8,c);break;case 23:break;case 22:var g=c.stateNode;c.memoizedState!==null?g._visibility&2?oo(l,c,i,u,a):xa(l,c):(g._visibility|=2,oo(l,c,i,u,a)),a&&f&2048&&Dr(c.alternate,c);break;case 24:oo(l,c,i,u,a),a&&f&2048&&Rr(c.alternate,c);break;default:oo(l,c,i,u,a)}t=t.sibling}}function xa(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,o=t,a=o.flags;switch(o.tag){case 22:xa(n,o),a&2048&&Dr(o.alternate,o);break;case 24:xa(n,o),a&2048&&Rr(o.alternate,o);break;default:xa(n,o)}t=t.sibling}}var zn=8192;function Tn(e,t,n){if(e.subtreeFlags&zn)for(e=e.child;e!==null;)Yv(e,t,n),e=e.sibling}function Yv(e,t,n){switch(e.tag){case 26:Tn(e,t,n),e.flags&zn&&(e.memoizedState!==null?y0(n,it,e.memoizedState,e.memoizedProps):(e=e.stateNode,(t&335544128)===t&&Es(n,e)));break;case 5:Tn(e,t,n),e.flags&zn&&(e=e.stateNode,(t&335544128)===t&&Es(n,e));break;case 3:case 4:var o=it;it=Ba(e.stateNode.containerInfo),Tn(e,t,n),it=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=zn,zn=16777216,Tn(e,t,n),zn=o):Tn(e,t,n));break;case 30:if((e.flags&zn)!==0&&(o=e.memoizedProps.name,o!=null&&o!=="auto")){var a=e.stateNode;a.paired=null,Ge===null&&(Ge=new Map),Ge.set(o,a)}Tn(e,t,n);break;default:Tn(e,t,n)}}function Gv(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function oa(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];de=o,Lv(o,e)}Gv(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)jv(e),e=e.sibling}function jv(e){switch(e.tag){case 0:case 11:case 15:oa(e),e.flags&2048&&hn(9,e,e.return);break;case 3:oa(e);break;case 12:oa(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,Yl(e)):oa(e);break;default:oa(e)}}function Yl(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];de=o,Lv(o,e)}Gv(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:hn(8,t,t.return),Yl(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,Yl(t));break;default:Yl(t)}e=e.sibling}}function Lv(e,t){for(;de!==null;){var n=de;switch(n.tag){case 0:case 11:case 15:hn(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var o=n.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:Za(n.memoizedState.cache)}if(o=n.child,o!==null)o.return=n,de=o;else e:for(n=e;de!==null;){o=de;var a=o.sibling,l=o.return;if(Cv(o),o===n){de=null;break e}if(a!==null){a.return=l,de=a;break e}de=l}}}var mh={getCacheForType:function(e){var t=me(ae),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return me(ae).controller.signal}},ph=typeof WeakMap=="function"?WeakMap:Map,H=0,Q=null,_=null,D=0,G=0,He=null,tn=!1,Xo=!1,Ur=!1,Yt=0,ee=0,yn=0,Dn=0,bc=0,je=0,Mo=0,ka=null,_e=null,Au=!1,Uc=0,Vv=0,vc=1/0,gc=null,dn=null,I=0,rt=null,jn=null,Tt=0,_u=0,Cu=null,Qv=null,wo=null,zo=null,Oo=null,Ta=0,Gl=null;function Xe(){return(H&2)!==0&&D!==0?D&-D:E.T!==null?Hr():Js()}function Xv(){if(je===0)if((D&536870912)===0||N){var e=ul;ul<<=1,(ul&3932160)===0&&(ul=262144),je=e}else je=536870912;return e=Se.current,e!==null&&(e.flags|=32),je}function Do(e,t){if(t!=null){var n=e.stateNode,o=n.ref;o===null&&(o=n.ref=sg(Ut(e.memoizedProps,n))),zo===null&&(zo=[]),zo.push(t.bind(null,o))}}function De(e,t,n){(e===Q&&(G===2||G===9)||e.cancelPendingCommit!==null)&&(Ro(e,0),nn(e,D,je,!1)),Va(e,n),((H&2)===0||e!==Q)&&(e===Q&&((H&2)===0&&(Dn|=n),ee===4&&nn(e,D,je,!1)),zt(e))}function Zv(e,t,n){if((H&6)!==0)throw Error(h(327));var o=!n&&(t&127)===0&&(t&e.expiredLanes)===0||La(e,t),a=o?Sh(e,t):Ai(e,t,!0),l=o;do{if(a===0){Xo&&!o&&nn(e,t,0,!1);break}else{if(n=e.current.alternate,l&&!hh(n)){a=Ai(e,t,!1),l=!1;continue}if(a===2){if(l=t,e.errorRecoveryDisabledLanes&l)var c=0;else c=e.pendingLanes&-536870913,c=c!==0?c:c&536870912?536870912:0;if(c!==0){t=c;e:{var i=e;a=ka;var u=i.current.memoizedState.isDehydrated;if(u&&(Ro(i,c).flags|=256),c=Ai(i,c,!1),c!==2&&c!==6){if(Ur&&!u){i.errorRecoveryDisabledLanes|=l,Dn|=l,a=4;break e}l=_e,_e=a,l!==null&&(_e===null?_e=l:_e.push.apply(_e,l))}a=c}if(l=!1,a!==2)continue}}if(a===1){Ro(e,0),nn(e,t,0,!0);break}e:{switch(o=e,l=a,l){case 0:case 1:throw Error(h(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:nn(o,t,je,!tn);break e;case 2:_e=null;break;case 3:case 5:break;default:throw Error(h(329))}if((t&62914560)===t&&(a=Uc+300-Le(),10<a)){if(nn(o,t,je,!tn),xc(o,0,!0)!==0)break e;Tt=t,o.timeoutHandle=Yr(Pd.bind(null,o,n,_e,gc,Au,t,je,Dn,Mo,tn,l,"Throttled",-0,0),a);break e}Pd(o,n,_e,gc,Au,t,je,Dn,Mo,tn,l,null,-0,0)}}break}while(!0);zt(e)}function Pd(e,t,n,o,a,l,c,i,u,f,g,m,d,v){e.timeoutHandle=-1;var y=t.subtreeFlags,x=(l&335544064)===l;if(m=null,(x||y&8192||(y&16785408)===16785408)&&(m={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:yt},Ge=null,Yv(t,l,m),x&&(y=m,x=e.containerInfo,x=(x.nodeType===9?x:x.ownerDocument).__reactViewTransition,x!=null&&(y.count++,y.waitingForViewTransition=!0,y=Ha.bind(y),x.finished.then(y,y))),y=(l&62914560)===l?Uc-Le():(l&4194048)===l?Vv-Le():0,y=S0(m,y),y!==null)){Tt=l,e.cancelPendingCommit=y(ts.bind(null,e,t,l,n,o,a,c,i,u,f,g,m,null,d,v)),nn(e,l,c,!f);return}ts(e,t,l,n,o,a,c,i,u,f,g,m)}function hh(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var o=0;o<n.length;o++){var a=n[o],l=a.getSnapshot;a=a.value;try{if(!Ze(l(),a))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function nn(e,t,n,o){t=Vs(e,t),t&=~bc,t&=~Dn,e.suspendedLanes|=t,e.pingedLanes&=~t,o&&(e.warmLanes|=t),o=e.expirationTimes;for(var a=t;0<a;){var l=31-Qe(a),c=1<<l;o[l]=-1,a&=~c}n!==0&&Xs(e,n,t)}function Bc(){return(H&6)===0?(Fa(0,!1),!1):!0}function Br(){if(_!==null){if(G===0)var e=_.return;else e=_,Ct=Zn=null,yr(e),ko=null,_a=0,e=_;for(;e!==null;)Sv(e.alternate,e),e=e.return;_=null}}function Ro(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,Gh(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),Tt=0,Br(),Q=e,_=n=Mt(e.current,null),D=t,G=0,He=null,tn=!1,Xo=La(e,t),Ur=!1,Mo=je=bc=Dn=yn=ee=0,_e=ka=null,Au=!1,Yt=Vs(e,t),zc(),n}function Kv(e,t){O=null,E.H=ic,t===Vo||t===Ac?(t=zd(),G=3):t===dr?(t=zd(),G=4):G=t===Or?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,He=t,_===null&&(ee=1,uc(e,et(t,e.current)))}function Jv(){var e=Se.current;return e===null?!0:(D&4194048)===D?Te===null:(D&62914560)===D||(D&536870912)!==0?e===Te:!1}function Fv(){var e=E.H;return E.H=ic,e===null?ic:e}function Wv(){var e=E.A;return E.A=mh,e}function mc(){ee=4,tn||(D&4194048)!==D&&Se.current!==null||(Xo=!0),(yn&134217727)===0&&(Dn&134217727)===0||Q===null||nn(Q,D,je,!1)}function Ai(e,t,n){var o=H;H|=2;var a=Fv(),l=Wv();(Q!==e||D!==t)&&(gc=null,Ro(e,t)),t=!1;var c=ee;e:do try{if(G!==0&&_!==null){var i=_,u=He;switch(G){case 8:Br(),c=6;break e;case 3:case 2:case 9:case 6:Se.current===null&&(t=!0);var f=G;if(G=0,He=null,po(e,i,u,f),n&&Xo){c=0;break e}break;default:f=G,G=0,He=null,po(e,i,u,f)}}yh(),c=ee;break}catch(g){Kv(e,g)}while(!0);return t&&e.shellSuspendCounter++,Ct=Zn=null,H=o,E.H=a,E.A=l,_===null&&(Q=null,D=0,zc()),c}function yh(){for(;_!==null;)$v(_)}function Sh(e,t){var n=H;H|=2;var o=Fv(),a=Wv();Q!==e||D!==t?(gc=null,vc=Le()+500,Ro(e,t)):Xo=La(e,t);e:do try{if(G!==0&&_!==null){t=_;var l=He;t:switch(G){case 1:G=0,He=null,po(e,t,l,1);break;case 2:case 9:if(wd(l)){G=0,He=null,es(t);break}t=function(){G!==2&&G!==9||Q!==e||(G=7),zt(e)},l.then(t,t);break e;case 3:G=7;break e;case 4:G=5;break e;case 7:wd(l)?(G=0,He=null,es(t)):(G=0,He=null,po(e,t,l,7));break;case 5:var c=null;switch(_.tag){case 26:c=_.memoizedState;case 5:case 27:var i=_;if(c?kg(c):i.stateNode.complete){G=0,He=null;var u=i.sibling;if(u!==null)_=u;else{var f=i.return;f!==null?(_=f,Hc(f)):_=null}break t}}G=0,He=null,po(e,t,l,5);break;case 6:G=0,He=null,po(e,t,l,6);break;case 8:Br(),ee=6;break e;default:throw Error(h(462))}}xh();break}catch(g){Kv(e,g)}while(!0);return Ct=Zn=null,E.H=o,E.A=a,H=n,_!==null?0:(Q=null,D=0,zc(),ee)}function xh(){for(;_!==null&&!qm();)$v(_)}function $v(e){var t=yv(e.alternate,e,Yt);e.memoizedProps=e.pendingProps,t===null?Hc(e):_=t}function es(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Ld(n,t,t.pendingProps,t.type,void 0,D);break;case 11:t=Ld(n,t,t.pendingProps,t.type.render,t.ref,D);break;case 5:yr(t);var o=t;o===be&&(N?(ec(o),o.tag===5&&o.stateNode!=null&&(J=o.stateNode)):(ec(o),N=!0));default:Sv(n,t),t=_=xb(t,Yt),t=yv(n,t,Yt)}e.memoizedProps=e.pendingProps,t===null?Hc(e):_=t}function po(e,t,n,o){Ct=Zn=null,yr(t),ko=null,_a=0;var a=t.return;try{if(uh(e,a,t,n,D)){ee=1,uc(e,et(n,e.current)),_=null;return}}catch(l){if(a!==null)throw _=a,l;ee=1,uc(e,et(n,e.current)),_=null;return}t.flags&32768?(N||o===1?e=!0:Xo||(D&536870912)!==0?e=!1:(tn=e=!0,(o===2||o===9||o===3||o===6)&&(o=Se.current,o!==null&&o.tag===13&&(o.flags|=16384))),Iv(t,e)):Hc(t)}function Hc(e){var t=e;do{if((t.flags&32768)!==0){Iv(t,tn);return}e=t.return;var n=sh(t.alternate,t,Yt);if(n!==null){_=n;return}if(t=t.sibling,t!==null){_=t;return}_=t=e}while(t!==null);ee===0&&(ee=5)}function Iv(e,t){do{var n=bh(e.alternate,e);if(n!==null){n.flags&=32767,_=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){_=e;return}_=e=n}while(e!==null);ee=6,_=null}function ts(e,t,n,o,a,l,c,i,u,f,g,m){e.cancelPendingCommit=null;do qc();while(I!==0);if((H&6)!==0)throw Error(h(327));if(t!==null){if(t===e.current)throw Error(h(177));e===Q&&(_=Q=null,D=0),jn=t,rt=e,Tt=n,Cu=a,Qv=o,kh(e,t,n,c,i,u,m)}}function kh(e,t,n,o,a,l,c){var i=t.lanes|t.childLanes;if(_u=i,i|=lr,Jm(e,n,i,o,a,l),zo=null,(n&335544064)===n?(Oo=Wp(e),o=10262):(Oo=null,o=10256),(t.subtreeFlags&o)!==0||(t.flags&o)!==0?(e.callbackNode=null,e.callbackPriority=0,Nh(Fl,function(){return Uu(),null})):(e.callbackNode=null,e.callbackPriority=0),dc=!1,o=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||o){o=E.T,E.T=null,a=q.p,q.p=2,l=H,H|=4;try{vh(e,t,n)}finally{H=l,q.p=a,E.T=o}}I=1,dc?wo=Zh(c,e.containerInfo,Oo,Mu,Du,Eh,Ru,Uu,Th,null,null):(Mu(),Du(),Ru())}function Th(e){if(I!==0){var t=rt.onRecoverableError;t(e,{componentStack:null})}}function Eh(){I===3&&(I=0,Hv(jn,rt),I=4)}function Mu(){if(I===1){I=0;var e=rt,t=jn,n=Tt,o=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||o){o=E.T,E.T=null;var a=q.p;q.p=2;var l=H;H|=4;try{fa=sc=!1,Uv(t,e,n),n=Yu;var c=bb(e.containerInfo),i=n.focusedElem,u=n.selectionRange;if(c!==i&&i&&i.ownerDocument&&sb(i.ownerDocument.documentElement,i)){if(u!==null&&ar(i)){var f=u.start,g=u.end;if(g===void 0&&(g=f),"selectionStart"in i)i.selectionStart=f,i.selectionEnd=Math.min(g,i.value.length);else{var m=i.ownerDocument||document,d=m&&m.defaultView||window;if(d.getSelection){var v=d.getSelection(),y=i.textContent.length,x=Math.min(u.start,y),z=u.end===void 0?x:Math.min(u.end,y);!v.extend&&x>z&&(c=z,z=x,x=c);var s=pd(i,x),r=pd(i,z);if(s&&r&&(v.rangeCount!==1||v.anchorNode!==s.node||v.anchorOffset!==s.offset||v.focusNode!==r.node||v.focusOffset!==r.offset)){var b=m.createRange();b.setStart(s.node,s.offset),v.removeAllRanges(),x>z?(v.addRange(b),v.extend(r.node,r.offset)):(b.setEnd(r.node,r.offset),v.addRange(b))}}}}for(m=[],v=i;v=v.parentNode;)v.nodeType===1&&m.push({element:v,left:v.scrollLeft,top:v.scrollTop});for(typeof i.focus=="function"&&i.focus(),i=0;i<m.length;i++){var p=m[i];p.element.scrollLeft=p.left,p.element.scrollTop=p.top}}Yo=!!qu,Yu=qu=null}finally{H=l,q.p=a,E.T=o}}e.current=t,I=2}}function Du(){if(I===2){I=0;var e=rt,t=jn,n=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||n){n=E.T,E.T=null;var o=q.p;q.p=2;var a=H;H|=4;try{Av(e,t.alternate,t)}finally{H=a,q.p=o,E.T=n}}I=3}}function Ru(){if(I===4||I===3){I=0;var e=wo;wo=null,Ym();var t=rt,n=jn,o=Tt,a=Qv,l=(o&335544064)===o?10262:10256;if((n.subtreeFlags&l)!==0||(n.flags&l)!==0?I=5:(I=0,jn=rt=null,Pv(t,t.pendingLanes)),l=t.pendingLanes,l===0&&(dn=null),Iu(o),n=n.stateNode,Ve&&typeof Ve.onCommitFiberRoot=="function")try{Ve.onCommitFiberRoot(ja,n,void 0,(n.current.flags&128)===128)}catch{}if(a!==null){n=E.T,l=q.p,q.p=2,E.T=null;try{for(var c=t.onRecoverableError,i=0;i<a.length;i++){var u=a[i];c(u.value,{componentStack:u.stack})}}finally{E.T=n,q.p=l}}if(a=zo,c=Oo,Oo=null,a!==null&&(zo=null,c===null&&(c=[]),e!==null))for(u=0;u<a.length;u++)n=(0,a[u])(c),n!==void 0&&e.finished.finally(n);(Tt&3)!==0&&qc(),zt(t),l=t.pendingLanes,(o&261930)!==0&&(l&42)!==0?t===Gl?Ta++:(Ta=0,Gl=t):(Ta=0,Gl=null),Fa(0,!1)}}function Pv(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Za(t)))}function qc(){return wo!==null&&(wo.skipTransition(),wo=null),Mu(),Du(),Ru(),Uu()}function Uu(){if(I!==5)return!1;var e=rt,t=_u;_u=0;var n=Iu(Tt),o=E.T,a=q.p;try{q.p=32>n?32:n,E.T=null,n=Cu,Cu=null;var l=rt,c=Tt;if(I=0,jn=rt=null,Tt=0,(H&6)!==0)throw Error(h(331));var i=H;if(H|=4,jv(l.current),qv(l,l.current,c,n),H=i,Fa(0,!1),Ve&&typeof Ve.onPostCommitFiberRoot=="function")try{Ve.onPostCommitFiberRoot(ja,l)}catch{}return!0}finally{q.p=a,E.T=o,Pv(e,t)}}function ns(e,t,n){t=et(n,t),t=vu(e.stateNode,t,2),e=un(e,t,2),e!==null&&(Va(e,2),zt(e))}function L(e,t,n){if(e.tag===3)ns(e,e,n);else for(;t!==null;){if(t.tag===3){ns(t,e,n);break}else if(t.tag===1){var o=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(dn===null||!dn.has(o))){e=et(n,e),n=vv(2),o=un(t,n,2),o!==null&&(gv(n,o,t,e),Va(o,2),zt(o));break}}t=t.return}}function _i(e,t,n){var o=e.pingCache;if(o===null){o=e.pingCache=new ph;var a=new Set;o.set(t,a)}else a=o.get(t),a===void 0&&(a=new Set,o.set(t,a));a.has(n)||(Ur=!0,a.add(n),e=wh.bind(null,e,t,n),t.then(e,e))}function wh(e,t,n){var o=e.pingCache;o!==null&&o.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,Q===e&&(D&n)===n&&((ee===4||ee===3&&(D&62914560)===D&&300>Le()-Uc)&&(H&2)===0?Ro(e,0):bc|=n,Mo===D&&(Mo=0)),zt(e)}function eg(e,t){t===0&&(t=Qs()),e=Xn(e,t),e!==null&&(Va(e,t),zt(e))}function zh(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),eg(e,n)}function Oh(e,t){var n=0;switch(e.tag){case 31:case 13:var o=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(h(314))}o!==null&&o.delete(t),eg(e,n)}function Nh(e,t){return Wu(e,t)}var Uo=null,ao=null,Bu=!1,pc=!1,Ci=!1,on=0;function zt(e){e!==ao&&e.next===null&&(ao===null?Uo=ao=e:ao=ao.next=e),pc=!0,Bu||(Bu=!0,_h())}function Fa(e,t){if(!Ci&&pc){Ci=!0;do for(var n=!1,o=Uo;o!==null;){if(!t)if(e!==0){var a=o.pendingLanes;if(a===0)var l=0;else{var c=o.suspendedLanes,i=o.pingedLanes;l=(1<<31-Qe(42|e)+1)-1,l&=a&~(c&~i),l=l&201326741?l&201326741|1:l?l|2:0}l!==0&&(n=!0,os(o,l))}else l=D,l=xc(o,o===Q?l:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(l&3)===0||La(o,l)||(n=!0,os(o,l));o=o.next}while(n);Ci=!1}}function Ah(){tg()}function tg(){pc=Bu=!1;var e=0;on!==0&&Yh()&&(e=on);for(var t=Le(),n=null,o=Uo;o!==null;){var a=o.next,l=ng(o,t);l===0?(o.next=null,n===null?Uo=a:n.next=a,a===null&&(ao=n)):(n=o,(e!==0||(l&3)!==0)&&(pc=!0)),o=a}I!==0&&I!==5||Fa(e,!1),on!==0&&(on=0)}function ng(e,t){for(var n=e.suspendedLanes,o=e.pingedLanes,a=e.expirationTimes,l=e.pendingLanes&-62914561;0<l;){var c=31-Qe(l),i=1<<c,u=a[c];u===-1?((i&n)===0||(i&o)!==0)&&(a[c]=Km(i,t)):u<=t&&(e.expiredLanes|=i),l&=~i}if(t=Q,n=D,n=xc(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,n===0||e===t&&(G===2||G===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&ri(o),e.callbackNode=null,e.callbackPriority=0;if((n&3)===0||La(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(o!==null&&ri(o),Iu(n)){case 2:case 8:n=js;break;case 32:n=Fl;break;case 268435456:n=Ls;break;default:n=Fl}return o=og.bind(null,e),n=Wu(n,o),e.callbackPriority=t,e.callbackNode=n,t}return o!==null&&o!==null&&ri(o),e.callbackPriority=2,e.callbackNode=null,2}function og(e,t){if(I!==0&&I!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(qc()&&e.callbackNode!==n)return null;var o=D;return o=xc(e,e===Q?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(Zv(e,o,t),ng(e,Le()),e.callbackNode!=null&&e.callbackNode===n?og.bind(null,e):null)}function os(e,t){if(qc())return null;Zv(e,t,!0)}function _h(){jh(function(){(H&6)!==0?Wu(Gs,Ah):tg()})}function Hr(){if(on===0){var e=Hn;e===0&&(e=il,il<<=1,(il&261888)===0&&(il=256)),on=e}return on}function as(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:Nl(e)}function Ch(e,t,n,o,a){if(t==="submit"&&n&&n.stateNode===a){var l=as((a[Ue]||null).action),c=o.submitter;c&&(t=(t=c[Ue]||null)?as(t.formAction):c.getAttribute("formAction"),t!==null&&(l=t,c=null));var i=new Tc("action","action",null,o,a);e.push({event:i,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(on!==0){var u=new FormData(a,c);su(n,{pending:!0,data:u,method:a.method,action:l},null,u)}}else typeof l=="function"&&(i.preventDefault(),u=new FormData(a,c),su(n,{pending:!0,data:u,method:a.method,action:l},l,u))},currentTarget:a}]})}}for(kl=0;kl<tu.length;kl++)Tl=tu[kl],ls=Tl.toLowerCase(),cs=Tl[0].toUpperCase()+Tl.slice(1),ft(ls,"on"+cs);var Tl,ls,cs,kl;ft(gb,"onAnimationEnd");ft(mb,"onAnimationIteration");ft(pb,"onAnimationStart");ft("dblclick","onDoubleClick");ft("focusin","onFocus");ft("focusout","onBlur");ft(Lp,"onTransitionRun");ft(Vp,"onTransitionStart");ft(Qp,"onTransitionCancel");ft(hb,"onTransitionEnd");Ao("onMouseEnter",["mouseout","mouseover"]);Ao("onMouseLeave",["mouseout","mouseover"]);Ao("onPointerEnter",["pointerout","pointerover"]);Ao("onPointerLeave",["pointerout","pointerover"]);Vn("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));Vn("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));Vn("onBeforeInput",["compositionend","keypress","textInput","paste"]);Vn("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));Vn("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));Vn("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Da="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Mh=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Da));function ag(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var o=e[n],a=o.event;o=o.listeners;e:{var l=void 0;if(t)for(var c=o.length-1;0<=c;c--){var i=o[c],u=i.instance,f=i.currentTarget;if(i=i.listener,u!==l&&a.isPropagationStopped())break e;l=i,a.currentTarget=f;try{l(a)}catch(g){$l(g)}a.currentTarget=null,l=u}else for(c=0;c<o.length;c++){if(i=o[c],u=i.instance,f=i.currentTarget,i=i.listener,u!==l&&a.isPropagationStopped())break e;l=i,a.currentTarget=f;try{l(a)}catch(g){$l(g)}a.currentTarget=null,l=u}}}}function A(e,t){var n=t[ed];n===void 0&&(n=t[ed]=new Set);var o=e+"__bubble";n.has(o)||(lg(t,e,2,!1),n.add(o))}function Mi(e,t,n){var o=0;t&&(o|=4),lg(n,e,o,t)}var El="_reactListening"+Math.random().toString(36).slice(2);function qr(e){if(!e[El]){e[El]=!0,Ws.forEach(function(n){n!=="selectionchange"&&(Mh.has(n)||Mi(n,!1,e),Mi(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[El]||(t[El]=!0,Mi("selectionchange",!1,t))}}function lg(e,t,n,o){switch(Ag(t)){case 2:var a=E0;break;case 8:a=w0;break;default:a=Xr}n=a.bind(null,t,n,e),a=void 0,!$i||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(a=!0),o?a!==void 0?e.addEventListener(t,n,{capture:!0,passive:a}):e.addEventListener(t,n,!0):a!==void 0?e.addEventListener(t,n,{passive:a}):e.addEventListener(t,n,!1)}function Di(e,t,n,o,a){var l=o;if((t&1)===0&&(t&2)===0&&o!==null)e:for(;;){if(o===null)return;var c=o.tag;if(c===3||c===4){var i=o.stateNode.containerInfo;if(i===a)break;if(c===4)for(c=o.return;c!==null;){var u=c.tag;if((u===3||u===4)&&c.stateNode.containerInfo===a)return;c=c.return}for(;i!==null;){if(c=On(i),c===null)return;if(u=c.tag,u===5||u===6||u===26||u===27){o=l=c;continue e}i=i.parentNode}}o=o.return}ab(function(){var f=l,g=er(n),m=[];e:{var d=yb.get(e);if(d!==void 0){var v=Tc,y=e;switch(e){case"keypress":if(_l(n)===0)break e;case"keydown":case"keyup":v=hp;break;case"focusin":y="focus",v=gi;break;case"focusout":y="blur",v=gi;break;case"beforeblur":case"afterblur":v=gi;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":v=ud;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":v=cp;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":v=Tp;break;case gb:case mb:case pb:v=rp;break;case hb:v=wp;break;case"scroll":case"scrollend":v=ap;break;case"wheel":v=Op;break;case"copy":case"cut":case"paste":v=dp;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":v=fd;break;case"submit":v=xp;break;case"toggle":case"beforetoggle":v=Ap}var x=(t&4)!==0,z=!x&&(e==="scroll"||e==="scrollend"),s=x?d!==null?d+"Capture":null:d;x=[];for(var r=f,b;r!==null;){var p=r;if(b=p.stateNode,p=p.tag,p!==5&&p!==26&&p!==27||b===null||s===null||(p=wa(r,s),p!=null&&x.push(Ra(r,p,b))),z)break;r=r.return}0<x.length&&(d=new v(d,y,null,n,g),m.push({event:d,listeners:x}))}}if((t&7)===0){e:{if(v=e==="mouseover"||e==="pointerover",d=e==="mouseout"||e==="pointerout",v&&n!==Wi&&(y=n.relatedTarget||n.fromElement)&&(On(y)||y[jo]))break e;(d||v)&&(y=g.window===g?g:(v=g.ownerDocument)?v.defaultView||v.parentWindow:window,d?(v=n.relatedTarget||n.toElement,d=f,v=v?On(v):null,v!==null&&(z=Ga(v),x=v.tag,v!==z||x!==5&&x!==27&&x!==6)&&(v=null)):(d=null,v=f),d!==v&&(x=ud,p="onMouseLeave",s="onMouseEnter",r="mouse",(e==="pointerout"||e==="pointerover")&&(x=fd,p="onPointerLeave",s="onPointerEnter",r="pointer"),z=d==null?y:ua(d),b=v==null?y:ua(v),y=new x(p,r+"leave",d,n,g),y.target=z,y.relatedTarget=b,p=null,On(g)===f&&(x=new x(s,r+"enter",v,n,g),x.target=b,x.relatedTarget=z,p=x),z=p,x=d&&v?qi(d,v,Dh):null,d!==null&&is(m,y,d,x,!1),v!==null&&z!==null&&is(m,z,v,x,!0)))}e:{if(d=f?ua(f):window,v=d.nodeName&&d.nodeName.toLowerCase(),v==="select"||v==="input"&&d.type==="file")var S=vd;else if(bd(d))if(fb)S=Yp;else{S=Hp;var M=Bp}else v=d.nodeName,!v||v.toLowerCase()!=="input"||d.type!=="checkbox"&&d.type!=="radio"?f&&Pu(f.elementType)&&(S=vd):S=qp;if(S&&(S=S(e,f))){rb(m,S,n,g);break e}M&&M(e,d,f)}switch(M=f?ua(f):window,e){case"focusin":(bd(M)||M.contentEditable==="true")&&(fo=M,Pi=f,ba=null);break;case"focusout":ba=Pi=fo=null;break;case"mousedown":eu=!0;break;case"contextmenu":case"mouseup":case"dragend":eu=!1,hd(m,n,g);break;case"selectionchange":if(jp)break;case"keydown":case"keyup":hd(m,n,g)}var k;if(or)e:{switch(e){case"compositionstart":var T="onCompositionStart";break e;case"compositionend":T="onCompositionEnd";break e;case"compositionupdate":T="onCompositionUpdate";break e}T=void 0}else ro?ib(e,n)&&(T="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(T="onCompositionStart");T&&(cb&&n.locale!=="ko"&&(ro||T!=="onCompositionStart"?T==="onCompositionEnd"&&ro&&(k=lb()):(Pt=g,tr="value"in Pt?Pt.value:Pt.textContent,ro=!0)),M=hc(f,T),0<M.length&&(T=new rd(T,e,null,n,g),m.push({event:T,listeners:M}),k?T.data=k:(k=ub(n),k!==null&&(T.data=k)))),(k=Cp?Mp(e,n):Dp(e,n))&&(T=hc(f,"onBeforeInput"),0<T.length&&(M=new rd("onBeforeInput","beforeinput",null,n,g),m.push({event:M,listeners:T}),M.data=k)),Ch(m,e,f,n,g)}ag(m,t)})}function Ra(e,t,n){return{instance:e,listener:t,currentTarget:n}}function hc(e,t){for(var n=t+"Capture",o=[];e!==null;){var a=e,l=a.stateNode;if(a=a.tag,a!==5&&a!==26&&a!==27||l===null||(a=wa(e,n),a!=null&&o.unshift(Ra(e,a,l)),a=wa(e,t),a!=null&&o.push(Ra(e,a,l))),e.tag===3)return o;e=e.return}return[]}function Dh(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function is(e,t,n,o,a){for(var l=t._reactName,c=[];n!==null&&n!==o;){var i=n,u=i.alternate,f=i.stateNode;if(i=i.tag,u!==null&&u===o)break;i!==5&&i!==26&&i!==27||f===null||(u=f,a?(f=wa(n,l),f!=null&&c.unshift(Ra(n,f,u))):a||(f=wa(n,l),f!=null&&c.push(Ra(n,f,u)))),n=n.return}c.length!==0&&e.push({event:t,listeners:c})}var Rh=/\r\n?/g,Uh=/\u0000|\uFFFD/g;function us(e){return(typeof e=="string"?e:""+e).replace(Rh,`
`).replace(Uh,"")}function cg(e,t){return t=us(t),us(e)===t}function j(e,t,n,o,a,l){switch(n){case"children":if(typeof o=="string")t==="body"||t==="textarea"&&o===""||_o(e,o);else if(typeof o=="number"||typeof o=="bigint")t!=="body"&&_o(e,""+o);else return;break;case"className":fl(e,"class",o);break;case"tabIndex":fl(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":fl(e,n,o);break;case"style":ob(e,o,l);return;case"data":if(t!=="object"){fl(e,"data",o);break}case"src":case"href":if(o===""&&(t!=="a"||n!=="href")){e.removeAttribute(n);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=Nl(o),e.setAttribute(n,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof l=="function"&&(n==="formAction"?(t!=="input"&&j(e,t,"name",a.name,a,null),j(e,t,"formEncType",a.formEncType,a,null),j(e,t,"formMethod",a.formMethod,a,null),j(e,t,"formTarget",a.formTarget,a,null)):(j(e,t,"encType",a.encType,a,null),j(e,t,"method",a.method,a,null),j(e,t,"target",a.target,a,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=Nl(o),e.setAttribute(n,o);break;case"onClick":o!=null&&(e.onclick=yt);return;case"onScroll":o!=null&&A("scroll",e);return;case"onScrollEnd":o!=null&&A("scrollend",e);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(h(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(h(60));l?.__html!==n&&(e.innerHTML=n)}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}n=Nl(o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":o===!0?e.setAttribute(n,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(n,o):e.removeAttribute(n);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(n):e.setAttribute(n,o);break;case"popover":A("beforetoggle",e),A("toggle",e),Ol(e,"popover",o);break;case"xlinkActuate":Nt(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Nt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Nt(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Nt(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Nt(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Nt(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Nt(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Nt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Nt(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":Ol(e,"is",o);break;case"innerText":case"textContent":return;default:if(!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")n=np.get(n)||n,Ol(e,n,o);else return}B=!0}function Hu(e,t,n,o,a,l){switch(n){case"style":ob(e,o,l);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(h(61));if(n=o.__html,n!=null){if(a.children!=null)throw Error(h(60));l?.__html!==n&&(e.innerHTML=n)}}break;case"children":if(typeof o=="string")_o(e,o);else if(typeof o=="number"||typeof o=="bigint")_o(e,""+o);else return;break;case"onScroll":o!=null&&A("scroll",e);return;case"onScrollEnd":o!=null&&A("scrollend",e);return;case"onClick":o!=null&&(e.onclick=yt);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!$s.hasOwnProperty(n))e:{if(n[0]==="o"&&n[1]==="n"&&(a=n.endsWith("Capture"),l=n.slice(2,a?n.length-7:void 0),t=e[Ue]||null,t=t!=null?t[n]:null,typeof t=="function"&&e.removeEventListener(l,t,a),typeof o=="function")){typeof t!="function"&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(l,o,a);break e}B=!0,n in e?e[n]=o:o===!0?e.setAttribute(n,""):Ol(e,n,o)}return}B=!0}function ye(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":A("error",e),A("load",e);var o=!1,a=!1,l;for(l in n)if(n.hasOwnProperty(l)){var c=n[l];if(c!=null)switch(l){case"src":o=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(h(137,t));default:j(e,t,l,c,n,null)}}a&&j(e,t,"srcSet",n.srcSet,n,null),o&&j(e,t,"src",n.src,n,null);return;case"input":A("invalid",e);var i=l=c=a=null,u=null,f=null;for(o in n)if(n.hasOwnProperty(o)){var g=n[o];if(g!=null)switch(o){case"name":a=g;break;case"type":c=g;break;case"checked":u=g;break;case"defaultChecked":f=g;break;case"value":l=g;break;case"defaultValue":i=g;break;case"children":case"dangerouslySetInnerHTML":if(g!=null)throw Error(h(137,t));break;default:j(e,t,o,g,n,null)}}eb(e,l,i,u,f,c,a,!1);return;case"select":A("invalid",e),o=c=l=null;for(a in n)if(n.hasOwnProperty(a)&&(i=n[a],i!=null))switch(a){case"value":l=i;break;case"defaultValue":c=i;break;case"multiple":o=i;default:j(e,t,a,i,n,null)}t=l,n=c,e.multiple=!!o,t!=null?yo(e,!!o,t,!1):n!=null&&yo(e,!!o,n,!0);return;case"textarea":A("invalid",e),l=a=o=null;for(c in n)if(n.hasOwnProperty(c)&&(i=n[c],i!=null))switch(c){case"value":o=i;break;case"defaultValue":a=i;break;case"children":l=i;break;case"dangerouslySetInnerHTML":if(i!=null)throw Error(h(91));break;default:j(e,t,c,i,n,null)}nb(e,o,a,l);return;case"option":for(u in n)n.hasOwnProperty(u)&&(o=n[u],o!=null)&&(u==="selected"?e.selected=o&&typeof o!="function"&&typeof o!="symbol":j(e,t,u,o,n,null));return;case"dialog":A("beforetoggle",e),A("toggle",e),A("cancel",e),A("close",e);break;case"iframe":case"object":A("load",e);break;case"video":case"audio":for(o=0;o<Da.length;o++)A(Da[o],e);break;case"image":A("error",e),A("load",e);break;case"details":A("toggle",e);break;case"embed":case"source":case"link":A("error",e),A("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(f in n)if(n.hasOwnProperty(f)&&(o=n[f],o!=null))switch(f){case"children":case"dangerouslySetInnerHTML":throw Error(h(137,t));default:j(e,t,f,o,n,null)}return;default:if(Pu(t)){for(g in n)n.hasOwnProperty(g)&&(o=n[g],o!==void 0&&Hu(e,t,g,o,n,void 0));return}}for(i in n)n.hasOwnProperty(i)&&(o=n[i],o!=null&&j(e,t,i,o,n,null))}var Bh={};function Hh(e,t,n,o){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var a=null,l=null,c=null,i=null,u=null,f=null,g=null;for(v in n){var m=n[v];if(n.hasOwnProperty(v)&&m!=null)switch(v){case"checked":break;case"value":break;case"defaultValue":u=m;default:o.hasOwnProperty(v)||j(e,t,v,null,o,m)}}for(var d in o){var v=o[d];if(m=n[d],o.hasOwnProperty(d)&&(v!=null||m!=null))switch(d){case"type":v!==m&&(B=!0),l=v;break;case"name":v!==m&&(B=!0),a=v;break;case"checked":v!==m&&(B=!0),f=v;break;case"defaultChecked":v!==m&&(B=!0),g=v;break;case"value":v!==m&&(B=!0),c=v;break;case"defaultValue":v!==m&&(B=!0),i=v;break;case"children":case"dangerouslySetInnerHTML":if(v!=null)throw Error(h(137,t));break;default:v!==m&&j(e,t,d,v,o,m)}}Fi(e,c,i,u,f,g,l,a);return;case"select":v=c=i=d=null;for(l in n)if(u=n[l],n.hasOwnProperty(l)&&u!=null)switch(l){case"value":break;case"multiple":v=u;default:o.hasOwnProperty(l)||j(e,t,l,null,o,u)}for(a in o)if(l=o[a],u=n[a],o.hasOwnProperty(a)&&(l!=null||u!=null))switch(a){case"value":l!==u&&(B=!0),d=l;break;case"defaultValue":l!==u&&(B=!0),i=l;break;case"multiple":l!==u&&(B=!0),c=l;default:l!==u&&j(e,t,a,l,o,u)}t=i,n=c,o=v,d!=null?yo(e,!!n,d,!1):!!o!=!!n&&(t!=null?yo(e,!!n,t,!0):yo(e,!!n,n?[]:"",!1));return;case"textarea":v=d=null;for(i in n)if(a=n[i],n.hasOwnProperty(i)&&a!=null&&!o.hasOwnProperty(i))switch(i){case"value":break;case"children":break;default:j(e,t,i,null,o,a)}for(c in o)if(a=o[c],l=n[c],o.hasOwnProperty(c)&&(a!=null||l!=null))switch(c){case"value":a!==l&&(B=!0),d=a;break;case"defaultValue":a!==l&&(B=!0),v=a;break;case"children":break;case"dangerouslySetInnerHTML":if(a!=null)throw Error(h(91));break;default:a!==l&&j(e,t,c,a,o,l)}tb(e,d,v);return;case"option":for(var y in n)d=n[y],n.hasOwnProperty(y)&&d!=null&&!o.hasOwnProperty(y)&&(y==="selected"?e.selected=!1:j(e,t,y,null,o,d));for(u in o)d=o[u],v=n[u],o.hasOwnProperty(u)&&d!==v&&(d!=null||v!=null)&&(u==="selected"?(d!==v&&(B=!0),e.selected=d&&typeof d!="function"&&typeof d!="symbol"):j(e,t,u,d,o,v));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var x in n)d=n[x],n.hasOwnProperty(x)&&d!=null&&!o.hasOwnProperty(x)&&j(e,t,x,null,o,d);for(f in o)if(d=o[f],v=n[f],o.hasOwnProperty(f)&&d!==v&&(d!=null||v!=null))switch(f){case"children":case"dangerouslySetInnerHTML":if(d!=null)throw Error(h(137,t));break;default:j(e,t,f,d,o,v)}return;default:if(Pu(t)){for(var z in n)d=n[z],n.hasOwnProperty(z)&&d!==void 0&&!o.hasOwnProperty(z)&&Hu(e,t,z,void 0,o,d);for(g in o)d=o[g],v=n[g],!o.hasOwnProperty(g)||d===v||d===void 0&&v===void 0||Hu(e,t,g,d,o,v);return}}for(var s in n)d=n[s],n.hasOwnProperty(s)&&d!=null&&!o.hasOwnProperty(s)&&j(e,t,s,null,o,d);for(m in o)d=o[m],v=n[m],!o.hasOwnProperty(m)||d===v||d==null&&v==null||j(e,t,m,d,o,v)}function rs(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function qh(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,n=performance.getEntriesByType("resource"),o=0;o<n.length;o++){var a=n[o],l=a.transferSize,c=a.initiatorType,i=a.duration;if(l&&i&&rs(c)){for(c=0,i=a.responseEnd,o+=1;o<n.length;o++){var u=n[o],f=u.startTime;if(f>i)break;var g=u.transferSize,m=u.initiatorType;g&&rs(m)&&(u=u.responseEnd,c+=g*(u<i?1:(i-f)/(u-f)))}if(--o,t+=8*(l+c)/(a.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var qu=null,Yu=null;function Ua(e){return e.nodeType===9?e:e.ownerDocument}function fs(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function ig(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function ug(e,t,n,o){return n=Ua(n).createElement(e),n[ge]=o,n[Ue]=t,ye(n,e,t),se(n),n}function Gu(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Ri=null;function Yh(){var e=window.event;return e&&e.type==="popstate"?e===Ri?!1:(Ri=e,!0):(Ri=null,!1)}var Yr=typeof setTimeout=="function"?setTimeout:void 0,Gh=typeof clearTimeout=="function"?clearTimeout:void 0,ds=typeof Promise=="function"?Promise:void 0,ss=typeof requestAnimationFrame=="function"?requestAnimationFrame:Yr,jh=typeof queueMicrotask=="function"?queueMicrotask:typeof ds<"u"?function(e){return ds.resolve(null).then(e).catch(Lh)}:Yr;function Lh(e){setTimeout(function(){throw e})}function xn(e){return e==="head"}function bs(e,t){var n=t,o=0;do{var a=n.nextSibling;if(e.removeChild(n),a&&a.nodeType===8)if(n=a.data,n==="/$"||n==="/&"){if(o===0){e.removeChild(a),Go(t);return}o--}else if(n==="$"||n==="$?"||n==="$~"||n==="$!"||n==="&")o++;else if(n==="html")Bi(e.ownerDocument.documentElement);else if(n==="head"){n=e.ownerDocument.head,Bi(n);for(var l=n.firstChild;l;){var c=l.nextSibling,i=l.nodeName;l[Qa]||i==="SCRIPT"||i==="STYLE"||i==="LINK"&&l.rel.toLowerCase()==="stylesheet"||n.removeChild(l),l=c}}else n==="body"&&Bi(e.ownerDocument.body);n=a}while(n);Go(t)}function vs(e,t){var n=e;e=0;do{var o=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",n.getAttribute("style")===""&&n.removeAttribute("style")):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),o&&o.nodeType===8)if(n=o.data,n==="/$"){if(e===0)break;e--}else n!=="$"&&n!=="$?"&&n!=="$~"&&n!=="$!"||e++;n=o}while(n)}function rg(e,t,n){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display==="inline"){if(t=e.getClientRects(),t.length===1)var o=1;else for(var a=o=0;a<t.length;a++){var l=t[a];0<l.width&&0<l.height&&o++}o===1&&(e=e.style,e.display=t.length===1?"inline-block":"block",e.marginTop="-"+n.paddingTop,e.marginBottom="-"+n.paddingBottom)}}function fg(e,t){e=e.style,t=t.style;var n=t!=null?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=n==null||typeof n=="boolean"?"":(""+n).trim(),n=t!=null?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=n==null||typeof n=="boolean"?"":(""+n).trim(),e.display==="inline-block"&&(t==null?e.display=e.margin="":(n=t.display,e.display=n==null||typeof n=="boolean"?"":n,n=t.margin,n!=null?e.margin=n:(n=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=n==null||typeof n=="boolean"?"":n,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=t==null||typeof t=="boolean"?"":t)))}function dg(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position==="absolute"||t.position==="fixed",clip:t.clipPath!=="none"||t.overflow!=="visible"||t.filter!=="none"||t.mask!=="none"||t.mask!=="none"||t.borderRadius!=="0px",view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function ju(e){var t=e.getBoundingClientRect(),n=getComputedStyle(e);return dg(t,n,e)}function Vh(e){var t=e.getBoundingClientRect();t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height);var n=getComputedStyle(e);return dg(t,n,e)}function Qh(e){return e.documentElement.clientHeight}function Xh(e){this.addEventListener("load",e),this.addEventListener("error",e)}function Zh(e,t,n,o,a,l,c,i,u){var f=t.nodeType===9?t:t.ownerDocument;try{var g=f.startViewTransition({update:function(){var d=f.defaultView,v=d.navigation&&d.navigation.transition,y=f.fonts.status;o();var x=[];if(y==="loaded"&&(Qh(f),f.fonts.status==="loading"&&x.push(f.fonts.ready)),y=x.length,e!==null)for(var z=e.suspenseyImages,s=0,r=0;r<z.length;r++){var b=z[r];if(!b.complete){var p=b.getBoundingClientRect();if(0<p.bottom&&0<p.right&&p.top<d.innerHeight&&p.left<d.innerWidth){if(s+=Tg(b),s>Vl){x.length=y;break}b=new Promise(Xh.bind(b)),x.push(b)}}}if(0<x.length)return d=Promise.race([Promise.all(x),new Promise(function(S){return setTimeout(S,500)})]).then(a,a),(v?Promise.allSettled([v.finished,d]):d).then(l,l);if(a(),v)return v.finished.then(l,l);l()},types:n});f.__reactViewTransition=g;var m=[];return g.ready.then(function(){for(var d=f.documentElement.getAnimations({subtree:!0}),v=0;v<d.length;v++){var y=d[v],x=y.effect,z=x.pseudoElement;if(z!=null&&z.startsWith("::view-transition")){m.push(y),y=x.getKeyframes();for(var s=z=void 0,r=!0,b=0;b<y.length;b++){var p=y[b],S=p.width;if(z===void 0)z=S;else if(z!==S){r=!1;break}if(S=p.height,s===void 0)s=S;else if(s!==S){r=!1;break}delete p.width,delete p.height,p.transform==="none"&&delete p.transform}r&&z!==void 0&&s!==void 0&&(x.setKeyframes(y),r=getComputedStyle(x.target,x.pseudoElement),r.width!==z||r.height!==s)&&(r=y[0],r.width=z,r.height=s,r=y[y.length-1],r.width=z,r.height=s,x.setKeyframes(y))}}c()},function(d){f.__reactViewTransition===g&&(f.__reactViewTransition=null);try{typeof d=="object"&&d!==null&&d.name==="InvalidStateError"&&(d.message==="View transition was skipped because document visibility state is hidden."||d.message==="Skipping view transition because document visibility state has become hidden."||d.message==="Skipping view transition because viewport size changed."||d.message==="Transition was aborted because of invalid state")&&(d=null),d!==null&&u(d)}finally{o(),a(),c()}}),g.finished.finally(function(){for(var d=0;d<m.length;d++)m[d].cancel();f.__reactViewTransition===g&&(f.__reactViewTransition=null),i()}),g}catch{return o(),a(),c(),null}}function Nn(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}Nn.prototype.animate=function(e,t){return t=typeof t=="number"?{duration:t}:X({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)};Nn.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),o=[],a=0;a<n.length;a++){var l=n[a].effect;l!==null&&l.target===e&&l.pseudoElement===t&&o.push(n[a])}return o};Nn.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function sg(e){return{name:e,group:new Nn("group",e),imagePair:new Nn("image-pair",e),old:new Nn("old",e),new:new Nn("new",e)}}function Ke(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}Ke.prototype.addEventListener=function(e,t,n){var o=null,a=null;if(!(n!=null&&typeof n!="boolean"&&(o=n.signal||null,o!==null&&o.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var l=this._eventListeners;if(bg(l,e,t,n)===-1){var c=this,i=t;n!=null&&typeof n!="boolean"&&n.once===!0&&(i=function(u){c.removeEventListener(e,t,n),typeof t=="function"?t.call(this,u):t.handleEvent(u)}),o!==null&&(a=c.removeEventListener.bind(c,e,t,n),o.addEventListener("abort",a,{once:!0}),a=o.removeEventListener.bind(o,"abort",a)),o=Bo(n),l.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:i,cleanup:a}),Re(this._fragmentFiber.child,!1,Kh,e,i,o)}this._eventListeners=l}};function Kh(e,t,n,o){return ue(e).addEventListener(t,n,o),!1}Ke.prototype.removeEventListener=function(e,t,n){var o=this._eventListeners;if(o!==null&&(t=bg(o,e,t,n),t!==-1)){var a=o[t];n=a.attachedListener;var l=a.cleanup;a=Bo(a.optionsOrUseCapture),Re(this._fragmentFiber.child,!1,Jh,e,n,a),o.splice(t,1),l!==null&&l()}};function Jh(e,t,n,o){return ue(e).removeEventListener(t,n,o),!1}function Bo(e){return e!=null&&typeof e!="boolean"&&(e.once===!0||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function gs(e){return e==null?"c=0":typeof e=="boolean"?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")}function bg(e,t,n,o){if(e.length===0)return-1;o=gs(o);for(var a=0;a<e.length;a++){var l=e[a];if(l.type===t&&l.listener===n&&gs(l.optionsOrUseCapture)===o)return a}return-1}Ke.prototype.dispatchEvent=function(e){var t=Ln(this._fragmentFiber);if(t===null)return!0;t=ue(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var o=t.nodeType===9?t.createComment(""):document.createTextNode("");if(n)for(var a=0;a<n.length;a++){var l=n[a];o.addEventListener(l.type,l.attachedListener,Bo(l.optionsOrUseCapture))}if(t.appendChild(o),e=o.dispatchEvent(e),n)for(a=0;a<n.length;a++)l=n[a],o.removeEventListener(l.type,l.attachedListener,Bo(l.optionsOrUseCapture));return t.removeChild(o),e}return t.dispatchEvent(e)};Ke.prototype.focus=function(e){Re(this._fragmentFiber.child,!0,vg,e,void 0,void 0)};function vg(e,t){return e.tag===6?!1:(e=ue(e),c0(e,t))}Ke.prototype.focusLast=function(e){var t=[];Re(this._fragmentFiber.child,!0,Gr,t,void 0,void 0);for(var n=t.length-1;0<=n&&!vg(t[n],e);n--);};function Gr(e,t){return t.push(e),!1}Ke.prototype.blur=function(){var e=Ln(this._fragmentFiber);e!==null&&(e=ue(e),e=Ua(e).activeElement,e!==null&&Re(this._fragmentFiber.child,!1,Fh,e,void 0,void 0))};function Fh(e,t){return e.tag===6?!1:(e=ue(e),e===t||e.contains(t)?(t.blur(),!0):!1)}Ke.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),Re(this._fragmentFiber.child,!1,Wh,e,void 0,void 0)};function Wh(e,t){return e.tag===6||(e=ue(e),t.observe(e)),!1}Ke.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),Re(this._fragmentFiber.child,!1,$h,e,void 0,void 0);for(var n=t=0;n<ut.length;n++){var o=ut[n];o.fragmentInstance===this&&o.observer===e?e.unobserve(o.instance):ut[t++]=o}ut.length=t}};function $h(e,t){return e.tag===6||(e=ue(e),t.unobserve(e)),!1}var ut=[],Ui=!1;function Ih(e,t,n){ut.push({fragmentInstance:e,observer:t,instance:n}),Ui||(Ui=!0,i0(function(){Ui=!1;var o=ut;ut=[];for(var a=0;a<o.length;a++){var l=o[a];l.observer.unobserve(l.instance)}}))}Ke.prototype.getClientRects=function(){var e=[];return Re(this._fragmentFiber.child,!1,Ph,e,void 0,void 0),e};function Ph(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=ue(e),t.push.apply(t,e.getClientRects());return!1}Ke.prototype.getRootNode=function(e){var t=Ln(this._fragmentFiber);return t===null?this:ue(t).getRootNode(e)};Ke.prototype.compareDocumentPosition=function(e){var t=Ln(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];Re(this._fragmentFiber.child,!1,Gr,n,void 0,void 0);var o=ue(t);if(n.length===0){if(n=o,Jf(this._fragmentFiber)){e:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break e}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var a=o=n.compareDocumentPosition(e);return n===e?a=Node.DOCUMENT_POSITION_CONTAINS:o&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=Bs(t)[1],n===null?a=Node.DOCUMENT_POSITION_PRECEDING:(e=ue(n).compareDocumentPosition(e),a=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),a|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=ue(n[0]),a=ue(n[n.length-1]);var l=Jf(this._fragmentFiber)?t.parentElement:o;if(l==null)return Node.DOCUMENT_POSITION_DISCONNECTED;o=l.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,l=l.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_CONTAINED_BY;var c=t.compareDocumentPosition(e),i=a.compareDocumentPosition(e),u=c&Node.DOCUMENT_POSITION_CONTAINED_BY||i&Node.DOCUMENT_POSITION_CONTAINED_BY;return i=o&&l&&c&Node.DOCUMENT_POSITION_FOLLOWING&&i&Node.DOCUMENT_POSITION_PRECEDING,t=o&&t===e||l&&a===e||u||i?Node.DOCUMENT_POSITION_CONTAINED_BY:!o&&t===e||!l&&a===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:c,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||e0(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function e0(e,t,n,o,a){var l=On(a);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!l)e:{for(;l!==null;){if(l.tag===7&&(l===t||l.alternate===t)){n=!0;break e}l=l.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(l===null)return l=a.ownerDocument,a===l||a===l.documentElement||a===l.body;e:{for(l=t,t=Ln(t);l!==null;){if(!(l.tag!==5&&l.tag!==3&&l.tag!==27||l!==t&&l.alternate!==t)){l=!0;break e}l=l.return}l=!1}return l}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!l)&&!(t=l===n)&&(t=qi(n,l,Ff),t===null?t=!1:(Re(t,!0,_m,l,n),l=lo,lo=null,t=l!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!l)&&!(t=l===o)&&(t=qi(o,l,Ff),t===null?t=!1:(Re(t,!0,Cm,l,o),l=lo,Hi=lo=null,t=l!==null)),t):!1}function ms(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}Ke.prototype.scrollIntoView=function(e){if(typeof e=="object")throw Error(h(566));var t=[];Re(this._fragmentFiber.child,!1,Gr,t,void 0,void 0);var n=e!==!1;if(t.length===0){var o=Bs(this._fragmentFiber);if(o=n?o[1]||o[0]||Ln(this._fragmentFiber):o[0]||o[1],o===null)return;if(o.tag===6){e=ue(o),ms(e,n);return}if(o=ue(o),o.nodeType!==9){if(o.nodeType===11){n="host"in o?o.host:null,n!==null&&n.scrollIntoView(e);return}o.scrollIntoView(e)}}for(o=n?t.length-1:0;o!==(n?-1:t.length);){var a=t[o];a.tag===6?(a=ue(a),ms(a,n)):ue(a).scrollIntoView(e),o+=n?-1:1}};function t0(e,t){return e=ue(e),gg(e,t),!1}function gg(e,t){e.reactFragments==null&&(e.reactFragments=new Set),e.reactFragments.add(t)}function mg(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.addEventListener(a.type,a.attachedListener,Bo(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(l){for(var c=0,i=0;i<ut.length;i++){var u=ut[i];(u.fragmentInstance!==t||u.observer!==l||u.instance!==e)&&(ut[c++]=u)}ut.length=c,l.observe(e)}),gg(e,t))}function n0(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var a=n[o];e.removeEventListener(a.type,a.attachedListener,Bo(a.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(l){typeof l.rootMargin=="string"?Ih(t,l,e):l.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function Lu(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":Lu(n),kc(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(n.rel.toLowerCase()==="stylesheet")continue}e.removeChild(n)}}function o0(e,t,n,o){for(;e.nodeType===1;){var a=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[Qa])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(l=e.getAttribute("rel"),l==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(l!==a.rel||e.getAttribute("href")!==(a.href==null||a.href===""?null:a.href)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin)||e.getAttribute("title")!==(a.title==null?null:a.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(l=e.getAttribute("src"),(l!==(a.src==null?null:a.src)||e.getAttribute("type")!==(a.type==null?null:a.type)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin))&&l&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var l=a.name==null?null:""+a.name;if(a.type==="hidden"&&e.getAttribute("name")===l)return e}else return e;if(e=nt(e.nextSibling),e===null)break}return null}function a0(e,t,n){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=nt(e.nextSibling),e===null))return null;return e}function pg(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=nt(e.nextSibling),e===null))return null;return e}function Vu(e){return e.data==="$?"||e.data==="$~"}function jr(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function l0(e,t){var n=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||n.readyState!=="loading")t();else{var o=function(){t(),n.removeEventListener("DOMContentLoaded",o)};n.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function nt(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var Qu=null;function ps(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"||n==="/&"){if(t===0)return nt(e.nextSibling);t--}else n!=="$"&&n!=="$!"&&n!=="$?"&&n!=="$~"&&n!=="&"||t++}e=e.nextSibling}return null}function hs(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"){if(t===0)return e;t--}else n!=="/$"&&n!=="/&"||t++}e=e.previousSibling}return null}function c0(e,t){function n(){o=!0}if(e.ownerDocument.activeElement===e)return!0;var o=!1;try{e.ownerDocument.addEventListener("focus",n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener("focus",n,!0)}return o}function i0(e){ss(function(){ss(function(t){return e(t)})})}function hg(e,t,n){switch(t=Ua(n),e){case"html":if(e=t.documentElement,!e)throw Error(h(452));return e;case"head":if(e=t.head,!e)throw Error(h(453));return e;case"body":if(e=t.body,!e)throw Error(h(454));return e;default:throw Error(h(451))}}function yg(e,t,n){for(var o in n){var a=n[o];n.hasOwnProperty(o)&&a!=null&&j(e,t,o,null,Bh,a)}n.dangerouslySetInnerHTML!=null&&(e.textContent=""),e.onclick===yt&&(e.onclick=null),kc(e)}function Bi(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);kc(e)}var ot=new Map,ys=new Set;function Ba(e){if(typeof e.getRootNode=="function"){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var Lt=q.d;q.d={f:u0,r:r0,D:f0,C:d0,L:s0,m:b0,X:g0,S:v0,M:m0};function u0(){var e=Lt.f(),t=Bc();return e||t}function r0(e){var t=Lo(e);t!==null&&t.tag===5&&t.type==="form"?ov(t):Lt.r(e)}var Zo=typeof document>"u"?null:document;function Sg(e,t,n){var o=Zo;if(o&&typeof t=="string"&&t){var a=Pe(t);a='link[rel="'+e+'"][href="'+a+'"]',typeof n=="string"&&(a+='[crossorigin="'+n+'"]'),ys.has(a)||(ys.add(a),e={rel:e,crossOrigin:n,href:t},o.querySelector(a)===null&&(t=o.createElement("link"),ye(t,"link",e),se(t),o.head.appendChild(t)))}}function f0(e){Lt.D(e),Sg("dns-prefetch",e,null)}function d0(e,t){Lt.C(e,t),Sg("preconnect",e,t)}function s0(e,t,n){Lt.L(e,t,n);var o=Zo;if(o&&e&&t){var a='link[rel="preload"][as="'+Pe(t)+'"]';t==="image"&&n&&n.imageSrcSet?(a+='[imagesrcset="'+Pe(n.imageSrcSet)+'"]',typeof n.imageSizes=="string"&&(a+='[imagesizes="'+Pe(n.imageSizes)+'"]')):a+='[href="'+Pe(e)+'"]';var l=a;switch(t){case"style":l=Ho(e);break;case"script":l=Ko(e)}if(!(ot.has(l)||(e=X({rel:"preload",href:t==="image"&&n&&n.imageSrcSet?void 0:e,as:t},n),ot.set(l,e),o.querySelector(a)!==null||t==="style"&&o.querySelector(Wa(l))||t==="script"&&o.querySelector($a(l))))){var c=o.createElement("link");ye(c,"link",e),t==="style"&&(c[Wl]=!0,c.onload=c.onerror=function(){Fs(c)}),se(c),o.head.appendChild(c)}}}function b0(e,t){Lt.m(e,t);var n=Zo;if(n&&e){var o=t&&typeof t.as=="string"?t.as:"script",a='link[rel="modulepreload"][as="'+Pe(o)+'"][href="'+Pe(e)+'"]',l=a;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":l=Ko(e)}if(!ot.has(l)&&(e=X({rel:"modulepreload",href:e},t),ot.set(l,e),n.querySelector(a)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector($a(l)))return}o=n.createElement("link"),ye(o,"link",e),se(o),n.head.appendChild(o)}}}function v0(e,t,n){Lt.S(e,t,n);var o=Zo;if(o&&e){var a=ho(o).hoistableStyles,l=Ho(e);t=t||"default";var c=a.get(l);if(!c){var i={loading:0,preload:null};if(c=o.querySelector(Wa(l)))i.loading=5;else{e=X({rel:"stylesheet",href:e,"data-precedence":t},n),(n=ot.get(l))&&Lr(e,n);var u=c=o.createElement("link");se(u),ye(u,"link",e),u._p=new Promise(function(f,g){u.onload=f,u.onerror=g}),u.addEventListener("load",function(){i.loading|=1}),u.addEventListener("error",function(){i.loading|=2}),i.loading|=4,jl(c,t,o)}c={type:"stylesheet",instance:c,count:1,state:i},a.set(l,c)}}}function g0(e,t){Lt.X(e,t);var n=Zo;if(n&&e){var o=ho(n).hoistableScripts,a=Ko(e),l=o.get(a);l||(l=n.querySelector($a(a)),l||(e=X({src:e,async:!0},t),(t=ot.get(a))&&Vr(e,t),l=n.createElement("script"),se(l),ye(l,"link",e),n.head.appendChild(l)),l={type:"script",instance:l,count:1,state:null},o.set(a,l))}}function m0(e,t){Lt.M(e,t);var n=Zo;if(n&&e){var o=ho(n).hoistableScripts,a=Ko(e),l=o.get(a);l||(l=n.querySelector($a(a)),l||(e=X({src:e,async:!0,type:"module"},t),(t=ot.get(a))&&Vr(e,t),l=n.createElement("script"),se(l),ye(l,"link",e),n.head.appendChild(l)),l={type:"script",instance:l,count:1,state:null},o.set(a,l))}}function Ss(e,t,n,o){var a=(a=an.current)?Ba(a):null;if(!a)throw Error(h(446));switch(e){case"meta":case"title":return null;case"style":return typeof n.precedence=="string"&&typeof n.href=="string"?(n=Ho(n.href),t=ho(a).hoistableStyles,o=t.get(n),o||(o={type:"style",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(n.rel==="stylesheet"&&typeof n.href=="string"&&typeof n.precedence=="string"){e=Ho(n.href);var l=ho(a).hoistableStyles,c=l.get(e);if(c||(a=a.ownerDocument||a,c={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},l.set(e,c),(l=a.querySelector(Wa(e)))?l._p||(c.instance=l,c.state.loading=5):(l=ot.get(e),l||(l={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},ot.set(e,l)),p0(a,e,l,c.state))),t&&o===null)throw Error(h(528,""));return c}if(t&&o!==null)throw Error(h(529,""));return null;case"script":return t=n.async,n=n.src,typeof n=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(n=Ko(n),t=ho(a).hoistableScripts,o=t.get(n),o||(o={type:"script",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(h(444,e))}}function Ho(e){return'href="'+Pe(e)+'"'}function Wa(e){return'link[rel="stylesheet"]['+e+"]"}function xg(e){return X({},e,{"data-precedence":e.precedence,precedence:null})}function p0(e,t,n,o){if(t=e.querySelector('link[rel="preload"][as="style"]['+t+"]")){if(t[Wl]!==!0){o.loading=1;return}}else t=e.createElement("link"),t[Wl]=!0,t.onload=t.onerror=Fs.bind(null,t),ye(t,"link",n),se(t),e.head.appendChild(t);o.preload=t,t.addEventListener("load",function(){return o.loading|=1}),t.addEventListener("error",function(){return o.loading|=2})}function Ko(e){return'[src="'+Pe(e)+'"]'}function $a(e){return"script[async]"+e}function xs(e,t,n){if(t.count++,t.instance===null)switch(t.type){case"style":var o=e.querySelector('style[data-href~="'+Pe(n.href)+'"]');if(o)return t.instance=o,se(o),o;var a=X({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),se(o),ye(o,"style",a),jl(o,n.precedence,e),t.instance=o;case"stylesheet":a=Ho(n.href);var l=e.querySelector(Wa(a));if(l)return t.state.loading|=4,t.instance=l,se(l),l;o=xg(n),(a=ot.get(a))&&Lr(o,a),l=(e.ownerDocument||e).createElement("link"),se(l);var c=l;return c._p=new Promise(function(i,u){c.onload=i,c.onerror=u}),ye(l,"link",o),t.state.loading|=4,jl(l,n.precedence,e),t.instance=l;case"script":return l=Ko(n.src),(a=e.querySelector($a(l)))?(t.instance=a,se(a),a):(o=n,(a=ot.get(l))&&(o=X({},n),Vr(o,a)),e=e.ownerDocument||e,a=e.createElement("script"),se(a),ye(a,"link",o),e.head.appendChild(a),t.instance=a);case"void":return null;default:throw Error(h(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(o=t.instance,t.state.loading|=4,jl(o,n.precedence,e));return t.instance}function jl(e,t,n){for(var o=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),a=o.length?o[o.length-1]:null,l=a,c=0;c<o.length;c++){var i=o[c];if(i.dataset.precedence===t)l=i;else if(l!==a)break}l?l.parentNode.insertBefore(e,l.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Lr(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function Vr(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var Ll=null;function ks(e,t,n){if(Ll===null){var o=new Map,a=Ll=new Map;a.set(n,o)}else a=Ll,o=a.get(n),o||(o=new Map,a.set(n,o));if(o.has(e))return o;for(o.set(e,null),n=n.getElementsByTagName(e),a=0;a<n.length;a++){var l=n[a];if(!(l[Qa]||l[ge]||e==="link"&&l.getAttribute("rel")==="stylesheet")&&l.namespaceURI!=="http://www.w3.org/2000/svg"){var c=l.getAttribute(t)||"";c=e+c;var i=o.get(c);i?i.push(l):o.set(c,[l])}}return o}function Xu(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t==="title"?e.querySelector("head > title"):null)}function h0(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function Ts(e,t){return e==="img"&&t.src!=null&&t.src!==""&&t.onLoad==null&&t.loading!=="lazy"}function kg(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function Tg(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function Es(e,t){typeof t.decode=="function"&&(e.imgCount++,t.complete||(e.imgBytes+=Tg(t),e.suspenseyImages.push(t)),e=x0.bind(e),t.decode().then(e,e))}function y0(e,t,n,o){if(n.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var a=Ho(o.href),l=t.querySelector(Wa(a));if(l){t=l._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=Ha.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=l,se(l);return}l=t.ownerDocument||t,o=xg(o),(a=ot.get(a))&&Lr(o,a),l=l.createElement("link"),se(l);var c=l;c._p=new Promise(function(i,u){c.onload=i,c.onerror=u}),ye(l,"link",o),n.instance=l}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(e.count++,n=Ha.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}var Vl=0;function S0(e,t){return e.stylesheets&&e.count===0&&Ql(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var o=setTimeout(function(){if(e.stylesheets&&Ql(e,e.stylesheets),e.unsuspend){var l=e.unsuspend;e.unsuspend=null,l()}},6e4+t);0<e.imgBytes&&Vl===0&&(Vl=62500*qh());var a=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&Ql(e,e.stylesheets),e.unsuspend)){var l=e.unsuspend;e.unsuspend=null,l()}},(e.imgBytes>Vl?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(a)}}:null}function Eg(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)Ql(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function Ha(){this.count--,Eg(this)}function x0(){this.imgCount--,Eg(this)}var yc=null;function Ql(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,yc=new Map,t.forEach(k0,e),yc=null,Ha.call(e))}function k0(e,t){if(!(t.state.loading&4)){var n=yc.get(e);if(n)var o=n.get(null);else{n=new Map,yc.set(e,n);for(var a=e.querySelectorAll("link[data-precedence],style[data-precedence]"),l=0;l<a.length;l++){var c=a[l];(c.nodeName==="LINK"||c.getAttribute("media")!=="not all")&&(n.set(c.dataset.precedence,c),o=c)}o&&n.set(null,o)}a=t.instance,c=a.getAttribute("data-precedence"),l=n.get(c)||o,l===o&&n.set(null,a),n.set(c,a),this.count++,o=Ha.bind(this),a.addEventListener("load",o),a.addEventListener("error",o),l?l.parentNode.insertBefore(a,l.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(a,e.firstChild)),t.state.loading|=4}}var qo={$$typeof:ht,Provider:null,Consumer:null,_currentValue:An,_currentValue2:An,_threadCount:0};function T0(e,t,n,o,a,l,c,i,u){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=fi(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=fi(0),this.hiddenUpdates=fi(null),this.identifierPrefix=o,this.onUncaughtError=a,this.onCaughtError=l,this.onRecoverableError=c,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=u,this.transitionTypes=null,this.incompleteTransitions=new Map}function wg(e,t,n,o,a,l,c,i,u,f,g,m){return e=new T0(e,t,n,c,u,f,g,m,i),t=1,l===!0&&(t|=24),l=Me(3,null,null,t),e.current=l,l.stateNode=e,t=rr(),t.refCount++,e.pooledCache=t,t.refCount++,l.memoizedState={element:o,isDehydrated:n,cache:t},sr(l),e}function zg(e){return e?(e=vo,e):vo}function Og(e,t,n,o,a,l){a=zg(a),o.context===null?o.context=a:o.pendingContext=a,o=cn(t),o.payload={element:n},l=l===void 0?null:l,l!==null&&(o.callback=l),n=un(e,o,t),n!==null&&(De(n,e,t),ga(n,e,t))}function ws(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function Qr(e,t){ws(e,t),(e=e.alternate)&&ws(e,t)}function Ng(e){if(e.tag===13||e.tag===31){var t=Xn(e,67108864);t!==null&&De(t,e,67108864),Qr(e,67108864)}}function zs(e){if(e.tag===13||e.tag===31){var t=Xe();t=$u(t);var n=Xn(e,t);n!==null&&De(n,e,t),Qr(e,t)}}var Yo=!0;function E0(e,t,n,o){var a=E.T;E.T=null;var l=q.p;try{q.p=2,Xr(e,t,n,o)}finally{q.p=l,E.T=a}}function w0(e,t,n,o){var a=E.T;E.T=null;var l=q.p;try{q.p=8,Xr(e,t,n,o)}finally{q.p=l,E.T=a}}function Xr(e,t,n,o){if(Yo){var a=Zu(o);if(a===null)Di(e,t,o,Sc,n),Os(e,o);else if(O0(a,e,t,n,o))o.stopPropagation();else if(Os(e,o),t&4&&-1<z0.indexOf(e)){for(;a!==null;){var l=Lo(a);if(l!==null)switch(l.tag){case 3:if(l=l.stateNode,l.current.memoizedState.isDehydrated){var c=En(l.pendingLanes);if(c!==0){var i=l;for(i.pendingLanes|=2,i.entangledLanes|=2;c;){var u=1<<31-Qe(c);i.entanglements[1]|=u,c&=~u}zt(l),(H&6)===0&&(vc=Le()+500,Fa(0,!1))}}break;case 31:case 13:i=Xn(l,2),i!==null&&De(i,l,2),Bc(),Qr(l,2)}if(l=Zu(o),l===null&&Di(e,t,o,Sc,n),l===a)break;a=l}a!==null&&o.stopPropagation()}else Di(e,t,o,null,n)}}function Zu(e){return e=er(e),Zr(e)}var Sc=null;function Zr(e){if(Sc=null,e=On(e),e!==null){var t=Ga(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=Ds(t),e!==null)return e;e=null}else if(n===31){if(e=Rs(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return Sc=e,null}function Ag(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Gm()){case Gs:return 2;case js:return 8;case Fl:case jm:return 32;case Ls:return 268435456;default:return 32}default:return 32}}var Ku=!1,sn=null,bn=null,vn=null,qa=new Map,Ya=new Map,$t=[],z0="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Os(e,t){switch(e){case"focusin":case"focusout":sn=null;break;case"dragenter":case"dragleave":bn=null;break;case"mouseover":case"mouseout":vn=null;break;case"pointerover":case"pointerout":qa.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Ya.delete(t.pointerId)}}function aa(e,t,n,o,a,l){return e===null||e.nativeEvent!==l?(e={blockedOn:t,domEventName:n,eventSystemFlags:o,nativeEvent:l,targetContainers:[a]},t!==null&&(t=Lo(t),t!==null&&Ng(t)),e):(e.eventSystemFlags|=o,t=e.targetContainers,a!==null&&t.indexOf(a)===-1&&t.push(a),e)}function O0(e,t,n,o,a){switch(t){case"focusin":return sn=aa(sn,e,t,n,o,a),!0;case"dragenter":return bn=aa(bn,e,t,n,o,a),!0;case"mouseover":return vn=aa(vn,e,t,n,o,a),!0;case"pointerover":var l=a.pointerId;return qa.set(l,aa(qa.get(l)||null,e,t,n,o,a)),!0;case"gotpointercapture":return l=a.pointerId,Ya.set(l,aa(Ya.get(l)||null,e,t,n,o,a)),!0}return!1}function _g(e){var t=On(e.target);if(t!==null){var n=Ga(t);if(n!==null){if(t=n.tag,t===13){if(t=Ds(n),t!==null){e.blockedOn=t,Pf(e.priority,function(){zs(n)});return}}else if(t===31){if(t=Rs(n),t!==null){e.blockedOn=t,Pf(e.priority,function(){zs(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Xl(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=Zu(e.nativeEvent);if(n===null){n=e.nativeEvent;var o=new n.constructor(n.type,n);Wi=o,n.target.dispatchEvent(o),Wi=null}else return t=Lo(n),t!==null&&Ng(t),e.blockedOn=n,!1;t.shift()}return!0}function Ns(e,t,n){Xl(e)&&n.delete(t)}function N0(){Ku=!1,sn!==null&&Xl(sn)&&(sn=null),bn!==null&&Xl(bn)&&(bn=null),vn!==null&&Xl(vn)&&(vn=null),qa.forEach(Ns),Ya.forEach(Ns)}function wl(e,t){e.blockedOn===t&&(e.blockedOn=null,Ku||(Ku=!0,re.unstable_scheduleCallback(re.unstable_NormalPriority,N0)))}var zl=null;function As(e){zl!==e&&(zl=e,re.unstable_scheduleCallback(re.unstable_NormalPriority,function(){zl===e&&(zl=null);for(var t=0;t<e.length;t+=3){var n=e[t],o=e[t+1],a=e[t+2];if(typeof o!="function"){if(Zr(o||n)===null)continue;break}var l=Lo(n);l!==null&&(e.splice(t,3),t-=3,su(l,{pending:!0,data:a,method:n.method,action:o},o,a))}}))}function Go(e){function t(u){return wl(u,e)}sn!==null&&wl(sn,e),bn!==null&&wl(bn,e),vn!==null&&wl(vn,e),qa.forEach(t),Ya.forEach(t);for(var n=0;n<$t.length;n++){var o=$t[n];o.blockedOn===e&&(o.blockedOn=null)}for(;0<$t.length&&(n=$t[0],n.blockedOn===null);)_g(n),n.blockedOn===null&&$t.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(o=0;o<n.length;o+=3){var a=n[o],l=n[o+1],c=a[Ue]||null;if(typeof l=="function")c||As(n);else if(c){var i=null;if(l&&l.hasAttribute("formAction")){if(a=l,c=l[Ue]||null)i=c.formAction;else if(Zr(a)!==null)continue}else i=c.action;typeof i=="function"?n[o+1]=i:(n.splice(o,3),o-=3),As(n)}}}function Cg(){function e(l){l.canIntercept&&l.info==="react-transition"&&l.intercept({handler:function(){return new Promise(function(c){return a=c})},focusReset:"manual",scroll:"manual"})}function t(){a!==null&&(a(),a=null),o||setTimeout(n,20)}function n(){if(!o&&!navigation.transition){var l=navigation.currentEntry;l&&l.url!=null&&navigation.navigate(l.url,{state:l.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,a=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),a!==null&&(a(),a=null)}}}function Kr(e){this._internalRoot=e}Yc.prototype.render=Kr.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(h(409));var n=t.current,o=Xe();Og(n,o,e,t,null,null)};Yc.prototype.unmount=Kr.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Og(e.current,2,null,e,null,null),Bc(),t[jo]=null}};function Yc(e){this._internalRoot=e}Yc.prototype.unstable_scheduleHydration=function(e){if(e){var t=Js();e={blockedOn:null,target:e,priority:t};for(var n=0;n<$t.length&&t!==0&&t<$t[n].priority;n++);$t.splice(n,0,e),n===0&&_g(e)}};var _s=Cs.version;if(_s!=="19.3.0")throw Error(h(527,_s,"19.3.0"));q.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(h(188)):(e=Object.keys(e).join(","),Error(h(268,e)));return e=Am(t),e=e!==null?Us(e):null,e=e===null?null:e.stateNode,e};var A0={bundleType:0,version:"19.3.0",rendererPackageName:"react-dom",currentDispatcherRef:E,reconcilerVersion:"19.3.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(la=__REACT_DEVTOOLS_GLOBAL_HOOK__,!la.isDisabled&&la.supportsFiber))try{ja=la.inject(A0),Ve=la}catch{}var la;Gc.createRoot=function(e,t){if(!Ms(e))throw Error(h(299));var n=!1,o="",a=dv,l=sv,c=bv;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(o=t.identifierPrefix),t.onUncaughtError!==void 0&&(a=t.onUncaughtError),t.onCaughtError!==void 0&&(l=t.onCaughtError),t.onRecoverableError!==void 0&&(c=t.onRecoverableError)),t=wg(e,1,!1,null,null,n,o,null,a,l,c,Cg),e[jo]=t.current,qr(e),new Kr(t)};Gc.hydrateRoot=function(e,t,n){if(!Ms(e))throw Error(h(299));var o=!1,a="",l=dv,c=sv,i=bv,u=null;return n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(a=n.identifierPrefix),n.onUncaughtError!==void 0&&(l=n.onUncaughtError),n.onCaughtError!==void 0&&(c=n.onCaughtError),n.onRecoverableError!==void 0&&(i=n.onRecoverableError),n.formState!==void 0&&(u=n.formState)),t=wg(e,1,!0,t,n??null,o,a,u,l,c,i,Cg),t.context=zg(null),n=t.current,o=Xe(),o=$u(o),a=cn(o),a.callback=null,un(n,a,o),n=o,t.current.lanes=n,Va(t,n),zt(t),e[jo]=t.current,qr(e),new Yc(t)};Gc.version="19.3.0"});var Ug=dt((ay,Rg)=>{"use strict";function Dg(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Dg)}catch(e){console.error(e)}}Dg(),Rg.exports=Mg()});var Ir=`/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

@font-face {
	font-family: "codicon";
	font-display: block;
	src: url("./codicon.ttf?9aab6318a6710999273bab9c78a9fd71") format("truetype");
}

.codicon[class*='codicon-'] {
	font: normal normal normal 16px/1 codicon;
	display: inline-block;
	text-decoration: none;
	text-rendering: auto;
	text-align: center;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	user-select: none;
	-webkit-user-select: none;
	-ms-user-select: none;
}

/*---------------------
 *  Modifiers
 *-------------------*/

@keyframes codicon-spin {
	100% {
		transform:rotate(360deg);
	}
}

.codicon-sync.codicon-modifier-spin,
.codicon-loading.codicon-modifier-spin,
.codicon-gear.codicon-modifier-spin {
	/* Use steps to throttle FPS to reduce CPU usage */
	animation: codicon-spin 1.5s steps(30) infinite;
}

.codicon-modifier-disabled {
	opacity: 0.5;
}

.codicon-modifier-hidden {
	opacity: 0;
}

/* custom speed & easing for loading icon */
.codicon-loading {
	animation-duration: 1s !important;
	animation-timing-function: cubic-bezier(0.53, 0.21, 0.29, 0.67) !important;
}

/*---------------------
 *  Icons
 *-------------------*/

.codicon-add:before { content: "\\ea60" }
.codicon-plus:before { content: "\\ea60" }
.codicon-gist-new:before { content: "\\ea60" }
.codicon-repo-create:before { content: "\\ea60" }
.codicon-lightbulb:before { content: "\\ea61" }
.codicon-light-bulb:before { content: "\\ea61" }
.codicon-repo:before { content: "\\ea62" }
.codicon-repo-delete:before { content: "\\ea62" }
.codicon-gist-fork:before { content: "\\ea63" }
.codicon-repo-forked:before { content: "\\ea63" }
.codicon-git-pull-request:before { content: "\\ea64" }
.codicon-git-pull-request-abandoned:before { content: "\\ea64" }
.codicon-record-keys:before { content: "\\ea65" }
.codicon-keyboard:before { content: "\\ea65" }
.codicon-tag:before { content: "\\ea66" }
.codicon-git-pull-request-label:before { content: "\\ea66" }
.codicon-tag-add:before { content: "\\ea66" }
.codicon-tag-remove:before { content: "\\ea66" }
.codicon-person:before { content: "\\ea67" }
.codicon-person-follow:before { content: "\\ea67" }
.codicon-person-outline:before { content: "\\ea67" }
.codicon-person-filled:before { content: "\\ea67" }
.codicon-source-control:before { content: "\\ea68" }
.codicon-mirror:before { content: "\\ea69" }
.codicon-mirror-public:before { content: "\\ea69" }
.codicon-star:before { content: "\\ea6a" }
.codicon-star-add:before { content: "\\ea6a" }
.codicon-star-delete:before { content: "\\ea6a" }
.codicon-star-empty:before { content: "\\ea6a" }
.codicon-comment:before { content: "\\ea6b" }
.codicon-comment-add:before { content: "\\ea6b" }
.codicon-alert:before { content: "\\ea6c" }
.codicon-warning:before { content: "\\ea6c" }
.codicon-search:before { content: "\\ea6d" }
.codicon-search-save:before { content: "\\ea6d" }
.codicon-log-out:before { content: "\\ea6e" }
.codicon-sign-out:before { content: "\\ea6e" }
.codicon-log-in:before { content: "\\ea6f" }
.codicon-sign-in:before { content: "\\ea6f" }
.codicon-eye:before { content: "\\ea70" }
.codicon-eye-unwatch:before { content: "\\ea70" }
.codicon-eye-watch:before { content: "\\ea70" }
.codicon-circle-filled:before { content: "\\ea71" }
.codicon-primitive-dot:before { content: "\\ea71" }
.codicon-close-dirty:before { content: "\\ea71" }
.codicon-debug-breakpoint:before { content: "\\ea71" }
.codicon-debug-breakpoint-disabled:before { content: "\\ea71" }
.codicon-debug-hint:before { content: "\\ea71" }
.codicon-terminal-decoration-success:before { content: "\\ea71" }
.codicon-primitive-square:before { content: "\\ea72" }
.codicon-edit:before { content: "\\ea73" }
.codicon-pencil:before { content: "\\ea73" }
.codicon-info:before { content: "\\ea74" }
.codicon-issue-opened:before { content: "\\ea74" }
.codicon-gist-private:before { content: "\\ea75" }
.codicon-git-fork-private:before { content: "\\ea75" }
.codicon-lock:before { content: "\\ea75" }
.codicon-mirror-private:before { content: "\\ea75" }
.codicon-close:before { content: "\\ea76" }
.codicon-remove-close:before { content: "\\ea76" }
.codicon-x:before { content: "\\ea76" }
.codicon-repo-sync:before { content: "\\ea77" }
.codicon-sync:before { content: "\\ea77" }
.codicon-clone:before { content: "\\ea78" }
.codicon-desktop-download:before { content: "\\ea78" }
.codicon-beaker:before { content: "\\ea79" }
.codicon-microscope:before { content: "\\ea79" }
.codicon-vm:before { content: "\\ea7a" }
.codicon-device-desktop:before { content: "\\ea7a" }
.codicon-file:before { content: "\\ea7b" }
.codicon-more:before { content: "\\ea7c" }
.codicon-ellipsis:before { content: "\\ea7c" }
.codicon-kebab-horizontal:before { content: "\\ea7c" }
.codicon-mail-reply:before { content: "\\ea7d" }
.codicon-reply:before { content: "\\ea7d" }
.codicon-organization:before { content: "\\ea7e" }
.codicon-organization-filled:before { content: "\\ea7e" }
.codicon-organization-outline:before { content: "\\ea7e" }
.codicon-new-file:before { content: "\\ea7f" }
.codicon-file-add:before { content: "\\ea7f" }
.codicon-new-folder:before { content: "\\ea80" }
.codicon-file-directory-create:before { content: "\\ea80" }
.codicon-trash:before { content: "\\ea81" }
.codicon-trashcan:before { content: "\\ea81" }
.codicon-history:before { content: "\\ea82" }
.codicon-clock:before { content: "\\ea82" }
.codicon-folder:before { content: "\\ea83" }
.codicon-file-directory:before { content: "\\ea83" }
.codicon-symbol-folder:before { content: "\\ea83" }
.codicon-logo-github:before { content: "\\ea84" }
.codicon-mark-github:before { content: "\\ea84" }
.codicon-github:before { content: "\\ea84" }
.codicon-terminal:before { content: "\\ea85" }
.codicon-console:before { content: "\\ea85" }
.codicon-repl:before { content: "\\ea85" }
.codicon-zap:before { content: "\\ea86" }
.codicon-symbol-event:before { content: "\\ea86" }
.codicon-error:before { content: "\\ea87" }
.codicon-stop:before { content: "\\ea87" }
.codicon-variable:before { content: "\\ea88" }
.codicon-symbol-variable:before { content: "\\ea88" }
.codicon-array:before { content: "\\ea8a" }
.codicon-symbol-array:before { content: "\\ea8a" }
.codicon-symbol-module:before { content: "\\ea8b" }
.codicon-symbol-package:before { content: "\\ea8b" }
.codicon-symbol-namespace:before { content: "\\ea8b" }
.codicon-symbol-object:before { content: "\\ea8b" }
.codicon-symbol-method:before { content: "\\ea8c" }
.codicon-symbol-function:before { content: "\\ea8c" }
.codicon-symbol-constructor:before { content: "\\ea8c" }
.codicon-symbol-boolean:before { content: "\\ea8f" }
.codicon-symbol-null:before { content: "\\ea8f" }
.codicon-symbol-numeric:before { content: "\\ea90" }
.codicon-symbol-number:before { content: "\\ea90" }
.codicon-symbol-structure:before { content: "\\ea91" }
.codicon-symbol-struct:before { content: "\\ea91" }
.codicon-symbol-parameter:before { content: "\\ea92" }
.codicon-symbol-type-parameter:before { content: "\\ea92" }
.codicon-symbol-key:before { content: "\\ea93" }
.codicon-symbol-text:before { content: "\\ea93" }
.codicon-symbol-reference:before { content: "\\ea94" }
.codicon-go-to-file:before { content: "\\ea94" }
.codicon-symbol-enum:before { content: "\\ea95" }
.codicon-symbol-value:before { content: "\\ea95" }
.codicon-symbol-ruler:before { content: "\\ea96" }
.codicon-symbol-unit:before { content: "\\ea96" }
.codicon-activate-breakpoints:before { content: "\\ea97" }
.codicon-archive:before { content: "\\ea98" }
.codicon-arrow-both:before { content: "\\ea99" }
.codicon-arrow-down:before { content: "\\ea9a" }
.codicon-arrow-left:before { content: "\\ea9b" }
.codicon-arrow-right:before { content: "\\ea9c" }
.codicon-arrow-small-down:before { content: "\\ea9d" }
.codicon-arrow-small-left:before { content: "\\ea9e" }
.codicon-arrow-small-right:before { content: "\\ea9f" }
.codicon-arrow-small-up:before { content: "\\eaa0" }
.codicon-arrow-up:before { content: "\\eaa1" }
.codicon-bell:before { content: "\\eaa2" }
.codicon-bold:before { content: "\\eaa3" }
.codicon-book:before { content: "\\eaa4" }
.codicon-bookmark:before { content: "\\eaa5" }
.codicon-debug-breakpoint-conditional-unverified:before { content: "\\eaa6" }
.codicon-debug-breakpoint-conditional:before { content: "\\eaa7" }
.codicon-debug-breakpoint-conditional-disabled:before { content: "\\eaa7" }
.codicon-debug-breakpoint-data-unverified:before { content: "\\eaa8" }
.codicon-debug-breakpoint-data:before { content: "\\eaa9" }
.codicon-debug-breakpoint-data-disabled:before { content: "\\eaa9" }
.codicon-debug-breakpoint-log-unverified:before { content: "\\eaaa" }
.codicon-debug-breakpoint-log:before { content: "\\eaab" }
.codicon-debug-breakpoint-log-disabled:before { content: "\\eaab" }
.codicon-briefcase:before { content: "\\eaac" }
.codicon-broadcast:before { content: "\\eaad" }
.codicon-browser:before { content: "\\eaae" }
.codicon-bug:before { content: "\\eaaf" }
.codicon-calendar:before { content: "\\eab0" }
.codicon-case-sensitive:before { content: "\\eab1" }
.codicon-check:before { content: "\\eab2" }
.codicon-checklist:before { content: "\\eab3" }
.codicon-chevron-down:before { content: "\\eab4" }
.codicon-chevron-left:before { content: "\\eab5" }
.codicon-chevron-right:before { content: "\\eab6" }
.codicon-chevron-up:before { content: "\\eab7" }
.codicon-chrome-close:before { content: "\\eab8" }
.codicon-chrome-maximize:before { content: "\\eab9" }
.codicon-chrome-minimize:before { content: "\\eaba" }
.codicon-chrome-restore:before { content: "\\eabb" }
.codicon-circle-outline:before { content: "\\eabc" }
.codicon-circle:before { content: "\\eabc" }
.codicon-debug-breakpoint-unverified:before { content: "\\eabc" }
.codicon-terminal-decoration-incomplete:before { content: "\\eabc" }
.codicon-circle-slash:before { content: "\\eabd" }
.codicon-circuit-board:before { content: "\\eabe" }
.codicon-clear-all:before { content: "\\eabf" }
.codicon-clippy:before { content: "\\eac0" }
.codicon-close-all:before { content: "\\eac1" }
.codicon-cloud-download:before { content: "\\eac2" }
.codicon-cloud-upload:before { content: "\\eac3" }
.codicon-code:before { content: "\\eac4" }
.codicon-collapse-all:before { content: "\\eac5" }
.codicon-color-mode:before { content: "\\eac6" }
.codicon-comment-discussion:before { content: "\\eac7" }
.codicon-credit-card:before { content: "\\eac9" }
.codicon-dash:before { content: "\\eacc" }
.codicon-dashboard:before { content: "\\eacd" }
.codicon-database:before { content: "\\eace" }
.codicon-debug-continue:before { content: "\\eacf" }
.codicon-debug-disconnect:before { content: "\\ead0" }
.codicon-debug-pause:before { content: "\\ead1" }
.codicon-debug-restart:before { content: "\\ead2" }
.codicon-debug-start:before { content: "\\ead3" }
.codicon-debug-step-into:before { content: "\\ead4" }
.codicon-debug-step-out:before { content: "\\ead5" }
.codicon-debug-step-over:before { content: "\\ead6" }
.codicon-debug-stop:before { content: "\\ead7" }
.codicon-debug:before { content: "\\ead8" }
.codicon-device-camera-video:before { content: "\\ead9" }
.codicon-device-camera:before { content: "\\eada" }
.codicon-device-mobile:before { content: "\\eadb" }
.codicon-diff-added:before { content: "\\eadc" }
.codicon-diff-ignored:before { content: "\\eadd" }
.codicon-diff-modified:before { content: "\\eade" }
.codicon-diff-removed:before { content: "\\eadf" }
.codicon-diff-renamed:before { content: "\\eae0" }
.codicon-diff:before { content: "\\eae1" }
.codicon-diff-sidebyside:before { content: "\\eae1" }
.codicon-discard:before { content: "\\eae2" }
.codicon-editor-layout:before { content: "\\eae3" }
.codicon-empty-window:before { content: "\\eae4" }
.codicon-exclude:before { content: "\\eae5" }
.codicon-extensions:before { content: "\\eae6" }
.codicon-eye-closed:before { content: "\\eae7" }
.codicon-file-binary:before { content: "\\eae8" }
.codicon-file-code:before { content: "\\eae9" }
.codicon-file-media:before { content: "\\eaea" }
.codicon-file-pdf:before { content: "\\eaeb" }
.codicon-file-submodule:before { content: "\\eaec" }
.codicon-file-symlink-directory:before { content: "\\eaed" }
.codicon-file-symlink-file:before { content: "\\eaee" }
.codicon-file-zip:before { content: "\\eaef" }
.codicon-files:before { content: "\\eaf0" }
.codicon-filter:before { content: "\\eaf1" }
.codicon-flame:before { content: "\\eaf2" }
.codicon-fold-down:before { content: "\\eaf3" }
.codicon-fold-up:before { content: "\\eaf4" }
.codicon-fold:before { content: "\\eaf5" }
.codicon-folder-active:before { content: "\\eaf6" }
.codicon-folder-opened:before { content: "\\eaf7" }
.codicon-gear:before { content: "\\eaf8" }
.codicon-gift:before { content: "\\eaf9" }
.codicon-gist-secret:before { content: "\\eafa" }
.codicon-gist:before { content: "\\eafb" }
.codicon-git-commit:before { content: "\\eafc" }
.codicon-git-compare:before { content: "\\eafd" }
.codicon-compare-changes:before { content: "\\eafd" }
.codicon-git-merge:before { content: "\\eafe" }
.codicon-github-action:before { content: "\\eaff" }
.codicon-github-alt:before { content: "\\eb00" }
.codicon-globe:before { content: "\\eb01" }
.codicon-grabber:before { content: "\\eb02" }
.codicon-graph:before { content: "\\eb03" }
.codicon-gripper:before { content: "\\eb04" }
.codicon-heart:before { content: "\\eb05" }
.codicon-home:before { content: "\\eb06" }
.codicon-horizontal-rule:before { content: "\\eb07" }
.codicon-hubot:before { content: "\\eb08" }
.codicon-inbox:before { content: "\\eb09" }
.codicon-issue-reopened:before { content: "\\eb0b" }
.codicon-issues:before { content: "\\eb0c" }
.codicon-italic:before { content: "\\eb0d" }
.codicon-jersey:before { content: "\\eb0e" }
.codicon-json:before { content: "\\eb0f" }
.codicon-bracket:before { content: "\\eb0f" }
.codicon-kebab-vertical:before { content: "\\eb10" }
.codicon-key:before { content: "\\eb11" }
.codicon-law:before { content: "\\eb12" }
.codicon-lightbulb-autofix:before { content: "\\eb13" }
.codicon-link-external:before { content: "\\eb14" }
.codicon-link:before { content: "\\eb15" }
.codicon-list-ordered:before { content: "\\eb16" }
.codicon-list-unordered:before { content: "\\eb17" }
.codicon-live-share:before { content: "\\eb18" }
.codicon-loading:before { content: "\\eb19" }
.codicon-location:before { content: "\\eb1a" }
.codicon-mail-read:before { content: "\\eb1b" }
.codicon-mail:before { content: "\\eb1c" }
.codicon-markdown:before { content: "\\eb1d" }
.codicon-megaphone:before { content: "\\eb1e" }
.codicon-mention:before { content: "\\eb1f" }
.codicon-milestone:before { content: "\\eb20" }
.codicon-git-pull-request-milestone:before { content: "\\eb20" }
.codicon-mortar-board:before { content: "\\eb21" }
.codicon-move:before { content: "\\eb22" }
.codicon-multiple-windows:before { content: "\\eb23" }
.codicon-mute:before { content: "\\eb24" }
.codicon-no-newline:before { content: "\\eb25" }
.codicon-note:before { content: "\\eb26" }
.codicon-octoface:before { content: "\\eb27" }
.codicon-open-preview:before { content: "\\eb28" }
.codicon-package:before { content: "\\eb29" }
.codicon-paintcan:before { content: "\\eb2a" }
.codicon-pin:before { content: "\\eb2b" }
.codicon-play:before { content: "\\eb2c" }
.codicon-run:before { content: "\\eb2c" }
.codicon-plug:before { content: "\\eb2d" }
.codicon-preserve-case:before { content: "\\eb2e" }
.codicon-preview:before { content: "\\eb2f" }
.codicon-project:before { content: "\\eb30" }
.codicon-pulse:before { content: "\\eb31" }
.codicon-question:before { content: "\\eb32" }
.codicon-quote:before { content: "\\eb33" }
.codicon-radio-tower:before { content: "\\eb34" }
.codicon-reactions:before { content: "\\eb35" }
.codicon-references:before { content: "\\eb36" }
.codicon-refresh:before { content: "\\eb37" }
.codicon-regex:before { content: "\\eb38" }
.codicon-remote-explorer:before { content: "\\eb39" }
.codicon-remote:before { content: "\\eb3a" }
.codicon-remove:before { content: "\\eb3b" }
.codicon-replace-all:before { content: "\\eb3c" }
.codicon-replace:before { content: "\\eb3d" }
.codicon-repo-clone:before { content: "\\eb3e" }
.codicon-repo-force-push:before { content: "\\eb3f" }
.codicon-repo-pull:before { content: "\\eb40" }
.codicon-repo-push:before { content: "\\eb41" }
.codicon-report:before { content: "\\eb42" }
.codicon-request-changes:before { content: "\\eb43" }
.codicon-rocket:before { content: "\\eb44" }
.codicon-root-folder-opened:before { content: "\\eb45" }
.codicon-root-folder:before { content: "\\eb46" }
.codicon-rss:before { content: "\\eb47" }
.codicon-ruby:before { content: "\\eb48" }
.codicon-save-all:before { content: "\\eb49" }
.codicon-save-as:before { content: "\\eb4a" }
.codicon-save:before { content: "\\eb4b" }
.codicon-screen-full:before { content: "\\eb4c" }
.codicon-screen-normal:before { content: "\\eb4d" }
.codicon-search-stop:before { content: "\\eb4e" }
.codicon-server:before { content: "\\eb50" }
.codicon-settings-gear:before { content: "\\eb51" }
.codicon-settings:before { content: "\\eb52" }
.codicon-shield:before { content: "\\eb53" }
.codicon-smiley:before { content: "\\eb54" }
.codicon-sort-precedence:before { content: "\\eb55" }
.codicon-split-horizontal:before { content: "\\eb56" }
.codicon-split-vertical:before { content: "\\eb57" }
.codicon-squirrel:before { content: "\\eb58" }
.codicon-star-full:before { content: "\\eb59" }
.codicon-star-half:before { content: "\\eb5a" }
.codicon-symbol-class:before { content: "\\eb5b" }
.codicon-symbol-color:before { content: "\\eb5c" }
.codicon-symbol-constant:before { content: "\\eb5d" }
.codicon-symbol-enum-member:before { content: "\\eb5e" }
.codicon-symbol-field:before { content: "\\eb5f" }
.codicon-symbol-file:before { content: "\\eb60" }
.codicon-symbol-interface:before { content: "\\eb61" }
.codicon-symbol-keyword:before { content: "\\eb62" }
.codicon-symbol-misc:before { content: "\\eb63" }
.codicon-symbol-operator:before { content: "\\eb64" }
.codicon-symbol-property:before { content: "\\eb65" }
.codicon-wrench:before { content: "\\eb65" }
.codicon-wrench-subaction:before { content: "\\eb65" }
.codicon-symbol-snippet:before { content: "\\eb66" }
.codicon-tasklist:before { content: "\\eb67" }
.codicon-telescope:before { content: "\\eb68" }
.codicon-text-size:before { content: "\\eb69" }
.codicon-three-bars:before { content: "\\eb6a" }
.codicon-thumbsdown:before { content: "\\eb6b" }
.codicon-thumbsup:before { content: "\\eb6c" }
.codicon-tools:before { content: "\\eb6d" }
.codicon-triangle-down:before { content: "\\eb6e" }
.codicon-triangle-left:before { content: "\\eb6f" }
.codicon-triangle-right:before { content: "\\eb70" }
.codicon-triangle-up:before { content: "\\eb71" }
.codicon-twitter:before { content: "\\eb72" }
.codicon-unfold:before { content: "\\eb73" }
.codicon-unlock:before { content: "\\eb74" }
.codicon-unmute:before { content: "\\eb75" }
.codicon-unverified:before { content: "\\eb76" }
.codicon-verified:before { content: "\\eb77" }
.codicon-versions:before { content: "\\eb78" }
.codicon-vm-active:before { content: "\\eb79" }
.codicon-vm-outline:before { content: "\\eb7a" }
.codicon-vm-running:before { content: "\\eb7b" }
.codicon-watch:before { content: "\\eb7c" }
.codicon-whitespace:before { content: "\\eb7d" }
.codicon-whole-word:before { content: "\\eb7e" }
.codicon-window:before { content: "\\eb7f" }
.codicon-word-wrap:before { content: "\\eb80" }
.codicon-zoom-in:before { content: "\\eb81" }
.codicon-zoom-out:before { content: "\\eb82" }
.codicon-list-filter:before { content: "\\eb83" }
.codicon-list-flat:before { content: "\\eb84" }
.codicon-list-selection:before { content: "\\eb85" }
.codicon-selection:before { content: "\\eb85" }
.codicon-list-tree:before { content: "\\eb86" }
.codicon-debug-breakpoint-function-unverified:before { content: "\\eb87" }
.codicon-debug-breakpoint-function:before { content: "\\eb88" }
.codicon-debug-breakpoint-function-disabled:before { content: "\\eb88" }
.codicon-debug-stackframe-active:before { content: "\\eb89" }
.codicon-circle-small-filled:before { content: "\\eb8a" }
.codicon-debug-stackframe-dot:before { content: "\\eb8a" }
.codicon-terminal-decoration-mark:before { content: "\\eb8a" }
.codicon-debug-stackframe:before { content: "\\eb8b" }
.codicon-debug-stackframe-focused:before { content: "\\eb8b" }
.codicon-debug-breakpoint-unsupported:before { content: "\\eb8c" }
.codicon-symbol-string:before { content: "\\eb8d" }
.codicon-debug-reverse-continue:before { content: "\\eb8e" }
.codicon-debug-step-back:before { content: "\\eb8f" }
.codicon-debug-restart-frame:before { content: "\\eb90" }
.codicon-debug-alt:before { content: "\\eb91" }
.codicon-call-incoming:before { content: "\\eb92" }
.codicon-call-outgoing:before { content: "\\eb93" }
.codicon-menu:before { content: "\\eb94" }
.codicon-expand-all:before { content: "\\eb95" }
.codicon-feedback:before { content: "\\eb96" }
.codicon-git-pull-request-reviewer:before { content: "\\eb96" }
.codicon-group-by-ref-type:before { content: "\\eb97" }
.codicon-ungroup-by-ref-type:before { content: "\\eb98" }
.codicon-account:before { content: "\\eb99" }
.codicon-git-pull-request-assignee:before { content: "\\eb99" }
.codicon-bell-dot:before { content: "\\eb9a" }
.codicon-debug-console:before { content: "\\eb9b" }
.codicon-library:before { content: "\\eb9c" }
.codicon-output:before { content: "\\eb9d" }
.codicon-run-all:before { content: "\\eb9e" }
.codicon-sync-ignored:before { content: "\\eb9f" }
.codicon-pinned:before { content: "\\eba0" }
.codicon-github-inverted:before { content: "\\eba1" }
.codicon-server-process:before { content: "\\eba2" }
.codicon-server-environment:before { content: "\\eba3" }
.codicon-pass:before { content: "\\eba4" }
.codicon-issue-closed:before { content: "\\eba4" }
.codicon-stop-circle:before { content: "\\eba5" }
.codicon-play-circle:before { content: "\\eba6" }
.codicon-record:before { content: "\\eba7" }
.codicon-debug-alt-small:before { content: "\\eba8" }
.codicon-vm-connect:before { content: "\\eba9" }
.codicon-cloud:before { content: "\\ebaa" }
.codicon-merge:before { content: "\\ebab" }
.codicon-export:before { content: "\\ebac" }
.codicon-graph-left:before { content: "\\ebad" }
.codicon-magnet:before { content: "\\ebae" }
.codicon-notebook:before { content: "\\ebaf" }
.codicon-redo:before { content: "\\ebb0" }
.codicon-check-all:before { content: "\\ebb1" }
.codicon-pinned-dirty:before { content: "\\ebb2" }
.codicon-pass-filled:before { content: "\\ebb3" }
.codicon-circle-large-filled:before { content: "\\ebb4" }
.codicon-circle-large:before { content: "\\ebb5" }
.codicon-circle-large-outline:before { content: "\\ebb5" }
.codicon-combine:before { content: "\\ebb6" }
.codicon-gather:before { content: "\\ebb6" }
.codicon-table:before { content: "\\ebb7" }
.codicon-variable-group:before { content: "\\ebb8" }
.codicon-type-hierarchy:before { content: "\\ebb9" }
.codicon-type-hierarchy-sub:before { content: "\\ebba" }
.codicon-type-hierarchy-super:before { content: "\\ebbb" }
.codicon-git-pull-request-create:before { content: "\\ebbc" }
.codicon-run-above:before { content: "\\ebbd" }
.codicon-run-below:before { content: "\\ebbe" }
.codicon-notebook-template:before { content: "\\ebbf" }
.codicon-debug-rerun:before { content: "\\ebc0" }
.codicon-workspace-trusted:before { content: "\\ebc1" }
.codicon-workspace-untrusted:before { content: "\\ebc2" }
.codicon-workspace-unknown:before { content: "\\ebc3" }
.codicon-terminal-cmd:before { content: "\\ebc4" }
.codicon-terminal-debian:before { content: "\\ebc5" }
.codicon-terminal-linux:before { content: "\\ebc6" }
.codicon-terminal-powershell:before { content: "\\ebc7" }
.codicon-terminal-tmux:before { content: "\\ebc8" }
.codicon-terminal-ubuntu:before { content: "\\ebc9" }
.codicon-terminal-bash:before { content: "\\ebca" }
.codicon-arrow-swap:before { content: "\\ebcb" }
.codicon-copy:before { content: "\\ebcc" }
.codicon-person-add:before { content: "\\ebcd" }
.codicon-filter-filled:before { content: "\\ebce" }
.codicon-wand:before { content: "\\ebcf" }
.codicon-debug-line-by-line:before { content: "\\ebd0" }
.codicon-inspect:before { content: "\\ebd1" }
.codicon-layers:before { content: "\\ebd2" }
.codicon-layers-dot:before { content: "\\ebd3" }
.codicon-layers-active:before { content: "\\ebd4" }
.codicon-compass:before { content: "\\ebd5" }
.codicon-compass-dot:before { content: "\\ebd6" }
.codicon-compass-active:before { content: "\\ebd7" }
.codicon-azure:before { content: "\\ebd8" }
.codicon-issue-draft:before { content: "\\ebd9" }
.codicon-git-pull-request-closed:before { content: "\\ebda" }
.codicon-git-pull-request-draft:before { content: "\\ebdb" }
.codicon-debug-all:before { content: "\\ebdc" }
.codicon-debug-coverage:before { content: "\\ebdd" }
.codicon-run-errors:before { content: "\\ebde" }
.codicon-folder-library:before { content: "\\ebdf" }
.codicon-debug-continue-small:before { content: "\\ebe0" }
.codicon-beaker-stop:before { content: "\\ebe1" }
.codicon-graph-line:before { content: "\\ebe2" }
.codicon-graph-scatter:before { content: "\\ebe3" }
.codicon-pie-chart:before { content: "\\ebe4" }
.codicon-bracket-dot:before { content: "\\ebe5" }
.codicon-bracket-error:before { content: "\\ebe6" }
.codicon-lock-small:before { content: "\\ebe7" }
.codicon-azure-devops:before { content: "\\ebe8" }
.codicon-verified-filled:before { content: "\\ebe9" }
.codicon-newline:before { content: "\\ebea" }
.codicon-layout:before { content: "\\ebeb" }
.codicon-layout-activitybar-left:before { content: "\\ebec" }
.codicon-layout-activitybar-right:before { content: "\\ebed" }
.codicon-layout-panel-left:before { content: "\\ebee" }
.codicon-layout-panel-center:before { content: "\\ebef" }
.codicon-layout-panel-justify:before { content: "\\ebf0" }
.codicon-layout-panel-right:before { content: "\\ebf1" }
.codicon-layout-panel:before { content: "\\ebf2" }
.codicon-layout-sidebar-left:before { content: "\\ebf3" }
.codicon-layout-sidebar-right:before { content: "\\ebf4" }
.codicon-layout-statusbar:before { content: "\\ebf5" }
.codicon-layout-menubar:before { content: "\\ebf6" }
.codicon-layout-centered:before { content: "\\ebf7" }
.codicon-target:before { content: "\\ebf8" }
.codicon-indent:before { content: "\\ebf9" }
.codicon-record-small:before { content: "\\ebfa" }
.codicon-error-small:before { content: "\\ebfb" }
.codicon-terminal-decoration-error:before { content: "\\ebfb" }
.codicon-arrow-circle-down:before { content: "\\ebfc" }
.codicon-arrow-circle-left:before { content: "\\ebfd" }
.codicon-arrow-circle-right:before { content: "\\ebfe" }
.codicon-arrow-circle-up:before { content: "\\ebff" }
.codicon-layout-sidebar-right-off:before { content: "\\ec00" }
.codicon-layout-panel-off:before { content: "\\ec01" }
.codicon-layout-sidebar-left-off:before { content: "\\ec02" }
.codicon-blank:before { content: "\\ec03" }
.codicon-heart-filled:before { content: "\\ec04" }
.codicon-map:before { content: "\\ec05" }
.codicon-map-horizontal:before { content: "\\ec05" }
.codicon-fold-horizontal:before { content: "\\ec05" }
.codicon-map-filled:before { content: "\\ec06" }
.codicon-map-horizontal-filled:before { content: "\\ec06" }
.codicon-fold-horizontal-filled:before { content: "\\ec06" }
.codicon-circle-small:before { content: "\\ec07" }
.codicon-bell-slash:before { content: "\\ec08" }
.codicon-bell-slash-dot:before { content: "\\ec09" }
.codicon-comment-unresolved:before { content: "\\ec0a" }
.codicon-git-pull-request-go-to-changes:before { content: "\\ec0b" }
.codicon-git-pull-request-new-changes:before { content: "\\ec0c" }
.codicon-search-fuzzy:before { content: "\\ec0d" }
.codicon-comment-draft:before { content: "\\ec0e" }
.codicon-send:before { content: "\\ec0f" }
.codicon-sparkle:before { content: "\\ec10" }
.codicon-insert:before { content: "\\ec11" }
.codicon-mic:before { content: "\\ec12" }
.codicon-thumbsdown-filled:before { content: "\\ec13" }
.codicon-thumbsup-filled:before { content: "\\ec14" }
.codicon-coffee:before { content: "\\ec15" }
.codicon-snake:before { content: "\\ec16" }
.codicon-game:before { content: "\\ec17" }
.codicon-vr:before { content: "\\ec18" }
.codicon-chip:before { content: "\\ec19" }
.codicon-piano:before { content: "\\ec1a" }
.codicon-music:before { content: "\\ec1b" }
.codicon-mic-filled:before { content: "\\ec1c" }
.codicon-repo-fetch:before { content: "\\ec1d" }
.codicon-copilot:before { content: "\\ec1e" }
.codicon-lightbulb-sparkle:before { content: "\\ec1f" }
.codicon-robot:before { content: "\\ec20" }
.codicon-sparkle-filled:before { content: "\\ec21" }
.codicon-diff-single:before { content: "\\ec22" }
.codicon-diff-multiple:before { content: "\\ec23" }
.codicon-surround-with:before { content: "\\ec24" }
.codicon-share:before { content: "\\ec25" }
.codicon-git-stash:before { content: "\\ec26" }
.codicon-git-stash-apply:before { content: "\\ec27" }
.codicon-git-stash-pop:before { content: "\\ec28" }
.codicon-vscode:before { content: "\\ec29" }
.codicon-vscode-insiders:before { content: "\\ec2a" }
.codicon-code-oss:before { content: "\\ec2b" }
.codicon-run-coverage:before { content: "\\ec2c" }
.codicon-run-all-coverage:before { content: "\\ec2d" }
.codicon-coverage:before { content: "\\ec2e" }
.codicon-github-project:before { content: "\\ec2f" }
.codicon-map-vertical:before { content: "\\ec30" }
.codicon-fold-vertical:before { content: "\\ec30" }
.codicon-map-vertical-filled:before { content: "\\ec31" }
.codicon-fold-vertical-filled:before { content: "\\ec31" }
.codicon-go-to-search:before { content: "\\ec32" }
.codicon-percentage:before { content: "\\ec33" }
.codicon-sort-percentage:before { content: "\\ec33" }
.codicon-attach:before { content: "\\ec34" }
.codicon-go-to-editing-session:before { content: "\\ec35" }
.codicon-edit-session:before { content: "\\ec36" }
.codicon-code-review:before { content: "\\ec37" }
.codicon-copilot-warning:before { content: "\\ec38" }
.codicon-python:before { content: "\\ec39" }
.codicon-copilot-large:before { content: "\\ec3a" }
.codicon-copilot-warning-large:before { content: "\\ec3b" }
.codicon-keyboard-tab:before { content: "\\ec3c" }
.codicon-copilot-blocked:before { content: "\\ec3d" }
.codicon-copilot-not-connected:before { content: "\\ec3e" }
.codicon-flag:before { content: "\\ec3f" }
.codicon-lightbulb-empty:before { content: "\\ec40" }
.codicon-symbol-method-arrow:before { content: "\\ec41" }
.codicon-copilot-unavailable:before { content: "\\ec42" }
.codicon-repo-pinned:before { content: "\\ec43" }
.codicon-keyboard-tab-above:before { content: "\\ec44" }
.codicon-keyboard-tab-below:before { content: "\\ec45" }
.codicon-git-pull-request-done:before { content: "\\ec46" }
.codicon-mcp:before { content: "\\ec47" }
.codicon-extensions-large:before { content: "\\ec48" }
.codicon-layout-panel-dock:before { content: "\\ec49" }
.codicon-layout-sidebar-left-dock:before { content: "\\ec4a" }
.codicon-layout-sidebar-right-dock:before { content: "\\ec4b" }
.codicon-copilot-in-progress:before { content: "\\ec4c" }
.codicon-copilot-error:before { content: "\\ec4d" }
.codicon-copilot-success:before { content: "\\ec4e" }
.codicon-chat-sparkle:before { content: "\\ec4f" }
.codicon-search-sparkle:before { content: "\\ec50" }
.codicon-edit-sparkle:before { content: "\\ec51" }
.codicon-copilot-snooze:before { content: "\\ec52" }
.codicon-send-to-remote-agent:before { content: "\\ec53" }
.codicon-comment-discussion-sparkle:before { content: "\\ec54" }
.codicon-chat-sparkle-warning:before { content: "\\ec55" }
.codicon-chat-sparkle-error:before { content: "\\ec56" }
.codicon-collection:before { content: "\\ec57" }
.codicon-new-collection:before { content: "\\ec58" }
.codicon-thinking:before { content: "\\ec59" }
.codicon-build:before { content: "\\ec5a" }
.codicon-comment-discussion-quote:before { content: "\\ec5b" }
.codicon-cursor:before { content: "\\ec5c" }
.codicon-eraser:before { content: "\\ec5d" }
.codicon-file-text:before { content: "\\ec5e" }
.codicon-quotes:before { content: "\\ec60" }
.codicon-rename:before { content: "\\ec61" }
.codicon-run-with-deps:before { content: "\\ec62" }
.codicon-debug-connected:before { content: "\\ec63" }
.codicon-strikethrough:before { content: "\\ec64" }
.codicon-open-in-product:before { content: "\\ec65" }
.codicon-index-zero:before { content: "\\ec66" }
.codicon-agent:before { content: "\\ec67" }
.codicon-edit-code:before { content: "\\ec68" }
.codicon-repo-selected:before { content: "\\ec69" }
.codicon-skip:before { content: "\\ec6a" }
.codicon-merge-into:before { content: "\\ec6b" }
.codicon-git-branch-changes:before { content: "\\ec6c" }
.codicon-git-branch-staged-changes:before { content: "\\ec6d" }
.codicon-git-branch-conflicts:before { content: "\\ec6e" }
.codicon-git-branch:before { content: "\\ec6f" }
.codicon-git-branch-create:before { content: "\\ec6f" }
.codicon-git-branch-delete:before { content: "\\ec6f" }
.codicon-search-large:before { content: "\\ec70" }
.codicon-terminal-git-bash:before { content: "\\ec71" }
.codicon-window-active:before { content: "\\ec72" }
.codicon-forward:before { content: "\\ec73" }
.codicon-download:before { content: "\\ec74" }
.codicon-clockface:before { content: "\\ec75" }
.codicon-unarchive:before { content: "\\ec76" }
.codicon-session-in-progress:before { content: "\\ec77" }
.codicon-collection-small:before { content: "\\ec78" }
.codicon-vm-small:before { content: "\\ec79" }
.codicon-cloud-small:before { content: "\\ec7a" }
.codicon-add-small:before { content: "\\ec7b" }
.codicon-remove-small:before { content: "\\ec7c" }
.codicon-worktree-small:before { content: "\\ec7d" }
.codicon-worktree:before { content: "\\ec7e" }
.codicon-screen-cut:before { content: "\\ec7f" }
.codicon-ask:before { content: "\\ec80" }
.codicon-openai:before { content: "\\ec81" }
.codicon-claude:before { content: "\\ec82" }
.codicon-open-in-window:before { content: "\\ec83" }
.codicon-new-session:before { content: "\\ec84" }
.codicon-terminal-secure:before { content: "\\ec85" }
.codicon-chat-import:before { content: "\\ec86" }
.codicon-chat-export:before { content: "\\ec87" }
.codicon-share-window:before { content: "\\ec88" }
.codicon-circle-slash-compact:before { content: "\\ec89" }
.codicon-copilot-compact:before { content: "\\ec8a" }
.codicon-folder-opened-compact:before { content: "\\ec8b" }
.codicon-folder-compact:before { content: "\\ec8c" }
.codicon-gear-compact:before { content: "\\ec8d" }
.codicon-git-branch-compact:before { content: "\\ec8e" }
.codicon-library-compact:before { content: "\\ec8f" }
.codicon-record-keys-compact:before { content: "\\ec90" }
.codicon-remote-compact:before { content: "\\ec91" }
.codicon-repo-forked-compact:before { content: "\\ec92" }
.codicon-repo-compact:before { content: "\\ec93" }
.codicon-shield-compact:before { content: "\\ec94" }
.codicon-sparkle-compact:before { content: "\\ec95" }
.codicon-symbol-color-compact:before { content: "\\ec96" }
.codicon-window-compact:before { content: "\\ec97" }
.codicon-error-compact:before { content: "\\ec98" }
.codicon-warning-compact:before { content: "\\ec99" }
.codicon-pass-compact:before { content: "\\ec9a" }
.codicon-important:before { content: "\\ec9b" }
.codicon-important-compact:before { content: "\\ec9c" }
.codicon-rocket-compact:before { content: "\\ec9d" }
.codicon-unpin:before { content: "\\ec9e" }
.codicon-add-compact:before { content: "\\ec9f" }
.codicon-attach-compact:before { content: "\\eca0" }
.codicon-beaker-compact:before { content: "\\eca1" }
.codicon-check-compact:before { content: "\\eca2" }
.codicon-checklist-compact:before { content: "\\eca3" }
.codicon-chevron-down-compact:before { content: "\\eca4" }
.codicon-chevron-left-compact:before { content: "\\eca5" }
.codicon-chevron-right-compact:before { content: "\\eca6" }
.codicon-chevron-up-compact:before { content: "\\eca7" }
.codicon-circle-filled-compact:before { content: "\\eca8" }
.codicon-circle-small-filled-compact:before { content: "\\eca9" }
.codicon-close-compact:before { content: "\\ecaa" }
.codicon-collapse-all-compact:before { content: "\\ecab" }
.codicon-comment-compact:before { content: "\\ecac" }
.codicon-comment-unresolved-compact:before { content: "\\ecad" }
.codicon-debug-connected-compact:before { content: "\\ecae" }
.codicon-debug-disconnect-compact:before { content: "\\ecaf" }
.codicon-edit-compact:before { content: "\\ecb0" }
.codicon-file-media-compact:before { content: "\\ecb1" }
.codicon-git-fetch:before { content: "\\ecb2" }
.codicon-lightbulb-compact:before { content: "\\ecb3" }
.codicon-loading-compact:before { content: "\\ecb4" }
.codicon-pass-filled-compact:before { content: "\\ecb5" }
.codicon-project-compact:before { content: "\\ecb6" }
.codicon-refresh-compact:before { content: "\\ecb7" }
.codicon-search-compact:before { content: "\\ecb8" }
.codicon-session-in-progress-compact:before { content: "\\ecb9" }
.codicon-sync-compact:before { content: "\\ecba" }
.codicon-terminal-compact:before { content: "\\ecbb" }
.codicon-vm-pending:before { content: "\\ecbc" }
.codicon-worktree-compact:before { content: "\\ecbd" }
.codicon-developer-tools:before { content: "\\ecbe" }
.codicon-cloud-compact:before { content: "\\ecbf" }
.codicon-agent-compact:before { content: "\\ecc0" }
.codicon-ask-compact:before { content: "\\ecc1" }
.codicon-settings-compact:before { content: "\\ecc2" }
.codicon-vm-compact:before { content: "\\ecc3" }
.codicon-run-compact:before { content: "\\ecc4" }
.codicon-git-pull-request-comment:before { content: "\\ecc5" }
.codicon-git-pull-request-error:before { content: "\\ecc6" }
.codicon-right-panel-hide:before { content: "\\ecc7" }
.codicon-right-panel-show:before { content: "\\ecc8" }
.codicon-vscode-insiders-outline:before { content: "\\ecc9" }
.codicon-vscode-outline:before { content: "\\ecca" }
.codicon-voice-mode:before { content: "\\eccb" }
.codicon-voice-mode-compact:before { content: "\\eccc" }
.codicon-mic-download:before { content: "\\eccd" }
.codicon-mic-download-compact:before { content: "\\ecce" }
.codicon-voice-mode-download:before { content: "\\eccf" }
.codicon-voice-mode-download-compact:before { content: "\\ecd0" }
.codicon-google-gemini:before { content: "\\ecd1" }
.codicon-kimi:before { content: "\\ecd2" }
.codicon-microsoft:before { content: "\\ecd3" }
.codicon-fish1-happy:before { content: "\\ecd4" }
.codicon-fish1-neutral:before { content: "\\ecd5" }
.codicon-fish1-sad:before { content: "\\ecd6" }
.codicon-fish1-very-sad:before { content: "\\ecd7" }
.codicon-fish2-happy:before { content: "\\ecd8" }
.codicon-fish2-neutral:before { content: "\\ecd9" }
.codicon-fish2-sad:before { content: "\\ecda" }
.codicon-fish2-very-sad:before { content: "\\ecdb" }
.codicon-fish3-happy:before { content: "\\ecdc" }
.codicon-fish3-neutral:before { content: "\\ecdd" }
.codicon-fish3-sad:before { content: "\\ecde" }
.codicon-fish3-very-sad:before { content: "\\ecdf" }
.codicon-fish4-happy:before { content: "\\ece0" }
.codicon-fish4-neutral:before { content: "\\ece1" }
.codicon-fish4-sad:before { content: "\\ece2" }
.codicon-fish4-very-sad:before { content: "\\ece3" }
.codicon-person-voice:before { content: "\\ece4" }
.codicon-person-voice-compact:before { content: "\\ece5" }
.codicon-person-voice-filled:before { content: "\\ece6" }
.codicon-person-voice-filled-compact:before { content: "\\ece7" }
`;var Pr=`/* VS Code theme variables for hosts outside VS Code (the browser extension's pages): a dark and
   a light set that follow the system theme, matching VS Code's Dark Modern and Light Modern. */

.ink-theme {
  --vscode-font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  --vscode-font-size: 13px;
  --vscode-editor-font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
  --vscode-foreground: #cccccc;
  --vscode-descriptionForeground: #9d9d9d;
  --vscode-icon-foreground: #cccccc;
  --vscode-editor-background: #1f1f1f;
  --vscode-editorWidget-background: #202020;
  --vscode-widget-border: #313131;
  --vscode-widget-shadow: rgba(0, 0, 0, 0.36);
  --vscode-focusBorder: #0078d4;
  --vscode-button-background: #0078d4;
  --vscode-button-foreground: #ffffff;
  --vscode-button-hoverBackground: #026ec1;
  --vscode-button-border: rgba(255, 255, 255, 0.07);
  --vscode-button-secondaryBackground: #313131;
  --vscode-button-secondaryForeground: #cccccc;
  --vscode-button-secondaryHoverBackground: #3c3c3c;
  --vscode-toolbar-hoverBackground: rgba(90, 93, 94, 0.31);
  --vscode-toolbar-activeBackground: rgba(99, 102, 103, 0.31);
  --vscode-input-background: #313131;
  --vscode-input-foreground: #cccccc;
  --vscode-input-border: #3c3c3c;
  --vscode-input-placeholderForeground: #989898;
  --vscode-dropdown-background: #313131;
  --vscode-dropdown-foreground: #cccccc;
  --vscode-dropdown-border: #3c3c3c;
  --vscode-checkbox-background: #313131;
  --vscode-checkbox-border: #3c3c3c;
  --vscode-menu-background: #1f1f1f;
  --vscode-menu-foreground: #cccccc;
  --vscode-menu-selectionBackground: #0078d4;
  --vscode-menu-selectionForeground: #ffffff;
  --vscode-menu-separatorBackground: #454545;
  --vscode-menu-border: #454545;
  --vscode-notifications-background: #1f1f1f;
  --vscode-notifications-foreground: #cccccc;
  --vscode-notifications-border: #2b2b2b;
  --vscode-textLink-foreground: #4daafc;
  --vscode-errorForeground: #f85149;
  --vscode-testing-iconPassed: #73c991;
  --vscode-editorWarning-foreground: #cca700;
  --vscode-terminal-ansiBlue: #4daafc;
  --vscode-terminal-ansiGreen: #3fb950;
  --vscode-terminal-ansiYellow: #d7ba7d;
  --vscode-terminal-ansiRed: #f85149;
  --vscode-terminal-ansiMagenta: #d670d6;
  --vscode-badge-background: #616161;
  --vscode-badge-foreground: #f8f8f8;
  --vscode-keybindingLabel-background: rgba(128, 128, 128, 0.17);
  --vscode-keybindingLabel-foreground: #cccccc;
  --vscode-keybindingLabel-border: rgba(51, 51, 51, 0.6);
  color-scheme: dark;
}

@media (prefers-color-scheme: light) {
  .ink-theme {
    --vscode-foreground: #3b3b3b;
    --vscode-descriptionForeground: #6f6f6f;
    --vscode-icon-foreground: #3b3b3b;
    --vscode-editor-background: #ffffff;
    --vscode-editorWidget-background: #f8f8f8;
    --vscode-widget-border: #e5e5e5;
    --vscode-widget-shadow: rgba(0, 0, 0, 0.16);
    --vscode-focusBorder: #005fb8;
    --vscode-button-background: #005fb8;
    --vscode-button-hoverBackground: #0258a8;
    --vscode-button-border: rgba(0, 0, 0, 0.1);
    --vscode-button-secondaryBackground: #e5e5e5;
    --vscode-button-secondaryForeground: #3b3b3b;
    --vscode-button-secondaryHoverBackground: #cccccc;
    --vscode-toolbar-hoverBackground: rgba(184, 184, 184, 0.31);
    --vscode-toolbar-activeBackground: rgba(166, 166, 166, 0.31);
    --vscode-input-background: #ffffff;
    --vscode-input-foreground: #3b3b3b;
    --vscode-input-border: #cecece;
    --vscode-input-placeholderForeground: #767676;
    --vscode-dropdown-background: #ffffff;
    --vscode-dropdown-foreground: #3b3b3b;
    --vscode-dropdown-border: #cecece;
    --vscode-checkbox-background: #f8f8f8;
    --vscode-checkbox-border: #cecece;
    --vscode-menu-background: #ffffff;
    --vscode-menu-foreground: #3b3b3b;
    --vscode-menu-selectionBackground: #005fb8;
    --vscode-menu-separatorBackground: #d4d4d4;
    --vscode-menu-border: #cecece;
    --vscode-notifications-background: #ffffff;
    --vscode-notifications-foreground: #3b3b3b;
    --vscode-notifications-border: #e5e5e5;
    --vscode-textLink-foreground: #005fb8;
    --vscode-errorForeground: #b3261e;
    --vscode-testing-iconPassed: #2e7d32;
    --vscode-editorWarning-foreground: #895503;
    --vscode-terminal-ansiBlue: #005fb8;
    --vscode-terminal-ansiGreen: #1a7f37;
    --vscode-terminal-ansiYellow: #895503;
    --vscode-terminal-ansiRed: #c72e0f;
    --vscode-terminal-ansiMagenta: #a626a4;
    --vscode-badge-background: #cccccc;
    --vscode-badge-foreground: #3b3b3b;
    --vscode-keybindingLabel-foreground: #3b3b3b;
    --vscode-keybindingLabel-border: rgba(204, 204, 204, 0.4);
    color-scheme: light;
  }
}
`;var ef=`/* The Inkspect design system: tokens and the shared components (buttons, fields, selects,
   switches, sliders, color picker, menus, toast, drawing toolbar and layer).
   Colors come from VS Code theme variables; hosts outside VS Code define them (theme.css).
   Every surface uses the tokens below, so sizes, radii and elevation stay consistent. */

:root,
:host {
  /* Shape */
  --ink-radius-sm: 4px;
  --ink-radius: 6px;
  --ink-radius-lg: 10px;
  --ink-radius-pill: 999px;
  /* Controls */
  --ink-control-sm: 24px;
  --ink-control: 28px;
  --ink-control-lg: 36px;
  /* Spacing */
  --ink-space-1: 4px;
  --ink-space-2: 8px;
  --ink-space-3: 12px;
  --ink-space-4: 16px;
  --ink-space-5: 24px;
  --ink-space-6: 32px;
  /* Type */
  --ink-font-xs: 11px;
  --ink-font-sm: 12px;
  --ink-font: var(--vscode-font-size, 13px);
  --ink-font-lg: 15px;
  --ink-font-xl: 22px;
  /* Surfaces and lines */
  --ink-surface: var(--vscode-editorWidget-background, var(--vscode-editor-background));
  /* Popups: lifted off the menu background, since many dark themes (Tokyo Night) give menus the
     sidebar's own color, a border the same near-black, and no shadow at all. */
  --ink-surface-raised: color-mix(
    in srgb,
    var(--vscode-foreground, #888) 7%,
    var(--vscode-menu-background, var(--ink-surface))
  );
  --ink-surface-sunken: color-mix(in srgb, var(--vscode-foreground, #888) 4%, transparent);
  --ink-border: var(--vscode-widget-border, rgba(128, 128, 128, 0.35));
  --ink-border-subtle: color-mix(in srgb, var(--vscode-foreground, #888) 10%, transparent);
  --ink-border-strong: color-mix(in srgb, var(--vscode-foreground, #888) 22%, transparent);
  --ink-hover: var(--vscode-toolbar-hoverBackground, rgba(128, 128, 128, 0.18));
  --ink-pressed: var(--vscode-toolbar-activeBackground, rgba(128, 128, 128, 0.26));
  /* Focus rings follow the theme's focus border; accents use the button color, which themes keep
     vivid (the focus border can be very dim). Text on tinted backgrounds uses the link color. */
  --ink-focus: var(--vscode-focusBorder, #0078d4);
  --ink-accent: var(--vscode-button-background, var(--ink-focus));
  --ink-accent-fg: var(--vscode-textLink-foreground, var(--ink-accent));
  --ink-accent-soft: color-mix(in srgb, var(--ink-accent) 20%, transparent);
  /* Secondary text, pulled toward the foreground so it stays readable in low-contrast themes. */
  --ink-muted: color-mix(
    in srgb,
    var(--vscode-descriptionForeground, #9d9d9d) 70%,
    var(--vscode-foreground, #ccc)
  );
  --ink-danger: var(--vscode-errorForeground, #f85149);
  --ink-success: var(--vscode-testing-iconPassed, #73c991);
  --ink-warning: var(--vscode-editorWarning-foreground, #cca700);
  /* The theme's own palette. Every theme defines its terminal ANSI colors, and they are its true
     hues (Tokyo Night's are #7aa2f7, #9ece6a, #e0af68, #f7768e, #bb9af7), unlike button and
     error colors, which some themes keep dim. Pulled slightly toward the foreground so they stay
     readable as text on both light and dark backgrounds. */
  --ink-blue: color-mix(
    in srgb,
    var(--vscode-terminal-ansiBlue, #3b8eea) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-green: color-mix(
    in srgb,
    var(--vscode-terminal-ansiGreen, #23d18b) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-yellow: color-mix(
    in srgb,
    var(--vscode-terminal-ansiYellow, #e5e510) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-red: color-mix(
    in srgb,
    var(--vscode-terminal-ansiRed, #f14c4c) 88%,
    var(--vscode-foreground, #888)
  );
  --ink-magenta: color-mix(
    in srgb,
    var(--vscode-terminal-ansiMagenta, #d670d6) 88%,
    var(--vscode-foreground, #888)
  );
  /* Elevation */
  /* Half the theme's widget shadow, half plain black: some themes make theirs transparent. */
  --ink-shadow-color: color-mix(
    in srgb,
    var(--vscode-widget-shadow, rgba(0, 0, 0, 0.3)) 50%,
    rgba(0, 0, 0, 0.5)
  );
  --ink-shadow-sm: 0 1px 3px var(--ink-shadow-color);
  --ink-shadow: 0 6px 20px var(--ink-shadow-color), 0 1px 4px var(--ink-shadow-color);
  --ink-shadow-lg: 0 12px 32px var(--ink-shadow-color), 0 2px 8px var(--ink-shadow-color);
  /* Motion */
  --ink-ease: cubic-bezier(0.2, 0, 0, 1);
  --ink-fast: 90ms;
  --ink-normal: 160ms;
}

/* Focus ------------------------------------------------------------------------------------ */

.icon-button:focus-visible,
.button:focus-visible,
.link-button:focus-visible,
.menu-item:focus-visible,
.select:focus-visible,
.switch:focus-visible,
.checkbox:focus-visible,
.segment:focus-visible,
.slider-track:focus-visible,
.swatch:focus-visible,
.color-area:focus-visible,
.color-hue:focus-visible,
.chip:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: 1px;
}

/* Icon buttons ----------------------------------------------------------------------------- */

.icon-button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: var(--ink-control);
  height: var(--ink-control);
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--vscode-icon-foreground, var(--vscode-foreground));
  font: inherit;
  cursor: pointer;
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.icon-button.small {
  width: var(--ink-control-sm);
  height: var(--ink-control-sm);
}

.icon-button:hover:not(:disabled) {
  background: var(--ink-hover);
}

.icon-button:active:not(:disabled) {
  background: var(--ink-pressed);
}

.icon-button.active {
  background: var(--ink-accent-soft);
  color: var(--vscode-inputOption-activeForeground, var(--vscode-foreground));
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--ink-accent) 60%, transparent);
}

.icon-button:disabled {
  opacity: 0.4;
  cursor: default;
}

/* Buttons ---------------------------------------------------------------------------------- */

.button {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: var(--ink-control);
  padding: 0 12px;
  border: 1px solid var(--vscode-button-border, transparent);
  border-radius: var(--ink-radius-sm);
  font: inherit;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.button.small {
  gap: 4px;
  height: var(--ink-control-sm);
  padding: 0 8px;
}

.button .codicon {
  font-size: 14px;
}

.button.primary {
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.primary:hover:not(:disabled) {
  background: var(--vscode-button-hoverBackground);
}

.button.secondary {
  background: var(--vscode-button-secondaryBackground);
  color: var(--vscode-button-secondaryForeground);
}

.button.secondary:hover:not(:disabled) {
  background: var(--vscode-button-secondaryHoverBackground);
}

.button.ghost {
  border-color: transparent;
  background: transparent;
  color: inherit;
}

.button.ghost:hover:not(:disabled) {
  background: var(--ink-hover);
}

/* A solid call to action in the theme's own blue (its palette, see --ink-blue), for themes whose
   button color is dim. Dark text on dark themes, where the palette's blue is light. */
.button.accent {
  border-color: transparent;
  background: var(--ink-blue);
  color: var(--vscode-editor-background, #fff);
  font-weight: 600;
}

.button.accent:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-blue) 85%, var(--vscode-foreground, #fff));
}

body.vscode-light .button.accent {
  color: #fff;
}

body.vscode-high-contrast .button.accent {
  border-color: var(--vscode-contrastBorder, transparent);
  background: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
}

.button.danger {
  border-color: color-mix(in srgb, var(--ink-danger) 45%, transparent);
  background: transparent;
  color: var(--ink-danger);
}

.button.danger:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ink-danger) 12%, transparent);
}

.button:disabled {
  opacity: 0.5;
  cursor: default;
}

.link-button {
  padding: 0;
  border: none;
  background: none;
  color: var(--vscode-textLink-foreground);
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.link-button:hover:not(:disabled) {
  color: var(--vscode-textLink-activeForeground, var(--vscode-textLink-foreground));
  text-decoration: underline;
}

.link-button:disabled {
  color: inherit;
  cursor: default;
}

.link-button.danger {
  color: var(--ink-danger);
}

/* Text fields ------------------------------------------------------------------------------ */

.text-field {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: var(--ink-control);
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  transition: border-color var(--ink-fast) var(--ink-ease);
}

.text-field.size-sm {
  height: var(--ink-control-sm);
  padding: 0 6px;
}

.text-field.size-lg {
  height: var(--ink-control-lg);
  padding: 0 12px;
  border-radius: var(--ink-radius);
}

.text-field:hover:not(.disabled) {
  border-color: var(--ink-border-strong);
}

.text-field:focus-within {
  border-color: var(--ink-focus);
  box-shadow: 0 0 0 1px var(--ink-focus);
}

.text-field.invalid {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.text-field.disabled {
  opacity: 0.5;
}

.text-field input {
  flex: 1;
  width: 100%;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: none;
  outline: none;
  background: transparent;
  color: inherit;
  font: inherit;
}

.text-field input::placeholder {
  color: var(--vscode-input-placeholderForeground, var(--ink-muted));
}

/* Numbers: no spinner arrows (the fields accept typing and arrow keys). */
.text-field input::-webkit-outer-spin-button,
.text-field input::-webkit-inner-spin-button {
  margin: 0;
  appearance: none;
}

.text-field input[type='number'] {
  appearance: textfield;
  font-variant-numeric: tabular-nums;
}

.text-field input[type='search']::-webkit-search-cancel-button {
  appearance: none;
}

.text-field-icon {
  flex-shrink: 0;
  color: var(--ink-muted);
}

.text-field-clear {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.text-field-clear:hover {
  background: var(--ink-hover);
  color: inherit;
}

/* Form rows -------------------------------------------------------------------------------- */

.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: var(--ink-space-3);
}

.field.inline {
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ink-space-3);
}

.field-label {
  color: var(--vscode-foreground);
  font-weight: 600;
}

.field.inline .field-label {
  font-weight: normal;
}

.field-control {
  display: flex;
  align-items: center;
  gap: var(--ink-space-2);
  min-width: 0;
}

.field-control > .text-field,
.field-control > .select {
  flex: 1;
}

.field-hint {
  flex-basis: 100%;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.field-hint.error {
  color: var(--ink-danger);
}

/* Select ----------------------------------------------------------------------------------- */

.select {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  height: var(--ink-control);
  padding: 0 6px 0 8px;
  border: 1px solid var(--vscode-dropdown-border, var(--vscode-input-border, var(--ink-border)));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-dropdown-background, var(--vscode-input-background));
  color: var(--vscode-dropdown-foreground, var(--vscode-input-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.select.size-sm {
  height: var(--ink-control-sm);
  padding: 0 4px 0 6px;
}

.select:hover:not(:disabled) {
  border-color: var(--ink-border-strong);
}

.select.open {
  border-color: var(--ink-focus);
}

.select.quiet {
  border-color: transparent;
  background: transparent;
}

.select.quiet:hover:not(:disabled),
.select.quiet.open {
  border-color: transparent;
  background: var(--ink-hover);
}

.select:disabled {
  opacity: 0.45;
  cursor: default;
}

.select-value {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.select-value.placeholder {
  color: var(--ink-muted);
}

.select-chevron {
  flex-shrink: 0;
  font-size: 14px !important;
  opacity: 0.8;
  transition: transform var(--ink-normal) var(--ink-ease);
}

.select.open .select-chevron {
  transform: rotate(180deg);
}

.select-list,
.color-picker,
.menu,
.popover {
  background: var(--ink-surface-raised);
  color: var(--vscode-menu-foreground, var(--vscode-foreground));
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow);
}

.select-list {
  position: fixed;
  z-index: 1000;
  max-height: min(340px, 60vh);
  padding: 4px;
  overflow-y: auto;
  outline: none;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.select-group {
  padding: 8px 8px 4px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.select-group:first-child {
  padding-top: 4px;
}

.select-option {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px 0 4px;
  border-radius: var(--ink-radius-sm);
  white-space: nowrap;
  cursor: pointer;
}

.select-option.active {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
}

.select-option.disabled {
  opacity: 0.45;
  cursor: default;
}

.select-check {
  flex-shrink: 0;
  font-size: 14px !important;
}

.select-option-label {
  flex: 1;
}

.select-option-detail {
  margin-left: 16px;
  opacity: 0.65;
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Switch and checkbox ---------------------------------------------------------------------- */

.switch,
.checkbox {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: var(--ink-space-2);
  padding: 2px 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.switch:disabled,
.checkbox:disabled {
  opacity: 0.45;
  cursor: default;
}

.switch-track {
  position: relative;
  flex-shrink: 0;
  width: 30px;
  height: 16px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-input-background, var(--ink-surface-sunken));
  transition:
    background-color var(--ink-normal) var(--ink-ease),
    border-color var(--ink-normal) var(--ink-ease);
}

.switch-thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--ink-muted);
  transition:
    transform var(--ink-normal) var(--ink-ease),
    background-color var(--ink-normal) var(--ink-ease);
}

.switch.on .switch-track {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
}

.switch.on .switch-thumb {
  background: var(--vscode-button-foreground, #fff);
  transform: translateX(14px);
}

.checkbox-box {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border: 1px solid var(--vscode-checkbox-border, var(--ink-border-strong));
  border-radius: 3px;
  background: var(--vscode-checkbox-background, var(--vscode-input-background));
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.checkbox.on .checkbox-box {
  border-color: var(--vscode-button-background, var(--ink-accent));
  background: var(--vscode-button-background, var(--ink-accent));
  color: var(--vscode-button-foreground, #fff);
}

.checkbox-box .codicon {
  font-size: 14px !important;
}

/* Segmented control ------------------------------------------------------------------------ */

.segmented {
  display: inline-flex;
  flex-shrink: 0;
  gap: 2px;
  height: var(--ink-control);
  padding: 2px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--ink-surface-sunken);
}

.segmented.size-sm {
  height: var(--ink-control-sm);
  padding: 1px;
  border-radius: var(--ink-radius-sm);
}

.segment {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  gap: 5px;
  min-width: 26px;
  padding: 0 10px;
  border: none;
  border-radius: calc(var(--ink-radius) - 2px);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color var(--ink-fast) var(--ink-ease),
    color var(--ink-fast) var(--ink-ease);
}

.segmented.size-sm .segment {
  padding: 0 8px;
  border-radius: 3px;
}

.segment:hover {
  color: var(--vscode-foreground);
}

.segment.checked {
  background: var(--vscode-button-secondaryBackground, var(--ink-hover));
  color: var(--vscode-button-secondaryForeground, var(--vscode-foreground));
  box-shadow: var(--ink-shadow-sm);
}

.segment-count {
  min-width: 16px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
  text-align: center;
}

.segment-count.error {
  background: var(--ink-danger);
  color: #fff;
}

/* Slider ----------------------------------------------------------------------------------- */

.slider {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
  height: var(--ink-control);
}

.slider.disabled {
  opacity: 0.45;
}

.slider > .codicon {
  color: var(--ink-muted);
}

.slider-track {
  position: relative;
  width: 84px;
  height: 18px;
  cursor: pointer;
  touch-action: none;
  border-radius: var(--ink-radius-sm);
}

.slider-track::before,
.slider-fill {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  height: 4px;
  border-radius: var(--ink-radius-pill);
  transform: translateY(-50%);
}

.slider-track::before {
  right: 0;
  background: var(--ink-border-strong);
}

.slider-fill {
  background: var(--ink-accent);
}

.slider-thumb {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid var(--ink-accent);
  border-radius: 50%;
  background: var(--vscode-editor-background, #fff);
  box-shadow: var(--ink-shadow-sm);
  transform: translate(-50%, -50%);
  transition: transform var(--ink-fast) var(--ink-ease);
}

.slider-track:hover .slider-thumb,
.slider-track:active .slider-thumb {
  transform: translate(-50%, -50%) scale(1.15);
}

.slider-value {
  min-width: 34px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
  font-variant-numeric: tabular-nums;
}

/* Swatches and color picker ---------------------------------------------------------------- */

.swatch {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  padding: 0;
  border: 1px solid color-mix(in srgb, var(--vscode-foreground, #888) 30%, transparent);
  border-radius: 50%;
  cursor: pointer;
  transition: transform var(--ink-fast) var(--ink-ease);
}

.swatch:hover {
  transform: scale(1.12);
}

.swatch.small {
  width: 16px;
  height: 16px;
}

.swatch.active {
  box-shadow:
    0 0 0 2px var(--ink-surface),
    0 0 0 3.5px var(--ink-accent);
}

.color-picker-trigger {
  background: conic-gradient(
    from 90deg,
    #f43f5e,
    #f59e0b,
    #84cc16,
    #06b6d4,
    #6366f1,
    #d946ef,
    #f43f5e
  );
}

.color-picker {
  position: fixed;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 224px;
  padding: 10px;
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font);
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

.color-area {
  position: relative;
  height: 140px;
  border-radius: var(--ink-radius-sm);
  background-image:
    linear-gradient(to top, #000, transparent), linear-gradient(to right, #fff, transparent) !important;
  cursor: crosshair;
  touch-action: none;
}

.color-hue {
  position: relative;
  height: 12px;
  border-radius: var(--ink-radius-pill);
  background: linear-gradient(
    to right,
    #f00 0%,
    #ff0 17%,
    #0f0 33%,
    #0ff 50%,
    #00f 67%,
    #f0f 83%,
    #f00 100%
  );
  cursor: pointer;
  touch-action: none;
}

.color-handle {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.35),
    0 1px 4px rgba(0, 0, 0, 0.4);
  transform: translate(-50%, -50%);
  pointer-events: none;
}

.color-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.color-preview {
  flex-shrink: 0;
  width: 26px;
  height: 26px;
  border: 1px solid var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
}

.color-hex {
  flex: 1;
  min-width: 0;
  height: 26px;
  padding: 0 8px;
  border: 1px solid var(--vscode-input-border, var(--ink-border));
  border-radius: var(--ink-radius-sm);
  outline: none;
  background: var(--vscode-input-background);
  color: var(--vscode-input-foreground);
  font-family: var(--vscode-editor-font-family, monospace);
  font-size: var(--ink-font-sm);
  text-transform: lowercase;
}

.color-hex:focus {
  border-color: var(--ink-focus);
}

.color-presets {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  padding-top: 8px;
  border-top: 1px solid var(--ink-border-subtle);
}

/* Chips and badges ------------------------------------------------------------------------- */

.badge {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 7px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  white-space: nowrap;
}

.badge.outline {
  border: 1px solid var(--ink-border-strong);
  background: transparent;
  color: var(--ink-muted);
}

.badge.success {
  background: color-mix(in srgb, var(--ink-success) 18%, transparent);
  color: var(--ink-success);
}

.badge.danger {
  background: color-mix(in srgb, var(--ink-danger) 18%, transparent);
  color: var(--ink-danger);
}

/* Key caps (shortcuts) --------------------------------------------------------------------- */

.keycaps {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 3px;
}

.keycap {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border: 1px solid var(--vscode-keybindingLabel-border, var(--ink-border-strong));
  border-radius: var(--ink-radius-sm);
  background: var(--vscode-keybindingLabel-background, var(--ink-surface-sunken));
  box-shadow: inset 0 -1px 0 var(--vscode-keybindingLabel-bottomBorder, var(--ink-border-strong));
  color: var(--vscode-keybindingLabel-foreground, var(--vscode-foreground));
  font-family: var(--vscode-font-family);
  font-size: var(--ink-font-xs);
  font-weight: 500;
  line-height: 1;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.keycaps.size-sm .keycap {
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  font-size: 10.5px;
}

/* Cards ------------------------------------------------------------------------------------ */

.card {
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius-lg);
  background: var(--ink-surface-sunken);
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--ink-space-3);
  padding: var(--ink-space-3) var(--ink-space-4);
  border-bottom: 1px solid var(--ink-border-subtle);
}

.card-title {
  margin: 0;
  font-size: var(--ink-font);
  font-weight: 600;
}

.card-body {
  padding: var(--ink-space-4);
}

.card-row {
  display: flex;
  align-items: center;
  gap: var(--ink-space-4);
  padding: var(--ink-space-3) var(--ink-space-4);
}

.card-row + .card-row {
  border-top: 1px solid var(--ink-border-subtle);
}

.card-row-text {
  flex: 1;
  min-width: 0;
}

.card-row-title {
  font-weight: 500;
}

.card-row-description {
  margin-top: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

/* Menus and popovers ----------------------------------------------------------------------- */

.menu,
.popover {
  position: fixed;
  z-index: 100;
  min-width: 200px;
  max-width: 420px;
  padding: 4px;
  animation: ink-pop-in var(--ink-normal) var(--ink-ease);
}

/* Long menus (a big bookmarks folder) stay short and scroll, like Chrome's. Items have a little
   room between them. */
.menu {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 5px;
  max-height: min(420px, calc(100vh - 8px));
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Submenus open without the pop animation, so they don't jump while the pointer moves. */
.menu .menu {
  animation: none;
}

.menu-item.expanded:not(:focus) {
  background: var(--ink-hover);
}

.menu-image {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  object-fit: contain;
}

.menu-arrow {
  margin-left: 12px;
  margin-right: -2px;
  opacity: 0.8;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  width: 100%;
  height: 28px;
  padding: 0 10px 0 8px;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.menu-item:hover:not(:disabled),
.menu-item:focus {
  background: var(--vscode-menu-selectionBackground, var(--vscode-list-activeSelectionBackground));
  color: var(--vscode-menu-selectionForeground, var(--vscode-list-activeSelectionForeground));
  outline: none;
}

.menu-item:disabled {
  opacity: 0.45;
  cursor: default;
}

.menu-label {
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.menu-shortcut {
  margin-left: 16px;
  opacity: 0.7;
  font-size: 0.9em;
}

.menu-separator {
  flex-shrink: 0;
  height: 1px;
  margin: 3px 6px;
  background: var(--vscode-menu-separatorBackground, var(--ink-border));
}

/* Toast ------------------------------------------------------------------------------------ */

.toast {
  position: fixed;
  bottom: 16px;
  left: 50%;
  z-index: 200;
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: calc(100% - 32px);
  padding: 8px 14px;
  transform: translateX(-50%);
  background: var(--vscode-notifications-background, var(--ink-surface));
  color: var(--vscode-notifications-foreground, var(--vscode-foreground));
  border: 1px solid var(--vscode-notifications-border, var(--ink-border));
  border-radius: var(--ink-radius);
  box-shadow: var(--ink-shadow-lg);
  animation: toast-in var(--ink-normal) var(--ink-ease);
}

/* A failure: marked as one, longer on screen, and dismissible. */
.toast.error {
  border-color: var(--vscode-inputValidation-errorBorder, var(--ink-danger));
}

.toast.error > .codicon-error {
  flex-shrink: 0;
  color: var(--ink-danger);
}

.toast .toast-dismiss {
  flex-shrink: 0;
  margin: -4px -8px -4px 0;
}

.header-actions,
.button-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
}

/* Drawing ---------------------------------------------------------------------------------- */

.draw-toolbar {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  padding: 4px 8px;
  background: var(--ink-surface);
  border-top: 1px solid var(--ink-border);
  border-bottom: 1px solid var(--ink-border);
}

.draw-group {
  display: flex;
  align-items: center;
  gap: 2px;
  padding-right: 6px;
  border-right: 1px solid var(--ink-border-subtle);
}

.draw-group.colors {
  gap: 6px;
  padding: 0 8px 0 4px;
}

.draw-capture {
  margin-left: 2px;
}

.draw-close {
  margin-left: auto;
}

.drawing-layer {
  position: absolute;
  z-index: 3;
}

.drawing-layer canvas {
  position: relative;
  display: block;
  touch-action: none;
}

/* A live redaction (liveRedactions): blurs the page behind it, under the drawing canvas. Drawn
   over page content, so its colors are fixed. */
.drawing-redaction {
  position: absolute;
  pointer-events: none;
  background: rgba(128, 128, 128, 0.2);
  backdrop-filter: blur(12px) saturate(0.5);
}

.drawing-text-input {
  position: absolute;
  min-width: 160px;
  min-height: 1.6em;
  padding: 2px 4px;
  border: 1px dashed var(--ink-accent);
  background: rgba(255, 255, 255, 0.85);
  font-family: system-ui, sans-serif;
  font-weight: 600;
  resize: both;
  outline: none;
}

/* Motion ----------------------------------------------------------------------------------- */

@keyframes ink-pop-in {
  from {
    opacity: 0;
    transform: translateY(-3px) scale(0.985);
  }
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translate(-50%, 8px);
  }
}

@media (prefers-reduced-motion: reduce) {
  .select-list,
  .color-picker,
  .menu,
  .popover,
  .toast {
    animation: none;
  }
}

/* Shortcut list (ShortcutList) ------------------------------------------------------------- */

.shortcuts-warning {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 12px 8px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

/* Groups: a pinned header per mode. */
.group-header {
  position: sticky;
  top: var(--shortcut-sticky-top, 0);
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  height: 28px;
  padding: 0 12px 0 6px;
  border: none;
  border-top: 1px solid var(--ink-border-subtle);
  background: var(--vscode-sideBar-background, var(--vscode-editor-background));
  color: var(--vscode-sideBarSectionHeader-foreground, var(--vscode-foreground));
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.group-header:hover {
  background: var(--vscode-list-hoverBackground);
}

.group-header:focus-visible {
  outline: 1px solid var(--ink-focus);
  outline-offset: -1px;
}

.group-icon {
  color: var(--ink-accent-fg);
}

.group-title {
  font-size: var(--ink-font-xs);
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.group-count {
  margin-left: auto;
  padding: 0 6px;
  border-radius: var(--ink-radius-pill);
  background: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  font-size: var(--ink-font-xs);
  line-height: 16px;
}

/* Rows: label, then actions (on hover), then the keys in a right-aligned column. */
.shortcut-item {
  position: relative;
  padding: 0 12px 0 32px;
  border-radius: var(--ink-radius);
  transition: background-color var(--ink-fast) var(--ink-ease);
}

.shortcut-item::before {
  content: '';
  position: absolute;
  top: 6px;
  bottom: 6px;
  left: 20px;
  width: 2px;
  border-radius: 1px;
  background: transparent;
}

.shortcut-item.changed::before {
  background: var(--ink-accent);
}

.shortcut-item.conflict::before {
  background: var(--ink-warning);
}

/* Outside VS Code (the browser extension) there is no list hover color: the kit's hover. */
.shortcut-item:hover,
.shortcut-item:focus-within {
  background: var(--vscode-list-hoverBackground, var(--ink-hover));
}

body.vscode-high-contrast .shortcut-item:hover,
body.vscode-high-contrast .shortcut-item:focus-within {
  outline: 1px dashed var(--vscode-contrastActiveBorder);
  outline-offset: -1px;
}

.shortcut-main {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 30px;
}

.shortcut-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Where a key works: VS (VS Code Browser) and BR (the browser toolbar), and the browser's own key. */
.shortcut-places {
  display: inline-flex;
  flex-shrink: 0;
  gap: 3px;
}

.shortcut-tag {
  --tag: var(--ink-muted);
  flex-shrink: 0;
  min-width: 22px;
  padding: 0 4px;
  border: 1px solid color-mix(in srgb, var(--tag) 40%, transparent);
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--tag) 10%, transparent);
  color: var(--tag);
  font-size: var(--ink-font-xs);
  font-weight: 600;
  line-height: 14px;
  text-align: center;
  letter-spacing: 0.02em;
}

.shortcut-tag.vs {
  --tag: var(--ink-blue);
}

.shortcut-tag.br {
  --tag: var(--ink-green);
}

body.vscode-high-contrast .shortcut-tag {
  border-color: var(--vscode-contrastBorder);
  background: transparent;
  color: var(--vscode-foreground);
}

.shortcut-item.changed .shortcut-label {
  font-weight: 500;
}

.shortcut-actions {
  display: inline-flex;
  flex-shrink: 0;
  justify-content: flex-end;
  gap: 1px;
  /* Room for both buttons (reset, add a key) in every row, so the columns line up. */
  min-width: calc(2 * var(--ink-control-sm) + 1px);
  opacity: 0;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.shortcut-item:hover .shortcut-actions,
.shortcut-item:focus-within .shortcut-actions {
  opacity: 1;
}

.shortcut-keys-column {
  display: inline-flex;
  flex-wrap: wrap;
  flex-shrink: 0;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  /* A steady width, so the VS/BR tags before it line up from row to row. */
  min-width: min(184px, 40%);
  max-width: 62%;
}

.key-button-wrap {
  position: relative;
  display: inline-flex;
}

.key-button {
  display: inline-flex;
  padding: 2px;
  border: 1px solid transparent;
  border-radius: var(--ink-radius);
  background: transparent;
  cursor: pointer;
}

.key-button:hover {
  border-color: var(--ink-border-strong);
  background: var(--ink-surface-sunken);
}

.key-button:focus-visible {
  outline: 1px solid var(--ink-focus);
}

/* The remove badge sits on the key's corner, so showing it doesn't move anything. */
.key-remove {
  position: absolute;
  top: -5px;
  right: -5px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 1px solid var(--ink-border-strong);
  border-radius: 50%;
  background: var(--ink-surface-raised);
  color: var(--ink-muted);
  opacity: 0;
  cursor: pointer;
  transition: opacity var(--ink-fast) var(--ink-ease);
}

.key-remove .codicon {
  font-size: 10px !important;
}

.key-button-wrap:hover .key-remove,
.key-remove:focus-visible {
  opacity: 1;
}

.key-remove:hover {
  border-color: var(--ink-danger);
  background: var(--ink-danger);
  color: #fff;
}

.key-empty {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 22px;
  padding: 0 8px;
  border: 1px dashed var(--ink-border-strong);
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  font: inherit;
  font-size: var(--ink-font-xs);
  cursor: pointer;
}

.key-empty:hover {
  border-color: var(--ink-focus);
  color: var(--vscode-foreground);
}

.key-empty .codicon {
  font-size: 12px !important;
}

.key-recording {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  padding: 0 2px 0 8px;
  border: 1px solid var(--ink-focus);
  border-radius: var(--ink-radius-sm);
  background: var(--ink-accent-soft);
  box-shadow: 0 0 0 1px var(--ink-focus);
  font-size: var(--ink-font-xs);
}

.recording-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #ef4444;
  animation: ink-shortcut-pulse 1s ease-in-out infinite;
}

.key-recording-cancel {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: var(--ink-radius-sm);
  background: transparent;
  color: var(--ink-muted);
  cursor: pointer;
}

.key-recording-cancel:hover {
  background: var(--ink-hover);
  color: inherit;
}

.shortcut-conflict {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 6px;
  padding: 0 0 6px;
  color: var(--ink-warning);
  font-size: var(--ink-font-sm);
}

@keyframes ink-shortcut-pulse {
  50% {
    opacity: 0.3;
  }
}

@media (prefers-reduced-motion: reduce) {
  .recording-dot {
    animation: none;
  }
}

body.vscode-high-contrast .key-button:hover {
  border-color: var(--vscode-contrastBorder);
}

/* Several keys for one action: "Ctrl T / Ctrl F4". */
.key-button-wrap + .key-button-wrap::before {
  content: '/';
  align-self: center;
  margin-right: 2px;
  color: var(--ink-muted);
  font-size: var(--ink-font-xs);
}

/* Element picker hint (PickerHint) ------------------------------------------------------------
   Drawn over page content, so it has its own dark look (the theme's colors could vanish on the
   page), in both products. Each product places it. */
/* Two rows: what a click does (with each modifier), then the keys. */
.picker-hint {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 7px;
  /* Its own width: centered with left: 50%, it would otherwise wrap at half the page. */
  width: max-content;
  padding: 6px 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.9);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  line-height: 1;
  pointer-events: none;
  backdrop-filter: blur(6px);
}

.picker-hint-group {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 6px 14px;
}

.picker-hint-item {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
}

.picker-hint-label {
  color: rgba(250, 250, 250, 0.82);
}

/* The main action, as a sentence; the others read "[Shift] + click  select several". */
.picker-hint-lead {
  color: #fff;
  font-weight: 600;
}

.picker-hint-click {
  color: #fff;
  font-weight: 500;
}

.picker-hint .keycap {
  border-color: rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  box-shadow: inset 0 -1px 0 rgba(255, 255, 255, 0.14);
  color: #fff;
}

/* Multi-selection bar (SelectionBar) ----------------------------------------------------------
   Over page content like the picker hint, so the same dark look; each product places it. */
.selection-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px;
  width: max-content;
  max-width: calc(100vw - 32px);
  padding: 5px 6px 5px 10px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: var(--ink-radius-lg);
  background: rgba(24, 24, 27, 0.94);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
  color: #fafafa;
  font-family: var(--vscode-font-family, system-ui, sans-serif);
  font-size: 12px;
  pointer-events: auto;
}

.selection-bar-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: 6px;
  font-weight: 600;
}

.selection-bar-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: var(--ink-radius-pill);
  background: #0a84ff;
  color: #fff;
  font-size: var(--ink-font-xs);
}

.selection-bar .button.ghost,
.selection-bar .icon-button {
  color: #fafafa;
}

.selection-bar .button.ghost:hover:not(:disabled),
.selection-bar .icon-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.12);
}

.selection-bar .button-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.selection-bar .keycap {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.16);
  box-shadow: none;
  color: #fff;
}

/* Thumbnails with a checkbox each (ThumbPicker): screenshots taken together ------------------- */
.thumb-picker {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(88px, 1fr));
  gap: var(--ink-space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.thumb-picker-item {
  position: relative;
  border-radius: var(--ink-radius);
}

.thumb-picker-image {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  aspect-ratio: 16 / 10;
  padding: 0;
  overflow: hidden;
  border: 1px solid var(--ink-border-subtle);
  border-radius: var(--ink-radius);
  background: var(--vscode-editor-background);
  color: var(--ink-muted);
  cursor: pointer;
  transition:
    opacity var(--ink-fast) var(--ink-ease),
    border-color var(--ink-fast) var(--ink-ease);
}

.thumb-picker-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

.thumb-picker-image:hover {
  border-color: var(--ink-border-strong);
}

/* Left out: dimmed, so what is sent stands out. */
.thumb-picker-item:not(.on) .thumb-picker-image {
  opacity: 0.45;
}

.thumb-picker-item.on .thumb-picker-image {
  border-color: var(--ink-accent);
}

.thumb-picker-check {
  position: absolute;
  top: 4px;
  left: 4px;
  padding: 2px;
  border-radius: var(--ink-radius-sm);
  background: color-mix(in srgb, var(--vscode-editor-background) 80%, transparent);
  box-shadow: var(--ink-shadow-sm);
}

body.vscode-high-contrast .thumb-picker-item.on .thumb-picker-image {
  outline: 1px solid var(--vscode-contrastActiveBorder);
}
`;var tf={global:"Browser",inspect:"Element picker",draw:"Drawing",screenshot:"Screenshot",devtools:"Console and network",device:"Device",measure:"Measure",eyedropper:"Eyedropper",overlay:"Design overlay",tweak:"CSS tweak",record:"Record",a11y:"Accessibility check",capture:"After a capture"},U=e=>`vscodeBrowser.${e}`,Ia=[{id:"tab.new",label:"New tab",scope:"global",keys:["ctrl+t"],command:U("newTab")},{id:"tab.close",label:"Close tab",scope:"global",keys:["ctrl+w","ctrl+f4"],command:U("closeTab")},{id:"tab.reopen",label:"Reopen closed tab",scope:"global",keys:["ctrl+shift+t"],command:U("reopenClosedTab")},{id:"tab.next",label:"Next tab",scope:"global",keys:["ctrl+tab","ctrl+pagedown"],mac:["ctrl+tab","cmd+alt+right"],command:U("nextTab")},{id:"tab.previous",label:"Previous tab",scope:"global",keys:["ctrl+shift+tab","ctrl+pageup"],mac:["ctrl+shift+tab","cmd+alt+left"],command:U("previousTab")},{id:"tab.duplicate",label:"Duplicate tab",scope:"global",keys:[],command:U("duplicateTab")},{id:"tab.private",label:"New private tab",scope:"global",keys:["ctrl+shift+n"],command:U("newPrivateTab")},{id:"window.new",label:"New window",scope:"global",keys:["ctrl+n"],command:U("newWindow")},{id:"nav.address",label:"Focus the address bar",scope:"global",keys:["ctrl+l","alt+d"],mac:["cmd+l","alt+d"],command:U("focusAddressBar")},{id:"nav.back",label:"Back",scope:"global",keys:["alt+left"],mac:["cmd+["],command:U("goBack")},{id:"nav.forward",label:"Forward",scope:"global",keys:["alt+right"],mac:["cmd+]"],command:U("goForward")},{id:"nav.reload",label:"Reload",scope:"global",keys:["ctrl+r","f5"],mac:["cmd+r"],command:U("reload")},{id:"nav.hardReload",label:"Hard reload",scope:"global",keys:["ctrl+shift+r","ctrl+f5"],mac:["cmd+shift+r"],command:U("hardReload")},{id:"nav.stop",label:"Stop loading",scope:"global",keys:[],command:U("stop")},{id:"nav.home",label:"Home page",scope:"global",keys:["alt+home"],mac:["cmd+shift+h"],command:U("goHome")},{id:"page.find",label:"Find in page",scope:"global",keys:["ctrl+f"],command:U("find")},{id:"page.zoomIn",label:"Zoom in",scope:"global",keys:["ctrl+=","ctrl+shift+="],command:U("zoomIn")},{id:"page.zoomOut",label:"Zoom out",scope:"global",keys:["ctrl+-"],command:U("zoomOut")},{id:"page.zoomReset",label:"Reset zoom",scope:"global",keys:["ctrl+0"],command:U("zoomReset")},{id:"page.bookmark",label:"Bookmark this page",scope:"global",keys:["ctrl+d"],command:U("bookmarkPage")},{id:"page.source",label:"View page source",scope:"global",keys:["ctrl+u"],mac:["cmd+alt+u"],command:U("viewSource")},{id:"page.pdf",label:"Save page as PDF",scope:"global",keys:[],command:U("savePdf")},{id:"page.copyUrl",label:"Copy page address",scope:"global",keys:["ctrl+shift+l"],command:U("copyUrl")},{id:"page.external",label:"Open in system browser",scope:"global",keys:[],command:U("openInSystemBrowser")},{id:"page.devtools",label:"Open DevTools",scope:"global",keys:["f12"],command:U("openDevTools")},{id:"page.contextToAgent",label:"Send page context to agent",scope:"global",keys:["ctrl+alt+enter"],command:U("sendPageContextToChat")},{id:"agent.showContext",label:"Show agent context",scope:"global",keys:["ctrl+shift+alt+a"],command:U("showAgentContext"),everywhere:!0},{id:"agent.sendLatest",label:"Send the latest capture to the agent",scope:"global",keys:["ctrl+shift+alt+v"],command:U("sendLatestContext"),everywhere:!0},{id:"open.history",label:"History",scope:"global",keys:["ctrl+h"],mac:["cmd+y"],command:U("showHistory")},{id:"open.downloads",label:"Downloads",scope:"global",keys:["shift+alt+l"],command:U("showDownloads")},{id:"open.bookmarks",label:"Bookmark manager",scope:"global",keys:["ctrl+alt+b"],command:U("showBookmarks")},{id:"open.bookmarksBar",label:"Show or hide the bookmarks bar",scope:"global",keys:["ctrl+shift+b"]},{id:"open.quickActions",label:"Quick actions",scope:"global",keys:["ctrl+shift+k"]},{id:"open.shortcuts",label:"Change keyboard shortcuts",scope:"global",keys:["ctrl+alt+k"],command:U("editShortcuts")},{id:"open.cheatSheet",label:"Keyboard shortcuts of this mode",scope:"global",keys:["ctrl+shift+/"],mac:["cmd+alt+/"]},{id:"mode.inspect",label:"Element picker",scope:"global",keys:["shift+alt+e"]},{id:"mode.draw",label:"Draw on the page",scope:"global",keys:["shift+alt+w"]},{id:"mode.screenshot",label:"Screenshot",scope:"global",keys:["shift+alt+g"]},{id:"mode.devtools",label:"Console and network",scope:"global",keys:["shift+alt+j"]},{id:"mode.device",label:"Device toolbar",scope:"global",keys:["shift+alt+m"]},{id:"mode.measure",label:"Measure",scope:"global",keys:["shift+alt+u"]},{id:"mode.eyedropper",label:"Eyedropper",scope:"global",keys:["shift+alt+y"]},{id:"mode.overlay",label:"Design overlay",scope:"global",keys:["shift+alt+o"]},{id:"mode.tweak",label:"CSS tweak",scope:"global",keys:["shift+alt+v"]},{id:"mode.record",label:"Record the page",scope:"global",keys:["ctrl+alt+r"]},{id:"mode.a11y",label:"Accessibility check",scope:"global",keys:["shift+alt+h"]},{id:"inspect.parent",label:"Select the parent element",scope:"inspect",keys:["up"]},{id:"inspect.child",label:"Select the first child element",scope:"inspect",keys:["down"]},{id:"inspect.copy",label:"Copy the selected elements",scope:"inspect",keys:["enter","c"]},{id:"inspect.screenshot",label:"Screenshot the element",scope:"inspect",keys:["s"]},{id:"inspect.agent",label:"Send the element to the agent",scope:"inspect",keys:["a"]},{id:"inspect.help",label:"Show these shortcuts",scope:"inspect",keys:["shift+/"]},{id:"inspect.exit",label:"Exit",scope:"inspect",keys:["escape"]},{id:"draw.select",label:"Select and move",scope:"draw",keys:["v"]},{id:"draw.pen",label:"Pen",scope:"draw",keys:["p"]},{id:"draw.pencil",label:"Pencil",scope:"draw",keys:["i"]},{id:"draw.marker",label:"Marker",scope:"draw",keys:["m"]},{id:"draw.brush",label:"Brush",scope:"draw",keys:["u"]},{id:"draw.highlighter",label:"Highlighter",scope:"draw",keys:["h"]},{id:"draw.neon",label:"Neon",scope:"draw",keys:["g"]},{id:"draw.line",label:"Line",scope:"draw",keys:["l"]},{id:"draw.arrow",label:"Arrow",scope:"draw",keys:["a"]},{id:"draw.doubleArrow",label:"Double arrow",scope:"draw",keys:["d"]},{id:"draw.rect",label:"Rectangle",scope:"draw",keys:["r"]},{id:"draw.ellipse",label:"Ellipse",scope:"draw",keys:["o"]},{id:"draw.text",label:"Text",scope:"draw",keys:["t"]},{id:"draw.callout",label:"Numbered callout",scope:"draw",keys:["n"]},{id:"draw.blur",label:"Redact (pixelate)",scope:"draw",keys:["b"]},{id:"draw.eraser",label:"Eraser",scope:"draw",keys:["e"]},...[1,2,3,4,5,6,7,8,9].map(e=>({id:`draw.color${e}`,label:`Color ${e}`,scope:"draw",keys:[String(e)]})),{id:"draw.thinner",label:"Thinner stroke",scope:"draw",keys:["["]},{id:"draw.thicker",label:"Thicker stroke",scope:"draw",keys:["]"]},{id:"draw.fill",label:"Fill shapes on or off",scope:"draw",keys:["f"]},{id:"draw.undo",label:"Undo",scope:"draw",keys:["ctrl+z"]},{id:"draw.redo",label:"Redo",scope:"draw",keys:["ctrl+y","ctrl+shift+z"]},{id:"draw.clear",label:"Clear all drawings",scope:"draw",keys:["shift+backspace"]},{id:"draw.visible",label:"Hide or show drawings",scope:"draw",keys:["w"]},{id:"draw.capture",label:"Screenshot the drawing area",scope:"draw",keys:["enter"]},{id:"draw.captureAgent",label:"Screenshot the drawing area and send it to the agent",scope:"draw",keys:["shift+enter"]},{id:"draw.captureMenu",label:"Screenshot menu",scope:"draw",keys:["s"]},{id:"draw.captureGroups",label:"Screenshot each drawing separately",scope:"draw",keys:["alt+g"]},{id:"draw.captureClean",label:"Screenshot the drawing area without drawings",scope:"draw",keys:["alt+c"]},{id:"draw.captureViewport",label:"Screenshot the visible area with drawings",scope:"draw",keys:["alt+v"]},{id:"draw.captureFullPage",label:"Screenshot the full page with drawings",scope:"draw",keys:["alt+f"]},{id:"draw.help",label:"Show these shortcuts",scope:"draw",keys:["shift+/"]},{id:"draw.exit",label:"Stop drawing",scope:"draw",keys:["escape"]},{id:"shot.viewport",label:"Visible area",scope:"screenshot",keys:["v"]},{id:"shot.fullPage",label:"Full page",scope:"screenshot",keys:["f"]},{id:"shot.region",label:"Region",scope:"screenshot",keys:["r"]},{id:"shot.element",label:"Element",scope:"screenshot",keys:["e"]},{id:"shot.drawing",label:"Drawing area",scope:"screenshot",keys:["d"]},{id:"shot.lastToAgent",label:"Send the last screenshot to the agent",scope:"screenshot",keys:["a"],command:U("screenshot.sendToTerminal")},{id:"capture.chat",label:"Send to chat",scope:"capture",keys:["alt+shift+c"]},{id:"capture.terminal",label:"Send to terminal",scope:"capture",keys:["alt+shift+x"]},{id:"capture.save",label:"Save in VS Code",scope:"capture",keys:["alt+shift+s"]},{id:"capture.download",label:"Download",scope:"capture",keys:["alt+shift+d"]},{id:"dev.console",label:"Console",scope:"devtools",keys:["alt+1"]},{id:"dev.network",label:"Network",scope:"devtools",keys:["alt+2"]},{id:"dev.filter",label:"Filter",scope:"devtools",keys:["alt+f"]},{id:"dev.copyErrors",label:"Copy console errors",scope:"devtools",keys:["alt+e"]},{id:"dev.copyFailed",label:"Copy failed requests",scope:"devtools",keys:["alt+q"]},{id:"dev.copyContext",label:"Copy page context",scope:"devtools",keys:["alt+p"]},{id:"dev.contextAgent",label:"Send page context to the agent",scope:"devtools",keys:["alt+shift+p"]},{id:"dev.clear",label:"Clear",scope:"devtools",keys:["alt+k"]},{id:"dev.close",label:"Close",scope:"devtools",keys:["alt+w"]},{id:"device.previous",label:"Previous device",scope:"device",keys:["alt+["]},{id:"device.next",label:"Next device",scope:"device",keys:["alt+]"]},{id:"device.rotate",label:"Rotate",scope:"device",keys:["alt+r"]},{id:"device.touch",label:"Touch and mobile on or off",scope:"device",keys:["alt+t"]},{id:"device.fit",label:"Fit to window",scope:"device",keys:["alt+0"]},{id:"device.zoomIn",label:"Zoom in",scope:"device",keys:["alt+="]},{id:"device.zoomOut",label:"Zoom out",scope:"device",keys:["alt+-"]},{id:"device.network",label:"Next network speed",scope:"device",keys:["alt+n"]},{id:"device.theme",label:"Next color scheme",scope:"device",keys:["alt+l"]},{id:"device.close",label:"Close the device toolbar",scope:"device",keys:[]},{id:"measure.grid",label:"Rulers and grid on or off",scope:"measure",keys:["g"]},{id:"measure.copy",label:"Copy the measurements",scope:"measure",keys:["c"]},{id:"measure.clear",label:"Clear the pinned element",scope:"measure",keys:["backspace"]},{id:"measure.help",label:"Show these shortcuts",scope:"measure",keys:["shift+/"]},{id:"measure.exit",label:"Exit",scope:"measure",keys:["escape"]},{id:"eyedropper.hex",label:"Copy colors as hex",scope:"eyedropper",keys:["h"]},{id:"eyedropper.rgb",label:"Copy colors as rgb()",scope:"eyedropper",keys:["r"]},{id:"eyedropper.hsl",label:"Copy colors as hsl()",scope:"eyedropper",keys:["l"]},{id:"eyedropper.help",label:"Show these shortcuts",scope:"eyedropper",keys:["shift+/"]},{id:"eyedropper.exit",label:"Exit",scope:"eyedropper",keys:["escape"]},{id:"overlay.open",label:"Open an image",scope:"overlay",keys:["alt+o"]},{id:"overlay.fainter",label:"Less opaque",scope:"overlay",keys:["alt+,"]},{id:"overlay.stronger",label:"More opaque",scope:"overlay",keys:["alt+."]},{id:"overlay.left",label:"Nudge left",scope:"overlay",keys:["alt+left"]},{id:"overlay.right",label:"Nudge right",scope:"overlay",keys:["alt+right"]},{id:"overlay.up",label:"Nudge up",scope:"overlay",keys:["alt+up"]},{id:"overlay.down",label:"Nudge down",scope:"overlay",keys:["alt+down"]},{id:"overlay.difference",label:"Difference blend on or off",scope:"overlay",keys:["alt+x"]},{id:"overlay.hide",label:"Hide or show the overlay",scope:"overlay",keys:["alt+h"]},{id:"overlay.exit",label:"Close the overlay",scope:"overlay",keys:["alt+z"]},{id:"tweak.agent",label:"Send the CSS changes to the agent",scope:"tweak",keys:["ctrl+enter"]},{id:"tweak.copy",label:"Copy the CSS changes",scope:"tweak",keys:["ctrl+shift+c"]},{id:"tweak.undo",label:"Undo the last change",scope:"tweak",keys:["ctrl+z"]},{id:"tweak.exit",label:"Exit and revert",scope:"tweak",keys:["escape"]},{id:"record.stop",label:"Stop and save",scope:"record",keys:["alt+s"]},{id:"record.pause",label:"Pause or resume",scope:"record",keys:["alt+y"]},{id:"record.cancel",label:"Cancel",scope:"record",keys:["alt+backspace"]},{id:"a11y.next",label:"Next issue",scope:"a11y",keys:["n","down"]},{id:"a11y.previous",label:"Previous issue",scope:"a11y",keys:["p","up"]},{id:"a11y.tabOrder",label:"Tab order on or off",scope:"a11y",keys:["t"]},{id:"a11y.copy",label:"Copy the report",scope:"a11y",keys:["c"]},{id:"a11y.agent",label:"Send the report to the agent",scope:"a11y",keys:["a"]},{id:"a11y.help",label:"Show these shortcuts",scope:"a11y",keys:["shift+/"]},{id:"a11y.exit",label:"Exit",scope:"a11y",keys:["escape"]}];function nf(e,t){return t?[...e.mac??e.keys.map(n=>n.replace(/\bctrl\+/,"cmd+"))]:[...e.keys]}function of(e){let t=uf(e.trim());return t.key?[t.ctrl&&"ctrl",t.shift&&"shift",t.alt&&"alt",t.meta&&"cmd",t.key].filter(Boolean).join("+"):""}function Pa(e,t){let n={};for(let o of Ia){let a=e[o.id],l=(a===void 0?nf(o,t):typeof a=="string"?[a]:[...a]).map(of);n[o.id]=[...new Set(l.filter(Boolean))]}return n}function af(e){if(!e||typeof e!="object"||Array.isArray(e))return{};let t=new Set(Ia.map(o=>o.id)),n={};for(let[o,a]of Object.entries(e))t.has(o)&&(typeof a=="string"||Array.isArray(a)&&a.every(l=>typeof l=="string"))&&(n[o]=a);return n}var lf=new Set(["mode.inspect","mode.draw","mode.screenshot","mode.device","mode.devtools","page.bookmark","open.shortcuts","inspect.parent","inspect.child","inspect.copy","inspect.exit",...["select","pen","pencil","marker","brush","highlighter","neon","line","arrow","doubleArrow","rect","ellipse","text","callout","blur","eraser"].map(e=>`draw.${e}`),...Array.from({length:9},(e,t)=>`draw.color${t+1}`),"draw.thinner","draw.thicker","draw.fill","draw.undo","draw.redo","draw.clear","draw.visible","draw.capture","draw.captureMenu","draw.captureGroups","draw.captureClean","draw.captureViewport","draw.captureFullPage","draw.exit","shot.viewport","shot.fullPage","shot.region","shot.element","shot.drawing","capture.chat","capture.terminal","capture.save","capture.download"]);function cf(e,t){let n=tm(e,t);return t?[...[...n.matchAll(/[⌃⌥⇧⌘]/g)].map(a=>a[0]),n.replace(/[⌃⌥⇧⌘]/g,"")]:n.split(/\+(?=.)/)}function tm(e,t){let n=uf(e),o={escape:"Esc",enter:t?"\u21A9":"Enter",backspace:t?"\u232B":"Backspace",delete:t?"\u2326":"Delete",up:"\u2191",down:"\u2193",left:"\u2190",right:"\u2192",pageup:"PgUp",pagedown:"PgDn",tab:t?"\u21E5":"Tab",space:"Space","/":n.shift?"?":"/"},a=!(n.key==="/"&&n.shift),l=o[n.key]??(n.key.length===1?n.key.toUpperCase():n.key[0].toUpperCase()+n.key.slice(1));return t?`${n.ctrl?"\u2303":""}${n.alt?"\u2325":""}${n.shift&&a?"\u21E7":""}${n.meta?"\u2318":""}${l}`:[n.ctrl&&"Ctrl",n.alt&&"Alt",n.shift&&a&&"Shift",l].filter(Boolean).join("+")}function uf(e){let t=e.toLowerCase().split("+"),n=t.pop()??"";return{ctrl:t.includes("ctrl"),shift:t.includes("shift"),alt:t.includes("alt"),meta:t.includes("cmd")||t.includes("meta")||t.includes("win"),key:n}}var Ef=Be(Jo(),1);var Tf,ym=e=>{let t=e.composedPath()[0];if(e.button!==0){Tf=void 0;return}t instanceof Element&&(Tf={element:t.closest('button, [role="button"], a')??t,at:performance.now()})};typeof window<"u"&&window.addEventListener("pointerdown",ym,!0);function Jc(...e){return e.filter(Boolean).join(" ")}var Wn=Be(at(),1);function Fo({variant:e="secondary",size:t="md",icon:n,iconEnd:o,loading:a,className:l,children:c,disabled:i,type:u="button",...f}){let g=a?"loading":n;return(0,Wn.jsxs)("button",{type:u,className:Jc("button",e,t==="sm"&&"small",l),disabled:i||a,"aria-busy":a||void 0,...f,children:[g&&(0,Wn.jsx)("span",{className:Jc("codicon",`codicon-${g}`,a&&"codicon-modifier-spin"),"aria-hidden":"true"}),c!==void 0&&(0,Wn.jsx)("span",{className:"button-label",children:c}),o&&(0,Wn.jsx)("span",{className:`codicon codicon-${o}`,"aria-hidden":"true"})]})}var Fc=Be(at(),1);function Nf({icon:e,label:t,onClick:n,onContextMenu:o,disabled:a,active:l,spin:c,className:i}){return(0,Fc.jsx)("button",{type:"button",className:["icon-button",l&&"active",i].filter(Boolean).join(" "),title:t,"aria-label":t,"aria-pressed":l,disabled:a,onClick:n,onContextMenu:o,children:(0,Fc.jsx)("span",{className:`codicon codicon-${e}${c?" codicon-modifier-spin":""}`,"aria-hidden":"true"})})}var Wc=Be(at(),1),km=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh");function $c({binding:e,size:t="md"}){let n=cf(e,km);return(0,Wc.jsx)("span",{className:`keycaps size-${t}`,"aria-label":n.join("+"),children:n.map((o,a)=>(0,Wc.jsx)("kbd",{className:"keycap",children:o},a))})}var Kn=Be(Jo()),Vg=Be(Ug());var Jr="inkspectShortcuts",Fr=typeof navigator<"u"&&navigator.userAgent.includes("Macintosh"),Hg=Ia.filter(e=>lf.has(e.id)),_0={"mode.device":"Responsive view","mode.screenshot":"Screenshot menu","open.shortcuts":"Keyboard shortcuts"},qg=e=>_0[e.id]??e.label;var Bg=["global","inspect","draw","screenshot"],cy=[...Bg,...Object.keys(tf).filter(e=>!Bg.includes(e))];async function C0(){let e=(await chrome.storage.sync.get(Jr))[Jr];return{overrides:af(e?.shortcuts??{}),updated:typeof e?.updated=="number"?e.updated:0}}function Yg(e){let t=()=>{C0().then(o=>e(Pa(o.overrides,Fr),o))},n=(o,a)=>{a==="sync"&&o[Jr]&&t()};return chrome.storage.onChanged.addListener(n),t(),()=>chrome.storage.onChanged.removeListener(n)}var ce=Be(at());function Gg({status:e,limit:t=1/0,size:n="lg"}){let o=e.state==="connected",a=o?e.windows?.length?[...e.windows].sort((u,f)=>u.name.localeCompare(f.name)||u.id.localeCompare(f.id)):[{id:"peer",name:e.peer??"VS Code",lastUsed:!0}]:[],l=a.slice(0,t),c=a.length-l.length,i=l.findIndex(u=>u.lastUsed);return(0,ce.jsxs)("div",{className:`link-graph size-${n} state-${e.state}`,"aria-hidden":"true",children:[(0,ce.jsx)("span",{className:"graph-node source",children:(0,ce.jsx)("span",{className:"codicon codicon-globe"})}),(0,ce.jsx)("ul",{className:"graph-targets",children:o?(0,ce.jsxs)(ce.Fragment,{children:[l.map((u,f)=>(0,ce.jsxs)("li",{className:`graph-target${u.lastUsed?" lit":f<i?" on-path":""}`,children:[(0,ce.jsx)("span",{className:"graph-node",children:(0,ce.jsx)("span",{className:"codicon codicon-vscode"})}),(0,ce.jsx)("span",{className:"graph-name",children:u.name}),u.lastUsed&&(0,ce.jsx)("span",{className:"graph-tag",children:"Sends go here"})]},u.id)),c>0&&(0,ce.jsx)("li",{className:"graph-target more",children:(0,ce.jsxs)("span",{className:"graph-name",children:["and ",c," more"]})})]}):(0,ce.jsxs)("li",{className:"graph-target pending",children:[(0,ce.jsx)("span",{className:"graph-node",children:(0,ce.jsx)("span",{className:"codicon codicon-vscode"})}),(0,ce.jsx)("span",{className:"graph-name",children:"VS Code"})]})})]})}var jg=`/* LinkGraph: the browser, and a branch to each VS Code window (a tree connector drawn in CSS).
   The branch to the window used last is lit: that is where sends go. */

.link-graph {
  --line: color-mix(in srgb, var(--vscode-foreground) 20%, transparent);
  --lit: var(--ink-blue);
  --node: 44px;
  --stem: 32px;
  --stroke: 2px;
  --row-pad: 5px;
  display: flex;
  align-items: flex-start;
  min-width: 0;
}

.link-graph.size-sm {
  --node: 30px;
  --stem: 18px;
  --row-pad: 3px;
}

.link-graph.state-unpaired {
  --line: color-mix(in srgb, var(--ink-yellow) 70%, transparent);
}

.link-graph.state-connecting {
  --line: color-mix(in srgb, var(--ink-blue) 55%, transparent);
}

.graph-node {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: var(--node);
  height: var(--node);
  border: 1px solid var(--ink-border-strong);
  border-radius: calc(var(--node) / 3.2);
  background: linear-gradient(
    180deg,
    color-mix(in srgb, var(--vscode-foreground) 7%, var(--vscode-editor-background)),
    var(--vscode-editor-background)
  );
  color: var(--vscode-foreground);
  box-shadow: var(--ink-shadow-sm);
}

.size-lg .graph-node .codicon {
  font-size: 22px !important;
}

.size-sm .graph-node .codicon {
  font-size: 15px !important;
}

/* The source sits level with the first branch; its stem runs straight into it (the border is
   outside the pseudo-element's box, so it starts one pixel further out to meet the bus). */
.graph-node.source {
  position: relative;
  margin-top: var(--row-pad);
  margin-right: var(--stem);
}

.graph-node.source::after {
  content: '';
  position: absolute;
  top: calc(50% - var(--stroke) / 2);
  left: calc(100% + 1px);
  width: var(--stem);
  height: var(--stroke);
  background: var(--line);
}

.link-graph.state-connected .graph-node.source::after {
  background: var(--lit);
}

.link-graph:not(.state-connected) .graph-node.source::after {
  background: repeating-linear-gradient(90deg, var(--line) 0 5px, transparent 5px 9px);
}

.graph-targets {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  margin: 0;
  padding: 0;
  list-style: none;
}

.graph-target {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  padding: var(--row-pad) 0 var(--row-pad) var(--stem);
}

.size-sm .graph-target {
  gap: 9px;
}

/* The branch into this target, and the bus down to the next (rounded into the bus). */
.graph-target::before {
  content: '';
  position: absolute;
  top: calc(50% - var(--stroke) / 2);
  left: 0;
  width: var(--stem);
  height: var(--stroke);
  border-radius: var(--stroke);
  background: var(--line);
}

.graph-target::after {
  content: '';
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: var(--stroke);
  background: var(--line);
}

.graph-target:first-child::after {
  top: 50%;
}

.graph-target:last-child::after {
  bottom: 50%;
}

.graph-target:only-child::after {
  display: none;
}

.graph-target.pending::before {
  background: repeating-linear-gradient(90deg, var(--line) 0 5px, transparent 5px 9px);
}

/* Where sends go: lit, and so is the bus from the browser down to it. */
.graph-target.lit::before {
  z-index: 1;
  background: var(--lit);
}

.graph-target::before,
.graph-target::after,
.graph-node {
  transition:
    background-color 0.2s ease,
    border-color 0.2s ease,
    color 0.2s ease;
}

.graph-target.on-path::after {
  background: var(--lit);
}

/* The lit row: the bus is lit down to its branch, and plain below it. */
.graph-target.lit:not(:first-child)::after {
  background: linear-gradient(var(--lit) 0 50%, var(--line) 50% 100%);
}

.graph-target.lit:last-child:not(:first-child)::after {
  background: var(--lit);
}

.graph-target.lit .graph-node {
  border-color: var(--lit);
  background: color-mix(in srgb, var(--lit) 14%, var(--vscode-editor-background));
  color: var(--lit);
}

.graph-target.pending .graph-node {
  color: var(--ink-blue);
}

.graph-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.graph-target.lit .graph-name {
  font-weight: 600;
}

.graph-target.more .graph-name {
  color: var(--ink-muted);
}

.graph-target.more::before {
  background: repeating-linear-gradient(90deg, var(--line) 0 2px, transparent 2px 5px);
}

.graph-tag {
  flex-shrink: 0;
  padding: 1px 8px;
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--lit) 16%, transparent);
  color: var(--lit);
  font-size: var(--ink-font-xs);
  font-weight: 600;
}
`;var Lg=`/* The toolbar button's popup. Components and tokens come from @inkspect/shared/ui; the link
   graph from ../ui/link-graph.css. */

* {
  box-sizing: border-box;
}

html,
body {
  margin: 0;
  background: var(--vscode-editor-background);
  color: var(--vscode-foreground);
  font-family: var(--vscode-font-family);
  font-size: var(--vscode-font-size);
  line-height: 1.45;
}

.muted {
  color: var(--ink-muted);
}

.popup {
  --tone: var(--ink-muted);
  display: flex;
  flex-direction: column;
  gap: 12px;
  width: 360px;
  padding: 14px 14px 0;
}

.popup.tone-ok {
  --tone: var(--ink-green);
}

.popup.tone-warn {
  --tone: var(--ink-yellow);
}

.popup.tone-busy {
  --tone: var(--ink-blue);
}

.popup-head {
  display: flex;
  align-items: center;
  gap: 10px;
}

.popup-head img {
  width: 24px;
  height: 24px;
  border-radius: 7px;
}

.popup-name {
  flex: 1;
  font-size: var(--ink-font-lg);
  font-weight: 700;
  letter-spacing: -0.01em;
}

.popup-state {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 24px;
  padding: 0 10px;
  border: 1px solid color-mix(in srgb, var(--tone) 35%, transparent);
  border-radius: var(--ink-radius-pill);
  background: color-mix(in srgb, var(--tone) 10%, transparent);
  font-size: var(--ink-font-xs);
  font-weight: 600;
}

.status-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--tone);
}

/* The link, on a dot-grid canvas: the popup's picture. */
.popup-link {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 14px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: 14px;
  background:
    radial-gradient(
        circle at 1px 1px,
        color-mix(in srgb, var(--vscode-foreground) 14%, transparent) 1px,
        transparent 0
      )
      0 0 / 14px 14px,
    var(--vscode-editorWidget-background);
  box-shadow: var(--ink-shadow-sm);
}

.popup-unlinked {
  display: flex;
  align-items: center;
  gap: 10px;
}

.popup-unlinked p {
  flex: 1;
  margin: 0;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.popup-action {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.open-toolbar {
  width: 100%;
  height: 42px;
  padding: 0 14px;
  border-radius: 12px;
  font-weight: 600;
}

.open-toolbar .button-label {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.open-toolbar .keycap {
  border-color: color-mix(in srgb, var(--vscode-button-foreground) 35%, transparent);
  background: color-mix(in srgb, var(--vscode-button-foreground) 16%, transparent);
  color: var(--vscode-button-foreground);
}

.popup-hint {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0;
  color: var(--ink-muted);
  font-size: var(--ink-font-sm);
}

.popup-hint {
  flex-wrap: wrap;
}

.popup-hint .button {
  flex-shrink: 0;
  margin-left: auto;
}

.popup-error {
  display: flex;
  gap: 6px;
  margin: 0;
  color: var(--ink-danger);
  font-size: var(--ink-font-sm);
}

/* The main keys, two by two. */
.popup-keys {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
}

.key-tile {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 8px;
  padding: 10px 11px;
  border: 1px solid var(--ink-border-subtle);
  border-radius: 12px;
  background: var(--vscode-editorWidget-background);
}

.key-tile-label {
  display: flex;
  align-items: center;
  gap: 7px;
  color: var(--vscode-foreground);
  font-size: var(--ink-font-sm);
  font-weight: 500;
}

.key-tile-label .codicon {
  color: var(--ink-blue);
  font-size: 14px !important;
}

.popup-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 2px -14px 0;
  padding: 8px 10px;
  border-top: 1px solid var(--ink-border-subtle);
}
`;var C=Be(at()),R0=["mode.inspect","mode.draw","mode.screenshot","mode.device"],U0={"mode.inspect":"inspect","mode.draw":"edit","mode.screenshot":"device-camera","mode.device":"device-mobile"},B0={connected:{label:"Linked",tone:"ok"},connecting:{label:"Connecting",tone:"busy"},unpaired:{label:"Not paired",tone:"warn"},offline:{label:"VS Code not running",tone:"off"}};function Wr(e){chrome.tabs.create({url:chrome.runtime.getURL(`options.html${e?`#${e}`:""}`)}),window.close()}function H0(){let[e,t]=(0,Kn.useState)({state:"connecting"}),[n,o]=(0,Kn.useState)(()=>Pa({},Fr)),[a,l]=(0,Kn.useState)(),[c,i]=(0,Kn.useState)("");(0,Kn.useEffect)(()=>{let m=()=>{chrome.runtime.sendMessage({type:"status"}).then(y=>y&&t(y))};m();let d=setInterval(m,1500),v=Yg(y=>o(y));return chrome.commands.getAll().then(y=>l(y.find(x=>x.name==="toggle-toolbar")?.shortcut??"")),()=>{clearInterval(d),v()}},[]);let u=async()=>{let m=await chrome.runtime.sendMessage({type:"toggleToolbar"}).catch(()=>null);m?.ok?window.close():i(m?.error??"The toolbar could not open on this page.")},f=B0[e.state],g=e.state==="connected";return(0,C.jsxs)("main",{className:`popup tone-${f.tone}`,children:[(0,C.jsxs)("header",{className:"popup-head",children:[(0,C.jsx)("img",{src:"icons/32.png",alt:""}),(0,C.jsx)("span",{className:"popup-name",children:"Inkspect"}),(0,C.jsxs)("span",{className:"popup-state",role:"status",children:[(0,C.jsx)("span",{className:"status-dot","aria-hidden":"true"}),f.label]})]}),(0,C.jsxs)("section",{className:"popup-link","aria-label":"VS Code",children:[(0,C.jsx)(Gg,{status:e,size:"sm"}),!g&&(0,C.jsxs)("div",{className:"popup-unlinked",children:[(0,C.jsx)("p",{children:e.state==="unpaired"?(0,C.jsxs)(C.Fragment,{children:["In VS Code, click ",(0,C.jsx)("b",{children:"Pair Browser Extension"})," in the Browser side panel. No code needed."]}):"Start VS Code with VS Code Browser to link it."}),e.state==="unpaired"&&(0,C.jsx)(Fo,{size:"sm",variant:"ghost",icon:"key",onClick:()=>Wr("vscode-code"),children:"Use a code"})]})]}),(0,C.jsxs)("div",{className:"popup-action",children:[(0,C.jsxs)(Fo,{variant:"primary",icon:"inspect",className:"open-toolbar",onClick:u,children:[(0,C.jsx)("span",{className:"open-label",children:"Open toolbar on this page"}),a&&(0,C.jsx)($c,{binding:a.toLowerCase(),size:"sm"})]}),a===""&&(0,C.jsxs)("p",{className:"popup-hint",children:[(0,C.jsx)("span",{className:"codicon codicon-keyboard","aria-hidden":"true"}),(0,C.jsx)("span",{children:"No shortcut is set for this."}),(0,C.jsx)(Fo,{size:"sm",variant:"ghost",onClick:()=>{chrome.tabs.create({url:"chrome://extensions/shortcuts"})},children:"Set one"})]}),c&&(0,C.jsxs)("p",{className:"popup-error",role:"alert",children:[(0,C.jsx)("span",{className:"codicon codicon-error","aria-hidden":"true"}),c]})]}),(0,C.jsx)("section",{className:"popup-keys","aria-label":"Main shortcuts",children:R0.map(m=>{let d=Hg.find(y=>y.id===m),v=n[m]?.[0];return d?(0,C.jsxs)("div",{className:"key-tile",children:[(0,C.jsxs)("span",{className:"key-tile-label",children:[(0,C.jsx)("span",{className:`codicon codicon-${U0[m]}`,"aria-hidden":"true"}),qg(d)]}),v?(0,C.jsx)($c,{binding:v,size:"sm"}):(0,C.jsx)("span",{className:"muted",children:"No key"})]},m):null})}),(0,C.jsxs)("footer",{className:"popup-foot",children:[(0,C.jsx)(Fo,{size:"sm",variant:"ghost",icon:"link-external",onClick:()=>Wr(),children:"Open Inkspect"}),(0,C.jsx)(Nf,{icon:"keyboard",label:"Change shortcuts",onClick:()=>Wr("shortcuts")})]})]})}var Qg=document.createElement("style");Qg.textContent=[Ir,Pr,ef,jg,Lg].join(`
`);document.head.append(Qg);document.documentElement.classList.add("ink-theme");(0,Vg.createRoot)(document.getElementById("root")).render((0,C.jsx)(H0,{}));})();
